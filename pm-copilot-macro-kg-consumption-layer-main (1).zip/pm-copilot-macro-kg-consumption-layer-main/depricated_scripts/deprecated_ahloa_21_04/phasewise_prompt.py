PHASE_SCHEMA_DESCRIPTIONS = {
0: """
=== BASE NODES: Core Entities ===

Foundational Nodes - TMobile, Nokia, Site, Vendor and SC Vendor.
TMobile assigns Site (as a project) to Nokia. Vendor and SC Vendor work on this Site.
All Market, Area, Region and State filters are from Site node only.

--- NODES ---

1. TMobile
   
2. Nokia
   
3. Site
   - s_site_id                          | STRING | Unique site identifier; primary key (e.g., '9NV0517R')
   - s_site_name                        | STRING | Human-readable site name (e.g., 'Nolensville II')
   - s_state                            | STRING | State abbreviation ("OR", "ND", "OH", "KY", "IN", "WV", "NE", "MO", "AR", "WI", "SD", "OK", "ID", "MN", "PA", "WY", "MT", "IL", "TN", "MI", "WA", "UT", "IA", "CO", "VA", "AZ" and "KS" only) **Key for state filter**
   - region                             | STRING | Nokia region ("WEST" and "CENTRAL" only) **Key for region filter**
   - m_area                             | STRING | Market area grouping ("Great Lakes", "Appalachian", "Desert West", "North West", "Midwest Rockies" and "Heartland" only) **Key for area filter**
   - m_market                           | STRING | Specific market ("WICHITA KS", "NASHVILLE", "DETROIT MI", "DAKOTAS", "DES MOINES IA", "INDIANAPOLIS IN", "COLUMBUS", "LOUISVILLE", "MILWAUKEE", "MONTANA", "WEST VIRGINIA", "MINNEAPOLIS MN", "DENVER CO", "SPOKANE WA", "TULSA OK", "KANSAS CITY KS", "ARKANSAS", "CINCINNATI", "KNOXVILLE TN", "PORTLAND OR", "CLEVELAND", "PHOENIX", "OMAHA", "CHICAGO", "ST. LOUIS", "SEATTLE WA", "OKLAHOMA CITY OK" and "PITTSBURGH PA" only) **Key for market filter**
   
4. Vendor
   - construction_gc        | STRING | General contractor (Vendor) company name; primary key
   
5. SC_Vendor
   - pj_soft_cost_vendor | STRING | SC_Vendor name (Soft-cost vendor); primary key
   
--- RELATIONSHIPS ---

(Site)<-[:GETS_SITE]-(Nokia)
(Site)<-[:ASSIGNS_SITE]-(TMobile)
(Site)<-[:WORKS_ON]-(Vendor)
(Site)<-[:SC_VENDOR_WORKS_ON]-(SC_Vendor)
(Site)-[:SITE_HAS_PROJECT]->(Phase1_ProjectAssignment)

--- ALL PHASE RELATIONS ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_P9]->(Phase9_Tower_Work)
       -[:P9_TO_P10]->(Phase10_Integration)
       -[:P10_TO_P11]->(Phase11_Post_Integration)
       -[:P11_TO_P12]->(Phase12_Revenue)

""",

"HSE": """
=== HSE: Health, Safety and Environment ===

The HSE node records safety compliance linkage during active construction phases. It links from the project path starting at Site, and contains visit-level records per project.

--- NODES ---

1. HSE
   - pj_project_id | STRING | Unique project identifier; primary key

2. Visit
   - pj_project_id             | STRING  | Project identifier this visit belongs to
   - visit_num                 | INTEGER | Visit sequence number; part of composite key
   - check_in_status           | STRING  | Crew check-in status 
   - check_in_date             | STRING  | Date of the crew check-in
   - ppe_validation            | STRING  | PPE inspection result
   - ppe_photo_available       | STRING  | Whether PPE photo was captured
   - jsa_completion_status     | STRING  | JSA completion status
   - each_crew_ptid_l2w_status | STRING  | PTID L2W availability status

--- RELATIONSHIPS (Site path shown ONCE) ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_HSE]->(HSE)

(HSE)-[:VISITS]->(Visit)
""",

"DEC_COP": """
=== DEC_COP: Close-Out Package & Punch List Workflow ===

The DEC_COP node tracks Nokia's close-out package (COP) submitted to T-Mobile after construction. 
It also anchors the punch list's (A checklist to be filled by Vendor during work) workflow - submission, returns, re-submission, and final approvals.
Here milestones from 3 databases are involved. Use prefix to distinguish them. 
pj_ are from TMobile DB, ms_ are from Nokia DB and scop_ are from DEC DB. 
In DEC DB tower and civil punch lists are seperately tracked.
--- NODES ---

1. DEC_COP
   - pj_project_id   | STRING | Unique project identifier; primary key
   - scop_title      | STRING | COP title (e.g., 'A1Q0166G_CENTRAL_*_Close Out Pack')
   - approvedpercent | STRING | COP approval percentage by T-Mobile (e.g., '100', '39')

2. Punch_List_status
In this phase the Vendor fills the checklist / punchlist and parallely Nokia team approves it (checks it). 
The approve result can be rejected. Yet to approve are pending. While completed are ones which are not rejected by Nokia.
   - pj_project_id                              | STRING | Primary key
   - scop_title                                 | STRING | Session/COP title
   - scop_ndpc_session_created_cw               | LOCAL_DATE_TIME | Session creation date
   - scop_ndpc_session_cw_last_activity         | LOCAL_DATE_TIME | Vendor last visit date
   - scop_ndpc_session_cw_pending_pct           | STRING | Civil: pending %
   - scop_ndpc_session_cw_completed_pct         | STRING | Civil: completed %
   - scop_ndpc_session_cw_approved_pct          | STRING | Civil: approved %
   - scop_ndpc_session_cw_rejected_pct          | STRING | Civil: rejected %
   - scop_ndpc_session_tw_pending_pct           | STRING | Tower: pending %
   - scop_ndpc_session_tw_completed_pct         | STRING | Tower: completed %
   - scop_ndpc_session_tw_approved_pct          | STRING | Tower: approved %
   - scop_ndpc_session_tw_rejected_pct          | STRING | Tower: rejected %

3. PL_Submission
Once the approvedpercent (from DEC_COP node) reaches 95%, it is submitted to TMobile for the first time in 1557 milestone.
   - pj_project_id                                        | STRING           | Primary key
   - ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl | LOCAL_DATE_TIME | Punch checklist 1st submission date in Nokia DB
   - ms_1558_admin_checklist_submitted_to_t_mobile_actual | LOCAL_DATE_TIME  | Admin checklist 1st submission date in Nokia DB
   - ms_1553_review_civil_quality_media_checklist         | LOCAL_DATE_TIME  | Civil quality/media checklist review from Nokia DB
   - pj_a_5500_receive_close_out_binder_finish | LOCAL_DATE_TIME | Punch checklist (Close out binder) recieved by TMobile for the first time, recorded in TMobile DB.
   - pj_p_5500_receive_close_out_binder_finish | LOCAL_DATE_TIME | <Planned>

4. PL_Post_Submission
Post submission, the rejected punch list is given back to Vendor after 7 days of 1557
   - pj_project_id                          | STRING          | Primary key
   - pj_a_5400_punch_list_to_gc_finish      | LOCAL_DATE_TIME | Vendor recieves rejected punch list.
   - pj_p_5400_punch_list_to_gc_finish      | LOCAL_DATE_TIME | <Planned>

5. PL_Resubmission
Nokia team reworks with Vendor on the rejected punchlist and they resubmit it finally, it takes upto 14 days at max from 5400.

   - pj_project_id                           | STRING          | Primary key
   - pj_a_5425_punch_list_complete_finish    | LOCAL_DATE_TIME | Punchlist resubmission date
   - pj_p_5425_punch_list_complete_finish    | LOCAL_DATE_TIME | <Planned>
   - scop_pending_days_for_gc_action         | STRING          | Days pending GC action from 5400

6. PL_Final_Approval
TMobile finally closes the Punchlist post resubmission (5425)
   - pj_project_id                              | STRING          | Primary key
   - pj_a_5525_approve_close_out_binder_finish  | LOCAL_DATE_TIME | Punch list (Close out binder) closing date in TMobile DB
   - pj_p_5525_approve_close_out_binder_finish  | LOCAL_DATE_TIME | <Planned>
   - ms_1559_cop_approved_by_t_mobile_actual    | LOCAL_DATE_TIME | TMobile punch list closing / final approval date in Nokia DB.
   - scop_checklist_accepted_by_customer        | STRING          | Same milestone in DEC database
   - pj_p_5540_financial_closeout_finish        | LOCAL_DATE_TIME | Planned date for DEC_COP finance close out (IA,GR,CA,BBR,etc)
   - magenta_ms_5525_actual                     | LOCAL_DATE_TIME | DEC_COP punchlist process completion date in Nokia DB.

--- RELATIONSHIPS (Site paths shown ONCE) ---

# Site → DEC_COP 
(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_DEC_COP]->(DEC_COP)

# DEC_COP → PL nodes
(DEC_COP)-[:HAS_PL]->(Punch_List_status)
(DEC_COP)-[:PL_SUBMITTED]->(PL_Submission)
(DEC_COP)-[:PL_RETURNED]->(PL_Post_Submission)
(DEC_COP)-[:PL_RESUBMITTED]->(PL_Resubmission)
(DEC_COP)-[:PL_APPROVED]->(PL_Final_Approval)

""",

1: """
=== PHASE 1: Project Initialization and Setup ===

Project details like Build Plan Year, Entitlement Complete Year, Project type (M-Modification General only) and a unique Por ID. 
Hard cost, soft cost and Vendor(GC or General Contractor) assignment details like comments, dates etc.
A unique smp_id for every project. And some more smp_details like smp_name (AHLOB Modernization only),
This phase also contains any drone (talonview) survey activity details.

--- NODES ---

1. Phase1_ProjectAssignment
   - pj_project_id   | STRING | Unique project identifier; primary key
   - s_site_id       | STRING | Site ID the project is assigned to
   - assigned_status | STRING | 'Assigned' / 'Not Assigned' only

2. SMP_ID_Creation
   - pj_project_id | STRING | Primary key
   - smp_id        | STRING | SMP WO ID (e.g., 'SMP-WO-1296358'), it is a unique project identifier just like pj_project_id
   - smp_name      | STRING | SMP program name (AHLOB Modernization only)
   - smp_status    | STRING | SMP status ('Active' and 'Cancelled' only)

3. Phase1_Details
   - pj_project_id                 | STRING | Primary key
   - pj_project_type               | STRING | Project type ('M-Modification General' only)
   - por_por_id                    | STRING | POR reference ID

4. Hard_cost_vendor_assignment
   - pj_project_id                     | STRING          | Primary key
   - pj_hard_cost_vendor_assignment_po | STRING          | HC Vendor Name
   - pj_hard_cost_approval_date        | LOCAL_DATE_TIME | HC approval date
   - assigned_status                   | STRING          | 'Assigned' / 'Not Assigned' only

5. Soft_cost_vendor_assignment
   - pj_project_id                        | STRING          | Primary key
   - pj_soft_cost_vendor                  | STRING          | Soft cost vendor Name
   - pj_soft_cost_approval_date           | LOCAL_DATE_TIME | Soft cost approval date
   - assigned_status                      | STRING          | 'Assigned' / 'Not Assigned' only

6. Vendor_assignment
   - pj_project_id                | STRING          | Primary key
   - construction_gc              | STRING/FLOAT    | Assigned GC
   - assigned_status              | STRING          | 'Assigned' / 'Not Assigned'
   - pj_a_3775_gc_selected_finish | LOCAL_DATE_TIME | Vendor (GC) assignment date in TMobile DB
   - pj_p_3775_gc_selected_finish | LOCAL_DATE_TIME | <Planned>

7. Drone
   - pj_project_id                           | STRING          | Primary key
   - ms_1321_talon_view_drone_svcs_actual    | LOCAL_DATE_TIME | Drone work Assigned Date. Use this key to filter all sites with Drone activities. 

   
--- ADDITIONAL RELATIONSHIPS (ALL start at Site) ---

(Phase1_ProjectAssignment)-[:HAS_DETAILS]->(Phase1_Details)
(Phase1_ProjectAssignment)-[:HAS_SUBPHASE]->(SMP_ID_Creation)
(Phase1_ProjectAssignment)-[:HAS_SUBPHASE]->(Hard_cost_vendor_assignment)
(Phase1_ProjectAssignment)-[:HAS_SUBPHASE]->(Soft_cost_vendor_assignment)
(Phase1_ProjectAssignment)-[:HAS_SUBPHASE]->(Vendor_assignment)
(Phase1_ProjectAssignment)-[:PROJECT_NEEDS_DRONE]->(Drone)
""",

2: """
=== PHASE 2: Pre-Construction Planning and Validation ===

In Phase 2, In this phase TMobile provides a Precon / Pre - NTP document to Nokia.
This document includes all the planned dates for activities / milestones decided by TMobile for the site like - 
CD (Construction Drawing), RFDS, BOM (Bill of Materials), SA (Structural Analysis) and MA (Mount Analysis)
In this phase TMobile also provides Entitlement Completion (EC) to Nokia and Talon view survey details.

--- NODES ---

1. Phase2_PreConstruction
   - pj_project_id | STRING | Primary key
   - precon_status | STRING | 'Validated' / 'Pending Validation' / 'Not Yet Submitted'

2. Talon_View
   - pj_project_id                                             | STRING           | Primary key
   - pj_a_1010_talonview_pre_con_site_survey_ordered_finish    | LOCAL_DATE_TIME  | Talonview site survey order date
   - pj_a_1015_talonview_pre_con_site_survey_approved_finish   | LOCAL_DATE_TIME  | Talonview site survey approve date
   - pj_p_1010_talonview_pre_con_site_survey_ordered_finish    | LOCAL_DATE_TIME  | <Planned>
   - pj_p_1015_talonview_pre_con_site_survey_approved_finish   | LOCAL_DATE_TIME  | <Planned>
   
3. Entitlement_Complete
   - pj_project_id                             | STRING           | Primary key
   - pj_a_3710_ran_entitlement_complete_finish | LOCAL_DATE_TIME  | Actual RAN entitlement completion
   - pj_a_3725_all_entitlement_complete_finish | LOCAL_DATE_TIME  | Actual all entitlements completion
   - pj_p_3710_ran_entitlement_complete_finish | LOCAL_DATE_TIME  | <Planned>
   - pj_p_3725_all_entitlement_complete_finish | LOCAL_DATE_TIME  | <Planned>

4. Precon_Milestones
   - pj_project_id                                            | STRING           | Primary key
   - pj_a_3800_pre_ntp_issued_finish                          | LOCAL_DATE_TIME  | Pre-NTP / Pre-con issued date in TMobile DB
   - pj_p_3800_pre_ntp_issued_finish                          | LOCAL_DATE_TIME  | <Planned>
   - pj_a_2225_construction_drawings_received_finish          | LOCAL_DATE_TIME  | CDs recieved date
   - pj_a_2250_construction_drawings_redlines_compiled_finish | LOCAL_DATE_TIME  | Corrections in CDs
   - pj_a_2275_final_construction_drawings_approved_finish    | LOCAL_DATE_TIME  | Final updated CDs (Under Precon Validation)
   - pj_p_2225_construction_drawings_received_finish          | LOCAL_DATE_TIME  | <Planned>
   - pj_p_2250_construction_drawings_redlines_compiled_finish | LOCAL_DATE_TIME  | <Planned>
   - pj_p_2275_final_construction_drawings_approved_finish    | LOCAL_DATE_TIME  | <Planned>

--- ADDITIONAL PHASE2 RELATIONSHIPS  ---

(Phase2_PreConstruction)-[:HAS_SUBPHASE]->(Precon_Validation)
(Phase2_PreConstruction)-[:HAS_SUBPHASE]->(Entitlement_Complete)
(Phase2_PreConstruction)-[:HAS_MILESTONES]->(Precon_Milestones)
""",

3: """
=== PHASE 3: Scoping and Site Assessment ===

Phase 3 defines the real scope of work required for project. 
Post the precon validation, Nokia team assigns pre-construction site walks and 
drone surveys. Additional scope of work (apart from the one mentioned in precon)
is identified during these surveys and precon validation which is finally compiled into 
a scoping package. This package is created & validated internally by Nokia and Vendor
and than it is submitted to TMobile.   

--- NODES ---

1. Phase3_Scoping
   - pj_project_id  | STRING | Primary key
   - scoping_status | STRING | 'Site Walk Not Assigned' / 'Site Walk/Survey Ongoing' / 'SP Created and Validated'

2. Phase3_Details
   - pj_project_id                                    | STRING           | Primary key
   - pre_con_type                                     | STRING           | Walk type - 'Local CM' for Manual walk and 'Drone' for Drone based survey.
   - ms_1316_pre_con_site_walk_completed_actual       | LOCAL_DATE_TIME  | Site walk date, if pre_con_type = 'Local CM', else NULL
   - ms_1321_talon_view_drone_svcs_actual             | LOCAL_DATE_TIME  | Drone date, if pre_con_type = 'Drone', else NULL
   - ms_1321_talon_view_drone_svcs_spo_issued_date    | LOCAL_DATE_TIME  | Drone SPO date, if pre_con_type = 'Drone', else NULL
   - pj_a_3825_pre_construction_walk_complete_finish  | LOCAL_DATE_TIME  | Drone / Manual Survey Complete Date (Main milestone)
   - pj_p_3825_pre_construction_walk_complete_finish  | LOCAL_DATE_TIME  | <Planned>
   - ms_1323_ready_for_scoping_actual                 | LOCAL_DATE_TIME  | Scoping package in this milestone
   - ms_1327_scoping_and_quoting_package_validated_actual | LOCAL_DATE_TIME | Scoping package is validated internally (Nokia and Vendor) and submitted to TMobile.

--- ADDITIONAL PHASE3 RELATIONSHIPS ---

(Phase3_Scoping)-[:HAS_DETAILS]->(Phase3_Details)
""",

4: """
=== PHASE 4: Vendor Quoting and Customer Approval ===

In Phase 4, TMobile recieves the Scoping Package from Nokia as an 'E-quote'.
TMobiles reviews and approves it.

--- NODES ---

1. Phase4_Quoting
   - pj_project_id                            | STRING           | Primary key
   - quoting_status                           | STRING           | 'Not Started' / 'Bid Walk Complete' / 'Submitted to Customer' / 'Approved by Customer'
   - pj_a_3815_bid_walk_complete_finish       | LOCAL_DATE_TIME  | SP (e-quote) recieved by TMobile in TMobile DB
   - pj_p_3815_bid_walk_complete_finish       | LOCAL_DATE_TIME  | <Planned>
   - pj_bid_walk_complete_3815_doc            | STRING           | Name of the E-quote
   - pj_bid_walk_complete_optional_status     | STRING           | 'In Review' or 'Approved'
   - ms_1331_scoping_package_submitted_actual | LOCAL_DATE_TIME  | SP (e-quote) submitted to TMobile
   - ms_1333_scoping_package_approved_by_customer_actual | LOCAL_DATE_TIME | SP (e-quote) accepted by TMobile

""",

5: """
=== PHASE 5: NTP and Material Ordering and Procurement ===

In Phase 5, TMobile provides the Notice to Proceed (NTP) to Nokia for 2 set of activites - 
The civil construction work on site and tower construction work. 
List of Materials required is finalized, and the Bill of Materials (BOM) is uploaded to the 
TMobile tool. As TMobile approves the BOM, materials arrive in the warehouse. 
Vendor collects the materials from the warehouse. 
Steel required in the project is finalized in this phase too. Steel details include 
po number, steel recieved status etc.

--- NODES ---

1. Phase5_NTP_and_Material
   - pj_project_id                                 | STRING           | Primary key
   - pj_p_4025_civil_ntp_submitted_to_gc_finish    | LOCAL_DATE_TIME  | <Planned>
   - pj_a_4025_civil_ntp_submitted_to_gc_finish    | LOCAL_DATE_TIME  | Civil NTP Submitted to Vendor (GC)
   - pj_p_4050_civil_ntp_accepted_by_gc_finish     | LOCAL_DATE_TIME  | <Planned>
   - pj_a_4050_civil_ntp_accepted_by_gc_finish     | LOCAL_DATE_TIME  | Civil NTP Accepted by Vendor (GC)
   - pj_p_4075_construction_ntp_submitted_to_gc_finish| LOCAL_DATE_TIME| Planned Tower NTP submitted
   - pj_a_4075_construction_ntp_submitted_to_gc_finish| LOCAL_DATE_TIME| Tower NTP Submitted to Vendor (GC)
   - pj_p_4100_construction_ntp_accepted_by_gc_finish | LOCAL_DATE_TIME| Planned Tower NTP accepted
   - pj_a_4100_construction_ntp_accepted_by_gc_finish | LOCAL_DATE_TIME| Tower NTP Accepted by Vendor (GC)
   - ms_1407_tower_ntp_validated_actual            | LOCAL_DATE_TIME  | Tower NTP validated by Nokia
   - ms_1507_tower_ntp_approved_actual             | LOCAL_DATE_TIME  | Tower NTP approved by Nokia

2. BOM_Submission
   - pj_project_id                             | STRING           | Primary key
   - pj_p_3850_bom_submitted_bom_in_bat_finish | LOCAL_DATE_TIME  | <Planned>
   - pj_a_3850_bom_submitted_bom_in_bat_finish | LOCAL_DATE_TIME  | BOM uploaded to BAT tool (TMobile tool)
   - pj_p_3875_bom_received_bom_in_aims_finish | LOCAL_DATE_TIME  | <Planned>
   - pj_a_3875_bom_received_bom_in_aims_finish | LOCAL_DATE_TIME  | BOM uploaded to AIMS tool (TMobile tool)
   - pj_p_3900_all_bat_orders_received_finish  | LOCAL_DATE_TIME  | <Planned>
   - pj_a_3900_all_bat_orders_received_finish  | LOCAL_DATE_TIME  | Material has arrived in warehouse

3. Steel_Submission
   - pj_project_id           | STRING           | Primary key
   - pj_steel_ordered_status | STRING           | Steel ordered status
   - pj_steel_received_status| STRING           | Steel received status
   - pj_steel_po_number      | STRING           | Steel PO number
   - pj_steel_ordered        | LOCAL_DATE_TIME  | Ordered date
   - pj_steel_received_date  | LOCAL_DATE_TIME  | Received date

4. Material_Pickup
   - pj_project_id                                  | STRING           | Primary key
   - pj_p_3925_msl_pickup_date_finish               | LOCAL_DATE_TIME  | <Planned>
   - pj_a_3925_msl_pickup_date_finish               | LOCAL_DATE_TIME  | Vendor Picks up Material from warehouse in this milestone
   - ms_1461_pickup_tower_materials_and_validate_actual | LOCAL_DATE_TIME | Same, Project Manager updates this  
   - ms_14610_gc_material_pickup_actual             | LOCAL_DATE_TIME  | Same, GC updates

--- ADDITIONAL PHASE5 RELATIONSHIPS ---

(Phase5_NTP_and_Material)-[:HAS_SUBPHASE]->(BOM_Submission)
(Phase5_NTP_and_Material)-[:HAS_SUBPHASE]->(Steel_Submission)
(Phase5_NTP_and_Material)-[:HAS_SUBPHASE]->(Material_Pickup)
""",

6: """
=== PHASE 6: Transport and Power Preparation ===

In Phase 6 the TMO Vendor performs a AAV telco site walk to analyse the transport requirements.
The TMO Vendor also performs a Power walk to define the power utility scope and gather power requirements.

--- NODES ---

1. Phase6_Transport_and_Power
   - pj_project_id                              | STRING           | Primary key
   - pj_p_2075_aav_telco_site_walk_complete_finish | LOCAL_DATE_TIME| <Planned>
   - pj_a_2075_aav_telco_site_walk_complete_finish | LOCAL_DATE_TIME| Actual AAV site walk complete
   - pj_p_2080_aav_telco_design_complete_finish | LOCAL_DATE_TIME  | <Planned>
   - pj_a_2080_aav_telco_design_complete_finish | LOCAL_DATE_TIME  | Actual AAV design complete
   - pj_p_4450_permanent_power_ordered_finish   | LOCAL_DATE_TIME  | <Planned>
   - pj_a_4450_permanent_power_ordered_finish   | LOCAL_DATE_TIME  | Actual power ordered
   - pj_p_4475_complete_power_walk_finish       | LOCAL_DATE_TIME  | <Planned>
   - pj_a_4475_complete_power_walk_finish       | LOCAL_DATE_TIME  | Actual power walk
   - pj_p_4500_power_design_approval_finish     | LOCAL_DATE_TIME  | <Planned>
   - pj_a_4500_power_design_approval_finish     | LOCAL_DATE_TIME  | Actual power design approval

""",

7: """
=== PHASE 7: Construction Readiness ===

Phase 7 includes all the milestones related to Supplier Purchase Order (SPO) and Customer Purchase Order (CPO).

--- NODES ---

1. Phase7_Construction_Readiness
   - pj_project_id                                | STRING           | Primary key
   - pj_p_4200_pull_construction_po_number_finish | LOCAL_DATE_TIME  | <Planned>
   - pj_a_4200_pull_construction_po_number_finish | LOCAL_DATE_TIME  | Actual construction PO pulled
   - pj_construction_pos_issued                   | FLOAT            | PO issued flag/count
   - base_spo_requested_date                      | LOCAL_DATE_TIME  | Base SPO requested
   - ms_1321_talon_view_drone_svcs_spo            | FLOAT            | TalonView SPO
   - ms_1321_talon_view_drone_svcs_spo_issued_date| LOCAL_DATE_TIME  | TalonView SPO issued date
   - ms_1551_civil_construction_complete_spo      | FLOAT            | Civil completion SPO
   - ms_1551_civil_construction_complete_spo_issued_date | LOCAL_DATE_TIME | Civil SPO issued
   - ms_1551_module_spo_vendor_name               | FLOAT            | Civil module SPO vendor
   - ms1555_construction_complete_spo             | FLOAT            | Tower completion SPO
   - ms1555_construction_complete_spo_issued_date | LOCAL_DATE_TIME  | Tower SPO issued
   - ms_1555_module_spo_vendor_name               | FLOAT            | Tower module SPO vendor
   - ms_1970_integration_complete_spo             | FLOAT            | Integration completion SPO
   - ms_1559_cop_approved_by_t_mobile_spo         | FLOAT            | COP approved SPO
   - ms_1559_cop_approved_by_t_mobile_spo_issued_date | LOCAL_DATE_TIME | COP SPO issued

""",

8: """
=== PHASE 8: Civil Construction and Power/AAV ===

Phase 8 includes the civil construction work start and finish dates. Parallel to civil construction 
power installation work start and end dates are also mentioned in this phase.
AAV is ready and MW installation is also finished.

--- NODES ---

1. Phase8_Civil_Work
   - pj_project_id                                | STRING           | Primary key
   - pj_p_4250_civil_construction_start_finish    | LOCAL_DATE_TIME  | <Planned>
   - pj_a_4250_civil_construction_start_finish    | LOCAL_DATE_TIME  | Actual civil start
   - pj_p_4750_civil_construction_complete_finish | LOCAL_DATE_TIME  | <Planned>
   - pj_a_4750_civil_construction_complete_finish | LOCAL_DATE_TIME  | Actual civil complete

2. Power_Installation
   - pj_project_id                     | STRING           | Primary key
   - pj_p_4525_power_ready_finish      | LOCAL_DATE_TIME  | <Planned>
   - pj_a_4525_power_ready_finish      | LOCAL_DATE_TIME  | Actual power ready
   - pj_p_4550_permanent_power_installed_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_4550_permanent_power_installed_finish | LOCAL_DATE_TIME | Actual permanent power installed on site

3. AAV_and_MW
   - pj_project_id                              | STRING           | Primary key
   - pj_p_4875_aav_telco_ready_finish           | LOCAL_DATE_TIME  | <Planned>
   - pj_a_4875_aav_telco_ready_finish           | LOCAL_DATE_TIME  | Actual AAV ready
   - pj_p_4425_mw_installation_complete_finish  | LOCAL_DATE_TIME  | <Planned>
   - pj_a_4425_mw_installation_complete_finish  | LOCAL_DATE_TIME  | Actual MW install complete

--- ADDITIONAL PHASE8 RELATIONSHIPS ---

(Phase8_Civil_Work)-[:HAS_SUBPHASE]->(Power_Installation)
(Phase8_Civil_Work)-[:HAS_SUBPHASE]->(AAV_and_MW)
""",

9: """
=== PHASE 9: Tower Construction ===

Phase 9 includes the tower construction work start and finish dates, delays and comments.

--- NODES ---

1. Phase9_Tower_Work
   - pj_project_id                           | STRING           | Primary key
   - pj_p_4225_construction_start_finish     | LOCAL_DATE_TIME  | <Planned>
   - pj_a_4225_construction_start_finish     | LOCAL_DATE_TIME  | Actual tower start
   - pj_p_5175_construction_complete_finish  | LOCAL_DATE_TIME  | <Planned>
   - pj_a_5175_construction_complete_finish  | LOCAL_DATE_TIME  | Actual tower complete
   - pj_construction_start_delay_code        | STRING           | Start delay code
   - pj_construction_start_delay_comments    | STRING           | Start delay comments
   - pj_construction_complete_delay_code     | STRING           | Complete delay code
   - pj_construction_complete_delay_comments | STRING           | Complete delay comments

""",

10: """
=== PHASE 10: Network Integration ===

Phase 10 manages the integration of telecom network equipment into the operational network.
This includes integration start and complete milestones, validating scf files and integration comments. 
Verifying that equipment communicates correctly with E911 test calls.
Airview report is completed in this Phase.

--- NODES ---

1. Phase10_Integration
   - pj_project_id                               | STRING           | Primary key
   - pj_p_5270_integration_start_finish          | LOCAL_DATE_TIME  | <Planned>
   - pj_a_5270_integration_start_finish          | LOCAL_DATE_TIME  | Actual integration start
   - pj_p_5275_integration_complete_finish       | LOCAL_DATE_TIME  | <Planned>
   - pj_a_5275_integration_complete_finish       | LOCAL_DATE_TIME  | Actual integration complete
   - pj_integration_comments                     | STRING           | Integration comments
   - ms_1564_validate_scf_files_are_available_actual | LOCAL_DATE_TIME | SCF validated
   - ms_1899_all_planned_technologies_integrated_actual | LOCAL_DATE_TIME | All techs integrated
   - ms_1971_air_view_report_completed_actual    | LOCAL_DATE_TIME  | AirView completed
   - ms_2123_planned_e911_test_calls_actual      | LOCAL_DATE_TIME  | E911 test calls

""",

11: """
=== PHASE 11: Post-Integration, RTT & On-Air ===

Phase 11 has integration completion milestones. It includes RTT (Ready-To-Test) and
network On-Air activation for various spectrum bands.
S
--- NODES ---

1. Phase11_Post_Integration
   - pj_project_id                          | STRING           | Primary key
   - ms_1970_integration_complete_actual    | LOCAL_DATE_TIME  | Integration complete
   - ms_1970_integration_complete_ca_date   | LOCAL_DATE_TIME  | CA complete
   - ms_1970_integration_complete_bbr_date  | LOCAL_DATE_TIME  | BBR complete
   - ms_1970_integration_complete_so_inv_date | LOCAL_DATE_TIME| SO invoice date
   - ms_1970_integration_complete_ia_date   | LOCAL_DATE_TIME  | IA complete
   - ms_1970_integration_complete_gr_date   | LOCAL_DATE_TIME  | GR complete
   - ms_1970_integration_complete_spo_issued_date | LOCAL_DATE_TIME | SPO issued

2. RTT
   - pj_project_id | STRING | Primary key

3. OnAir
   - pj_project_id                 | STRING           | Primary key
   - pj_a_5600_gsm_onair_finish    | LOCAL_DATE_TIME  | GSM On-Air

--- ADDITIONAL PHASE11 RELATIONSHIPS (ALL start at Site) ---

(Phase11_Post_Integration)-[:HAS_SUBPHASE]->(RTT)
(Phase11_Post_Integration)-[:HAS_SUBPHASE]->(OnAir)

""",

12: """
=== PHASE 12: Revenue & Financial Close-Out ===

Phase 12 contains revenue milestones (CA, IA, GR, BBR, SO etc) 
from different 4 phases of the project - Civil, Tower, Integration and DEC_COP.

--- NODES ---

1. Phase12_Revenue
   - pj_project_id | STRING | Primary key

2. Civil_Revenue
   - pj_project_id                                       | STRING           | Primary key
   - pj_p_2275_final_construction_drawings_approved_finish | LOCAL_DATE_TIME| Planned CDs final approved (xref)
   - pj_a_2275_final_construction_drawings_approved_finish | LOCAL_DATE_TIME| Actual CDs final approved (xref)
   - ms_1551_civil_construction_complete_ia_date         | LOCAL_DATE_TIME  | Civil IA complete
   - ms_1551_civil_construction_complete_gr_date         | LOCAL_DATE_TIME  | Civil GR complete
   - ms_1551_civil_construction_complete_gr_so_number    | STRING           | Civil GR SO number
   - ms_1551_civil_construction_complete_invoice_date    | LOCAL_DATE_TIME  | Civil invoice date
   - ms_1551_civil_construction_complete_invoice         | STRING           | Civil invoice #
   - ms_1551_civil_construction_complete_ca_date         | LOCAL_DATE_TIME  | Civil CA complete
 
3. Tower_Revenue
   - pj_project_id                         | STRING           | Primary key
   - ms1555_construction_complete_invoice_date | LOCAL_DATE_TIME | Tower invoice date
   - ms1555_construction_complete_invoice | STRING/FLOAT      | Tower invoice #
   - ms1555_construction_complete_ca_date | LOCAL_DATE_TIME   | Tower CA complete
   - ms1555_construction_complete_bbr_date| LOCAL_DATE_TIME   | Tower BBR complete
   - ms1555_construction_complete_gr_date | LOCAL_DATE_TIME   | Tower GR complete
   - ms1555_construction_complete_ia_date | LOCAL_DATE_TIME   | Tower IA complete
 
4. PL_Revenue
   - pj_project_id                          | STRING           | Primary key
   - ms_1559_cop_approved_by_t_mobile_ia_date | LOCAL_DATE_TIME| COP IA
   - ms_1559_cop_approved_by_t_mobile_gr_date | LOCAL_DATE_TIME| COP GR
   - ms_1559_cop_approved_by_t_mobile_ca_date | LOCAL_DATE_TIME| COP CA
   - ms_1559_cop_approved_by_t_mobile_bbr_date| LOCAL_DATE_TIME| COP BBR

--- ADDITIONAL PHASE12 RELATIONSHIPS (ALL start at Site) ---

(Phase12_Revenue)-[:HAS_SUBPHASE]->(Civil_Revenue)
(Phase12_Revenue)-[:12HAS_SUBPHASE2]->(Tower_Revenue)
(Phase12_Revenue)-[:12HAS_SUBPHASE3]->(PL_Revenue)
""",
}