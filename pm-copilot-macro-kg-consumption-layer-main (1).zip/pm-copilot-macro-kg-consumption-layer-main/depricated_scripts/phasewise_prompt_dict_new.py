PHASE_SCHEMA_DESCRIPTIONS = {
0: """
=== BASE NODES: Core Entities ===

These are the foundational nodes representing the key organizations and assets in the telecom deployment system. Projects are assigned by T-Mobile to Nokia at a specific Site; market segmentation (region, area, market) lives on the Site node.

--- NODES ---

1. TMobile
   - name | STRING | Singleton node representing T-Mobile as the customer/owner; always 'TMobile'

2. Nokia
   - name | STRING | Singleton node representing Nokia as the deployment partner; always 'Nokia'

3. Site
   - s_site_id                          | STRING | Unique site identifier; primary key (e.g., '9NV0517R')
   - s_site_name                        | STRING | Human-readable site name (e.g., 'Nolensville II')
   - s_address                          | STRING | Street address of the site
   - s_city                             | STRING | City where the site is located
   - s_state                            | STRING | State abbreviation (e.g., 'TN', 'IN')
   - s_zip                              | STRING | ZIP code of the site
   - s_site_latitude                    | STRING | GPS latitude
   - s_site_longitude                   | STRING | GPS longitude
   - s_site_class                       | STRING | Tower class (e.g., 'Monopole', 'Guyed Tower')
   - s_site_type                        | STRING | Site type (e.g., 'Structure Non Building')
   - s_site_jurisdiction                | STRING | Governing jurisdiction (e.g., 'Metro/Davidson Co.')
   - s_structure_landlord_name_siterra  | STRING | Landlord/tower owner (e.g., 'Crown Castle', 'SBA')
   - site_deployment_reference_model    | FLOAT  | Reference deployment model (e.g., 'Config4-Split')
   - region                             | STRING | Nokia region (e.g., 'CENTRAL') **Key for region filters**
   - m_area                             | STRING | Market area grouping (e.g., 'Appalachian') **Key for area filters**
   - m_market                           | STRING | Specific market (e.g., 'NASHVILLE') **Key for market filters**
   - name                               | STRING | Node label name, always 'Site'

4. Vendor
   - construction_gc        | STRING | General contractor (Vendor) company name; primary key
   - pj_general_contractor  | STRING | GC name recorded in the project
   - name                   | STRING | Node label name, always 'Vendor'

5. TMO_Vendor
   - s_primary_aav_vendor_name_salesforce | STRING | TMO soft-cost vendor; primary key
   - s_power_provider_company_name        | STRING | Electrical utility provider (e.g., 'DUKE ENERGY')
   - s_power_provider_contact_number      | FLOAT  | Utility contact number
   - name                                 | STRING | Node label name, always 'TMO Vendor'

--- RELATIONSHIPS ---

(Site)<-[:GETS_SITE]-(Nokia)
(Site)<-[:ASSIGNS_SITE]-(TMobile)
(Site)<-[:WORKS_ON]-(Vendor)
(Site)<-[:TMO_VENDOR_WORKS_ON]-(TMO_Vendor)
(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
""",

"HSE": """
=== HSE: Health, Safety and Environment ===

The HSE node records safety compliance linkage during active construction phases. It links from the project path starting at Site, and contains visit-level records per project.

--- NODES ---

1. HSE
   - pj_project_id | STRING | Unique project identifier; primary key
   - name          | STRING | Node label name, always 'HSE'
   - description   | STRING | Description of HSE linkage for construction activity

2. Visit
   - pj_project_id             | STRING  | Project identifier this visit belongs to
   - visit_num                 | INTEGER | Visit sequence number; part of composite key
   - check_in_status           | STRING  | Crew check-in status (e.g., 'Done', 'Not Done')
   - check_in_date             | STRING  | Date of the crew check-in
   - ppe_validation            | STRING  | PPE inspection result (e.g., 'Pass', 'Failed')
   - ppe_photo_available       | STRING  | Whether PPE photo was captured (e.g., 'Yes', 'No')
   - jsa_completion_status     | STRING  | JSA completion status (e.g., 'Completed', 'Not Completed')
   - each_crew_ptid_l2w_status | STRING  | PTID L2W availability status (e.g., 'Available', 'Not Available')
   - name                      | STRING  | Node label name, always 'Visit'

--- RELATIONSHIPS (Site path shown ONCE) ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_HSE]->(HSE)

(HSE)-[:VISITS]->(Visit)

--- Cypher Upsert for Visit (example) ---

UNWIND $rows AS row
MATCH (h:HSE {pj_project_id: row.pj_project_id})
MERGE (v:Visit {
    pj_project_id: row.pj_project_id,
    visit_num: row.visit_num
})
SET
    v.check_in_status = row.check_in_status,
    v.check_in_date = row.check_in_date,
    v.ppe_photo_available = row.ppe_photo_available,
    v.ppe_validation = row.ppe_validation,
    v.jsa_completion_status = row.jsa_completion_status,
    v.each_crew_ptid_l2w_status = row.each_crew_ptid_l2w_status
MERGE (h)-[:VISITS]->(v)
""",

"DEC_COP": """
=== DEC_COP: Close-Out Package & Punch List Workflow ===

The DEC_COP node tracks Nokia's close-out package (COP) submitted to T-Mobile after construction. It also anchors the punch list workflow (submission, returns, re-submission, and final approval).

--- NODES ---

1. DEC_COP
   - pj_project_id   | STRING | Unique project identifier; primary key
   - scop_title      | STRING | COP title (e.g., 'A1Q0166G_CENTRAL_*_Close Out Pack')
   - approvedpercent | STRING | COP approval percentage by T-Mobile (e.g., '100', '39')
   - name            | STRING | Node label name, always 'DEC_COP'
   - description     | STRING | Description of DEC COP tracking

2. Punch_List_status
   - pj_project_id                              | STRING | Primary key
   - scop_title                                 | STRING | Session/COP title
   - scop_ndpc_session_created_cw               | STRING | Session creation week
   - scop_ndpc_session_cw_pending_pct           | STRING | Civil: pending %
   - scop_ndpc_session_cw_completed_pct         | STRING | Civil: completed %
   - scop_ndpc_session_cw_last_activity         | STRING | Civil: last activity
   - scop_ndpc_session_cw_approved_pct          | STRING | Civil: approved %
   - scop_ndpc_session_cw_rejected_pct          | STRING | Civil: rejected %
   - scop_ndpc_session_tw_pending_pct           | STRING | Tower: pending %
   - scop_ndpc_session_tw_completed_pct         | STRING | Tower: completed %
   - scop_ndpc_session_tw_approved_pct          | STRING | Tower: approved %
   - scop_ndpc_session_tw_rejected_pct          | STRING | Tower: rejected %
   - name                                       | STRING | Always 'Punch List Status'

3. PL_Submission
   - pj_project_id                                        | STRING           | Primary key
   - ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl | LOCAL_DATE_TIME | Punch checklist submitted
   - ms_1558_admin_checklist_submitted_to_t_mobile_actual | LOCAL_DATE_TIME  | Admin checklist submitted
   - ms_1553_review_civil_quality_media_checklist         | LOCAL_DATE_TIME  | Civil quality/media checklist review
   - scop_cw_checklist_submitted_to_customer              | STRING           | Civil checklist submitted to customer (Y/N)
   - scop_tw_checklist_submitted_to_customer              | STRING           | Tower checklist submitted to customer (Y/N)
   - name                                                 | STRING           | Always 'PL Submission'

4. PL_Post_Submission
   - pj_project_id                          | STRING          | Primary key
   - pj_a_5400_punch_list_to_gc_finish      | LOCAL_DATE_TIME | Actual: punch list to GC
   - pj_p_5400_punch_list_to_gc_finish      | LOCAL_DATE_TIME | Planned: punch list to GC
   - scop_cw_punchlist_by_customer          | STRING          | Civil punchlist returned by customer (Y/N/Count)
   - scop_tw_punchlist_by_customer          | STRING          | Tower punchlist returned by customer (Y/N/Count)
   - scop_cw_checklist_audit_completed      | STRING          | Civil checklist audit completed (Y/N)
   - scop_cw_checklist_audit_pl_category    | STRING          | Civil PL audit category
   - scop_cw_cl_completed_by_gc             | STRING          | Civil checklist completed by GC (Y/N)
   - name                                   | STRING          | Always 'PL Post Submission'

5. PL_Resubmission
   - pj_project_id                           | STRING          | Primary key
   - pj_a_5425_punch_list_complete_finish    | LOCAL_DATE_TIME | Actual: punch list complete
   - pj_p_5425_punch_list_complete_finish    | LOCAL_DATE_TIME | Planned: punch list complete
   - scop_pending_days_for_gc_action         | STRING          | Days pending GC action
   - scop_aging_for_pending_gc_action        | STRING          | Aging for pending GC action
   - pj_a_5500_receive_close_out_binder_finish | LOCAL_DATE_TIME | Actual: COB received
   - pj_p_5500_receive_close_out_binder_finish | LOCAL_DATE_TIME | Planned: COB received
   - name                                    | STRING          | Always 'PL Resubmission'

6. PL_Final_Approval
   - pj_project_id                              | STRING          | Primary key
   - pj_a_5525_approve_close_out_binder_finish  | LOCAL_DATE_TIME | Actual: COB approval
   - pj_p_5525_approve_close_out_binder_finish  | LOCAL_DATE_TIME | Planned: COB approval
   - ms_1559_cop_approved_by_t_mobile_actual    | LOCAL_DATE_TIME | T-Mobile COP approval date
   - scop_checklist_accepted_by_customer        | STRING          | Checklist accepted (Y/N)
   - pj_p_5540_financial_closeout_finish        | LOCAL_DATE_TIME | Planned: financial closeout
   - magenta_ms_5525_actual                     | LOCAL_DATE_TIME | Magenta 5525 actual
   - name                                       | STRING          | Always 'PL Final Approval'

--- RELATIONSHIPS (Site paths shown ONCE) ---

# Site → DEC_COP (one example path via Phase 8)
(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_DEC_COP]->(DEC_COP)

# DEC_COP → PL nodes (shown once each)
(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_DEC_COP]->(DEC_COP)-[:HAS_PL]->(Punch_List_status)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_DEC_COP]->(DEC_COP)-[:PL_SUBMITTED]->(PL_Submission)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_DEC_COP]->(DEC_COP)-[:PL_RETURNED]->(PL_Post_Submission)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_DEC_COP]->(DEC_COP)-[:PL_RESUBMITTED]->(PL_Resubmission)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_DEC_COP]->(DEC_COP)-[:PL_APPROVED]->(PL_Final_Approval)
""",

1: """
=== PHASE 1: Project Initialization and Setup ===

Phase 1 establishes the project and links it to the site. It includes SMP ID creation, project metadata, vendor assignments (hard cost, soft cost, GC), and serves as the root for downstream phases.

--- NODES ---

1. Phase1_ProjectAssignment
   - pj_project_id   | STRING | Unique project identifier; primary key
   - s_site_id       | STRING | Site ID the project is assigned to
   - assigned_status | STRING | 'Assigned' / 'Not Assigned'
   - name            | STRING | Always '1. Project Assigned'
   - description     | STRING | Site assignment milestone

2. SMP_ID_Creation
   - pj_project_id | STRING | Primary key
   - smp_id        | STRING | SMP WO ID (e.g., 'SMP-WO-1296358')
   - smp_name      | STRING | SMP program name/type
   - smp_version   | FLOAT  | SMP version
   - smp_status    | STRING | SMP status (e.g., 'Active')
   - name          | STRING | Always 'SMP_ID Creation'
   - description   | STRING | SMP ID creation step

3. Phase1_Details
   - pj_project_id                 | STRING | Primary key
   - smp_id                        | STRING | SMP WO ID
   - pj_por_count                  | STRING | POR count
   - pj_project_type               | STRING | Project type (e.g., 'N-NSD Macro')
   - por_por_id                    | STRING | POR reference ID
   - por_regional_dev_initiatives  | STRING | Regional initiative
   - t_mobile_proj_cd              | FLOAT  | T-Mobile internal project code
   - por                           | FLOAT  | Period of Record (e.g., '07 2025')
   - pj_gc_crew_name               | FLOAT  | GC crew name (if any)
   - name                          | STRING | Always 'Details'
   - description                   | STRING | Phase 1 metadata

4. Hard_cost_vendor_assignment
   - pj_project_id                     | STRING          | Primary key
   - pj_hard_cost_pm                   | STRING/FLOAT    | Hard cost PM
   - pj_hard_cost_vendor_assignment_po | STRING          | HC vendor PO
   - pj_hard_cost_approval_date        | LOCAL_DATE_TIME | HC approval date
   - assigned_status                   | STRING          | 'Assigned' / 'Not Assigned'
   - name                              | STRING          | Always 'Hard Cost Vendor Assignment'
   - description                       | STRING          | HC vendor assignment

5. Soft_cost_vendor_assignment
   - pj_project_id                        | STRING          | Primary key
   - s_primary_aav_vendor_name_salesforce | STRING          | TMO soft-cost vendor
   - pj_soft_cost_pm                      | STRING          | Soft cost PM
   - pj_soft_cost_approval_date           | LOCAL_DATE_TIME | Soft cost approval date
   - pj_soft_cost_comments                | FLOAT           | Comments
   - pj_soft_cost_vendor                  | STRING          | Vendor (if present)
   - assigned_status                      | STRING          | 'Assigned' / 'Not Assigned'
   - name                                 | STRING          | Always 'Soft Cost Vendor Assignment'
   - description                          | STRING          | Soft cost vendor assignment

6. Vendor_assignment
   - pj_project_id                | STRING          | Primary key
   - construction_gc              | STRING/FLOAT    | Assigned GC
   - assigned_status              | STRING          | 'Assigned' / 'Not Assigned'
   - pj_p_3775_gc_selected_finish | LOCAL_DATE_TIME | Planned GC selection complete
   - pj_a_3775_gc_selected_finish | LOCAL_DATE_TIME | Actual GC selection complete
   - name                         | STRING          | Always 'Vendor Assignment'
   - description                  | STRING          | Nokia GC assignment

--- RELATIONSHIPS (ALL start at Site) ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)-[:1HAS_SUBPHASE1]->(SMP_ID_Creation)
(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)-[:1HAS_DETAILS]->(Phase1_Details)
(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)-[:1HAS_SUBPHASE3]->(Hard_cost_vendor_assignment)
(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)-[:1HAS_SUBPHASE2]->(Soft_cost_vendor_assignment)
(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)-[:1HAS_SUBPHASE4]->(Vendor_assignment)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)-[:P1_TO_P2]->(Phase2_PreConstruction)
""",

2: """
=== PHASE 2: Pre-Construction Planning and Validation ===

Phase 2 covers TalonView surveys, structural/mount analysis, construction drawing preparation, entitlement completion, and pre-construction validation.

--- NODES ---

1. Phase2_PreConstruction
   - pj_project_id | STRING | Primary key
   - precon_status | STRING | 'Validated' / 'Pending Validation' / 'Not Yet Submitted'
   - name          | STRING | Always '2. Precon'
   - description   | STRING | Pre-construction readiness

2. Precon_Validation
   - pj_project_id                                    | STRING           | Primary key
   - validation_status                                | STRING/FLOAT     | Validation status
   - pre_con_validation_rejection_reason              | STRING/FLOAT     | Rejection reason (if any)
   - ms_1313_pre_construction_package_validated_actual| LOCAL_DATE_TIME  | Validation actual
   - ms_1315_pre_construction_package_rejected_actual | LOCAL_DATE_TIME  | Rejection actual
   - pj_a_1010_talonview_pre_con_site_survey_ordered_finish  | LOCAL_DATE_TIME | Actual survey ordered
   - pj_a_1015_talonview_pre_con_site_survey_approved_finish | LOCAL_DATE_TIME | Actual survey approved
   - pj_p_1010_talonview_pre_con_site_survey_ordered_finish  | LOCAL_DATE_TIME | Planned survey ordered
   - pj_p_1015_talonview_pre_con_site_survey_approved_finish | LOCAL_DATE_TIME | Planned survey approved
   - name                                             | STRING           | Always 'Precon Validation'
   - description                                      | STRING           | Nokia package validation

3. Entitlement_Complete
   - pj_project_id                             | STRING           | Primary key
   - pj_a_3710_ran_entitlement_complete_finish | LOCAL_DATE_TIME  | Actual RAN entitlement completion
   - pj_a_3725_all_entitlement_complete_finish | LOCAL_DATE_TIME  | Actual all entitlements completion
   - pj_p_3710_ran_entitlement_complete_finish | LOCAL_DATE_TIME  | Planned RAN entitlement
   - pj_p_3725_all_entitlement_complete_finish | LOCAL_DATE_TIME  | Planned all entitlements
   - name                                      | STRING           | Always 'Entitlement Complete'
   - description                               | STRING           | Entitlement approvals

4. Precon_Milestones
   - pj_project_id                                            | STRING           | Primary key
   - pj_p_1400_structural_complete_finish                     | LOCAL_DATE_TIME  | Planned structural complete
   - pj_p_1525_mount_analysis_ordered_finish                  | LOCAL_DATE_TIME  | Planned mount analysis ordered
   - pj_p_1550_mount_analysis_received_finish                 | LOCAL_DATE_TIME  | Planned mount analysis received
   - pj_p_2200_construction_drawings_ordered_finish           | LOCAL_DATE_TIME  | Planned CDs ordered
   - pj_p_2225_construction_drawings_received_finish          | LOCAL_DATE_TIME  | Planned CDs received
   - pj_p_2250_construction_drawings_redlines_compiled_finish | LOCAL_DATE_TIME  | Planned redlines compiled
   - pj_p_2275_final_construction_drawings_approved_finish    | LOCAL_DATE_TIME  | Planned CDs approved
   - pj_p_2286_mw_final_construction_drawings_approved_finish | LOCAL_DATE_TIME  | Planned MW CDs approved
   - pj_p_2350_bom_submitted_from_market_to_region_finish     | LOCAL_DATE_TIME  | Planned BOM submitted M->R
   - pj_p_3800_pre_ntp_issued_finish                          | LOCAL_DATE_TIME  | Planned pre-NTP
   - pj_a_1400_structural_complete_finish                     | LOCAL_DATE_TIME  | Actual structural complete
   - pj_a_1525_mount_analysis_ordered_finish                  | LOCAL_DATE_TIME  | Actual mount analysis ordered
   - pj_a_1550_mount_analysis_received_finish                 | LOCAL_DATE_TIME  | Actual mount analysis received
   - pj_a_2200_construction_drawings_ordered_finish           | LOCAL_DATE_TIME  | Actual CDs ordered
   - pj_a_2225_construction_drawings_received_finish          | LOCAL_DATE_TIME  | Actual CDs received
   - pj_a_2250_construction_drawings_redlines_compiled_finish | LOCAL_DATE_TIME  | Actual redlines compiled
   - pj_a_2275_final_construction_drawings_approved_finish    | LOCAL_DATE_TIME  | Actual CDs approved
   - pj_a_2286_mw_final_construction_drawings_approved_finish | LOCAL_DATE_TIME  | Actual MW CDs approved
   - pj_a_2350_bom_submitted_from_market_to_region_finish     | LOCAL_DATE_TIME  | Actual BOM submitted M->R
   - pj_a_3800_pre_ntp_issued_finish                          | LOCAL_DATE_TIME  | Actual pre-NTP
   - pj_a_2475_dou_final_rfds_issued                          | LOCAL_DATE_TIME  | Actual DOU final RFDs
   - ms_1310_pre_construction_package_received_actual         | LOCAL_DATE_TIME  | Precon package received
   - name                                                     | STRING           | Always 'Precon Milestones'
   - description                                              | STRING           | Milestone tracking

--- RELATIONSHIPS (ALL start at Site) ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)-[:P1_TO_P2]->(Phase2_PreConstruction)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)-[:P1_TO_P2]->(Phase2_PreConstruction)-[:2HAS_SUBPHASE1]->(Precon_Validation)
(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)-[:P1_TO_P2]->(Phase2_PreConstruction)-[:2HAS_SUBPHASE2]->(Entitlement_Complete)
(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)-[:P1_TO_P2]->(Phase2_PreConstruction)-[:2HAS_MILESTONES]->(Precon_Milestones)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)-[:P1_TO_P2]->(Phase2_PreConstruction)-[:P2_TO_P3]->(Phase3_Scoping)
""",

3: """
=== PHASE 3: Scoping and Site Assessment ===

Phase 3 defines the construction scope via site walks, drone surveys (TalonView), and scoping package preparation/validation.

--- NODES ---

1. Phase3_Scoping
   - pj_project_id  | STRING | Primary key
   - scoping_status | STRING | 'Site Walk Not Assigned' / 'Site Walk/Survey Ongoing' / 'SP Created and Validated'
   - name           | STRING | Always '3. Scoping'
   - description    | STRING | Scoping phase description

2. Phase3_Details
   - pj_project_id                                    | STRING           | Primary key
   - pre_con_type                                     | STRING           | Pre-con type
   - ms_1314_ndpc_survey_request_form_submitted_actual| LOCAL_DATE_TIME  | NDPC survey request
   - ms_1316_pre_con_site_walk_completed_actual       | LOCAL_DATE_TIME  | Site walk complete
   - ms_1321_talon_view_drone_svcs_actual             | LOCAL_DATE_TIME  | TalonView services completed
   - ms_1321_talon_view_drone_svcs_spo_issued_date    | LOCAL_DATE_TIME  | TalonView SPO issued
   - pj_p_3825_pre_construction_walk_complete_finish  | LOCAL_DATE_TIME  | Planned walk complete
   - pj_a_3825_pre_construction_walk_complete_finish  | LOCAL_DATE_TIME  | Actual walk complete
   - ms_1323_ready_for_scoping_actual                 | LOCAL_DATE_TIME  | Ready for scoping
   - ms_1327_scoping_and_quoting_package_validated_actual | LOCAL_DATE_TIME | SP validated
   - name                                             | STRING           | Always 'Scoping Details'
   - description                                      | STRING           | Scoping detail milestones

--- RELATIONSHIPS (ALL start at Site) ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)-[:P1_TO_P2]->(Phase2_PreConstruction)-[:P2_TO_P3]->(Phase3_Scoping)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)-[:P1_TO_P2]->(Phase2_PreConstruction)-[:P2_TO_P3]->(Phase3_Scoping)-[:3HAS_DETAILS]->(Phase3_Details)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)-[:P1_TO_P2]->(Phase2_PreConstruction)-[:P2_TO_P3]->(Phase3_Scoping)-[:P3_TO_P4]->(Phase4_Quoting)
""",

4: """
=== PHASE 4: Vendor Quoting and Customer Approval ===

Phase 4 manages vendor bid walks, scoping package submission, and customer approval of quotes.

--- NODES ---

1. Phase4_Quoting
   - pj_project_id                            | STRING           | Primary key
   - quoting_status                           | STRING           | 'Not Started' / 'Bid Walk Complete' / 'Submitted to Customer' / 'Approved by Customer'
   - pj_p_3815_bid_walk_complete_finish       | LOCAL_DATE_TIME  | Planned bid walk complete
   - pj_a_3815_bid_walk_complete_finish       | LOCAL_DATE_TIME  | Actual bid walk complete
   - pj_bid_walk_complete_3815_doc            | FLOAT            | Bid walk document reference
   - pj_bid_walk_complete_optional_status     | FLOAT            | Optional flag
   - ms_1331_scoping_package_submitted_actual | LOCAL_DATE_TIME  | SP submitted to customer
   - ms_1333_scoping_package_approved_by_customer_actual | LOCAL_DATE_TIME | Customer approval
   - name                                     | STRING           | Always '4. Quoting'
   - description                              | STRING           | Quoting phase description

--- RELATIONSHIPS (ALL start at Site) ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
""",

5: """
=== PHASE 5: Material Ordering and Procurement ===

Phase 5 includes NTP issuance/acceptance, BOM flow, steel procurement, and material pickup logistics.

--- NODES ---

1. Phase5_NTP_and_Material
   - pj_project_id                                 | STRING           | Primary key
   - pj_p_4025_civil_ntp_submitted_to_gc_finish    | LOCAL_DATE_TIME  | Planned Civil NTP submitted
   - pj_a_4025_civil_ntp_submitted_to_gc_finish    | LOCAL_DATE_TIME  | Actual Civil NTP submitted
   - pj_p_4050_civil_ntp_accepted_by_gc_finish     | LOCAL_DATE_TIME  | Planned Civil NTP accepted
   - pj_a_4050_civil_ntp_accepted_by_gc_finish     | LOCAL_DATE_TIME  | Actual Civil NTP accepted
   - pj_p_4075_construction_ntp_submitted_to_gc_finish| LOCAL_DATE_TIME| Planned Tower NTP submitted
   - pj_a_4075_construction_ntp_submitted_to_gc_finish| LOCAL_DATE_TIME| Actual Tower NTP submitted
   - pj_p_4100_construction_ntp_accepted_by_gc_finish | LOCAL_DATE_TIME| Planned Tower NTP accepted
   - pj_a_4100_construction_ntp_accepted_by_gc_finish | LOCAL_DATE_TIME| Actual Tower NTP accepted
   - ms_1407_tower_ntp_validated_actual            | LOCAL_DATE_TIME  | Tower NTP validated
   - ms_1507_tower_ntp_approved_actual             | LOCAL_DATE_TIME  | Tower NTP approved
   - name                                          | STRING           | Always '5. NTP & Material'
   - description                                   | STRING           | NTP & material orchestration

2. BOM_Submission
   - pj_project_id                              | STRING           | Primary key
   - pj_p_3850_bom_submitted_bom_in_bat_finish | LOCAL_DATE_TIME  | Planned BOM in BAT
   - pj_a_3850_bom_submitted_bom_in_bat_finish | LOCAL_DATE_TIME  | Actual BOM in BAT
   - pj_p_3875_bom_received_bom_in_aims_finish | LOCAL_DATE_TIME  | Planned BOM in AIMS
   - pj_a_3875_bom_received_bom_in_aims_finish | LOCAL_DATE_TIME  | Actual BOM in AIMS
   - pj_p_3900_all_bat_orders_received_finish  | LOCAL_DATE_TIME  | Planned all BAT orders received
   - pj_a_3900_all_bat_orders_received_finish  | LOCAL_DATE_TIME  | Actual all BAT orders received
   - name                                      | STRING           | Always 'BOM'
   - description                               | STRING           | BOM submission tracking

3. Steel_Submission
   - pj_project_id           | STRING           | Primary key
   - pj_steel_ordered_status | FLOAT            | Steel ordered status
   - pj_steel_received_status| FLOAT            | Steel received status
   - pj_steel_po_number      | FLOAT            | Steel PO number
   - pj_steel_ordered        | LOCAL_DATE_TIME  | Ordered date
   - pj_steel_received_date  | LOCAL_DATE_TIME  | Received date
   - name                    | STRING           | Always 'Steel'
   - description             | STRING           | Steel procurement status

4. Material_Pickup
   - pj_project_id                                  | STRING           | Primary key
   - pj_p_3925_msl_pickup_date_finish               | LOCAL_DATE_TIME  | Planned MSL pickup
   - pj_a_3925_msl_pickup_date_finish               | LOCAL_DATE_TIME  | Actual MSL pickup
   - ms_1461_pickup_tower_materials_and_validate_actual | LOCAL_DATE_TIME | Tower materials pickup & validate
   - ms_14610_gc_material_pickup_actual             | LOCAL_DATE_TIME  | GC material pickup
   - name                                           | STRING           | Always 'Material_Pickup'
   - description                                    | STRING           | Logistics/material pickup

--- RELATIONSHIPS (ALL start at Site) ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)-[:5HAS_SUBPHASE1]->(BOM_Submission)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)-[:5HAS_SUBPHASE2]->(Steel_Submission)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)-[:5HAS_SUBPHASE3]->(Material_Pickup)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
""",

6: """
=== PHASE 6: Transport and Power Preparation ===

Phase 6 completes AAV telco activities and permanent power steps to prepare the site for construction and integration.

--- NODES ---

1. Phase6_Transport_and_Power
   - pj_project_id                              | STRING           | Primary key
   - pj_p_2075_aav_telco_site_walk_complete_finish | LOCAL_DATE_TIME| Planned AAV site walk complete
   - pj_a_2075_aav_telco_site_walk_complete_finish | LOCAL_DATE_TIME| Actual AAV site walk complete
   - pj_p_2080_aav_telco_design_complete_finish | LOCAL_DATE_TIME  | Planned AAV design complete
   - pj_a_2080_aav_telco_design_complete_finish | LOCAL_DATE_TIME  | Actual AAV design complete
   - pj_p_4450_permanent_power_ordered_finish   | LOCAL_DATE_TIME  | Planned power ordered
   - pj_a_4450_permanent_power_ordered_finish   | LOCAL_DATE_TIME  | Actual power ordered
   - pj_p_4475_complete_power_walk_finish       | LOCAL_DATE_TIME  | Planned power walk
   - pj_a_4475_complete_power_walk_finish       | LOCAL_DATE_TIME  | Actual power walk
   - pj_p_4500_power_design_approval_finish     | LOCAL_DATE_TIME  | Planned power design approval
   - pj_a_4500_power_design_approval_finish     | LOCAL_DATE_TIME  | Actual power design approval
   - name                                       | STRING           | Always '6. Transport and Power'
   - description                                | STRING           | Transport & power preparation

--- RELATIONSHIPS (ALL start at Site) ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
""",

7: """
=== PHASE 7: Construction Readiness ===

Phase 7 verifies all POs and SPOs are in place and the project is ready for execution.

--- NODES ---

1. Phase7_Construction_Readiness
   - pj_project_id                                | STRING           | Primary key
   - pj_p_4200_pull_construction_po_number_finish | LOCAL_DATE_TIME  | Planned construction PO pulled
   - pj_a_4200_pull_construction_po_number_finish | LOCAL_DATE_TIME  | Actual construction PO pulled
   - pj_construction_pos_issued                   | FLOAT            | PO issued flag/count
   - base_spo_requested_date                      | LOCAL_DATE_TIME  | Base SPO requested
   - ms_1321_talon_view_drone_svcs_spo            | FLOAT            | TalonView SPO
   - ms_1321_talon_view_drone_svcs_spo_issued_date| LOCAL_DATE_TIME  | TalonView SPO issued date
   - ms_1551_civil_construction_complete_spo      | FLOAT            | Civil completion SPO
   - ms_1551_civil_construction_complete_spo_issued_date | LOCAL_DATE_TIME | Civil SPO issued
   - ms_1551_module_spo_vendor_name               | FLOAT            | Civil module SPO vendor
   - ms1555_construction_complete_spo             | FLOAT            | Tower completion SPO
   - ms1555_construction_complete_spo_issued_date | LOCAL_DATE_TIME  | Tower SPO issued
   - ms_1555_module_spo_vendor_name               | FLOAT            | Tower module SPO vendor
   - ms_1970_integration_complete_spo             | FLOAT            | Integration completion SPO
   - ms_1559_cop_approved_by_t_mobile_spo         | FLOAT            | COP approved SPO
   - ms_1559_cop_approved_by_t_mobile_spo_issued_date | LOCAL_DATE_TIME | COP SPO issued
   - name                                         | STRING           | Always '7. CX Readiness'
   - description                                  | STRING           | Construction readiness checks

--- RELATIONSHIPS (ALL start at Site) ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
""",

8: """
=== PHASE 8: Civil Construction and Power/AAV Tracking ===

Phase 8 tracks civil construction start/finish and links to power installation and AAV/MW readiness. It also connects to HSE and the DEC COP process.

--- NODES ---

1. Phase8_Civil_Work
   - pj_project_id                                | STRING           | Primary key
   - pj_p_4250_civil_construction_start_finish    | LOCAL_DATE_TIME  | Planned civil start
   - pj_a_4250_civil_construction_start_finish    | LOCAL_DATE_TIME  | Actual civil start
   - pj_p_4750_civil_construction_complete_finish | LOCAL_DATE_TIME  | Planned civil complete
   - pj_a_4750_civil_construction_complete_finish | LOCAL_DATE_TIME  | Actual civil complete
   - name                                         | STRING           | Always '8. Civil'
   - description                                  | STRING           | Civil construction milestones

2. Power_Installation
   - pj_project_id                     | STRING           | Primary key
   - pj_p_4525_power_ready_finish      | LOCAL_DATE_TIME  | Planned power ready
   - pj_a_4525_power_ready_finish      | LOCAL_DATE_TIME  | Actual power ready
   - pj_p_4550_permanent_power_installed_finish | LOCAL_DATE_TIME | Planned permanent power
   - pj_a_4550_permanent_power_installed_finish | LOCAL_DATE_TIME | Actual permanent power
   - name                              | STRING           | Always 'Power_Installation'
   - description                       | STRING           | Permanent power milestones

3. AAV_and_MW
   - pj_project_id                              | STRING           | Primary key
   - pj_p_4875_aav_telco_ready_finish           | LOCAL_DATE_TIME  | Planned AAV ready
   - pj_a_4875_aav_telco_ready_finish           | LOCAL_DATE_TIME  | Actual AAV ready
   - pj_p_4425_mw_installation_complete_finish  | LOCAL_DATE_TIME  | Planned MW install complete
   - pj_a_4425_mw_installation_complete_finish  | LOCAL_DATE_TIME  | Actual MW install complete
   - name                                       | STRING           | Always 'AAV_and_MW'
   - description                                | STRING           | AAV & microwave readiness

--- RELATIONSHIPS (ALL start at Site) ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)-[:8HAS_SUBPHASE1]->(Power_Installation)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)-[:8HAS_SUBPHASE2]->(AAV_and_MW)

# Site -> HSE and Site -> DEC_COP are shown ONCE in their respective sections.
# Site -> Phase9 handoff:
(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_P9]->(Phase9_Tower_Work)
""",

9: """
=== PHASE 9: Tower Construction and Structural Work ===

Phase 9 covers tower construction start/finish, delay codes/comments, and hands off to integration after completion.

--- NODES ---

1. Phase9_Tower_Work
   - pj_project_id                           | STRING           | Primary key
   - pj_p_4225_construction_start_finish     | LOCAL_DATE_TIME  | Planned tower start
   - pj_a_4225_construction_start_finish     | LOCAL_DATE_TIME  | Actual tower start
   - pj_p_5175_construction_complete_finish  | LOCAL_DATE_TIME  | Planned tower complete
   - pj_a_5175_construction_complete_finish  | LOCAL_DATE_TIME  | Actual tower complete
   - pj_construction_start_delay_code        | STRING           | Start delay code
   - pj_construction_start_delay_comments    | FLOAT            | Start delay comments
   - pj_construction_complete_delay_code     | FLOAT            | Complete delay code
   - pj_construction_complete_delay_comments | FLOAT            | Complete delay comments
   - name                                    | STRING           | Always '9. Tower'
   - description                             | STRING           | Tower construction milestones

--- RELATIONSHIPS (ALL start at Site) ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_P9]->(Phase9_Tower_Work)

# Site -> HSE and Site -> DEC_COP are shown ONCE in their sections.
# Handoff to Phase 10:
(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_P9]->(Phase9_Tower_Work)
       -[:P9_TO_P10]->(Phase10_Integration)
""",

10: """
=== PHASE 10: Network Integration ===

Phase 10 executes and records integration milestones, SCF validation, technology integration, AirView, and E911 tests.

--- NODES ---

1. Phase10_Integration
   - pj_project_id                               | STRING           | Primary key
   - pj_p_5270_integration_start_finish          | LOCAL_DATE_TIME  | Planned integration start
   - pj_a_5270_integration_start_finish          | LOCAL_DATE_TIME  | Actual integration start
   - pj_p_5275_integration_complete_finish       | LOCAL_DATE_TIME  | Planned integration complete
   - pj_a_5275_integration_complete_finish       | LOCAL_DATE_TIME  | Actual integration complete
   - pj_integration_comments                     | STRING           | Integration comments
   - ms_1564_validate_scf_files_are_available_actual | LOCAL_DATE_TIME | SCF validated
   - ms_1899_all_planned_technologies_integrated_actual | LOCAL_DATE_TIME | All techs integrated
   - ms_1971_air_view_report_completed_actual    | LOCAL_DATE_TIME  | AirView completed
   - ms_2123_planned_e911_test_calls_actual      | LOCAL_DATE_TIME  | E911 test calls
   - name                                        | STRING           | Always '10. Integration'
   - description                                 | STRING           | Integration milestones

--- RELATIONSHIPS (ALL start at Site) ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_P9]->(Phase9_Tower_Work)
       -[:P9_TO_P10]->(Phase10_Integration)
       -[:P10_TO_P11]->(Phase11_Post_Integration)
""",

11: """
=== PHASE 11: Post-Integration, RTT & On-Air ===

Phase 11 finalizes integration commercial steps and tracks RTT per band and On-Air activation per band.

--- NODES ---

1. Phase11_Post_Integration
   - pj_project_id                          | STRING           | Primary key
   - ms_1970_integration_complete_actual    | LOCAL_DATE_TIME  | Integration complete
   - ms_1970_integration_complete_ca_date   | LOCAL_DATE_TIME  | CA complete
   - ms_1970_integration_complete_bbr_date  | LOCAL_DATE_TIME  | BBR complete
   - ms_1970_integration_complete_so_inv_date | LOCAL_DATE_TIME| SO invoice date
   - ms_1970_integration_complete_ia_date   | LOCAL_DATE_TIME  | IA complete
   - ms_1970_integration_complete_gr_date   | LOCAL_DATE_TIME  | GR complete
   - ms_1970_integration_complete_spo_issued_date | LOCAL_DATE_TIME | SPO issued
   - name                                   | STRING           | Always '11. Post_Integration'
   - description                            | STRING           | Post-integration milestones

2. RTT
   - pj_project_id | STRING | Primary key
   - ...           |        | RTT planned/actual per band:
       * GSM/CDMA/Ux/Lx bands (e.g., pj_p_5575_gsm_rtt_finish, pj_a_5575_gsm_rtt_finish, ... )
       * LTE & NR bands including: L700/L850/L1900/L2100/L2500/L3500, N600/N1900/N2100/N2500/N28/N24/N39/N47/N3400/N3700
       * T-Mobile-specific test milestones (t698/t600/t700 etc.)
   - name          | STRING | Always 'RTT'
   - description   | STRING | RTT milestone tracking per spectrum band

3. OnAir
   - pj_project_id                 | STRING           | Primary key
   - pj_a_5800_l2100_onair_finish  | LOCAL_DATE_TIME  | L2100 On-Air
   - pj_a_5750_l1900_onair_finish  | LOCAL_DATE_TIME  | L1900 On-Air
   - pj_a_6000_l700_onair_finish   | LOCAL_DATE_TIME  | L700 On-Air
   - pj_a_5850_l2100_aws3_onair_finish | LOCAL_DATE_TIME | L2100 AWS3 On-Air
   - pj_a_5900_l600_onair_finish   | LOCAL_DATE_TIME  | L600 On-Air
   - pj_a_5863_l2500_onair_finish  | LOCAL_DATE_TIME  | L2500 On-Air
   - pj_a_6050_l850_onair_finish   | LOCAL_DATE_TIME  | L850 On-Air
   - pj_a_5950_n600_onair_finish   | LOCAL_DATE_TIME  | N600 On-Air
   - pj_a_6318_n2500_onair_finish  | LOCAL_DATE_TIME  | N2500 On-Air
   - pj_a_6257_n1900_onair_finish  | LOCAL_DATE_TIME  | N1900 On-Air
   - pj_a_6270_n2100_onair_finish  | LOCAL_DATE_TIME  | N2100 On-Air
   - pj_a_6300_n28_onair_finish    | LOCAL_DATE_TIME  | N28 On-Air
   - pj_a_5700_u2100_onair_finish  | LOCAL_DATE_TIME  | U2100 On-Air
   - pj_a_5650_u1900_onair_finish  | LOCAL_DATE_TIME  | U1900 On-Air
   - pj_a_5600_gsm_onair_finish    | LOCAL_DATE_TIME  | GSM On-Air
   - name                          | STRING           | Always 'Phase11_OnAir'
   - description                   | STRING           | On-Air activation per band

--- RELATIONSHIPS (ALL start at Site) ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_P9]->(Phase9_Tower_Work)
       -[:P9_TO_P10]->(Phase10_Integration)
       -[:P10_TO_P11]->(Phase11_Post_Integration)

# Sub-phase links (Site-rooted)
(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_P9]->(Phase9_Tower_Work)
       -[:P9_TO_P10]->(Phase10_Integration)
       -[:P10_TO_P11]->(Phase11_Post_Integration)-[:11HAS_SUBPHASE1]->(RTT)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_P9]->(Phase9_Tower_Work)
       -[:P9_TO_P10]->(Phase10_Integration)
       -[:P10_TO_P11]->(Phase11_Post_Integration)-[:11HAS_SUBPHASE2]->(OnAir)

# Handoff to Phase 12:
(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_P9]->(Phase9_Tower_Work)
       -[:P9_TO_P10]->(Phase10_Integration)
       -[:P10_TO_P11]->(Phase11_Post_Integration)
       -[:P11_TO_P12]->(Phase12_Revenue)
""",

12: """
=== PHASE 12: Revenue & Financial Close-Out ===

Phase 12 consolidates financial milestones for Civil, Tower, and Punch List (COP) workstreams: IA, GR, CA, invoicing, and BBR.

--- NODES ---

1. Phase12_Revenue
   - pj_project_id | STRING | Primary key
   - name          | STRING | Always '12. Revenue'
   - description   | STRING | Revenue closure root node

2. Civil_Revenue
   - pj_project_id                                       | STRING           | Primary key
   - pj_p_2275_final_construction_drawings_approved_finish | LOCAL_DATE_TIME| Planned CDs final approved (xref)
   - pj_a_2275_final_construction_drawings_approved_finish | LOCAL_DATE_TIME| Actual CDs final approved (xref)
   - ms_1551_civil_construction_complete_ia_date         | LOCAL_DATE_TIME  | Civil IA complete
   - ms_1551_civil_construction_complete_gr_date         | LOCAL_DATE_TIME  | Civil GR complete
   - ms_1551_civil_construction_complete_gr_so_number    | STRING           | Civil GR SO number
   - ms_1551_civil_construction_complete_invoice_date    | LOCAL_DATE_TIME  | Civil invoice date
   - ms_1551_civil_construction_complete_invoice         | STRING           | Civil invoice #
   - ms_1551_civil_construction_complete_ca_date         | LOCAL_DATE_TIME  | Civil CA complete
   - name                                                | STRING           | Always 'Civil_Revenue'
   - description                                         | STRING           | Civil finance milestones

3. Tower_Revenue
   - pj_project_id                         | STRING           | Primary key
   - ms1555_construction_complete_invoice_date | LOCAL_DATE_TIME | Tower invoice date
   - ms1555_construction_complete_invoice | STRING/FLOAT      | Tower invoice #
   - ms1555_construction_complete_ca_date | LOCAL_DATE_TIME   | Tower CA complete
   - ms1555_construction_complete_bbr_date| LOCAL_DATE_TIME   | Tower BBR complete
   - ms1555_construction_complete_gr_date | LOCAL_DATE_TIME   | Tower GR complete
   - ms1555_construction_complete_ia_date | LOCAL_DATE_TIME   | Tower IA complete
   - name                                 | STRING            | Always 'Tower_Revenue'
   - description                          | STRING            | Tower finance milestones

4. PL_Revenue
   - pj_project_id                          | STRING           | Primary key
   - ms_1559_cop_approved_by_t_mobile_ia_date | LOCAL_DATE_TIME| COP IA
   - ms_1559_cop_approved_by_t_mobile_gr_date | LOCAL_DATE_TIME| COP GR
   - ms_1559_cop_approved_by_t_mobile_ca_date | LOCAL_DATE_TIME| COP CA
   - ms_1559_cop_approved_by_t_mobile_bbr_date| LOCAL_DATE_TIME| COP BBR
   - name                                   | STRING           | Always 'PL Finance'
   - description                            | STRING           | COP finance milestones

--- RELATIONSHIPS (ALL start at Site) ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_P9]->(Phase9_Tower_Work)
       -[:P9_TO_P10]->(Phase10_Integration)
       -[:P10_TO_P11]->(Phase11_Post_Integration)
       -[:P11_TO_P12]->(Phase12_Revenue)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_P9]->(Phase9_Tower_Work)
       -[:P9_TO_P10]->(Phase10_Integration)
       -[:P10_TO_P11]->(Phase11_Post_Integration)
       -[:P11_TO_P12]->(Phase12_Revenue)-[:12HAS_SUBPHASE1]->(Civil_Revenue)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_P9]->(Phase9_Tower_Work)
       -[:P9_TO_P10]->(Phase10_Integration)
       -[:P10_TO_P11]->(Phase11_Post_Integration)
       -[:P11_TO_P12]->(Phase12_Revenue)-[:12HAS_SUBPHASE2]->(Tower_Revenue)

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
       -[:P1_TO_P2]->(Phase2_PreConstruction)
       -[:P2_TO_P3]->(Phase3_Scoping)
       -[:P3_TO_P4]->(Phase4_Quoting)
       -[:P4_TO_P5]->(Phase5_NTP_and_Material)
       -[:P5_TO_P6]->(Phase6_Transport_and_Power)
       -[:P6_TO_PHASE7]->(Phase7_Construction_Readiness)
       -[:P7_TO_P8]->(Phase8_Civil_Work)
       -[:P8_TO_P9]->(Phase9_Tower_Work)
       -[:P9_TO_P10]->(Phase10_Integration)
       -[:P10_TO_P11]->(Phase11_Post_Integration)
       -[:P11_TO_P12]->(Phase12_Revenue)-[:12HAS_SUBPHASE3]->(PL_Revenue)
""",
}