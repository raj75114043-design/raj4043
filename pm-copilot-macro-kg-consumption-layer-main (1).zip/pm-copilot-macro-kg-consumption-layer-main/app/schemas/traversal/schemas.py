from pydantic import BaseModel

class SchemaExtractionRequest(BaseModel):
    query: str

class SchemaExtractionResponse(BaseModel):
    query: str
    relevant_schema: str