from pydantic import BaseModel
from typing import List

# ----------- Request Schema -----------
class PhaseRouterRequest(BaseModel):
    query: str

# ----------- Response Schema -----------
class PhaseRouterResponse(BaseModel):
    phases: List[int]
    modules: List[str]