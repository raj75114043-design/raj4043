# app/services/text2cypher/schemas.py
from typing import List, Optional, Literal
from pydantic import BaseModel, Field
from typing_extensions import TypedDict

# ----- API request/response (stay as Pydantic) -----

class Text2CypherRequest(BaseModel):
    question: str = Field(..., min_length=3, max_length=4000)
    phases:   Optional[List[int]]  = None
    modules:  Optional[List[str]]  = None
    timeout_s: Optional[float] = Field(default=100.0, ge=1.0, le=300.0)

class Text2CypherResponse(BaseModel):
    status: Literal["ok", "error"]
    message: Optional[str] = None
    cypher_statement: Optional[str] = None
    cypher_errors: Optional[List[str]] = None
    records: Optional[List[dict]] = None
    steps: List[str] = []
    retries: int = 0

# ----- LLM structured output -----

class Property(BaseModel):
    node_label:     str
    property_key:   str
    property_value: str

class ValidateAndCorrectOutput(BaseModel):
    errors:           Optional[List[str]] = None
    filters:          Optional[List[Property]] = None
    corrected_cypher: str

# ----- Agent internal state (TypedDict for LangGraph) -----

class AgentStateDict(TypedDict, total=False):
    question:         str
    phases:           List[int]
    modules:          List[str]
    next_action:      str
    cypher_statement: str
    cypher_errors:    List[str]
    database_records: List[dict]
    steps:            List[str]
    answer:           str
    retry_count:      int

# ----- Phase Router Output -----

class PhaseRouterOutput(BaseModel):
    """Output schema for routing user query to relevant project phases and modules."""
    phases: List[int] = Field(
        description="List of relevant project phase numbers from 1 to 11"
    )
    modules: List[str] = Field(
        default=[],
        description="List of additional module keys relevant to the query. Valid values: 'HSE', 'DEC_COP'"
    )