from typing import Optional
from app.db.neo4j_database import get_neo4j_ahloa_driver
from app.utils.neo4j_serialization import serialize_neo4j_value

SITE_MILESTONES_CYPHER = """
MATCH (s:Site {s_site_id: $site_id})

// Phase 1
OPTIONAL MATCH (s)-[:SITE_TO_P1]->(p1:Phase1_ProjectAssignment)
OPTIONAL MATCH (p1)-[:HAS_DETAILS]->(p1d:Phase1_Details)
OPTIONAL MATCH (p1)-[:HAS_SUBPHASE]->(smp:SMP_ID_Creation)
OPTIONAL MATCH (p1)-[:HAS_SUBPHASE]->(hc:Hard_cost_vendor_assignment)
OPTIONAL MATCH (p1)-[:HAS_SUBPHASE]->(sc:Soft_cost_vendor_assignment)
OPTIONAL MATCH (p1)-[:HAS_SUBPHASE]->(va:Vendor_assignment)
OPTIONAL MATCH (p1)-[:PROJECT_NEEDS_DRONE]->(drone:Drone)

// Phase 2
OPTIONAL MATCH (s)-[:SITE_TO_P2]->(p2:Phase2_PreConstruction)
OPTIONAL MATCH (p2)-[:HAS_SUBPHASE]->(tv:Talon_View)
OPTIONAL MATCH (p2)-[:HAS_SUBPHASE]->(ec:Entitlement_Complete)
OPTIONAL MATCH (p2)-[:HAS_MILESTONES]->(pm:Precon_Milestones)

// Phase 3
OPTIONAL MATCH (s)-[:SITE_TO_P3]->(p3:Phase3_Scoping)
OPTIONAL MATCH (p3)-[:HAS_DETAILS]->(p3d:Phase3_Details)

// Phase 4
OPTIONAL MATCH (s)-[:SITE_TO_P4]->(p4:Phase4_Quoting)

// Phase 5
OPTIONAL MATCH (s)-[:SITE_TO_P5]->(p5:Phase5_NTP)

// Phase 6
OPTIONAL MATCH (s)-[:SITE_TO_P6]->(p6:Phase6_Material)
OPTIONAL MATCH (p6)-[:HAS_SUBPHASE]->(bom:BOM_Submission)
OPTIONAL MATCH (p6)-[:HAS_SUBPHASE]->(steel:Steel_Submission)
OPTIONAL MATCH (p6)-[:HAS_SUBPHASE]->(mp:Material_Pickup)

// Phase 7
OPTIONAL MATCH (s)-[:SITE_TO_P7]->(p7:Phase7_Construction_Readiness)

// Phase 8
OPTIONAL MATCH (s)-[:SITE_TO_P8]->(p8:Phase8_Tower_Work)

// Phase 9
OPTIONAL MATCH (s)-[:SITE_TO_P9]->(p9:Phase9_Integration)

// Phase 10
OPTIONAL MATCH (s)-[:SITE_TO_P10]->(p10:Phase11_Post_Integration)

// Phase 11 - Revenue
OPTIONAL MATCH (s)-[:SITE_TO_P11]->(p11:Phase12_Revenue)
OPTIONAL MATCH (p11)-[:HAS_SUBPHASE]->(tr:Tower_Revenue)
OPTIONAL MATCH (p11)-[:HAS_SUBPHASE]->(pl_rev:PL_Revenue)
OPTIONAL MATCH (p11)-[:HAS_SUBPHASE]->(ir:Integration_Revenue)

// HSE
OPTIONAL MATCH (s)-[:SITE_TO_HSE]->(hse:HSE)
OPTIONAL MATCH (hse)-[:VISITS]->(visit:Visit)
OPTIONAL MATCH (visit)-[:REJECTED]->(revisit:Revisit)

// DEC_COP
OPTIONAL MATCH (s)-[:SITE_TO_DEC_COP]->(dec:DEC_COP)
OPTIONAL MATCH (dec)-[:HAS_PL]->(pl_status:Punch_List_status)
OPTIONAL MATCH (dec)-[:PL_SUBMITTED]->(pl_sub:PL_Submission)
OPTIONAL MATCH (dec)-[:PL_RETURNED]->(pl_post:PL_Post_Submission)
OPTIONAL MATCH (dec)-[:PL_RESUBMITTED]->(pl_resub:PL_Resubmission)
OPTIONAL MATCH (dec)-[:PL_APPROVED]->(pl_final:PL_Final_Approval)

RETURN
  // Site
  s.s_site_id AS site_id,
  s.s_site_name AS site_name,
  s.s_state AS state,
  s.region AS region,
  s.m_area AS area,
  s.m_market AS market,

  // Phase 1
  p1.pj_project_id AS p1_project_id,
  p1.assigned_status AS p1_assigned_status,
  p1d.pj_project_type AS p1_project_type,
  p1d.por_por_id AS p1_por_id,
  smp.smp_id AS p1_smp_id,
  smp.smp_name AS p1_smp_name,
  smp.smp_status AS p1_smp_status,
  hc.pj_hard_cost_vendor_assignment_po AS p1_hc_vendor,
  hc.pj_hard_cost_approval_date AS p1_hc_approval_date,
  hc.assigned_status AS p1_hc_assigned_status,
  sc.pj_soft_cost_vendor AS p1_sc_vendor,
  sc.pj_soft_cost_approval_date AS p1_sc_approval_date,
  sc.assigned_status AS p1_sc_assigned_status,
  va.construction_gc AS p1_gc,
  va.assigned_status AS p1_gc_assigned_status,
  va.pj_a_3775_gc_selected_finish AS p1_gc_selected_actual,
  va.pj_p_3775_gc_selected_finish AS p1_gc_selected_planned,
  drone.ms_1321_talon_view_drone_svcs_actual AS p1_drone_assigned_date,

  // Phase 2
  p2.precon_status AS p2_precon_status,
  tv.pj_a_1010_talonview_pre_con_site_survey_ordered_finish AS p2_tv_ordered_actual,
  tv.pj_p_1010_talonview_pre_con_site_survey_ordered_finish AS p2_tv_ordered_planned,
  tv.pj_a_1015_talonview_pre_con_site_survey_approved_finish AS p2_tv_approved_actual,
  tv.pj_p_1015_talonview_pre_con_site_survey_approved_finish AS p2_tv_approved_planned,
  ec.pj_a_3710_ran_entitlement_complete_finish AS p2_ran_ec_actual,
  ec.pj_p_3710_ran_entitlement_complete_finish AS p2_ran_ec_planned,
  ec.pj_a_3725_all_entitlement_complete_finish AS p2_all_ec_actual,
  ec.pj_p_3725_all_entitlement_complete_finish AS p2_all_ec_planned,
  pm.pj_a_3800_pre_ntp_issued_finish AS p2_pre_ntp_actual,
  pm.pj_p_3800_pre_ntp_issued_finish AS p2_pre_ntp_planned,
  pm.pj_a_2225_construction_drawings_received_finish AS p2_cd_received_actual,
  pm.pj_p_2225_construction_drawings_received_finish AS p2_cd_received_planned,
  pm.pj_a_2250_construction_drawings_redlines_compiled_finish AS p2_cd_redlines_actual,
  pm.pj_p_2250_construction_drawings_redlines_compiled_finish AS p2_cd_redlines_planned,
  pm.pj_a_2275_final_construction_drawings_approved_finish AS p2_cd_final_actual,
  pm.pj_p_2275_final_construction_drawings_approved_finish AS p2_cd_final_planned,

  // Phase 3
  p3.scoping_status AS p3_scoping_status,
  p3d.pj_a_3825_pre_construction_walk_complete_finish AS p3_site_walk_actual,
  p3d.pj_p_3825_pre_construction_walk_complete_finish AS p3_site_walk_planned,

  // Phase 4
  p4.quoting_status AS p4_quoting_status,
  p4.pj_a_3815_bid_walk_complete_finish AS p4_bid_walk_actual,
  p4.pj_p_3815_bid_walk_complete_finish AS p4_bid_walk_planned,
  p4.pj_bid_walk_complete_3815_doc AS p4_equote_name,
  p4.pj_bid_walk_complete_optional_status AS p4_equote_status,

  // Phase 5
  p5.pj_a_4075_construction_ntp_submitted_to_gc_finish AS p5_ntp_submitted_actual,
  p5.pj_p_4075_construction_ntp_submitted_to_gc_finish AS p5_ntp_submitted_planned,
  p5.pj_a_4100_construction_ntp_accepted_by_gc_finish AS p5_ntp_accepted_actual,
  p5.pj_p_4100_construction_ntp_accepted_by_gc_finish AS p5_ntp_accepted_planned,
  p5.ms_1407_tower_ntp_validated_actual AS p5_ntp_validated_actual,
  p5.ms_1507_tower_ntp_approved_actual AS p5_ntp_approved_actual,

  // Phase 6
  p6.material_status AS p6_material_status,
  bom.pj_a_3850_bom_submitted_bom_in_bat_finish AS p6_bom_bat_actual,
  bom.pj_p_3850_bom_submitted_bom_in_bat_finish AS p6_bom_bat_planned,
  bom.pj_a_3875_bom_received_bom_in_aims_finish AS p6_bom_aims_actual,
  bom.pj_p_3875_bom_received_bom_in_aims_finish AS p6_bom_aims_planned,
  bom.pj_a_3900_all_bat_orders_received_finish AS p6_material_arrived_actual,
  bom.pj_p_3900_all_bat_orders_received_finish AS p6_material_arrived_planned,
  steel.pj_steel_ordered_status AS p6_steel_ordered_status,
  steel.pj_steel_received_status AS p6_steel_received_status,
  steel.pj_steel_po_number AS p6_steel_po_number,
  steel.pj_steel_ordered AS p6_steel_ordered_date,
  steel.pj_steel_received_date AS p6_steel_received_date,
  mp.pj_a_3925_msl_pickup_date_finish AS p6_material_pickup_actual,
  mp.pj_p_3925_msl_pickup_date_finish AS p6_material_pickup_planned,
  mp.ms_1461_pickup_tower_materials_and_validate_actual AS p6_material_pickup_pm,
  mp.ms_14610_gc_material_pickup_actual AS p6_material_pickup_gc,

  // Phase 7
  p7.pj_construction_pos_issued AS p7_pos_issued,
  p7.ms_1321_talon_view_drone_svcs_spo AS p7_talonview_spo,
  p7.ms_1321_talon_view_drone_svcs_spo_issued_date AS p7_talonview_spo_date,
  p7.ms1555_construction_complete_spo AS p7_tower_spo,
  p7.ms1555_construction_complete_spo_issued_date AS p7_tower_spo_date,

  // Phase 8
  p8.pj_a_4225_construction_start_finish AS p8_tower_start_actual,
  p8.pj_p_4225_construction_start_finish AS p8_tower_start_planned,
  p8.pj_a_5175_construction_complete_finish AS p8_tower_complete_actual,
  p8.pj_p_5175_construction_complete_finish AS p8_tower_complete_planned,
  p8.pj_construction_start_delay_code AS p8_start_delay_code,
  p8.pj_construction_start_delay_comments AS p8_start_delay_comments,
  p8.pj_construction_complete_delay_code AS p8_complete_delay_code,
  p8.pj_construction_complete_delay_comments AS p8_complete_delay_comments,

  // Phase 9
  p9.pj_a_5270_integration_start_finish AS p9_integration_start_actual,
  p9.pj_p_5270_integration_start_finish AS p9_integration_start_planned,
  p9.pj_a_5275_integration_complete_finish AS p9_integration_complete_actual,
  p9.pj_p_5275_integration_complete_finish AS p9_integration_complete_planned,
  p9.pj_integration_comments AS p9_integration_comments,
  p9.ms_1899_all_planned_technologies_integrated_actual AS p9_all_techs_integrated,

  // Phase 10
  p10.ms_1970_integration_complete_actual AS p10_post_integration_complete,
  p10.ms_2045_72_hours_monitoring_complete_actual AS p10_72hr_monitoring_complete,
  p10.ms_17050_gc_ahloa_return_actual AS p10_equipment_returned,
  p10.ms_17100_gc_ahloa_disposal_actual AS p10_equipment_disposed,

  // Phase 11 - Revenue
  tr.ms1555_construction_complete_invoice_date AS p11_tower_invoice_date,
  tr.ms1555_construction_complete_invoice AS p11_tower_invoice,
  tr.ms1555_construction_complete_ca_date AS p11_tower_ca_date,
  tr.ms1555_construction_complete_bbr_date AS p11_tower_bbr_date,
  tr.ms1555_construction_complete_gr_date AS p11_tower_gr_date,
  tr.ms1555_construction_complete_ia_date AS p11_tower_ia_date,
  pl_rev.ms_1559_cop_approved_by_t_mobile_ia_date AS p11_cop_ia_date,
  pl_rev.ms_1559_cop_approved_by_t_mobile_gr_date AS p11_cop_gr_date,
  pl_rev.ms_1559_cop_approved_by_t_mobile_ca_date AS p11_cop_ca_date,
  pl_rev.ms_1559_cop_approved_by_t_mobile_bbr_date AS p11_cop_bbr_date,
  ir.ms_1970_integration_complete_actual AS p11_integration_complete,
  ir.ms_1970_integration_complete_ca_date AS p11_integration_ca_date,
  ir.ms_1970_integration_complete_bbr_date AS p11_integration_bbr_date,
  ir.ms_1970_integration_complete_so_inv_date AS p11_integration_so_inv_date,
  ir.ms_1970_integration_complete_ia_date AS p11_integration_ia_date,
  ir.ms_1970_integration_complete_gr_date AS p11_integration_gr_date,
  ir.ms_1970_integration_complete_spo_issued_date AS p11_integration_spo_issued_date,

  // HSE
  collect(DISTINCT {
    check_in_status: visit.check_in_status,
    check_in_date: visit.check_in_date,
    ppe_validation: visit.ppe_validation,
    ppe_photo_available: visit.ppe_photo_available,
    jsa_completion_status: visit.jsa_completion_status,
    each_crew_ptid_l2w_status: visit.each_crew_ptid_l2w_status,
    visit_num: visit.visit_num,
    revisit_non_compliance_category: revisit.non_compliance_category,
    revisit_escalation_l1: revisit.escalation_l1_to_gc,
    revisit_escalation_l2: revisit.esaclation_l2_to_cm,
    revisit_escalation_l3: revisit.esaclation_l3_to_pm,
    revisit_escalation_l4: revisit.escalation_l4_pd_all
  }) AS hse_visits,

  // DEC_COP
  dec.scop_title AS dec_cop_title,
  dec.approvedpercent AS dec_cop_approved_pct,
  pl_status.scop_ndpc_session_created_cw AS dec_pl_session_created,
  pl_status.scop_ndpc_session_cw_last_activity AS dec_pl_last_activity,
  pl_status.scop_ndpc_session_cw_pending_pct AS dec_civil_pending_pct,
  pl_status.scop_ndpc_session_cw_completed_pct AS dec_civil_completed_pct,
  pl_status.scop_ndpc_session_cw_approved_pct AS dec_civil_approved_pct,
  pl_status.scop_ndpc_session_cw_rejected_pct AS dec_civil_rejected_pct,
  pl_status.scop_ndpc_session_tw_pending_pct AS dec_tower_pending_pct,
  pl_status.scop_ndpc_session_tw_completed_pct AS dec_tower_completed_pct,
  pl_status.scop_ndpc_session_tw_approved_pct AS dec_tower_approved_pct,
  pl_status.scop_ndpc_session_tw_rejected_pct AS dec_tower_rejected_pct,
  pl_sub.ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl AS dec_pl_submitted_nokia,
  pl_sub.ms_1558_admin_checklist_submitted_to_t_mobile_actual AS dec_admin_checklist_submitted,
  pl_sub.ms_1553_review_civil_quality_media_checklist AS dec_civil_checklist_reviewed,
  pl_sub.pj_a_5500_receive_close_out_binder_finish AS dec_pl_received_tmobile_actual,
  pl_sub.pj_p_5500_receive_close_out_binder_finish AS dec_pl_received_tmobile_planned,
  pl_post.pj_a_5400_punch_list_to_gc_finish AS dec_pl_to_gc_actual,
  pl_post.pj_p_5400_punch_list_to_gc_finish AS dec_pl_to_gc_planned,
  pl_resub.pj_a_5425_punch_list_complete_finish AS dec_pl_resubmitted_actual,
  pl_resub.pj_p_5425_punch_list_complete_finish AS dec_pl_resubmitted_planned,
  pl_resub.scop_pending_days_for_gc_action AS dec_pl_gc_pending_days,
  pl_final.pj_a_5525_approve_close_out_binder_finish AS dec_pl_approved_tmobile_actual,
  pl_final.pj_p_5525_approve_close_out_binder_finish AS dec_pl_approved_tmobile_planned,
  pl_final.ms_1559_cop_approved_by_t_mobile_actual AS dec_cop_approved_nokia,
  pl_final.scop_checklist_accepted_by_customer AS dec_checklist_accepted,
  pl_final.pj_p_5540_financial_closeout_finish AS dec_financial_closeout_planned,
  pl_final.magenta_ms_5525_actual AS dec_pl_complete_nokia
"""


async def get_site_milestones(site_id: str) -> Optional[dict]:
    """
    Fetch all milestones across all phases (1-11), HSE, and DEC_COP
    for a given site_id.

    Args:
        site_id: The unique site identifier (e.g., '9NV0517R')

    Returns:
        A serialized dict of all milestone fields, or None if site not found.
    """
    driver = get_neo4j_ahloa_driver()

    async with driver.session() as session:
        result = await session.run(SITE_MILESTONES_CYPHER, site_id=site_id)
        record = await result.single()

    if record is None:
        return None

    return serialize_neo4j_value(record.data())