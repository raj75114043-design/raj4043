from typing import Optional
from app.db.neo4j_database import get_neo4j_nas_driver
from app.utils.neo4j_serialization import serialize_neo4j_value

NAS_SITE_MILESTONES_CYPHER = """
MATCH (s:Site {nas_site_id: $site_id})

// Phase 1 - e911
OPTIONAL MATCH (s)-[:SITE_E911]->(se:Site_e911)
OPTIONAL MATCH (se)-[:E911_READY]->(ready:READY)-[:READY_E911]->(e911_ready:e911)
OPTIONAL MATCH (se)-[:E911_INTP]->(intp:INTP)-[:INTP_E911]->(e911_intp:e911)
OPTIONAL MATCH (se)-[:E911_NOT_READY]->(not_ready:NOT_READY)-[:NOT_READY_E911]->(e911_not_ready:e911)

// Phase 2 - Planned Activities
OPTIONAL MATCH (s)-[:HAS_PLANNED_ACTIVITIES]->(spa:Site_Planned_Activity)
OPTIONAL MATCH (spa)-[:HAS_APPROVED_ACTIVITIES]->(pa_app:PA_Approved)-[:HAS_APPROVED_ACTIVITY]->(act_approved:Planned_Activity)
OPTIONAL MATCH (spa)-[:HAS_PENDING_ACTIVITIES]->(pa_pend:PA_Pending)-[:HAS_PENDING_ACTIVITY]->(act_pending:Planned_Activity)
OPTIONAL MATCH (spa)-[:HAS_REJECTED_ACTIVITIES]->(pa_rej:PA_Rejected)-[:HAS_REJECTED_ACTIVITY]->(act_rejected:Planned_Activity)

// Phase 3 - Sessions
OPTIONAL MATCH (s)-[:HAS_SESSIONS]->(ss:Site_Session)
OPTIONAL MATCH (ss)-[:HAS_SESSION]->(session:Session)
OPTIONAL MATCH (session)-[:HAS_CHECK_IN]->(sci:Session_Check_In)
OPTIONAL MATCH (session)-[:HAS_CHECK_OUT]->(sco:Session_Check_Out)
OPTIONAL MATCH (session)-[:HAS_EXTENSION]->(sext:Session_Extension)
OPTIONAL MATCH (session)-[:HAS_REJECTION]->(srej:Session_Rejection)

// Phase 4 - Integration
OPTIONAL MATCH (s)-[:HAS_Integration]->(sint:Site_Integration)
OPTIONAL MATCH (sint)-[:HAS_Call_Test]->(sct:Site_Call_Test)
OPTIONAL MATCH (sint)-[:HAS_GO_Email]->(sgo:Site_GO_Email)
OPTIONAL MATCH (sint)-[:HAS_Layers]->(slayers:Site_layers)

// Phase 5 - RF010
OPTIONAL MATCH (s)-[:HAS_RF010s]->(srf:Site_RF010)
OPTIONAL MATCH (srf)-[:HAS_RF010]->(rf010:RF010)
OPTIONAL MATCH (rf010)-[:HAS_MB]->(rf_mb:RF010_MB)
OPTIONAL MATCH (rf010)-[:HAS_Completion]->(rf_comp:RF010_Completion)
OPTIONAL MATCH (rf010)-[:HAS_HOP]->(rf_hop:RF010_HOP)

RETURN
  // Site
  s.nas_site_id AS site_id,
  s.name AS site_name,
  s.nas_market AS market,

  // Phase 1 - e911 (collected as lists per status)
  collect(DISTINCT {
    id: e911_ready.id,
    nas_site_id: e911_ready.nas_site_id,
    status: 'READY',
    nas_validate_e911_readiness: e911_ready.nas_validate_e911_readiness,
    nas_e911_validation_date: e911_ready.nas_e911_validation_date,
    nas_e911_validation_reason: e911_ready.nas_e911_validation_reason,
    nas_psap_id: e911_ready.nas_psap_id,
    nas_psap_name: e911_ready.nas_psap_name,
    nas_existing_layers: e911_ready.nas_existing_layers,
    nas_proposed_layers: e911_ready.nas_proposed_layers,
    nas_consolidation_check_all_layers: e911_ready.nas_consolidation_check_all_layers,
    nas_engineer: e911_ready.nas_engineer,
    nas_remarks: e911_ready.nas_remarks,
    e911_visit: e911_ready.e911_visit,
    create_date: e911_ready.create_date,
    write_date: e911_ready.write_date
  }) AS e911_ready_visits,

  collect(DISTINCT {
    id: e911_intp.id,
    nas_site_id: e911_intp.nas_site_id,
    status: 'INTP',
    nas_validate_e911_readiness: e911_intp.nas_validate_e911_readiness,
    nas_e911_validation_date: e911_intp.nas_e911_validation_date,
    nas_e911_validation_reason: e911_intp.nas_e911_validation_reason,
    nas_psap_id: e911_intp.nas_psap_id,
    nas_psap_name: e911_intp.nas_psap_name,
    nas_existing_layers: e911_intp.nas_existing_layers,
    nas_proposed_layers: e911_intp.nas_proposed_layers,
    nas_consolidation_check_all_layers: e911_intp.nas_consolidation_check_all_layers,
    nas_engineer: e911_intp.nas_engineer,
    nas_remarks: e911_intp.nas_remarks,
    e911_visit: e911_intp.e911_visit,
    create_date: e911_intp.create_date,
    write_date: e911_intp.write_date
  }) AS e911_intp_visits,

  collect(DISTINCT {
    id: e911_not_ready.id,
    nas_site_id: e911_not_ready.nas_site_id,
    status: 'NOT_READY',
    nas_validate_e911_readiness: e911_not_ready.nas_validate_e911_readiness,
    nas_e911_validation_date: e911_not_ready.nas_e911_validation_date,
    nas_e911_validation_reason: e911_not_ready.nas_e911_validation_reason,
    nas_psap_id: e911_not_ready.nas_psap_id,
    nas_psap_name: e911_not_ready.nas_psap_name,
    nas_existing_layers: e911_not_ready.nas_existing_layers,
    nas_proposed_layers: e911_not_ready.nas_proposed_layers,
    nas_consolidation_check_all_layers: e911_not_ready.nas_consolidation_check_all_layers,
    nas_engineer: e911_not_ready.nas_engineer,
    nas_remarks: e911_not_ready.nas_remarks,
    e911_visit: e911_not_ready.e911_visit,
    create_date: e911_not_ready.create_date,
    write_date: e911_not_ready.write_date
  }) AS e911_not_ready_visits,

  // Phase 2 - Planned Activities (collected as lists per status)
  collect(DISTINCT {
    activity_id: act_approved.activity_id,
    status: 'Approved',
    nas_status: act_approved.nas_status,
    nas_activity_details: act_approved.nas_activity_details,
    nas_activity_start_date: act_approved.nas_activity_start_date,
    nas_activity_end_date: act_approved.nas_activity_end_date,
    nas_request_time: act_approved.nas_request_time,
    nas_workorder_id: act_approved.nas_workorder_id,
    nas_company_name: act_approved.nas_company_name,
    nas_nest_type: act_approved.nas_nest_type,
    activity_order: act_approved.activity_order,
    create_date: act_approved.create_date,
    write_date: act_approved.write_date
  }) AS planned_activities_approved,

  collect(DISTINCT {
    activity_id: act_pending.activity_id,
    status: 'Pending',
    nas_status: act_pending.nas_status,
    nas_activity_details: act_pending.nas_activity_details,
    nas_activity_start_date: act_pending.nas_activity_start_date,
    nas_activity_end_date: act_pending.nas_activity_end_date,
    nas_request_time: act_pending.nas_request_time,
    nas_workorder_id: act_pending.nas_workorder_id,
    nas_company_name: act_pending.nas_company_name,
    nas_nest_type: act_pending.nas_nest_type,
    activity_order: act_pending.activity_order,
    create_date: act_pending.create_date,
    write_date: act_pending.write_date
  }) AS planned_activities_pending,

  collect(DISTINCT {
    activity_id: act_rejected.activity_id,
    status: 'Rejected',
    nas_status: act_rejected.nas_status,
    nas_activity_details: act_rejected.nas_activity_details,
    nas_activity_start_date: act_rejected.nas_activity_start_date,
    nas_activity_end_date: act_rejected.nas_activity_end_date,
    nas_request_time: act_rejected.nas_request_time,
    nas_workorder_id: act_rejected.nas_workorder_id,
    nas_company_name: act_rejected.nas_company_name,
    nas_nest_type: act_rejected.nas_nest_type,
    activity_order: act_rejected.activity_order,
    create_date: act_rejected.create_date,
    write_date: act_rejected.write_date
  }) AS planned_activities_rejected,

  // Phase 3 - Sessions (collected with sub-details)
  collect(DISTINCT {
    session_id: session.session_id,
    name: session.name,
    nas_activity_type: session.nas_activity_type,
    nas_company_name: session.nas_company_name,
    nas_contact_person: session.nas_contact_person,
    nas_user_id: session.nas_user_id,
    nas_workorder_id: session.nas_workorder_id,
    nas_nest_type: session.nas_nest_type,
    nas_status_nest_active: session.nas_status_nest_active,
    nas_last_event: session.nas_last_event,
    nas_nest_start_time: session.nas_nest_start_time,
    nas_nest_start_time_requested: session.nas_nest_start_time_requested,
    nas_checkout_time: session.nas_checkout_time,
    nas_checkout_approve_time: session.nas_checkout_approve_time,
    nas_total_activity_duration: session.nas_total_activity_duration,
    session_order: session.session_order,
    check_in: sci.check_in,
    check_out: sco.check_out,
    extension: sext.extension,
    rejection_reason: srej.rejection_reason,
    rejection_notes: srej.rejection_notes
  }) AS sessions,

  // Phase 4 - Integration
  sint.nas_integration_date AS integration_date,
  sint.nas_remarks AS integration_remarks,
  sct.nas_call_test_completed_date AS call_test_completed_date,
  sct.nas_call_test_completion_status AS call_test_completion_status,
  sct.nas_remarks AS call_test_remarks,
  sgo.nas_go_email_responsibility AS go_email_responsibility,
  sgo.nas_completion_partial_email_responsibility AS completion_partial_email_responsibility,
  slayers.nas_existing_layer AS integration_existing_layers,
  slayers.nas_proposed_layer AS integration_proposed_layers,

  // Phase 5 - RF010 (collected with sub-details)
  collect(DISTINCT {
    rf010_id: rf010.rf010_id,
    name: rf010.name,
    rf010_order: rf010.rf010_order,
    mb_status: rf_mb.mb_status,
    task_completed_datetime: rf_comp.task_completed_datetime,
    hop_validation_status: rf_hop.hop_validation_status
  }) AS rf010_records
"""


async def get_nas_site_milestones(site_id: str) -> Optional[dict]:
    """
    Fetch all milestones across all NAS phases (1-5) for a given nas_site_id.
    Covers e911 readiness, planned activities, sessions, integration, and RF010.

    Args:
        site_id: The unique NAS site identifier (e.g., 'NAS-SITE-001')

    Returns:
        A serialized dict of all milestone fields, or None if site not found.
    """
    driver = get_neo4j_nas_driver()

    async with driver.session() as session:
        result = await session.run(NAS_SITE_MILESTONES_CYPHER, site_id=site_id)
        record = await result.single()

    if record is None:
        return None

    return serialize_neo4j_value(record.data())