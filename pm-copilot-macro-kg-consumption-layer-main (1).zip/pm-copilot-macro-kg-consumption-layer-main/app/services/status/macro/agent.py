from typing import Optional
from app.db.neo4j_database import get_neo4j_driver
from app.utils.neo4j_serialization import serialize_neo4j_value

PROJECT_MILESTONES_CYPHER = """
MATCH (proj:Project {pj_project_id: $project_id})
MATCH (s:Site)-[:SITE_HAS_PROJECT]->(proj)

// Phase 1
OPTIONAL MATCH (proj)-[:PROJECT_TO_P1]->(p1:Phase1_ProjectAssignment)
OPTIONAL MATCH (p1)-[:HAS_DETAILS]->(p1d:Phase1_Details)
OPTIONAL MATCH (p1)-[:HAS_SUBPHASE]->(smp:SMP_ID_Creation)
OPTIONAL MATCH (p1)-[:HAS_SUBPHASE]->(hc:Hard_cost_vendor_assignment)
OPTIONAL MATCH (p1)-[:HAS_SUBPHASE]->(sc:Soft_cost_vendor_assignment)

// Phase 2
OPTIONAL MATCH (proj)-[:PROJECT_TO_P2]->(p2:Phase2_PreConstruction)
OPTIONAL MATCH (p2)-[:HAS_MILESTONES]->(pm:Precon_Milestones)
OPTIONAL MATCH (p2)-[:HAS_CD]->(cd:Construction_Drawings)
OPTIONAL MATCH (p2)-[:HAS_SUBPHASE]->(pv:Precon_Validation)
OPTIONAL MATCH (p2)-[:HAS_SUBPHASE]->(ec:Entitlement_Complete)
OPTIONAL MATCH (p2)-[:HAS_SUBPHASE]->(va:Vendor_assignment)

// Phase 3
OPTIONAL MATCH (proj)-[:PROJECT_TO_P3]->(p3:Phase3_Survey_and_Scoping)
OPTIONAL MATCH (p3)-[:HAS_MANUAL_SURVEY]->(ms_survey:Manual_Survey)
OPTIONAL MATCH (p3)-[:HAS_DRONE_SURVEY]->(ds:Drone_Survey)
OPTIONAL MATCH (p3)-[:HAS_SUBPHASE]->(sc3:Scoping_Completion)

// Phase 4
OPTIONAL MATCH (proj)-[:PROJECT_TO_P4]->(p4:Phase4_Quoting)

// Phase 5
OPTIONAL MATCH (proj)-[:PROJECT_TO_P5]->(p5:Phase5_NTP)
OPTIONAL MATCH (p5)-[:HAS_SUBPHASE]->(civil_ntp:Civil_NTP_Magenta)
OPTIONAL MATCH (p5)-[:HAS_SUBPHASE]->(tower_ntp:Tower_NTP_Magenta)
OPTIONAL MATCH (p5)-[:HAS_SUBPHASE]->(ntp_ndpd:NTP_NDPD)

// Phase 6
OPTIONAL MATCH (proj)-[:PROJECT_TO_P6]->(p6:Phase6_Material)
OPTIONAL MATCH (p6)-[:HAS_SUBPHASE]->(bom:BOM_Submission)
OPTIONAL MATCH (p6)-[:HAS_SUBPHASE]->(steel:Steel_Submission)
OPTIONAL MATCH (p6)-[:HAS_SUBPHASE]->(mp:Material_Pickup)

// Phase 7
OPTIONAL MATCH (proj)-[:PROJECT_TO_P7]->(p7:Phase7_AAV_and_Power_Planning)
OPTIONAL MATCH (p7)-[:HAS_AAV]->(aav:AAV)
OPTIONAL MATCH (p7)-[:HAS_POWER]->(pwr:Power)

// Phase 8
OPTIONAL MATCH (proj)-[:PROJECT_TO_P8]->(p8:Phase8_Construction_Readiness)

// Phase 9
OPTIONAL MATCH (proj)-[:PROJECT_TO_P9]->(p9:Phase9_Civil_Work)
OPTIONAL MATCH (p9)-[:HAS_SUBPHASE]->(cs:Civil_Start)
OPTIONAL MATCH (p9)-[:HAS_SUBPHASE]->(cf:Civil_Finish)
OPTIONAL MATCH (p9)-[:HAS_POWER_INSTALLATION]->(pi:Power_Installation)
OPTIONAL MATCH (p9)-[:HAS_AAV_AND_MW]->(amw:AAV_and_MW)

// Phase 10
OPTIONAL MATCH (proj)-[:PROJECT_TO_P10]->(p10:Phase10_Tower_Work)
OPTIONAL MATCH (p10)-[:HAS_SUBPHASE]->(ts:Tower_Start)
OPTIONAL MATCH (p10)-[:HAS_SUBPHASE]->(tf:Tower_Finish)
OPTIONAL MATCH (p10)-[:HAS_SUBPHASE]->(td:Tower_Delay)

// Phase 11
OPTIONAL MATCH (proj)-[:PROJECT_TO_P11]->(p11:Phase11_Integration)
OPTIONAL MATCH (p11)-[:HAS_SUBPHASE]->(int_s:Integration_Start)
OPTIONAL MATCH (p11)-[:HAS_SUBPHASE]->(int_f:Integration_Finish)
OPTIONAL MATCH (p11)-[:HAS_SUBPHASE]->(int_d:Integration_Details)

// Phase 12
OPTIONAL MATCH (proj)-[:PROJECT_TO_P12]->(p12:Phase12_Post_Integration)
OPTIONAL MATCH (p12)-[:HAS_SUBPHASE]->(rtt:RTT)
OPTIONAL MATCH (p12)-[:HAS_SUBPHASE]->(onair:OnAir)

// Phase 13 - Revenue
OPTIONAL MATCH (proj)-[:PROJECT_TO_P13]->(p13:Phase13_Revenue)
OPTIONAL MATCH (p13)-[:HAS_SUBPHASE]->(cr:Civil_Revenue)
OPTIONAL MATCH (p13)-[:HAS_SUBPHASE]->(tr:Tower_Revenue)
OPTIONAL MATCH (p13)-[:HAS_SUBPHASE]->(pl_rev:PL_Revenue)
OPTIONAL MATCH (p13)-[:HAS_SUBPHASE]->(ir:Integration_Revenue)

// HSE
OPTIONAL MATCH (proj)-[:PROJECT_TO_HSE]->(hse:HSE)
OPTIONAL MATCH (hse)-[:VISITS]->(visit:Visit)
OPTIONAL MATCH (visit)-[:REJECTED]->(revisit:Revisit)

// DEC_COP
OPTIONAL MATCH (proj)-[:SITE_TO_DEC_COP]->(dec:DEC_COP)
OPTIONAL MATCH (dec)-[:HAS_PL]->(pl_status:Punch_List_status)
OPTIONAL MATCH (dec)-[:PL_SUBMITTED]->(pl_sub:PL_Submission)
OPTIONAL MATCH (dec)-[:PL_RETURNED]->(pl_post:PL_Post_Submission)
OPTIONAL MATCH (dec)-[:PL_RESUBMITTED]->(pl_resub:PL_Resubmission)
OPTIONAL MATCH (dec)-[:PL_APPROVED]->(pl_final:PL_Final_Approval)

RETURN
  // Site & Project
  s.s_site_id AS site_id,
  s.s_site_name AS site_name,
  s.s_state AS state,
  s.region AS region,
  s.m_area AS area,
  s.m_market AS market,
  proj.pj_project_id AS project_id,
  proj.pj_project_name AS project_name,
  proj.pj_project_status AS project_status,
  proj.pj_project_type AS project_type,

  // Phase 1
  p1.s_site_id AS p1_site_id,
  p1d.smp_id AS p1_smp_id,
  p1d.pj_por_count AS p1_por_count,
  p1d.por_por_id AS p1_por_id,
  p1d.por AS p1_por_build_plan_year,
  smp.smp_id AS p1_smp_wo_id,
  smp.smp_name AS p1_smp_name,
  smp.smp_version AS p1_smp_version,
  smp.smp_status AS p1_smp_status,
  hc.pj_hard_cost_vendor_assignment_po AS p1_hc_vendor,
  hc.pj_hard_cost_approval_date AS p1_hc_approval_date,
  sc.s_primary_aav_vendor_name_salesforce AS p1_sc_aav_vendor,
  sc.pj_soft_cost_approval_date AS p1_sc_approval_date,

  // Phase 2
  p2.precon_status AS p2_precon_status,
  pm.pj_a_3800_pre_ntp_issued_finish AS p2_pre_ntp_actual,
  pm.pj_p_3800_pre_ntp_issued_finish AS p2_pre_ntp_planned,
  pm.ms_1310_pre_construction_package_received_actual AS p2_precon_pkg_received_nokia,
  pm.pj_p_1400_structural_complete_finish AS p2_structural_complete_planned,
  pm.pj_p_1525_mount_analysis_ordered_finish AS p2_ma_ordered_planned,
  pm.pj_p_1550_mount_analysis_received_finish AS p2_ma_received_planned,
  pm.pj_p_2200_construction_drawings_ordered_finish AS p2_cd_ordered_planned,
  pm.pj_p_2225_construction_drawings_received_finish AS p2_cd_received_planned,
  pm.pj_p_2250_construction_drawings_redlines_compiled_finish AS p2_cd_redlines_planned,
  pm.pj_p_2275_final_construction_drawings_approved_finish AS p2_cd_final_planned,
  pm.pj_p_2286_mw_final_construction_drawings_approved_finish AS p2_mw_cd_final_planned,
  pm.pj_p_2350_bom_submitted_from_market_to_region_finish AS p2_bom_submitted_planned,
  cd.pj_a_2200_construction_drawings_ordered_finish AS p2_cd_ordered_actual,
  cd.pj_a_2225_construction_drawings_received_finish AS p2_cd_received_actual,
  cd.pj_a_2250_construction_drawings_redlines_compiled_finish AS p2_cd_redlines_actual,
  cd.pj_a_2275_final_construction_drawings_approved_finish AS p2_cd_final_actual,
  cd.pj_a_2286_mw_final_construction_drawings_approved_finish AS p2_mw_cd_final_actual,
  pv.validation_status AS p2_validation_status,
  pv.pre_con_validation_rejection_reason AS p2_rejection_reason,
  pv.ms_1313_pre_construction_package_validated_actual AS p2_validated_actual,
  pv.ms_1315_pre_construction_package_rejected_actual AS p2_rejected_actual,
  ec.pj_a_3710_ran_entitlement_complete_finish AS p2_ran_ec_actual,
  ec.pj_p_3710_ran_entitlement_complete_finish AS p2_ran_ec_planned,
  ec.pj_a_3725_all_entitlement_complete_finish AS p2_all_ec_actual,
  ec.pj_p_3725_all_entitlement_complete_finish AS p2_all_ec_planned,
  va.construction_gc AS p2_gc,
  va.pj_a_3775_gc_selected_finish AS p2_gc_selected_actual,
  va.pj_p_3775_gc_selected_finish AS p2_gc_selected_planned,

  // Phase 3
  p3.scoping_status AS p3_scoping_status,
  ms_survey.pre_con_type AS p3_manual_survey_type,
  ms_survey.ms_1316_pre_con_site_walk_completed_actual AS p3_manual_walk_actual,
  ds.pre_con_type AS p3_drone_survey_type,
  ds.ms_1314_ndpc_survey_request_form_submitted_actual AS p3_drone_request_actual,
  ds.ms_1321_talon_view_drone_svcs_actual AS p3_drone_survey_actual,
  ds.ms_1321_talon_view_drone_svcs_spo_issued_date AS p3_drone_spo_issued,
  sc3.pj_a_3825_pre_construction_walk_complete_finish AS p3_survey_complete_actual,
  sc3.pj_p_3825_pre_construction_walk_complete_finish AS p3_survey_complete_planned,
  sc3.ms_1323_ready_for_scoping_actual AS p3_scoping_ready_actual,
  sc3.ms_1327_scoping_and_quoting_package_validated_actual AS p3_scoping_validated_actual,

  // Phase 4
  p4.quoting_status AS p4_quoting_status,
  p4.pj_a_3815_bid_walk_complete_finish AS p4_bid_walk_actual,
  p4.pj_p_3815_bid_walk_complete_finish AS p4_bid_walk_planned,
  p4.pj_bid_walk_complete_3815_doc AS p4_equote_name,
  p4.pj_bid_walk_complete_optional_status AS p4_equote_status,
  p4.ms_1331_scoping_package_submitted_actual AS p4_sp_submitted_actual,
  p4.ms_1333_scoping_package_approved_by_customer_actual AS p4_sp_approved_actual,

  // Phase 5
  civil_ntp.pj_a_4025_civil_ntp_submitted_to_gc_finish AS p5_civil_ntp_submitted_actual,
  civil_ntp.pj_p_4025_civil_ntp_submitted_to_gc_finish AS p5_civil_ntp_submitted_planned,
  civil_ntp.pj_a_4050_civil_ntp_accepted_by_gc_finish AS p5_civil_ntp_accepted_actual,
  civil_ntp.pj_p_4050_civil_ntp_accepted_by_gc_finish AS p5_civil_ntp_accepted_planned,
  tower_ntp.pj_a_4075_construction_ntp_submitted_to_gc_finish AS p5_tower_ntp_submitted_actual,
  tower_ntp.pj_p_4075_construction_ntp_submitted_to_gc_finish AS p5_tower_ntp_submitted_planned,
  tower_ntp.pj_a_4100_construction_ntp_accepted_by_gc_finish AS p5_tower_ntp_accepted_actual,
  tower_ntp.pj_p_4100_construction_ntp_accepted_by_gc_finish AS p5_tower_ntp_accepted_planned,
  ntp_ndpd.ms_1407_tower_ntp_validated_actual AS p5_tower_ntp_validated_actual,
  ntp_ndpd.ms_1507_tower_ntp_approved_actual AS p5_tower_ntp_approved_actual,

  // Phase 6
  p6.material_status AS p6_material_status,
  bom.pj_a_3850_bom_submitted_bom_in_bat_finish AS p6_bom_bat_actual,
  bom.pj_p_3850_bom_submitted_bom_in_bat_finish AS p6_bom_bat_planned,
  bom.pj_a_3875_bom_received_bom_in_aims_finish AS p6_bom_aims_actual,
  bom.pj_p_3875_bom_received_bom_in_aims_finish AS p6_bom_aims_planned,
  bom.pj_a_3900_all_bat_orders_received_finish AS p6_material_arrived_actual,
  bom.pj_p_3900_all_bat_orders_received_finish AS p6_material_arrived_planned,
  steel.pj_steel_ordered_status AS p6_steel_ordered_status,
  steel.pj_steel_received_status AS p6_steel_received_status,
  steel.pj_steel_po_number AS p6_steel_po_number,
  steel.pj_steel_ordered AS p6_steel_ordered_date,
  steel.pj_steel_received_date AS p6_steel_received_date,
  mp.pj_a_3925_msl_pickup_date_finish AS p6_material_pickup_actual,
  mp.pj_p_3925_msl_pickup_date_finish AS p6_material_pickup_planned,
  mp.ms_1461_pickup_tower_materials_and_validate_actual AS p6_material_pickup_pm,
  mp.ms_14610_gc_material_pickup_actual AS p6_material_pickup_gc,

  // Phase 7
  aav.pj_a_2075_aav_telco_site_walk_complete_finish AS p7_aav_walk_actual,
  aav.pj_p_2075_aav_telco_site_walk_complete_finish AS p7_aav_walk_planned,
  aav.pj_a_2080_aav_telco_design_complete_finish AS p7_aav_design_actual,
  aav.pj_p_2080_aav_telco_design_complete_finish AS p7_aav_design_planned,
  pwr.pj_a_4450_permanent_power_ordered_finish AS p7_power_ordered_actual,
  pwr.pj_p_4450_permanent_power_ordered_finish AS p7_power_ordered_planned,
  pwr.pj_a_4475_complete_power_walk_finish AS p7_power_walk_actual,
  pwr.pj_p_4475_complete_power_walk_finish AS p7_power_walk_planned,
  pwr.pj_a_4500_power_design_approval_finish AS p7_power_design_actual,
  pwr.pj_p_4500_power_design_approval_finish AS p7_power_design_planned,

  // Phase 8
  p8.pj_a_4200_pull_construction_po_number_finish AS p8_construction_po_actual,
  p8.pj_p_4200_pull_construction_po_number_finish AS p8_construction_po_planned,
  p8.pj_construction_pos_issued AS p8_pos_issued,
  p8.base_spo_requested_date AS p8_base_spo_requested,
  p8.ms_1551_civil_construction_complete_spo AS p8_civil_spo,
  p8.ms_1551_civil_construction_complete_spo_issued_date AS p8_civil_spo_issued_date,
  p8.ms_1551_module_spo_vendor_name AS p8_civil_module_spo_vendor,
  p8.ms1555_construction_complete_spo AS p8_tower_spo,
  p8.ms1555_construction_complete_spo_issued_date AS p8_tower_spo_issued_date,
  p8.ms_1555_module_spo_vendor_name AS p8_tower_module_spo_vendor,
  p8.ms_1970_integration_complete_spo AS p8_integration_spo,
  p8.ms_1559_cop_approved_by_t_mobile_spo AS p8_cop_spo,
  p8.ms_1559_cop_approved_by_t_mobile_spo_issued_date AS p8_cop_spo_issued_date,

  // Phase 9
  cs.pj_a_4250_civil_construction_start_finish AS p9_civil_start_actual,
  cs.pj_p_4250_civil_construction_start_finish AS p9_civil_start_planned,
  cf.pj_a_4750_civil_construction_complete_finish AS p9_civil_complete_actual,
  cf.pj_p_4750_civil_construction_complete_finish AS p9_civil_complete_planned,
  pi.pj_a_4525_power_ready_finish AS p9_power_ready_actual,
  pi.pj_p_4525_power_ready_finish AS p9_power_ready_planned,
  pi.pj_a_4550_permanent_power_installed_finish AS p9_power_installed_actual,
  pi.pj_p_4550_permanent_power_installed_finish AS p9_power_installed_planned,
  amw.pj_a_4875_aav_telco_ready_finish AS p9_aav_ready_actual,
  amw.pj_p_4875_aav_telco_ready_finish AS p9_aav_ready_planned,
  amw.pj_a_4425_mw_installation_complete_finish AS p9_mw_install_actual,
  amw.pj_p_4425_mw_installation_complete_finish AS p9_mw_install_planned,

  // Phase 10
  ts.pj_a_4225_construction_start_finish AS p10_tower_start_actual,
  ts.pj_p_4225_construction_start_finish AS p10_tower_start_planned,
  tf.pj_a_5175_construction_complete_finish AS p10_tower_complete_actual,
  tf.pj_p_5175_construction_complete_finish AS p10_tower_complete_planned,
  td.pj_construction_start_delay_code AS p10_start_delay_code,
  td.pj_construction_start_delay_comments AS p10_start_delay_comments,
  td.pj_construction_complete_delay_code AS p10_complete_delay_code,
  td.pj_construction_complete_delay_comments AS p10_complete_delay_comments,

  // Phase 11
  int_s.pj_a_5270_integration_start_finish AS p11_integration_start_actual,
  int_s.pj_p_5270_integration_start_finish AS p11_integration_start_planned,
  int_f.pj_a_5275_integration_complete_finish AS p11_integration_complete_actual,
  int_f.pj_p_5275_integration_complete_finish AS p11_integration_complete_planned,
  int_f.pj_integration_comments AS p11_integration_comments,
  int_d.ms_1564_validate_scf_files_are_available_actual AS p11_scf_validated_actual,
  int_d.ms_1899_all_planned_technologies_integrated_actual AS p11_all_techs_integrated,
  int_d.ms_1971_air_view_report_completed_actual AS p11_airview_completed,
  int_d.ms_2123_planned_e911_test_calls_actual AS p11_e911_test_calls,

  // Phase 12
  p12.ms_1970_integration_complete_actual AS p12_integration_complete_actual,
  p12.ms_1970_integration_complete_spo_issued_date AS p12_integration_spo_issued,
  rtt.pj_a_5575_gsm_rtt_finish AS p12_gsm_rtt_actual,
  onair.pj_a_5600_gsm_onair_finish AS p12_gsm_onair_actual,

  // Phase 13 - Revenue
  cr.ms_1551_civil_construction_complete_ia_date AS p13_civil_ia_date,
  cr.ms_1551_civil_construction_complete_gr_date AS p13_civil_gr_date,
  cr.ms_1551_civil_construction_complete_gr_so_number AS p13_civil_gr_so_number,
  cr.ms_1551_civil_construction_complete_invoice_date AS p13_civil_invoice_date,
  cr.ms_1551_civil_construction_complete_invoice AS p13_civil_invoice,
  cr.ms_1551_civil_construction_complete_ca_date AS p13_civil_ca_date,
  tr.ms1555_construction_complete_invoice_date AS p13_tower_invoice_date,
  tr.ms1555_construction_complete_invoice AS p13_tower_invoice,
  tr.ms1555_construction_complete_ca_date AS p13_tower_ca_date,
  tr.ms1555_construction_complete_bbr_date AS p13_tower_bbr_date,
  tr.ms1555_construction_complete_gr_date AS p13_tower_gr_date,
  tr.ms1555_construction_complete_ia_date AS p13_tower_ia_date,
  pl_rev.ms_1559_cop_approved_by_t_mobile_ia_date AS p13_cop_ia_date,
  pl_rev.ms_1559_cop_approved_by_t_mobile_gr_date AS p13_cop_gr_date,
  pl_rev.ms_1559_cop_approved_by_t_mobile_ca_date AS p13_cop_ca_date,
  pl_rev.ms_1559_cop_approved_by_t_mobile_bbr_date AS p13_cop_bbr_date,
  ir.ms_1970_integration_complete_ca_date AS p13_integration_ca_date,
  ir.ms_1970_integration_complete_bbr_date AS p13_integration_bbr_date,
  ir.ms_1970_integration_complete_so_inv_date AS p13_integration_so_inv_date,
  ir.ms_1970_integration_complete_ia_date AS p13_integration_ia_date,
  ir.ms_1970_integration_complete_gr_date AS p13_integration_gr_date,

  // HSE
  collect(DISTINCT {
    visit_num: visit.visit_num,
    check_in_status: visit.check_in_status,
    check_in_date: visit.check_in_date,
    ppe_validation: visit.ppe_validation,
    ppe_photo_available: visit.ppe_photo_available,
    jsa_completion_status: visit.jsa_completion_status,
    each_crew_ptid_l2w_status: visit.each_crew_ptid_l2w_status,
    revisit_non_compliance_category: revisit.non_compliance_category,
    revisit_escalation_l1: revisit.escalation_l1_to_gc,
    revisit_escalation_l2: revisit.esaclation_l2_to_cm,
    revisit_escalation_l3: revisit.esaclation_l3_to_pm,
    revisit_escalation_l4: revisit.escalation_l4_pd_all
  }) AS hse_visits,

  // DEC_COP
  dec.scop_title AS dec_cop_title,
  dec.approvedpercent AS dec_cop_approved_pct,
  pl_status.scop_ndpc_session_created_cw AS dec_pl_session_created,
  pl_status.scop_ndpc_session_cw_last_activity AS dec_pl_last_activity,
  pl_status.scop_ndpc_session_cw_pending_pct AS dec_civil_pending_pct,
  pl_status.scop_ndpc_session_cw_completed_pct AS dec_civil_completed_pct,
  pl_status.scop_ndpc_session_cw_approved_pct AS dec_civil_approved_pct,
  pl_status.scop_ndpc_session_cw_rejected_pct AS dec_civil_rejected_pct,
  pl_status.scop_ndpc_session_tw_pending_pct AS dec_tower_pending_pct,
  pl_status.scop_ndpc_session_tw_completed_pct AS dec_tower_completed_pct,
  pl_status.scop_ndpc_session_tw_approved_pct AS dec_tower_approved_pct,
  pl_status.scop_ndpc_session_tw_rejected_pct AS dec_tower_rejected_pct,
  pl_sub.ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl AS dec_pl_submitted_nokia,
  pl_sub.ms_1558_admin_checklist_submitted_to_t_mobile_actual AS dec_admin_checklist_submitted,
  pl_sub.ms_1553_review_civil_quality_media_checklist AS dec_civil_checklist_reviewed,
  pl_sub.pj_a_5500_receive_close_out_binder_finish AS dec_pl_received_tmobile_actual,
  pl_sub.pj_p_5500_receive_close_out_binder_finish AS dec_pl_received_tmobile_planned,
  pl_post.pj_a_5400_punch_list_to_gc_finish AS dec_pl_to_gc_actual,
  pl_post.pj_p_5400_punch_list_to_gc_finish AS dec_pl_to_gc_planned,
  pl_resub.pj_a_5425_punch_list_complete_finish AS dec_pl_resubmitted_actual,
  pl_resub.pj_p_5425_punch_list_complete_finish AS dec_pl_resubmitted_planned,
  pl_resub.scop_pending_days_for_gc_action AS dec_pl_gc_pending_days,
  pl_final.pj_a_5525_approve_close_out_binder_finish AS dec_pl_approved_tmobile_actual,
  pl_final.pj_p_5525_approve_close_out_binder_finish AS dec_pl_approved_tmobile_planned,
  pl_final.ms_1559_cop_approved_by_t_mobile_actual AS dec_cop_approved_nokia,
  pl_final.scop_checklist_accepted_by_customer AS dec_checklist_accepted,
  pl_final.pj_p_5540_financial_closeout_finish AS dec_financial_closeout_planned,
  pl_final.magenta_ms_5525_actual AS dec_pl_complete_nokia
"""


async def get_project_milestones(project_id: str) -> Optional[dict]:
    """
    Fetch all milestones across all phases (1-13), HSE, and DEC_COP
    for a given project_id (Macro / NTM schema).

    Args:
        project_id: The unique project identifier (e.g., 'SMP-WO-1296358')

    Returns:
        A serialized dict of all milestone fields, or None if project not found.
    """
    driver = get_neo4j_driver()

    async with driver.session() as session:
        result = await session.run(PROJECT_MILESTONES_CYPHER, project_id=project_id)
        record = await result.single()

    if record is None:
        return None

    return serialize_neo4j_value(record.data())