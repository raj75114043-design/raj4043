import logging
logger = logging.getLogger(__name__)

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

from app.services.text2cypher.macro.phasewise_prompt import PHASE_SCHEMA_DESCRIPTIONS_MACRO
from app.services.text2cypher.macro.llm_client import LLM_MEDIUM


# ── Helpers ────────────────────────────────────────────────────────────────────

def _concatenate_schema() -> str:
    def sort_key(k):
        try:
            return (0, int(k), "")
        except (ValueError, TypeError):
            return (1, 0, str(k))

    return "\n\n".join(
        PHASE_SCHEMA_DESCRIPTIONS_MACRO[k]
        for k in sorted(PHASE_SCHEMA_DESCRIPTIONS_MACRO.keys(), key=sort_key)
    )

# Build once at module load — schema is static
FULL_SCHEMA = _concatenate_schema()

# LangChain ChatPromptTemplate
EXTRACTION_PROMPT = ChatPromptTemplate.from_messages([
    (
        "system",
        """You are an expert Neo4j graph schema analyst for the MACRO telecom project.
Below is the complete graph schema describing all nodes, relationships, and properties:

=== FULL SCHEMA ===
{full_schema}
===================

TASK:
Analyze the user query and identify ONLY the nodes, relationships, and properties relevant to answering it.

OUTPUT FORMAT (strictly this, no prose):

1. Relationships (one per line):
(NodeLabel)-[:RELATIONSHIP_TYPE]->(NodeLabel)

2. Nodes with relevant properties (one per line):
(NodeLabel {{property1: type, property2: type}})

3. Relationships with properties if applicable (one per line):
(NodeLabel {{prop: type}})-[:REL_TYPE {{prop: type}}]->(NodeLabel {{prop: type}})

RULES:
- Only include nodes and relationships directly needed to answer the query.
- Include specific properties used for filtering, returning, or joining.
- Do NOT include unrelated phases or nodes.
- Do NOT add explanations — output only schema lines.""",
    ),
    ("human", "{query}"),
])

# Chain: prompt | llm | parse to string
extraction_chain = EXTRACTION_PROMPT | LLM_MEDIUM | StrOutputParser()

def extract_relevant_schema_macro(query: str) -> str:
    logger.info(f"Extracting schema for query: {query}")
    return extraction_chain.invoke({
        "full_schema": FULL_SCHEMA,
        "query": query,
    })