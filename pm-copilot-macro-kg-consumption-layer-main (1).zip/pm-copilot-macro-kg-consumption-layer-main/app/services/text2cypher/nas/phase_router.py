from langchain_core.prompts import ChatPromptTemplate
from typing import List
from app.services.text2cypher.ahloa.llm_client import LLM_MEDIUM
from app.schemas.text2cypher.schemas import PhaseRouterOutput

llm = LLM_MEDIUM

# Bind structured output directly to the LLM
structured_llm = llm.with_structured_output(PhaseRouterOutput)

ROUTER_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """
You are a telecom knowledge graph query router.

Your task is to analyze the user's question and determine which domain phases
of the telecom operational knowledge graph are required to answer it.

You must return ONLY the relevant phase numbers as a list of integers between 1 and 5.
If the query spans the entire operational lifecycle, return all phases [1,2,3,4,5].
Do NOT explain your reasoning.

-----------------------------------
KG DOMAIN PHASE DEFINITIONS (MAX 5)
-----------------------------------

Phase 1 – e911 Readiness & Validation
This phase covers all topics related to E911 readiness and validation including:
- e911 validation status (READY, INTP, NOT READY)
- PSAP details, validation dates, validation reasons
- Layer-level RIOT vs RFCIQ checks
- Existing vs proposed layers
- Engineer remarks and action items
- e911 visit sequencing and readiness trends

Relevant KG entities include:
Site_e911, READY, INTP, NOT_READY, e911

-----------------------------------

Phase 2 – Planned Outages & Activities
This phase includes all planned outage and activity planning information such as:
- Planned outage activities (Outage-1, Outage-2, etc.)
- Activity approval status (Approved, Pending, Rejected)
- Activity timelines, vendors, work orders
- Activity sequencing and nesting type (SI / NSI)

Relevant KG entities include:
Site_Planned_Activity, Planned_Activity,
PA_Approved, PA_Pending, PA_Rejected

-----------------------------------

Phase 3 – Sessions (NEST / Field Execution)
This phase covers execution-level session data including:
- Field sessions and session sequencing
- Check-in, check-out, extensions, and rejections
- NEST status, SLA times, approvals
- Session-level work orders, vendors, and users

Relevant KG entities include:
Site_Session, Session,
Session_Check_In, Session_Check_Out,
Session_Extension, Session_Rejection

-----------------------------------

Phase 4 – Integration & Call Testing
This phase represents network integration and readiness after execution:
- Site integration milestones
- Call test completion and status (GREEN / RED / PARTIAL)
- GO email responsibilities
- Existing and proposed radio layers
- Integration remarks and issues

Relevant KG entities include:
Site_Integration, Site_Call_Test,
Site_GO_Email, Site_layers

-----------------------------------

Phase 5 – RF010 Milestones
This phase includes RF010 and microwave-related milestones:
- RF010 task sequencing
- MB status and completion tracking
- HOP validation
- RF010 completion dates and order

Relevant KG entities include:
Site_RF010, RF010,
RF010_MB, RF010_Completion, RF010_HOP

-----------------------------------

You must return ONLY a list of phase numbers.
Phases are integers between 1 and 5.
"""),
    ("human", "{query}")
])

router_chain = ROUTER_PROMPT | structured_llm

def phase_router_func(query: str) -> PhaseRouterOutput:
    """
    Routes a user query to relevant telecom deployment phases and modules.

    Args:
        query (str): User question related to telecom deployment project.

    Returns:
        PhaseRouterOutput: Structured object containing:
            - phases (List[int])
            - modules (List[str])
    """
    response = router_chain.invoke({"query": query})

    return response

## Router Adapter
def route_phases_and_modules_nas(question: str) -> tuple[List[int], List[str]]:
    """
    Thin adapter, so we can mock in tests and keep boundaries clean.
    """
    res: PhaseRouterOutput = phase_router_func(question)
    return res.phases, res.modules