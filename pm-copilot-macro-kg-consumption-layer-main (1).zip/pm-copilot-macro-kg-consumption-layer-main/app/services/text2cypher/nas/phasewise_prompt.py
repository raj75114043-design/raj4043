PHASE_SCHEMA_DESCRIPTIONS_NAS = {

0: """
=== BASE NODE: Site (Global Context) ===

The Site node is the authoritative root for the entire graph.
ALL queries MUST anchor from Site.

--- CORE NODE ---

Site
- nas_site_id | STRING | Site primary identifier
- name        | STRING | Always 'Site'
- nas_market  | STRING | Market name

--- BASE QUERY RULE ---

Every query MUST start from:
(Site)
""",

1: """
=== PHASE 1: e911 Readiness & Validation ===

Captures emergency (e911) readiness classification, validation history,
PSAP details, and RIOT vs RFCIQ layer comparisons.
Everytime a site engineer visits a site to test for e911, either he/she can mark the site
as READY, INTP and NOT_READY. These nodes are just to classify the e911 visits.
These nodes do not contain any real property. 

--- CORE NODES ---

1. Site_e911
- nas_site_id | STRING
(This is just a representative node that indicates a site contains multiple e911 instances)

2. READY
- nas_site_id | STRING
(This is just a representative node that connects to all ready e911 instances)

3. INTP
- nas_site_id | STRING
(This is just a representative node that connects to all intp e911 instances)

4. NOT_READY
- nas_site_id | STRING
(This is just a representative node that connects to all not ready e911 instances)

5. e911
- id                                 | LONG            | A Unique ID assigned to every e911 instance    
- nas_site_id                        | STRING          | nas_site_id
- nas_validate_e911_readiness        | STRING          | Possible options are - LTE TAC mismatch; Not Ready LTE TAC Mismacth; Not Ready - All Layers GMLC, eSMLC RED/ N25 C2 Not provisioned in RIOT; NOT READY; Not Ready(N1900 C2 Not Configured in RIOT); RFCIQ NA; Not ready(No CIQ File in Tool); LTE TAC Mismatch; Not Ready NR TAC Mismatch; Not Ready -RF CIQ NA; Not Ready L600 Confirmation required; OLD RFCIQ is available; LTE TAC MISMATCH, IN RFCIQ 41602, IN RIOT 41490; On Hold /GSM Confirmation PendingNot Ready; Not Checking; Not Ready - L600 NA RFDS & Design Comments,But Available in RFCIQ , RIOT( OFF-AIR); Not Ready (NR Existing layer RIOT RED); Not Ready - LTE TAC Mismatch; Not Ready NR TAC Mismacth; GMLC.eSMLC RED NOT READY; Non Ready; RF CIQ Not Available Yet; Not Ready - All Layers GMLC, eSMLC RED; Not Ready (GMLC & ESMLC RED for all layers); RFCIQ not available; Not Ready - RFCIQ NA, All Layers GMLC, eSMLC RED; Not Ready (NR TAC Mismatch); CIQ NA; L2100 C1, N600 CELL NAME MISMATCH; Not Ready LTE TAC Mismatch; Pending RIOT GREEN; Ready_Completed; Not READY; Not Ready - L600 NA in RFDS & Design Comments, But Available in RF CIQ; Ready; Not Ready- All Layers GMLC, eSMLC RED and NR TAC Mismatch; L1900 CELL NAME MISMATCH, As per RFDS L1900 AND GSM Is proposed, AS Per micheal mail the both layer are existing and RIOT also green; L600 not availble in RF CIQ; Not Ready- N2100 GMLC, eSMLC RED; L700 not availble in RF CIQ; Not Ready - N600 C2 Design commands available & RFCIQ Not Available; Already GREEN Mail Shared; Not Ready Layer Confirmation required; Not Ready - L600 NA RFDS & Design Comment; Not ready; proposed layers not configured; RF CIQ HAS OLD FILE(2022); READY; Not Ready(LTE TAC Mismatch); Not Ready- All layers GMLC, eSMLC RED; CIQ Validation status; Not Ready- ALL LAYERS GMLC, eSMLC RED; RFCIQ NOT AVAILABLE; CIQ NOT AVAILABLE; LTE TAC MISMATCH, IN RFCIQ 41603, IN RIOT 41498; GMLC, eSMLC RED NOT READY; Not Ready - RFCIQ NA; READY_Completed; Not Ready- All Layers GMLC, eSMLC RED & L1900 NA in CIQ; Not Ready (GMLC & ESMLC RED for all layers) & NR TAC Mismatch; RF CIQ NA; NOT Ready(NR TAC MISMATCH); Not Ready (CIQ NA); Not Ready- All Layers GMLC, eSMLC RED; TAC Consolidation, LBR mandatory Before IX; Not Ready; RF CIQ NOT AVAILABLE; Not Ready - N2100 NA in CIQ; Not Ready & LTE TAC Mismatch; Not Ready L700 Not Provision in RIOT; Not Ready LTE TAC Mismatch; NOT Ready(LTE TAC MISMATCH); Not Ready - All Layers GMLC, eSMLC RED & LTE TAC Mismatch; Not Ready (LTE & NR TAC Mismatch); CIQ File not found; NOT Ready 
- nas_e911_validation_date           | DATE            | The e911 instance completion date
- nas_e911_validation_reason         | STRING / DOUBLE | Detailed reason mentioned
- nas_psap_id                        | STRING / DOUBLE | PSAP ID
- nas_psap_name                      | STRING / DOUBLE | PSAP Name
- nas_existing_layers                | STRING / DOUBLE | Existing layers detail
- nas_proposed_layers                | STRING / DOUBLE | New/proposed layers detail
- nas_consolidation_check_all_layers | STRING          | 
- nas_engineer                       | STRING / DOUBLE | Engineer Name
- nas_remarks                        | STRING / DOUBLE | Remarks mentioned by engineer
- e911_visit                         | LONG            | e911 visit number on Site
- create_date                        | LOCAL_DATE_TIME | Date when the entry was created in data
- write_date                         | LOCAL_DATE_TIME | Date when the entry was written in data
(This is the main node that represents an e911 visit details made by an engineer on the site)

--- RELATIONSHIPS ---

(Site)-[:SITE_E911]->(Site_e911)

(Site_e911)-[:E911_READY]->(READY)-[:READY_E911]->(e911)
(Site_e911)-[:E911_INTP]->(INTP)-[:INTP_E911]->(e911)
(Site_e911)-[:E911_NOT_READY]->(NOT_READY)-[:NOT_READY_E911]->(e911)
""",

2: """
=== PHASE 2: Planned Outages & Activities ===

Models planned activities including approval flows,
vendors, work orders, and outage timelines.

--- CORE NODES ---

1. Site_Planned_Activity
- nas_site_id | STRING

PA_Approved
- nas_site_id | STRING
- name        | STRING | 'Approved'

PA_Pending
- nas_site_id | STRING
- name        | STRING | 'Pending'

PA_Rejected
- nas_site_id | STRING
- name        | STRING | 'Rejected'

Planned_Activity
- activity_id              | LONG
- nas_site_id              | STRING
- nas_status               | STRING
- nas_activity_details     | STRING | DOUBLE
- nas_activity_start_date  | LOCAL_DATE_TIME
- nas_activity_end_date    | LOCAL_DATE_TIME
- nas_request_time         | LOCAL_DATE_TIME
- nas_workorder_id         | STRING
- nas_company_name         | STRING
- nas_nest_type            | STRING
- activity_order           | LONG
- create_date              | LOCAL_DATE_TIME
- write_date               | LOCAL_DATE_TIME

--- RELATIONSHIPS ---

(Site)-[:HAS_PLANNED_ACTIVITIES]->(Site_Planned_Activity)

(Site_Planned_Activity)-[:HAS_APPROVED_ACTIVITIES]->(PA_Approved)
(Site_Planned_Activity)-[:HAS_PENDING_ACTIVITIES]->(PA_Pending)
(Site_Planned_Activity)-[:HAS_REJECTED_ACTIVITIES]->(PA_Rejected)

(PA_Approved)-[:HAS_APPROVED_ACTIVITY]->(Planned_Activity)
(PA_Pending)-[:HAS_PENDING_ACTIVITY]->(Planned_Activity)
(PA_Rejected)-[:HAS_REJECTED_ACTIVITY]->(Planned_Activity)
""",

3: """
=== PHASE 3: Sessions (NEST / Field Execution) ===

Captures field execution sessions including
check-in, check-out, extensions, and rejections.

--- CORE NODES ---

Site_Session
- nas_site_id | STRING
- name        | STRING | 'Session'

Session
- session_id                      | LONG
- nas_site_id                     | STRING
- name                            | STRING
- nas_activity_type               | STRING | DOUBLE
- nas_company_name                | STRING
- nas_contact_person              | STRING
- nas_user_id                     | STRING
- nas_workorder_id                | STRING
- nas_nest_type                   | STRING
- nas_status_nest_active          | STRING
- nas_last_event                  | STRING
- nas_nest_start_time             | LOCAL_DATE_TIME
- nas_nest_start_time_requested   | LOCAL_DATE_TIME
- nas_checkout_time               | LOCAL_DATE_TIME
- nas_checkout_approve_time       | LOCAL_DATE_TIME
- nas_total_activity_duration     | STRING | DOUBLE
- session_order                   | LONG

Session_Check_In
- session_id | LONG
- name       | STRING | 'Check-In'
- check_in   | STRING

Session_Check_Out
- session_id | LONG
- name       | STRING | 'Check-Out'
- check_out  | STRING

Session_Extension
- session_id | LONG
- name       | STRING | 'Extension'
- extension  | STRING

Session_Rejection
- session_id        | LONG
- name              | STRING | 'Rejection'
- rejection_reason  | STRING
- rejection_notes   | STRING | DOUBLE

--- RELATIONSHIPS ---

(Site)-[:HAS_SESSIONS]->(Site_Session)
(Site_Session)-[:HAS_SESSION]->(Session)

(Session)-[:HAS_CHECK_IN]->(Session_Check_In)
(Session)-[:HAS_CHECK_OUT]->(Session_Check_Out)
(Session)-[:HAS_EXTENSION]->(Session_Extension)
(Session)-[:HAS_REJECTION]->(Session_Rejection)
""",

4: """
=== PHASE 4: Integration & Call Testing ===

Models integration readiness, call testing,
GO email responsibilities, and layer configuration.

--- CORE NODES ---

Site_Integration
- nas_site_id          | STRING
- name                 | STRING | 'Integration'
- nas_integration_date | DATE
- nas_remarks          | STRING | DOUBLE

Site_Call_Test
- nas_site_id                     | STRING
- nas_call_test_completed_date    | DATE
- nas_call_test_completion_status | STRING | DOUBLE
- nas_remarks                     | STRING | DOUBLE

Site_GO_Email
- nas_site_id
- nas_go_email_responsibility                    | STRING | DOUBLE
- nas_completion_partial_email_responsibility   | STRING | DOUBLE

Site_layers
- nas_site_id
- nas_existing_layer | STRING | DOUBLE
- nas_proposed_layer | STRING | DOUBLE

--- RELATIONSHIPS ---

(Site)-[:HAS_Integration]->(Site_Integration)
(Site_Integration)-[:HAS_Call_Test]->(Site_Call_Test)
(Site_Integration)-[:HAS_GO_Email]->(Site_GO_Email)
(Site_Integration)-[:HAS_Layers]->(Site_layers)
""",

5: """
=== PHASE 5: RF010 Milestones ===

Captures RF010 sequencing, MB status,
completion tracking, and HOP validation.

--- CORE NODES ---

Site_RF010
- nas_site_id | STRING
- name        | STRING | 'Site_RF010'

RF010
- rf010_id    | LONG
- nas_site_id | STRING
- name        | STRING
- rf010_order | LONG

RF010_MB
- rf010_id | LONG
- name     | STRING | 'MB'
- mb_status| STRING

RF010_Completion
- rf010_id               | LONG
- name                   | STRING | 'Completion'
- task_completed_datetime| LOCAL_DATE_TIME

RF010_HOP
- rf010_id              | LONG
- name                  | STRING | 'HOP'
- hop_validation_status | STRING

--- RELATIONSHIPS ---

(Site)-[:HAS_RF010s]->(Site_RF010)
(Site_RF010)-[:HAS_RF010]->(RF010)

(RF010)-[:HAS_MB]->(RF010_MB)
(RF010)-[:HAS_Completion]->(RF010_Completion)
(RF010)-[:HAS_HOP]->(RF010_HOP)
"""
}