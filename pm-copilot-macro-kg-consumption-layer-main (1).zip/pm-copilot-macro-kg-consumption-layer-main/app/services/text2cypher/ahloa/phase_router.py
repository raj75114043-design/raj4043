from langchain_core.prompts import ChatPromptTemplate
from typing import List
from app.services.text2cypher.ahloa.llm_client import LLM_MEDIUM
from app.schemas.text2cypher.schemas import PhaseRouterOutput

llm = LLM_MEDIUM

# Bind structured output directly to the LLM
structured_llm = llm.with_structured_output(PhaseRouterOutput)

ROUTER_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """

You are a telecom deployment project knowledge router.

Your task is to analyze the user's question and determine which telecom project phases
are relevant for answering the query.

You must return ONLY the relevant phase numbers as a list of integers between 1 and 11.
If the query relates to the whole project lifecycle, return all phases [1,2,3,4,5,6,7,8,9,10,11].
Do NOT explain your reasoning.
 
-----------------------------------
TELECOM PROJECT PHASE DEFINITIONS
-----------------------------------

Phase 1 – Project / Site Assignment
In this phase T-Mobile(TMO) assigns project to Nokia. Nokia is the Hard cost (HC) vendor for TMO.
This phase additionally has:
Project details like Build Plan Year, Entitlement Complete Year, Project type (M-Modification General only) and a unique Por ID. 
Hard cost, soft cost and Vendor(GC or General Contractor) assignment details like comments, dates etc.
A unique smp_id for every project and some more smp_details like smp_name (AHLOB Modernization only).


Phase 2 – Pre-Construction
In this phase TMO provides a Pre-NTP(Precon) document to Nokia.
This document includes all the planned dates for activities / milestones decided by TMobile for the site like - 
CD (Construction Drawing), RFDS, BOM (Bill of Materials), SA (Structural Analysis) and MA (Mount Analysis)
In this phase TMobile also provides Entitlement Completion (EC) to Nokia and Talon view survey details.

Phase 3 – Scoping
This phase contains survey / site-walk completion milestone

Phase 4 – Quoting
In Phase 4, TMobile recieves the Scoping Package from Nokia as an 'E-quote'.
TMobiles reviews and approves it.

Phase 5 – NTP & Material
In Phase 5, TMobile provides the Notice to Proceed (NTP) to Nokia for Tower Work (Radio Swap/Upgrade Activity).
     
Phase 6 - Material
List of Materials required is finalized, and the Bill of Materials (BOM) is uploaded to the 
TMobile tools - AIMs and BAT. As TMobile approves the BOM, materials arrive in the warehouse. 
Vendor collects / picks-up the materials from the warehouse. 
Steel required in the project is finalized in this phase too. Steel details include 
po number, steel recieved status etc.
 
Phase 7 – Tower Work Readiness (SWAP Readiness or Cx Readiness or Construction Readiness)
This phase includes all the POs (SPO and CPO i.e Supplier PO and Customer PO). These POs together are the Pre-requisites for Tower (SWAP) work.

Phase 8 – Tower Work (SWAP Work or Radio SWAP or Equipment Upgrade)
This phase includes the tower work (swap) start and finish dates, delays and comments.

Phase 9 – Network Integration
This phase manages the integration of telecom network equipment into the operational network.
This includes integration start and complete milestones, and integration comments. 

Phase 10 – Post-Integration
This phase has integration completion milestones. It also includs 72 hours monitoring milestone and 
old ahloa equipement disposal or return status.
     
Phase 11 Revenue
This phase contains revenue and finance milestones (CA, IA, GR, BBR, SO etc) 
from different 3 phases of the project - Tower (swap), Integration and DEC_COP.
     
You must return ONLY the relevant phase numbers AND any additional modules.

Phases are integers between 1 and 11.
Modules are strings — valid values are: 'HSE', 'DEC_COP'

- Return 'HSE' if the query relates to crew visits, safety compliance, PPE, JSA, and check-ins.
- Return 'DEC_COP' if the query relates to close-out packages, COP or SCOP, DEC, and punch lists.
     
"""),
    ("human", "{query}")
])

router_chain = ROUTER_PROMPT | structured_llm

def phase_router_func(query: str) -> PhaseRouterOutput:
    """
    Routes a user query to relevant telecom deployment phases and modules.

    Args:
        query (str): User question related to telecom deployment project.

    Returns:
        PhaseRouterOutput: Structured object containing:
            - phases (List[int])
            - modules (List[str])
    """
    response = router_chain.invoke({"query": query})

    return response

## Router Adapter
def route_phases_and_modules_ahloa(question: str) -> tuple[List[int], List[str]]:
    """
    Thin adapter, so we can mock in tests and keep boundaries clean.
    """
    res: PhaseRouterOutput = phase_router_func(question)
    return res.phases, res.modules