PHASE_SCHEMA_DESCRIPTIONS_AHLOA = {
0: """
=== BASE NODES: Core Entities ===

Foundational Nodes - TMobile, Nokia, Site, Vendor and SC Vendor.
TMobile assigns Site (as a project) to Nokia. Vendor works on this Site.
All Market, Area, Region and State filters are from Site node only.
All projects are AHLOA, hence no filters needed.
These nodes have 2 type of properties
1. Magenta (T-Mobile database properties) - Starts with 'pj'.
Note: 'pj_a' is for actual date and 'pj_p' for planned date.  
2. NDPD (Nokia database properties) - Starts with 'ms'.

--- NODES ---

1. TMobile
   
2. Nokia
   
3. Site
   - s_site_id                          | STRING | Unique site identifier; primary key (e.g., '9NV0517R')
   - s_site_name                        | STRING | Human-readable site name (e.g., 'Nolensville II')
   - s_state                            | STRING | State abbreviation ("OR", "ND", "OH", "KY", "IN", "WV", "NE", "MO", "AR", "WI", "SD", "OK", "ID", "MN", "PA", "WY", "MT", "IL", "TN", "MI", "WA", "UT", "IA", "CO", "VA", "AZ" and "KS" only) **Key for state filter**
   - region                             | STRING | Nokia region ("WEST" and "CENTRAL" only) **Key for region filter**
   - m_area                             | STRING | Market area grouping ("Great Lakes", "Appalachian", "Desert West", "North West", "Midwest Rockies" and "Heartland" only) **Key for area filter**
   - m_market                           | STRING | Specific market ("WICHITA KS", "NASHVILLE", "DETROIT MI", "DAKOTAS", "DES MOINES IA", "INDIANAPOLIS IN", "COLUMBUS", "LOUISVILLE", "MILWAUKEE", "MONTANA", "WEST VIRGINIA", "MINNEAPOLIS MN", "DENVER CO", "SPOKANE WA", "TULSA OK", "KANSAS CITY KS", "ARKANSAS", "CINCINNATI", "KNOXVILLE TN", "PORTLAND OR", "CLEVELAND", "PHOENIX", "OMAHA", "CHICAGO", "ST. LOUIS", "SEATTLE WA", "OKLAHOMA CITY OK" and "PITTSBURGH PA" only) **Key for market filter**
  
4. Vendor
   - construction_gc        | STRING | General contractor (Vendor) company name; primary key
   
--- RELATIONSHIPS ---

(Site)<-[:GETS_SITE]-(Nokia)
(Site)<-[:ASSIGNS_SITE]-(TMobile)
(Site)<-[:WORKS_ON]-(Vendor)

--- ALL PHASE RELATIONS ---

(Site)-[:SITE_TO_P1]->(Phase1_ProjectAssignment)
(Site)-[:SITE_TO_P2]->(Phase2_PreConstruction)
(Site)-[:SITE_TO_P3]->(Phase3_Scoping)
(Site)-[:SITE_TO_P4]->(Phase4_Quoting)
(Site)-[:SITE_TO_P5]->(Phase5_NTP)
(Site)-[:SITE_TO_P6]->(Phase6_Material)
(Site)-[:SITE_TO_P7]->(Phase7_Tower_Readiness)
(Site)-[:SITE_TO_P8]->(Phase8_Tower_Work)
(Site)-[:SITE_TO_P9]->(Phase9_Integration)
(Site)-[:SITE_TO_P10]->(Phase10_Post_Integration)
(Site)-[:SITE_TO_P11]->(Phase11_Revenue)

""",

1: """
=== PHASE 1: Project Initialization and Setup ===

Project details like Build Plan Year, Project type (M-Modification General only) and a unique Por ID. 
Hard cost, soft cost and Vendor(GC or General Contractor) assignment details like comments, dates etc.
A unique smp_id for every project. And some more smp_details like smp_name (AHLOB Modernization always),
This phase also contains any drone (talonview) survey activity details.

--- NODES ---

1. Phase1_ProjectAssignment
   - pj_project_id   | STRING | Unique project identifier; primary key
   - s_site_id       | STRING | Site ID the project is assigned to
   - assigned_status | STRING | 'Assigned' / 'Not Assigned' only

2. SMP_ID_Creation
   - pj_project_id | STRING | Primary key
   - smp_id        | STRING | SMP WO ID (e.g., 'SMP-WO-1296358'), it is a unique project identifier just like pj_project_id
   - smp_name      | STRING | SMP program name (AHLOB Modernization only)
   - smp_status    | STRING | SMP status ('Active' and 'Cancelled' only)

3. Phase1_Details
   - pj_project_id                 | STRING | Primary key
   - pj_project_type               | STRING | Project type ('M-Modification General' only)
   - por_por_id                    | STRING | POR reference ID

4. Hard_cost_vendor_assignment
   - pj_project_id                     | STRING          | Primary key
   - pj_hard_cost_vendor_assignment_po | STRING          | HC Vendor Name
   - pj_hard_cost_approval_date        | LOCAL_DATE_TIME | HC approval date
   - assigned_status                   | STRING          | 'Assigned' / 'Not Assigned' only

5. Soft_cost_vendor_assignment
   - pj_project_id                        | STRING          | Primary key
   - pj_soft_cost_vendor                  | STRING          | Soft cost vendor Name
   - pj_soft_cost_approval_date           | LOCAL_DATE_TIME | Soft cost approval date
   - assigned_status                      | STRING          | 'Assigned' / 'Not Assigned' only

6. Vendor_assignment
   - pj_project_id                | STRING          | Primary key
   - construction_gc              | STRING/FLOAT    | Assigned GC
   - assigned_status              | STRING          | 'Assigned' / 'Not Assigned'
   - pj_a_3775_gc_selected_finish | LOCAL_DATE_TIME | Vendor (GC) assignment date in TMobile DB
   - pj_p_3775_gc_selected_finish | LOCAL_DATE_TIME | <Planned>

7. Drone
   - pj_project_id                           | STRING          | Primary key
   - ms_1321_talon_view_drone_svcs_actual    | LOCAL_DATE_TIME | Drone work Assigned Date. Use this key to filter all sites with Drone activities. 

   
--- ADDITIONAL RELATIONSHIPS (ALL start at Site) ---

(Phase1_ProjectAssignment)-[:HAS_DETAILS]->(Phase1_Details)
(Phase1_ProjectAssignment)-[:HAS_SUBPHASE]->(SMP_ID_Creation)
(Phase1_ProjectAssignment)-[:HAS_SUBPHASE]->(Hard_cost_vendor_assignment)
(Phase1_ProjectAssignment)-[:HAS_SUBPHASE]->(Soft_cost_vendor_assignment)
(Phase1_ProjectAssignment)-[:HAS_SUBPHASE]->(Vendor_assignment)
(Phase1_ProjectAssignment)-[:PROJECT_NEEDS_DRONE]->(Drone)
""",

2: """
=== PHASE 2: Pre-Construction Planning and Validation ===

In Phase 2, In this phase TMobile provides a Precon / Pre - NTP document to Nokia.
This document includes all the planned dates for activities / milestones decided by TMobile for the site like - 
CD (Construction Drawing), RFDS, BOM (Bill of Materials), SA (Structural Analysis) and MA (Mount Analysis)
In this phase TMobile also provides Entitlement Completion (EC) to Nokia and Talon view survey details.

--- NODES ---

1. Phase2_PreConstruction
   - pj_project_id | STRING | Primary key
   - precon_status | STRING | 'Validated' / 'Pending Validation' / 'Not Yet Submitted'

2. Talon_View
   - pj_project_id                                             | STRING           | Primary key
   - pj_a_1010_talonview_pre_con_site_survey_ordered_finish    | LOCAL_DATE_TIME  | Talonview site survey order date
   - pj_a_1015_talonview_pre_con_site_survey_approved_finish   | LOCAL_DATE_TIME  | Talonview site survey approve date
   - pj_p_1010_talonview_pre_con_site_survey_ordered_finish    | LOCAL_DATE_TIME  | <Planned>
   - pj_p_1015_talonview_pre_con_site_survey_approved_finish   | LOCAL_DATE_TIME  | <Planned>
   
3. Entitlement_Complete
   - pj_project_id                             | STRING           | Primary key
   - pj_a_3710_ran_entitlement_complete_finish | LOCAL_DATE_TIME  | Actual RAN entitlement completion
   - pj_a_3725_all_entitlement_complete_finish | LOCAL_DATE_TIME  | Actual all entitlements completion
   - pj_p_3710_ran_entitlement_complete_finish | LOCAL_DATE_TIME  | <Planned>
   - pj_p_3725_all_entitlement_complete_finish | LOCAL_DATE_TIME  | <Planned>

4. Precon_Milestones
   - pj_project_id                                            | STRING           | Primary key
   - pj_a_3800_pre_ntp_issued_finish                          | LOCAL_DATE_TIME  | Pre-NTP / Pre-con issued date in TMobile DB
   - pj_p_3800_pre_ntp_issued_finish                          | LOCAL_DATE_TIME  | <Planned>
   - pj_a_2225_construction_drawings_received_finish          | LOCAL_DATE_TIME  | CDs recieved date
   - pj_a_2250_construction_drawings_redlines_compiled_finish | LOCAL_DATE_TIME  | Corrections in CDs
   - pj_a_2275_final_construction_drawings_approved_finish    | LOCAL_DATE_TIME  | Final updated CDs (Under Precon Validation)
   - pj_p_2225_construction_drawings_received_finish          | LOCAL_DATE_TIME  | <Planned>
   - pj_p_2250_construction_drawings_redlines_compiled_finish | LOCAL_DATE_TIME  | <Planned>
   - pj_p_2275_final_construction_drawings_approved_finish    | LOCAL_DATE_TIME  | <Planned>

--- ADDITIONAL PHASE2 RELATIONSHIPS  ---

(Phase2_PreConstruction)-[:HAS_SUBPHASE]->(Precon_Validation)
(Phase2_PreConstruction)-[:HAS_SUBPHASE]->(Entitlement_Complete)
(Phase2_PreConstruction)-[:HAS_MILESTONES]->(Precon_Milestones)
""",

3: """
=== PHASE 3: Scoping and Site Assessment ===

Phase 3 defines the real scope of work required for project. 
After the precon/pre-ntp, Nokia team assigns pre-construction site walks/surveys. Additional 
scope of work (apart from the one mentioned in precon) is identified during these surveys 
and is compiled into a scoping package.

--- NODES ---

1. Phase3_Scoping
   - pj_project_id  | STRING | Primary key
   - scoping_status | STRING | 'Site Walk Not Assigned' / 'Site Walk/Survey Ongoing' / 'SP Created and Validated'

2. Phase3_Details
   - pj_project_id                                    | STRING           | Primary key
   - pj_a_3825_pre_construction_walk_complete_finish  | LOCAL_DATE_TIME  | Drone / Manual Survey Complete Date (Main milestone)
   - pj_p_3825_pre_construction_walk_complete_finish  | LOCAL_DATE_TIME  | <Planned>

--- ADDITIONAL PHASE3 RELATIONSHIPS ---

(Phase3_Scoping)-[:HAS_DETAILS]->(Phase3_Details)
""",

4: """
=== PHASE 4: Vendor Quoting and Customer Approval ===

In Phase 4, TMobile recieves the Scoping Package from Nokia as an 'E-quote'.
TMobiles reviews and approves it.

--- NODES ---

1. Phase4_Quoting
   - pj_project_id                            | STRING           | Primary key
   - quoting_status                           | STRING           | 'Not Started' / 'Bid Walk Complete' / 'Submitted to Customer' / 'Approved by Customer'
   - pj_a_3815_bid_walk_complete_finish       | LOCAL_DATE_TIME  | SP (e-quote) recieved by TMobile in TMobile DB
   - pj_p_3815_bid_walk_complete_finish       | LOCAL_DATE_TIME  | <Planned>
   - pj_bid_walk_complete_3815_doc            | STRING           | Name given to the E-quote
   - pj_bid_walk_complete_optional_status     | STRING           | 'In Review' or 'Approved'
""",

5: """
=== PHASE 5: NTP ===

In Phase 5, TMobile provides the Notice to Proceed (NTP) to Nokia for Tower Work 
(Radio Swap/Upgrade Activity).

--- NODES ---

1. Phase5_NTP
   - pj_project_id                                    | STRING           | Primary key
   - pj_p_4075_construction_ntp_submitted_to_gc_finish| LOCAL_DATE_TIME  | <Planned>
   - pj_a_4075_construction_ntp_submitted_to_gc_finish| LOCAL_DATE_TIME  | Tower work (swap) NTP Submitted to Vendor (GC)
   - pj_p_4100_construction_ntp_accepted_by_gc_finish | LOCAL_DATE_TIME  | <Planned>
   - pj_a_4100_construction_ntp_accepted_by_gc_finish | LOCAL_DATE_TIME  | Tower work (swap) NTP Accepted by Vendor (GC)
   - ms_1407_tower_ntp_validated_actual               | LOCAL_DATE_TIME  | Tower work (swap) NTP validated by Nokia
   - ms_1507_tower_ntp_approved_actual                | LOCAL_DATE_TIME  | Tower work (swap) NTP approved by Nokia
""",

6: """
=== PHASE 6: Material Procurement ===

List of Materials required is finalized, and the Bill of Materials (BOM) is uploaded to the 
TMobile tool. As TMobile approves the BOM, materials arrive in the warehouse. 
Vendor collects the materials from the warehouse. 
Steel required in the project is finalized in this phase too. Steel details include 
po number, steel recieved status etc.

--- NODES ---

1. Phase6_Material
   - pj_project_id   | STRING | Primary key
   - material_status | STRING | 'Material Pickup Complete' / 'BAT Uploaded' / 'AIMS Uploaded' / 'Pending'

2. BOM_Submission
   - pj_project_id                             | STRING           | Primary key
   - pj_p_3850_bom_submitted_bom_in_bat_finish | LOCAL_DATE_TIME  | <Planned>
   - pj_a_3850_bom_submitted_bom_in_bat_finish | LOCAL_DATE_TIME  | BOM uploaded to BAT tool (TMobile tool)
   - pj_p_3875_bom_received_bom_in_aims_finish | LOCAL_DATE_TIME  | <Planned>
   - pj_a_3875_bom_received_bom_in_aims_finish | LOCAL_DATE_TIME  | BOM uploaded to AIMS tool (TMobile tool)
   - pj_p_3900_all_bat_orders_received_finish  | LOCAL_DATE_TIME  | <Planned>
   - pj_a_3900_all_bat_orders_received_finish  | LOCAL_DATE_TIME  | Material has arrived in warehouse

3. Steel_Submission
   - pj_project_id           | STRING           | Primary key
   - pj_steel_ordered_status | STRING           | Steel ordered status
   - pj_steel_received_status| STRING           | Steel received status
   - pj_steel_po_number      | STRING           | Steel PO number
   - pj_steel_ordered        | LOCAL_DATE_TIME  | Ordered date
   - pj_steel_received_date  | LOCAL_DATE_TIME  | Received date

4. Material_Pickup
   - pj_project_id                                      | STRING           | Primary key
   - pj_p_3925_msl_pickup_date_finish                   | LOCAL_DATE_TIME  | <Planned>
   - pj_a_3925_msl_pickup_date_finish                   | LOCAL_DATE_TIME  | Vendor Picks up Material from warehouse in this milestone
   - ms_1461_pickup_tower_materials_and_validate_actual | LOCAL_DATE_TIME  | Vendor Picks up Material from warehouse in this milestone (Updated by - Project Manager)
   - ms_14610_gc_material_pickup_actual                 | LOCAL_DATE_TIME  | Vendor Picks up Material from warehouse in this milestone (Updated by - Vendor/GC) 

--- ADDITIONAL PHASE6 RELATIONSHIPS ---

(Phase6_Material)-[:HAS_SUBPHASE]->(BOM_Submission)
(Phase6_Material)-[:HAS_SUBPHASE]->(Steel_Submission)
(Phase6_Material)-[:HAS_SUBPHASE]->(Material_Pickup)
""",

7: """
=== PHASE 7: Tower (swap) Readiness ===

This phase includes all the POs (SPO and CPO i.e Supplier PO and Customer PO). 
These POs together are the Pre-requisites for Tower (SWAP) work.

--- NODES ---

1. Phase7_Construction_Readiness
   - pj_project_id                                | STRING           | Primary key
   - pj_construction_pos_issued                   | FLOAT            | PO issued flag/count
   - ms_1321_talon_view_drone_svcs_spo            | FLOAT            | TalonView SPO
   - ms_1321_talon_view_drone_svcs_spo_issued_date| LOCAL_DATE_TIME  | TalonView SPO issued date
   - ms1555_construction_complete_spo             | FLOAT            | Tower completion SPO
   - ms1555_construction_complete_spo_issued_date | LOCAL_DATE_TIME  | Tower SPO issue date
""",

8: """
=== PHASE 8: Tower Work (SWAP Work or Radio SWAP or Equipment Upgrade) ===

This phase includes the tower work (swap) start and finish dates, delays and comments.

--- NODES ---

1. Phase8_Tower_Work
   - pj_project_id                           | STRING           | Primary key
   - pj_p_4225_construction_start_finish     | LOCAL_DATE_TIME  | <Planned>
   - pj_a_4225_construction_start_finish     | LOCAL_DATE_TIME  | Actual tower work (swap) start date
   - pj_p_5175_construction_complete_finish  | LOCAL_DATE_TIME  | <Planned>
   - pj_a_5175_construction_complete_finish  | LOCAL_DATE_TIME  | Actual tower work (swap) complete date
   - pj_construction_start_delay_code        | STRING           | Start delay code
   - pj_construction_start_delay_comments    | STRING           | Start delay comments
   - pj_construction_complete_delay_code     | STRING           | Complete delay code
   - pj_construction_complete_delay_comments | STRING           | Complete delay comments

""",

9: """
=== PHASE 9: Network Integration ===

This phase manages the integration of telecom network equipment into the operational network.
This includes integration start and complete milestones, and integration comments. 

--- NODES ---

1. Phase9_Integration
   - pj_project_id                                      | STRING          | Primary key
   - pj_p_5270_integration_start_finish                 | LOCAL_DATE_TIME | <Planned>
   - pj_a_5270_integration_start_finish                 | LOCAL_DATE_TIME | Actual network integration start date
   - pj_p_5275_integration_complete_finish              | LOCAL_DATE_TIME | <Planned>
   - pj_a_5275_integration_complete_finish              | LOCAL_DATE_TIME | Actual network integration complete date
   - pj_integration_comments                            | STRING          | Integration comments
   - ms_1899_all_planned_technologies_integrated_actual | LOCAL_DATE_TIME | All techs integrated
""",

10: """
=== PHASE 10: Post-Integration ===

This phase has integration completion milestones. It also includs 72 hours monitoring milestone.
Old ahloa equipement can be either disposed or returned.

--- NODES ---

1. Phase11_Post_Integration
   - pj_project_id                                 | STRING          | Primary key
   - ms_1970_integration_complete_actual           | LOCAL_DATE_TIME | Post Integration completion date 
   - ms_2045_72_hours_monitoring_complete_actual   | LOCAL_DATE_TIME | +72 hours from 1970 milestone date
   - ms_17050_gc_ahloa_return_actual               | LOCAL_DATE_TIME | If this date is not null than old equipement is returned back on that date.
   - ms_17100_gc_ahloa_disposal_actual             | LOCAL_DATE_TIME | If this date is not null than old equipement is disposed on that date.
""",

11: """
=== PHASE 11: Revenue & Financial Close-Out ===

This phase contains revenue milestones (CA, IA, GR, BBR, SO etc) 
from different 3 phases of the project - Tower (swap), Integration and DEC_COP.

--- NODES ---

1. Phase12_Revenue
   - pj_project_id | STRING | Primary key
 
2. Tower_Revenue
   - pj_project_id                              | STRING          | Primary key
   - ms1555_construction_complete_invoice_date  | LOCAL_DATE_TIME | Tower invoice date
   - ms1555_construction_complete_invoice       | STRING/FLOAT    | Tower invoice
   - ms1555_construction_complete_ca_date       | LOCAL_DATE_TIME | Tower CA complete date
   - ms1555_construction_complete_bbr_date      | LOCAL_DATE_TIME | Tower BBR complete date
   - ms1555_construction_complete_gr_date       | LOCAL_DATE_TIME | Tower GR complete date
   - ms1555_construction_complete_ia_date       | LOCAL_DATE_TIME | Tower IA complete date
 
3. PL_Revenue
   - pj_project_id                          | STRING           | Primary key
   - ms_1559_cop_approved_by_t_mobile_ia_date | LOCAL_DATE_TIME| COP IA
   - ms_1559_cop_approved_by_t_mobile_gr_date | LOCAL_DATE_TIME| COP GR
   - ms_1559_cop_approved_by_t_mobile_ca_date | LOCAL_DATE_TIME| COP CA
   - ms_1559_cop_approved_by_t_mobile_bbr_date| LOCAL_DATE_TIME| COP BBR

4. Integration_Revenue
   - pj_project_id                                | STRING           | Primary key
   - ms_1970_integration_complete_actual          | LOCAL_DATE_TIME  | Integration complete
   - ms_1970_integration_complete_ca_date         | LOCAL_DATE_TIME  | CA complete date
   - ms_1970_integration_complete_bbr_date        | LOCAL_DATE_TIME  | BBR complete date
   - ms_1970_integration_complete_so_inv_date     | LOCAL_DATE_TIME  | SO invoice date
   - ms_1970_integration_complete_ia_date         | LOCAL_DATE_TIME  | IA complete date
   - ms_1970_integration_complete_gr_date         | LOCAL_DATE_TIME  | GR complete date
   - ms_1970_integration_complete_spo_issued_date | LOCAL_DATE_TIME  | SPO issued date

--- ADDITIONAL PHASE12 RELATIONSHIPS (ALL start at Site) ---

(Phase11_Revenue)-[:HAS_SUBPHASE]->(Tower_Revenue)
(Phase11_Revenue)-[:HAS_SUBPHASE]->(PL_Revenue)
(Phase11_Revenue)-[:HAS_SUBPHASE]->(Integration_Revenue)
""",

"HSE": """
=== HSE: Health, Safety and Environment ===

The HSE node records safety compliance linkage during active construction phases. It links from the project path starting at Site, and contains visit-level records per project.

--- NODES ---

1. HSE
   - pj_project_id | STRING | Unique project identifier; primary key

2. Visit
   - pj_project_id             | STRING  | Project identifier this visit belongs to
   - visit_num                 | INTEGER | Visit sequence number; part of composite key
   - check_in_status           | STRING  | Crew check-in status 
   - check_in_date             | STRING  | Date of the crew check-in
   - ppe_validation            | STRING  | PPE inspection result
   - ppe_photo_available       | STRING  | Whether PPE photo was captured
   - jsa_completion_status     | STRING  | JSA completion status
   - each_crew_ptid_l2w_status | STRING  | PTID L2W availability status

3. Revisit
   - pj_project_id              | STRING  | Project identifier
   - visit_num                  | INTEGER | Visit number that triggered the revisit
   - market_cm_name             | STRING  | Market CM name
   - escalation_l1_to_gc        | STRING  | L1 escalation to GC
   - esaclation_l2_to_cm        | STRING  | L2 escalation to CM
   - esaclation_l3_to_pm        | STRING  | L3 escalation to PM
   - escalation_l4_pd_all       | STRING  | L4 escalation to PD/All
   - non_compliance_category    | STRING  | Category of non-compliance

--- HSE RELATIONSHIPS ---

(Site)-[:SITE_TO_HSE]->(HSE)
(HSE)-[:VISITS]->(Visit)
(Visit)-[:REJECTED]->(Revisit)
""",

"DEC_COP": """
=== DEC_COP: Close-Out Package & Punch List Workflow ===

The DEC_COP node tracks Nokia's close-out package (COP) submitted to T-Mobile after construction. 
It also anchors the punch list's (A checklist to be filled by Vendor during work) workflow - submission, returns, re-submission, and final approvals.
Here milestones from 3 databases are involved. Use prefix to distinguish them. 
pj_ are from TMobile DB, ms_ are from Nokia DB and scop_ are from DEC DB. 
In DEC DB tower and civil punch lists are seperately tracked.
--- NODES ---

1. DEC_COP
   - pj_project_id   | STRING | Unique project identifier; primary key
   - scop_title      | STRING | COP title (e.g., 'A1Q0166G_CENTRAL_*_Close Out Pack')
   - approvedpercent | STRING | COP approval percentage by T-Mobile (e.g., '100', '39')

2. Punch_List_status
In this phase the Vendor fills the checklist / punchlist and parallely Nokia team approves it (checks it). 
The approve result can be rejected. Yet to approve are pending. While completed are ones which are not rejected by Nokia.
   - pj_project_id                              | STRING | Primary key
   - scop_title                                 | STRING | Session/COP title
   - scop_ndpc_session_created_cw               | LOCAL_DATE_TIME | Session creation date
   - scop_ndpc_session_cw_last_activity         | LOCAL_DATE_TIME | Vendor last visit date
   - scop_ndpc_session_cw_pending_pct           | STRING | Civil: pending %
   - scop_ndpc_session_cw_completed_pct         | STRING | Civil: completed %
   - scop_ndpc_session_cw_approved_pct          | STRING | Civil: approved %
   - scop_ndpc_session_cw_rejected_pct          | STRING | Civil: rejected %
   - scop_ndpc_session_tw_pending_pct           | STRING | Tower: pending %
   - scop_ndpc_session_tw_completed_pct         | STRING | Tower: completed %
   - scop_ndpc_session_tw_approved_pct          | STRING | Tower: approved %
   - scop_ndpc_session_tw_rejected_pct          | STRING | Tower: rejected %

3. PL_Submission
Once the approvedpercent (from DEC_COP node) reaches 95%, it is submitted to TMobile for the first time in 1557 milestone.
   - pj_project_id                                        | STRING           | Primary key
   - ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl | LOCAL_DATE_TIME | Punch checklist 1st submission date in Nokia DB
   - ms_1558_admin_checklist_submitted_to_t_mobile_actual | LOCAL_DATE_TIME  | Admin checklist 1st submission date in Nokia DB
   - ms_1553_review_civil_quality_media_checklist         | LOCAL_DATE_TIME  | Civil quality/media checklist review from Nokia DB
   - pj_a_5500_receive_close_out_binder_finish | LOCAL_DATE_TIME | Punch checklist (Close out binder) recieved by TMobile for the first time, recorded in TMobile DB.
   - pj_p_5500_receive_close_out_binder_finish | LOCAL_DATE_TIME | <Planned>

4. PL_Post_Submission
Post submission, the rejected punch list is given back to Vendor after 7 days of 1557
   - pj_project_id                          | STRING          | Primary key
   - pj_a_5400_punch_list_to_gc_finish      | LOCAL_DATE_TIME | Vendor recieves rejected punch list.
   - pj_p_5400_punch_list_to_gc_finish      | LOCAL_DATE_TIME | <Planned>

5. PL_Resubmission
Nokia team reworks with Vendor on the rejected punchlist and they resubmit it finally, it takes upto 14 days at max from 5400.
   - pj_project_id                           | STRING          | Primary key
   - pj_a_5425_punch_list_complete_finish    | LOCAL_DATE_TIME | Punchlist resubmission date
   - pj_p_5425_punch_list_complete_finish    | LOCAL_DATE_TIME | <Planned>
   - scop_pending_days_for_gc_action         | STRING          | Days pending GC action from 5400

6. PL_Final_Approval
TMobile finally closes the Punchlist post resubmission (5425)
   - pj_project_id                              | STRING          | Primary key
   - pj_a_5525_approve_close_out_binder_finish  | LOCAL_DATE_TIME | Punch list (Close out binder) closing date in TMobile DB
   - pj_p_5525_approve_close_out_binder_finish  | LOCAL_DATE_TIME | <Planned>
   - ms_1559_cop_approved_by_t_mobile_actual    | LOCAL_DATE_TIME | TMobile punch list closing / final approval date in Nokia DB.
   - scop_checklist_accepted_by_customer        | STRING          | Same milestone in DEC database
   - pj_p_5540_financial_closeout_finish        | LOCAL_DATE_TIME | Planned date for DEC_COP finance close out (IA,GR,CA,BBR,etc)
   - magenta_ms_5525_actual                     | LOCAL_DATE_TIME | DEC_COP punchlist process completion date in Nokia DB.

--- DEC_COP RELATIONSHIPS ---

(Site)-[:SITE_TO_DEC_COP]->(DEC_COP)
(DEC_COP)-[:HAS_PL]->(Punch_List_status)
(DEC_COP)-[:PL_SUBMITTED]->(PL_Submission)
(DEC_COP)-[:PL_RETURNED]->(PL_Post_Submission)
(DEC_COP)-[:PL_RESUBMITTED]->(PL_Resubmission)
(DEC_COP)-[:PL_APPROVED]->(PL_Final_Approval)
"""
}