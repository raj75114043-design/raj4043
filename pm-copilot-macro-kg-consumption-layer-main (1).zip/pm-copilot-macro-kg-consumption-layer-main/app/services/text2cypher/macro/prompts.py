# app/services/text2cypher/prompts.py
import re
from langchain_core.prompts import ChatPromptTemplate

CYPHER_RE = re.compile(r"<cypher>\s*(.*?)\s*</cypher>", re.DOTALL | re.IGNORECASE)

def extract_cypher(text: str) -> str:
    m = CYPHER_RE.search(text)
    return m.group(1).strip() if m else text.strip()

TEXT2CYPHER_PROMPT = ChatPromptTemplate.from_messages([
    ("system",
     "You are an expert Neo4j Cypher query generator.\n"
     "Use ONLY the nodes, relationships and properties defined in the schema below.\n"
     "Schema:\n---\n{schema}\n---\n"
     "Rules:\n"
     "- Always add LIMIT 200 to every query.\n"
     "- Never use properties or labels not present in the schema.\n"
     "- For any date or time based filters use - localdatetime('YYYY-MM-DDTHH:MM:SS') in cypher"),
    ("human",
     "Question: {question}\n\n"
     "Respond ONLY with:\n<cypher>\nMATCH ...\n</cypher>"),
])

VALIDATE_CORRECT_PROMPT = ChatPromptTemplate.from_messages([
    ("system", "You are a senior Cypher expert. Review and fix Cypher queries."),
    ("human",
     """Schema:
{schema}

Question: {question}

Cypher:
{cypher}

Tasks:
1. List all syntax/semantic errors (empty list if none).
2. Extract every property filter used.
3. Return a corrected Cypher (identical to input if already correct).

Rules:
- The query MUST have a LIMIT clause; add LIMIT 200 if missing.
- Use ONLY nodes, relationships and properties present in the schema.
- Return ONLY valid Cypher in corrected_cypher — no backticks, no explanation."""),
])