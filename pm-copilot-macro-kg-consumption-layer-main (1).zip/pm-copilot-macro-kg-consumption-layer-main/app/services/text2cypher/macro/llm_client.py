# app/services/text2cypher/llm_client.py
from langchain_openai import ChatOpenAI
from app.core.config import settings

def get_llm(model_name: str = "gpt-5", reasoning_effort: str = "low", temperature: float = 0.0) -> ChatOpenAI:
    """
    Returns a ChatOpenAI client configured for Nokia LLM Gateway.

    We pass workspace and API key via headers as required by the gateway.
    """
    if not settings.llm_gateway_link or not settings.llm_api_key or not settings.workspace_name:
        raise RuntimeError("LLM gateway settings are not configured")

    headers = {
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    }

    return ChatOpenAI(
        api_key="NONE",  # gateway uses header auth, not bearer
        model=model_name,
        base_url=settings.llm_gateway_link,
        default_headers=headers,
        temperature=temperature,
        reasoning_effort=reasoning_effort,
    )

# pre-wired common clients (reuse across agent)
LLM_LOW    = get_llm(model_name="gpt-5.2", reasoning_effort="low", temperature=0.0)
LLM_MEDIUM = get_llm(model_name="gpt-5.2", reasoning_effort="medium", temperature=0.0)