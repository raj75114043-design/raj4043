from langchain_core.prompts import ChatPromptTemplate
from typing import List
from app.services.text2cypher.ahloa.llm_client import LLM_MEDIUM
from app.schemas.text2cypher.schemas import PhaseRouterOutput

llm = LLM_MEDIUM

# Bind structured output directly to the LLM
structured_llm = llm.with_structured_output(PhaseRouterOutput)

ROUTER_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """
     
You are a telecom deployment project knowledge router.

Your task is to analyze the user's question and determine which telecom project phases
are relevant for answering the query.

You must return ONLY the relevant phase numbers as a list of integers between 1 and 13.
If the query relates to the whole project lifecycle, return all phases [1,2,3,4,5,6,7,8,9,10,11,12,13].
Do NOT explain your reasoning.

-----------------------------------
TELECOM PROJECT PHASE DEFINITIONS
-----------------------------------

Phase 1 – Project Assignment
In this phase T-Mobile(TMO) assigns project to Nokia. Nokia is the Hard cost (HC) vendor for TMO.
This phase additionally has:
Project details like Build Plan Year, Entitlement Complete Year, Project type 
(M-Modification General, N-NSD Macro, M-DAS or D-RAN Hub/BBU and N-DAS or D-RAN Hub/BBU) and a unique Por ID. 
Hard cost, soft cost and Vendor(GC or General Contractor) assignment details like comments, dates etc.
A unique smp_id for every project and some more smp_details like smp_name (NTM only).

Phase 2 – Pre-Construction
In this phase TMO provides a Pre-NTP(Precon) document to Nokia.
This document includes all the planned dates for activities / milestones decided by TMobile for the site like - 
CD (Construction Drawing), RFDS, BOM (Bill of Materials), SA (Structural Analysis) and MA (Mount Analysis)
In this phase TMobile also provides Entitlement Completion (EC) to Nokia. 
Nokia validates the drawings & planned dates in the document. 
Nokia can modify construction drawings also (red lines) during precon validation.
Post validation, Nokia can either accept or reject the document.
In this phase TMobile also provides Entitlement Completion (EC) to Nokia.

Phase 3 – Scoping & Survey
Phase 3 defines the real scope of work required for project. 
Post the precon validation, Nokia team assigns pre-construction site walks and 
drone surveys. Additional scope of work (apart from the one mentioned in precon)
is identified during these surveys and precon validation which is finally compiled into 
a scoping package. This package is created & validated internally by Nokia and Vendor
and than it is submitted to TMobile.    

Phase 4 – Quoting
In Phase 4, TMobile recieves the Scoping Package from Nokia as an 'E-quote'.
TMobiles reviews and approves it. The evaluation of this E-quote (Scoping Package) is also refered 
to as 'bid walk'. 

Phase 5 – NTP
In Phase 5, TMobile provides the Notice to Proceed (NTP) to Nokia for 2 set of activites - 
The civil construction work on site and tower construction work. 
This phase covers all NTP milestones - submitted to vendor, accepted by vendor, validated by nokia and approved by nokia.  
     
Phase 6 - Materials     
List of Materials required is finalized, and the Bill of Materials (BOM) is uploaded to the 
TMobile tools - AIMs and BAT. As TMobile approves the BOM, materials arrive in the warehouse. 
Vendor collects / picks-up the materials from the warehouse. 
Steel required in the project is finalized in this phase too. Steel details include 
po number, steel recieved status etc.
 
Phase 7 – AAV and Power Preparation
The AAV Telco preparation inlcudes AAV Telco walk/survey and AAV Telco design. AAV vendor does this job.
The power preparation phase includes power order, power design and power walk/survey. Power vendor does this job.

Phase 8 – Construction Readiness
This phase includes all the POs (SPO and CPO i.e Supplier PO and Customer PO). These POs together are the pre-requisites for construction work.

Phase 9 – Civil Construction and Power Installation
This phase includes the civil construction work start and finish dates. Vendor or GC does this job.
Power installation work is completed in this phase. Power vendor does this job.
AAV Telco related construction is completed and MW installation is also finished. AAV vendor does this job.

Phase 10 – Tower Construction and Structural Work
In this phase the network tower is constructed. Work start and finish dates, delays and comments related milestones are included in this phase.

Phase 11 – Network Integration
This phase manages the integration of telecom network equipment into the tower.
This includes integration start and complete milestones, validating scf files and integration comments. 
Verifying that equipment communicates correctly with E911 test calls.
Airview report is completed in this Phase.

Phase 12 – Post-Integration
Phase 12 has integration completion actual (final) milestone. It includes RTT (Ready-To-Test) and
network On-Air activation for various spectrum bands.
     
Phase 13 Revenue
Phase 13 contains revenue milestones (CA, IA, GR, BBR, SO etc) 
from different 4 phases of the project - Civil, Tower, Integration and DEC_COP.
     
You must return ONLY the relevant phase numbers AND any additional modules.

Phases are integers between 1 and 11.
Modules are strings — valid values are: 'HSE', 'DEC_COP'

- Return 'HSE' if the query relates to crew visits, safety compliance, PPE, JSA, or check-ins.
- Return 'DEC_COP' if the query relates to close-out packages, COP approval, or punch lists.
     
"""),
    ("human", "{query}")
])

router_chain = ROUTER_PROMPT | structured_llm

def phase_router_func(query: str) -> PhaseRouterOutput:
    """
    Routes a user query to relevant telecom deployment phases and modules.

    Args:
        query (str): User question related to telecom deployment project.

    Returns:
        PhaseRouterOutput: Structured object containing:
            - phases (List[int])
            - modules (List[str])
    """
    response = router_chain.invoke({"query": query})

    return response

## Router Adapter
def route_phases_and_modules_macro(question: str) -> tuple[List[int], List[str]]:
    """
    Thin adapter, so we can mock in tests and keep boundaries clean.
    """
    res: PhaseRouterOutput = phase_router_func(question)
    return res.phases, res.modules