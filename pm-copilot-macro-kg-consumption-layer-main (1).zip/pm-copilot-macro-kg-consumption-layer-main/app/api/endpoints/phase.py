# router.py
import asyncio
import logging

from fastapi import APIRouter, HTTPException, status
from fastapi import APIRouter
from app.schemas.phase_router.schemas import PhaseRouterResponse, PhaseRouterRequest
from app.services.text2cypher.ahloa.phase_router import route_phases_and_modules_ahloa
from app.services.text2cypher.macro.phase_router import route_phases_and_modules_macro
from app.services.text2cypher.nas.phase_router import route_phases_and_modules_nas

logger = logging.getLogger(__name__)
router = APIRouter(
    prefix="/phase-router",
    tags=["Phase Router"]
)

# ----------- API Endpoint AHLOA -----------
@router.post("/phase_ahloa", response_model=PhaseRouterResponse)
def route_phases(request: PhaseRouterRequest):
    """
    Routes a natural language query to KG phases and modules.
    """
    phases, modules = route_phases_and_modules_ahloa(request.query)

    return {
        "phases": phases,
        "modules": modules
    }

# ----------- API Endpoint MACRO -----------
@router.post("/phase_macro", response_model=PhaseRouterResponse)
def route_phases(request: PhaseRouterRequest):
    """
    Routes a natural language query to KG phases and modules.
    """
    phases, modules = route_phases_and_modules_macro(request.query)

    return {
        "phases": phases,
        "modules": modules
    }

# ----------- API Endpoint NAS -----------
@router.post("/phase_nas", response_model=PhaseRouterResponse)
def route_phases(request: PhaseRouterRequest):
    """
    Routes a natural language query to KG phases and modules.
    """
    phases, modules = route_phases_and_modules_nas(request.query)

    return {
        "phases": phases,
        "modules": modules
    }