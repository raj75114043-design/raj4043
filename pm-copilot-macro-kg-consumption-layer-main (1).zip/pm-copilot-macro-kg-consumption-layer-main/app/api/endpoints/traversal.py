import logging

from fastapi import APIRouter, HTTPException, status
from app.services.traversal.ahloa.agent import extract_relevant_schema_ahloa
from app.services.traversal.macro.agent import extract_relevant_schema_macro
from app.services.traversal.nas.agent import extract_relevant_schema_nas
from app.schemas.traversal.schemas import SchemaExtractionRequest, SchemaExtractionResponse
logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/Graph Traversal",
    tags=["Graph Traversal"]
)

# ----------- API Endpoint AHLOA -----------
@router.post("/extract_ahloa", response_model=SchemaExtractionResponse)
def extract_schema(request: SchemaExtractionRequest):
    """
    Extracts relevant Neo4j nodes and relationships from the AHLOA schema
    for a given natural language query.
    """
    relevant_schema = extract_relevant_schema_ahloa(request.query)

    return {
        "query": request.query,
        "relevant_schema": relevant_schema
    }

# ----------- API Endpoint MACRO -----------
@router.post("/extract_macro", response_model=SchemaExtractionResponse)
def extract_schema(request: SchemaExtractionRequest):
    """
    Extracts relevant Neo4j nodes and relationships from the AHLOA schema
    for a given natural language query.
    """
    relevant_schema = extract_relevant_schema_macro(request.query)

    return {
        "query": request.query,
        "relevant_schema": relevant_schema
    }

# ----------- API Endpoint NAS -----------
@router.post("/extract_nas", response_model=SchemaExtractionResponse)
def extract_schema(request: SchemaExtractionRequest):
    """
    Extracts relevant Neo4j nodes and relationships from the AHLOA schema
    for a given natural language query.
    """
    relevant_schema = extract_relevant_schema_nas(request.query)

    return {
        "query": request.query,
        "relevant_schema": relevant_schema
    }