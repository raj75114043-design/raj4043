# app/api/endpoints/text2cypher.py
import asyncio
import logging

from fastapi import APIRouter, HTTPException, status

from app.schemas.text2cypher.schemas import Text2CypherRequest, Text2CypherResponse
from app.services.text2cypher.macro.agent import run_agent_once_macro
from app.services.text2cypher.ahloa.agent import run_agent_once_ahloa
from app.services.text2cypher.nas.agent import run_agent_once_nas

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/graph/text2cypher", tags=["Text2Cypher"])


@router.post("/run_macro", response_model=Text2CypherResponse)
async def text2cypher_run(req: Text2CypherRequest) -> Text2CypherResponse:
    """
    One-shot Text2Cypher execution. Returns cypher, errors (if any), and records.
    """
    try:
        final_state_future = run_agent_once_macro(
            question=req.question,
            phases=req.phases,
            modules=req.modules,
        )
        state = await asyncio.wait_for(final_state_future, timeout=req.timeout_s)

        cypher_errors = state.get("cypher_errors") or []
        status_str = "ok" if not cypher_errors else "error"

        return Text2CypherResponse(
            status=status_str,
            message=None if status_str == "ok" else "Cypher validation/execution errors present.",
            cypher_statement=state.get("cypher_statement"),
            cypher_errors=cypher_errors or None,
            records=state.get("database_records") or None,
            steps=state.get("steps") or [],
            retries=state.get("retry_count", 0),
        )
    except asyncio.TimeoutError:
        logger.warning("Text2Cypher timed out.")
        raise HTTPException(status_code=status.HTTP_504_GATEWAY_TIMEOUT, detail="Request timed out")
    except Exception as e:
        logger.exception("Text2Cypher failure")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/run_ahloa", response_model=Text2CypherResponse)
async def text2cypher_run(req: Text2CypherRequest) -> Text2CypherResponse:
    """
    One-shot Text2Cypher execution. Returns cypher, errors (if any), and records.
    """
    try:
        final_state_future = run_agent_once_ahloa(
            question=req.question,
            phases=req.phases,
            modules=req.modules,
        )
        state = await asyncio.wait_for(final_state_future, timeout=req.timeout_s)

        cypher_errors = state.get("cypher_errors") or []
        status_str = "ok" if not cypher_errors else "error"

        return Text2CypherResponse(
            status=status_str,
            message=None if status_str == "ok" else "Cypher validation/execution errors present.",
            cypher_statement=state.get("cypher_statement"),
            cypher_errors=cypher_errors or None,
            records=state.get("database_records") or None,
            steps=state.get("steps") or [],
            retries=state.get("retry_count", 0),
        )
    except asyncio.TimeoutError:
        logger.warning("Text2Cypher timed out.")
        raise HTTPException(status_code=status.HTTP_504_GATEWAY_TIMEOUT, detail="Request timed out")
    except Exception as e:
        logger.exception("Text2Cypher failure")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/run_nas", response_model=Text2CypherResponse)
async def text2cypher_run(req: Text2CypherRequest) -> Text2CypherResponse:
    """
    One-shot Text2Cypher execution. Returns cypher, errors (if any), and records.
    """
    try:
        final_state_future = run_agent_once_nas(
            question=req.question,
            phases=req.phases,
            modules=req.modules,
        )
        state = await asyncio.wait_for(final_state_future, timeout=req.timeout_s)

        cypher_errors = state.get("cypher_errors") or []
        status_str = "ok" if not cypher_errors else "error"

        return Text2CypherResponse(
            status=status_str,
            message=None if status_str == "ok" else "Cypher validation/execution errors present.",
            cypher_statement=state.get("cypher_statement"),
            cypher_errors=cypher_errors or None,
            records=state.get("database_records") or None,
            steps=state.get("steps") or [],
            retries=state.get("retry_count", 0),
        )
    except asyncio.TimeoutError:
        logger.warning("Text2Cypher timed out.")
        raise HTTPException(status_code=status.HTTP_504_GATEWAY_TIMEOUT, detail="Request timed out")
    except Exception as e:
        logger.exception("Text2Cypher failure")
        raise HTTPException(status_code=500, detail=str(e))