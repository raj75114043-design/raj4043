import logging
from fastapi import APIRouter, HTTPException

import math
from typing import Any
from fastapi.responses import JSONResponse

from app.services.status.ahloa.agent import get_site_milestones
from app.services.status.macro.agent import get_project_milestones
from app.services.status.nas.agent import get_nas_site_milestones

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/status",
    tags=["Site/Project Status"]
)

# ── NaN / Inf sanitizer ────────────────────────────────────────────────────────

def _sanitize(obj: Any) -> Any:
    """
    Recursively walk a dict/list structure and replace any float nan/inf/-inf
    with None so that FastAPI's JSON serializer doesn't choke.
    """
    if isinstance(obj, dict):
        return {k: _sanitize(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_sanitize(v) for v in obj]
    if isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
        return None
    return obj


def _safe_json(data: Any) -> JSONResponse:
    return JSONResponse(content=_sanitize(data))


# ── Routes ─────────────────────────────────────────────────────────────────────

@router.get("/ahloa/site/{site_id}")
async def ahloa_site_milestones(site_id: str):
    """
    Fetch all milestones across all AHLOA phases (1–11), HSE, and DEC_COP
    for a given site_id.

    - **site_id**: Unique site identifier (e.g. `9NV0517R`)
    """
    logger.info(f"[AHLOA] Fetching milestones for site_id={site_id}")
    result = await get_site_milestones(site_id)
    if result is None:
        raise HTTPException(status_code=404, detail=f"AHLOA site '{site_id}' not found.")
    return _safe_json(result)


@router.get("/macro/project/{project_id}")
async def macro_project_milestones(project_id: str):
    """
    Fetch all milestones across all Macro/NTM phases (1–13), HSE, and DEC_COP
    for a given project_id.

    - **project_id**: Unique project identifier (e.g. `SMP-WO-1296358`)
    """
    logger.info(f"[MACRO] Fetching milestones for project_id={project_id}")
    result = await get_project_milestones(project_id)
    if result is None:
        raise HTTPException(status_code=404, detail=f"Macro project '{project_id}' not found.")
    return _safe_json(result)


@router.get("/nas/site/{site_id}")
async def nas_site_milestones(site_id: str):
    """
    Fetch all milestones across all NAS phases (1–5) for a given nas_site_id.
    Covers e911 readiness, planned activities, sessions, integration, and RF010.

    - **site_id**: Unique NAS site identifier (e.g. `NAS-SITE-001`)
    """
    logger.info(f"[NAS] Fetching milestones for site_id={site_id}")
    result = await get_nas_site_milestones(site_id)
    if result is None:
        raise HTTPException(status_code=404, detail=f"NAS site '{site_id}' not found.")
    return _safe_json(result)