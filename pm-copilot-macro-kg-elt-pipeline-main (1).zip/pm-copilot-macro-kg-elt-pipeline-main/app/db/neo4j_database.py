"""
Async Neo4j connection manager
Author: Advait Shah, PwC India
Client: Nokia
"""

import logging
from neo4j import AsyncGraphDatabase
from app.core.config import settings

logger = logging.getLogger(__name__)

# Global async driver instance
neo4j_driver = None
neo4j_db_driver = None
neo4j_ahloa_driver = None
neo4j_kpi_driver = None
neo4j_nas_driver = None


# ==================== Macro-Phasewise KG Functions ====================

async def init_neo4j() -> None:
    """
    Initialize the async Neo4j (Macro-Phasewise) driver.
    Called during FastAPI startup lifespan.
    """

    global neo4j_driver

    logger.info("Initializing Async Neo4j (Macro-Phasewise) driver...")

    try:
        neo4j_driver = AsyncGraphDatabase.driver(
            settings.neo4j_uri,
            auth=settings.neo4j_auth,
        )

        # Test connection (official async pattern)
        async with neo4j_driver.session() as session:
            await session.run("RETURN 1")

        logger.info("Async Neo4j (Macro-Phasewise) connection established successfully")

    except Exception as e:
        logger.error(f"Async Neo4j (Macro-Phasewise) connection failed: {e}")
        raise

async def close_neo4j() -> None:
    """
    Close (Macro-Phasewise) driver on application shutdown.
    """
    global neo4j_driver

    if neo4j_driver:
        logger.info("Closing Async Neo4j (Macro-Phasewise) driver...")
        await neo4j_driver.close()
        logger.info("Async Neo4j (Macro-Phasewise) driver closed")

def get_neo4j_driver():
    """
    Return the initialized async Neo4j (Macro-Phasewise) driver.
    """
    if neo4j_driver is None:
        raise RuntimeError("Neo4j (Macro-Phasewise) driver not initialized")
    return neo4j_driver

async def health_check_neo4j() -> bool:
    """
    Check if Neo4j (Macro-Phasewise) connection is alive.
    """
    try:
        driver = get_neo4j_driver()
        async with driver.session() as session:
            await session.run("RETURN 1")
        return True
    except Exception as e:
        logger.warning(f"Neo4j (Macro-Phasewise) health check failed: {e}")
        return False
    

# ==================== Database Schema KG  Functions ====================

async def init_neo4j_db() -> None:
    """
    Initialize the async Neo4j_DB driver.
    """
    global neo4j_db_driver
    logger.info("Initializing Async Neo4j_DB driver ...")
    try:
        neo4j_db_driver = AsyncGraphDatabase.driver(
            settings.neo4j_db_uri,
            auth=settings.neo4j_db_auth,
        )
        async with neo4j_db_driver.session() as session:
            await session.run("RETURN 1")
        logger.info("Async Neo4j_DB connection established successfully")
    except Exception as e:
        logger.error(f"Async Neo4j_DB connection failed: {e}")
        raise


async def close_neo4j_db() -> None:
    """
    Close the Neo4j_DB driver on application shutdown.
    """
    global neo4j_db_driver
    if neo4j_db_driver:
        logger.info("Closing Async Neo4j_DB driver ...")
        await neo4j_db_driver.close()
        logger.info("Async Neo4j_DB driver closed")


def get_neo4j_db_driver():
    """
    Return the initialized async Neo4j_DB driver.
    """
    if neo4j_db_driver is None:
        raise RuntimeError("Neo4j_DB driver not initialized")
    return neo4j_db_driver


async def health_check_neo4j_db() -> bool:
    """
    Check if Neo4j_DB connection is alive.
    """
    try:
        driver = get_neo4j_db_driver()
        async with driver.session() as session:
            await session.run("RETURN 1")
        return True
    except Exception as e:
        logger.warning(f"Neo4j_DB health check failed: {e}")
        return False
    

# ==================== (AHLOA KG)  Functions ====================

async def init_neo4j_ahloa() -> None:
    """
    Initialize the async Neo4j_AHLOA.
    """
    global neo4j_ahloa_driver
    logger.info("Initializing Async Neo4j_AHLOA...")
    try:
        neo4j_ahloa_driver = AsyncGraphDatabase.driver(
            settings.neo4j_ahloa_uri,
            auth=settings.neo4j_ahloa_auth,
        )
        async with neo4j_ahloa_driver.session() as session:
            await session.run("RETURN 1")
        logger.info("Async Neo4j_AHLOA connection established successfully")
    except Exception as e:
        logger.error(f"Async Neo4j_AHLOA connection failed: {e}")
        raise


async def close_neo4j_ahloa() -> None:
    """
    Close the Neo4j_AHLOA driver on application shutdown.
    """
    global neo4j_ahloa_driver
    if neo4j_ahloa_driver:
        logger.info("Closing Async Neo4j_AHLOA driver...")
        await neo4j_ahloa_driver.close()
        logger.info("Async Neo4j_AHLOA driver closed")


def get_neo4j_ahloa_driver():
    """
    Return the initialized async Neo4j_AHLOA driver.
    """
    if neo4j_ahloa_driver is None:
        raise RuntimeError("Neo4j_AHLOA driver not initialized")
    return neo4j_ahloa_driver


async def health_check_neo4j_ahloa() -> bool:
    """
    Check if Neo4j_AHLOA connection is alive.
    """
    try:
        driver = get_neo4j_ahloa_driver()
        async with driver.session() as session:
            await session.run("RETURN 1")
        return True
    except Exception as e:
        logger.warning(f"Neo4j_AHLOA health check failed: {e}")
        return False
    

# ==================== (KPI KG) Functions ====================


async def init_neo4j_kpi() -> None:
    """
    Initialize the async Neo4j_KPI.
    """
    global neo4j_kpi_driver
    logger.info("Initializing Async Neo4j_KPI...")
    try:
        neo4j_kpi_driver = AsyncGraphDatabase.driver(
            settings.neo4j_kpi_uri,
            auth=settings.neo4j_kpi_auth,
        )
        async with neo4j_kpi_driver.session() as session:
            await session.run("RETURN 1")
        logger.info("Async Neo4j_KPI connection established successfully")
    except Exception as e:
        logger.error(f"Async Neo4j_KPI connection failed: {e}")
        raise


async def close_neo4j_kpi() -> None:
    """
    Close the Neo4j_KPI driver on application shutdown.
    """
    global neo4j_kpi_driver
    if neo4j_kpi_driver:
        logger.info("Closing Async Neo4j_KPI driver...")
        await neo4j_kpi_driver.close()
        logger.info("Async Neo4j_KPI driver closed")


def get_neo4j_kpi_driver():
    """
    Return the initialized async Neo4j_KPI driver.
    """
    if neo4j_kpi_driver is None:
        raise RuntimeError("Neo4j_KPI driver not initialized")
    return neo4j_kpi_driver


async def health_check_neo4j_kpi() -> bool:
    """
    Check if Neo4j_KPI connection is alive.
    """
    try:
        driver = get_neo4j_kpi_driver()
        async with driver.session() as session:
            await session.run("RETURN 1")
        return True
    except Exception as e:
        logger.warning(f"Neo4j_KPI health check failed: {e}")
        return False

# ==================== (NAS KG)  Functions ====================


async def init_neo4j_nas() -> None:
    """
    Initialize the async Neo4j_NAS.
    """
    global neo4j_nas_driver
    logger.info("Initializing Async Neo4j_NAS...")
    try:
        neo4j_nas_driver = AsyncGraphDatabase.driver(
            settings.neo4j_nas_uri,
            auth=settings.neo4j_nas_auth,
        )
        async with neo4j_nas_driver.session() as session:
            await session.run("RETURN 1")
        logger.info("Async Neo4j_NAS connection established successfully")
    except Exception as e:
        logger.error(f"Async Neo4j_NAS connection failed: {e}")
        raise


async def close_neo4j_nas() -> None:
    """
    Close the Neo4j_NAS driver on application shutdown.
    """
    global neo4j_nas_driver
    if neo4j_nas_driver:
        logger.info("Closing Async Neo4j_NAS driver...")
        await neo4j_nas_driver.close()
        logger.info("Async Neo4j_NAS driver closed")


def get_neo4j_nas_driver():
    """
    Return the initialized async Neo4j_NAS driver.
    """
    if neo4j_nas_driver is None:
        raise RuntimeError("Neo4j_NAS driver not initialized")
    return neo4j_nas_driver


async def health_check_neo4j_nas() -> bool:
    """
    Check if Neo4j_NAS connection is alive.
    """
    try:
        driver = get_neo4j_nas_driver()
        async with driver.session() as session:
            await session.run("RETURN 1")
        return True
    except Exception as e:
        logger.warning(f"Neo4j_NAS health check failed: {e}")
        return False
