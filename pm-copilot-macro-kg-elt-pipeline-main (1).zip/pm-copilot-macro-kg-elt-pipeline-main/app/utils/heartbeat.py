"""
Heartbeat streaming helper.

Wraps a long-running coroutine in a StreamingResponse that emits a
keep-alive line every `interval` seconds. This prevents upstream
proxies/ingresses (nginx, ALB, Istio, etc.) from closing the connection
with a 504 Gateway Timeout while the work is still running inside the pod.

Output format: newline-delimited JSON (NDJSON).
  {"event": "heartbeat", "elapsed": 25.0}
  {"event": "heartbeat", "elapsed": 50.0}
  ...
  {"event": "result", "data": {...}}     # on success
  {"event": "error",  "detail": "..."}    # on failure
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Any, Awaitable, Callable

from fastapi.responses import StreamingResponse

logger = logging.getLogger(__name__)

DEFAULT_HEARTBEAT_INTERVAL_SECONDS = 25.0


async def _heartbeat_generator(
    work: Callable[[], Awaitable[Any]],
    interval: float,
):
    started = time.monotonic()
    task = asyncio.create_task(work())

    try:
        while True:
            try:
                # Wait up to `interval` for the task; shield so the
                # timeout cancels the wait, not the underlying work.
                result = await asyncio.wait_for(
                    asyncio.shield(task), timeout=interval
                )
                yield (
                    json.dumps(
                        {"event": "result", "data": result},
                        default=str,
                    )
                    + "\n"
                )
                return
            except asyncio.TimeoutError:
                elapsed = round(time.monotonic() - started, 2)
                yield (
                    json.dumps({"event": "heartbeat", "elapsed": elapsed})
                    + "\n"
                )
            except Exception as e:
                logger.exception("Heartbeat-wrapped work failed")
                yield (
                    json.dumps(
                        {"event": "error", "detail": str(e)}
                    )
                    + "\n"
                )
                return
    finally:
        if not task.done():
            task.cancel()


def stream_with_heartbeat(
    work: Callable[[], Awaitable[Any]],
    interval: float = DEFAULT_HEARTBEAT_INTERVAL_SECONDS,
) -> StreamingResponse:
    """
    Run `work()` and return an NDJSON StreamingResponse that emits a
    heartbeat line every `interval` seconds until the work completes.

    Usage in a FastAPI route:

        @router.post("/sync-neo4j")
        async def sync_neo4j(...):
            async def _work():
                # ... long-running logic ...
                return {"status": "success", ...}

            return stream_with_heartbeat(_work, interval=25.0)
    """
    return StreamingResponse(
        _heartbeat_generator(work, interval),
        media_type="application/x-ndjson",
        headers={
            # Disable proxy buffering so heartbeats reach the client
            # immediately (nginx and many ingresses honor this).
            "X-Accel-Buffering": "no",
            "Cache-Control": "no-cache",
        },
    )
