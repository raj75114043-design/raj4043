"""
Async ETL Router for Node & Relationship Ingestion into NAS Neo4j
Author: Advait Shah (PwC India)
Client: Nokia
"""

from fastapi import APIRouter, HTTPException
import asyncio
import json
from pathlib import Path
import logging
from typing import List, Dict

from sqlalchemy import text

from app.db.database import AsyncSessionLocal  # Postgres session stays the same
# 🔁 Only the driver changes to NAS:
from app.db.neo4j_database import get_neo4j_nas_driver

from app.services.neo4j_builder.async_node_builder import AsyncNeo4jNodeBuilder
from app.services.neo4j_builder.async_relation_builder import AsyncNeo4jRelationBuilder

router = APIRouter(
    prefix="/etl-nas",
    tags=["NAS KG Data Sync"]
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------
# Schema Loaders (JSON under app/schemas/nas)
# ---------------------------------------------------------------------

def _schemas_root() -> Path:
    # endpoints/ -> api/ -> app/
    return Path(__file__).resolve().parents[2] / "schemas" / "nas"

def load_node_schemas_nas() -> dict:
    """
    Loads node_nas.json for NAS inside the FastAPI project structure.
    """
    schema_path = _schemas_root() / "node_nas.json"
    if not schema_path.exists():
        raise FileNotFoundError(f"Schema file not found: {schema_path}")
    with open(schema_path, "r") as f:
        return json.load(f)

def load_relation_schemas_nas() -> dict:
    """
    Loads relation_nas.json for NAS inside the FastAPI project structure.
    """
    schema_path = _schemas_root() / "relation_nas.json"
    if not schema_path.exists():
        raise FileNotFoundError(f"Relationship schema file not found: {schema_path}")
    with open(schema_path, "r") as f:
        return json.load(f)

# ---------------------------------------------------------------------
# Workers
# ---------------------------------------------------------------------

async def run_single_node_nas(
    name: str,
    schema: dict,
    batch_size: int = 2000,
    max_concurrency: int = 5,
):
    """
    Full ETL for a single node: constraint + batch insert, targeting NAS DB.
    """
    logger.info(f"🔵 [NAS] ETL Started for node: {name}")

    driver = get_neo4j_nas_driver()

    builder = AsyncNeo4jNodeBuilder(
        node_schema=schema,
        driver=driver,
        pg_session_factory=AsyncSessionLocal,
    )

    await builder.create_constraint_async()

    await builder.run(
        batch_size=batch_size,
        max_concurrency=max_concurrency,
    )

    logger.info(f"🟢 [NAS] ETL Completed for node: {name}")


async def run_single_relationship_nas(
    name: str,
    schema: dict,
    batch_size: int = 500,
    max_concurrency: int = 5,
):
    """
    Full ETL for a single relationship: fetch + batch MERGE, targeting NAS DB.
    """
    logger.info(f"🔵 [NAS] Relationship ETL Started: {name}")

    driver = get_neo4j_nas_driver()

    builder = AsyncNeo4jRelationBuilder(
        rel_schema=schema,
        driver=driver,
        pg_session_factory=AsyncSessionLocal,
    )

    await builder.run(
        batch_size=batch_size,
        max_concurrency=max_concurrency,
    )

    logger.info(f"🟢 [NAS] Relationship ETL Completed: {name}")

# ---------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------

@router.post("/run-nodes")
async def run_all_nodes_nas(
    max_parallel_nodes: int = 3,
    batch_size: int = 2000,
    max_batch_concurrency: int = 5,
):
    """
    Triggers async ETL for all nodes defined in NAS node JSON.
    Executes ETL concurrently with concurrency limits.
    """
    try:
        node_schemas = load_node_schemas_nas()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"[NAS] Schema load failed: {e}")

    semaphore = asyncio.Semaphore(max_parallel_nodes)
    tasks = []

    async def run_with_limit(node_name, schema):
        async with semaphore:
            await run_single_node_nas(
                name=node_name,
                schema=schema,
                batch_size=batch_size,
                max_concurrency=max_batch_concurrency,
            )

    for name, schema in node_schemas.items():
        tasks.append(asyncio.create_task(run_with_limit(name, schema)))

    logger.info("🚀 [NAS] Starting ETL for ALL Neo4j nodes...")
    await asyncio.gather(*tasks)
    logger.info("🎉 [NAS] All nodes injected successfully!")

    return {
        "status": "success",
        "message": "[NAS] All Neo4j nodes ETL completed successfully.",
        "nodes_processed": list(node_schemas.keys()),
    }


@router.post("/run-relationships")
async def run_all_relationships_nas(
    max_parallel_relationships: int = 3,
    batch_size: int = 500,
    max_batch_concurrency: int = 5,
):
    """
    Triggers async ETL for all relationships defined in NAS relation JSON.
    """
    try:
        rel_schemas = load_relation_schemas_nas()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"[NAS] Relationship schema load failed: {e}")

    semaphore = asyncio.Semaphore(max_parallel_relationships)
    tasks = []

    async def run_with_limit(rel_name, schema):
        async with semaphore:
            await run_single_relationship_nas(
                name=rel_name,
                schema=schema,
                batch_size=batch_size,
                max_concurrency=max_batch_concurrency,
            )

    for name, schema in rel_schemas.items():
        tasks.append(asyncio.create_task(run_with_limit(name, schema)))

    logger.info("🚀 [NAS] Starting ETL for ALL Neo4j relationships...")
    await asyncio.gather(*tasks)
    logger.info("🎉 [NAS] All relationships injected successfully!")

    return {
        "status": "success",
        "message": "[NAS] All Neo4j relationships ETL completed successfully.",
        "relationships_processed": list(rel_schemas.keys()),
    }

# ---------------------------------------------------------------------
# CUSTOM VISIT + REVISIT INJECTION — NAS
# ---------------------------------------------------------------------

@router.post("/custom-injection")
async def custom_injection_nas(
    batch_size: int = 250,
):
    """
    Custom injection: Map Planned_Activity -> Session
    Creates (:Planned_Activity)-[:FOLLOWS_SESSION]->(:Session)
    """

    logger.info("🔗 [NAS] Starting custom Activity → Session mapping")

    driver = get_neo4j_nas_driver()

    # -------------------------------------------------------
    # 1) Fetch mapping data from Postgres
    # -------------------------------------------------------

    sql = text("""
        SELECT DISTINCT
            npoa.id AS activity_id,
            nslcd.id AS session_id
        FROM pwc_macro_staging_schema.stg_nas_planned_outage_activity npoa
        JOIN pwc_macro_staging_schema.stg_nas_session_level_combined_data nslcd
          ON npoa.nas_site_id = nslcd.nas_site_id
        WHERE
            npoa.nas_activity_start_date IS NOT NULL
            AND npoa.nas_activity_end_date IS NOT NULL
            AND nslcd.nas_session_create_time IS NOT NULL
            AND npoa.nas_activity_start_date::DATE
                <= nslcd.nas_session_create_time::DATE
            AND nslcd.nas_session_create_time::DATE
                <= npoa.nas_activity_end_date::DATE
    """)

    async with AsyncSessionLocal() as pg_session:
        result = await pg_session.execute(sql)
        rows = result.mappings().all()

    if not rows:
        logger.info("[NAS] No Activity → Session mappings found")
        return {
            "status": "success",
            "relationships_created": 0,
            "message": "No qualifying Activity–Session mappings found",
        }

    data = [dict(r) for r in rows]
    logger.info(f"[NAS] Retrieved {len(data)} Activity–Session pairs")

    # -------------------------------------------------------
    # 2) Cypher (SAFE: OPTIONAL MATCH + guard)
    # -------------------------------------------------------

    CYPHER = """
    UNWIND $rows AS row

    OPTIONAL MATCH (a:Planned_Activity {activity_id: row.activity_id})
    OPTIONAL MATCH (s:Session {session_id: row.session_id})

    WITH a, s
    WHERE a IS NOT NULL AND s IS NOT NULL

    MERGE (a)-[:FOLLOWS_SESSION]->(s)
    """

    # -------------------------------------------------------
    # 3) Batch execution (SEQUENTIAL to avoid deadlocks)
    # -------------------------------------------------------

    def chunker(seq, size):
        for i in range(0, len(seq), size):
            yield seq[i:i + size]

    batches = list(chunker(data, batch_size))
    total_created = 0

    async with driver.session() as session:
        for idx, batch in enumerate(batches, start=1):
            await session.execute_write(
                lambda tx: tx.run(CYPHER, rows=batch)
            )
            total_created += len(batch)
            logger.info(
                f"[NAS] FOLLOWS_SESSION batch {idx}/{len(batches)} processed "
                f"({len(batch)} rows)"
            )

    logger.info(
        f"✅ [NAS] Activity → Session mapping completed. "
        f"Total rows processed: {total_created}"
    )

    return {
        "status": "success",
        "relationships_processed": total_created,
        "relationship_type": "FOLLOWS_SESSION",
        "batch_size": batch_size,
    }

# ---------------------------------------------------------------------
# FULL SYNC — NAS
# ---------------------------------------------------------------------

@router.post("/sync-neo4j")
async def sync_neo4j_nas(
    node_batch_size: int = 2000,
    node_concurrency: int = 5,
    visit_batch_size: int = 1000,
    visit_concurrency: int = 4,
    relation_batch_size: int = 1000,
    relation_concurrency: int = 4,
    cleanup_chunk_size: int = 20000,
    cleanup_max_loops: int = 100,
    wipe_store: bool = False,
):
    """
    FULL NEO4J SYNC PIPELINE (NAS)
    """
    try:
        logger.info("🧹 [NAS] Cleaning Neo4j...")
        from app.api.endpoints.nas import cleanup_neo4j_nas
        cleanup_resp = await cleanup_neo4j_nas(
            chunk_size=cleanup_chunk_size,
            max_loops=cleanup_max_loops,
            wipe_store=wipe_store,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"[NAS] Cleanup failed: {e}")

    try:
        nodes_resp = await run_all_nodes_nas(
            batch_size=node_batch_size,
            max_batch_concurrency=node_concurrency,
            max_parallel_nodes=4,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"[NAS] Node ETL failed: {e}")

    try:
        visit_resp = await custom_injection_nas(
            batch_size=visit_batch_size,
            # max_parallel_batches=visit_concurrency,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"[NAS] Visit ETL failed: {e}")

    try:
        rel_resp = await run_all_relationships_nas(
            batch_size=relation_batch_size,
            max_batch_concurrency=relation_concurrency,
            max_parallel_relationships=4,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"[NAS] Relationship ETL failed: {e}")

    return {
        "status": "success",
        "message": "[NAS] Full Neo4j Sync Completed Successfully",
        "steps": {
            "cleanup": cleanup_resp,
            "general_nodes": nodes_resp,
            "custom_visit": visit_resp,
            "general_relationships": rel_resp
        }
    }

# ---------------------------------------------------------------------
# CLEANUP — NAS
# ---------------------------------------------------------------------

@router.delete("/cleanup-neo4j")
async def cleanup_neo4j_nas(
    chunk_size: int = 20000,
    max_loops: int = 100,
    wipe_store: bool = False,
):
    """
    Full Neo4j cleanup for the NAS database.
    """
    if wipe_store:
        return {
            "status": "manual_action_required",
            "message": "[NAS] To fully reset label/property tokens, follow:",
            "steps": [
                "1. Stop Neo4j",
                "2. Delete neostore files",
                "3. Restart Neo4j",
            ],
        }

    driver = get_neo4j_nas_driver()
    stats = {
        "constraints_dropped": 0,
        "indexes_dropped": 0,
        "nodes_deleted": 0,
        "passes": 0,
        "token_warning": (
            "Tokens persist in Community edition. They disappear only after offline wipe."
        ),
    }

    async with driver.session() as session:
        # Drop constraints
        try:
            result = await session.run("SHOW CONSTRAINTS YIELD name")
            constraint_names = [record["name"] async for record in result]
            for name in constraint_names:
                try:
                    await session.run(f"DROP CONSTRAINT `{name}`")
                    stats["constraints_dropped"] += 1
                except:
                    pass
        except:
            pass

        # Drop indexes
        try:
            result = await session.run("SHOW INDEXES YIELD name, type")
            index_names = [
                record["name"] async for record in result if record["type"] != "LOOKUP"
            ]
            for name in index_names:
                try:
                    await session.run(f"DROP INDEX `{name}`")
                    stats["indexes_dropped"] += 1
                except:
                    pass
        except:
            pass

        # Delete nodes in batches
        count_result = await session.run("MATCH (n) RETURN count(n) AS c")
        count_record = await count_result.single()
        remaining = count_record["c"]
        initial_count = remaining
        loops = 0

        while remaining > 0 and loops < max_loops:
            loops += 1
            await session.run("""
                MATCH (n) 
                WITH n LIMIT $limit 
                DETACH DELETE n
            """, {"limit": chunk_size})

            count_result = await session.run("MATCH (n) RETURN count(n) AS c")
            remaining = (await count_result.single())["c"]

        stats["nodes_deleted"] = initial_count - remaining
        stats["passes"] = loops

    return {
        "status": "success" if remaining == 0 else "partial",
        "message": "[NAS] Neo4j cleanup complete.",
        "stats": stats,
    }