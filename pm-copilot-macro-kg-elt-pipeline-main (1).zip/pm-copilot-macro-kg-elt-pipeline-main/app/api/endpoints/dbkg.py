#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from fastapi import APIRouter, HTTPException
import logging
import asyncio

from app.db.neo4j_database import (
    get_neo4j_db_driver,
    health_check_neo4j_db,
)

from app.services.dbkg.schema_extractor import (
    extract_tables_and_relationships,
    extract_columns,
    extract_kpis_and_table_links,
    extract_questions_and_table_links,
    extract_keywords_and_table_links,
)

SCHEMA_URL = (
    "https://pm-copilot-macro-gcl-osdp-gsd-gsd-delivery-staging."
    "aibi-americas-002.dyn.nesc.nokia.net/api/v1/dev/table-schema-builder"
)

# ---------------------------------------------------------------------
# Helper: Fetch JSON
# ---------------------------------------------------------------------

import aiohttp
from fastapi import HTTPException
from aiohttp import BasicAuth

async def fetch_schema_json() -> dict:
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                SCHEMA_URL,
                auth=BasicAuth("anython", "pwc_macro_team")
            ) as resp:

                if resp.status != 200:
                    raise HTTPException(
                        status_code=500,
                        detail=f"Schema fetch failed with HTTP {resp.status}"
                    )

                return await resp.json()

    except Exception as e:
        logger.error(f"❌ Failed to fetch schema JSON: {e}")
        raise HTTPException(status_code=500, detail=str(e))

router = APIRouter(
    prefix="/dbkg",
    tags=["Database Schema KG ETL"]
)

logger = logging.getLogger(__name__)


# -------------------------------------------------------------------
# ✅ Async Neo4j Write Helpers
# -------------------------------------------------------------------

async def async_run(session, cypher: str, params: dict = None):
    """Safely run async Cypher"""
    await session.run(cypher, params or {})


async def ensure_constraints(session):
    await async_run(session, """
        CREATE CONSTRAINT table_name_unique IF NOT EXISTS
        FOR (t:Table) REQUIRE t.name IS UNIQUE
    """)
    await async_run(session, """
        CREATE CONSTRAINT column_unique IF NOT EXISTS
        FOR (c:Column) REQUIRE (c.table, c.name) IS UNIQUE
    """)
    await async_run(session, """
        CREATE CONSTRAINT kpi_unique IF NOT EXISTS
        FOR (k:KPI) REQUIRE k.name IS UNIQUE
    """)
    await async_run(session, """
        CREATE CONSTRAINT question_unique IF NOT EXISTS
        FOR (q:Question) REQUIRE q.name IS UNIQUE
    """)
    await async_run(session, """
        CREATE CONSTRAINT keyword_unique IF NOT EXISTS
        FOR (kw:Keyword) REQUIRE kw.name IS UNIQUE
    """)


async def write_tables(session, rows):
    await async_run(session, """
        UNWIND $rows AS row
        MERGE (t:Table {name: row.name})
        SET t.column_count = row.column_count,
            t.kpi_count = row.kpi_count,
            t.question_count = row.question_count,
            t.keyword_count = row.keyword_count
    """, {"rows": rows})


async def write_relationships(session, rows):
    if not rows:
        return
    await async_run(session, """
        UNWIND $rels AS rel
        MATCH (src:Table {name: rel.source})
        MATCH (dst:Table {name: rel.target})
        MERGE (src)-[r:RELATED_TO]->(dst)
        SET r.shared_columns = rel.shared_columns,
            r.shared_column_count = rel.shared_column_count,
            r.affinity_score = rel.affinity_score
    """, {"rels": rows})


async def write_columns(session, rows):
    await async_run(session, """
        UNWIND $rows AS row
        MERGE (c:Column {table: row.table, name: row.name})
        SET c.ordinal = row.ordinal
    """, {"rows": rows})


async def write_table_column_relationships(session, rows):
    await async_run(session, """
        UNWIND $rels AS rel
        MATCH (t:Table {name: rel.table})
        MATCH (c:Column {table: rel.table, name: rel.name})
        MERGE (t)-[:HAS_COL]->(c)
    """, {"rels": rows})


async def write_kpis(session, rows):
    await async_run(session, """
        UNWIND $rows AS row
        MERGE (k:KPI {name: row.name})
        SET k.description = row.description,
            k.formula = row.formula,
            k.logic = row.logic,
            k.total_columns_extracted = row.total_columns_extracted,
            k.matched_count = row.matched_count,
            k.coverage_pct = row.coverage_pct,
            k.can_execute = row.can_execute
    """, {"rows": rows})


async def write_table_kpi_relationships(session, rows):
    await async_run(session, """
        UNWIND $rels AS rel
        MATCH (t:Table {name: rel.table})
        MATCH (k:KPI {name: rel.kpi})
        MERGE (t)-[r:INVOLVES]->(k)
        SET r.matched_columns = rel.matched_columns
    """, {"rels": rows})


async def write_questions(session, rows):
    await async_run(session, """
        UNWIND $rows AS row
        MERGE (q:Question {name: row.name})
        SET q.sql = row.sql,
            q.total_columns_extracted = row.total_columns_extracted,
            q.matched_count = row.matched_count,
            q.coverage_pct = row.coverage_pct,
            q.can_execute = row.can_execute
    """, {"rows": rows})


async def write_table_question_relationships(session, rows):
    await async_run(session, """
        UNWIND $rels AS rel
        MATCH (t:Table {name: rel.table})
        MATCH (q:Question {name: rel.question})
        MERGE (t)-[r:SUPPORTS]->(q)
        SET r.matched_columns = rel.matched_columns
    """, {"rels": rows})


async def write_keywords(session, rows):
    await async_run(session, """
        UNWIND $rows AS row
        MERGE (kw:Keyword {name: row.name})
        SET kw.description = row.description,
            kw.synonyms = row.synonyms,
            kw.total_columns_extracted = row.total_columns_extracted,
            kw.matched_count = row.matched_count,
            kw.coverage_pct = row.coverage_pct,
            kw.can_execute = row.can_execute
    """, {"rows": rows})


async def write_table_keyword_relationships(session, rows):
    await async_run(session, """
        UNWIND $rels AS rel
        MATCH (t:Table {name: rel.table})
        MATCH (kw:Keyword {name: rel.keyword})
        MERGE (t)-[r:HAS_KEYWORD]->(kw)
        SET r.matched_columns = rel.matched_columns
    """, {"rels": rows})


# -------------------------------------------------------------------
# ✅ Main ETL Function
# -------------------------------------------------------------------

async def run_etl_pipeline(schema_json: dict):
    logger.info("✅ Processing table schema...")

    tables, table_rels = extract_tables_and_relationships(schema_json)
    known_tables = {t["name"] for t in tables}

    columns, table_column_rels = extract_columns(schema_json)
    kpis, table_kpi_rels = extract_kpis_and_table_links(schema_json, known_tables)
    questions, table_question_rels = extract_questions_and_table_links(schema_json, known_tables)
    keywords, table_keyword_rels = extract_keywords_and_table_links(schema_json, known_tables)

    driver = get_neo4j_db_driver()

    async with driver.session() as session:
        await ensure_constraints(session)

        await write_tables(session, tables)
        await write_columns(session, columns)
        await write_kpis(session, kpis)
        await write_questions(session, questions)
        await write_keywords(session, keywords)

        await write_relationships(session, table_rels)
        await write_table_column_relationships(session, table_column_rels)
        await write_table_kpi_relationships(session, table_kpi_rels)
        await write_table_question_relationships(session, table_question_rels)
        await write_table_keyword_relationships(session, table_keyword_rels)

    logger.info("✅ ETL complete: Graph successfully updated.")


# -------------------------------------------------------------------
# ✅ Router Endpoints
# -------------------------------------------------------------------

@router.get("/health")
async def etl_health():
    ok = await health_check_neo4j_db()
    return {"neo4j_db_ok": ok}


@router.post("/sync-schema")
async def sync_schema():
    """
    Fetch table schema JSON and load into Neo4j asynchronously.
    """
    logger.info("🚀 Starting schema sync ETL job...")

    schema_json = await fetch_schema_json()
    if not schema_json:
        raise HTTPException(status_code=500, detail="Schema JSON empty or invalid")

    await run_etl_pipeline(schema_json)

    return {"status": "success", "message": "Graph DB updated from schema JSON."}


# ---------------------------------------------------------------------
# ✅ CLEANUP ENDPOINT
# ---------------------------------------------------------------------

@router.delete("/cleanup")
async def cleanup_dbkg(
    chunk_size: int = 20000,
    max_loops: int = 100
):
    """
    Cleanup Neo4j_DB:
    - Drop constraints
    - Drop non-lookup indexes
    - DETACH DELETE all nodes in batches
    """

    driver = get_neo4j_db_driver()
    stats = {
        "constraints_removed": 0,
        "indexes_removed": 0,
        "nodes_deleted": 0,
        "passes": 0
    }

    async with driver.session() as session:

        # Drop constraints
        result = await session.run("SHOW CONSTRAINTS YIELD name")
        names = [r["name"] async for r in result]

        for name in names:
            try:
                await session.run(f"DROP CONSTRAINT `{name}`")
                stats["constraints_removed"] += 1
            except:
                pass

        # Drop indexes
        result = await session.run("SHOW INDEXES YIELD name, type")
        idx_names = [r["name"] async for r in result if r["type"] != "LOOKUP"]

        for name in idx_names:
            try:
                await session.run(f"DROP INDEX `{name}`")
                stats["indexes_removed"] += 1
            except:
                pass

        # DELETE nodes in batches
        count_res = await session.run("MATCH (n) RETURN count(n) as c")
        remaining = (await count_res.single())["c"]

        loops = 0
        while remaining > 0 and loops < max_loops:
            loops += 1
            await session.run("""
                MATCH (n)
                WITH n LIMIT $limit
                DETACH DELETE n
            """, {"limit": chunk_size})

            count_res = await session.run("MATCH (n) RETURN count(n) as c")
            new_remaining = (await count_res.single())["c"]

            if new_remaining >= remaining:  # Stuck
                break

            remaining = new_remaining

        stats["nodes_deleted"] = remaining
        stats["passes"] = loops

    return {
        "status": "success",
        "message": "DB Schema KG cleaned successfully.",
        "stats": stats,
    }