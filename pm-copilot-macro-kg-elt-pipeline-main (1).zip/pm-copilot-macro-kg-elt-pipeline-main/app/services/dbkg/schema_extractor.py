#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Schema extraction utilities for Macro-Phasewise KG ETL.
This file is imported by etl_router.py.

Includes extraction of:
- Tables
- Table-to-table relationships
- Columns
- KPIs
- Questions
- Keywords
"""

from typing import Any, Dict, List, Tuple


# -------------------------------------------------------------------
# ✅ TABLE + RELATIONSHIP EXTRACTION
# -------------------------------------------------------------------

def extract_tables_and_relationships(schema: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    Extract:
      - tables: name, column_count, kpi_count, question_count, keyword_count
      - table→table relationships (affinity_score > 0.5)
    """
    if "table_schema_map" not in schema:
        raise ValueError("JSON missing 'table_schema_map' key")

    tsm = schema["table_schema_map"]
    tables_dict = tsm.get("tables", {})

    table_nodes = []
    for table_name, tdef in tables_dict.items():
        if not isinstance(tdef, dict):
            continue

        column_count = tdef.get("column_count")
        if not isinstance(column_count, int) and column_count is not None:
            try:
                column_count = int(column_count)
            except Exception:
                column_count = None

        # Compute counts
        kpi_count = len(tdef.get("kpis", [])) if isinstance(tdef.get("kpis"), list) else 0
        question_count = len(tdef.get("questions", [])) if isinstance(tdef.get("questions"), list) else 0
        keyword_count = len(tdef.get("keywords", [])) if isinstance(tdef.get("keywords"), list) else 0

        table_nodes.append({
            "name": table_name,
            "column_count": column_count,
            "kpi_count": kpi_count,
            "question_count": question_count,
            "keyword_count": keyword_count,
        })

    # Build table relationships
    table_names_set = {t["name"] for t in table_nodes}
    relationships = []

    for source_name, tdef in tables_dict.items():
        if not isinstance(tdef, dict):
            continue

        rels = tdef.get("related_tables", [])
        if not isinstance(rels, list):
            continue

        for rel in rels:
            target = rel.get("table_name")
            if not target or target not in table_names_set:
                continue

            shared_columns = rel.get("shared_columns", [])
            shared_column_count = rel.get("shared_column_count")
            affinity_score = rel.get("affinity_score")

            if not isinstance(shared_columns, list):
                shared_columns = []

            try:
                affinity_score = float(affinity_score)
            except:
                continue

            if affinity_score <= 0.5:
                continue  # filter weak relationships

            try:
                shared_column_count = int(shared_column_count)
            except:
                shared_column_count = None

            relationships.append({
                "source": source_name,
                "target": target,
                "shared_columns": shared_columns,
                "shared_column_count": shared_column_count,
                "affinity_score": affinity_score
            })

    return table_nodes, relationships


# -------------------------------------------------------------------
# ✅ COLUMN EXTRACTION
# -------------------------------------------------------------------

def extract_columns(schema: Dict[str, Any]):
    column_nodes = []
    table_column_rels = []

    tables_dict = schema.get("table_schema_map", {}).get("tables", {})

    for table_name, tdef in tables_dict.items():
        cols = tdef.get("columns", [])
        if not isinstance(cols, list):
            cols = [str(cols)]

        for idx, col in enumerate(cols, start=1):
            col_name = str(col)
            column_nodes.append({
                "table": table_name,
                "name": col_name,
                "ordinal": idx
            })
            table_column_rels.append({
                "table": table_name,
                "name": col_name
            })

    return column_nodes, table_column_rels


# -------------------------------------------------------------------
# ✅ KPI EXTRACTION
# -------------------------------------------------------------------

def extract_kpis_and_table_links(schema, known_tables=None):
    kpi_nodes = []
    table_kpi_rels = []

    tsm = schema.get("table_schema_map", {})
    kpi_index = tsm.get("kpi_index", {})

    if not isinstance(kpi_index, dict):
        return kpi_nodes, table_kpi_rels

    for kpi_name, kd in kpi_index.items():
        if not isinstance(kd, dict):
            continue

        description = kd.get("description")
        formula = kd.get("formula")
        logic = kd.get("logic")

        validation = kd.get("validation", {}) or {}
        total_columns_extracted = validation.get("total_columns_extracted")
        matched_count = validation.get("matched_count")
        coverage_pct = validation.get("coverage_pct")
        can_execute = validation.get("can_execute")

        try:
            total_columns_extracted = int(total_columns_extracted) if total_columns_extracted else None
        except:
            total_columns_extracted = None

        try:
            matched_count = int(matched_count) if matched_count else None
        except:
            matched_count = None

        try:
            coverage_pct = float(coverage_pct) if coverage_pct else None
        except:
            coverage_pct = None

        if isinstance(can_execute, str):
            can_execute = can_execute.lower() in ("true", "1", "yes")

        kpi_nodes.append({
            "name": kpi_name,
            "description": description,
            "formula": formula,
            "logic": logic,
            "total_columns_extracted": total_columns_extracted,
            "matched_count": matched_count,
            "coverage_pct": coverage_pct,
            "can_execute": can_execute
        })

        tables_involved = kd.get("tables_involved", [])
        if not isinstance(tables_involved, list):
            tables_involved = [str(tables_involved)]

        matched_by_table = kd.get("matched_columns_by_table", {})
        if not isinstance(matched_by_table, dict):
            matched_by_table = {}

        for tbl in tables_involved:
            tbl_name = str(tbl)
            if known_tables and tbl_name not in known_tables:
                continue

            matched = matched_by_table.get(tbl_name, [])
            if not isinstance(matched, list):
                matched = [matched]

            table_kpi_rels.append({
                "table": tbl_name,
                "kpi": kpi_name,
                "matched_columns": matched
            })

    return kpi_nodes, table_kpi_rels


# -------------------------------------------------------------------
# ✅ QUESTION EXTRACTION
# -------------------------------------------------------------------

def extract_questions_and_table_links(schema, known_tables=None):
    question_nodes = []
    table_question_rels = []

    tsm = schema.get("table_schema_map", {})
    question_index = tsm.get("question_index", {})

    if not isinstance(question_index, dict):
        return question_nodes, table_question_rels

    for question_text, qd in question_index.items():
        if not isinstance(qd, dict):
            continue

        sql = qd.get("sql")
        validation = qd.get("validation", {}) or {}

        total_columns_extracted = validation.get("total_columns_extracted")
        matched_count = validation.get("matched_count")
        coverage_pct = validation.get("coverage_pct")
        can_execute = validation.get("can_execute")

        try:
            total_columns_extracted = int(total_columns_extracted) if total_columns_extracted else None
        except:
            total_columns_extracted = None

        try:
            matched_count = int(matched_count) if matched_count else None
        except:
            matched_count = None

        try:
            coverage_pct = float(coverage_pct) if coverage_pct else None
        except:
            coverage_pct = None

        if isinstance(can_execute, str):
            can_execute = can_execute.lower() in ("true", "1", "yes")

        question_nodes.append({
            "name": question_text,
            "sql": sql,
            "total_columns_extracted": total_columns_extracted,
            "matched_count": matched_count,
            "coverage_pct": coverage_pct,
            "can_execute": can_execute,
        })

        tables_involved = qd.get("tables_involved", [])
        if not isinstance(tables_involved, list):
            tables_involved = [tables_involved]

        matched_by_table = qd.get("matched_columns_by_table", {})
        if not isinstance(matched_by_table, dict):
            matched_by_table = {}

        for tbl in tables_involved:
            tbl_name = str(tbl)
            if known_tables and tbl_name not in known_tables:
                continue

            matched = matched_by_table.get(tbl_name, [])
            if not isinstance(matched, list):
                matched = [matched]

            table_question_rels.append({
                "table": tbl_name,
                "question": question_text,
                "matched_columns": matched
            })

    return question_nodes, table_question_rels


# -------------------------------------------------------------------
# ✅ KEYWORD EXTRACTION
# -------------------------------------------------------------------

def extract_keywords_and_table_links(schema, known_tables=None):
    keyword_nodes = []
    table_keyword_rels = []

    tsm = schema.get("table_schema_map", {})
    keyword_index = tsm.get("keyword_index", {})

    if not isinstance(keyword_index, dict):
        return keyword_nodes, table_keyword_rels

    # Normalize synonyms: supports string, list, newline, comma-separated
    def normalize_synonyms(value):
        if value is None:
            return []
        if isinstance(value, list):
            return [str(v).strip() for v in value if v]

        raw = str(value)
        parts = []
        for chunk in raw.replace("\r", "").split("\n"):
            parts.extend(chunk.split(","))
        return [p.strip() for p in parts if p.strip()]

    for keyword_name, kd in keyword_index.items():
        description = kd.get("description")
        synonyms = normalize_synonyms(kd.get("synonyms"))

        validation = kd.get("validation", {}) or {}
        total_columns_extracted = validation.get("total_columns_extracted")
        matched_count = validation.get("matched_count")
        coverage_pct = validation.get("coverage_pct")
        can_execute = validation.get("can_execute")

        try:
            total_columns_extracted = int(total_columns_extracted) if total_columns_extracted else None
        except:
            total_columns_extracted = None

        try:
            matched_count = int(matched_count) if matched_count else None
        except:
            matched_count = None

        try:
            coverage_pct = float(coverage_pct) if coverage_pct else None
        except:
            coverage_pct = None

        if isinstance(can_execute, str):
            can_execute = can_execute.lower() in ("true", "1", "yes")

        keyword_nodes.append({
            "name": keyword_name,
            "description": description,
            "synonyms": synonyms,
            "total_columns_extracted": total_columns_extracted,
            "matched_count": matched_count,
            "coverage_pct": coverage_pct,
            "can_execute": can_execute
        })

        tables_involved = kd.get("tables_involved", [])
        if not isinstance(tables_involved, list):
            tables_involved = [tables_involved]

        matched_by_table = kd.get("matched_columns_by_table", {})
        if not isinstance(matched_by_table, dict):
            matched_by_table = {}

        for tbl in tables_involved:
            tbl_name = str(tbl)
            if known_tables and tbl_name not in known_tables:
                continue

            matched = matched_by_table.get(tbl_name, [])
            if not isinstance(matched, list):
                matched = [matched]

            table_keyword_rels.append({
                "table": tbl_name,
                "keyword": keyword_name,
                "matched_columns": matched
            })

    return keyword_nodes, table_keyword_rels