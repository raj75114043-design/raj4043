"""
Schema Loader for Database Schema Knowledge Graph
Author: Advait Shah (PwC India)
Client: Nokia

This module exposes pure functions used by the DB-KG ETL router:

- extract_tables_and_relationships
- extract_columns
- extract_kpis_and_table_links
- extract_questions_and_table_links
- extract_keywords_and_table_links

These functions take the JSON schema as input and output lists of nodes
and relationship records ready to be written into Neo4j.
"""

from typing import Dict, Any, List, Tuple, Optional, Set


# ============================================================
# ✅ TABLES + TABLE→TABLE RELATIONSHIPS
# ============================================================

def extract_tables_and_relationships(
    schema: Dict[str, Any]
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:

    if "table_schema_map" not in schema:
        raise ValueError("JSON missing 'table_schema_map'")

    tsm = schema["table_schema_map"]
    tables_dict = tsm.get("tables", {})

    table_nodes = []
    for table_name, tdef in tables_dict.items():
        if not isinstance(tdef, dict):
            continue

        col_count = tdef.get("column_count")
        try:
            col_count = int(col_count) if col_count is not None else None
        except:
            col_count = None

        table_nodes.append({
            "name": table_name,
            "column_count": col_count
        })

    table_names = {t["name"] for t in table_nodes}
    relationships = []

    for src, tdef in tables_dict.items():
        rels = tdef.get("related_tables", [])
        if not isinstance(rels, list):
            continue

        for rel in rels:
            target = rel.get("table_name")
            if not target or target not in table_names:
                continue

            shared = rel.get("shared_columns", [])
            if not isinstance(shared, list):
                shared = [] if shared is None else [str(shared)]

            shared_count = rel.get("shared_column_count")
            try:
                shared_count = int(shared_count) if shared_count else None
            except:
                shared_count = None

            affinity = rel.get("affinity_score")
            try:
                affinity = float(affinity)
            except:
                continue

            # Filter: score > 0.5
            if affinity <= 0.5:
                continue

            relationships.append({
                "source": src,
                "target": target,
                "shared_columns": [str(x) for x in shared],
                "shared_column_count": shared_count,
                "affinity_score": affinity
            })

    return table_nodes, relationships


# ============================================================
# ✅ COLUMNS + TABLE→COLUMN
# ============================================================

def extract_columns(schema: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:

    tsm = schema.get("table_schema_map", {})
    tables_dict = tsm.get("tables", {})

    columns = []
    table_column_rels = []

    for table_name, tdef in tables_dict.items():
        cols = tdef.get("columns", []) or []
        if not isinstance(cols, list):
            cols = [str(cols)]

        for idx, col in enumerate(cols, start=1):
            col_name = str(col)
            columns.append({
                "table": table_name,
                "name": col_name,
                "ordinal": idx,
            })
            table_column_rels.append({
                "table": table_name,
                "name": col_name,
            })

    return columns, table_column_rels


# ============================================================
# ✅ KPIs + TABLE→KPI
# ============================================================

def extract_kpis_and_table_links(
    schema: Dict[str, Any],
    known_tables: Optional[Set[str]] = None
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:

    tsm = schema.get("table_schema_map", {})
    kpi_index = tsm.get("kpi_index", {})

    kpis = []
    rels = []

    for kpi_name, kd in kpi_index.items():
        if not isinstance(kd, dict):
            continue

        validation = kd.get("validation", {}) or {}

        def _num(val, cast):
            try:
                return cast(val) if val is not None else None
            except:
                return None

        kpis.append({
            "name": str(kpi_name),
            "description": kd.get("description"),
            "formula": kd.get("formula"),
            "logic": kd.get("logic"),
            "total_columns_extracted": _num(validation.get("total_columns_extracted"), int),
            "matched_count": _num(validation.get("matched_count"), int),
            "coverage_pct": _num(validation.get("coverage_pct"), float),
            "can_execute": (
                validation.get("can_execute") in ("true", "True", True, 1, "1", "yes")
            )
        })

        tables_involved = kd.get("tables_involved", []) or []
        if not isinstance(tables_involved, list):
            tables_involved = [tables_involved]

        matched_by_table = kd.get("matched_columns_by_table", {}) or {}

        for tbl in tables_involved:
            tbl = str(tbl)
            if known_tables and tbl not in known_tables:
                continue

            matched = matched_by_table.get(tbl, [])
            if not isinstance(matched, list):
                matched = [matched]

            rels.append({
                "table": tbl,
                "kpi": str(kpi_name),
                "matched_columns": [str(x) for x in matched]
            })

    return kpis, rels


# ============================================================
# ✅ QUESTIONS + TABLE→QUESTION
# ============================================================

def extract_questions_and_table_links(
    schema: Dict[str, Any],
    known_tables: Optional[Set[str]] = None
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:

    tsm = schema.get("table_schema_map", {})
    qidx = tsm.get("question_index", {})

    questions = []
    rels = []

    for question, qd in qidx.items():
        if not isinstance(qd, dict):
            continue

        validation = qd.get("validation", {}) or {}

        def _num(val, cast):
            try:
                return cast(val) if val is not None else None
            except:
                return None

        questions.append({
            "name": str(question),
            "sql": qd.get("sql"),
            "total_columns_extracted": _num(validation.get("total_columns_extracted"), int),
            "matched_count": _num(validation.get("matched_count"), int),
            "coverage_pct": _num(validation.get("coverage_pct"), float),
            "can_execute": (
                validation.get("can_execute") in ("true", "True", True, 1, "1", "yes")
            )
        })

        tables_involved = qd.get("tables_involved", []) or []
        if not isinstance(tables_involved, list):
            tables_involved = [tables_involved]

        matched_by_table = qd.get("matched_columns_by_table", {}) or {}

        for tbl in tables_involved:
            tbl = str(tbl)
            if known_tables and tbl not in known_tables:
                continue

            matched = matched_by_table.get(tbl, [])
            if not isinstance(matched, list):
                matched = [matched]

            rels.append({
                "table": tbl,
                "question": str(question),
                "matched_columns": [str(x) for x in matched]
            })

    return questions, rels


# ============================================================
# ✅ KEYWORDS + TABLE→KEYWORD
# ============================================================

def _normalize_synonyms(value: Any) -> List[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(x).strip() for x in value if str(x).strip()]
    # string → split
    raw = str(value).replace("\r", "")
    out = []
    for line in raw.split("\n"):
        for part in line.split(","):
            part = part.strip()
            if part:
                out.append(part)
    return out


def extract_keywords_and_table_links(
    schema: Dict[str, Any],
    known_tables: Optional[Set[str]] = None
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:

    tsm = schema.get("table_schema_map", {})
    kwidx = tsm.get("keyword_index", {})

    keywords = []
    rels = []

    for keyword, kd in kwidx.items():
        if not isinstance(kd, dict):
            continue

        validation = kd.get("validation", {}) or {}

        def _num(val, cast):
            try:
                return cast(val) if val is not None else None
            except:
                return None

        keywords.append({
            "name": str(keyword),
            "description": kd.get("description"),
            "synonyms": _normalize_synonyms(kd.get("synonyms")),
            "total_columns_extracted": _num(validation.get("total_columns_extracted"), int),
            "matched_count": _num(validation.get("matched_count"), int),
            "coverage_pct": _num(validation.get("coverage_pct"), float),
            "can_execute": (
                validation.get("can_execute") in ("true", "True", True, 1, "1", "yes")
            )
        })

        tables_involved = kd.get("tables_involved", []) or []
        if not isinstance(tables_involved, list):
            tables_involved = [tables_involved]

        matched_by_table = kd.get("matched_columns_by_table", {}) or {}

        for tbl in tables_involved:
            tbl = str(tbl)
            if known_tables and tbl not in known_tables:
                continue

            matched = matched_by_table.get(tbl, [])
            if not isinstance(matched, list):
                matched = [matched]

            rels.append({
                "table": tbl,
                "keyword": str(keyword),
                "matched_columns": [str(x) for x in matched]
            })

    return keywords, rels