"""
Async Neo4j Relationship ETL Builder
Author: Advait Shah (PwC India)
Client: Nokia
"""

from typing import Any, Dict, List, Optional
import pandas as pd
import logging
import asyncio

from sqlalchemy.ext.asyncio import AsyncSession
from neo4j import AsyncGraphDatabase
from sqlalchemy import text

logger = logging.getLogger(__name__)


class AsyncNeo4jRelationBuilder:
    """
    Fully async version of the relationship ETL builder.
    """

    def __init__(
        self,
        rel_schema: Dict[str, Any],
        driver,
        pg_session_factory,
    ):
        self.rel_type: str = rel_schema["type"]
        self.from_node: str = rel_schema["from_node"]
        self.from_key: Optional[str] = rel_schema.get("from_key") or None
        self.to_node: str = rel_schema["to_node"]
        self.to_key: Optional[str] = rel_schema.get("to_key") or None
        self.sql_etl: str = rel_schema["SQL_ETL"]

        self.driver = driver
        self.pg_session_factory = pg_session_factory

        self.properties: List[str] = []
        self._cypher: Optional[str] = None

    # ----------------------------------------------------------------------
    # Async Data Fetch
    # ----------------------------------------------------------------------

    async def fetch_data_async(self) -> pd.DataFrame:
        """
        Fetch SQL result asynchronously and classify columns into:
        - from_key
        - to_key
        - relationship properties
        """

        async with self.pg_session_factory() as session:
            result = await session.execute(text(self.sql_etl))
            rows = result.mappings().all()
            df = pd.DataFrame(rows)

        # Validate key columns if expected
        declared_keys = {k for k in [self.from_key, self.to_key] if k}

        for k in declared_keys:
            if k not in df.columns:
                raise ValueError(
                    f"[{self.rel_type}] Missing key column '{k}' in SQL results"
                )

        # Derive relationship properties
        self.properties = [c for c in df.columns if c not in declared_keys]

        df = df.where(pd.notnull(df), None)

        # Drop duplicates
        if declared_keys:
            before = len(df)
            df = df.drop_duplicates(subset=list(declared_keys))
            dropped = before - len(df)
            if dropped:
                logger.info(
                    f"[{self.rel_type}] Dropped {dropped} duplicate relationships"
                )

        logger.info(f"[{self.rel_type}] Fetched {len(df)} rows from Postgres")
        return df

    # ----------------------------------------------------------------------
    # Cypher Query Builder (Async)
    # ----------------------------------------------------------------------

    def build_query(self) -> str:
        if self._cypher:
            return self._cypher

        # BUILD MATCH CLAUSES
        if self.from_key:
            from_match = f"MATCH (a:{self.from_node} {{{self.from_key}: row.{self.from_key}}})"
        else:
            from_match = f"MATCH (a:{self.from_node})"

        if self.to_key:
            to_match = f"MATCH (b:{self.to_node} {{{self.to_key}: row.{self.to_key}}})"
        else:
            to_match = f"MATCH (b:{self.to_node})"

        # MERGE RELATIONSHIP
        merge_clause = f"MERGE (a)-[r:{self.rel_type}]->(b)"

        # SET properties
        set_clause = ""
        if self.properties:
            sets = ", ".join([f"r.{p} = row.{p}" for p in self.properties])
            set_clause = f"SET {sets}"

        query = (
            "UNWIND $rows AS row\n"
            f"{from_match}\n"
            f"{to_match}\n"
            f"{merge_clause}\n"
            f"{set_clause}"
        )

        self._cypher = query.strip()
        return self._cypher

    # ----------------------------------------------------------------------
    # Async Batch Inject
    # ----------------------------------------------------------------------

    async def _inject_single_batch(self, batch, batch_idx):
        cypher = self.build_query()

        try:
            async with self.driver.session() as session:
                await session.execute_write(
                    lambda tx: tx.run(cypher, rows=batch)
                )
            return len(batch), None

        except Exception as e:
            return 0, e

    async def inject_batches(
        self,
        df: pd.DataFrame,
        batch_size: int = 800,
        max_concurrency: int = 6
    ):
        """
        Pure async batch ETL using asyncio.gather and semaphores.
        """

        if df.empty:
            logger.info(f"[{self.rel_type}] No rows — skipping")
            return

        records = df.to_dict(orient="records")
        batches = [
            records[i:i+batch_size]
            for i in range(0, len(records), batch_size)
        ]

        sem = asyncio.Semaphore(max_concurrency)
        tasks = []

        async def _bounded_inject(batch, idx):
            async with sem:
                return await self._inject_single_batch(batch, idx)

        # Schedule tasks
        for idx, batch in enumerate(batches):
            tasks.append(asyncio.create_task(_bounded_inject(batch, idx)))

        results = await asyncio.gather(*tasks)

        total = sum(r[0] for r in results)
        logger.info(f"[{self.rel_type}] Completed: {total} rows")

    # ----------------------------------------------------------------------
    # Full ETL Runner
    # ----------------------------------------------------------------------

    async def run(self, batch_size=800, max_concurrency=6):
        df = await self.fetch_data_async()
        await self.inject_batches(df, batch_size, max_concurrency)