"""
Async Neo4j ETL Node Builder (Production Grade)
Author: Advait Shah (PwC India)
Client: Nokia
"""

from typing import Any, Dict, List, Optional
import pandas as pd
import logging
import asyncio

from neo4j import AsyncGraphDatabase, AsyncTransaction
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

logger = logging.getLogger(__name__)


class AsyncNeo4jNodeBuilder:
    """
    Fully async ETL processor for a single Neo4j node type.

    Responsibilities:
      1. fetch_data_async()  -> async Postgres -> DataFrame
      2. build_query()       -> prepare UNWIND Cypher
      3. inject_batches()    -> async parallel batch injection using asyncio.gather
      4. run()               -> full ETL pipeline

    Args:
        node_schema: Definition of node mapping (label, pk, properties, SQL_ETL)
        driver: Async Neo4j driver instance (AsyncGraphDatabase.driver)
        pg_session_factory: Callable that returns an AsyncSession object
    """

    def __init__(
        self,
        node_schema: Dict[str, Any],
        driver,
        pg_session_factory
    ):
        self.label = node_schema["label"]
        self.primary_key = node_schema["primary_key"]

        # uniquely ordered properties
        seen = set()
        self.properties = []
        for p in node_schema.get("properties", []):
            if p not in seen:
                seen.add(p)
                self.properties.append(p)

        self.sql_etl = node_schema["SQL_ETL"]
        self.driver = driver                  # async Neo4j driver
        self.pg_session_factory = pg_session_factory  # async Postgres session factory

        self.required_columns = list(
            dict.fromkeys([self.primary_key] + self.properties)
        )

        self._cypher: Optional[str] = None

    # ------------------------------------------------------------------
    # 0. Constraint Creation (ASYNC)
    # ------------------------------------------------------------------

    async def create_constraint_async(self) -> None:
        """
        Create uniqueness constraint for the primary key.
        """
        constraint_query = (
            f"CREATE CONSTRAINT {self.label}_{self.primary_key}_unique IF NOT EXISTS\n"
            f"FOR (n:{self.label})\n"
            f"REQUIRE n.{self.primary_key} IS UNIQUE"
        )

        async with self.driver.session() as session:
            await session.execute_write(
                lambda tx: tx.run(constraint_query)
            )

        logger.info(f"[{self.label}] Constraint ensured for {self.primary_key}")

    # ------------------------------------------------------------------
    # 1. Async Data fetch from Postgres
    # ------------------------------------------------------------------

    async def fetch_data_async(self) -> pd.DataFrame:
        """
        Run SQL asynchronously using AsyncSession and return a cleaned DF.
        """

        async with self.pg_session_factory() as session:
            result = await session.execute(text(self.sql_etl))
            rows = result.mappings().all()
            df = pd.DataFrame(rows)

        if df.empty:
            logger.warning(f"[{self.label}] SQL returned 0 rows.")
            return df

        # validate columns
        missing = [c for c in self.required_columns if c not in df.columns]
        if missing:
            raise ValueError(
                f"[{self.label}] Missing columns from Postgres: {missing}"
            )

        df = df[self.required_columns].copy()
        df = df.where(pd.notnull(df), None)

        before = len(df)
        df = df.drop_duplicates(subset=[self.primary_key])
        dropped = before - len(df)

        if dropped:
            logger.info(
                f"[{self.label}] Dropped {dropped} duplicate rows on PK {self.primary_key}"
            )

        logger.info(f"[{self.label}] Fetched {len(df)} rows from Postgres.")
        return df

    # ------------------------------------------------------------------
    # 2. Build Cypher Query
    # ------------------------------------------------------------------

    def build_query(self) -> str:
        """
        Build the async UNWIND MERGE Cypher query.
        """

        if self._cypher:
            return self._cypher

        pk = self.primary_key

        self._cypher = (
            f"UNWIND $rows AS row\n"
            f"MERGE (n:{self.label} {{{pk}: row.{pk}}})\n"
            f"SET n += row"
        )

        return self._cypher

    # ------------------------------------------------------------------
    # 3. Batch Splitting
    # ------------------------------------------------------------------

    def _split_batches(
        self, df: pd.DataFrame, batch_size: int
    ) -> List[List[Dict[str, Any]]]:

        records = df.to_dict(orient="records")

        norm = [
            {col: row.get(col, None) for col in self.required_columns}
            for row in records
        ]

        return [
            norm[i: i + batch_size]
            for i in range(0, len(norm), batch_size)
        ]

    # ------------------------------------------------------------------
    # 4. Inject a single batch (async)
    # ------------------------------------------------------------------

    async def _inject_single_batch(
        self, 
        batch: List[Dict[str, Any]], 
        batch_idx: int, 
        retries: int = 2
    ) -> int:

        cypher = self.build_query()

        for attempt in range(retries + 1):
            try:
                async with self.driver.session() as session:
                    await session.execute_write(
                        lambda tx: tx.run(cypher, rows=batch)
                    )
                return len(batch)

            except Exception as e:
                if attempt == retries:
                    logger.error(
                        f"[{self.label}] Batch {batch_idx} failed after retries: {e}"
                    )
                    raise
                logger.warning(
                    f"[{self.label}] Retry batch {batch_idx} (attempt {attempt+1})"
                )

    # ------------------------------------------------------------------
    # 5. Async Parallel Injection
    # ------------------------------------------------------------------

    async def inject_batches(
        self,
        df: Optional[pd.DataFrame] = None,
        batch_size: int = 500,
        max_concurrency: int = 5
    ) -> None:

        if df is None:
            df = await self.fetch_data_async()

        if df.empty:
            logger.info(f"[{self.label}] No rows to inject.")
            return

        batches = self._split_batches(df, batch_size)
        num_batches = len(batches)

        logger.info(
            f"[{self.label}] Injecting {len(df)} rows in "
            f"{num_batches} batches (size={batch_size}) ..."
        )

        semaphore = asyncio.Semaphore(max_concurrency)

        async def _bounded_inject(batch, idx):
            async with semaphore:
                return await self._inject_single_batch(batch, idx)

        tasks = [
            _bounded_inject(batch, idx)
            for idx, batch in enumerate(batches)
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        total_ok = 0
        failed = 0

        for idx, r in enumerate(results):
            if isinstance(r, Exception):
                failed += 1
                logger.error(f"[{self.label}] Batch {idx+1} FAILED")
            else:
                total_ok += r
                logger.info(
                    f"[{self.label}] Batch {idx+1}/{num_batches} OK — {r} rows"
                )

        logger.info(
            f"[{self.label}] Injection complete. Success={total_ok}, Failed={failed}"
        )

    # ------------------------------------------------------------------
    # 6. Full ETL Pipeline
    # ------------------------------------------------------------------

    async def run(
        self,
        batch_size: int = 500,
        max_concurrency: int = 5,
    ) -> None:

        df = await self.fetch_data_async()
        await self.inject_batches(
            df=df,
            batch_size=batch_size,
            max_concurrency=max_concurrency,
        )