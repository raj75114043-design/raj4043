import os
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from neo4j import GraphDatabase
from neo4j_node_builder_v3 import Neo4jNodeBuilder
from postgres import query_execution_postgres_db
from dotenv import load_dotenv

# -------------------------------
# Load environment variables
# -------------------------------
load_dotenv()

NEO4J_URI = os.getenv("NEO4J_URI")
NEO4J_USER = os.getenv("NEO4J_USER")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")
JSON_PATH = "node_schemas_new.json"

# -------------------------------
# Config
# -------------------------------
BATCH_SIZE = 200       # Adjust batch size for better parallelism
NODE_WORKERS = 4     # Number of nodes to process in parallel
BATCH_WORKERS = 10     # Internal batch threads per node

# -------------------------------
# Load node schemas
# -------------------------------
def load_node_schemas(path: str):
    with open(path, "r") as f:
        return json.load(f)

# -------------------------------
# Process a single node
# -------------------------------
def process_node(node_name, node_schema, driver):
    print(f"\n🚀 Processing node: {node_name}")

    builder = Neo4jNodeBuilder(
        node_schema=node_schema,
        driver=driver,
        pg_query_fn=query_execution_postgres_db,
    )

    # Step 1: Ensure uniqueness constraint
    builder.create_constraint()

    # Step 2: Fetch + inject
    builder.run(batch_size=BATCH_SIZE, max_workers=BATCH_WORKERS)


# -------------------------------
# Main Execution
# -------------------------------
def main():
    schemas = load_node_schemas(JSON_PATH)

    driver = GraphDatabase.driver(
        NEO4J_URI,
        auth=(NEO4J_USER, NEO4J_PASSWORD),
        max_connection_pool_size=50  # performance boost
    )

    try:
        # Parallel processing of nodes
        with ThreadPoolExecutor(max_workers=NODE_WORKERS) as pool:
            futures = {
                pool.submit(process_node, node_name, node_schema, driver): node_name
                for node_name, node_schema in schemas.items()
            }

            for future in as_completed(futures):
                node = futures[future]
                try:
                    future.result()
                except Exception as e:
                    print(f"❌ Node {node} failed: {e}")
                    continue  # safely continue with other nodes

    finally:
        driver.close()


if __name__ == "__main__":
    main()