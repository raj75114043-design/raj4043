import json
from neo4j import GraphDatabase
from neo4j_node_builder_v3 import Neo4jNodeBuilder
from postgres import query_execution_postgres_db


# -------------------------------
# CONFIG
# -------------------------------
import os
from dotenv import load_dotenv

load_dotenv()

NEO4J_URI = os.getenv("NEO4J_URI")
NEO4J_USER = os.getenv("NEO4J_USER")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")

JSON_PATH = "node_schemas_new.json"

BATCH_SIZE = 1000
MAX_WORKERS = 6


# -------------------------------
# LOAD SCHEMA JSON
# -------------------------------
def load_node_schemas(path: str):
    with open(path, "r") as f:
        return json.load(f)


# -------------------------------
# PROCESS ONE NODE
# -------------------------------
def process_node(node_name, node_schema, driver):
    print(f"\n🚀 Processing node: {node_name}")

    builder = Neo4jNodeBuilder(
        node_schema=node_schema,
        driver=driver,
        pg_query_fn=query_execution_postgres_db,
    )

    # Step 1: Create constraint
    builder.create_constraint()

    # Step 2: Run ETL + Injection
    builder.run(
        batch_size=BATCH_SIZE,
        max_workers=MAX_WORKERS
    )


# -------------------------------
# MAIN EXECUTION
# -------------------------------
def main():
    schemas = load_node_schemas(JSON_PATH)

    driver = GraphDatabase.driver(
        NEO4J_URI,
        auth=(NEO4J_USER, NEO4J_PASSWORD),
        max_connection_pool_size=50  # performance boost
    )

    try:
        for node_name, node_schema in schemas.items():
            try:
                process_node(node_name, node_schema, driver)
            except Exception as e:
                print(f"❌ Failed node {node_name}: {e}")
                continue  # move to next node safely

    finally:
        driver.close()


if __name__ == "__main__":
    main()