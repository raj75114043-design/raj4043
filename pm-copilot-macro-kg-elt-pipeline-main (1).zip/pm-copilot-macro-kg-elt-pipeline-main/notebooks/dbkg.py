"""
Async ETL Router for Database Schema Knowledge Graph (Neo4j_DB)
Author: Advait Shah (PwC India)
Client: Nokia
"""

import logging
import aiohttp
from fastapi import APIRouter, HTTPException

from app.db.neo4j_database import get_neo4j_db_driver
from app.services.dbkg.schema_loader import (
    extract_tables_and_relationships,
    extract_columns,
    extract_kpis_and_table_links,
    extract_questions_and_table_links,
    extract_keywords_and_table_links,
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/dbkg",
    tags=["Database Schema KG ETL"],
)

SCHEMA_URL = (
    "https://pm-copilot-macro-gcl-osdp-gsd-gsd-delivery-staging."
    "aibi-americas-002.dyn.nesc.nokia.net/api/v1/dev/table-schema-builder"
)

# ---------------------------------------------------------------------
# Helper: Fetch JSON
# ---------------------------------------------------------------------

import aiohttp
from fastapi import HTTPException
from aiohttp import BasicAuth

async def fetch_schema_json() -> dict:
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(
                SCHEMA_URL,
                auth=BasicAuth("anython", "pwc_macro_team")
            ) as resp:

                if resp.status != 200:
                    raise HTTPException(
                        status_code=500,
                        detail=f"Schema fetch failed with HTTP {resp.status}"
                    )

                return await resp.json()

    except Exception as e:
        logger.error(f"❌ Failed to fetch schema JSON: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ---------------------------------------------------------------------
# Helper: Constraints for DB KG
# ---------------------------------------------------------------------

ASYNC_CONSTRAINTS = [
    """
    CREATE CONSTRAINT IF NOT EXISTS
    FOR (t:Table) REQUIRE t.name IS UNIQUE
    """,
    """
    CREATE CONSTRAINT IF NOT EXISTS
    FOR (c:Column) REQUIRE (c.table, c.name) IS UNIQUE
    """,
    """
    CREATE CONSTRAINT IF NOT EXISTS
    FOR (k:KPI) REQUIRE k.name IS UNIQUE
    """,
    """
    CREATE CONSTRAINT IF NOT EXISTS
    FOR (q:Question) REQUIRE q.name IS UNIQUE
    """,
    """
    CREATE CONSTRAINT IF NOT EXISTS
    FOR (kw:Keyword) REQUIRE kw.name IS UNIQUE
    """,
]


async def ensure_constraints_async(session):
    for cql in ASYNC_CONSTRAINTS:
        await session.run(cql)


# ---------------------------------------------------------------------
# Helper: Async Batch Writers
# ---------------------------------------------------------------------

async def run_unwind(session, cypher: str, rows: list):
    if not rows:
        return
    await session.run(cypher, rows=rows)


# ---------------------------------------------------------------------
# ✅ MAIN ENDPOINT: RUN FULL ETL
# ---------------------------------------------------------------------

@router.post("/run-etl")
async def run_db_schema_etl():
    """
    ETL Pipeline:
    1) Fetch JSON
    2) Parse into tables, columns, KPIs, questions, keywords + rels
    3) Write to Neo4j_DB
    """

    logger.info("🚀 Starting DB Schema KG ETL...")

    # 1) FETCH JSON
    schema_json = await fetch_schema_json()

    # 2) PARSE
    tables, table_table_rels = extract_tables_and_relationships(schema_json)
    known_tables = {t["name"] for t in tables}

    columns, table_column_rels = extract_columns(schema_json)
    kpis, table_kpi_rels = extract_kpis_and_table_links(schema_json, known_tables)
    questions, table_question_rels = extract_questions_and_table_links(schema_json, known_tables)
    keywords, table_keyword_rels = extract_keywords_and_table_links(schema_json, known_tables)

    # 3) WRITE TO NEO4J_DB
    driver = get_neo4j_db_driver()

    async with driver.session() as session:

        # Constraints
        logger.info("🔧 Ensuring uniqueness constraints...")
        await ensure_constraints_async(session)

        # --- Nodes ---
        await run_unwind(session, """
            UNWIND $rows AS row
            MERGE (t:Table {name: row.name})
            SET t.column_count = row.column_count
        """, tables)

        await run_unwind(session, """
            UNWIND $rows AS row
            MERGE (c:Column {table: row.table, name: row.name})
            SET c.ordinal = row.ordinal
        """, columns)

        await run_unwind(session, """
            UNWIND $rows AS row
            MERGE (k:KPI {name: row.name})
            SET  k.description = row.description,
                 k.formula = row.formula,
                 k.logic = row.logic,
                 k.total_columns_extracted = row.total_columns_extracted,
                 k.matched_count = row.matched_count,
                 k.coverage_pct = row.coverage_pct,
                 k.can_execute = row.can_execute
        """, kpis)

        await run_unwind(session, """
            UNWIND $rows AS row
            MERGE (q:Question {name: row.name})
            SET q.sql = row.sql,
                q.total_columns_extracted = row.total_columns_extracted,
                q.matched_count = row.matched_count,
                q.coverage_pct = row.coverage_pct,
                q.can_execute = row.can_execute
        """, questions)

        await run_unwind(session, """
            UNWIND $rows AS row
            MERGE (kw:Keyword {name: row.name})
            SET kw.description = row.description,
                kw.synonyms = row.synonyms,
                kw.total_columns_extracted = row.total_columns_extracted,
                kw.matched_count = row.matched_count,
                kw.coverage_pct = row.coverage_pct,
                kw.can_execute = row.can_execute
        """, keywords)

        # --- Relationships ---
        await run_unwind(session, """
            UNWIND $rows AS rel
            MATCH (src:Table {name: rel.source})
            MATCH (dst:Table {name: rel.target})
            MERGE (src)-[r:RELATED_TO]->(dst)
            SET r.shared_columns = rel.shared_columns,
                r.shared_column_count = rel.shared_column_count,
                r.affinity_score = rel.affinity_score
        """, table_table_rels)

        await run_unwind(session, """
            UNWIND $rows AS rel
            MATCH (t:Table {name: rel.table})
            MATCH (c:Column {table: rel.table, name: rel.name})
            MERGE (t)-[:HAS_COL]->(c)
        """, table_column_rels)

        await run_unwind(session, """
            UNWIND $rows AS rel
            MATCH (t:Table {name: rel.table})
            MATCH (k:KPI {name: rel.kpi})
            MERGE (t)-[r:INVOLVES]->(k)
            SET r.matched_columns = rel.matched_columns
        """, table_kpi_rels)

        await run_unwind(session, """
            UNWIND $rows AS rel
            MATCH (t:Table {name: rel.table})
            MATCH (q:Question {name: rel.question})
            MERGE (t)-[r:SUPPORTS]->(q)
            SET r.matched_columns = rel.matched_columns
        """, table_question_rels)

        await run_unwind(session, """
            UNWIND $rows AS rel
            MATCH (t:Table {name: rel.table})
            MATCH (kw:Keyword {name: rel.keyword})
            MERGE (t)-[r:HAS_KEYWORD]->(kw)
            SET r.matched_columns = rel.matched_columns
        """, table_keyword_rels)

    logger.info("✅ DB Schema KG ETL Completed Successfully")

    return {
        "status": "success",
        "tables": len(tables),
        "columns": len(columns),
        "kpis": len(kpis),
        "questions": len(questions),
        "keywords": len(keywords)
    }


# ---------------------------------------------------------------------
# ✅ CLEANUP ENDPOINT
# ---------------------------------------------------------------------

@router.delete("/cleanup")
async def cleanup_dbkg(
    chunk_size: int = 20000,
    max_loops: int = 100
):
    """
    Cleanup Neo4j_DB:
    - Drop constraints
    - Drop non-lookup indexes
    - DETACH DELETE all nodes in batches
    """

    driver = get_neo4j_db_driver()
    stats = {
        "constraints_removed": 0,
        "indexes_removed": 0,
        "nodes_deleted": 0,
        "passes": 0
    }

    async with driver.session() as session:

        # Drop constraints
        result = await session.run("SHOW CONSTRAINTS YIELD name")
        names = [r["name"] async for r in result]

        for name in names:
            try:
                await session.run(f"DROP CONSTRAINT `{name}`")
                stats["constraints_removed"] += 1
            except:
                pass

        # Drop indexes
        result = await session.run("SHOW INDEXES YIELD name, type")
        idx_names = [r["name"] async for r in result if r["type"] != "LOOKUP"]

        for name in idx_names:
            try:
                await session.run(f"DROP INDEX `{name}`")
                stats["indexes_removed"] += 1
            except:
                pass

        # DELETE nodes in batches
        count_res = await session.run("MATCH (n) RETURN count(n) as c")
        remaining = (await count_res.single())["c"]

        loops = 0
        while remaining > 0 and loops < max_loops:
            loops += 1
            await session.run("""
                MATCH (n)
                WITH n LIMIT $limit
                DETACH DELETE n
            """, {"limit": chunk_size})

            count_res = await session.run("MATCH (n) RETURN count(n) as c")
            new_remaining = (await count_res.single())["c"]

            if new_remaining >= remaining:  # Stuck
                break

            remaining = new_remaining

        stats["nodes_deleted"] = remaining
        stats["passes"] = loops

    return {
        "status": "success",
        "message": "DB Schema KG cleaned successfully.",
        "stats": stats,
    }