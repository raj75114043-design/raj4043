"""
Async ETL Runner for All Nodes
Author: Advait Shah (PwC India)
Client: Nokia

Loads node_schemas_new.json and injects all nodes asynchronously
using AsyncNeo4jNodeBuilder.
"""

# --- bootstrap sys.path to include project root ---
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]  # one level up from notebooks/
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
# --------------------------------------------------

import json
import asyncio
import logging

from pathlib import Path
from app.db.database import AsyncSessionLocal
from app.db.neo4j_database import get_neo4j_driver
from async_node_builder import AsyncNeo4jNodeBuilderss

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------
# Load Schema
# ---------------------------------------------------------------------

def load_node_schemas(path: str) -> dict:
    file_path = Path(path)
    if not file_path.exists():
        raise FileNotFoundError(f"Schema file not found: {path}")

    with open(file_path, "r") as f:
        return json.load(f)


# ---------------------------------------------------------------------
# ETL Runner for a Single Node
# ---------------------------------------------------------------------

async def run_single_node(
    name: str,
    schema: dict,
    driver,
    pg_session_factory,
    batch_size: int = 800,
    max_concurrency: int = 6
):
    """
    Run async ETL for one node using AsyncNeo4jNodeBuilder.
    """

    logger.info(f"🚀 Starting ETL for node: {name}")

    builder = AsyncNeo4jNodeBuilder(
        node_schema=schema,
        driver=driver,
        pg_session_factory=pg_session_factory,
    )

    # Step 1: Ensure uniqueness constraint
    await builder.create_constraint_async()

    # Step 2: Full ETL → Fetch → Batch Inject
    await builder.run(
        batch_size=batch_size,
        max_concurrency=max_concurrency,
    )

    logger.info(f"✅ Completed ETL for: {name}")


# ---------------------------------------------------------------------
# Run ALL Node ETLs Concurrently (Fastest)
# ---------------------------------------------------------------------

async def run_all_nodes(
    schema_file: str = "node_schemas_new.json",
    max_parallel_nodes: int = 4,
    batch_size: int = 800,
    max_batch_concurrency: int = 6,
):
    """
    Run ETL for all nodes concurrently (with limit).
    """

    node_schemas = load_node_schemas(schema_file)
    driver = get_neo4j_driver()

    semaphore = asyncio.Semaphore(max_parallel_nodes)
    tasks = []

    async def _run_limited(name, schema):
        async with semaphore:
            await run_single_node(
                name=name,
                schema=schema,
                driver=driver,
                pg_session_factory=AsyncSessionLocal,
                batch_size=batch_size,
                max_concurrency=max_batch_concurrency,
            )

    # Create tasks for all nodes
    for name, schema in node_schemas.items():
        tasks.append(asyncio.create_task(_run_limited(name, schema)))

    # Run all tasks in parallel
    await asyncio.gather(*tasks)

    logger.info("🎉 All node ETLs completed.")


# ---------------------------------------------------------------------
# CLI Entry Point (Optional for Notebook)
# ---------------------------------------------------------------------

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(message)s",
    )

    asyncio.run(
        run_all_nodes(
            schema_file="node_schemas_new.json",
            max_parallel_nodes=4,      # 4 nodes process in parallel
            batch_size=800,            # Neo4j batch size
            max_batch_concurrency=6,   # Intra-node parallel batch inserts
        )
    )