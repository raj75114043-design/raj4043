import asyncio
import logging
import re
from typing import Dict, List
from thefuzz import fuzz
# from async_db_pool_manager import DatabasePoolManager
from database.session import get_session_ctx
import os
from sqlalchemy import text
import os
import pandas as pd 
from dotenv import load_dotenv
load_dotenv()

# Initialize logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class AsyncKPIMatcher:
    _instance = None
    _initialized = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(AsyncKPIMatcher, cls).__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._initialized:
            self.threshold = 0.85
            self.stop_words = {'show', 'me', 'the', 'in', 'for', 'of', 'and', 'with', 'by', 'terms'}
            AsyncKPIMatcher._initialized = True
            
    def _preprocess_text(self, text: str) -> str:
        """Clean and normalize text"""
        text = text.lower()
        text = re.sub(r'[^\w\s]', ' ', text)
        return ' '.join(word for word in text.split() if word not in self.stop_words)

    def _get_word_combinations(self, words: List[str], max_length: int = 3) -> List[str]:
        """Generate word combinations up to specified length"""
        combinations = []
        for i in range(len(words)):
            for j in range(i + 1, min(i + max_length + 1, len(words) + 1)):
                combinations.append(' '.join(words[i:j]))
        return combinations

    async def _match_phrase(self, phrase: str, target: str) -> float:
        """Match a phrase against a target using multiple fuzzy matching strategies"""
        if len(phrase) < 3:
            return 0.0
        
        def compute_matches():
            token_sort = fuzz.token_sort_ratio(phrase, target) / 100
            token_set = fuzz.token_set_ratio(phrase, target) / 100
            partial = fuzz.partial_ratio(phrase, target) / 100 if len(phrase) > 4 else 0
            return max(token_sort, token_set, partial)
            
        return await asyncio.to_thread(compute_matches)

    async def _get_kpi_data(self) -> Dict[str, List[str]]:
        """Retrieve KPI dictionary from database using connection pool"""
        try:
           async with get_session_ctx() as session:
                res = await session.execute(text("""
                    SELECT k.name, array_agg(s.synonym) as synonyms
                    FROM osdp_pwc_sch.kpis k
                    LEFT JOIN osdp_pwc_sch.kpi_synonyms s ON k.id = s.kpi_id
                    GROUP BY k.id, k.name
                """))

                rows = res.fetchall()
                
                df = pd.DataFrame(rows, columns=['name', 'synonyms'])

                # Create a dictionary from the DataFrame
                kpi_dict = df.set_index('name')['synonyms'].apply(lambda x: [syn for syn in x if syn is not None]).to_dict()
                
                return kpi_dict
                
        except Exception as e:
            logger.error(f"Error retrieving KPI data: {str(e)}")
            raise

    async def find_kpis(self, question: str) -> List[str]:
        """
        Find KPIs in the question using fuzzy string matching asynchronously
        
        Args:
            question (str): The input question to search for KPIs
            
        Returns:
            List[str]: List of matched KPI names
        """
        try:
            # Get KPI dictionary from database
            kpi_dict = await self._get_kpi_data()
            
            # Process text and generate combinations
            processed_text = self._preprocess_text(question)
            words = processed_text.split()
            word_combinations = self._get_word_combinations(words)
            
            # Store matches with confidence scores
            matches = {}
            
            # Process each combination against KPIs and synonyms
            for combo in word_combinations:
                for kpi, synonyms in kpi_dict.items():
                    # # Check against KPI name
                    # confidence = await self._match_phrase(combo, kpi.lower())
                    # if confidence >= self.threshold:
                    #     matches[kpi] = max(matches.get(kpi, 0), confidence)
                    
                    # Check against synonyms
                    for synonym in synonyms:
                        confidence = await self._match_phrase(combo, synonym.lower())
                        if confidence >= self.threshold:
                            matches[kpi] = max(matches.get(kpi, 0), confidence)
            print(f"###KPIS######:{matches.keys()})")
            return list(matches.keys())
            
        except Exception as e:
            logger.error(f"Error finding KPIs: {str(e)}")
            raise

# Singleton instance
kpi_matcher = AsyncKPIMatcher()

# Example usage
# async def main():
#     try:
#         questions = [
#             "Show me the revenue growth and sales performance",
#             "What is the market share",
#             "Show achievement percentage"
#         ]
        
#         for question in questions:
#             matched_kpis = await kpi_matcher.find_kpis(question)
#             print(f"\nQuestion: {question}")
#             print("Matched KPIs:", matched_kpis)
            
#     except Exception as e:
#         logger.error(f"Error in main: {str(e)}")
#     finally:
#         # Cleanup database pool
#         db_manager = await DatabasePoolManager.get_instance()
#         await db_manager.close()

# if __name__ == "__main__":
#     asyncio.run(main())