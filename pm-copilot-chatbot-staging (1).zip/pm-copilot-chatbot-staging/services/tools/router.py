from.state import convbiState
from database.session import get_session_ctx
from sqlalchemy import text
import pandas as pd
from typing import Literal
from langgraph.graph import END

async def kpi_router(state: convbiState) -> Literal["kpi_search","followup_query_rewrite"]:
    
    folloup_flag= state['followup_flag']
    
    if folloup_flag:
        return ["followup_query_rewrite"]
    else:
        return "kpi_search"
    
async def qb_router(state: convbiState) -> Literal["qb_search","followup_query_rewrite"]:
    
    folloup_flag= state['followup_flag']
    
    if folloup_flag:
        return ["followup_query_rewrite"]
    else:
        return "qb_search"
    
async def error_correction(state: convbiState) -> Literal["text_response","sql_generate"]:
    error_message = state["sql_error"][-1] if state["sql_error"] else ""
    if error_message == "":
        return "text_response"
    elif len(state["sql_error"]) > 2 :
        return "text_response"
    else:
        return "sql_generate"

