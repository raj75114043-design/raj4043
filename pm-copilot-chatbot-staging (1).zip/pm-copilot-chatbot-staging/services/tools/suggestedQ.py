from services.config_llm import LLMConfig
from pydantic import BaseModel, Field
from langchain.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from typing import List


from.state import convbiState
from services.prompts import sugg

class suggested_question(BaseModel):
    """List of Suggested Questions"""
    questions: List[str] = Field(description="Two suggested questions")

async def suggested_generate(state: convbiState):

    print('6. Suggested Queries started')
    if state['followup_flag'] and state['follow_up_query'] is not None:
        user_query = state['follow_up_query']
    else:
        user_query = state['query']
    schema= state['schema']
    llm = LLMConfig.openai()

    praser = JsonOutputParser(pydantic_object=suggested_question)
    format_instructions = praser.get_format_instructions()

    prompt = PromptTemplate(
                template= sugg,
                input_variables= ["query","schema"],
                partial_variables={"format": format_instructions},
                )

    chain = prompt | llm | praser
    sugg_output  = await chain.ainvoke({"query":user_query,'schema':schema})
    print('6. Suggested Queries complete')
    return {"suggested_ques": sugg_output['questions']}
