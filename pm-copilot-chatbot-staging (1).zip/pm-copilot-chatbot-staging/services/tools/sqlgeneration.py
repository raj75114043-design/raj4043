
from services.config_llm import LLMConfig
from pydantic import BaseModel, Field
from langchain.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from services.sql_agent_prompts import sql_generation_template_main, sql_generation_template_feedback, sql_generation_template_followup
from .state import convbiState
from datetime import date


class sql_generation(BaseModel):
    """Final SQL Code"""
    sql: str = Field(description="Executable Final SQL Code Only")


async def sql_generate(state: convbiState):

    print('5. SQL generation node started')
    
    if state['followup_flag'] and state['follow_up_query'] is not None:
        user_query = state['follow_up_query']
    else:
        user_query = state['query']
    
    # user_query = state['query']
    schema= state['schema']
    # print("Schema going for context: ", schema)
    qb = state['qb']
    error = state["sql_error"][-1] if state["sql_error"] else ""
    current_date = date.today()
    llm = LLMConfig.openai()
    praser = JsonOutputParser(pydantic_object=sql_generation)
    format_instructions = praser.get_format_instructions()

    if error == "":

        if state['followup_flag']:
            previous_query = state['previous_query']
            previous_sql = state['previous_sql']
            prompt = PromptTemplate(
                        template= sql_generation_template_followup,
                        input_variables= ["db_schema","user_query","current_date","qb","previous_query","previous_sql"],
                        partial_variables={"format": format_instructions},
                        )

            chain = prompt | llm | praser
            sql_object = await chain.ainvoke({"db_schema":schema,"user_query": user_query,'current_date':current_date,"qb":qb,"previous_query":previous_query,"previous_sql":previous_sql})
            print("5. SQL Generation Complete through Followup")
            return {"sql":sql_object['sql'], "sql_generate_prompt": prompt}
        
        else:
            prompt = PromptTemplate(
                        template= sql_generation_template_main,
                        input_variables= ["db_schema","user_query","current_date","qb"],
                        partial_variables={"format": format_instructions},
                        )

            chain = prompt | llm | praser
            sql_object = await chain.ainvoke({"db_schema":schema,"user_query": user_query,'current_date':current_date,"qb":qb})
            print("5. SQL Generation Complete")
            print("SQL Query: ", sql_object['sql'])
            return {"sql":sql_object['sql'], "sql_generate_prompt": prompt}

    else :
        error_sql = state['sql']
        prompt = PromptTemplate(
                    template= sql_generation_template_feedback,
                    input_variables= ["tool_error","SQL_code"],
                    partial_variables={"format": format_instructions},
                    )

        chain = prompt | llm | praser
        sql_object = await chain.ainvoke({"tool_error":error,"SQL_code": error_sql})
        print("5. SQL Generated through Error correction")
        return {"sql":sql_object['sql']}

    
    
