from services.config_llm import LLMConfig
from services.prompts import question_merge_template
from pydantic import BaseModel, Field
from langchain.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from .state import convbiState

# Define Pydantic schema once
class QuestionMerge(BaseModel):
    """To create a single question out of the follow up question"""
    merge_output: str = Field(
        description="A single question which has complete context and can be answered without referring to the question it follows up"
    )

# Initialize once at import
llm = LLMConfig.openai()
parser = JsonOutputParser(pydantic_object=QuestionMerge)
format_instructions = parser.get_format_instructions()
prompt = PromptTemplate(
    template=question_merge_template,
    input_variables=["user_query", "previous_user_query"],
    partial_variables={"format": format_instructions},
)
chain = prompt | llm | parser

async def followup_query_rewrite(state: convbiState):
    print("1. Follow-up node started")

    result = await chain.ainvoke({
        "user_query": state["query"],
        "previous_user_query": state["previous_query"]
    })

    print("1. Follow-up node complete")
    return {"follow_up_query": result["merge_output"]}
