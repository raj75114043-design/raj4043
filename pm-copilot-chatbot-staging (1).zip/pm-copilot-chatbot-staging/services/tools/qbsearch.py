
from sqlalchemy import text
import pandas as pd
from database.session import get_session_ctx_pgvec
from pydantic import BaseModel, Field
from typing import List
from .state import convbiState
from services.config_llm import LLMConfig
 
 
 
 
async def qb_search(state: convbiState):

    print('2.QB node started')
    """Run a embedding search query against the PostgreSQL database using pgvector."""
   
    if state['followup_flag'] and state['follow_up_query'] is not None:
        query = state['follow_up_query']
    else:
        query = state['query']

    embedding_model = LLMConfig.openai_embedding()
    question_embedding = await embedding_model.aembed_query(query)
    question_embedding = str(question_embedding)
   
    sql = text("""
        SELECT
            id,
            question,
            sql,
            question_embedding <=> :embedding AS similarity
        FROM osdp_pwc_sch.question_bank
        ORDER BY question_embedding <=> :embedding 
        LIMIT 2
    """)
 
    async with get_session_ctx_pgvec() as session:
        result = await session.execute(
            sql,
            {"embedding": question_embedding}  # bind parameters
        )
        rows = result.fetchall()
        formatted_results = [
        {"Question": row[1], "SQL": row[2]} for row in rows ]
        print('2. QB node complete')
        return {'qb':formatted_results}

