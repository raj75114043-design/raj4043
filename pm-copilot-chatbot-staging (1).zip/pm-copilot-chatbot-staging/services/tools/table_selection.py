from .state import convbiState
import json
import os

# Cache at module load
current_dir = os.path.dirname(os.path.abspath(__file__))
schema_file = os.path.join(current_dir, "..", "..", "services", "tools", "table_schema.json")

with open(schema_file, "r") as file:
    TABLE_SCHEMA = json.load(file)

async def schema_search(state: convbiState):
    print('4. Schema matching started')
    search_keywords = state['kpi']

    found_keys = [(key, TABLE_SCHEMA[key]) for key in search_keywords if key in TABLE_SCHEMA]
    final_schema = "".join(
        f" {key}: {json.dumps(value, indent=4)}\n\n"
        for key, value in found_keys
    )

    print('4. Schema matching complete')
    # print(final_schema)
    return {"schema": final_schema}



