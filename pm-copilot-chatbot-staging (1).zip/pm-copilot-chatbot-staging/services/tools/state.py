from typing import Annotated, List
from operator import add
from typing_extensions import TypedDict
from langchain_core.messages import AnyMessage


class convbiState(TypedDict):
    query:str
    kpi:List[str]
    categorical:List[str]
    qb:List[dict]
    table_flagged:List[str]
    schema:str
    sql:str
    df:str
    followup_flag:bool
    previous_query: str = ""
    previous_sql: str = ""
    follow_up_query: str = ""
    sql_generate_prompt: str = ""
    sql_error : Annotated[list[AnyMessage], add] 
    suggested_ques:List[str]
    response : str
    intent: str


