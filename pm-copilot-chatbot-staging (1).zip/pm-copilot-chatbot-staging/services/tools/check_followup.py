from .state import convbiState




async def check_followup(state: convbiState):
    

    query = state['query']
    previous_query = state['previous_query']
    previous_sql = state['previous_sql']
    
    # if query.lstrip().startswith("@"):
    #     return {"followup_flag": True,
    #             "query":query.replace("@", "")}
    # return {"followup_flag": False}

    if previous_query is not None and previous_sql is not None:
        return {"followup_flag": True,
                "query":query}
    return {"followup_flag": False}
        
    
    