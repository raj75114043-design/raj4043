from services.tools.micro_agents.reco_pg_query import reco_pg_query_return_df_tool
import asyncio
from typing import Any, List, Dict

async def fetch_table(q):
    sql_query = q.get("sql")
    table_name = q.get("table")
    description = q.get("description")
    query_id = q.get("id")

    try:
        query_result_df, error_flag = await reco_pg_query_return_df_tool(sql_query)
        if error_flag:
            print(f"Query failed for {table_name} (error_flag=True)")
            return None
        
        # Take only first 5 rows
        df_preview = query_result_df.head(5)

        # Convert data to list of JSON-like dicts
        data_json = df_preview.to_dict(orient="records")

        # Extract column names and dtypes
        columns_info = [
            {"name": col, "dtype": str(dtype)}
            for col, dtype in query_result_df.dtypes.items()
        ]

        return {
            "id": query_id,
            "table": table_name,
            "description": description,
            "columns": columns_info,
            "data_preview": data_json,
            "dataframes": query_result_df
        }

    except Exception as e:
        print(f"Exception while fetching {table_name}: {e}")
        return None


async def get_derived_tables(qs):
    print("\nDerived tables fetching started")

    # Run all queries concurrently
    tasks = [fetch_table(q) for q in qs]
    all_results = await asyncio.gather(*tasks, return_exceptions=True)

    # Keep only successful ones
    derived_tables = [
        r for r in all_results
        if isinstance(r, dict) and r.get("data_preview") is not None
    ]

    print(f"All derived tables processed. Success: {len(derived_tables)}/{len(qs)}")
    return derived_tables