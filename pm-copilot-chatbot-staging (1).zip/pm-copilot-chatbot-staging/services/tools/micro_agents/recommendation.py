
from langchain.prompts import PromptTemplate
from pydantic import BaseModel, Field
from typing import List
from langchain_core.output_parsers import JsonOutputParser


from services.config_llm import LLMConfig
from services.tools.micro_agents.reco_orchestrator import recommend_orch
llm = LLMConfig.openai()

async def get_recommendation(state):
    query=state['query']
    sugg_output = await recommend_orch(query)
    state['response']=sugg_output.content
    return state
