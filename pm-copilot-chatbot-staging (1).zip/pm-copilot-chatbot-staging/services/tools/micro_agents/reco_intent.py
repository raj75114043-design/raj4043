import os
import json
from langchain.prompts.example_selector import SemanticSimilarityExampleSelector
from langchain.vectorstores import FAISS
from langchain.prompts import FewShotPromptTemplate, PromptTemplate
from services.config_llm import LLMConfig
from services.micro_agent_prompts import INTENT_RECO_PROMPT

class LoadExamplesIntentReco:
    def __init__(self,file_path="reco_intent_examples.json",k=5):
        current_dir = os.path.dirname(os.path.abspath(__file__))
        f_path = os.path.join(current_dir, "..", "..","..","database", file_path)
        examples=json.load(open(f_path))
        self.embed=LLMConfig.openai_embedding()
        self.loader=self._load_db(examples,k=k)
    
    def _load_db(self,docs,k):
        example_selector = SemanticSimilarityExampleSelector.from_examples(
            docs,
            embeddings=self.embed,
            vectorstore_cls=FAISS,
            k=k
        )
        return example_selector
    
    def get_examples(self,query):
        selected_examples = self.loader.select_examples({"input": query})
        return selected_examples
    
    def get_loader(self):
        return self.loader

llm = LLMConfig.openai()
example_selector=LoadExamplesIntentReco()
template=PromptTemplate.from_template(INTENT_RECO_PROMPT)

chain=template|llm



async def get_intent(query):
    print("1. Entered in Intent")
    selected_examples=example_selector.get_examples(query)
    example_string="\n\n".join([f"query:{i['question']} \n classified:{i['category']}"for i in selected_examples])
    # print("examples strings: ", example_string)
    is_correct=True
    loop_count=0
    while is_correct:
        try:
            classified=chain.invoke({
            "query": query,
            "examples":example_string
            })
            print(classified)
            content=classified.content.strip("```json").strip('```')
            print(content)
            #classified)print(
            classes=json.loads(content)
            
            if "classified" in classes:
                is_correct=False
            else: loop_count+=1
        except Exception as e:
            print(e)
            if loop_count>3:
                raise Exception("Error!!! Classifing Intent")
            loop_count+=1   
    intent=classes['classified']
    return intent

