
from langchain.prompts import PromptTemplate
from pydantic import BaseModel, Field
from typing import List
from langchain_core.output_parsers import JsonOutputParser


from services.config_llm import LLMConfig
from services.micro_agent_prompts import INTENT_PROMPT,SUGGESTION_PROMPT_NO_SCHEMA
llm = LLMConfig.openai()


class suggested_question(BaseModel):
    """List of Suggested Questions"""
    questions: List[str] = Field(description="Two suggested questions")


async def get_suggestions(state):
    query=state['query']
    
    
    praser = JsonOutputParser(pydantic_object=suggested_question)
    format_instructions = praser.get_format_instructions()
    template=PromptTemplate(template= SUGGESTION_PROMPT_NO_SCHEMA,
                input_variables= ["query"],
                partial_variables={"format": format_instructions},
               )
    sugg_chain=template|llm| praser
    sugg_output  = await sugg_chain.ainvoke({"query":query})
    return {"suggested_ques": sugg_output['questions']}

