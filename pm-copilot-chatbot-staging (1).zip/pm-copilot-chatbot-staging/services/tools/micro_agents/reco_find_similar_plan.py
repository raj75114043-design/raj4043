from services.config_llm import LLMConfig
import numpy as np

def cosine_similarity(vec1, vec2):
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    
    dot_product = np.dot(vec1, vec2)
    norm_vec1 = np.linalg.norm(vec1)
    norm_vec2 = np.linalg.norm(vec2)
    
    return dot_product / (norm_vec1 * norm_vec2)


def find_most_similar_plan(user_query, plan):
    
    embedding_model = LLMConfig.openai_embedding()
    query_embedding = embedding_model.embed_query(user_query)
    
    max_similarity = -1
    best_match_index = 0
    
    for i, plan_item in enumerate(plan):
        problem = plan_item["Problem"]

        problem_embedding = embedding_model.embed_query(problem)
        similarity = cosine_similarity(query_embedding, problem_embedding)
        
        if similarity > max_similarity:
            max_similarity = similarity
            best_match_index = i
            general_flag = plan_item["General_Flag"]
    
    print(f"Best match similarity score: {best_match_index} with score {max_similarity}")
    return best_match_index,general_flag, max_similarity