import os 
from services.tools.micro_agents.intent_classifier import LoadExamplesIntent
from services.config_llm import LLMConfig
import numpy as np


current_dir = os.path.dirname(os.path.abspath(__file__))
general_file = os.path.join(current_dir, "..", "..", "..","database", "recommendation.json")
example_selector=LoadExamplesIntent(general_file)

async def get_recommendation_examples_all(query):
    examples=example_selector.get_examples(query)
    examples_selected="\n\n".join([f"Problem: {i['problem']} \nRecommendation: {i['recommendation']}" for i in examples])
    return examples_selected


