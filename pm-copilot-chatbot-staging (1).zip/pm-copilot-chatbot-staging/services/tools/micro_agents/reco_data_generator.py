from services.config_llm import LLMConfig
llm = LLMConfig.openai()
from pydantic import BaseModel, Field
from langchain.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from datetime import datetime
from services.tools.micro_agents.reco_pg_query import reco_pg_query_tool


class context_builder(BaseModel):
    question_new: str = Field(..., description="The question with 'INSERT HERE' to be replaced with context from User problem Statement")
    sql_query_new: str = Field(..., description="The SQL query with 'INSERT HERE' to be replaced with context from User problem Statement")

async def question_context_builder(user_query, question, sql_query,schema):
    """For Non General Queries, function to add the missing context to the question and SQL from the user query using LLM"""
    
    prompt = """  
    You are an expert data analyst. 
    You will be provided with a user problem statement, a question, schema related to it, and its a SQL query. You are also given the todays date.
    The question and SQL query are used to analyse the problem statement given by the user. 
    These question and SQL query will not be complete and will need some context from the user problem statement and the schema to make them complete.
    Your task is to reframe the question and SQL query to include the missing context from the user query. 
    The place to add the context will be marked as 'INSERT HERE' in the question and SQL query.
    You will replace 'INSERT HERE' with the relevant context from the user problem statement.

    NOTE: IF THE USER PROBLEM STATEMENT DOES NOT HAVE THE CONTEXT TO FILL IN, REMOVE THE CONDITION WHICH CONTAINS 'INSERT HERE' FROM THE SQL QUERY AND QUESTION RATHER THAN LEAVING 'INSERT HERE' IN THE FINAL OUTPUT.
    MAKE SURE YOU TWEAK THE QUESTION AND SQL TO ALIGN WITH THE PROBLEM STATEMENT GIVEN BY THE USER.
   
    **IMPORTANT: IF 'DON'T CHANGE SQL' Is MENTIONED IN QUESTION - DONT CHANGE THE SQL QUERY based on user problem or schem, Return exact the SAME SQL query.**

    User Problem Statement: 
        {user_query}

    Question to add context to:
        {question}

    SQL query to add context to:
        {sql_query}

    Schema related to the problem statement:
        {schema}


    Todays Date: {current_date}
    Use todays date to get todays date to use as context if required.

    Provide the reframed question and SQL query in the below format:
        {format}
    """

    llm = LLMConfig.openai()
    parser = JsonOutputParser(pydantic_object=context_builder)
    format_instructions = parser.get_format_instructions()
    prompt_template = PromptTemplate(
        input_variables=["user_query", "question", "sql_query","current_date","schema"],
        partial_variables={"format": format_instructions},
        template=prompt
    )

    chain = prompt_template | llm | parser
    response = await chain.ainvoke({"user_query": user_query, "question": question, "sql_query": sql_query, "current_date": datetime.now().strftime('%d-%m-%Y'),"schema": schema})
    return response['question_new'], response['sql_query_new']

async def format_plan_results(user_query,plan, plan_index, general_flag, schema):
    result_string = f"**Data Required for the Problem Statement: {user_query}**\n\n"
    if general_flag:
        for question, sql_query in plan[plan_index]["Steps"].items():
            query_result, error_flag = await reco_pg_query_tool(sql_query)
            if error_flag:
                pass
            else:
                result_string += f"{question}\n\n"
                result_string += f"{query_result}\n\n"
    else:
        for question, sql_query in plan[plan_index]["Steps"].items():
            new_question, new_sql = await question_context_builder(user_query, question, sql_query, schema)
            new_query_result, error_flag = await reco_pg_query_tool(new_sql)
            if error_flag:
                pass
            else:
                result_string += f"{new_question}\n\n"
                result_string += f"{new_query_result}\n\n"
    
    return result_string