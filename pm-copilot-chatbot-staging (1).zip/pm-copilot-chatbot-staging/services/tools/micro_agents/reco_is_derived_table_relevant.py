from datetime import datetime
from typing import Any, Dict, List
from services.config_llm import LLMConfig
llm = LLMConfig.openai()
from langchain.prompts import PromptTemplate
import json
import re

async def is_derived_table_relevant(user_query, derived_tables):
    """
    Use LLM to determine if user query information exists in the derived tables.
    Returns:
        Info_avlbl: "TRUE" or "FALSE"
        required_tables: list of table names (if found)
    """

    # Prepare formatted dataset for prompt
    formatted_results = []
    for d in derived_tables:
        table_name = d.get("table", "")
        description = d.get("description", "")
        columns = d.get("columns", [])
        data_preview = d.get("dataframes", [])

        # Convert columns + datatypes
        col_lines = "\n".join([f"- {c['name']} ({c['dtype']})" for c in columns])

        # Convert preview to markdown table (5 rows)
        import pandas as pd
        # preview_df = pd.DataFrame(data_preview)

        preview_md = data_preview.to_markdown(index=False) if not data_preview.empty else "No preview available."

        table_block = f"""
### Table: {table_name}
**Description:** {description}

**Columns:**
{col_lines}

**Preview (Top 5 rows):**
{preview_md}
"""
        formatted_results.append(table_block)

    dataset_md = "\n\n".join(formatted_results)

    # Build LLM prompt
    prompt = """
You are an intelligent data reasoning assistant for a **telecom project**.

Your task is to analyze data from multiple tables and determine whether the required information 
to answer or to give any recommendations for the user's question exists within them.

### Domain Context
This system supports telecom rollout and radio swap operations for customer cell towers.
- Each tower/site may have multiple activities such as entitlement, construction, integration, and swap.
- Vendors / General Contractors (GC) / Subcontractors perform site-related work like Collect material from the warehouse, perform swapping tasks on site where tower is present.
- Tables may include milestones, Material Informations, prerquistes information, dependencies, vendor performance, compliace checks or more.
- When GC/vendor reaches on sites Health & safety team checks all the compliances and mandatory checks. For ground works related to radio swapping, outage is required in which it always should be in Maintenance hours while crews performing swapping tasks on site.

### Your Task
Given:
- Multiple tables (each with: name, description, column names, and tables in Markdown)
- A user question

You must decide:
1. Whether the dataset contains **sufficient information** to answer the question.
2. Which tables are **relevant** to the question.
3. Number of relevant tables can be one or more than one.

### Important Instructions
- Do **not** provide any explanation or verbose reasoning outside the JSON.
- Select **only those tables** those are relevants and should have relevant columns or data patterns.
- If suffiecient data is available, mark `"found": "TRUE"` and list the relevant tables.
- If nothing seems relevant, return `"found": "FALSE"` and `"table_names": []`.
- If "Use AI Assitant" Mentioned in user question then return `"found": "FALSE"` and `"table_names": []`.

---

# Dataset
{dataset}

# User Question
{user_query}

# Output Format
Return JSON only in this structure:
{{
    "question": "<original question>",
    "found": "TRUE" or "FALSE",
    "table_names": ["table_name_1", "table_name_2"]
}}
    """


    # Prepare the LLM
    llm = LLMConfig.openai()
    prompt_template = PromptTemplate(
        input_variables=["user_query", "dataset"],
        template=prompt
    )

    chain = prompt_template | llm

    # Current date (if you want to log or include it)
    current_date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Run async LLM call
    response = await chain.ainvoke({
        "user_query": user_query,
        "dataset": dataset_md,
    })

    # Parse the LLM response safely
    raw = response.content.strip()

    try:
        match = re.search(r"\{[\s\S]*\}", raw)
        if match:
            json_str = match.group(0)
        else:
            json_str = raw  # fallback if raw is already JSON
        parsed = json.loads(json_str)
        found = str(parsed.get("found", "")).upper()
        tables = parsed.get("table_names", [])
        if not isinstance(tables, list):
            tables = [tables] if tables else []

        return found, tables

    except Exception as e:
        print("LLM response parsing failed:", e)
        print("Raw response:", response.content)
        return "FALSE", []