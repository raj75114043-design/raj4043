import os
import json
from langchain.prompts.example_selector import SemanticSimilarityExampleSelector
from langchain.vectorstores import FAISS
from langchain.prompts import FewShotPromptTemplate, PromptTemplate
from services.config_llm import LLMConfig
from services.micro_agent_prompts import INTENT_PROMPT
class LoadExamplesIntent:
    def __init__(self,file_path="intent_examples.json",k=8):
        f_path=os.path.join('database',file_path)
        examples=json.load(open(f_path))
        self.embed=LLMConfig.openai_embedding()
        self.loader=self._load_db(examples,k=k)
    
    def _load_db(self,docs,k):
        example_selector = SemanticSimilarityExampleSelector.from_examples(
            docs,
            embeddings=self.embed,
            vectorstore_cls=FAISS,
            k=k
        )
        return example_selector
    
    def get_examples(self,query):
        selected_examples = self.loader.select_examples({"input": query})
        return selected_examples
    
    def get_loader(self):
        return self.loader

llm = LLMConfig.openai()
example_selector=LoadExamplesIntent()
template=PromptTemplate.from_template(INTENT_PROMPT)

chain=template|llm



async def get_intent(state):
    print("1. Entered in Intent")
    query=state['query']
    selected_examples=example_selector.get_examples(query)
    example_string="\n\n".join([f"query:{i['question']} \n classified:{i['category']}"for i in selected_examples])
    # print(example_string)
    is_correct=True
    loop_count=0
    while is_correct:
        try:
            classified=chain.invoke({
            "query": query,
            "examples":example_string
            })
            print(classified)
            content=classified.content.strip("```json").strip('```')
            print(content)
            #classified)print(
            classes=json.loads(content)
            
            if "classified" in classes:
                is_correct=False
            else: loop_count+=1
        except Exception as e:
            print(e)
            if loop_count>3:
                raise Exception("Error!!! Classifing Intent")
            loop_count+=1
    state["intent"]=classes['classified']
    state['followup_flag']=False
    return state

async def route_from_intent(state):
    if state['intent'] =="sql" or state['previous_query'] is not None :
        return "check_followup"
    elif state['intent']=='recommendation':
        # return "recommendation"
        return "general"
    else: return "general"