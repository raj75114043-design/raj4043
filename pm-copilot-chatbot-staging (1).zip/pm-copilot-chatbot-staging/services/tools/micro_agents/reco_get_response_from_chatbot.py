from services.tools.langgraph_runner import LangGraphRunner
import traceback

async def get_response_from_chatbot(more_questions):

    formatted_results = ""
    collected_count = 0

    if not more_questions:
        print("No questions provided to chatbot.")
        return ""

    print(f"Running {len(more_questions)} follow-up questions...")

    for idx, q in enumerate(more_questions, start=1):
        try:
            workflow = LangGraphRunner()
            result = await workflow.run({
                "query": q,
                "previous_query": "",
                "previous_sql": "",
                "intent": "",
                "followup_flag": False
            })

            # Extract markdown/table response
            response_markdown = result.get("df", "") if isinstance(result, dict) else ""

            if response_markdown:
                formatted_results += f"### Q{idx}: {q}\n\n"
                formatted_results += f"**Answer Table:**\n{response_markdown}\n\n"
                collected_count += 1
            else:
                print(f"No response_markdown for Q{idx}: {q}")

        except Exception as e:
            print(f"Error processing Q{idx}: {q}\n{traceback.format_exc()}")
            continue

    # Final summary message
    print(f"Collected responses for {collected_count}/{len(more_questions)} questions.")

    if collected_count == 0:
        formatted_results = "No valid responses were returned for any of the generated questions."

    return formatted_results