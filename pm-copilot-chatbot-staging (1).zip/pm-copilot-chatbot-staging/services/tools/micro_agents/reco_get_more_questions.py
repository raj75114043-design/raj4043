from datetime import datetime
from typing import Any, Dict, List
from services.config_llm import LLMConfig
llm = LLMConfig.openai()
from langchain.prompts import PromptTemplate
import json
import re

async def get_more_questions(user_query: str, recommendation_examples_all):
    """
    If no relevant tables were found for the user's question,
    this function asks the LLM to suggest 3 related or refined questions
    that might help retrieve data or insights from the available dataset.
    """

    prompt = """
You are a telecom data reasoning assistant working on a **radio swap project**.  

Your goal is to help generate **data-oriented questions** whenever the system cannot find data directly related to a user's query.

---

# Objective
Transform a user's query into **3 refined or alternative questions** that are specific, measurable, and can be answered using typical telecom project datasets.

---

# Your Tasks
1. Analyze the user's question carefully.
2. Review the provided **problems and recommendation examples**.
3. Take guidance from the recommendations to help frame **relevant, actionable questions**.  
   - For example, if a recommendation focuses on vendor performance, ensure at least one generated question relates to vendors or metrics associated with them.
   - Similarly, if a recommendation highlights HSE compliance, revisit count, or rollback incidents, generate questions targeting these measurable aspects.
4. Generate **3 alternative questions** that are:
   - Data-focused and measurable
   - Related to site status, delays, vendor performance, milestone progress, compliance, or similar telecom project metrics
5. Avoid general business questions or questions that cannot be answered using project datasets.
6. **Important:** Only ask for direct values, counts, percentages, or metrics.  
   - Do NOT ask “how,” “why,” or “what actions” type questions.
   - Focus solely on measurable data that can be retrieved from datasets.

---

# Input
## User Query
{user_query}

## Problems and Recommendations
{recommendation_examples_all}

---

# Output Format
Return **JSON only** in the following format:

{{
    "related_questions": [
        "question_1",
        "question_2",
        "question_3"
    ]
}}

# Additional Guidelines
- Keep questions simple, clear, and actionable.
- Make sure each question is relevant to the dataset and measurable.
- Explicitly leverage the recommendations to make questions more targeted.
- Avoid duplication; each question should cover a distinct aspect.
- Strictly follow the Output Format.

**IMPORTANT RULES**
- Only use fix time periods, like year, quarter, months, weeks or days.
"""


    llm = LLMConfig.openai()  # or whichever LLM interface you use

    prompt_template = PromptTemplate(
        input_variables=["user_query", "recommendation_examples_all"],
        template=prompt
    )

    chain = prompt_template | llm

    try:
        response = await chain.ainvoke({
            "user_query": user_query,
            "recommendation_examples_all": recommendation_examples_all
        })
        raw = response.content.strip()

        # Extract and parse JSON safely
        match = re.search(r"\{[\s\S]*\}", raw)
        json_str = match.group(0) if match else raw
        parsed = json.loads(json_str)

        questions = parsed.get("related_questions", [])
        if not isinstance(questions, list):
            questions = [questions]

        return questions
    
    except Exception as e:
        print("get_more_questions: Parsing failed ->", e)
        print("Raw response:", response.content if 'response' in locals() else 'No response')
        return []