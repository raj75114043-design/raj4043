
from langchain.prompts import PromptTemplate
from pydantic import BaseModel, Field
from typing import List
from langchain_core.output_parsers import JsonOutputParser


from services.config_llm import LLMConfig
from services.prompts import fallback_result
llm = LLMConfig.openai()


class suggested_question(BaseModel):
    """List of Suggested Questions"""
    questions: List[str] = Field(description="Two suggested questions")


template=PromptTemplate.from_template(fallback_result)
sugg_chain=template|llm
async def get_reponse(state):
    query=state['query']
    
    sugg_output  = sugg_chain.invoke({"query":query})
    state['response']=sugg_output.content
    return state