
import asyncio
from services.config_llm import LLMConfig
llm = LLMConfig.openai()
from langchain.prompts import PromptTemplate

async def get_graph_type_and_columns(question: str, table_md: str) -> list[str]:

    prompt = f"""
You are a **Data Visualization Expert** helping to automatically determine the best chart type
and the relevant columns from a database table.

---

### USER QUESTION:
{question}

---

### TABLE SCHEMA (Markdown Columns):
{table_md}

---

### YOUR TASK:
Based on the user’s question and the table schema:
1. Identify **the most appropriate single chart type** to visualize the requested insight.
2. Select **only ONE chart** type from this list:
   - `barChart`
   - `lineChart`
   - `pieChart`
   - `scatterPlot`
3. Use **only exact column names** from the table schema for `x`, `y`, `labels`, or `values`.
4. Provide a **descriptive title** and **labels** that match the user's intent.
5. Return a **strict JSON array** with **exactly one object** (no explanations, no text before or after).

---

### STRICT OUTPUT FORMAT (choose one depending on chart type)

**1. Bar Chart**
[
  {{{{
    "barChart": {{{{
      "title": "<CHART TITLE>",
      "x": "<COLUMN_NAME>",
      "y": "<COLUMN_NAME>",
      "label": "<LABEL>"
    }}}}
  }}}}
]

**2. Line Chart**
[
  {{{{
    "lineChart": {{{{
      "title": "<CHART TITLE>",
      "x": "<COLUMN_NAME>",
      "y": "<COLUMN_NAME>",
      "x_label": "<LABEL>",
      "y_label": "<LABEL>"
    }}}}
  }}}}
]

**3. Pie Chart**
[
  {{{{
    "pieChart": {{{{
      "title": "<CHART TITLE>",
      "labels": "<COLUMN_NAME>",
      "values": "<COLUMN_NAME>"
    }}}}
  }}}}
]

**4. Scatter Plot**
[
  {{{{
    "scatterPlot": {{{{
      "title": "<CHART TITLE>",
      "dataset": [
        {{{{
          "x": "<COLUMN_NAME>",
          "y": "<COLUMN_NAME>",
          "label": "<LABEL>"
        }}}}
      ],
      "x_label": "<LABEL>",
      "y_label": "<LABEL>"
    }}}}
  }}}}
]
"""

    llm = LLMConfig.openai()
    prompt_template = PromptTemplate(
        input_variables=["question", "table_md"],
        template=prompt
    )
    chain = prompt_template | llm 
    response = await chain.ainvoke({"question": question, "table_md": table_md})
    return response.content

