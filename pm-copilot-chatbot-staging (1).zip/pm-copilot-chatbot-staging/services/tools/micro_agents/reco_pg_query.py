from database.session import get_session_ctx
from sqlalchemy import text
import pandas as pd

async def reco_pg_query_tool(query):
    """Run a SQL query against the PostgreSQL database."""
    from datetime import datetime
    start = datetime.now()
    from database.session import get_session_ctx
    from sqlalchemy import text
    import pandas as pd

    async with get_session_ctx() as session:
        try:
            result = await session.execute(text(query))
            row = result.fetchall()
            df = pd.DataFrame(row, columns=result.keys())
            df_markdown = df.to_markdown(index=False)
            end = datetime.now()
            print(f'Hitting PG Complete {end-start}')
            return df_markdown, False
        except Exception as e:
            return e, True
        
async def reco_pg_query_return_df_tool(query):
    """Run a SQL query against the PostgreSQL database."""
    from datetime import datetime
    start = datetime.now()
    from database.session import get_session_ctx
    from sqlalchemy import text
    import pandas as pd

    async with get_session_ctx() as session:
        try:
            result = await session.execute(text(query))
            row = result.fetchall()
            df = pd.DataFrame(row, columns=result.keys())
            end = datetime.now()
            print(f'Hitting PG Complete {end-start}')
            return df, False
        except Exception as e:
            return e, True