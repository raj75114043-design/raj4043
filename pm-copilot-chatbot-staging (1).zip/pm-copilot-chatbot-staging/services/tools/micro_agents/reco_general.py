from langchain.prompts import PromptTemplate
from pydantic import BaseModel, Field
from typing import List
from langchain_core.output_parsers import JsonOutputParser

import os 
from services.config_llm import LLMConfig
from services.micro_agent_prompts import recommendation_prompt
from services.tools.micro_agents.intent_classifier import LoadExamplesIntent
llm = LLMConfig.openai()

current_dir = os.path.dirname(os.path.abspath(__file__))
general_file = os.path.join(current_dir, "..", "..", "..","database", "recommendation.json")
example_selector=LoadExamplesIntent(general_file)


template=PromptTemplate.from_template(recommendation_prompt)
sugg_chain=template|llm
async def get_general_recommendation(query):
    examples=example_selector.get_examples(query)
    examples_selected="\n\n".join([f"Problem: {i['problem']} \nRecommendation: {i['recommendation']}" for i in examples])
    sugg_output=sugg_chain.invoke({
    "examples":examples_selected,
    "problem": query
    })
    response = sugg_output.content
    return response
