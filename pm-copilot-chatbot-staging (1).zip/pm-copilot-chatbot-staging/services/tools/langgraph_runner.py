from langgraph.graph import StateGraph, START, END

from services.tools.kpisearch import kpi_search
from services.tools.qbsearch import qb_search
from services.tools.table_selection import schema_search
from services.tools.sqlgeneration import sql_generate
from services.tools.run_sql_query import pg_query_tool
from services.tools.router import kpi_router, qb_router, error_correction
from services.tools.check_followup import check_followup
from services.tools.followup_query_rewrite import followup_query_rewrite
from services.tools.suggestedQ import suggested_generate
from services.tools.textResponse import text_generate
from services.tools.state import convbiState
from services.tools.micro_agents.intent_classifier import get_intent,route_from_intent
from services.tools.micro_agents.suggest_question_no_schema import get_suggestions
from services.tools.micro_agents.general_responce import get_reponse
# from services.tools.micro_agents.recommendation import get_recommendation
import logging
from typing import Dict, Any, Literal

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

class LangGraphRunner:
    def __init__(self):
        self.graph = StateGraph(convbiState)
        self._build_graph()
        self.workflow = self.graph.compile()

    def _build_graph(self):
        """Add nodes and edges to the graph."""
        self.graph.add_node("intent_node", get_intent)
        self.graph.add_node("kpi_search", kpi_search)
        self.graph.add_node("schema_search", schema_search)
        self.graph.add_node("qb_search", qb_search)
        self.graph.add_node("sql_generate", sql_generate)
        self.graph.add_node("pg_query_tool", pg_query_tool)
        self.graph.add_node("check_followup", check_followup)
        self.graph.add_node("followup_query_rewrite", followup_query_rewrite)
        self.graph.add_node("text_response", text_generate)
        self.graph.add_node("general_response",get_reponse)
        self.graph.add_node("suggested_questions",suggested_generate)
        self.graph.add_node("get_suggestions_no_schema",get_suggestions)
        # self.graph.add_node("recommendation",get_recommendation)
        
        
        ##new
        self.graph.add_edge(START,"intent_node")
        self.graph.add_conditional_edges("intent_node",route_from_intent,{
            "check_followup":"check_followup",
            "general":"general_response"
            # "recommendation": "recommendation"
        })
        ##new
        self.graph.add_conditional_edges("check_followup", kpi_router)
        self.graph.add_conditional_edges("check_followup", qb_router)
        self.graph.add_edge("followup_query_rewrite", "kpi_search")
        self.graph.add_edge("followup_query_rewrite", "qb_search")
        self.graph.add_edge("kpi_search", "schema_search")

        self.graph.add_edge(["schema_search","qb_search"], "sql_generate")
        self.graph.add_edge("sql_generate", "pg_query_tool")
        self.graph.add_conditional_edges("pg_query_tool", error_correction)
        self.graph.add_edge("schema_search","suggested_questions")
        self.graph.add_edge(["suggested_questions","text_response"],END)
        self.graph.add_edge("general_response","get_suggestions_no_schema")
        # self.graph.add_edge("recommendation","get_suggestions_no_schema")
        self.graph.add_edge("get_suggestions_no_schema",END)
    async def run(self, inputs: dict) -> Dict[str, Any]:
        """Run the compiled workflow with given query."""
        try:
            input_state = {"query": inputs['query'], "previous_query": inputs.get('previous_query', ''), "previous_sql": inputs.get('previous_sql', '')}
            logger.info(f"Running LangGraph workflow with query: {input_state}")
            result = await self.workflow.ainvoke(input_state)
            logger.info("Workflow completed successfully")
            return result
        except Exception as e:
            logger.error(f"LangGraph workflow failed: {str(e)}", exc_info=True)
            raise RuntimeError("Workflow execution failed") from e

