from.state import convbiState
from database.session import get_session_ctx
from sqlalchemy import text
import pandas as pd
from datetime import datetime
from services.config_llm import LLMConfig
from services.prompts import fallback_result



async def pg_query_tool(state: convbiState):
    """Run a SQL query against the PostgreSQL database."""
    start = datetime.now()
    print('Hitting PG Started')
    query = state['sql']
    if state['followup_flag'] and state['follow_up_query'] is not None:
        user_query = state['follow_up_query']
    else:
        user_query = state['query']
    async with get_session_ctx() as session:
        try:
            result = await session.execute(text(query))
            row = result.fetchall()
            df = pd.DataFrame(row, columns=result.keys())
            df_markdown = df.to_markdown(index=False)
            end = datetime.now()
            print(f'Hitting PG Complete {end-start}')
            return {"df": df_markdown,"sql_error":['']}
        except Exception as e:
            print(e)
            llm = LLMConfig.openai()
            res = llm.invoke(fallback_result.format(query = user_query))
            answer = res.content
            return {"df": answer,"sql_error":[e]}
