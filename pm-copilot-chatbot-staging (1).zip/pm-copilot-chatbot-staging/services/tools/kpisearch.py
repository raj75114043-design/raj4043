import asyncio
import re
import pandas as pd
from rapidfuzz import fuzz
from dotenv import load_dotenv
from sqlalchemy import text
from .state import convbiState
from database.session import get_session_ctx

load_dotenv()

# --- CPU-bound function moved out of async context ---
def _run_fuzzy_matching(word_combinations, kpi_dict, threshold):
    """Perform fuzzy matching between query word combinations and KPI synonyms."""
    matches = {}
    stop_words = {'show', 'me', 'the', 'in', 'for', 'of', 'and', 'with', 'by', 'terms'}

    def _match_phrase(phrase: str, target: str) -> float:
        if len(phrase) < 3:
            return 0.0
        token_sort = fuzz.token_sort_ratio(phrase, target) / 100
        token_set = fuzz.token_set_ratio(phrase, target) / 100
        partial = fuzz.partial_ratio(phrase, target) / 100 if len(phrase) > 4 else 0
        return max(token_sort, token_set, partial)

    for combo in word_combinations:
        for kpi, synonyms in kpi_dict.items():
            for synonym in synonyms:
                confidence = _match_phrase(combo, synonym.lower())
                if confidence >= threshold:
                    matches[kpi] = max(matches.get(kpi, 0), confidence)

    return matches


async def kpi_search(state: convbiState):
    print('3. KPI node started')

    # Step 1: Pick the right query
    if state['followup_flag'] and state['follow_up_query'] is not None:
        query = state['follow_up_query']
    else:
        query = state['query']

    threshold = 0.85
    stop_words = {'show', 'me', 'the', 'in', 'for', 'of', 'and', 'with', 'by', 'terms'}

    # Step 2: Get KPI dictionary from DB
    async with get_session_ctx() as session:
        kpi_sql = """
            SELECT k.name, array_agg(s.synonym) as synonyms
            FROM osdp_pwc_sch.kpis k
            LEFT JOIN osdp_pwc_sch.kpi_synonyms s ON k.id = s.kpi_id
            GROUP BY k.id, k.name
        """
        result = await session.execute(text(kpi_sql))
        rows = result.fetchall()
        df = pd.DataFrame(rows, columns=['name', 'synonyms'])
        kpi_dict = df.set_index('name')['synonyms'].apply(lambda x: [syn for syn in x if syn is not None]).to_dict()

    # Step 3: Preprocess query
    query = query.lower()
    query = re.sub(r'[^\w\s]', ' ', query)
    query = ' '.join(word for word in query.split() if word not in stop_words)
    words = query.split()

    # Step 4: Generate word combinations
    word_combinations = []
    max_length = 3
    for i in range(len(words)):
        for j in range(i + 1, min(i + max_length + 1, len(words) + 1)):
            word_combinations.append(' '.join(words[i:j]))

    # Step 5: Offload CPU-bound fuzzy matching
    matches = await asyncio.to_thread(_run_fuzzy_matching, word_combinations, kpi_dict, threshold)

    print("Keywords matched: ", matches)
    print('3. KPI node complete')
    return {"kpi": list(matches.keys())}
