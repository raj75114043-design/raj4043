from services.config_llm import LLMConfig
from langchain.prompts import PromptTemplate
from.state import convbiState
from services.prompts import text

async def text_generate(state : convbiState):

    if state['followup_flag'] and state['follow_up_query'] is not None:
        user_query = state['follow_up_query']
    else:
        user_query = state['query']

    table = state['df']

    if table == "Sorry I cannot answer the query right now":
        return {"response" : table}     
        
    llm = LLMConfig.openai_gpt5_mini()

    prompt = PromptTemplate(
                template= text,
                input_variables= ["query","table"]
                )

    chain = prompt | llm

    text_output  = await chain.ainvoke({"query":user_query,'table':table})
    return {"response" : text_output.content} 