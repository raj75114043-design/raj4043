import time
from datetime import datetime, date
from sqlalchemy.ext.asyncio import AsyncSession
# from tools.models import ConversationLog, ProcessingStep
from tools.models import ConversationLog, ProcessingStep
from sqlalchemy.dialects.postgresql import UUID
from uuid import uuid4
import json

async def log_conversation(connection, query: str,follow_up_flag:str,followup_query:str , sql: str, user_id: UUID, duration: float) :
    conversation_id = uuid4()
    created_at = datetime.now()
    try:
        await connection.execute(
            """
            INSERT INTO conversation_logs (conversation_id, user_id, user_query,follow_up_flag,followup_query, final_sql, execution_time, created_at)
            VALUES ($1, $2, $3, $4, $5, $6,$7,$8)
            """,
            conversation_id, user_id, query,follow_up_flag,followup_query, sql, duration, created_at
        )
        return conversation_id
    except Exception as e:
        raise

async def log_step(connection, conv_id: UUID, step_name: str, input_data: str, output_data: str, duration: float):
    try:
        await connection.execute(
            """
            INSERT INTO processing_steps (step_id, conversation_id, step_name, step_input, step_output, execution_time)
            VALUES ($1, $2, $3, $4, $5, $6)
            """,
            uuid4(), conv_id, step_name, input_data, output_data, duration
        )
    except Exception as e:
        raise

def measure_time():
    """Context manager to measure execution time"""
    return time.perf_counter()