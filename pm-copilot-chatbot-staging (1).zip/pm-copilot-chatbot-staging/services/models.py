from sqlalchemy import Column, String, DateTime, Text, ForeignKey, Float, JSON, Index, UniqueConstraint, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid
from sqlalchemy.dialects.postgresql import UUID, JSONB
from datetime import date

Base = declarative_base()

# def generate_uuid():
#     return str(uuid.uuid4())

class User(Base):
    __tablename__ = "users"
    user_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, nullable=False)
    created_at = Column(DateTime, default=date.today())
    last_active = Column(DateTime, default=date.today())

class ConversationLog(Base):
    __tablename__ = "conversation_logs"
    conversation_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.user_id'))
    user_query = Column(Text, nullable=False)
    # final_query = Column(Text, nullable=False)
    follow_up_flag= Column(Text, nullable=False)
    followup_query = Column(Text, nullable=False)
    final_sql = Column(Text)
    # result_json = Column(JSONB)
    execution_time = Column(Float)
    created_at = Column(DateTime, default=datetime.now())

    # New columns - add these AFTER database is updated
    is_favorited = Column(Boolean, default=False, nullable=False)
    title = Column(String(255), default='', nullable=False)
    updated_at = Column(DateTime, default=datetime.now(), onupdate=datetime.now())
    steps = relationship("ProcessingStep", back_populates="conversation",cascade="all, delete-orphan")


class ProcessingStep(Base):
    __tablename__ = "processing_steps"
    
    # step_id = Column(String(36), primary_key=True, default=generate_uuid)
    step_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey('conversation_logs.conversation_id'))
    #conversation_id = Column(UUID(as_uuid=True))
    step_name = Column(String(100))
    step_input = Column(Text)
    step_output = Column(Text)
    execution_time = Column(Float)
    created_at = Column(DateTime, default=date.today())
    
    conversation = relationship("ConversationLog", back_populates="steps")


class Feedback(Base):
    __tablename__ = "feedback"
    
    feedback_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    conversation_id = Column(UUID(as_uuid=True), ForeignKey('conversation_logs.conversation_id'), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey('users.user_id'), nullable=False)
    feedback_type = Column(String(20), nullable=False)
    created_at = Column(DateTime, default=datetime.now())
    updated_at = Column(DateTime, default=datetime.now(), onupdate=datetime.now())
    __table_args__ = (
        UniqueConstraint('user_id', 'conversation_id', name='unique_user_conversation_feedback'),
    )
    
