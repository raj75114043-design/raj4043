import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_openai import OpenAIEmbeddings
 
# Load environment variables from .env
load_dotenv()
 
 
class LLMConfig:
    @staticmethod
    def openai():
        """Initializes and returns a GPT-4o ChatOpenAI instance using environment variables."""
 
        base_url = os.getenv("LLM_API_KEY_URL")
        api_key = os.getenv("OPENAI_API_KEY")
        workspace_name = os.getenv("OPENAI_WORKSPACE_NAME")
 
        if not all([base_url, api_key, workspace_name]):
            raise EnvironmentError("Missing one or more OpenAI environment variables.")
 
        return ChatOpenAI(
            api_key="NONE",  
            model="gpt-4o-mini",
            base_url=base_url,
            default_headers={
                "api-key": api_key,
                "workspacename": workspace_name
            },
            temperature=0,
            verbose=True,
            max_completion_tokens= 12000
        )
    
    @staticmethod
    def openai_gpt5_mini():
        """Initializes and returns a GPT-4o ChatOpenAI instance using environment variables."""
 
        base_url = os.getenv("LLM_API_KEY_URL")
        api_key = os.getenv("OPENAI_API_KEY")
        workspace_name = os.getenv("OPENAI_WORKSPACE_NAME")
 
        if not all([base_url, api_key, workspace_name]):
            raise EnvironmentError("Missing one or more OpenAI environment variables.")
 
        return ChatOpenAI(
            api_key="NONE",  
            model="gpt-5-mini",
            base_url=base_url,
            default_headers={
                "api-key": api_key,
                "workspacename": workspace_name
            },
            temperature=0,
            verbose=True
        )
       
    @staticmethod
    def openai_embedding():
        """Initializes and returns a OpenAI Embedding model instance using environment variables."""
 
        EMBED_API_URL = os.getenv("LLM_API_KEY_URL")
        EMBED_API_KEY = os.getenv("OPENAI_API_KEY")
        workspacename= os.getenv("workspacename")
       
       
        embedding_model = OpenAIEmbeddings(
            api_key="NONE",
            base_url= EMBED_API_URL,
            default_headers={
                'api-key': EMBED_API_KEY,
                'workspacename': workspacename
            },
            model="text-embedding-ada-002"
        )
       
        return embedding_model