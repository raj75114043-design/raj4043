API SERVER : uvicorn main:app --reload --port 8001 --log-level debug
STREAMLIT APP : uv run streamlit run streamlit_app.py


Ho to create UV enviorment
1- uv cache clean (optonal)
2- uv sync
3-.venv/Scripts/activate