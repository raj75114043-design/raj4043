from pydantic import BaseModel, Field
from typing import List, Optional


class ChatHistoryItem(BaseModel):
    question: str
    answer: str
    previous_query: Optional[str] = None
    previous_sql: Optional[str] = None


class RecoRequest(BaseModel):
    question: str = Field(..., description="User's current question")
    chat_history: List[ChatHistoryItem] = Field(default_factory=list)
    previous_query: Optional[str] = Field(default=None, description="Optional follow-up query")
    previous_sql: Optional[str] = Field(default=None, description="Optional follow-up query")
    chat_session_id: str = Field(..., description="Unique chat session ID")
    user_id: str = Field(..., description="User ID")
    
class RecoResponse(BaseModel):
    chat_session_id: str = Field(..., description="Unique chat session ID")
    user_id: str = Field(..., description="User ID")
    question: str = Field(..., description="User's current question (reframed if followup)")
    answer: str = Field(..., description="Answer in markdown format")
    sql_query: str = Field(..., description="Generated SQL query")
    previous_query: Optional[str] = Field(default=None, description="Optional follow-up query")
    suggested_question: List[str] = Field(default_factory=list, description="Follow-up questions")
    response : str = Field(..., description="Result of table as a text")
