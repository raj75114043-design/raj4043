from fastapi import APIRouter, HTTPException
from api.schemas.query_model import QueryRequest, QueryResponse
from services.tools.langgraph_runner import LangGraphRunner
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from traceback import format_exc

console=Console()
router = APIRouter()

@router.post("/query", response_model=QueryResponse, summary="AI Assistant")
async def run_query(payload: QueryRequest):
    """
    Accepts a user question along with optional chat history, user ID, and session ID.
    Processes the query using the LangGraph workflow and returns a markdown answer, SQL query, and suggested follow-ups.
    """
    try:
        workflow = LangGraphRunner()
        result = await workflow.run({"query":payload.question,
                                     "previous_query": payload.previous_query,
                                     "previous_sql": payload.previous_sql,
                                     "intent":"",
                                     "followup_flag":False})
        # answer = result['df'] # TABLE SWITCHED TO TEXT
        answer = result['response']

        if result['followup_flag'] and result['follow_up_query'] is not None:
            question = result['follow_up_query']
        else:
            question = result['query']
        if 'sql' in result:
            sql_query = result['sql']
        else:
            sql_query=""
        suggested_question = result['suggested_ques']
        previous_query = result['previous_query']
        #print(result['df'])
        # response = result['response'] # TEXT SWITCHED TO TABLE
        if 'df' not in result:
            response=""
        else:
            response = result['df']
        

        console.print(Panel("Query processed successfully",
        title="Success",
        subtitle="Query Route hadnler",
        style="green"))

        return QueryResponse(
            chat_session_id=payload.chat_session_id,
            user_id=payload.user_id,
            question=question,
            answer=answer,
            sql_query=sql_query,
            suggested_question=suggested_question,
            previous_query=previous_query,
            response=response
        )
    except Exception as e:
        print(format_exc())
        raise HTTPException(status_code=500, detail=str(e))
