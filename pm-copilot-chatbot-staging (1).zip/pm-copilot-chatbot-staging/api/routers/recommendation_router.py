from fastapi import APIRouter, HTTPException
from api.schemas.recommendation_model import RecoRequest, RecoResponse
from services.tools.micro_agents.reco_orchestrator import recommend_orch
from services.tools.micro_agents.suggest_question_reco_agent import get_suggestions
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from traceback import format_exc

console=Console()
router = APIRouter()

@router.post("/recommend", response_model=RecoResponse, summary="To get Recommendations")
async def run_query(payload: RecoRequest):
    """
    Accepts a user question along with optional chat history, user ID, and session ID.
    Processes the query using the Recommendation workflow and returns a markdown answer, and suggested follow-ups.
    """
    try:
        query = payload.question
        question = query
        answer = await recommend_orch(query)
        sql_query=""
        suggested_question = await get_suggestions(query)
        response = ""
        previous_query = ""

        console.print(Panel("Query processed successfully",
        title="Success",
        subtitle="Recommendation Route hadnler",
        style="green"))

        return RecoResponse(
            chat_session_id=payload.chat_session_id,
            user_id=payload.user_id,
            question=question,
            answer=answer,
            sql_query=sql_query,
            suggested_question=suggested_question,
            previous_query=previous_query,
            response=response
        )
    except Exception as e:
        print(format_exc())
        raise HTTPException(status_code=500, detail=str(e))
