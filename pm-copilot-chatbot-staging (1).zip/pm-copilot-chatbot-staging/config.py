from pydantic_settings import BaseSettings, SettingsConfigDict
from urllib.parse import quote_plus
 
 
class DatabaseSettings(BaseSettings):
    POSTGRES_SERVER: str
    POSTGRES_USER: str
    POSTGRES_PASSWORD: str
    POSTGRES_DB: str
    POSTGRES_PORT:int
    POSTGRES_SCHEMA:str
   
    model_config = SettingsConfigDict(env_file='./.env', env_ignore_empty=True, extra="ignore")
   
 
    @property
    def POSTGRES_URL(self):
        user = quote_plus(self.POSTGRES_USER)
        password = quote_plus(self.POSTGRES_PASSWORD)
        return f"postgresql+asyncpg://{user}:{password}@{self.POSTGRES_SERVER}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
   
    @property
    def POSTGRES_URL_psycopg(self):
        user = quote_plus(self.POSTGRES_USER)
        password = quote_plus(self.POSTGRES_PASSWORD)
        schema_name=quote_plus(self.POSTGRES_SCHEMA)
        connection_string =  (
                            f"postgresql+psycopg_async://{user}:{password}"
                            f"@{self.POSTGRES_SERVER}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
                            f"?options=-csearch_path%3D{schema_name}"
                        )
        return connection_string
 
 
settings = DatabaseSettings()