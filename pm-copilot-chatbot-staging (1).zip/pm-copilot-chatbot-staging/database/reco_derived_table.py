qs = [
    {
        "table":"market_median_cycle_times",
        "id":"prerequisite_trends",
        "description": "Contains median cycle times (in days) between major telecom project milestones, calculated per market from the tmo_retro_trial_consolidate table. Used to analyze project execution efficiency and identify bottlenecks across markets. Includes median durations for stages: entitlement to NTP acceptance, NTP to BOM receipt, BOM to material pickup, and material pickup to construction start. Useful for comparing market-wise performance, vendor efficiency, and tracking process delays in the radio swap or site upgrade lifecycle.",
        "sql":"""SELECT 
    mb_market AS market,

    PERCENTILE_CONT(0.5) WITHIN GROUP (
        ORDER BY (mb_pj_a4100_construction_ntp_accepted_by_gc_finish - mb_pj_a_3710_ran_entitlement_complete_finish)
    ) AS median_time_ent_to_ntp_entitlement_days,


    PERCENTILE_CONT(0.5) WITHIN GROUP (
        ORDER BY (mb_pj_a3875_bom_received_bom_in_aims_finish  - mb_pj_a4100_construction_ntp_accepted_by_gc_finish)
    ) AS median_time_ran_ntp_to_bom_days,


    PERCENTILE_CONT(0.5) WITHIN GROUP (
        ORDER BY (mb_pj_a3925_msl_pickup_date_finish - mb_pj_a3875_bom_received_bom_in_aims_finish)
    ) AS median_time_bom_to_material_pickup_days,


    PERCENTILE_CONT(0.5) WITHIN GROUP (
        ORDER BY (mb_pj_a4225_construction_start_finish  - mb_pj_a3925_msl_pickup_date_finish)
    ) AS median_time_meterial_pickup_to_construction_start_days

FROM tmo_retro_trial_consolidate
WHERE 
    mb_pj_a3875_bom_received_bom_in_aims_finish IS NOT NULL AND mb_pj_a_3710_ran_entitlement_complete_finish IS NOT NULL AND
    mb_pj_a4100_construction_ntp_accepted_by_gc_finish IS NOT NULL AND mb_pj_a3925_msl_pickup_date_finish IS NOT NULL AND
    mb_pj_a4225_construction_start_finish IS NOT NULL
GROUP BY mb_market
ORDER BY mb_market;"""
    },
    {
        "table":"GC/Vendor/Crew Daily CAPACITY and Availibility by Market",
        "id":"daily_capacity_by_marketr",
        "description": "Shows total GC/Vendor crew capacity and availability at the market level. Calculated from gc_capacity_market_trial and tmo_retro_trial_consolidate tables. It measures how many crews are allocated versus busy in active construction work. Includes total capacity, number of busy crews, and available crews per market. Useful for assessing vendor resource utilization, identifying under- or over-loaded markets, and planning future site execution schedules efficiently.",
        "sql":"""WITH total_capacity AS (
    SELECT 
        market, 
        SUM(day_wise_gc_capacity) AS total_gc_capacity_per_market
    FROM 
        public.gc_capacity_market_trial
    GROUP BY 
        market
),
busy_crews AS (
    SELECT 
        mb_market AS market,
        COUNT(*) AS busy_crews
    FROM 
        tmo_retro_trial_consolidate
    WHERE 
        nd_ms_1555_construction_complete_actual IS NULL
        AND nd_implementationvendor IS NOT NULL
    GROUP BY 
        mb_market
)
SELECT 
    c.market,
    c.total_gc_capacity_per_market,
    COALESCE(b.busy_crews, 0) AS busy_crews,
    (c.total_gc_capacity_per_market - COALESCE(b.busy_crews, 0)) AS available_crews
FROM 
    total_capacity c
LEFT JOIN 
    busy_crews b 
ON 
    lower(c.market) = lower(b.market)
ORDER BY 
    c.market;

        """
    },
    {
        "table": "Completed VS WIP VS Scheduled Sites",
        "id": "site_level_info",
        "description": "Provides market-level summary of total, completed, work-in-progress (WIP), and scheduled telecom sites using data from tmo_retro_trial_consolidate. Helps track project progress by showing how many sites have started, are under construction, or are yet to begin. Useful for monitoring rollout performance, identifying markets with delays, and managing construction timelines effectively.",
        "sql":"""SELECT 
            mb_market AS market,
        
            COUNT(*) AS total_sites,
        
            COUNT(*) FILTER (
                WHERE nd_ms_1550_construction_start_actual IS NOT NULL
                  AND nd_ms_1555_construction_complete_actual IS NOT NULL
            ) AS completed_sites,
        
            COUNT(*) FILTER (
                WHERE nd_ms_1550_construction_start_actual IS NOT NULL
                  AND nd_ms_1555_construction_complete_actual IS NULL
            ) AS wip_sites,
        
            COUNT(*) FILTER (
                WHERE nd_ms_1550_construction_start_actual IS NULL
                  AND nd_ms_1555_construction_complete_actual IS NULL
            ) AS pending_sites
            
        FROM 
            tmo_retro_trial_consolidate
        GROUP BY 
            mb_market
        ORDER BY 
            mb_market;
        """

    },
    {
        "table": "Average Weekly Run Rate",
        "id": "weekly_run_rate_by_market",
        "description": "Shows the average number of site swaps completed per week at the market level, derived from tmo_retro_trial_consolidate. Represents market productivity trends and helps track weekly execution performance. Useful for identifying high-performing markets, assessing crew efficiency, and setting realistic rollout targets based on historical swap completion data.",
        "sql":"""SELECT 
                mb_market,
                ROUND(AVG(sites_completed)::NUMERIC, 2) AS avg_run_rate_per_week
            FROM (
                SELECT 
                    mb_market,
                    DATE_TRUNC('week', pm_swap_actual_date) AS week_start,
                    COUNT(mb_site_code) AS sites_completed
                FROM 
                    tmo_retro_trial_consolidate
                WHERE 
                    pm_swap_actual_date IS NOT NULL
                GROUP BY 
                    mb_market, DATE_TRUNC('week', pm_swap_actual_date)
            ) AS weekly_data
            GROUP BY 
                mb_market
            ORDER BY 
                avg_run_rate_per_week DESC;
            """

    },
     {
        "table":"Average Weekly Run Rate by vendor/GC/Crew",
         "id":"weekly_run_eate_by_vendor",
        "description": "Displays the average number of site swaps completed per week by each Vendor, GC, or Crew, based on data from tmo_retro_trial_consolidate. It measures productivity performance at the execution-resource level rather than just by market. Useful for comparing vendor efficiency, identifying top-performing crews, and optimizing resource allocation to improve weekly site completion rates.",
        "sql":"""SELECT 
                mb_market,
                ROUND(AVG(sites_completed)::NUMERIC, 2) AS avg_run_rate_per_week
            FROM (
                SELECT 
                    mb_market,
                    DATE_TRUNC('week', pm_swap_actual_date) AS week_start,
                    COUNT(mb_site_code) AS sites_completed
                FROM 
                    tmo_retro_trial_consolidate
                WHERE 
                    pm_swap_actual_date IS NOT NULL
                GROUP BY 
                    mb_market, DATE_TRUNC('week', pm_swap_actual_date)
            ) AS weekly_data
            GROUP BY 
                mb_market
            ORDER BY 
                avg_run_rate_per_week DESC;
            """
    },
    {
        "table":"Prerequisites for GO/NoGo sites",
        "id":"prerequisites",
        "description": "This table provides a detailed market-level breakdown of prerequisite readiness for sites where construction has not yet started. It tracks completion of 12 key prerequisites required before swap execution, such as SMP ID availability, RAN entitlement, BOM receipt, NTP acceptance, material pickup, outage approval, site access, vendor assignment, CR/WO creation, SPO provision, outage duration, and crane/manlift check. Useful for identifying GO/No-Go readiness, blocked sites, and overall pre-construction health of each market.",
        "sql":"""WITH total_sites_all AS (
    SELECT 
        mb_region,
        mb_market,
        COUNT(DISTINCT mb_site_code) AS total_sites
    FROM tmo_retro_trial_consolidate
    GROUP BY mb_region, mb_market
),
prereq_flags AS (
    SELECT 
        trtc.mb_region,
        trtc.mb_market,
        trtc.mb_site_code,

        -- Individual prerequisite flags
        CASE WHEN trtc.nd_smp_id IS NOT NULL THEN 1 ELSE 0 END AS prereq_1_smp_id,
        CASE WHEN trtc.mb_pj_a_3710_ran_entitlement_complete_finish IS NOT NULL THEN 1 ELSE 0 END AS prereq_2_ran_entitlement,
        CASE WHEN trtc.mb_pj_a3875_bom_received_bom_in_aims_finish IS NOT NULL THEN 1 ELSE 0 END AS prereq_3_bom_received,
        CASE WHEN trtc.mb_pj_a4100_construction_ntp_accepted_by_gc_finish IS NOT NULL THEN 1 ELSE 0 END AS prereq_4_ntp_accepted,
        CASE WHEN trtc.mb_pj_a3925_msl_pickup_date_finish IS NOT NULL THEN 1 ELSE 0 END AS prereq_5_msl_pickup,
        CASE WHEN LOWER(trtc.pm_outage_approval_status) = 'yes' THEN 1 ELSE 0 END AS prereq_6_outage_approval,
        CASE WHEN trtc.mb_site_access IS NOT NULL THEN 1 ELSE 0 END AS prereq_7_site_access,
        CASE WHEN trtc.nd_implementationvendor IS NOT NULL THEN 1 ELSE 0 END AS prereq_8_vendor,
        CASE WHEN trtc.pm_activity_cr_wo_no IS NOT NULL THEN 1 ELSE 0 END AS prereq_9_cr_wo,
        CASE WHEN trtc.pm_spo_provided_to_construction_gc IS NOT NULL THEN 1 ELSE 0 END AS prereq_10_spo_provided,
        CASE WHEN trtc.pm_outage_approval_duration IS NOT NULL THEN 1 ELSE 0 END AS prereq_11_outage_duration,
        CASE 
            WHEN trtc.pm_require_crane_or_manlift IS NULL THEN 1
            WHEN LOWER(trtc.pm_require_crane_or_manlift) = 'yes'
                 AND trtc.pm_request_crane_or_manlift_details IS NOT NULL
                 AND trtc.pm_crane_or_manlift_availability IS NOT NULL
            THEN 1
            ELSE 0
        END AS prereq_12_crane_check
    FROM tmo_retro_trial_consolidate trtc
    WHERE trtc.mb_pj_a4225_construction_start_finish IS NULL
),
prereq_summary AS (
    SELECT 
        mb_region,
        mb_market,
        mb_site_code,
        prereq_1_smp_id,
        prereq_2_ran_entitlement,
        prereq_3_bom_received,
        prereq_4_ntp_accepted,
        prereq_5_msl_pickup,
        prereq_6_outage_approval,
        prereq_7_site_access,
        prereq_8_vendor,
        prereq_9_cr_wo,
        prereq_10_spo_provided,
        prereq_11_outage_duration,
        prereq_12_crane_check,
        (
            prereq_1_smp_id + prereq_2_ran_entitlement + prereq_3_bom_received + prereq_4_ntp_accepted +
            prereq_5_msl_pickup + prereq_6_outage_approval + prereq_7_site_access + prereq_8_vendor + prereq_9_cr_wo +
            prereq_10_spo_provided + prereq_11_outage_duration + prereq_12_crane_check
        ) AS total_completed_prereqs
    FROM prereq_flags
)
SELECT
    ps.mb_region,
    ps.mb_market,
 tsa.total_sites,
    COUNT(*) AS construction_not_started_sites,

    -- Summary counts
    SUM(CASE WHEN total_completed_prereqs = 12 THEN 1 ELSE 0 END) AS all_12_prerequisites_completed,
    SUM(CASE WHEN total_completed_prereqs <= 11 THEN 1 ELSE 0 END) AS less_or_equal_to_11_prerequisites_completed,

    -- Individual prerequisite completion counts
    SUM(prereq_1_smp_id) AS sites_with_smp_id,
    SUM(prereq_2_ran_entitlement) AS sites_with_ran_entitlement,
    SUM(prereq_3_bom_received) AS sites_with_bom_received,
    SUM(prereq_4_ntp_accepted) AS sites_with_ntp_accepted,
    SUM(prereq_5_msl_pickup) AS sites_with_material_pickup,
    SUM(prereq_6_outage_approval) AS sites_with_outage_approval,
    SUM(prereq_7_site_access) AS sites_with_site_access,
    SUM(prereq_8_vendor) AS sites_with_vendor,
    SUM(prereq_9_cr_wo) AS sites_with_cr_wo,
    SUM(prereq_10_spo_provided) AS sites_with_spo_provided,
    SUM(prereq_11_outage_duration) AS sites_with_outage_duration,
    SUM(prereq_12_crane_check) AS sites_with_crane_check

FROM prereq_summary ps
LEFT JOIN total_sites_all tsa 
    ON tsa.mb_region = ps.mb_region 
   AND tsa.mb_market = ps.mb_market
GROUP BY ps.mb_region, ps.mb_market, tsa.total_sites
ORDER BY ps.mb_region, ps.mb_market;"""
    },
    {
        "table":"Vendor Performance",
        "id":"vendor_performance",
        "description":"Performance of each vendor is calculated basis the  hse_score (Health and safety),material_pickup_score (TAT fro Meterial Pickup),scrap_return_score (TAT for Scrap return),ndpc_punchpoint_score",
        "sql":"""WITH site_scores AS ( 

    SELECT  

        t.nd_implementationvendor AS gc_vendor, 

        t.mb_site_code, 

        t.mb_market, 

         

        -- HSE metrics per site 

        COUNT(*) AS site_sessions, 

         

        -- Check-in non-compliance % per site 

        CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_check_in_status)) != 'DONE' OR h.tmo_hse_sm_check_in_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) AS check_in_non_comp_pct, 

         

        -- PPE non-compliance % per site 

        CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_ppe_validation)) != 'PASS' OR h.tmo_hse_sm_ppe_validation IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) AS ppe_non_comp_pct, 

         

        -- JSA non-compliance % per site 

        CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_jsa_completion_status)) != 'COMPLETED' OR h.tmo_hse_sm_jsa_completion_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) AS jsa_non_comp_pct, 

         

        -- L2W non-compliance % per site 

        CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_fv_each_crew_ptid_status)) != 'AVAILABLE' OR h.tmo_hse_fv_each_crew_ptid_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) AS l2w_non_comp_pct, 

         

        -- Material Pickup days per site (P3925 - A3925) 

        CAST(t.mb_pj_p3925_msl_pickup_date_finish AS DATE) - CAST(t.mb_pj_a3925_msl_pickup_date_finish AS DATE) AS material_pickup_days, 

         

        -- Scrap Return days per site (Scrap Confirmation - A5175 Construction Complete) 

        CAST(t.pm_scrap_confirmation_date AS DATE) - CAST(t.mb_pj_a5175_construction_complete_finish AS DATE) AS scrap_return_days, 

         

        -- Check-in Score per site 

        CASE  

            WHEN CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_check_in_status)) != 'DONE' OR h.tmo_hse_sm_check_in_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) <= 0.10 THEN 100 

            WHEN CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_check_in_status)) != 'DONE' OR h.tmo_hse_sm_check_in_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) > 0.10  

                 AND CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_check_in_status)) != 'DONE' OR h.tmo_hse_sm_check_in_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) <= 0.25 THEN 75 

            WHEN CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_check_in_status)) != 'DONE' OR h.tmo_hse_sm_check_in_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) > 0.25  

                 AND CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_check_in_status)) != 'DONE' OR h.tmo_hse_sm_check_in_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) <= 0.50 THEN 50 

            ELSE 0 

        END AS check_in_score, 

         

        -- PPE Score per site 

        CASE  

            WHEN CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_ppe_validation)) != 'PASS' OR h.tmo_hse_sm_ppe_validation IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) <= 0.10 THEN 100 

            WHEN CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_ppe_validation)) != 'PASS' OR h.tmo_hse_sm_ppe_validation IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) > 0.10  

                 AND CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_ppe_validation)) != 'PASS' OR h.tmo_hse_sm_ppe_validation IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) <= 0.25 THEN 75 

            WHEN CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_ppe_validation)) != 'PASS' OR h.tmo_hse_sm_ppe_validation IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) > 0.25  

                 AND CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_ppe_validation)) != 'PASS' OR h.tmo_hse_sm_ppe_validation IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) <= 0.50 THEN 50 

            ELSE 0 

        END AS ppe_score, 

         

        -- JSA Score per site 

        CASE  

            WHEN CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_jsa_completion_status)) != 'COMPLETED' OR h.tmo_hse_sm_jsa_completion_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) <= 0.10 THEN 100 

            WHEN CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_jsa_completion_status)) != 'COMPLETED' OR h.tmo_hse_sm_jsa_completion_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) > 0.10  

                 AND CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_jsa_completion_status)) != 'COMPLETED' OR h.tmo_hse_sm_jsa_completion_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) <= 0.25 THEN 75 

            WHEN CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_jsa_completion_status)) != 'COMPLETED' OR h.tmo_hse_sm_jsa_completion_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) > 0.25  

                 AND CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_sm_jsa_completion_status)) != 'COMPLETED' OR h.tmo_hse_sm_jsa_completion_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) <= 0.50 THEN 50 

            ELSE 0 

        END AS jsa_score, 

         

        -- L2W Score per site 

        CASE  

            WHEN CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_fv_each_crew_ptid_status)) != 'AVAILABLE' OR h.tmo_hse_fv_each_crew_ptid_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) <= 0.10 THEN 100 

            WHEN CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_fv_each_crew_ptid_status)) != 'AVAILABLE' OR h.tmo_hse_fv_each_crew_ptid_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) > 0.10  

                 AND CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_fv_each_crew_ptid_status)) != 'AVAILABLE' OR h.tmo_hse_fv_each_crew_ptid_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) <= 0.25 THEN 75 

            WHEN CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_fv_each_crew_ptid_status)) != 'AVAILABLE' OR h.tmo_hse_fv_each_crew_ptid_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) > 0.25  

                 AND CAST(SUM(CASE WHEN UPPER(TRIM(h.tmo_hse_fv_each_crew_ptid_status)) != 'AVAILABLE' OR h.tmo_hse_fv_each_crew_ptid_status IS NULL THEN 1 ELSE 0 END) AS NUMERIC) / NULLIF(COUNT(*), 0) <= 0.50 THEN 50 

            ELSE 0 

        END AS l2w_score, 

         

        -- Material Pickup Score per site 

        CASE  

            WHEN (CAST(t.mb_pj_p3925_msl_pickup_date_finish AS DATE) - CAST(t.mb_pj_a3925_msl_pickup_date_finish AS DATE)) <= 0 THEN 100 

            WHEN (CAST(t.mb_pj_p3925_msl_pickup_date_finish AS DATE) - CAST(t.mb_pj_a3925_msl_pickup_date_finish AS DATE)) = 1 THEN 75 

            WHEN (CAST(t.mb_pj_p3925_msl_pickup_date_finish AS DATE) - CAST(t.mb_pj_a3925_msl_pickup_date_finish AS DATE)) = 2 THEN 50 

            WHEN (CAST(t.mb_pj_p3925_msl_pickup_date_finish AS DATE) - CAST(t.mb_pj_a3925_msl_pickup_date_finish AS DATE)) > 2 THEN 0 

            ELSE NULL 

        END AS material_pickup_score, 

         

        -- Scrap Return Score per site 

        CASE  

            WHEN (CAST(t.pm_scrap_confirmation_date AS DATE) - CAST(t.mb_pj_a5175_construction_complete_finish AS DATE)) <= 10 THEN 100 

            WHEN (CAST(t.pm_scrap_confirmation_date AS DATE) - CAST(t.mb_pj_a5175_construction_complete_finish AS DATE)) > 10  

                 AND (CAST(t.pm_scrap_confirmation_date AS DATE) - CAST(t.mb_pj_a5175_construction_complete_finish AS DATE)) <= 11 THEN 75 

            WHEN (CAST(t.pm_scrap_confirmation_date AS DATE) - CAST(t.mb_pj_a5175_construction_complete_finish AS DATE)) > 11  

                 AND (CAST(t.pm_scrap_confirmation_date AS DATE) - CAST(t.mb_pj_a5175_construction_complete_finish AS DATE)) <= 12 THEN 50 

            WHEN (CAST(t.pm_scrap_confirmation_date AS DATE) - CAST(t.mb_pj_a5175_construction_complete_finish AS DATE)) > 12 THEN 0 

            ELSE NULL 

        END AS scrap_return_score 

         

    FROM tmo_retro_trial_consolidate t 

    INNER JOIN tmo_hse_supervision_trial h  

        ON t.mb_site_code = h.site_id 

         

    WHERE t.nd_ms_1899_all_planned_technologies_integrated_actual < CURRENT_DATE 

        AND t.nd_implementationvendor IS NOT NULL 

        AND UPPER(TRIM(t.nd_smp_name)) = 'AHLOB MODERNIZATION' 

         

    GROUP BY t.nd_implementationvendor, t.mb_site_code, t.mb_market, 

             t.mb_pj_p3925_msl_pickup_date_finish, t.mb_pj_a3925_msl_pickup_date_finish, 

             t.pm_scrap_confirmation_date, t.mb_pj_a5175_construction_complete_finish 

), 

 

ndpc_site_scores AS ( 

    SELECT  

        t.nd_implementationvendor AS gc_vendor, 

        t.mb_site_code, 

        t.pm_ndpc_session_title_name, 

         

        -- Count total NDPC entries for this site's session 

        COUNT(n.form_answer_status) AS total_ndpc_entries, 

         

        -- Count rejections (form_answer_status = 2) for this site's session 

        SUM(CASE WHEN n.form_answer_status = 2 THEN 1 ELSE 0 END) AS ndpc_rejections, 

         

        -- Calculate rejection percentage per site 

        CAST(SUM(CASE WHEN n.form_answer_status = 2 THEN 1 ELSE 0 END) AS NUMERIC) /  

        NULLIF(COUNT(n.form_answer_status), 0) AS ndpc_rejection_pct, 

         

        -- NDPC Score per site 

        CASE  

            WHEN CAST(SUM(CASE WHEN n.form_answer_status = 2 THEN 1 ELSE 0 END) AS NUMERIC) /  

                 NULLIF(COUNT(n.form_answer_status), 0) <= 0.05 THEN 100 

            WHEN CAST(SUM(CASE WHEN n.form_answer_status = 2 THEN 1 ELSE 0 END) AS NUMERIC) /  

                 NULLIF(COUNT(n.form_answer_status), 0) > 0.05  

                 AND CAST(SUM(CASE WHEN n.form_answer_status = 2 THEN 1 ELSE 0 END) AS NUMERIC) /  

                 NULLIF(COUNT(n.form_answer_status), 0) <= 0.25 THEN 75 

            WHEN CAST(SUM(CASE WHEN n.form_answer_status = 2 THEN 1 ELSE 0 END) AS NUMERIC) /  

                 NULLIF(COUNT(n.form_answer_status), 0) > 0.25  

                 AND CAST(SUM(CASE WHEN n.form_answer_status = 2 THEN 1 ELSE 0 END) AS NUMERIC) /  

                 NULLIF(COUNT(n.form_answer_status), 0) <= 0.50 THEN 50 

            WHEN CAST(SUM(CASE WHEN n.form_answer_status = 2 THEN 1 ELSE 0 END) AS NUMERIC) /  

                 NULLIF(COUNT(n.form_answer_status), 0) > 0.50 THEN 0 

            ELSE NULL 

        END AS ndpc_score 

         

    FROM tmo_retro_trial_consolidate t 

    LEFT JOIN tmo_ndpc_form_answer_report_trial n  

        ON UPPER(TRIM(t.pm_ndpc_session_title_name)) = UPPER(TRIM(n.session_title)) 

         

    WHERE t.nd_ms_1899_all_planned_technologies_integrated_actual < CURRENT_DATE 

        AND t.nd_implementationvendor IS NOT NULL 

        AND UPPER(TRIM(t.nd_smp_name)) = 'AHLOB MODERNIZATION' 

         

    GROUP BY t.nd_implementationvendor, t.mb_site_code, t.pm_ndpc_session_title_name 

) 

 

SELECT  

    COALESCE(s.gc_vendor, n.gc_vendor) AS gc_vendor, 

     

   

    -- Final Scores (averaged across all sites per vendor) 

    ROUND(((AVG(s.check_in_score) + AVG(s.ppe_score) + AVG(s.jsa_score) + AVG(s.l2w_score)) / 4.0)::NUMERIC, 2) AS hse_score, 

    ROUND(AVG(s.material_pickup_score)::NUMERIC, 2) AS material_pickup_score, 

    ROUND(AVG(s.scrap_return_score)::NUMERIC, 2) AS scrap_return_score, 

    ROUND(AVG(n.ndpc_score)::NUMERIC, 2) AS ndpc_punchpoint_score, 

     

    -- Combined Overall Score (average of all 7 scores: HSE + Material Pickup + Scrap Return + NDPC) 

    ROUND(((AVG(s.check_in_score) + AVG(s.ppe_score) + AVG(s.jsa_score) + AVG(s.l2w_score) +  

            AVG(s.material_pickup_score) + AVG(s.scrap_return_score) + AVG(n.ndpc_score)) / 7.0)::NUMERIC, 2) AS combined_overall_score 

 

FROM site_scores s 

FULL OUTER JOIN ndpc_site_scores n  

    ON s.gc_vendor = n.gc_vendor AND s.mb_site_code = n.mb_site_code 

     

GROUP BY COALESCE(s.gc_vendor, n.gc_vendor) 

ORDER BY combined_overall_score DESC, gc_vendor; """    
    },
    {
        "table": "Site forcasted BY month",
        "description": "Shows the monthly forecast of site construction starts based on the planned construction start dates from tmo_retro_trial_consolidate. It provides the total number of sites expected to begin construction each month, helping in capacity planning, resource allocation, and progress forecasting at the regional or market level.",
        "id":"site_forecasted_by_month",
        "sql":"""SELECT 
    DATE_TRUNC('month', mb_pj_p4225_construction_start_finish)::date AS forecast_month,
    COUNT(*) AS total_forecasted_sites
FROM 
    tmo_retro_trial_consolidate
WHERE 
    LOWER(mb_region) = 'central'
    AND mb_pj_p4225_construction_start_finish IS NOT NULL
GROUP BY 
    DATE_TRUNC('month', mb_pj_p4225_construction_start_finish)
ORDER BY 
    forecast_month;"""
    } 
]