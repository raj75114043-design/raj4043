from sqlmodel import SQLModel, Field
from datetime import datetime
from typing import Optional, Dict, Any
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy import Column
from sqlalchemy import func, Index


    
class kpis(SQLModel, table=True):
    __table_args__ = {"schema": "osdp_pwc_sch"}
    
    id: int = Field(default=None, primary_key=True)
    name: str
    
class kpi_synonyms(SQLModel, table=True):
    __table_args__ = {"schema": "osdp_pwc_sch"}
    
    id: int = Field(default=None, primary_key=True)
    kpi_id: int = Field(foreign_key="osdp_pwc_sch.kpis.id")
    synonym: str
    
class tableschema(SQLModel, table=True):
    __table_args__ = {"schema": "osdp_pwc_sch"}
    
    id: Optional[int] = Field(default=None, primary_key=True)
    json_schema: Dict[str, Any] = Field(
        sa_column=Column(JSONB)
    )
    


    