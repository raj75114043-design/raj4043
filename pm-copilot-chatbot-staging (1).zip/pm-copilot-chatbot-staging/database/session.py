from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlmodel import SQLModel
from config import settings
from rich.console import Console
from rich.panel import Panel
 
 
from contextlib import asynccontextmanager
 
console = Console()
 
# Create the database engine for genral use
engine = create_async_engine(
    url=settings.POSTGRES_URL,
    # echo=True,  # Set to True for debugging purposes
)
 
# Create the database engine for genral use with psycopg2 for advanced features for pg vector operations
engine_pgvector = create_async_engine(
    url=settings.POSTGRES_URL_psycopg,
    echo=False,  # Disable in production
    pool_size=5,  # Base connections for concurrent queries
    max_overflow=5,  # Handle bursts up to 30 total connections
    pool_timeout=30,  # Seconds to wait for a connection
    pool_pre_ping=True  # Validate connections to avoid stale ones
)
 
async def create_db_tables():
    try:
        async with engine.begin() as conn:
            from database.model import  kpis,kpi_synonyms,tableschema
            # Create all tables in the database
            await conn.run_sync(SQLModel.metadata.create_all)
           
            console.print(Panel("Database tables successfully mapped and created.",
                                title="Success",
                                subtitle="Created db fuction",
                                style="green"))
    except Exception as e:
        print(f"Error creating database tables: {e}")
        raise
       
async def get_session():
    """Create a new session for database operations."""
    async_session = sessionmaker(
        bind=engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )
   
    async with async_session() as session:
        yield session
       
print(f"Connecting to DB at: {settings.POSTGRES_URL}")
 
@asynccontextmanager
async def get_session_ctx():
    """Context-managed version of get_session for async with usage."""
    async_session = sessionmaker(
        bind=engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )
    async with async_session() as session:
        yield session
 
################## For Pg vector operations ##################
 
async def get_session_pgvec():
    """Create a new session for database operations."""
    async_session = sessionmaker(
        bind=engine_pgvector,
        class_=AsyncSession,
        expire_on_commit=False,
    )
   
    async with async_session() as session:
        yield session
       
print(f"Connecting to DB at: {settings.POSTGRES_URL}")
 
@asynccontextmanager
async def get_session_ctx_pgvec():
    """Context-managed version of get_session for async with usage."""
    async_session = sessionmaker(
        bind=engine_pgvector,
        class_=AsyncSession,
        expire_on_commit=False,
    )
    async with async_session() as session:
        yield session