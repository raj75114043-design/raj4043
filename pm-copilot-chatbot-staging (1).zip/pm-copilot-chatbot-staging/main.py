from contextlib import asynccontextmanager
from fastapi import FastAPI
from database.session import create_db_tables
from database.model import tableschema
import os
import json

from database.session import get_session_ctx
from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from fastapi.middleware.cors import CORSMiddleware

from api.routers import query_router, recommendation_router, graph_router

console= Console()


 


@asynccontextmanager
async def lifespan_handler(app: FastAPI):
    # Task-1: Create database tables at startup
    await create_db_tables()
    
    #Task-2:Read schema from tableschema table and save to tableschema/table_schema.json
    async with get_session_ctx() as session:
        result = await session.execute(
            tableschema.__table__.select().order_by(tableschema.id.desc())
        )
        row = result.first()

        if row and row[1]:
            schema = json.loads(row[1]) #Loads in proper format
            os.makedirs("tableschema", exist_ok=True)
            with open(os.path.join("tableschema", "table_schema.json"), "w") as f:
                json.dump(schema, f, indent=4)
            console.print(Panel("Schema loaded inside tableschema/table_schema.json",
                    title="Success",
                    subtitle="Lifespan handler",
                    style="green"))

    
    yield


app= FastAPI(lifespan=lifespan_handler)


origins = [
    "http://localhost.tiangolo.com",
    "https://localhost.tiangolo.com",
    "http://localhost",
    "http://localhost:8080",
    "http://localhost:5173",
    "https://nokiapmcopilot-gsd-staging.aibi-americas-002.dyn.nesc.nokia.net/ai-assistant",
    "https://nokiapmcopilot-gsd-staging.aibi-americas-002.dyn.nesc.nokia.net",
    "https://pmcopilot-agent-osdp-gsd-gsd-delivery-staging.aibi-americas-002.dyn.nesc.nokia.net",
    "*"
]
 
 
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    return {"status": "ok", "message": "Chatbot API is running"}



app.include_router(query_router.router, prefix="/api/v1", tags=["Query Processing"])
app.include_router(recommendation_router.router, prefix="/api/v1", tags=["Recommendation Processing"])
app.include_router(graph_router.router, prefix="/api/v1", tags=["Generate Graph"])

