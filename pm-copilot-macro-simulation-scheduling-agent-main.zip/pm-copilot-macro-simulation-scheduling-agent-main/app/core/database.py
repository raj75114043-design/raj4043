from urllib.parse import quote_plus
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from app.core.config import settings

# URL-encode password
password_encoded = quote_plus(settings.PG_PASSWORD)

# Build engine safely
engine = create_engine(
    f"postgresql+psycopg2://{settings.PG_USER}:{password_encoded}"
    f"@{settings.PG_HOST}:{settings.PG_PORT}/{settings.PG_DATABASE}",
    pool_pre_ping=True
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    pass


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Config DB (schedular_agent) — milestone definitions, gantt config, etc.
config_password_encoded = quote_plus(settings.CONFIG_PG_PASSWORD)

config_engine = create_engine(
    f"postgresql+psycopg2://{settings.CONFIG_PG_USER}:{config_password_encoded}"
    f"@{settings.CONFIG_PG_HOST}:{settings.CONFIG_PG_PORT}/{settings.CONFIG_PG_DATABASE}",
    pool_pre_ping=True
)

ConfigSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=config_engine)


class ConfigBase(DeclarativeBase):
    pass


def get_config_db():
    db = ConfigSessionLocal()
    try:
        yield db
    finally:
        db.close()
