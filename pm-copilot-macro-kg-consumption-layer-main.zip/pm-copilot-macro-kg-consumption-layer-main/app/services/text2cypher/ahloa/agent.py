# app/services/text2cypher/agent.py
from typing import List, Optional, Dict, Any, Literal, Awaitable, Callable
import asyncio
import logging

from langgraph.graph import START, END, StateGraph
from langchain_core.runnables import Runnable

from app.services.text2cypher.ahloa.llm_client import LLM_LOW, LLM_MEDIUM
from app.services.text2cypher.ahloa.prompts import (
    TEXT2CYPHER_PROMPT,
    VALIDATE_CORRECT_PROMPT,
    extract_cypher,
)
from app.schemas.text2cypher.schemas import (
    AgentStateDict,
    ValidateAndCorrectOutput,
)
from app.services.text2cypher.ahloa.phase_router import route_phases_and_modules
from app.db.neo4j_database import get_neo4j_ahloa_driver
from app.services.text2cypher.ahloa.phasewise_prompt import PHASE_SCHEMA_DESCRIPTIONS
from app.utils.neo4j_serialization import serialize_neo4j_value

logger = logging.getLogger(__name__)
MAX_RETRIES = 2

TEXT2CYPHER_CHAIN: Runnable = TEXT2CYPHER_PROMPT | LLM_MEDIUM
VALIDATE_CORRECT_CHAIN: Runnable = VALIDATE_CORRECT_PROMPT | LLM_LOW.with_structured_output(ValidateAndCorrectOutput)

def build_phase_schema(phases: List[int], modules: List[str]) -> str:
    keys = [0] + sorted(phases) + modules
    return "\n".join(
        PHASE_SCHEMA_DESCRIPTIONS[k]
        for k in keys
        if k in PHASE_SCHEMA_DESCRIPTIONS
    )

EventPublisher = Optional[Callable[[str, Dict[str, Any]], Awaitable[None]]]

_compiled = None

def _route_validate(state: AgentStateDict) -> Literal["correct_cypher", "execute_cypher"]:
    action = state.get("next_action") or ""
    if action in ("end", "correct_cypher"):
        return "correct_cypher"
    return "execute_cypher"

def _get_graph():
    global _compiled
    if _compiled:
        return _compiled

    logger.info("Compiling LangGraph agent (async)…")

    async def generate_cypher(state: AgentStateDict, publish: EventPublisher = None) -> AgentStateDict:
        phases  = state.get("phases") or []
        modules = state.get("modules") or []

        if not phases and not modules:
            phases, modules = route_phases_and_modules(state["question"])
            if publish:
                await publish("router", {"phases": phases, "modules": modules})

        schema = build_phase_schema(phases, modules)
        result = await TEXT2CYPHER_CHAIN.ainvoke({"question": state["question"], "schema": schema})
        text   = getattr(result, "content", str(result))
        cypher = extract_cypher(text)
        if publish:
            await publish("generate_cypher", {"cypher": cypher})

        state["phases"]           = phases
        state["modules"]          = modules
        state["cypher_statement"] = cypher
        state["next_action"]      = "validate_cypher"
        state.setdefault("steps", []).append("generate_cypher")
        return state

    async def validate_cypher(state: AgentStateDict, publish: EventPublisher = None) -> AgentStateDict:
        cypher = state["cypher_statement"]
        schema = build_phase_schema(state.get("phases", []), state.get("modules", []))
        driver = get_neo4j_ahloa_driver()
        errors: List[str] = []

        async def explain_task():
            async with driver.session() as session:
                await session.run(f"EXPLAIN {cypher}")

        async def llm_task():
            return await VALIDATE_CORRECT_CHAIN.ainvoke({
                "question": state["question"],
                "schema":   schema,
                "cypher":   cypher,
            })

        try:
            _, llm_output = await asyncio.gather(explain_task(), llm_task())
        except Exception as e:
            errors.append(f"EXPLAIN failed: {e}")
            llm_output = await llm_task()

        corrected = llm_output.corrected_cypher or cypher
        if llm_output.errors:
            errors.extend(llm_output.errors)

        state["cypher_statement"] = corrected
        state["cypher_errors"]    = errors
        state.setdefault("steps", []).append("validate_cypher")

        if publish:
            await publish("validate_cypher", {"errors": errors, "corrected_cypher": corrected})

        retry = state.get("retry_count", 0)
        if errors and retry < MAX_RETRIES:
            state["next_action"] = "correct_cypher"
        elif errors:
            state["next_action"] = "end"
        else:
            state["next_action"] = "execute_cypher"

        return state

    async def correct_cypher(state: AgentStateDict, publish: EventPublisher = None) -> AgentStateDict:
        state["retry_count"] = state.get("retry_count", 0) + 1
        state["next_action"] = "validate_cypher"
        state.setdefault("steps", []).append("correct_cypher")
        if publish:
            await publish("correct_cypher", {"retry_count": state["retry_count"]})
        return state

    async def execute_cypher(state: AgentStateDict, publish: EventPublisher = None) -> AgentStateDict:
        records: List[dict] = []
        driver = get_neo4j_ahloa_driver()
        try:
            async with driver.session() as session:     
                result = await session.run(state["cypher_statement"])
                raw_records = [record.data() async for record in result]
                records = [serialize_neo4j_value(r) for r in raw_records]


        except Exception as e:
            logger.exception("Cypher execution error")
            state.setdefault("cypher_errors", []).append(str(e))
        state["database_records"] = records
        state["next_action"]      = "END"
        state.setdefault("steps", []).append("execute_cypher")
        if publish:
            await publish("execute_cypher", {"rowcount": len(records)})
        return state

    lg = StateGraph(AgentStateDict)
    lg.add_node("generate_cypher", generate_cypher)
    lg.add_node("validate_cypher", validate_cypher)
    lg.add_node("correct_cypher",  correct_cypher)
    lg.add_node("execute_cypher",  execute_cypher)

    lg.add_edge(START,             "generate_cypher")
    lg.add_edge("generate_cypher", "validate_cypher")
    lg.add_conditional_edges("validate_cypher", _route_validate)
    lg.add_edge("correct_cypher",  "validate_cypher")
    lg.add_edge("execute_cypher",  END)

    _compiled = lg.compile()
    return _compiled

async def run_agent_once_ahloa(
    question: str,
    phases: Optional[List[int]] = None,
    modules: Optional[List[str]] = None,
    publish: EventPublisher = None,
) -> AgentStateDict:
    agent = _get_graph()

    state: AgentStateDict = {
        "question": question,
        "phases": phases or [],
        "modules": modules or [],
        "next_action": "",
        "cypher_statement": "",
        "cypher_errors": [],
        "database_records": [],
        "steps": [],
        "answer": "",
        "retry_count": 0,
    }

    final_state: AgentStateDict = await agent.ainvoke(
        state,
        config={"configurable": {"publish": publish}},
    )
    return final_state