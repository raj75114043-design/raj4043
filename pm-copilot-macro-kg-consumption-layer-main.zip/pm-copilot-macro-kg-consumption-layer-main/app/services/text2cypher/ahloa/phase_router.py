from langchain_core.prompts import ChatPromptTemplate
from typing import List
from app.services.text2cypher.ahloa.llm_client import LLM_MEDIUM
from app.schemas.text2cypher.schemas import PhaseRouterOutput

llm = LLM_MEDIUM

# Bind structured output directly to the LLM
structured_llm = llm.with_structured_output(PhaseRouterOutput)

ROUTER_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """

You are a telecom deployment project knowledge router.

Your task is to analyze the user's question and determine which telecom project phases
are relevant for answering the query.

You must return ONLY the relevant phase numbers as a list of integers between 1 and 10.
If the query relates to the whole project lifecycle, return all phases [1,2,3,4,5,6,7,8,9,10].
Do NOT explain your reasoning.

-----------------------------------
TELECOM PROJECT PHASE DEFINITIONS
-----------------------------------

Phase 1 – Project / Site Assignment
Project details like Build Plan Year, Entitlement Complete Year, Project type (M-Modification General only) and a unique Por ID. 
Hard cost, soft cost and Vendor(GC or General Contractor) assignment details like comments, dates etc.
A unique smp_id for every project. And some more smp_details like smp_name (AHLOB Modernization only),
This phase also contains any drone (talonview) survey activity details.


Phase 2 – Pre-Construction
In Phase 2, In this phase TMobile provides a Precon / Pre - NTP document to Nokia.
This document includes all the planned dates for activities / milestones decided by TMobile for the site like - 
CD (Construction Drawing), RFDS, BOM (Bill of Materials), SA (Structural Analysis) and MA (Mount Analysis)
In this phase TMobile also provides Entitlement Completion (EC) to Nokia and Talon view survey details.

Phase 3 – Scoping
Phase 3 defines the real scope of work required for project. 
Post the precon validation, Nokia team assigns pre-construction site walks and 
drone surveys. Additional scope of work (apart from the one mentioned in precon)
is identified during these surveys and precon validation which is finally compiled into 
a scoping package. This package is created & validated internally by Nokia and Vendor
and than it is submitted to TMobile.    

Phase 4 – Quoting
In Phase 4, TMobile recieves the Scoping Package from Nokia as an 'E-quote'.
TMobiles reviews and approves it.

Phase 5 – NTP & Material
In Phase 5, TMobile provides the Notice to Proceed (NTP) to Nokia for 2 set of activites - 
The civil construction work on site and tower construction work. 
List of Materials required is finalized, and the Bill of Materials (BOM) is uploaded to the 
TMobile tool. As TMobile approves the BOM, materials arrive in the warehouse. 
Vendor collects the materials from the warehouse. 
Steel required in the project is finalized in this phase too. Steel details include 
po number, steel recieved status etc.
 
Phase 6 – Transport and Power Preparation
In Phase 6 the TMO Vendor performs a AAV telco site walk to analyse the transport requirements.
The TMO Vendor also performs a Power walk to define the power utility scope and gather power requirements.

Phase 7 – Construction Readiness
Phase 7 includes all the milestones related to Supplier Purchase Order (SPO) and Customer Purchase Order (CPO).

Phase 8 – Civil Construction and Power Installation
Phase 8 includes the civil construction work start and finish dates. Parallel to civil construction 
power installation work start and end dates are also mentioned in this phase.
AAV is ready and MW installation is also finished.

Phase 9 – Tower Construction and Structural Work
Phase 9 includes the tower construction work start and finish dates, delays and comments.

Phase 10 – Network Integration
Phase 10 manages the integration of telecom network equipment into the operational network.
This includes integration start and complete milestones, validating scf files and integration comments. 
Verifying that equipment communicates correctly with E911 test calls.
Airview report is completed in this Phase.

Phase 11 – Post-Integration
Phase 11 has integration completion milestones. It includes RTT (Ready-To-Test) and
network On-Air activation for various spectrum bands.
     
Phase 12 Revenue
Phase 12 contains revenue milestones (CA, IA, GR, BBR, SO etc) 
from different 4 phases of the project - Civil, Tower, Integration and DEC_COP.
     
You must return ONLY the relevant phase numbers AND any additional modules.

Phases are integers between 1 and 10.
Modules are strings — valid values are: 'HSE', 'DEC_COP'

- Return 'HSE' if the query relates to crew visits, safety compliance, PPE, JSA, or check-ins.
- Return 'DEC_COP' if the query relates to close-out packages, COP approval, or punch lists.
     
"""),
    ("human", "{query}")
])

router_chain = ROUTER_PROMPT | structured_llm

def phase_router_func(query: str) -> PhaseRouterOutput:
    """
    Routes a user query to relevant telecom deployment phases and modules.

    Args:
        query (str): User question related to telecom deployment project.

    Returns:
        PhaseRouterOutput: Structured object containing:
            - phases (List[int])
            - modules (List[str])
    """
    response = router_chain.invoke({"query": query})

    return response

## Router Adapter

def route_phases_and_modules(question: str) -> tuple[List[int], List[str]]:
    """
    Thin adapter, so we can mock in tests and keep boundaries clean.
    """
    res: PhaseRouterOutput = phase_router_func(question)
    return res.phases, res.modules