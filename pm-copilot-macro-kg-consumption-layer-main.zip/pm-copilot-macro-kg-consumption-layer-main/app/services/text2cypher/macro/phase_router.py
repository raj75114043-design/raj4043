from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field
from typing import List

class PhaseRouterOutput(BaseModel):
    """Output schema for routing user query to relevant project phases and modules."""
    phases: List[int] = Field(
        description="List of relevant project phase numbers from 1 to 11"
    )
    modules: List[str] = Field(
        default=[],
        description="List of additional module keys relevant to the query. Valid values: 'HSE', 'DEC_COP'"
    )

llm = ChatOpenAI(
    api_key="NONE",
    model="gpt-5",
    base_url="https://llmgateway-qa-api.nokia.com/v1.2/",
    default_headers={
        "api-key": (
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
            "eyJ1c2VyTmFtZSI6IlJvbGxvdXRBZ2VudERldlRvb2wiLCJPYmplY3RJRCI6IjNGRUY4NzI0LUE5RTItNDMyQy1COTk4LTU0NDMwMEZBQjcxMyIsIndvcmtTcGFjZU5hbWUiOiJWUjE4NTdSb2xsb3V0QWdlbnREZXZTcGFjZSIsIm5iZiI6MTc3MDg4NTYyNCwiZXhwIjoxODAyNDIxNjI0LCJpYXQiOjE3NzA4ODU2MjR9."
            "HvO_kB6UNwcNSV4B_MXuh9OK54rYtRRDMPH5Y1EuOhc"
        ),
        "workspacename": "VR1857RolloutAgentDevSpace",
    },
    temperature=0,
    reasoning_effort="medium",
)

# Bind structured output directly to the LLM
structured_llm = llm.with_structured_output(PhaseRouterOutput)

ROUTER_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are a telecom deployment project knowledge router.

Your task is to analyze the user's question and determine which telecom project phases
are relevant for answering the query.

A telecom deployment project is divided into 12 phases.
Each phase represents a specific stage of the site deployment lifecycle.
The key participants are - TMobile / TMO (Nokia's Customer), Nokia, 
Vendors and TMO Vendors.

You must return ONLY the relevant phase numbers as a list of integers between 1 and 12.
If the query relates to the whole project lifecycle, return all phases [1,2,3,4,5,6,7,8,9,10,11,12].
Do NOT explain your reasoning.

-----------------------------------
TELECOM PROJECT PHASE DEFINITIONS
-----------------------------------

Phase 1 – Project / Site Assignment
In Phase 1, TMobile assigns the site & project to Nokia (Nokia itself is the Hard cost vendor for TMobile). 
Nokia creates and details SMP ID, recieves project details (project type, regional initiatives and POR details)
and assigns a vendor (Nokia vendor / General contractor - GC). 
TMobile also assigns a TMO vendor (Soft cost vendor) on this site.

Phase 2 – Pre-Construction
In Phase 2, In this phase TMobile provides a Precon / Pre - NTP document to Nokia.
This document includes all the activities / milestones planned by TMobile 
for the project along with their planned dates.
The document includes - Construction drawings and Mount analysis. 
Nokia validates the drawings & planned activities in the document. 
Post validation, Nokia can either accept or reject the document.
In this phase TMobile also provides Entitlement Completion (EC) to Nokia.

Phase 3 – Scoping
Phase 3 defines the real scope of work required for project. 
Post the precon validation, Nokia team assigns pre-construction site walks and 
drone surveys. Additional scope of work (apart from the one mentioned in precon)
is identified during these surveys and precon validation which is finally compiled into 
a scoping package. This package is created & validated internally by Nokia and Vendor
and than it is submitted to TMobile.    

Phase 4 – Quoting
In Phase 4, TMobile recieves the Scoping Package from Nokia as an 'E-quote'.
TMobiles reviews and approves it.

Phase 5 – NTP & Material
In Phase 5, TMobile provides the Notice to Proceed (NTP) to Nokia for 2 set of activites - 
The civil construction work on site and tower construction work. 
List of Materials required is finalized, and the Bill of Materials (BOM) is uploaded to the 
TMobile tool. As TMobile approves the BOM, materials arrive in the warehouse. 
Vendor collects the materials from the warehouse. 
Steel required in the project is finalized in this phase too. Steel details include 
po number, steel recieved status etc.
 
Phase 6 – Transport and Power Preparation
In Phase 6 the TMO Vendor performs a AAV telco site walk to analyse the transport requirements.
The TMO Vendor also performs a Power walk to define the power utility scope and gather power requirements.

Phase 7 – Construction Readiness
Phase 7 includes all the milestones related to Supplier Purchase Order (SPO) and Customer Purchase Order (CPO).

Phase 8 – Civil Construction and Power Installation
Phase 8 includes the civil construction work start and finish dates. Parallel to civil construction 
power installation work start and end dates are also mentioned in this phase.
AAV is ready and MW installation is also finished.

Phase 9 – Tower Construction and Structural Work
Phase 9 includes the tower construction work start and finish dates, delays and comments.

Phase 10 – Network Integration
Phase 10 manages the integration of telecom network equipment into the operational network.
This includes integration start and complete milestones, validating scf files and integration comments. 
Verifying that equipment communicates correctly with E911 test calls.
Airview report is completed in this Phase.

Phase 11 – Post-Integration
Phase 11 has integration completion milestones. It includes RTT (Ready-To-Test) and
network On-Air activation for various spectrum bands.
     
Phase 12 Revenue
Phase 12 contains revenue milestones (CA, IA, GR, BBR, SO etc) 
from different 4 phases of the project - Civil, Tower, Integration and DEC_COP.
     
You must return ONLY the relevant phase numbers AND any additional modules.

Phases are integers between 1 and 11.
Modules are strings — valid values are: 'HSE', 'DEC_COP'

- Return 'HSE' if the query relates to crew visits, safety compliance, PPE, JSA, or check-ins.
- Return 'DEC_COP' if the query relates to close-out packages, COP approval, or punch lists.
     
"""),
    ("human", "{query}")
])

router_chain = ROUTER_PROMPT | structured_llm

def phase_router_func(query: str) -> PhaseRouterOutput:
    """
    Routes a user query to relevant telecom deployment phases and modules.

    Args:
        query (str): User question related to telecom deployment project.

    Returns:
        PhaseRouterOutput: Structured object containing:
            - phases (List[int])
            - modules (List[str])
    """
    response = router_chain.invoke({"query": query})

    return response

def route_phases_and_modules(question: str) -> tuple[List[int], List[str]]:
    """
    Thin adapter, so we can mock in tests and keep boundaries clean.
    """
    res: PhaseRouterOutput = phase_router_func(question)
    return res.phases, res.modules