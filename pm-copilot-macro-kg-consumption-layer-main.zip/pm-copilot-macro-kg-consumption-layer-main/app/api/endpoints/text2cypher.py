# app/api/endpoints/text2cypher.py
import asyncio
import json
import logging
from typing import AsyncGenerator, Dict, Any

from fastapi import APIRouter, HTTPException, status
from fastapi.responses import StreamingResponse

from app.schemas.text2cypher.schemas import Text2CypherRequest, Text2CypherResponse
from app.services.text2cypher.macro.agent import run_agent_once_macro
from app.services.text2cypher.ahloa.agent import run_agent_once_ahloa

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/graph/text2cypher", tags=["Text2Cypher"])

def _sse(event: str | None, data: Dict[str, Any]) -> str:
    payload = f"data: {json.dumps(data, ensure_ascii=False)}\n"
    if event:
        payload = f"event: {event}\n{payload}"
    return payload + "\n"

@router.post("/run_macro", response_model=Text2CypherResponse)
async def text2cypher_run(req: Text2CypherRequest) -> Text2CypherResponse:
    """
    One-shot Text2Cypher execution. Returns cypher, errors (if any), and records.
    """
    try:
        final_state_future = run_agent_once_macro(
            question=req.question,
            phases=req.phases,
            modules=req.modules,
        )
        state = await asyncio.wait_for(final_state_future, timeout=req.timeout_s)

        cypher_errors = state.get("cypher_errors") or []
        status_str = "ok" if not cypher_errors else "error"

        return Text2CypherResponse(
            status=status_str,
            message=None if status_str == "ok" else "Cypher validation/execution errors present.",
            cypher_statement=state.get("cypher_statement"),
            cypher_errors=cypher_errors or None,
            records=state.get("database_records") or None,
            steps=state.get("steps") or [],
            retries=state.get("retry_count", 0),
        )
    except asyncio.TimeoutError:
        logger.warning("Text2Cypher timed out.")
        raise HTTPException(status_code=status.HTTP_504_GATEWAY_TIMEOUT, detail="Request timed out")
    except Exception as e:
        logger.exception("Text2Cypher failure")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/stream_macro")
async def text2cypher_stream(question: str, timeout_s: float = 60.0) -> StreamingResponse:
    """
    Server-Sent Events stream. Yields step-by-step updates and final result.
    Query params:
      - question: required
      - timeout_s: optional
    """
    async def publisher(event: str, payload: Dict[str, Any]) -> None:
        # This is a placeholder; generator below will send events. We’ll attach via queue.
        # We will set a closure to enqueue events. See below.
        pass

    async def event_generator() -> AsyncGenerator[str, None]:
        queue: asyncio.Queue[str] = asyncio.Queue()

        async def _publish(event: str, payload: Dict[str, Any]) -> None:
            await queue.put(_sse(event, payload))

        async def _runner():
            try:
                state = await asyncio.wait_for(
                    run_agent_once_macro(question=question, publish=_publish),
                    timeout=timeout_s,
                )
                # final event
                cypher_errors = state.get("cypher_errors") or []
                await queue.put(_sse("final", {
                    "status": "ok" if not cypher_errors else "error",
                    "cypher_statement": state.get("cypher_statement"),
                    "cypher_errors": cypher_errors,
                    "records": state.get("database_records"),
                    "steps": state.get("steps") or [],
                    "retries": state.get("retry_count", 0),
                }))

            except asyncio.TimeoutError:
                await queue.put(_sse("error", {"message": "timeout"}))
            except Exception as e:
                logger.exception("SSE stream error")
                await queue.put(_sse("error", {"message": str(e)}))
            finally:
                # signal end of stream
                await queue.put("__CLOSE__")

        runner_task = asyncio.create_task(_runner())

        try:
            while True:
                chunk = await queue.get()
                if chunk == "__CLOSE__":
                    break
                yield chunk
        finally:
            runner_task.cancel()

    headers = {
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "X-Accel-Buffering": "no",
    }
    return StreamingResponse(event_generator(), media_type="text/event-stream", headers=headers)

@router.post("/run_ahloa", response_model=Text2CypherResponse)
async def text2cypher_run(req: Text2CypherRequest) -> Text2CypherResponse:
    """
    One-shot Text2Cypher execution. Returns cypher, errors (if any), and records.
    """
    try:
        final_state_future = run_agent_once_ahloa(
            question=req.question,
            phases=req.phases,
            modules=req.modules,
        )
        state = await asyncio.wait_for(final_state_future, timeout=req.timeout_s)

        cypher_errors = state.get("cypher_errors") or []
        status_str = "ok" if not cypher_errors else "error"

        return Text2CypherResponse(
            status=status_str,
            message=None if status_str == "ok" else "Cypher validation/execution errors present.",
            cypher_statement=state.get("cypher_statement"),
            cypher_errors=cypher_errors or None,
            records=state.get("database_records") or None,
            steps=state.get("steps") or [],
            retries=state.get("retry_count", 0),
        )
    except asyncio.TimeoutError:
        logger.warning("Text2Cypher timed out.")
        raise HTTPException(status_code=status.HTTP_504_GATEWAY_TIMEOUT, detail="Request timed out")
    except Exception as e:
        logger.exception("Text2Cypher failure")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/stream_ahloa")
async def text2cypher_stream(question: str, timeout_s: float = 60.0) -> StreamingResponse:
    """
    Server-Sent Events stream. Yields step-by-step updates and final result.
    Query params:
      - question: required
      - timeout_s: optional
    """
    async def publisher(event: str, payload: Dict[str, Any]) -> None:
        # This is a placeholder; generator below will send events. We’ll attach via queue.
        # We will set a closure to enqueue events. See below.
        pass

    async def event_generator() -> AsyncGenerator[str, None]:
        queue: asyncio.Queue[str] = asyncio.Queue()

        async def _publish(event: str, payload: Dict[str, Any]) -> None:
            await queue.put(_sse(event, payload))

        async def _runner():
            try:
                state = await asyncio.wait_for(
                    run_agent_once_ahloa(question=question, publish=_publish),
                    timeout=timeout_s,
                )
                # final event
                cypher_errors = state.get("cypher_errors") or []
                await queue.put(_sse("final", {
                    "status": "ok" if not cypher_errors else "error",
                    "cypher_statement": state.get("cypher_statement"),
                    "cypher_errors": cypher_errors,
                    "records": state.get("database_records"),
                    "steps": state.get("steps") or [],
                    "retries": state.get("retry_count", 0),
                }))

            except asyncio.TimeoutError:
                await queue.put(_sse("error", {"message": "timeout"}))
            except Exception as e:
                logger.exception("SSE stream error")
                await queue.put(_sse("error", {"message": str(e)}))
            finally:
                # signal end of stream
                await queue.put("__CLOSE__")

        runner_task = asyncio.create_task(_runner())

        try:
            while True:
                chunk = await queue.get()
                if chunk == "__CLOSE__":
                    break
                yield chunk
        finally:
            runner_task.cancel()

    headers = {
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "X-Accel-Buffering": "no",
    }
    return StreamingResponse(event_generator(), media_type="text/event-stream", headers=headers)