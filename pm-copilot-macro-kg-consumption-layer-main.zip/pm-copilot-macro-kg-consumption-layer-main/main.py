"""
Configuration management for Neo4j ETL
Author: Advait Shah, Associate, PwC India
Client: Nokia

Run:
    uvicorn main:app --host 0.0.0.0 --port 8000 --reload
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.db.database import init_db, close_db
from app.db.neo4j_database import (
    init_neo4j, close_neo4j,
    init_neo4j_db, close_neo4j_db,
    init_neo4j_ahloa, close_neo4j_ahloa,
    init_neo4j_kpi, close_neo4j_kpi,
    init_neo4j_nas, close_neo4j_nas,
)

# ── Routers ──────────────────────────────────────────────────────────
from app.api.endpoints.text2cypher import router as text2cypher_router
from app.api.endpoints.db_kg import router as schema_kg_router

# ── Logging ──────────────────────────────────────────────────────────
logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


# ── Lifespan ─────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):

    logger.info("Starting KG Assistant ...")

    await init_db()           # PostgreSQL
    await init_neo4j()        # Neo4j
    await init_neo4j_db()     # Neo4j_DB
    await init_neo4j_ahloa()  # Neo4j_AHLOA
    await init_neo4j_kpi()    # Neo4j_KPI
    await init_neo4j_nas()    # Neo4j_NAS
    logger.info("Database connections ready")

    yield

    logger.info("Shutting down ...")

    await close_db()           # PostgreSQL
    await close_neo4j()        # Neo4j
    await close_neo4j_db()     # Neo4j_DB
    await close_neo4j_ahloa()  # Neo4j_AHLOA
    await close_neo4j_kpi()    # Neo4j_KPI
    await close_neo4j_nas()    # Neo4j_NAS
    logger.info("Shutdown complete")


# ── App ──────────────────────────────────────────────────────────────

app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="KG Consumables and KG-ETL (Postgres->Neo4j)",
    lifespan=lifespan,
)

# ── CORS ─────────────────────────────────────────────────────────────

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Removed CORS ORIGIN, But need to know Later
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Register routers ────────────────────────────────────────────────

API_PREFIX = settings.api_v1_prefix  # /api/v1

app.include_router(text2cypher_router, prefix=API_PREFIX)
app.include_router(schema_kg_router, prefix=API_PREFIX)

# ── Health check ─────────────────────────────────────────────────────

# from fastapi import APIRouter
import asyncio
from app.core.config import settings
from app.db.database import health_check_async as pg_health_check
from app.db.neo4j_database import health_check_neo4j, health_check_neo4j_db, health_check_neo4j_ahloa, health_check_neo4j_kpi, health_check_neo4j_nas

@app.get("/health", tags=["Health"])
async def health():
    """Application health check (Postgres + Neo4j)."""
    # Run both checks concurrently
    pg_ok, neo4j_ok, neo4j_db_ok, neo4j_ahloa_ok, neo4j_kpi_ok, neo4j_nas_ok = await asyncio.gather(
        pg_health_check(), 
        health_check_neo4j(),
        health_check_neo4j_db(),
        health_check_neo4j_ahloa(),
        health_check_neo4j_kpi(),
        health_check_neo4j_nas()
    )

    # Overall status
    overall_ok = pg_ok and neo4j_ok and neo4j_db_ok and neo4j_ahloa_ok and neo4j_kpi_ok and neo4j_nas_ok

    return {
        "status": "healthy" if overall_ok else "degraded",
        "version": settings.app_version,
        "database": {
            "postgres": "connected" if pg_ok else "disconnected",
            "neo4j": "connected" if neo4j_ok else "disconnected",
            "neo4j_db": "connected" if neo4j_db_ok else "disconnected",
            "neo4j_ahloa": "connected" if neo4j_ahloa_ok else "disconnected",
            "neo4j_kpi": "connected" if neo4j_kpi_ok else "disconnected",
            "neo4j_nas": "connected" if neo4j_nas_ok else "disconnected"
        },
    }


@app.get("/", tags=["Root"])
async def root():
    """Root endpoint – service info."""
    return {
        "service": settings.app_name,
        "version": settings.app_version,
        "docs": "/docs",
    }


# ── Uvicorn entry point ─────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host=settings.host,
        port=settings.port,
        reload=True,
        log_level=settings.log_level.lower(),
        timeout_keep_alive=300,    
        timeout_graceful_shutdown=60,
    )
