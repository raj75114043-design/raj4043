# main.py

"""
Email Document Agent FastAPI Application.

This is the main entry point for the Email Document Agent API.
It sets up the FastAPI application with:
- PostgreSQL connection pooling
- API routes for Email Document management
- Health check endpoints
- CORS middleware
"""
import time
import os

import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.llm_config import get_settings
from app.db.pool import DatabasePool
from app.api.routes import (
    email_doc_job_orchestrator,
    health,
    data,
    s3_blob_storage,
    document_parser,
    email_agent,
    email_general_tools,
    send_email,
    send_email_bot,
    receive_email,
    workflow_agent,
    documentation,
    sharepoint_blob_trigger,
    email_doc_job_live_status,
    email_doc_job_configuration,
    email_doc_job_draft_emails,
    email_doc_job_drill_down_tables,
    email_doc_job_runner, 
)

from app.services.workflow_email_scheduler import(
    run_workflow_email_scheduler,
)
from app.services.email_scheduler import(
    run_email_scheduler,
)
from app.email_job_auto_trigger.start_scheduler import(
    email_doc_job_runner_scheduler_loop
) 

from app.email_doc_job_engine.main_orchestrator.job_queue_manager import (
    start_job_queue_worker
)

from app.email_job_auto_trigger.email_send_scheduler import (
    run_email_send_scheduler
)

from app.api.routes.document_parser import cleanup_sessions
from app.api.routes.send_email_bot import cleanup_drafts
from app.utils.users_email import refresh_user_cache


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan manager.

    Handles startup and shutdown events:
    - Startup: Initialize database connection pool
    - Shutdown: Close database connection pool gracefully
    """
    # Startup
    settings = get_settings()
    print(f"Starting {settings.app_name}...")

    try:
        await DatabasePool.create_pool()
        print("Database pool initialized successfully")

        # START BACKGROUND TASK HERE
        asyncio.create_task(cleanup_drafts()) 
        asyncio.create_task(refresh_user_cache())
        asyncio.create_task(cleanup_sessions())

        # asyncio.create_task(run_email_scheduler())
        # asyncio.create_task(run_workflow_email_scheduler())

        # START EMAIL DOC JOB SCHEDULER
        await start_job_queue_worker()
        asyncio.create_task(email_doc_job_runner_scheduler_loop())
        asyncio.create_task(run_email_send_scheduler())
        
        print("[ APP STARTED ]")
        
    except Exception as e:
        print(f"Warning: Failed to initialize database pool: {e}")
        print("API will start but database features may not work")

    yield
    # Shutdown
    print("Shutting down...")
    await DatabasePool.close_pool()
    print("Database pool closed")


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    settings = get_settings()

    app = FastAPI(
        title=settings.app_name,
        description="""
## Email Document Agent API

A modular Email Document agent for managing and executing Scheduled Emails OR Documents Processing.

""",
        version="1.0.0",
        lifespan=lifespan,
    )

    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure appropriately for production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Include routers
    app.include_router(health.router)
    app.include_router(data.router, prefix="/api/v1")
    # app.include_router(email_doc_job_orchestrator.router, prefix="/api/v1")
    app.include_router(email_general_tools.router, prefix="/api/v1")
    app.include_router(send_email_bot.router, prefix="/api/v1")
    app.include_router(document_parser.router, prefix="/api/v1")
    app.include_router(send_email.router, prefix="/api/v1")
    app.include_router(s3_blob_storage.router, prefix="/api/v1")
    # app.include_router(email_agent.router, prefix="/api/v1")
    app.include_router(receive_email.router, prefix="/api/v1")
    app.include_router(workflow_agent.router, prefix="/api/v1")
    app.include_router(documentation.router, prefix="/api/v1")
    app.include_router(sharepoint_blob_trigger.router, prefix="/api/v1")
    app.include_router(email_doc_job_live_status.router, prefix="/api/v1")
    app.include_router(email_doc_job_configuration.router, prefix="/api/v1")
    app.include_router(email_doc_job_draft_emails.router, prefix="/api/v1")
    app.include_router(email_doc_job_drill_down_tables.router, prefix="/api/v1")
    app.include_router(email_doc_job_runner.router, prefix="/api/v1")

    return app


# Create the application instance
app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
    )
