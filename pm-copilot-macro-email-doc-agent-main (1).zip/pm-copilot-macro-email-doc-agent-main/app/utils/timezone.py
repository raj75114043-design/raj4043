# import pytz
# from datetime import datetime

# INDIA_TIME_ZONE = pytz.timezone("Asia/Kolkata")

# def get_datetime_now_without_zone():
#     return datetime.now(INDIA_TIME_ZONE).replace(tzinfo=None)


from datetime import datetime
from zoneinfo import ZoneInfo

def get_datetime_now_without_zone():

    return (
        datetime.now(ZoneInfo("Asia/Kolkata"))
        .replace(tzinfo=None)
    )