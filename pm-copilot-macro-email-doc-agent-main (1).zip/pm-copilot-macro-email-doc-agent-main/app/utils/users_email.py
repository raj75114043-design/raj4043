# app/utils/user_email.py

import asyncio
import time
from app.db.pool import get_connection

USER_CACHE = {
    "data": [],
    "email_set": set(),
    "name_map": {},
    "loaded": False,
    "last_loaded": 0
}

LOCK = asyncio.Lock()
TTL = 300  # 5 minutes

async def load_user_cache(force=False):
    async with LOCK:
        now = time.time()

        # Skip reload if within TTL
        if not force and USER_CACHE["loaded"] and (now - USER_CACHE["last_loaded"] < TTL):
            return

        async with get_connection() as db:
            rows = await db.fetch("""
                SELECT name, email
                FROM osdp_pwc_sch.users
                ORDER BY name;
            """)

        data = []
        email_set = set()
        name_map = {}

        for row in rows:
            name = row["name"].lower()
            email = row["email"].lower()

            data.append((name, email))
            email_set.add(email)
            name_map[name] = email

        USER_CACHE["data"] = data
        USER_CACHE["email_set"] = email_set
        USER_CACHE["name_map"] = name_map
        USER_CACHE["loaded"] = True
        USER_CACHE["last_loaded"] = now

        print("[USER CACHE] Loaded/Refreshed")


async def refresh_user_cache():
    while True:
        try:
            await load_user_cache(force=True)
        except Exception as e:
            print(f"[USER CACHE ERROR]: {e}")

        await asyncio.sleep(300)  # refresh every 5 min