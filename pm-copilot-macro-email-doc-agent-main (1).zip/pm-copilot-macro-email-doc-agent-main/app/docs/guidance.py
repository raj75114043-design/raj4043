
JOB_CONFIGURATION_GUIDANCE = """
# Job Configuration Guidance

---

# 1. Meta Data

Basic job information.

| Field | Required | Description |
|---|---|---|
| `job_id` | Yes | Unique job identifier |
| `job_name` | Yes | Friendly job name |
| `job_description` | Yes | Short description |
| `job_category` | Yes | Example: Reporting / Validation |
| `job_type` | Yes | `Email` or `Document` |
| `job_trigger_point` | Yes | `RECEIVED_EMAIL` or `SCHEDULED_TIME` |
| `job_owner` | Yes | At least 1 owner email |
| `schedule_run_times` | Conditional | Required for scheduled jobs |
| `days_of_week` | Conditional | Required for scheduled jobs |
| `timezone` | Optional | Default: `Asia/Kolkata` |
| `linked_tables` | Optional | Related tables used in workflow |

---

# 2. Receive Email

Enable when workflow starts from incoming email.

## Required Fields

```json
{
  "is_enabled": true,
  "receive_details": {
    "subject_template": "Daily Report"
  }
}
```

## Email Body Parsing

Used to extract text values from email body.

### Configure

- `output_table_name`
- `parsing_context`
- `fields`

### Field Definition

| Field | Description |
|---|---|
| `name` | Output column name |
| `type` | Data type |
| `synonyms` | Alternative names in email |

### Supported Types

- `string`
- `int`
- `bool`
- `date`
- `datetime`

---

## Tables In Email Body

Used when email body contains table format data.

### Configure

- `output_table_name`
- `fields`

---

## Attachment Parsing

---

### Structured Attachments

Supported file types:

- `xlsx`
- `csv`

### Configure

| Field | Description |
|---|---|
| `file_name_template` | File matching pattern |
| `sheet_name` | Excel sheet name |
| `fields` | Columns to extract |
| `output_table_name` | Output dataframe name |

---

### Unstructured Attachments

Supported file types:

- `pdf`
- `png`
- `jpg`
- `jpeg`

### Configure

| Field | Description |
|---|---|
| `parsing_context` | Extraction instructions |
| `fields` | Fields to extract |
| `output_table_name` | Output dataframe |

---

# 3. Decision Point

Optional conditional execution logic.

## Configure

| Field | Description |
|---|---|
| `is_enabled` | Enable decision validation |
| `text_in_body` | Required text in email body |

If text is not found, workflow may stop.

---

# 4. S3 / Postgre Input Tables

Used when workflow directly loads external data.

---

# 4.1 S3 Structured Input

Supported:

- `xlsx`
- `csv`

## Configure

| Field | Description |
|---|---|
| `s3_bucket_name` | Bucket name |
| `s3_key` | Exact file path |
| `s3_folder` | Folder path |
| `file_name_template` | File matching pattern |
| `pick_strategy` | File selection strategy |
| `sheets` | Excel sheet configuration |

---

## Pick Strategy

| Value | Meaning |
|---|---|
| `latest` | Pick latest file |
| `current_date` | Pick today's file |
| `exact` | Exact file match |
| `all` | Load all matching files |

---

# 4.2 S3 Unstructured Input

Supported:

- `pdf`
- `png`
- `jpg`
- `jpeg`

## Configure

| Field | Description |
|---|---|
| `parsing_context` | Extraction guidance |
| `fields` | Fields to extract |
| `output_table_name` | Output dataframe |

---

# 4.3 Postgre Input

## Configure

| Field | Description |
|---|---|
| `schema` | Database schema |
| `table_name` | Source table |
| `selected_columns` | Required columns |
| `required_all_columns` | Load complete table |
| `output_table_name` | Output dataframe |

---

# 5. Post Processing

Used for transformations and data preparation.

---

# 5.1 SQL Processing

## Configure

| Field | Description |
|---|---|
| `input_tables` | Input dataframe names |
| `query` | SQL query |
| `output` | Output dataframe |

## Common Use Cases

- Table joins
- Filtering
- Aggregation
- Deduplication

---

# 5.2 Pandas Processing

Currently Supported Operations:

- `transpose`

## Configure

| Field | Description |
|---|---|
| `input_tables` | Input dataframe |
| `operation` | Pandas operation |
| `output_tables` | Output dataframe |

---

# 6. Output Handling

---

# 6.1 Save To S3

Used to save output files.

## Configure

| Field | Description |
|---|---|
| `bucket_name` | Target bucket |
| `key_folder` | Output folder |
| `all_dataframes` | Save all dataframes |
| `selected_dataframes` | Save selected dataframes |
| `all_dataframes_in_one_file` | Merge outputs |
| `file_format` | `xlsx` or `csv` |

---

# 6.2 Update Database

Used to insert processed data into PostgreSQL.

## Configure

| Field | Description |
|---|---|
| `input_table` | Source dataframe |
| `postgre_table_name` | Target table |
| `schema` | Target schema |
| `mode` | Insert mode |
| `auto_create_table` | Auto create table |
| `auto_add_columns` | Auto add missing columns |

---

## Supported Modes

- `append`

---

# 7. HITL (Human In The Loop)

Enable manual approval step.

## Configure

| Field | Description |
|---|---|
| `is_enable` | Pause workflow for review |

---

# 8. Send Email

Used for final email distribution.

---

# 8.1 Single Mode Distribution

One email for complete dataset.

## Configure

| Field | Description |
|---|---|
| `to` | Recipient list |
| `cc` | CC recipients |
| `bcc` | BCC recipients |
| `subject` | Email subject |
| `body_context` | Email body instructions |
| `table_as_markdown` | Inline tables |
| `table_as_attachment` | File attachments |

---

# 8.2 Multi Mode Distribution

Separate emails based on grouping.

## Configure

| Field | Description |
|---|---|
| `group_by.column` | Split column |
| `recipient_mapping` | Mapping per group |

## Common Use Cases

- Region-wise emails
- Market-wise emails
- Customer-wise reports

---

# 8.3 Markdown Tables

Inline tables inside email body.

## Configure

| Field | Description |
|---|---|
| `all_dataframes` | Include all dataframes |
| `selected_dataframes` | Include selected dataframes |

---

# 8.4 Attachment Tables

Attach dataframes as files.

## Configure

| Field | Description |
|---|---|
| `all_dataframes` | Attach all dataframes |
| `selected_dataframes` | Attach selected dataframes |
| `all_dataframes_in_one_file` | Merge outputs |
| `attachment_format` | `xlsx` or `csv` |

---

# 9. Important Validation Rules

---

## Receive Email Validation

If:

```json
"is_enabled": true
```

Then:

```json
"receive_details"
```

is mandatory.

---

## Scheduled Jobs Validation

If:

```json
"job_trigger_point": "SCHEDULED_TIME"
```

Then configure:

- `schedule_run_times`
- `days_of_week`
- `timezone`

---

# 10. Recommended Workflow Order

```text
Receive Email
    ↓
Parse Email / Attachments
    ↓
Decision Point
    ↓
Load S3 / Postgre Tables
    ↓
Post Processing
    ↓
Save Outputs
    ↓
Human Review (Optional)
    ↓
Send Email
```

---

# 11. Best Practices

- Always use meaningful `output_table_name`
- Keep SQL outputs reusable
- Use synonyms for better extraction accuracy
- Prefer structured parsing whenever possible
- Use multi-mode only when recipient split is required
- Enable `auto_add_columns` for evolving schemas
- Use `linked_tables` for dependency tracking
- Keep post-processing modular
- Validate file naming templates carefully

---

# 12. Supported Enums

---

## Job Type

```text
Email
Document
```

---

## Trigger Point

```text
RECEIVED_EMAIL
SCHEDULED_TIME
```

---

## Structured File Types

```text
xlsx
csv
```

---

## Unstructured File Types

```text
pdf
png
jpg
jpeg
any
```

---

## Post Processing Types

```text
sql
pandas
```

---

## Pandas Operations

```text
transpose
```

---

## Postgre Modes

```text
append
```

---

# 13. Minimal Example Structure

```json
{
  "meta_data": {},
  "job_steps": {
    "receive_email": {},
    "decision_point": {},
    "s3_postgre_input_tables": {},
    "post_processing": {},
    "output_handling": {},
    "required_hitl": {},
    "send_email": {}
  }
}
```
"""