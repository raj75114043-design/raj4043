from app.config.azure_doc_settings import get_config
from app.services.azure_doc_parsing import DocumentService

def get_document_service():
    config = get_config()
    return DocumentService(config)