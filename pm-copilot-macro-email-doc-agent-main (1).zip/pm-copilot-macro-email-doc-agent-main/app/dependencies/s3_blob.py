from app.services.s3_blob_management import S3Service

def get_s3_service():
    return S3Service()