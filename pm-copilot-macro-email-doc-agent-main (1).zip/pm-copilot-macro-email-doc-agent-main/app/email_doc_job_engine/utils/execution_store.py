
# app\email_doc_job_engine\utils\execution_store.py

import asyncio
from datetime import datetime, timedelta
from app.utils.timezone import get_datetime_now_without_zone

EXECUTION_STORE = {}
EXECUTION_LOCK = asyncio.Lock()

# CLEANUP_AFTER_SECONDS = 300  #5 mins

async def create_execution(execution_id: str, job_id: str):

    time_now = get_datetime_now_without_zone()

    async with EXECUTION_LOCK:

        EXECUTION_STORE[execution_id] = {
            "execution_id": execution_id,
            "job_id": job_id,
            "status": "QUEUED",
            "created_at": time_now,
            "started_at": None,
            "completed_at": None,
            "execution_log": {
                "steps": []
            },
            "result": None,
            "error": None
        }

        print(
            f"\n[EXECUTION CREATED] "
            f"execution_id={execution_id} "
            f"job_id={job_id}"
        )


async def update_execution(
    execution_id: str,
    log_step: str = None,
    log_message: str = None,
    **kwargs
):

    async with EXECUTION_LOCK:

        if execution_id not in EXECUTION_STORE:
            return

        # ----------------------------------------
        # NORMAL FIELD UPDATE
        # ----------------------------------------
        EXECUTION_STORE[execution_id].update(kwargs)

        # ----------------------------------------
        # EXECUTION LOG APPEND
        # ----------------------------------------
        if log_step and log_message:

            time_now = get_datetime_now_without_zone()

            EXECUTION_STORE[
                execution_id
            ]["execution_log"]["steps"].append({
                "step": log_step,
                "message": log_message,
                "timestamp": time_now
            })


async def get_execution(execution_id: str):

# async with EXECUTION_LOCK:
    return EXECUTION_STORE.get(execution_id)


# async def cleanup_execution_after_delay(execution_id: str):

#     await asyncio.sleep(CLEANUP_AFTER_SECONDS)

#     async with EXECUTION_LOCK:

#         if execution_id in EXECUTION_STORE:
#             del EXECUTION_STORE[execution_id]

#             print(f"[CLEANUP] Removed execution_id={execution_id}")


async def cleanup_execution(
    execution_id: str
):

    async with EXECUTION_LOCK:

        if execution_id in EXECUTION_STORE:

            del EXECUTION_STORE[
                execution_id
            ]

            print(
                f"[CLEANUP] Removed execution_id={execution_id}\n"
            )


async def get_execution_log(
    execution_id: str
):

    # async with EXECUTION_LOCK:

    if execution_id not in EXECUTION_STORE:
        return {}

    return EXECUTION_STORE[
        execution_id
    ].get(
        "execution_log",
        {}
    )