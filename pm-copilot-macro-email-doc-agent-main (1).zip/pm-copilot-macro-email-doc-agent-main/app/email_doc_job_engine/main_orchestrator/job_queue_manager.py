# app/email_doc_job_engine/job_queue/job_queue_manager.py

import asyncio
import uuid

from app.db.pool import get_connection

from app.email_doc_job_engine.main_orchestrator.orchestrator import run_job

from app.email_doc_job_engine.utils.execution_store import (
    create_execution,
    update_execution,
    cleanup_execution
)


from app.dependencies.azure_doc_intelligence import (
    get_document_service
)

from app.dependencies.s3_blob import (
    get_s3_service
)


# =========================================================
# CONFIG
# =========================================================

MAX_QUEUE_SIZE = 50

# only ONE worker
TOTAL_WORKERS = 1

# =========================================================
# GLOBAL QUEUE
# =========================================================

JOB_QUEUE = asyncio.Queue(maxsize=MAX_QUEUE_SIZE)

# prevent duplicate worker startup
WORKER_STARTED = False

# jobs currently executing
RUNNING_JOBS = {}

# jobs waiting in queue
QUEUED_JOBS = set()

# shared lock
JOB_STATE_LOCK = asyncio.Lock()

# =========================================================
# ADD JOB TO QUEUE
# =========================================================

async def enqueue_job(
    *,
    job_id
):

    # -----------------------------------------
    # DUPLICATE CHECK
    # -----------------------------------------

    async with JOB_STATE_LOCK:

        running_jobs = [
            {
                "job_id": job_id,
                "execution_id": data["execution_id"]
            }
            for job_id, data in RUNNING_JOBS.items()
        ]
        queued_jobs = list(QUEUED_JOBS)

        # -----------------------------------------
        # ALREADY QUEUED
        # -----------------------------------------

        if job_id in QUEUED_JOBS:

            return {
                "success": False,
                "status": "ALREADY_QUEUED",
                "message": f"Job already queued: {job_id}",
                "execution_id": None,
                "job_id": job_id,
                "queue_position": None,
                "running_job_ids": running_jobs,
                "queued_job_ids": queued_jobs
            }

        # -----------------------------------------
        # ALREADY RUNNING
        # -----------------------------------------

        if job_id in RUNNING_JOBS:

            return {
                "success": False,
                "status": "ALREADY_RUNNING",
                "message": f"Job already running: {job_id}",
                "execution_id": None,
                "job_id": job_id,
                "queue_position": None,
                "running_job_ids": running_jobs,
                "queued_job_ids": queued_jobs
            }

        
    # -----------------------------------------
    # QUEUE FULL
    # -----------------------------------------

    if JOB_QUEUE.full():

        async with JOB_STATE_LOCK:

            running_jobs = [
                {
                    "job_id": job_id,
                    "execution_id": data["execution_id"]
                }
                for job_id, data in RUNNING_JOBS.items()
            ]
            queued_jobs = list(QUEUED_JOBS)

        return {
            "success": False,
            "status": "QUEUE_FULL",
            "message": (
                "Job queue is full. "
                "Please try again after some time."
            ),
            "execution_id": None,
            "job_id": job_id,
            "queue_position": None,
            "running_job_ids": running_jobs,
            "queued_job_ids": queued_jobs
        }

    # -----------------------------------------
    # CREATE EXECUTION
    # -----------------------------------------

    execution_id = str(uuid.uuid4())

    await create_execution(
        execution_id=execution_id,
        job_id=job_id
    )


    # -----------------------------------------
    # MARK QUEUED
    # -----------------------------------------

    async with JOB_STATE_LOCK:
        QUEUED_JOBS.add(job_id)
            


    # -----------------------------------------
    # ADD TO QUEUE
    # -----------------------------------------

    try:

        await JOB_QUEUE.put({
            "execution_id": execution_id,
            "job_id": job_id
        })

    except Exception:

        async with JOB_STATE_LOCK:
            QUEUED_JOBS.discard(job_id)

        raise



    # -----------------------------------------
    # QUEUE POSITION
    # -----------------------------------------

    queue_position = JOB_QUEUE.qsize()

    await update_execution(
        execution_id=execution_id,
        status="QUEUED",
        result={
            "queue_position": queue_position
        }
    )


    # -----------------------------------------
    # FINAL STATE
    # -----------------------------------------

    async with JOB_STATE_LOCK:

        running_jobs = [
            {
                "job_id": job_id,
                "execution_id": data["execution_id"]
            }
            for job_id, data in RUNNING_JOBS.items()
        ]
        queued_jobs = list(QUEUED_JOBS)

    return {
        "success": True,
        "status": "QUEUED",
        "message": "Job added to queue successfully",
        "execution_id": execution_id,
        "job_id": job_id,
        "queue_position": queue_position,
        "running_job_ids": running_jobs,
        "queued_job_ids": queued_jobs
    }


# =========================================================
# SINGLE WORKER
# =========================================================

async def queue_worker():

    print("[JOB QUEUE] Worker started")

    while True:

        execution_id = None
        job_id = None

        try:

            # -------------------------------------------------
            # WAIT FOR NEXT JOB
            # -------------------------------------------------

            job_data = await JOB_QUEUE.get()

            execution_id = job_data["execution_id"]
            job_id = job_data["job_id"]

            # -------------------------------------------------
            # MOVE QUEUED -> RUNNING
            # -------------------------------------------------

            async with JOB_STATE_LOCK:

                QUEUED_JOBS.discard(job_id)

                RUNNING_JOBS[job_id] = {
                    "execution_id": execution_id
                }

            print(
                f"[JOB QUEUE] Running job={job_id}"
            )

            # -------------------------------------------------
            # UPDATE EXECUTION
            # -------------------------------------------------

            await update_execution(
                execution_id=execution_id,
                status="RUNNING"
            )

            # -------------------------------------------------
            # CREATE SERVICES ONLY WHEN JOB STARTS
            # -------------------------------------------------

            azure_service = get_document_service()
            s3_service = get_s3_service()

            # -------------------------------------------------
            # RUN JOB
            # -------------------------------------------------

            async with get_connection() as db:

                await run_job(
                    db=db,
                    azure_service=azure_service,
                    s3_service=s3_service,
                    job_id=job_id,
                    execution_id=execution_id
                )

            print(
                f"[JOB SUCCESS] {job_id}"
            )

        # -----------------------------------------------------
        # HANDLE FAILURES
        # -----------------------------------------------------

        except Exception as e:

            print(
                f"[JOB FAILED] {job_id} -> {str(e)}"
            )

            if execution_id:

                await update_execution(
                    execution_id=execution_id,
                    status="FAILED",
                    error=str(e)
                )

        # -----------------------------------------------------
        # CLEANUP
        # -----------------------------------------------------

        finally:

            if job_id:

                async with JOB_STATE_LOCK:

                    RUNNING_JOBS.pop(
                        job_id,
                        None
                    )

            # mark queue task complete safely
            try:
                JOB_QUEUE.task_done()
            except Exception:
                pass

            # immediate cleanup
            if execution_id:
                await cleanup_execution(execution_id)

            # prevent tight crash loop
            await asyncio.sleep(0.1)


# # =========================================================
# # SINGLE WORKER
# # =========================================================

# async def queue_worker():

#     print("[JOB QUEUE] Worker started")

#     while True:

#         job_data = await JOB_QUEUE.get()

#         execution_id = job_data["execution_id"]
#         job_id = job_data["job_id"]

#         async with JOB_STATE_LOCK:

#             QUEUED_JOBS.discard(job_id)

#             RUNNING_JOBS[job_id] = {
#                 "execution_id": execution_id
#             }

#         try:

#             print(
#                 f"[JOB QUEUE] Running job={job_id}"
#             )

#             await update_execution(
#                 execution_id=execution_id,
#                 status="RUNNING"
#             )


#             async with get_connection() as db:

#                 azure_service = get_document_service()
#                 s3_service = get_s3_service()

#                 await run_job(
#                     db=db,
#                     azure_service=azure_service,
#                     s3_service=s3_service,
#                     job_id=job_id,
#                     execution_id=execution_id
#                 )
                

#         except Exception as e:

#             print(
#                 f"[JOB FAILED] {job_id} -> {str(e)}"
#             )
#             await update_execution(
#                 execution_id=execution_id,
#                 status="FAILED",
#                 error=str(e)
#             )

#         finally:

#             async with JOB_STATE_LOCK:
#                 RUNNING_JOBS.pop(job_id, None)

#             JOB_QUEUE.task_done()

#             # -----------------------------------------
#             # CLEANUP EXECUTION CACHE
#             # -----------------------------------------

#             asyncio.create_task(
#                 cleanup_execution_after_delay(
#                     execution_id
#                 )
#             )

# =========================================================
# START WORKERS
# =========================================================

async def start_job_queue_worker():

    global WORKER_STARTED

    if WORKER_STARTED:
        return

    WORKER_STARTED = True

    for _ in range(TOTAL_WORKERS):

        asyncio.create_task(
            queue_worker()
        )

    print(
        f"[JOB QUEUE] Started "
        f"{TOTAL_WORKERS} worker(s)"
    )

# =========================================================
# GET QUEUE STATUS
# ========================================================

async def get_job_queue_state():

    async with JOB_STATE_LOCK:

        running_jobs = [
            {
                "job_id": job_id,
                "execution_id": data["execution_id"]
            }
            for job_id, data in RUNNING_JOBS.items()
        ]
        return {
            "running_job_ids": running_jobs,
            "queued_job_ids": list(QUEUED_JOBS),
            "running_count": len(RUNNING_JOBS),
            "queued_count": len(QUEUED_JOBS),
            "queue_size": JOB_QUEUE.qsize(),
            "max_queue_size": MAX_QUEUE_SIZE,
            "available_slots": (
                MAX_QUEUE_SIZE - JOB_QUEUE.qsize()
            )
        }