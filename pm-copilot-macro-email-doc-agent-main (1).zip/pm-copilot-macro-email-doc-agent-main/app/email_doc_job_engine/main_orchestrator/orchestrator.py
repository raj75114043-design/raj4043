# app\schedule_job\email_job_orchestrator\orchestrator.py

import pandas as pd
import asyncio
from datetime import datetime
from zoneinfo import ZoneInfo

from app.services.azure_doc_parsing import DocumentService
from app.services.s3_blob_management import S3Service

from asyncpg import Connection
from fastapi import HTTPException

from app.email_doc_job_engine.orchestrator_services.job_config_loader import load_job_config
from app.email_doc_job_engine.orchestrator_services.received_email_collector import fetch_matching_email
from app.email_doc_job_engine.orchestrator_services.dataframes_loader_s3_postgre import load_dataframes_from_s3_postgre
from app.email_doc_job_engine.orchestrator_services.dataframes_loader_received import load_dataframes_from_received_mail
from app.email_doc_job_engine.orchestrator_services.output_handler import handle_outputs
from app.email_doc_job_engine.orchestrator_services.email_drafter import send_email_output
from app.email_doc_job_engine.orchestrator_services.decision_maker import check_final_go_decision
from app.email_doc_job_engine.orchestrator_services.job_execution_tracker import update_job_execution_status, update_job_current_status
from app.email_doc_job_engine.data_processing_engine.data_operation_engine import DataOperationEngine

from app.utils.timezone import get_datetime_now_without_zone

from app.email_doc_job_engine.utils.execution_store import update_execution, get_execution_log

from app.email_doc_job_engine.job_schema.job_config_class import JobConfig

from app.email_doc_job_engine.utils.safe_loader import safe_get


# =====================================================
# MAIN ORCHESTRATOR
# =====================================================

MAX_ROWS = 100_000
MAX_COLS = 200

EMAIL_MAX_ROWS = 10_000
EMAIL_MAX_COLS = 50


# =====================================================
# DF LIMITER
# =====================================================

def _enforce_df_limits(
    dfs: dict,
    max_rows: int = 100_000,
    max_cols: int = 100
) -> dict:

    limited = {}

    for name, df in dfs.items():

        if not isinstance(df, pd.DataFrame):
            limited[name] = df
            continue

        original_shape = df.shape

        if len(df) > max_rows:
            df = df.head(max_rows)

        if df.shape[1] > max_cols:
            df = df.iloc[:, :max_cols]

        # print(f"[LIMIT] {name}: {original_shape} -> {df.shape}")

        limited[name] = df

    return limited


# =====================================================
# RUN JOB
# =====================================================

async def run_job(
    db: Connection,
    azure_service: DocumentService,
    s3_service: S3Service,
    job_id: str,
    execution_id: str = None
):

    print(f"\n>>>> [Engine] - Job: {job_id} Execution Started...\n")

    Status = None
    final_dfs = {}
    email_data = {}
    final_go_decision = True
    job_started_at = get_datetime_now_without_zone()

    try:

        # =====================================================
        # MARK RUNNING
        # =====================================================

        if execution_id:

            time_now = get_datetime_now_without_zone()

            await update_execution(
                execution_id=execution_id,
                status="RUNNING",
                started_at=time_now
            )

        await update_job_current_status(
            db=db,
            job_id=job_id,
            current_status='RUNNING'
        )





        # =====================================================
        # LOAD CONFIG
        # =====================================================
        job = await load_job_config(db, job_id)

        if job:
            
            await update_execution(
                execution_id=execution_id,
                log_step="CONFIG_LOADED",
                log_message="Configuration Loaded Successfully"
            )

        # validated_job = JobConfig.model_validate(job)

        # try:
        #     job = await load_job_config(db, job_id)
        #     # validated_job = JobConfig.model_validate(job)
        #     # print(f"[CONFIG VALIDATION SUCCESS] Job '{validated_job.meta_data.job_id}' validated successfully")

        # except Exception as e:
        #     print(f"[CONFIG VALIDATION FAILED] Job '{job_id}' failed validation: {str(e)}")
        #     raise





        # =====================================================
        # RECEIVE EMAIL
        # =====================================================

        if safe_get(job, "job_steps", "receive_email", "is_enabled", default=False):

            received_email = safe_get(job, "job_steps", "receive_email", default={})
            subject_template = safe_get(received_email, "receive_details", "subject_template", default="")

            await update_execution(
                execution_id=execution_id,
                log_step="RECEIVE_EMAIL",
                log_message=f"Receive Email Started with Subject Template: {subject_template}"
            )

            try:
                email_data = await fetch_matching_email(
                    db,
                    subject_template,
                    execution_id
                )
            except Exception as e:
                print(f"[EMAIL FETCH ERROR] {str(e)}")
                raise
            

            if email_data:

                await update_execution(
                    execution_id=execution_id,
                    log_step="RECEIVE_EMAIL",
                    log_message=f"Fetched Email Data with Subject: {len(email_data)}"
                )

                # =====================================================
                # LOAD EMAIL DATAFRAMES
                # =====================================================

                email_dfs = await load_dataframes_from_received_mail(
                    db,
                    s3_service,
                    azure_service,
                    safe_get(job,"job_steps","receive_email","parsing",default={}),
                    email_data,
                    execution_id
                )

                if email_dfs:
                    final_dfs.update(email_dfs)

                    await update_execution(
                        execution_id=execution_id,
                        log_step="RECEIVE_EMAIL",
                        log_message=f"Fetched All DataFrames From Received Email with Total DF = {len(final_dfs)}"
                    )




        # =====================================================
        # DECISION POINT
        # =====================================================

        decision_point_info = safe_get(job, "job_steps", "decision_point", default={})

        if safe_get(job, "job_steps", "decision_point", "is_enable", default=False):

            final_go_decision = check_final_go_decision(
                decision_point_info,
                email_data
            )

        await update_execution(
            execution_id=execution_id,
            log_step="FINAL GO DECISION",
            log_message=f"Final Go Decision: {final_go_decision}"
        )

        # =====================================================
        # STOP IF DECISION FALSE
        # =====================================================

        if not final_go_decision:

            Status = "SKIPPED"

            time_now = get_datetime_now_without_zone()
            await update_execution(
                execution_id=execution_id,
                status="JOB SKIPPED",
                completed_at=time_now,
                log_step="SKIPPED",
                log_message=f"Decision point returned FALSE"
            )

            await update_job_current_status(
                db=db,
                job_id=job_id,
                current_status='JOB SKIPPED'
            )

            return Status





        # =====================================================
        # LOAD S3 / POSTGRES TABLES
        # =====================================================

        # if job.get("job_steps", {}).get("s3_postgre_input_tables", {}).get("is_required", False):    
        if safe_get(job, "job_steps", "s3_postgre_input_tables", "is_required", default=False):

            await update_execution(
                execution_id=execution_id,
                log_step="LOAD DATAFRAMES FROM S3-PostgreDB",
                log_message=f"S3 and Postgre Data Loading Started"
            )

            # s3_postgre_input_info=job.get("job_steps", {}).get("s3_postgre_input_tables", {})
            s3_postgre_input_info = safe_get(job, "job_steps", "s3_postgre_input_tables", default={})

            s3_pg_dfs = await load_dataframes_from_s3_postgre(
                db,
                s3_service,
                azure_service,
                s3_postgre_input_info,
                execution_id
            )

            if s3_pg_dfs:

                final_dfs.update(s3_pg_dfs)
                await update_execution(
                    execution_id=execution_id,
                    log_step="LOAD DATAFRAMES FROM S3-PostgreDB",
                    log_message="Structured Input Loaded Successfully From S3 and Postgre"
                )



        # =====================================================
        # VALIDATE DATAFRAMES
        # =====================================================

        if final_dfs:

            for name, df in final_dfs.items():

                await update_execution(
                    execution_id=execution_id,
                    log_step="FINAL DATAFRAMES",
                    log_message=f"DataFrame '{name}' generated with rows={len(df)} cols={len(df.columns)}"
                )


        else:

            await update_execution(
                execution_id=execution_id,
                log_step="FINAL DATAFRAMES",
                log_message="No dataframes generated from any source"
            )

            raise HTTPException(
                status_code=400,
                detail="No dataframes generated from any source"
            )

        # =====================================================
        # LIMIT INPUT DFS
        # =====================================================

        final_dfs = _enforce_df_limits(
            final_dfs,
            MAX_ROWS,
            MAX_COLS
        )




        # =====================================================
        # POST PROCESSING
        # =====================================================

        # if job.get("job_steps", {}).get("post_processing", {}).get("is_operation_required", False):
        if safe_get(job, "job_steps", "post_processing", "is_operation_required", default=False):
            
            await update_execution(
                execution_id=execution_id,
                log_step="DATA PROCESSING",
                log_message="Data Processing Started"
            )

            post_processing = safe_get(job, "job_steps", "post_processing", default={})

            steps = safe_get(post_processing, "steps", default=[])

            await update_execution(
                execution_id=execution_id,
                log_step="DATA PROCESSING",
                log_message=f"Total Number of Steps: {len(steps)}"
            )
            # engine = DataOperationEngine()

            # post_final_tables = engine.process(
            #     final_dfs,
            #     steps
            # )

            engine = DataOperationEngine()

            post_final_tables = await asyncio.to_thread(
                engine.process,
                final_dfs,
                steps
            )

            post_final_tables = _enforce_df_limits(
                post_final_tables,
                MAX_ROWS,
                MAX_COLS
            )

        else:

            post_final_tables = final_dfs



        # =====================================================
        # FINAL TABLE PREP
        # =====================================================

        final_dfs_new = {}

        for name, df in post_final_tables.items():

            if isinstance(df, pd.DataFrame):

                final_dfs_new[name] = df.head(1000)

                # print(f"\nFinal DF: {name}\n", df.head(5))
                # print("\nColumn Data Types:")
                # print(df.dtypes)

                await update_execution(
                    execution_id=execution_id,
                    log_step="POST-DATA PROCESSING",
                    log_message=f"Prepared dataframe '{name}' rows={len(df)} cols={len(df.columns)}"
                )

            else:

                final_dfs_new[name] = df

                await update_execution(
                    execution_id=execution_id,
                    log_step="POST-DATA PROCESSING",
                    log_message=f"Stored non-dataframe object '{name}'"
                )





        # =====================================================
        # OUTPUT HANDLING
        # =====================================================

        output_handling = safe_get(job, "job_steps", "output_handling", default={})

        if (
            safe_get(output_handling, "update_db", "is_enabled", default=False)
            or
            safe_get(output_handling, "save_to_s3", "enabled", default=False)
        ):
            await handle_outputs(
                db,
                s3_service,
                output_handling,
                tables=post_final_tables
            )

            await update_execution(
                execution_id=execution_id,
                log_step="OUTPUT HANDLING",
                log_message="Output Handling Completed"
            )

        else:

            await update_execution(
                execution_id=execution_id,
                log_step="OUTPUT HANDLING",
                log_message="Output Handling Skipped"
            )




        # =====================================================
        # LIMIT EMAIL TABLES
        # =====================================================

        post_final_tables = _enforce_df_limits(
            post_final_tables,
            EMAIL_MAX_ROWS,
            EMAIL_MAX_COLS
        )



        # =====================================================
        # SEND EMAIL
        # =====================================================

        required_hitl = safe_get(
            job,
            "job_steps",
            "required_hitl",
            "is_enable",
            default=False
        )

        print(f"\n>>>>>>>>>>>> HITL = {required_hitl} <<<<<<<<<<<<\n")

        await update_execution(
            execution_id=execution_id,
            log_step="EMAIL SENDING/DRAFTING STARTED",
            log_message="Email Sending / Drafting Started..."
        )

        await send_email_output(
            db=db,
            job_id=job_id,
            config=safe_get(job, "job_steps", "send_email", default={}),
            tables=post_final_tables,
            email_data=email_data,
            required_hitl=required_hitl,
            execution_id=execution_id
        )


        # =====================================================
        # FINAL STATUS
        # =====================================================

        if required_hitl:

            Status = "DRAFTED SUCCESS"

            await update_execution(
                execution_id=execution_id,
                log_step="DRAFT_EMAIL",
                log_message="Email Drafted"
            )

        else:

            Status = "MAIL SENT SUCCESS"

            await update_execution(
                execution_id=execution_id,
                log_step="SEND_EMAIL",
                log_message="Email Transaction Done"
            )






        # =====================================================
        # DB TRACKER
        # =====================================================

        try:
            execution_log = await get_execution_log(execution_id)
            await update_job_execution_status(
                db=db,
                job_id=job_id,
                execution_log=execution_log,   
                status=Status,
                started_at=job_started_at,
                completed_at=get_datetime_now_without_zone(),
                extra_data={
                    "total_dataframes": len(final_dfs_new)
                }
            )

        except Exception as tracking_error:

            print(
                "FAILED TO SAVE JOB STATUS:",
                str(tracking_error)
            )



        # =====================================================
        # UPDATE CACHE
        # =====================================================

        if execution_id:

            await update_execution(
                execution_id=execution_id,
                status=Status,
                completed_at=get_datetime_now_without_zone(),
                result={
                    "job_id": job_id,
                    "status": Status,
                    "total_dataframes": len(final_dfs_new)
                }
            )

        return Status

        # =====================================================
        # EXCEPTION
        # =====================================================

    except ValueError as e:

        error_message = str(e)

        # ---------------------------------------------
        # NO EMAIL FOUND → SKIPPED
        # ---------------------------------------------

        if "No matching email found" in error_message:

            Status = "SKIPPED"

            await update_execution(
                execution_id=execution_id,
                status="SKIPPED",
                completed_at=get_datetime_now_without_zone(),
                log_step="JOB_SKIPPED",
                log_message=error_message
            )

            try:

                execution_log = await get_execution_log(execution_id)

                await update_job_execution_status(
                    db=db,
                    job_id=job_id,
                    execution_log=execution_log,
                    status="SKIPPED",
                    started_at=job_started_at,
                    completed_at=get_datetime_now_without_zone(),
                    extra_data={
                        "reason": error_message
                    }
                )

            except Exception as tracking_error:

                print(
                    "FAILED TO SAVE JOB STATUS:",
                    str(tracking_error)
                )

            print(
                f"[JOB SKIPPED] {job_id} -> {error_message}"
            )

            return "SKIPPED"

        # ---------------------------------------------
        # OTHER VALUE ERRORS
        # ---------------------------------------------

        raise


    # =====================================================
    # FINALLY
    # =====================================================

    finally:

        await update_job_current_status(
            db=db,
            job_id=job_id,
            current_status='IDLE'
        )

        print(f"\n>>>> [Engine] - Job: {job_id} Execution Completed\n")
