from __future__ import annotations
from enum import Enum
from typing import Dict, List, Optional, Union, Literal
from datetime import time

from pydantic import (
    BaseModel,
    Field,
    ConfigDict,
    model_validator
)

# =========================================================
# BASE MODEL
# =========================================================

class SafeBaseModel(BaseModel):
    """
    Common base model.

    - Allows partial payloads
    - Ignores unknown fields
    - Makes workflow configs future-proof
    """

    model_config = ConfigDict(
        extra="ignore",
        arbitrary_types_allowed=True
    )


# =========================================================
# LITERALS
# =========================================================

JobTypeLiteral = Literal[
    "Email",
    "Document"
]

TriggerPointLiteral = Literal[
    "RECEIVED_EMAIL",
    "SCHEDULED_TIME"
]

DaysLiteral = Literal[
    "MON",
    "TUE",
    "WED",
    "THU",
    "FRI",
    "SAT",
    "SUN"
]

TimezoneLiteral = Literal[
    "Asia/Kolkata",
    "UTC",
    "America/New_York",
    "America/Chicago",
    "America/Denver",
    "America/Los_Angeles",
    "Europe/London",
    "Europe/Paris",
    "Asia/Singapore",
    "Asia/Dubai",
    "Asia/Tokyo",
    "Australia/Sydney"
]


SchemaName = Literal[
    "pwc_macro_staging_schema",
    "macro_email_doc_agent",
    "pwc_workflow_agent_schema",
    "public"
]


# =========================================================
# ENUMS
# =========================================================

class FieldType(str, Enum):
    STRING = "string"
    INT = "int"
    BOOLEAN = "boolean"
    DATE = "date"
    DATETIME = "datetime"


class StructuredFileType(str, Enum):
    XLSX = "xlsx"
    CSV = "csv"


class UnstructuredFileType(str, Enum):
    JPG = "jpg"
    JPEG = "jpeg"
    PNG = "png"
    PDF = "pdf"
    ANY = "any"


class PickStrategy(str, Enum):
    LATEST = "latest"
    CURRENT_DATE = "current_date"
    EXACT = "exact"
    ALL = "all"


class PostgresMode(str, Enum):
    APPEND = "append"



class PostProcessingType(str, Enum):
    SQL = "sql"
    PANDAS = "pandas"


class PandasOperations(str, Enum):
    TRANSPOSE = "transpose"


# =========================================================
# COMMON MODELS
# =========================================================

class ParsingFieldDefinition(SafeBaseModel):
    name: Optional[str] = None
    type: Optional[FieldType] = None
    synonyms: List[str] = Field(default_factory=list)


class TableField(SafeBaseModel):
    name: Optional[str] = None
    type: Optional[FieldType] = None


# =========================================================
# EMAIL BODY PARSING
# =========================================================

class EmailBodyContextTable(SafeBaseModel):
    output_table_name: Optional[str] = None
    parsing_context: Optional[str] = None
    fields: List[ParsingFieldDefinition] = Field(default_factory=list)


class EmailBodyParsing(SafeBaseModel):
    is_available: bool = False
    context_to_llm: List[EmailBodyContextTable] = Field(default_factory=list)


# =========================================================
# TABLES IN BODY
# =========================================================

class BodyTableDefinition(SafeBaseModel):
    output_table_name: Optional[str] = None
    fields: List[TableField] = Field(default_factory=list)


class TablesInBody(SafeBaseModel):
    is_available: bool = False
    tables: List[BodyTableDefinition] = Field(default_factory=list)


# =========================================================
# STRUCTURED FILE PARSING
# =========================================================

class StructuredSheetDefinition(SafeBaseModel):
    sheet_name: Optional[str] = None
    all_fields: bool = False
    starting_row: int = 1
    fields: List[TableField] = Field(default_factory=list)
    output_table_name: Optional[str] = None


class StructuredFileDefinition(SafeBaseModel):
    file_name_template: Optional[str] = None
    file_type: StructuredFileType = StructuredFileType.XLSX
    sheets: List[StructuredSheetDefinition] = Field(default_factory=list)


# =========================================================
# UNSTRUCTURED FILE PARSING
# =========================================================

class UnstructuredFileDefinition(SafeBaseModel):
    file_name_template: Optional[str] = None
    file_type: UnstructuredFileType = UnstructuredFileType.ANY
    fields: List[ParsingFieldDefinition] = Field(default_factory=list)
    parsing_context: Optional[str] = None
    output_table_name: Optional[str] = None


# =========================================================
# ATTACHMENTS
# =========================================================

class StructuredAttachmentConfig(SafeBaseModel):
    is_available: bool = False
    selected_files: List[StructuredFileDefinition] = Field(default_factory=list)


class UnstructuredAttachmentConfig(SafeBaseModel):
    is_available: bool = False
    selected_files: List[UnstructuredFileDefinition] = Field(default_factory=list)


class AttachmentParsing(SafeBaseModel):
    is_available: bool = False
    structured: Optional[StructuredAttachmentConfig] = None
    unstructured: Optional[UnstructuredAttachmentConfig] = None


# =========================================================
# RECEIVE EMAIL
# =========================================================

class ReceiveDetails(SafeBaseModel):
    subject_template: Optional[str] = None


class ParsingConfig(SafeBaseModel):
    email_body: Optional[EmailBodyParsing] = None
    tables_in_body: Optional[TablesInBody] = None
    attachments: Optional[AttachmentParsing] = None


class ReceiveEmailStep(SafeBaseModel):
    is_enabled: bool = False
    receive_details: Optional[ReceiveDetails] = None
    parsing: Optional[ParsingConfig] = None

    @model_validator(mode="after")
    def validate_receive_email(self):

        if self.is_enabled and not self.receive_details:
            raise ValueError(
                "receive_details required when receive_email is enabled"
            )

        return self


# =========================================================
# DECISION POINT
# =========================================================

class DecisionPoint(SafeBaseModel):
    is_enabled: bool = False
    text_in_body: Optional[str] = None


# =========================================================
# S3 STRUCTURED INPUT
# =========================================================

class S3StructuredFileDefinition(SafeBaseModel):
    s3_bucket_name: Optional[str] = None
    s3_key: Optional[str] = None
    s3_folder: Optional[str] = None
    file_name_template: Optional[str] = None
    pick_strategy: Optional[PickStrategy] = None
    file_type: StructuredFileType = StructuredFileType.XLSX
    sheets: List[StructuredSheetDefinition] = Field(default_factory=list)


# =========================================================
# S3 UNSTRUCTURED INPUT
# =========================================================

class S3UnstructuredFileDefinition(SafeBaseModel):
    s3_bucket_name: Optional[str] = None
    s3_key: Optional[str] = None
    s3_folder: Optional[str] = None
    file_name_template: Optional[str] = None
    pick_strategy: Optional[PickStrategy] = None
    file_type: UnstructuredFileType = UnstructuredFileType.ANY
    fields: List[ParsingFieldDefinition] = Field(default_factory=list)
    parsing_context: Optional[str] = None
    output_table_name: Optional[str] = None


class S3StructuredConfig(SafeBaseModel):
    is_required: bool = False
    selected_files: List[S3StructuredFileDefinition] = Field(default_factory=list)


class S3UnstructuredConfig(SafeBaseModel):
    is_required: bool = False
    selected_files: List[S3UnstructuredFileDefinition] = Field(default_factory=list)


class S3BlobStorageConfig(SafeBaseModel):
    structured: Optional[S3StructuredConfig] = None
    unstructured: Optional[S3UnstructuredConfig] = None


# =========================================================
# POSTGRES INPUT TABLES
# =========================================================

class PostgreInputTable(SafeBaseModel):
    table_name: Optional[str] = None
    schema: Optional[SchemaName] = "macro_email_doc_agent"
    required_all_columns: bool = False
    selected_columns: List[str] = Field(default_factory=list)
    output_table_name: Optional[str] = None


class PostgreDBConfig(SafeBaseModel):
    is_required: bool = False
    tables: List[PostgreInputTable] = Field(default_factory=list)


# =========================================================
# INPUT TABLE CONFIG
# =========================================================

class S3PostgreInputTables(SafeBaseModel):
    is_required: bool = False
    s3_blob_storage: Optional[S3BlobStorageConfig] = None
    postgre_db: Optional[PostgreDBConfig] = None


# =========================================================
# POST PROCESSING
# =========================================================

class SQLProcessingStep(SafeBaseModel):
    id: Optional[int] = None
    type: PostProcessingType = PostProcessingType.SQL
    input_tables: List[str] = Field(default_factory=list)
    query: Optional[str] = None
    output: Optional[str] = None


class PandasProcessingStep(SafeBaseModel):
    id: Optional[int] = None
    type: PostProcessingType = PostProcessingType.PANDAS
    input_tables: List[str] = Field(default_factory=list)
    operation: Optional[PandasOperations] = PandasOperations.TRANSPOSE
    output_tables: List[str] = Field(default_factory=list)


PostProcessingStep = Union[
    SQLProcessingStep,
    PandasProcessingStep
]


class PostProcessingConfig(SafeBaseModel):
    is_operation_required: bool = False
    steps: List[PostProcessingStep] = Field(default_factory=list)


# =========================================================
# OUTPUT HANDLING
# =========================================================

class SaveToS3Config(SafeBaseModel):
    enabled: bool = False
    bucket_name: Optional[str] = None
    key_folder: Optional[str] = None
    all_dataframes: bool = False
    selected_dataframes: List[str] = Field(default_factory=list)
    all_dataframes_in_one_file: bool = False
    file_format: Optional[str] = "xlsx"


class UpdateDBTableConfig(SafeBaseModel):
    enabled: bool = False
    input_table: Optional[str] = None
    postgre_table_name: Optional[str] = None
    schema: Optional[SchemaName] = "macro_email_doc_agent"
    mode: PostgresMode = PostgresMode.APPEND
    auto_create_table: bool = True
    auto_add_columns: bool = True


class UpdateDBConfig(SafeBaseModel):
    is_enabled: bool = False
    table: List[UpdateDBTableConfig] = Field(default_factory=list)


class OutputHandlingConfig(SafeBaseModel):
    save_to_s3: Optional[SaveToS3Config] = None
    update_db: Optional[UpdateDBConfig] = None


# =========================================================
# HITL
# =========================================================

class RequiredHITLConfig(SafeBaseModel):
    is_enable: bool = False


# =========================================================
# EMAIL OUTPUT
# =========================================================

class MarkdownTableConfig(SafeBaseModel):
    all_dataframes: bool = False
    selected_dataframes: List[str] = Field(default_factory=list)


class AttachmentTableConfig(SafeBaseModel):
    all_dataframes: bool = False
    all_dataframes_in_one_file: bool = False
    selected_dataframes: List[str] = Field(default_factory=list)
    attachment_format: Optional[str] = "xlsx"


class SingleModeEmailConfig(SafeBaseModel):
    to: List[str] = Field(default_factory=list)
    cc: List[str] = Field(default_factory=list)
    bcc: List[str] = Field(default_factory=list)

    subject: Optional[str] = None

    body_context: Optional[str] = None
    llm_required: bool = False

    table_as_markdown: Optional[MarkdownTableConfig] = None
    table_as_attachment: Optional[AttachmentTableConfig] = None

class MultiModeEmailConfig(SafeBaseModel):

    subject_template: Optional[str] = None

    body_context: Optional[str] = None
    llm_required: bool = False

    table_as_markdown: Optional[MarkdownTableConfig] = None
    table_as_attachment: Optional[AttachmentTableConfig] = None

class SingleModeDistribution(SafeBaseModel):
    enabled: bool = False
    email: Optional[SingleModeEmailConfig] = None


class GroupByConfig(SafeBaseModel):
    column: Optional[str] = None


class RecipientMapping(SafeBaseModel):
    to: List[str] = Field(default_factory=list)
    cc: List[str] = Field(default_factory=list)


class MultiModeDistribution(SafeBaseModel):
    enabled: bool = False
    group_by: Optional[GroupByConfig] = None
    recipient_mapping: Dict[str, RecipientMapping] = Field(default_factory=dict)
    email: Optional[MultiModeEmailConfig] = None


class DistributionConfig(SafeBaseModel):
    single_mode: Optional[SingleModeDistribution] = None
    multi_mode: Optional[MultiModeDistribution] = None


class SendEmailConfig(SafeBaseModel):
    is_enable: bool = False
    distribution: Optional[DistributionConfig] = None


# =========================================================
# ROOT JOB STEP CONFIG
# =========================================================

class JobSteps(SafeBaseModel):
    receive_email: Optional[ReceiveEmailStep] = None
    decision_point: Optional[DecisionPoint] = None
    s3_postgre_input_tables: Optional[S3PostgreInputTables] = None
    post_processing: Optional[PostProcessingConfig] = None
    output_handling: Optional[OutputHandlingConfig] = None
    required_hitl: Optional[RequiredHITLConfig] = None
    send_email: Optional[SendEmailConfig] = None


# =========================================================
# META DATA
# =========================================================

class MetaData(SafeBaseModel):
    job_id: str
    job_name: str
    job_description: str
    job_category: str
    job_type: JobTypeLiteral
    job_trigger_point: TriggerPointLiteral
    job_owner: List[str] = Field(min_length=1)
    current_status: Optional[str] = "CREATED"
    schedule_run_times: List[time] = Field(default_factory=list)
    days_of_week: List[DaysLiteral] = Field(default_factory=list)
    timezone: Optional[TimezoneLiteral] = "Asia/Kolkata"
    is_active: bool = True
    view_to_all: bool = True
    linked_tables: List[str] = Field(default_factory=list)


# =========================================================
# ROOT CONFIG
# =========================================================

class JobConfig(SafeBaseModel):
    meta_data: Optional[MetaData]
    job_steps: Optional[JobSteps] = None