import pandas as pd
import duckdb
import fnmatch
import re
from typing import Dict, List, Any


class PostProcessingEngine:

    def __init__(self):
        self.context: Dict[str, pd.DataFrame] = {}

    # -----------------------------
    # PUBLIC METHODS
    # -----------------------------
    def load_inputs(self, inputs: Dict[str, pd.DataFrame]):
        self.context.update(inputs)

    def execute(self, steps: List[Dict[str, Any]]) -> Dict[str, pd.DataFrame]:
        con = duckdb.connect()

        try:
            for step in steps:
                self._validate_step(step)

                step_type = step["type"]

                if step_type == "sql":
                    self._run_sql_step(step, con)

                elif step_type == "split":
                    self._run_split_step(step)

                elif step_type == "pandas":
                    self._run_pandas_step(step)

                else:
                    raise ValueError(f"Unsupported step type: {step_type}")

            return dict(self.context)

        finally:
            con.close()
            self.context.clear()   # important cleanup

    # -----------------------------
    # STEP EXECUTORS
    # -----------------------------
    def _run_sql_step(self, step: Dict[str, Any], con):
        input_tables = step.get("input_tables", [])
        query = step["query"]

        self._validate_sql(query)

        # Register only required tables
        for table in input_tables:
            if table not in self.context:
                raise ValueError(f"Table '{table}' not found in context")
            con.register(table, self.context[table])

        result = con.execute(query).df()

        # Handle multi-output
        if "multiple_output" in step:
            self._handle_multiple_output(step, result)
        else:
            self.context[step["output"]] = result

    def _run_split_step(self, step: Dict[str, Any]):
        df = self.context.get(step["input"])

        if df is None:
            raise ValueError(f"Input '{step['input']}' not found")

        column = step["column"]
        prefix = step["output_prefix"]

        if column not in df.columns:
            raise ValueError(f"Column '{column}' not found")

        unique_vals = df[column].dropna().unique()

        if len(unique_vals) > 50:
            raise ValueError("Too many unique values to split")

        for val in unique_vals:
            safe_val = self._sanitize(val)
            self.context[f"{prefix}{safe_val}"] = df[df[column] == val]

    def _run_pandas_step(self, step: Dict[str, Any]):
        pattern = step.get("input_pattern")
        operation = step["operation"]
        prefix = step.get("output_prefix", "")

        if not pattern:
            raise ValueError("input_pattern required for pandas step")

        matched = False

        for key, df in list(self.context.items()):
            if fnmatch.fnmatch(key, pattern):
                matched = True
                result = self._apply_pandas_operation(df.copy(), operation, step)
                self.context[f"{prefix}{key}"] = result

        if not matched:
            raise ValueError(f"No dataframe matched pattern '{pattern}'")

    # -----------------------------
    # PANDAS OPERATIONS
    # -----------------------------
    def _apply_pandas_operation(self, df: pd.DataFrame, operation: str, step: Dict[str, Any]):
        params = step.get("params", {})

        if operation == "transpose":
            return df.T.reset_index()

        elif operation == "filter":
            return df.query(params["condition"])

        elif operation == "add_column":
            df[params["column_name"]] = df.eval(params["expression"])
            return df

        else:
            raise ValueError(f"Unsupported pandas operation: {operation}")

    # -----------------------------
    # MULTI OUTPUT HANDLING
    # -----------------------------
    def _handle_multiple_output(self, step: Dict[str, Any], df: pd.DataFrame):
        config = step["multiple_output"]

        column = config["column"]
        prefix = config["prefix"]

        if column not in df.columns:
            raise ValueError(f"Column '{column}' not found for multi-output")

        unique_vals = df[column].dropna().unique()

        if len(unique_vals) > 50:
            raise ValueError("Too many partitions")

        for val in unique_vals:
            safe_val = self._sanitize(val)
            self.context[f"{prefix}{safe_val}"] = df[df[column] == val]

    # -----------------------------
    # VALIDATION
    # -----------------------------
    def _validate_step(self, step: Dict[str, Any]):
        if "type" not in step:
            raise ValueError("Step must have 'type'")

        if step["type"] == "sql":
            if "query" not in step:
                raise ValueError("SQL step requires 'query'")

        if step["type"] == "split":
            required = ["input", "column", "output_prefix"]
            for r in required:
                if r not in step:
                    raise ValueError(f"Split step missing '{r}'")

    def _validate_sql(self, query: str):
        forbidden = ["DROP", "DELETE", "INSTALL", "COPY"]

        upper_query = query.upper()

        for word in forbidden:
            if word in upper_query:
                raise ValueError(f"Unsafe SQL detected: {word}")

    # -----------------------------
    # UTILS
    # -----------------------------
    def _sanitize(self, value: Any) -> str:
        return re.sub(r"\W+", "_", str(value))