# services/data_operation_engine.py

import duckdb
import pandas as pd

def _simple_transpose_clean(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()

    # Step 1: transpose
    df_out = df.T

    # Step 2: first row → header
    df_out.columns = df_out.iloc[0]

    # Step 3: drop header row
    df_out = df_out.iloc[1:]

    # Step 4: reset index
    df_out = df_out.reset_index()

    # Step 5: dynamic rename (NO hardcoding)
    first_col_name = df.columns[0] if len(df.columns) > 0 else "column"
    df_out.rename(columns={df_out.columns[0]: first_col_name}, inplace=True)

    return df_out

class DataOperationEngine:

    def __init__(self):
        # In-memory DB (fast + isolated per execution)
        self.conn = duckdb.connect(database=":memory:")
        self.tables = {}       # active tables
        self.table_meta = {}   # metadata tracking

    # =====================================================
    # REGISTER INITIAL TABLES
    # =====================================================
    def register_tables(self, dfs: dict):
        for name, df in dfs.items():

            if not isinstance(df, pd.DataFrame):
                continue

            self._safe_register(name, df)

    # =====================================================
    # SAFE REGISTER (overwrite-safe)
    # =====================================================
    def _safe_register(self, name: str, df: pd.DataFrame):
        try:
            self.conn.unregister(name)
        except Exception:
            pass

        self.conn.register(name, df)
        self.tables[name] = df

        self.table_meta[name] = {
            "rows": len(df),
            "cols": len(df.columns)
        }

    # =====================================================
    # VALIDATION
    # =====================================================
    def _validate_inputs(self, input_tables):
        missing = [t for t in input_tables if t not in self.tables]
        if missing:
            raise ValueError(f"Missing input tables: {missing}")

    # =====================================================
    # SQL EXECUTION
    # =====================================================
    def execute_sql(self, step: dict):
        input_tables = step.get("input_tables", [])
        query = step.get("query")
        output = step.get("output")
        persist = step.get("persist", True)

        self._validate_inputs(input_tables)

        # print(f"\n[SQL STEP] -> {output}")

        try:
            # Execute SQL in DuckDB
            df = self.conn.execute(query).df()

        except Exception as e:
            raise RuntimeError(f"SQL failed for step {output}: {str(e)}")

        # print(f"[SQL RESULT] {output}: rows={len(df)}, cols={len(df.columns)}")

        # Register output
        self._safe_register(output, df)

        # Cleanup inputs if not needed
        self._cleanup_inputs(input_tables, persist)

    # =====================================================
    # PANDAS OPERATIONS
    # =====================================================
    def execute_pandas(self, step: dict):
        operation = step.get("operation")
        input_tables = step.get("input_tables", [])
        output_tables = step.get("output_tables", [])
        persist = step.get("persist", True)

        self._validate_inputs(input_tables)

        # print(f"\n[PANDAS STEP] -> {operation}")

        # -------------------------------------------------
        # TRANSPOSE
        # -------------------------------------------------
        if operation == "transpose":

            pivot_column = step.get("pivot_column")

            if len(input_tables) != len(output_tables):
                raise ValueError(
                    "transpose requires equal input_tables and output_tables"
                )

            for inp, out in zip(input_tables, output_tables):

                df = self.tables[inp]

                df_out = _simple_transpose_clean(df)

                # print(f"[PANDAS RESULT] {out}: rows={len(df_out)}, cols={len(df_out.columns)}")

                self._safe_register(out, df_out)

        # if operation == "transpose":

        #     if len(input_tables) != len(output_tables):
        #         raise ValueError(
        #             "transpose requires equal input_tables and output_tables"
        #         )

        #     for inp, out in zip(input_tables, output_tables):

        #         df = self.tables[inp]

        #         if df.empty:
        #             df_out = pd.DataFrame()
        #         else:
        #             df_out = df.T

        #             # set first row as header
        #             df_out.columns = df_out.iloc[0]
        #             df_out = df_out[1:]

        #             # reset index properly
        #             df_out.index.name = "metric"
        #             df_out = df_out.reset_index()

        #         print(f"[PANDAS RESULT] {out}: rows={len(df_out)}, cols={len(df_out.columns)}")

        #         self._safe_register(out, df_out)

        else:
            raise ValueError(f"Unsupported pandas operation: {operation}")

        # Cleanup inputs if not needed
        self._cleanup_inputs(input_tables, persist)

    # =====================================================
    # MEMORY CLEANUP (STEP LEVEL)
    # =====================================================
    def _cleanup_inputs(self, input_tables, persist: bool):
        """
        Drop input tables after use if persist=False
        """
        if persist:
            return

        for t in input_tables:
            if t in self.tables:
                try:
                    self.conn.unregister(t)
                except Exception:
                    pass

                del self.tables[t]
                self.table_meta.pop(t, None)

                print(f"[CLEANUP] Dropped table: {t}")

    # =====================================================
    # FULL CLEANUP (CRITICAL)
    # =====================================================
    def cleanup_all(self):
        print("\n[CLEANUP] Releasing all tables and closing connection")

        for t in list(self.tables.keys()):
            try:
                self.conn.unregister(t)
            except Exception:
                pass

        self.tables.clear()
        self.table_meta.clear()

        try:
            self.conn.close()
        except Exception:
            pass

        print("[CLEANUP] Done")

    # =====================================================
    # STEP EXECUTION ENGINE
    # =====================================================
    def run_steps(self, steps: list):

        for step in steps:

            step_type = step.get("type")

            if step_type == "sql":
                self.execute_sql(step)

            elif step_type == "pandas":
                self.execute_pandas(step)

            else:
                raise ValueError(f"Unsupported step type: {step_type}")

        return self.tables

    # =====================================================
    # PUBLIC PROCESS METHOD (SAFE)
    # =====================================================
    def process(self, dfs: dict, steps: list):

        try:
            print("\n[ENGINE] Registering initial tables...")
            self.register_tables(dfs)

            print("[ENGINE] Running steps...")
            result_tables = self.run_steps(steps)

            # IMPORTANT: Copy results BEFORE cleanup
            final_output = {
                k: v.copy() for k, v in result_tables.items()
            }

            print("\n[ENGINE] Completed")

            return final_output

        except Exception as e:
            print(f"\n[ENGINE ERROR] {str(e)}")
            raise

        finally:
            # ALWAYS CLEANUP (success OR failure)
            self.cleanup_all()