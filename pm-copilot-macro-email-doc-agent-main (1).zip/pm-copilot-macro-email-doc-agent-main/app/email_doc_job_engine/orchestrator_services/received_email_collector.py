# services/received_mail_collector.py

import json
import pprint
import re
from typing import Dict, Any
from asyncpg import Connection


# =========================================================
# KEYWORD EXTRACTION (CORE FIX)
# =========================================================
def extract_keywords(template: str):
    """
    Extract meaningful keywords from template
    Removes {{variables}} and symbols
    """
    if not template:
        return []

    # remove {{variables}}
    temp = re.sub(r"\{\{.*?\}\}", " ", template)

    # keep only words
    words = re.findall(r"[a-zA-Z0-9]+", temp)

    # lowercase + unique
    keywords = list(set(w.lower() for w in words if len(w) > 2))

    return keywords


# =========================================================
# REGEX (ONLY FOR FIELD EXTRACTION)
# =========================================================
def template_to_regex(template: str) -> str:
    pattern = re.escape(template)

    pattern = re.sub(r"\\\{\\\{.*?\\\}\\\}", r"(.+?)", pattern)
    pattern = pattern.replace(r"\,", r"\s*,\s*")
    pattern = pattern.replace(r"\ ", r"\s+")

    return f"^{pattern}$"


# =========================================================
# ATTACHMENT NORMALIZATION
# =========================================================
def normalize_attachments(raw):
    if not raw:
        return []

    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except Exception:
            return []

    if not isinstance(raw, list):
        return []

    cleaned = []

    for item in raw:
        if isinstance(item, str):
            try:
                item = json.loads(item)
            except Exception:
                continue

        if isinstance(item, dict):
            cleaned.append(item)

    return cleaned


# =========================================================
# EXTRACT SUBJECT VARIABLES
# =========================================================
def extract_subject_fields(subject: str, template: str) -> Dict[str, Any]:
    regex = template_to_regex(template)
    match = re.match(regex, subject)

    if not match:
        print("\nSubject did NOT match template (regex extraction failed)")
        return {}

    keys = re.findall(r"\{\{(.*?)\}\}", template)
    extracted = dict(zip(keys, match.groups()))

    # print("\nExtracted Subject Variables:")
    # pprint.pprint(extracted)

    return extracted


# =========================================================
# MAIN FUNCTION (FETCH EMAIL)
# =========================================================
async def fetch_matching_email(
    db: Connection,
    subject_template: str,
    execution_id: str,
) -> Dict[str, Any]:

    keywords = extract_keywords(subject_template)

    query = """
    SELECT
        id,
        email_from,
        to_list,
        cc_list,
        subject,
        body,
        received_time,
        attachments,
        created_at
    FROM macro_email_doc_agent.email_received_tracker
    ORDER BY created_at DESC
    LIMIT 1;
    """

    rows = await db.fetch(query)
    
    for row in rows:
        subject = row["subject"] or ""
        subject_lower = subject.lower()

        # -----------------------------------
        # KEYWORD MATCHING (CORE LOGIC)
        # -----------------------------------
        if all(keyword in subject_lower for keyword in keywords):

            attachments = normalize_attachments(row["attachments"])
            extracted_fields = extract_subject_fields(
                subject,
                subject_template
            )

            return {
                "body": row["body"],
                "attachments": attachments,
                "metadata": dict(row),
                "extracted_subject_fields": extracted_fields
            }

    raise ValueError("No matching email found using keyword matching")