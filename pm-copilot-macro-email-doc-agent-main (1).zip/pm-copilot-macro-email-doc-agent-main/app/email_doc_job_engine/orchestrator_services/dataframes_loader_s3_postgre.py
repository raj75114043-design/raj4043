import pandas as pd
import re

import json
import mimetypes

from io import BytesIO, StringIO
from bs4 import BeautifulSoup
from datetime import datetime
from app.services.azure_doc_parsing import DocumentService
from app.services.s3_blob_management import S3Service
from asyncpg import Connection

from app.email_doc_job_engine.utils.execution_store import update_execution

from app.email_doc_job_engine.utils.safe_loader import safe_get


# def validate_unstructured_output(fields, output: dict, file_name: str):
#     expected_cols = {f["name"] for f in fields}
#     actual_cols = set(output.keys())

#     missing = expected_cols - actual_cols
#     extra = actual_cols - expected_cols

#     if missing:
#         raise ValueError(
#             f"[{file_name}] Missing fields in extraction: {missing}"
#         )

#     if extra:
#         raise ValueError(
#             f"[{file_name}] Unexpected fields in extraction: {extra}"
#         )


def validate_unstructured_output(fields, output, file_name: str):

    expected_cols = {f["name"] for f in fields}

    # ==========================================
    # MULTI ROW SUPPORT
    # ==========================================
    if isinstance(output, list):

        for idx, row in enumerate(output):

            if not isinstance(row, dict):
                raise ValueError(
                    f"[{file_name}] Row {idx} is not a valid object"
                )

            actual_cols = set(row.keys())

            missing = expected_cols - actual_cols
            extra = actual_cols - expected_cols

            if missing:
                raise ValueError(
                    f"[{file_name}] Row {idx} missing fields: {missing}"
                )

            if extra:
                raise ValueError(
                    f"[{file_name}] Row {idx} unexpected fields: {extra}"
                )

        return

    # ==========================================
    # SINGLE ROW SUPPORT
    # ==========================================
    if isinstance(output, dict):

        actual_cols = set(output.keys())

        missing = expected_cols - actual_cols
        extra = actual_cols - expected_cols

        if missing:
            raise ValueError(
                f"[{file_name}] Missing fields in extraction: {missing}"
            )

        if extra:
            raise ValueError(
                f"[{file_name}] Unexpected fields in extraction: {extra}"
            )

        return

    # ==========================================
    # INVALID FORMAT
    # ==========================================
    raise ValueError(
        f"[{file_name}] Output must be dict or list[dict]"
    )

def template_to_regex(template: str) -> str:
    """
    Convert template base to regex
    Example:
    RIOT_{{site_code}}_{{date}} → ^RIOT_.+?_.+?$
    """
    if not template:
        return ".*"

    pattern = re.escape(template)

    # replace {{var}} → non-greedy wildcard
    pattern = re.sub(r"\\{\\{.*?\\}\\}", r".+?", pattern)

    return f"^{pattern}$"


def split_name_and_ext(name: str):
    if "." in name:
        return name.rsplit(".", 1)
    return name, ""


def match_template_unstructured(s3_key: str, template: str, file_type: str) -> bool:
    """
    Match:
    - filename (from s3_key) with template
    - extension with file_type
    """

    if not s3_key or not template:
        return False

    full_file_name = s3_key.split("/")[-1]
    actual_base, actual_ext = split_name_and_ext(full_file_name)
    template_base, template_ext = split_name_and_ext(template)
    expected_ext = (file_type or template_ext).lower()
    actual_ext = actual_ext.lower()

    if expected_ext and actual_ext != expected_ext:
        return False

    pattern = template_to_regex(template_base)

    return re.match(pattern, actual_base) is not None


def cast_column(df, fields):
    """
    Apply schema-based type casting
    """
    for f in fields:
        col = f.get("name")
        dtype = f.get("type")

        if col not in df.columns:
            continue

        try:
            if dtype == "int":
                df[col] = pd.to_numeric(df[col], errors="coerce").astype("Int64")

            elif dtype == "float":
                df[col] = pd.to_numeric(df[col], errors="coerce")

            else:
                df[col] = df[col].astype(str)

        except Exception:
            pass

    return df



# =========================================================
# GET CONTENT TYPE
# =========================================================
def get_content_type(file_ext: str):

    if not file_ext:
        return "application/octet-stream"

    file_ext = file_ext.lower()

    extension_map = {

        # images
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "png": "image/png",

        # docs
        "pdf": "application/pdf"
    }

    return extension_map.get(
        file_ext,
        mimetypes.guess_type(f"dummy.{file_ext}")[0]
        or "application/octet-stream"
    )



async def load_dataframes_from_s3_postgre(
    db: Connection,
    s3_service: S3Service,
    azure_service: DocumentService,
    s3_postgre_input_info: dict,
    execution_id: str,
):
    dfs = {}

    # print("s3_postgre config: ", s3_cfg)

    if not s3_postgre_input_info:
        return dfs

    # s3_cfg = s3_postgre_input_info.get("s3_blob_storage", {})
    s3_cfg = safe_get(s3_postgre_input_info, "s3_blob_storage", default={})


    # -----------------------------------------------------
    # S3 STRUCTURED FILES
    # -----------------------------------------------------
    # if s3_cfg.get("structured", {}).get("is_required", False):
    if safe_get(s3_cfg, "structured", "is_required", default=False):

        # await update_execution(
        #     execution_id=execution_id,
        #     log_step="LOADING FILES FROM S3 STRUCTURED INPUT",
        #     log_message=f"s3 Structured Files Loading Started..."
        # )


        # structured_files = s3_cfg.get("structured", {}).get("selected_files", [])
        structured_files = safe_get(s3_cfg, "structured", "selected_files", default=[])

        for file_cfg in structured_files:

            bucket = file_cfg.get("s3_bucket_name")
            s3_key = file_cfg.get("s3_key")
            folder = file_cfg.get("s3_folder")
            template = file_cfg.get("file_name_template", "")
            pick_strategy = (file_cfg.get("pick_strategy") or "latest").lower()
            file_type = file_cfg.get("file_type", "")
            sheets = file_cfg.get("sheets", [])

            selected_files = []

            # =================================================
            # CASE 1: DIRECT KEY
            # =================================================
            if s3_key:
                selected_files = [{"key": s3_key}]

            # =================================================
            # CASE 2: FROM FOLDER
            # =================================================
            elif folder:

                files = await s3_service.list_files(bucket, folder)
                if not files:
                    continue

                # -------------------------
                # STEP 1: TEMPLATE FILTER (OPTIONAL)
                # -------------------------
                if template:
                    files = [
                        f for f in files
                        if match_template_unstructured(f["key"], template, file_type)
                    ]

                    if not files:
                        continue

                # -------------------------
                # STEP 2: PICK STRATEGY
                # -------------------------
                if pick_strategy == "latest":

                    selected_files = [sorted(
                        files,
                        key=lambda x: x["last_modified"],
                        reverse=True
                    )[0]]

                elif pick_strategy == "current_date":

                    from datetime import datetime
                    today = datetime.now().date()

                    today_files = [
                        f for f in files
                        if f["last_modified"].date() == today
                    ]

                    if not today_files:
                        # execution_log_steps.append({"s3 Structured Files - No files available for Today's Date!"})
                        
                        continue

                    # MULTIPLE FILES CASE
                    selected_files = today_files

                else:
                    continue

            # =================================================
            # STEP 3: PROCESS FILE(S)
            # =================================================
            for f in selected_files:

                key = f["key"]
                file_bytes = await s3_service.get_file_bytes(bucket, key)
                buffer = BytesIO(file_bytes)

                # -------------------------
                # CSV
                # -------------------------
                if key.endswith(".csv"):

                    sheet_cfg = sheets[0] if sheets else {}
                    fields = sheet_cfg.get("fields", [])
                    output_name = sheet_cfg.get("output_table_name")

                    if not output_name:
                        continue

                    # -----------------------------------------
                    # STARTING ROW SUPPORT
                    # -----------------------------------------
                    # starting_row = sheet_cfg.get("starting_row", 1)
                    starting_row = safe_get(sheet_cfg, "starting_row", default=1)
                    skiprows = max(starting_row - 1, 0)
                    
                    # -----------------------------------------
                    # DTYPE MAP
                    # -----------------------------------------
                    dtype_map = {
                        f["name"]: "string"
                        for f in fields
                        if f.get("type") == "string"
                    } if fields else None

                    # -----------------------------------------
                    # READ CSV
                    # -----------------------------------------
                    df = pd.read_csv(
                        buffer,
                        dtype=dtype_map,
                        low_memory=False,
                        skiprows=skiprows
                    )

                    if fields:
                        cols = [f["name"] for f in fields]
                        df = df[[c for c in df.columns if c in cols]]
                        df = df.reindex(columns=cols)
                        df = cast_column(df, fields)

                    # -----------------------------------------
                    # MULTI FILE MERGE SUPPORT
                    # -----------------------------------------
                    if output_name in dfs:
                        dfs[output_name] = pd.concat(
                            [dfs[output_name], df],
                            ignore_index=True
                        )
                    else:
                        dfs[output_name] = df


                # -------------------------
                # EXCEL
                # -------------------------
                elif key.endswith(".xlsx"):

                    excel = pd.ExcelFile(buffer)

                    for sheet_cfg in sheets:

                        sheet_name = sheet_cfg.get("sheet_name")
                        fields = sheet_cfg.get("fields", [])
                        output_name = sheet_cfg.get("output_table_name")

                        if not output_name:
                            continue

                        # -----------------------------------------
                        # STARTING ROW SUPPORT
                        # -----------------------------------------
                        # starting_row = sheet_cfg.get("starting_row", 1)
                        starting_row = safe_get(sheet_cfg, "starting_row", default=1)
                        skiprows = max(starting_row - 1, 0)

                        # -----------------------------------------
                        # DTYPE MAP
                        # -----------------------------------------
                        dtype_map = {
                            f["name"]: "string"
                            for f in fields
                            if f.get("type") == "string"
                        } if fields else None


                        # -----------------------------------------
                        # READ SHEET
                        # -----------------------------------------
                        if sheet_name:

                            if sheet_name not in excel.sheet_names:
                                continue

                            df = excel.parse(
                                sheet_name,
                                skiprows=skiprows,
                                dtype=dtype_map
                            )

                        else:
                            # fallback: first sheet
                            df = excel.parse(
                                excel.sheet_names[0],
                                skiprows=skiprows,
                                dtype=dtype_map
                            )


                        if not sheet_cfg.get("all_fields", True):
                            allowed_cols = [f["name"] for f in fields]
                            df = df[[c for c in allowed_cols if c in df.columns]]
                            df = df.reindex(columns=allowed_cols)

                        df = cast_column(df, fields)

                        # -----------------------------------------
                        # MULTI FILE MERGE SUPPORT
                        # -----------------------------------------
                        if output_name in dfs:

                            dfs[output_name] = pd.concat(
                                [dfs[output_name], df],
                                ignore_index=True
                            )

                        else:
                            dfs[output_name] = df


    # -----------------------------------------------------
    # S3 UNSTRUCTURED FILES (FINAL VERSION)
    # -----------------------------------------------------
    # if s3_cfg.get("unstructured", {}).get("is_required", False):
    if safe_get(s3_cfg, "unstructured", "is_required", default=False):

        # unstructured_files = s3_cfg.get("unstructured", {}).get("selected_files", [])
        unstructured_files = safe_get(s3_cfg, "unstructured", "selected_files", default=[])

        for file_cfg in unstructured_files:

            bucket = file_cfg.get("s3_bucket_name")
            s3_key = file_cfg.get("s3_key")
            folder = file_cfg.get("s3_folder")
            template = file_cfg.get("file_name_template", "")
            pick_strategy = (file_cfg.get("pick_strategy") or "latest").lower()
            fields = file_cfg.get("fields", [])
            output_name = file_cfg.get("output_table_name")

            selected_files = []

            # =================================================
            # CASE 1: DIRECT KEY
            # =================================================
            if s3_key:
                selected_files = [{"key": s3_key}]

            # =================================================
            # CASE 2: FROM FOLDER
            # =================================================

            elif folder:

                files = await s3_service.list_files(bucket, folder)


                if not files:
                    continue

                # =================================================
                # KEEP ONLY ACTUAL FILES
                # (ignore folder placeholders)
                # =================================================
                files = [
                    f for f in files
                    if not f["key"].endswith("/")
                ]

                if not files:

                    continue

                # -------------------------
                # Normalize helper
                # -------------------------
                def normalize(s):
                    return re.sub(r"\s+", "", str(s)).lower()

                def match_template_unstructured(file_name, template):

                    if not template:
                        return True

                    normalized_file = normalize(file_name)

                    # =================================================
                    # SIMPLE KEYWORD MODE
                    # no placeholders -> contains match
                    # =================================================
                    if "{{" not in template and "}}" not in template:

                        return normalize(template) in normalized_file

                    # =================================================
                    # TEMPLATE MODE
                    # =================================================

                    pattern = re.escape(template)

                    # Replace {{var}} with regex wildcard
                    pattern = re.sub(
                        r"\\\{\\\{.*?\\\}\\\}",
                        r".*?",
                        pattern
                    )

                    # allow partial match anywhere
                    pattern = f".*{pattern}.*"

                    return re.match(
                        pattern,
                        file_name,
                        re.IGNORECASE
                    ) is not None

                # =================================================
                # EXTRACT FOLDER HIERARCHY
                # =================================================
                def extract_folder_levels(file_key, root_folder):

                    """
                    Example:

                    root_folder = "input"

                    file_key =
                    input/siteA/2026/may/report.pdf

                    returns:
                    {
                        "folder_level_1": "siteA",
                        "folder_level_2": "2026",
                        "folder_level_3": "may"
                    }
                    """

                    # remove root folder prefix
                    relative_path = file_key[len(root_folder):].lstrip("/")

                    # split path
                    parts = relative_path.split("/")

                    # last item is filename
                    folder_parts = parts[:-1]

                    folder_data = {}

                    for idx, part in enumerate(folder_parts, start=1):
                        folder_data[f"folder_level_{idx}"] = part

                    return folder_data

                # -------------------------
                # STEP 1: Template filter
                # -------------------------
                if template:

                    files = [
                        f for f in files
                        if match_template_unstructured(
                            f["key"].split("/")[-1],
                            template
                        )
                    ]

                    if not files:

                        continue

                # -------------------------
                # STEP 2: Strategy
                # -------------------------

                if pick_strategy == "latest":

                    selected_files = [sorted(
                        files,
                        key=lambda x: x["last_modified"],
                        reverse=True
                    )[0]]

                elif pick_strategy == "current_date":

                    from datetime import datetime
                    today = datetime.now().date()


                    today_files = [
                        f for f in files
                        if f["last_modified"].date() == today
                    ]

                    if not today_files:
                        continue

                    selected_files = today_files


                elif pick_strategy == "all":
                    selected_files = files
                    
                else:

                    continue

            # =================================================
            # STEP 3: PROCESS FILE(S)
            # =================================================

            combined_rows = []

            # for f in selected_files:
            print("\nSelected Unstructured Files: ", len(selected_files))
            # print(type(selected_files))
            # print(selected_files)
                
            for f in selected_files:

                key = f["key"]
                file_bytes = await s3_service.get_file_bytes(bucket, key)


                # =================================================
                # DETECT FILE TYPE
                # =================================================
                file_type = key.split(".")[-1].lower()

                allowed_extensions = {"png", "jpg", "jpeg", "pdf"}

                if file_type not in allowed_extensions:
                    print(
                        f"Skipping unsupported file type: "
                        f"{file_type} for file: {s3_key}"
                    )
                    continue

                content_type = get_content_type(file_type)

                structured = await azure_service.extract_fields(
                    file_bytes=file_bytes,
                    content_type=content_type,
                    fields=fields,
                    model="prebuilt-layout",
                    parsing_context=file_cfg.get("parsing_context")
                )
                print(">>>>>>>>>>>>>> Exract Fields using Azure & LLM : Done")
                # print(type(structured))
                # print(structured)


                # validate
                validate_unstructured_output(fields, structured, key)

                rows = structured if isinstance(structured, list) else [structured]
                # print("rows", rows)

                for row in rows:
                    # =================================================
                    # ADD METADATA
                    # =================================================
                    row["file_name"] = key.split("/")[-1]
                    row["file_type"] = file_type
                    row["file_s3_key"] = key
                    row["file_s3_bucket"] = bucket

                    # ONLY when available
                    if f.get("last_modified"):
                        row["s3_files_modified_data"] = (
                            f["last_modified"].isoformat()
                        )


                    # =================================================
                    # ADD FOLDER HIERARCHY
                    # =================================================
                    if folder:

                        folder_levels = extract_folder_levels(
                            file_key=key,
                            root_folder=folder
                        )

                        row.update(folder_levels)

                    combined_rows.append(row)

            # =================================================
            # STEP 4: FINAL DF
            # =================================================
            if combined_rows:
                dfs[output_name] = pd.DataFrame(combined_rows)


    # =====================================================
    # 2. POSTGRES TABLES
    # =====================================================
    # postgre_confg = s3_postgre_input_info.get("postgre_db", {})
    postgre_confg = safe_get(s3_postgre_input_info, "postgre_db", default={})

    # if postgre_confg.get("is_required", False):
    if safe_get(postgre_confg, "is_required", default=False):


        # pg_tables = postgre_confg.get("tables", [])
        pg_tables = safe_get(postgre_confg, "tables", default=[])

        
        for table_cfg in pg_tables:

            table_name = table_cfg.get("table_name")
            schema = table_cfg.get("schema", "macro_email_doc_agent")
            output_name = table_cfg.get("output_table_name")

            if not table_name or not output_name:
                continue

            # ============================================
            # BUILD COLUMN LIST
            # ===========================================

            if table_cfg.get("required_all_columns", True):

                select_clause = "*"

            else:

                selected_cols = table_cfg.get("selected_columns", [])

                if not selected_cols:
                    continue

                select_clause = ", ".join(
                    [f'"{col}"' for col in selected_cols]
                )

            # ============================================
            # QUERY
            # ============================================

            query = f'''
                SELECT {select_clause}
                FROM "{schema}"."{table_name}"
            '''

            rows = await db.fetch(query)

            if not rows:
                continue

            dfs[output_name] = pd.DataFrame([dict(r) for r in rows])

    return dfs