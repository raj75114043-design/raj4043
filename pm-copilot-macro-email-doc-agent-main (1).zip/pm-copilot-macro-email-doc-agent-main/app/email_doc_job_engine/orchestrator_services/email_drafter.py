import asyncio
import base64
import pandas as pd
import asyncio
import re
from asyncpg import Connection

from io import BytesIO
from typing import Dict

from app.services.send_email_gateway import (
    get_session_id,
    send_email_via_gateway,
)

from app.core.llm_client import get_llm_client
from app.email_doc_job_engine.orchestrator_services.backend_table_updation import insert_email_send_tracker

from app.email_doc_job_engine.utils.safe_loader import safe_get
from app.utils.timezone import get_datetime_now_without_zone

# =====================================================
# HELPERS FOR MULTI MAIL
# =====================================================

def resolve_recipient(value: str, recipient_map: dict):
    """
    Smart match:
    - exact match first
    - then partial match (both ways)
    - fallback to 'others'
    """

    val_norm = normalize(value)

    # 1. Exact match
    if val_norm in recipient_map:
        return recipient_map[val_norm]

    # 2. Partial match (very important)
    for key, cfg in recipient_map.items():
        if key == "others":
            continue

        if val_norm in key or key in val_norm:
            return cfg

    # 3. Fallback
    return recipient_map.get("others", {})


def normalize(text: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(text).lower())

def normalize_value_loose(text: str) -> str:
    text = str(text).lower()

    # remove special chars
    text = re.sub(r"[^a-z0-9\s]", "", text)

    # take only first word (VERY IMPORTANT)
    return text.split()[0] if text else ""

def find_matching_column(df: pd.DataFrame, target: str):
    target_norm = normalize(target)

    for col in df.columns:
        if target_norm in normalize(col):
            return col

    return None


def normalize_mapping(mapping: dict):
    return {normalize(k): v for k, v in mapping.items()}


# =====================================================
# HELPERS
# =====================================================
def df_to_html(df: pd.DataFrame) -> str:
    if df is None or df.empty:
        return "<p>No data available</p>"

    # # Header
    # header_html = "".join([
    #     f'<th style="background-color:#124191;color:white;padding:8px;border:1px solid #ddd;text-align:center;">{col}</th>'
    #     for col in df.columns
    # ])

    header_html = "".join([
        f'<th style="background-color:#124191;color:white;padding:8px;border:1px solid #ddd;text-align:center;">'
        f'{col.replace("_", " ").title()}'
        f'</th>'
        for col in df.columns
    ])

    # Rows
    rows_html = ""
    for i, row in enumerate(df.values):
        bg = "#f9f9f9" if i % 2 == 0 else "#ffffff"

        row_html = "".join([
            f'<td style="padding:6px;border:1px solid #ddd;text-align:center;background-color:{bg};">{val}</td>'
            for val in row
        ])

        rows_html += f"<tr>{row_html}</tr>"

    # Final HTML (clean f-string)
    html = f"""
    <div style="font-family: Arial, sans-serif; font-size: 13px;">
        <table style="border-collapse: collapse; width: 100%; margin: 10px 0;">
            <thead>
                <tr>{header_html}</tr>
            </thead>
            <tbody>
                {rows_html}
            </tbody>
        </table>
    </div>
    """

    return html

def df_to_base64_csv(df: pd.DataFrame) -> str:
    return base64.b64encode(
        df.to_csv(index=False).encode("utf-8")
    ).decode("utf-8")


def df_to_base64_xlsx_single(df: pd.DataFrame) -> str:
    buffer = BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="data")
    buffer.seek(0)
    return base64.b64encode(buffer.read()).decode("utf-8")


def df_to_base64_xlsx_multi(tables: Dict[str, pd.DataFrame]) -> str:
    buffer = BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        for name, df in tables.items():
            df.to_excel(writer, index=False, sheet_name=name[:31])
    buffer.seek(0)
    return base64.b64encode(buffer.read()).decode("utf-8")


def filter_tables(tables: Dict[str, pd.DataFrame], cfg: dict) -> Dict[str, pd.DataFrame]:
    if not isinstance(cfg, dict):
        return tables if cfg else {}

    # if cfg.get("all_dataframes", True):
    if safe_get(cfg, "all_dataframes", default=True):  
        return tables

    selected = cfg.get("selected_dataframes", [])
    return {k: v for k, v in tables.items() if k in selected}


def render_template(text: str, context: dict) -> str:
    if not text:
        return text

    for k, v in context.items():
        text = text.replace(f"{{{{{k}}}}}", str(v))
    return text


def format_title(name: str) -> str:
    if not name:
        return ""

    # replace underscores with space
    name = name.replace("_", " ")

    # title case each word
    return name.title()


async def generate_llm_html_email_body(
    body_context: str,
    combined_table_html: str,
    email_fetched_config: dict,
) -> str:

    prompt = f"""
You are an enterprise email formatter.

Generate a professional HTML email body.

Requirements:
- Return ONLY valid HTML
- Use inline CSS only
- Make email visually clean and modern
- Use professional enterprise formatting
- Add proper spacing and padding
- Make tables highly readable
- Make table headers green
- Convert all column names into Sentence Case
- Preserve all table rows and values exactly
- Do not remove any data
- Add alternate row colors
- Keep the email Outlook-friendly

Email Context:
{body_context}

Email Fetched Details: 
{email_fetched_config}

Tables HTML:
{combined_table_html}
"""
    
    llm = get_llm_client("medium")
    llm_response = await llm.ainvoke(prompt)
    html_body = llm_response.content.strip()

    return html_body



async def _send_email(
    db: Connection,
    job_id: str,
    email_cfg: dict,
    tables: Dict[str, pd.DataFrame],
    email_data: Dict = {},
    required_hitl: bool = True
):

    # =====================================================
    # CONFIG
    # =====================================================
    body_context = email_cfg.get("body_context", "")
    llm_required = email_cfg.get("llm_required", False)

    to_list = email_cfg.get("to", [])
    cc_list = email_cfg.get("cc", [])
    bcc_list = email_cfg.get("bcc", [])
    subject = email_cfg.get("subject", "Report")

    body = body_context

    # =====================================================
    # BODY TABLES (HTML)
    # =====================================================
    body_cfg = email_cfg.get("table_as_markdown", {})
    body_tables = filter_tables(tables, body_cfg)

    combined_table_html = ""

    if body_cfg:

        body += "<br><br>"

        for name, df in body_tables.items():

            section_html = f"""
            <div style="margin-bottom:24px;">
                {df_to_html(df)}
            </div>
            """

            combined_table_html += section_html

            # default non-LLM body
            body += section_html

    # =====================================================
    # LLM EMAIL BODY
    # =====================================================

    print("\nLLM Required For Email Body Generation:", llm_required)

    if llm_required:
        body = await generate_llm_html_email_body(
            body_context=body_context,
            combined_table_html=combined_table_html,
            email_fetched_config=email_data.get(
                "extracted_subject_fields",
                {}
            )
        )

    # =====================================================
    # ATTACHMENTS
    # =====================================================
    attachments = []

    attach_cfg = email_cfg.get("table_as_attachment", {})
    attach_tables = filter_tables(tables, attach_cfg)

    attachment_format = attach_cfg.get("attachment_format", "csv")
    single_file = attach_cfg.get("all_dataframes_in_one_file", False)

    if attach_cfg:

        # -------------------------------------------------
        # CSV ATTACHMENTS
        # -------------------------------------------------
        if attachment_format == "csv":

            for name, df in attach_tables.items():

                attachments.append({
                    "filename": f"{name}.csv",
                    "filedata": df_to_base64_csv(df)
                })

        # -------------------------------------------------
        # XLSX ATTACHMENTS
        # -------------------------------------------------
        elif attachment_format == "xlsx":

            # Single combined report
            if single_file:

                attachments.append({
                    "filename": "report.xlsx",
                    "filedata": df_to_base64_xlsx_multi(
                        attach_tables
                    )
                })

            # Separate file per dataframe
            else:

                for name, df in attach_tables.items():

                    attachments.append({
                        "filename": f"{name}.xlsx",
                        "filedata": df_to_base64_xlsx_single(df)
                    })

    # =====================================================
    # DEBUG LOG
    # =====================================================
    print("\nEMAIL COMPOSING DONE =================")
    print("To:", to_list)
    print("Subject:", subject)
    print("Attachments:", len(attachments))

    # =====================================================
    # EMAIL TRACKER ROW
    # =====================================================

    tracker_row = {
        "job_id": job_id,
        "to_list": to_list,
        "cc_list": cc_list,
        "bcc_list": bcc_list,
        "email_subject": subject,
        "email_body": body,
        "attachments": attachments,
        "is_approval_required": required_hitl,
        "mail_status": None
    }

    # =====================================================
    # HITL / APPROVAL FLOW
    # =====================================================
    if required_hitl:

        tracker_row["mail_status"] = "APPROVAL_PENDING"
        tracker_row["remarks"] = "Waiting for approval"
        tracker_row["sent_at"] = None

        await insert_email_send_tracker(
            db=db,
            rows=[tracker_row]
        )

        print("Email Drafted for approval")
        return

    # =====================================================
    # DIRECT SEND FLOW
    # =====================================================
    session_id = await asyncio.to_thread(get_session_id)

    print("Email API Gateway Authenticated Successfully!")

    response = await asyncio.to_thread(
        send_email_via_gateway,
        session_id,
        to_list=to_list,
        cc_list=cc_list,
        bcc_list=bcc_list,
        subject=subject,
        body=body,
        attachments=attachments,
    )


    gateway_status = (
        response.get("result", {})
        .get("status", "")
        if isinstance(response, dict)
        else str(response)
    )

    time_now = get_datetime_now_without_zone()

    gateway_status = (
        response.get("result", {})
        .get("status", "")
    )

    if "Successfully sent" in gateway_status:
        mail_status = "MAIL_SENT"
    else:
        mail_status = "FAILED"

    tracker_row["mail_status"] = mail_status
    tracker_row["sent_at"] = time_now
    tracker_row["remarks"] = gateway_status

    await insert_email_send_tracker(
        db=db,
        rows=[tracker_row]
    )

    print("Email Transaction Done:", response)


# =====================================================
# MAIN FUNCTION
# =====================================================
async def send_email_output(
        db:Connection, 
        job_id: str, 
        config: dict, 
        tables: Dict[str, pd.DataFrame], 
        email_data: Dict, 
        required_hitl: bool, 
        execution_id: str
    ):

    if not safe_get(config, "is_enable", default=False):
        print("Email sending disabled")
        return

    distribution = safe_get(config, "distribution", default={})

    # =====================================================
    # SINGLE MODE
    # =====================================================
    single_cfg = safe_get(distribution, "single_mode", default={})

    if safe_get(single_cfg, "enabled", default=False):

        await _send_email(
            db=db,
            job_id=job_id,
            email_cfg=single_cfg.get("email", {}),
            tables=tables,
            email_data=email_data,
            required_hitl=required_hitl
        )

    # =====================================================
    # MULTI MODE
    # =====================================================
    
    multi_cfg = safe_get(distribution, "multi_mode", default={})

    if not safe_get(multi_cfg, "enabled", default=False):
        return


    group_column = multi_cfg.get("group_by", {}).get("column")

    recipient_map = normalize_mapping(
        multi_cfg.get("recipient_mapping", {})
    )

    email_template = multi_cfg.get("email", {})

    if not group_column:
        raise ValueError("multi_mode requires group_by.column")

    print(f"\n[MULTI MODE] Grouping by: {group_column}")

    # =====================================================
    # STEP 0: FIND RELEVANT TABLES ONLY
    # =====================================================

    grouping_tables = set()

    markdown_cfg = email_template.get("table_as_markdown", {})
    attachment_cfg = email_template.get("table_as_attachment", {})

    # Markdown tables
    if markdown_cfg.get("all_dataframes", False):
        grouping_tables.update(tables.keys())
    else:
        grouping_tables.update(
            markdown_cfg.get("selected_dataframes", [])
        )

    # Attachment tables
    if attachment_cfg.get("all_dataframes", False):
        grouping_tables.update(tables.keys())
    else:
        grouping_tables.update(
            attachment_cfg.get("selected_dataframes", [])
        )

    # Keep only valid existing tables
    grouping_tables = {
        t for t in grouping_tables if t in tables
    }

    if not grouping_tables:
        print("[MULTI MODE] No valid grouping tables found")
        return

    print(f"[MULTI MODE] Tables used for grouping: {grouping_tables}")

    # =====================================================
    # STEP 1: FIND GROUP COLUMN
    # =====================================================

    df_group_columns = {}

    for name in grouping_tables:

        df = tables[name]

        col = find_matching_column(df, group_column)

        if not col:

            print(
                f"[MULTI MODE] Column '{group_column}' missing in '{name}' → fallback to others"
            )

            recipient = recipient_map.get("others", {})

            email_cfg = {
                "to": recipient.get("to", []),
                "cc": recipient.get("cc", []),
                "bcc": recipient.get("bcc", []),
                "subject": email_template.get("subject_template", "Report"),
                "body_context": email_template.get("body_context", ""),
                "llm_required": email_template.get("llm_required", False),
                "table_as_markdown": email_template.get("table_as_markdown"),
                "table_as_attachment": email_template.get("table_as_attachment"),
            }

            await _send_email(
                db=db, 
                job_id=job_id, 
                email_cfg=email_cfg, 
                tables=tables, 
                required_hitl=required_hitl
                )
            return

        df_group_columns[name] = col

    print(f"[MULTI MODE] Common Columns: {df_group_columns}")

    # =====================================================
    # STEP 2: FIND COMMON VALUES
    # =====================================================

    common_values = None

    for name in grouping_tables:

        df = tables[name]
        col = df_group_columns[name]

        values = set(
            normalize_value_loose(v)
            for v in df[col].dropna().unique()
        )

        if common_values is None:
            common_values = values
        else:
            common_values = common_values.intersection(values)

    print(f"[MULTI MODE] Common groups: {common_values}")

    # =====================================================
    # CASE 2 → NO COMMON VALUES
    # =====================================================

    if not common_values:

        print("[MULTI MODE] No common values → sending full dataset to 'others'")

        recipient = recipient_map.get("others", {})

        email_cfg = {
            "to": recipient.get("to", []),
            "cc": recipient.get("cc", []),
            "bcc": recipient.get("bcc", []),
            "subject": email_template.get("subject_template", "Report"),
            "body_context": email_template.get("body_context", ""),
            "llm_required": email_template.get("llm_required", False),
            "table_as_markdown": email_template.get("table_as_markdown"),
            "table_as_attachment": email_template.get("table_as_attachment"),
        }

        await _send_email(
            db=db, 
            job_id=job_id, 
            email_cfg=email_cfg, 
            tables=tables, 
            required_hitl=required_hitl
            )
        return

    # =====================================================
    # STEP 3: PRECOMPUTE NORMALIZED COLUMNS
    # =====================================================

    normalized_cache = {}

    for name in grouping_tables:

        df = tables[name]
        col = df_group_columns[name]

        normalized_cache[name] = (
            df[col]
            .astype(str)
            .str.lower()
            .str.replace(r"[^a-z0-9]", "", regex=True)
        )

    # =====================================================
    # STEP 4: BUILD EMAIL PACKAGES
    # =====================================================

    tasks = []
    results = []

    for value in common_values:

        split_tables = {}
        display_value = None

        valid_package = True

        for name in grouping_tables:

            df = tables[name]
            col = df_group_columns[name]

            norm_series = normalized_cache[name]

            mask = norm_series.str.startswith(value)

            sub_df = df[mask]

            if sub_df.empty:
                valid_package = False
                break

            split_tables[name] = sub_df

            if display_value is None:
                display_value = sub_df[col].iloc[0]

        if not valid_package:
            continue

        context = {
            group_column: display_value
        }

        recipient = resolve_recipient(value, recipient_map)

        email_cfg = {
            "to": recipient.get("to", []),
            "cc": recipient.get("cc", []),
            "bcc": recipient.get("bcc", []),
            "subject": render_template(
                email_template.get("subject_template", ""),
                context
            ),
            "body_context": render_template(
                email_template.get("body_context", ""),
                context
            ),
            "llm_required": email_template.get("llm_required", False),
            "table_as_markdown": email_template.get("table_as_markdown"),
            "table_as_attachment": email_template.get("table_as_attachment"),
        }

        print(f"\n[PACKAGE] {group_column}={display_value}")

        tasks.append(
            (email_cfg, split_tables, display_value)
        )

    # =====================================================
    # CASE 3 → NO VALID PACKAGES
    # =====================================================

    if not tasks:

        print("[MULTI MODE] No valid packages → fallback to others")

        recipient = recipient_map.get("others", {})

        email_cfg = {
            "to": recipient.get("to", []),
            "cc": recipient.get("cc", []),
            "bcc": recipient.get("bcc", []),
            "subject": email_template.get("subject_template", "Report"),
            "body_context": email_template.get("body_context", ""),
            "llm_required": email_template.get("llm_required", False),
            "table_as_markdown": email_template.get("table_as_markdown"),
            "table_as_attachment": email_template.get("table_as_attachment"),
        }

        await _send_email(
            db=db, 
            job_id=job_id, 
            email_cfg=email_cfg, 
            tables=tables, 
            required_hitl=required_hitl)
        return


    if required_hitl:

        # =====================================================
        # STEP 5: EXECUTE SEQUENTIALLY
        # =====================================================

        for email_cfg, split_tables, value in tasks:

            try:

                await _send_email(
                    db=db,
                    job_id=job_id,
                    email_cfg=email_cfg,
                    tables=split_tables,
                    required_hitl=required_hitl
                )

                results.append((value, "SUCCESS"))

            except Exception as e:

                results.append((value, f"FAILED: {str(e)}"))

        
    else:

        # =====================================================
        # STEP 5: EXECUTE IN BATCHES
        # =====================================================

        BATCH_SIZE = 5

        async def execute_task(email_cfg, split_tables, value):

            try:
                await _send_email(
                    db=db, 
                    job_id=job_id, 
                    email_cfg=email_cfg, 
                    tables=split_tables, 
                    required_hitl=required_hitl
                    )
                return (value, "SUCCESS")

            except Exception as e:
                return (value, f"FAILED: {str(e)}")

        for i in range(0, len(tasks), BATCH_SIZE):

            batch = tasks[i:i + BATCH_SIZE]

            batch_tasks = [
                execute_task(cfg, tbls, val)
                for cfg, tbls, val in batch
            ]

            batch_results = await asyncio.gather(*batch_tasks)

            results.extend(batch_results)



        # =====================================================
        # FINAL SUMMARY
        # =====================================================

        print("\n========== EMAIL SUMMARY ==========")
        print(f"Total Packages: {len(results)}")
        print(
            f"Success: "
            f"{len([r for r in results if r[1] == 'SUCCESS'])}"
        )
        print(
            f"Failed: "
            f"{len([r for r in results if r[1] != 'SUCCESS'])}"
        )
        # execution_log_steps.append({"step": "SEND MULTI EMAIL", "message": f"Email Transaction Done - Total Packages: {len(results)}, Success: {len([r for r in results if r[1] == 'SUCCESS'])}, Failed: {len([r for r in results if r[1] != 'SUCCESS'])}"})
        if results:
            print("\nDetails:")
            for r in results:
                print(r)


