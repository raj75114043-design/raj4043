import pandas as pd
import re
import os
import re
import mimetypes
from io import BytesIO, StringIO
from bs4 import BeautifulSoup
import json
from app.services.azure_doc_parsing import DocumentService
from app.services.s3_blob_management import S3Service
from asyncpg import Connection
from app.core.llm_client import get_llm_client

from app.email_doc_job_engine.utils.safe_loader import safe_get


def validate_unstructured_output(fields, output: dict, file_name: str):
    expected_cols = {f["name"] for f in fields}
    actual_cols = set(output.keys())

    missing = expected_cols - actual_cols
    extra = actual_cols - expected_cols

    if missing:
        raise ValueError(
            f"[{file_name}] Missing fields in extraction: {missing}"
        )

    if extra:
        raise ValueError(
            f"[{file_name}] Unexpected fields in extraction: {extra}"
        )


def template_to_regex(template: str) -> str:
    """
    Convert template base to regex
    Example:
    RIOT_{{site_code}}_{{date}} → ^RIOT_.+?_.+?$
    """
    if not template:
        return ".*"

    pattern = re.escape(template)

    # replace {{var}} → non-greedy wildcard
    pattern = re.sub(r"\\{\\{.*?\\}\\}", r".+?", pattern)

    return f"^{pattern}$"

# =========================================================
# SPLIT FILE NAME + EXTENSION
# =========================================================
def split_name_and_ext(name: str):

    if not name:
        return "", ""

    base_name = os.path.basename(name)

    file_name, file_ext = os.path.splitext(base_name)

    return (
        file_name.strip(),
        file_ext.replace(".", "").lower().strip()
    )


# =========================================================
# TEMPLATE -> REGEX
# =========================================================
def template_to_regex(template: str) -> str:

    if not template:
        return r".*"

    # escape regex chars
    pattern = re.escape(template)

    # convert {{variable}} -> wildcard
    pattern = re.sub(
        r"\\\{\\\{.*?\\\}\\\}",
        r".+?",
        pattern
    )

    # allow flexible separators
    pattern = pattern.replace(r"\ ", r"[\s_\-]*")
    pattern = pattern.replace(r"\_", r"[\s_\-]*")
    pattern = pattern.replace(r"\-", r"[\s_\-]*")

    return rf".*{pattern}.*"


# =========================================================
# GET CONTENT TYPE
# =========================================================
def get_content_type(file_ext: str):

    if not file_ext:
        return "application/octet-stream"

    file_ext = file_ext.lower()

    extension_map = {

        # images
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "png": "image/png",
        "bmp": "image/bmp",
        "tiff": "image/tiff",
        "tif": "image/tiff",
        "webp": "image/webp",

        # docs
        "pdf": "application/pdf",

        # excel
        "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "xls": "application/vnd.ms-excel",

        # text
        "txt": "text/plain",
        "csv": "text/csv"
    }

    return extension_map.get(
        file_ext,
        mimetypes.guess_type(f"dummy.{file_ext}")[0]
        or "application/octet-stream"
    )


# =========================================================
# MATCH TEMPLATE
# =========================================================
def match_template(s3_key: str, template: str) -> bool:
    """
    Supports:
    - full file names
    - partial names
    - keyword matching
    - dynamic placeholders {{var}}
    - ignores extension
    """

    if not s3_key or not template:
        return False

    full_file_name = s3_key.split("/")[-1]

    actual_base, _ = split_name_and_ext(full_file_name)
    template_base, _ = split_name_and_ext(template)

    pattern = template_to_regex(template_base)

    return re.match(
        pattern,
        actual_base,
        re.IGNORECASE
    ) is not None


# =========================================================
# LLM STRUCTURED EXTRACTION (EMAIL BODY)
# =========================================================

async def extract_structured_from_text(text: str, cfg: dict):

    fields = cfg.get("fields", [])
    parsing_context = cfg.get("parsing_context", "")
    allow_multiple_rows = cfg.get("allow_multiple_rows", True)

    field_names = [f["name"] for f in fields]

    prompt = f"""
You are a strict JSON extractor.

CONTEXT:
{parsing_context}

FIELDS:
{fields}

IMPORTANT:
- Return ONLY valid JSON
- No markdown
- No explanation
- Exact field names only
- null if missing

If multiple rows exist:
Return JSON ARRAY.

If single row:
Return JSON OBJECT.

TEXT:
{text}
"""

    try:
        
        llm = get_llm_client("medium")

        response = llm.invoke(prompt)
        # print("\nLLM response:", response)

        content = response.content.strip()
        # remove markdown safely
        content = content.replace("```json", "").replace("```", "").strip()
        # print("\nRaw content:", content)

        data = json.loads(content)
        # print("\nParsed json:", data)

        # =====================================================
        # MULTIPLE ROWS
        # =====================================================
        if isinstance(data, list):

            cleaned_rows = []
            for row in data:
                if not isinstance(row, dict):
                    continue
                cleaned_rows.append({
                    f["name"]: row.get(f["name"])
                    for f in fields
                })

            # print("\nFinal cleaned rows:", cleaned_rows)

            return cleaned_rows

        # =====================================================
        # SINGLE ROW
        # =====================================================
        elif isinstance(data, dict):

            cleaned_row = {
                f["name"]: data.get(f["name"])
                for f in fields
            }

            # print("\nFinal cleaned row:", cleaned_row)

            return cleaned_row

        else:

            print("Invalid JSON structure")

            return []

    except Exception as e:

        print("\nERROR IN extract_structured_from_text")
        print(str(e))

        return []

# =========================================================
# CLEAN TEXT EXTRACTION
# =========================================================

def extract_clean_text(html: str):
    if not html:
        return ""

    soup = BeautifulSoup(html, "lxml")

    # Remove junk
    for tag in soup(["script", "style", "noscript"]):
        tag.decompose()

    # Extract text
    text = soup.get_text("\n", strip=True)

    # Normalize
    text = re.sub(r'\n+', '\n', text)
    text = re.sub(r'[ \t]+', ' ', text)

    return text.strip()

def extract_tables_from_html(html: str):
    soup = BeautifulSoup(html, "lxml")
    tables = soup.find_all("table")

    dfs = []

    for table in tables:
        try:
            df_list = pd.read_html(StringIO(str(table)), flavor="lxml")

            if not df_list:
                continue

            df = df_list[0]

            if df.empty:
                continue

            if df.shape[0] < 1 or df.shape[1] < 2:
                continue

            dfs.append(df)

        except Exception:
            continue

    return dfs

def is_valid_table(df):
    if df is None or df.empty:
        return False

    if df.shape[0] < 2:
        return False

    non_empty_ratio = df.notna().sum().sum() / (df.shape[0] * df.shape[1])

    return non_empty_ratio > 0.3

def normalize_col(col):
    return re.sub(r"\s+", " ", str(col)).strip().lower()


def cast_column(df, fields):
    """
    Apply schema-based type casting
    """
    for f in fields:
        col = f.get("name")
        dtype = f.get("type")

        if col not in df.columns:
            continue

        try:
            if dtype == "int":
                df[col] = pd.to_numeric(df[col], errors="coerce").astype("Int64")

            elif dtype == "float":
                df[col] = pd.to_numeric(df[col], errors="coerce")

            else:
                df[col] = df[col].astype(str)

        except Exception:
            pass

    return df

# =========================================================
# MAIN LOADER (FIXED)
# =========================================================
async def load_dataframes_from_received_mail(
    db: Connection,
    s3_service: S3Service,
    azure_service: DocumentService,
    parsing_config: dict,
    email_data: dict,
    execution_id: str
):
    dfs = {}

    html = email_data.get("body", "")
    text = extract_clean_text(html)

    # =========================================================
    # 1. EMAIL BODY - TABLE EXTRACTION (CONFIG DRIVEN)
    # =========================================================
    tables_cfg = safe_get(parsing_config,"tables_in_body",default={})

    if safe_get(tables_cfg, "is_available", default=False):

        extracted_tables = extract_tables_from_html(html)
        config_tables = tables_cfg.get("tables", [])

        for table_cfg in config_tables:

            output_name = table_cfg.get("output_table_name")
            fields = table_cfg.get("fields", [])

            if not output_name:
                continue

            expected_cols = [f["name"] for f in fields]

            matched_df = None

            for df in extracted_tables:

                if not is_valid_table(df):
                    continue

                df_cols = [normalize_col(c) for c in df.columns]
                expected_cols_norm = [normalize_col(c) for c in expected_cols]

                match_count = sum(
                    1 for col in expected_cols_norm
                    if col in df_cols
                )

                if match_count >= max(1, len(expected_cols) // 2):
                    matched_df = df
                    break

            if matched_df is None:
                print(f"No matching table found for {output_name}")
                continue

            # -----------------------------
            # CLEAN + ALIGN (ROBUST)
            # -----------------------------
            df = matched_df.copy()

            # Normalize expected + actual columns
            expected_map = {
                normalize_col(col): col for col in expected_cols
            }

            df_col_map = {
                normalize_col(col): col for col in df.columns
            }

            final_mapping = {}

            for norm_expected, original_expected in expected_map.items():

                # 1. Exact match
                if norm_expected in df_col_map:
                    final_mapping[original_expected] = df_col_map[norm_expected]
                    continue

                # 2. Fuzzy match (contains logic)
                for df_norm, df_original in df_col_map.items():
                    if norm_expected in df_norm or df_norm in norm_expected:
                        final_mapping[original_expected] = df_original
                        break

            # -----------------------------
            # Build final dataframe
            # -----------------------------
            df_clean = pd.DataFrame()

            for expected_col, actual_col in final_mapping.items():
                df_clean[expected_col] = df[actual_col]

            # Ensure all expected columns exist
            for col in expected_cols:
                if col not in df_clean.columns:
                    df_clean[col] = None

            # Reorder columns
            df_clean = df_clean[expected_cols]

            # Type casting
            df_clean = cast_column(df_clean, fields)

            dfs[output_name] = df_clean

        # print("Body Tables Extracted:", list(dfs.keys()))
        
    # =========================================================
    # 2. EMAIL BODY - STRUCTURED LLM EXTRACTION
    # =========================================================
    # body_cfg = parsing_config.get("email_body", {})
    body_cfg = safe_get(parsing_config, "email_body", default={})

    # if body_cfg.get("is_available"):
    if safe_get(body_cfg, "is_available", default=False):   

        extracted_keys = []

        for ctx_cfg in body_cfg.get("context_to_llm", []):

            output_name = ctx_cfg.get("output_table_name")

            if not output_name:
                print("Skipping LLM config (no output_table_name)")
                continue

            print("\nContext: ", ctx_cfg)

            structured = await extract_structured_from_text(text, ctx_cfg)

            print("\nstructured output: ", structured)

            # multiple rows
            if isinstance(structured, list):
                dfs[output_name] = pd.DataFrame(structured)

            # single row
            else:
                dfs[output_name] = pd.DataFrame([structured])

            extracted_keys.append(output_name)


    # return dfs
    # =========================================================
    # 3. ATTACHMENTS - STRUCTURED
    # =========================================================


    # attachments_cfg = parsing_config.get("attachments", {})
    # structured_cfg = attachments_cfg.get("structured", {})

    attachments_cfg = safe_get(parsing_config, "attachments", default={})
    structured_cfg = safe_get(attachments_cfg, "structured", default={})

    # if structured_cfg.get("is_available", False):
    if safe_get(structured_cfg, "is_available", default=False):    

        for file_cfg in structured_cfg.get("selected_files", []):

            template = file_cfg.get("file_name_template", "")
            expected_sheets = file_cfg.get("sheets", [])

            for att in email_data.get("attachments", []):

                file_name = att.get("file_name", "")
                s3_key = att.get("s3_key", "")
                bucket = att.get("s3_bucket_name")
                template = file_cfg.get("file_name_template", "")
                file_type = file_cfg.get("file_type", "")

                if not match_template(s3_key, template):
                    continue

                print("MATCHED FILE:", s3_key)

                file_bytes = await s3_service.get_file_bytes(bucket, s3_key)
                buffer = BytesIO(file_bytes)

                # ---------------- CSV ----------------
                if s3_key.endswith(".csv"):

                    sheet_cfg = expected_sheets[0] if expected_sheets else {}
                    fields = sheet_cfg.get("fields", [])
                    output_name = sheet_cfg.get("output_table_name")

                    # starting_row = sheet_cfg.get("starting_row", 1)
                    starting_row = safe_get(sheet_cfg, "starting_row", default=1)
                    skiprows = max(starting_row - 1, 0)
                    
                    dtype_map = {
                        f["name"]: "string"
                        for f in fields
                        if f.get("type") == "string"
                    } if fields else None

                    df = pd.read_csv(buffer, dtype=dtype_map, low_memory=False, skiprows=skiprows)
                    # df = pd.read_csv(buffer)

                    if fields:
                        cols = [f["name"] for f in fields]
                        df = df[[c for c in df.columns if c in cols]]
                        df = df.reindex(columns=cols)
                        df = cast_column(df, fields)

                    dfs[output_name] = df

                # ---------------- XLSX ----------------
                elif s3_key.endswith(".xlsx"):

                    excel = pd.ExcelFile(buffer)

                    for sheet_cfg in expected_sheets:

                        sheet_name = sheet_cfg.get("sheet_name")
                        output_name = sheet_cfg.get("output_table_name")
                        fields = sheet_cfg.get("fields", [])

                        # starting_row = sheet_cfg.get("starting_row", 1)
                        starting_row = safe_get(sheet_cfg, "starting_row", default=1)
                        skiprows = max(starting_row - 1, 0)
                        
                        if sheet_name not in excel.sheet_names:
                            continue

                        dtype_map = {
                            f["name"]: "string"
                            for f in fields
                            if f.get("type") == "string"
                        } if fields else None

                        df = excel.parse(
                            sheet_name,
                            skiprows=skiprows,
                            dtype=dtype_map
                        )
                        
                        # df = excel.parse(sheet_name)

                        if fields:
                            cols = [f["name"] for f in fields]
                            df = df[[c for c in df.columns if c in cols]]
                            df = df.reindex(columns=cols)
                            df = cast_column(df, fields)

                        dfs[output_name] = df
                        

    # =========================================================
    # 4. ATTACHMENTS - UNSTRUCTURED (OCR + LLM)
    # =========================================================

    # unstructured_cfg = attachments_cfg.get("unstructured", {})
    unstructured_cfg = safe_get(attachments_cfg, "unstructured", default={})

    # if unstructured_cfg.get("is_available"):
    if safe_get(unstructured_cfg, "is_available", default=False): 

        print("\nAnalyzing Unstructured File from email attachments........")

        for file_cfg in unstructured_cfg.get("selected_files", []):
            template = file_cfg.get("file_name_template", "")
            fields = file_cfg.get("fields", [])
            output_name = file_cfg.get("output_table_name")

            for att in email_data.get("attachments", []):

                s3_key = att.get("s3_key", "")
                file_name = att.get("file_name", "")
                bucket = att.get("s3_bucket_name")

                print("s3_key: ", s3_key)

                # =============================================
                # TEMPLATE MATCH
                # =============================================
                if not match_template(s3_key, template):
                    continue

                print(f"Matched attachment: {s3_key}")

                # =============================================
                # FILE EXTENSION
                # =============================================
                _, file_ext = split_name_and_ext(s3_key)
                file_ext = file_ext.lower()

                # =============================================
                # ALLOWED FILE TYPES ONLY
                # =============================================
                allowed_extensions = {"png", "jpg", "jpeg", "pdf"}

                if file_ext not in allowed_extensions:
                    print(
                        f"Skipping unsupported file type: "
                        f"{file_ext} for file: {s3_key}"
                    )
                    continue

                print(f"Matched attachment: {s3_key}")

                # =============================================
                # FILE TYPE
                # =============================================
                content_type = get_content_type(file_ext)

                print(f"Detected content type: {content_type}")

                file_bytes = await s3_service.get_file_bytes(
                    att["s3_bucket_name"],
                    s3_key
                )

                structured = await azure_service.extract_fields(
                    file_bytes=file_bytes,
                    content_type=content_type,
                    fields=fields,
                    model="prebuilt-layout",
                    parsing_context=file_cfg.get("parsing_context")
                )

                validate_unstructured_output(fields, structured, template)

                dfs[output_name] = pd.DataFrame([structured])



    # =========================================================
    # FINAL VALIDATION
    # =========================================================
    if not dfs:
        raise ValueError("No dataframes extracted from email")

    return dfs