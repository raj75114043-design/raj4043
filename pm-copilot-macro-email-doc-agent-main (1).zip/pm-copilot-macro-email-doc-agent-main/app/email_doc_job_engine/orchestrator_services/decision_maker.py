import re
from html import unescape
from bs4 import BeautifulSoup


def normalize_text(text: str) -> str:
    """
    Normalize text for flexible matching.
    """

    if not text:
        return ""

    text = unescape(text)

    # lowercase
    text = text.lower()

    # collapse whitespace
    text = re.sub(r"\s+", " ", text)

    # remove extra special chars except useful ones
    text = re.sub(r"[^\w\s\-:/{}]", "", text)

    return text.strip()


def extract_text_from_html(html: str) -> str:
    """
    Convert HTML email body to plain text.
    """

    if not html:
        return ""

    soup = BeautifulSoup(html, "html.parser")

    # remove style/script
    for tag in soup(["style", "script"]):
        tag.decompose()

    return soup.get_text(separator=" ")


def build_regex_pattern(text_in_body: str) -> str:
    """
    Convert template into regex.

    Example:
    "CBN Validation Results - {{site_code}} - Approved"

    becomes:

    r"cbn validation results\\s*-\\s*.*?\\s*-\\s*approved"
    """

    text_in_body = normalize_text(text_in_body)

    # escape regex chars first
    pattern = re.escape(text_in_body)

    # replace template placeholders with wildcard
    pattern = re.sub(
        r"\\\{\\\{.*?\\\}\\\}",
        r".*?",
        pattern
    )

    # flexible spacing around hyphen
    pattern = pattern.replace(r"\-", r"\s*-\s*")

    # flexible whitespace
    pattern = pattern.replace(r"\ ", r"\s+")

    return pattern


def check_final_go_decision(
    decision_point_info,
    email_data: dict
) -> bool:

    text_in_body = decision_point_info.get("text_in_body", "")
    html_email_body = email_data.get("body", "")

    if not text_in_body:
        return False

    # extract html -> plain text
    email_plain_text = extract_text_from_html(html_email_body)

    # normalize email text
    email_plain_text = normalize_text(email_plain_text)

    # build regex pattern
    pattern = build_regex_pattern(text_in_body)

    # match
    return bool(
        re.search(pattern, email_plain_text, re.IGNORECASE)
    )