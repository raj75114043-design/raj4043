# app/services/email_send_tracker.py

import json
from datetime import datetime


async def insert_email_send_tracker(
    db,
    rows: list
):

    if not rows:
        return

    query = """
    INSERT INTO macro_email_doc_agent.email_doc_usecase_jobs_email_send
    (
        job_id,
        to_list,
        cc_list,
        bcc_list,
        email_subject,
        email_body,
        attachments,
        is_approval_required,
        mail_status,
        remarks,
        sent_at,
        updated_at
    )
    VALUES
    (
        $1,   -- job_id
        $2,   -- to_list
        $3,   -- cc_list
        $4,   -- bcc_list
        $5,   -- email_subject
        $6,   -- email_body
        $7::jsonb, -- attachments
        $8,   -- is_approval_required
        $9,   -- mail_status
        $10,  -- remarks
        $11,  -- sent_at
        $12   -- updated_at
    )
    """

    now = datetime.now()

    for row in rows:

        await db.execute(
            query,
            row.get("job_id"),
            row.get("to_list", []),
            row.get("cc_list", []),
            row.get("bcc_list", []),
            row.get("email_subject"),
            row.get("email_body"),
            json.dumps(row.get("attachments", [])),
            row.get("is_approval_required", False),
            row.get("mail_status"),
            row.get("remarks"),
            row.get("sent_at"),
            now
        )