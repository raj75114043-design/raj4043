# services/job_loader.py

import json
import os
from asyncpg import Connection

async def load_job_config(db: Connection, job_id: str) -> dict:

    query = """
        SELECT json_config
        FROM macro_email_doc_agent.email_doc_usecase_jobs
        WHERE job_id = $1
        AND is_active = TRUE
        LIMIT 1
    """

    try:
        row = await db.fetchrow(query, job_id)

        if row:
            config = row["json_config"]

            if isinstance(config, str):
                config = json.loads(config)

            print(f"[JOB LOADER] Loaded config from DB for {job_id}")
            return config

        else:
            print(f"[JOB LOADER] job_id {job_id} not found in DB")

    except Exception as e:
        print(f"[JOB LOADER] DB FAILED → {e}")
        raise ValueError(
            f"Failed to load job config for {job_id} from DB and file. Error: {e}"
        )