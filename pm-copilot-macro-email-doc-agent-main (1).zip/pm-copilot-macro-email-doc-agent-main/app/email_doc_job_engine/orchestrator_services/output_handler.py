import pandas as pd
import numpy as np
from io import BytesIO
from datetime import datetime

from asyncpg import Connection
from app.services.s3_blob_management import S3Service
from app.email_doc_job_engine.utils.safe_loader import safe_get


# =====================================================
# TYPE MAPPING (PANDAS → POSTGRES)
# =====================================================
def map_dtype(dtype):
    if pd.api.types.is_integer_dtype(dtype):
        return "BIGINT"
    if pd.api.types.is_float_dtype(dtype):
        return "DOUBLE PRECISION"
    if pd.api.types.is_bool_dtype(dtype):
        return "BOOLEAN"
    if pd.api.types.is_datetime64_any_dtype(dtype):
        return "TIMESTAMP"
    return "TEXT"

# =====================================================
# CREATE TABLE IF NOT EXISTS
# =====================================================
async def ensure_table_exists(conn, df, table_name, schema):

    columns = []
    for col, dtype in df.dtypes.items():
        pg_type = map_dtype(dtype)
        columns.append(f'"{col}" {pg_type}')

    columns_sql = ", ".join(columns)

    query = f"""
        CREATE TABLE IF NOT EXISTS "{schema}"."{table_name}" (
            {columns_sql}
        )
    """

    await conn.execute(query)


# =====================================================
# ADD MISSING COLUMNS
# =====================================================
async def add_missing_columns(conn, df, table_name, schema):

    existing_cols_query = f"""
        SELECT column_name
        FROM information_schema.columns
        WHERE table_schema = $1
        AND table_name = $2
    """

    rows = await conn.fetch(existing_cols_query, schema, table_name)
    existing_cols = {r["column_name"] for r in rows}

    for col, dtype in df.dtypes.items():
        if col not in existing_cols:
            pg_type = map_dtype(dtype)

            alter_query = f"""
                ALTER TABLE "{schema}"."{table_name}"
                ADD COLUMN "{col}" {pg_type}
            """

            await conn.execute(alter_query)
            print(f"Added column '{col}' to {table_name}")




async def handle_outputs(
    db: Connection,
    s3_service: S3Service,
    config: dict,
    tables: dict
):

    # =====================================================
    # HELPER: FILTER TABLES
    # =====================================================
    def filter_tables(all_tables: dict, cfg: dict):
        if not cfg.get("all_dataframes", True):
            selected = cfg.get("selected_dataframes", [])
            return {k: v for k, v in all_tables.items() if k in selected}
        return all_tables

    # =====================================================
    # 1. SAVE TO S3
    # =====================================================
    s3_cfg = safe_get(config, "save_to_s3", default={})

    if safe_get(s3_cfg, "enabled", default=False):

        bucket = s3_cfg["bucket_name"]
        key_folder = s3_cfg.get("key_folder", "outputs/")
        file_format = s3_cfg.get("file_format", "csv")
        one_file = s3_cfg.get("all_dataframes_in_one_file", False)

        # ts = datetime.now().strftime("%Y%m%d-%H%M%S")
        ts_date = datetime.now().strftime("%Y%m%d")
        ts_time = datetime.now().strftime("%H%M%S")

        selected_tables = filter_tables(tables, s3_cfg)

        if not selected_tables:
            print("No tables selected for S3 upload")
        else:

            # =================================================
            # CASE 1: ALL DATAFRAMES IN ONE FILE (ONLY XLSX)
            # =================================================
            if one_file:

                if file_format != "xlsx":
                    raise ValueError("all_dataframes_in_one_file=true only supports xlsx")

                buffer = BytesIO()

                with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
                    for name, df in selected_tables.items():
                        df = df.where(pd.notnull(df), None)
                        df.to_excel(writer, index=False, sheet_name=name[:31])

                buffer.seek(0)

                key = f"{key_folder}{ts_date}/{ts_time}/combined_report.xlsx"

                await s3_service.upload_bytes(
                    bucket=bucket,
                    key=key,
                    data=buffer.read(),
                    content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                )

                print(f"Uploaded combined file: {key}")

            # =================================================
            # CASE 2: MULTIPLE FILES (ONE PER DF)
            # =================================================
            else:

                for name, df in selected_tables.items():

                    df = df.where(pd.notnull(df), None)

                    if file_format == "csv":
                        file_bytes = df.to_csv(index=False).encode("utf-8")
                        content_type = "text/csv"

                    elif file_format == "xlsx":
                        buffer = BytesIO()
                        df.to_excel(buffer, index=False)
                        buffer.seek(0)
                        file_bytes = buffer.read()
                        content_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

                    else:
                        raise ValueError(f"Unsupported format: {file_format}")

                    key = f"{key_folder}{ts_date}/{ts_time}/{name}.{file_format}"

                    await s3_service.upload_bytes(
                        bucket=bucket,
                        key=key,
                        data=file_bytes,
                        content_type=content_type
                    )

                    print(f"Uploaded: {key}")


    # =====================================================
    # 2. UPDATE DATABASE
    # =====================================================

    db_cfg = safe_get(config, "update_db", default={})

    if safe_get(db_cfg, "is_enabled", default=False):

        for table_cfg in db_cfg.get("table", []):

            if not table_cfg.get("enabled"):
                continue

            input_table = table_cfg.get("input_table")

            if input_table not in tables:
                print(f"Table '{input_table}' not found, skipping DB insert")
                continue

            df = tables[input_table]
            df = df.where(pd.notnull(df), None)

            if df.empty:
                print(f"Empty dataframe '{input_table}', skipping DB insert")
                continue

            table_name = table_cfg["postgre_table_name"]
            schema = table_cfg.get("schema", "macro_email_doc_agent")

            # =================================================
            # 1. AUTO CREATE TABLE
            # =================================================
            if table_cfg.get("auto_create_table"):
                await ensure_table_exists(db, df, table_name, schema)

            # =================================================
            # 2. AUTO ADD COLUMNS
            # =================================================
            if table_cfg.get("auto_add_columns"):
                await add_missing_columns(db, df, table_name, schema)

            # =================================================
            # 3. FETCH POSTGRES COLUMN TYPES
            # =================================================
            column_type_rows = await db.fetch(
                """
                SELECT
                    column_name,
                    data_type
                FROM information_schema.columns
                WHERE table_schema = $1
                AND table_name = $2
                """,
                schema,
                table_name
            )

            pg_column_types = {
                row["column_name"]: row["data_type"]
                for row in column_type_rows
            }

            # =================================================
            # 4. AUTO TYPE CAST BASED ON PG TYPES
            # =================================================
            for col in df.columns:

                if col not in pg_column_types:
                    continue

                pg_type = pg_column_types[col]

                try:

                    # INTEGER TYPES
                    if pg_type in [
                        "integer",
                        "smallint",
                        "bigint"
                    ]:

                        df[col] = pd.to_numeric(
                            df[col],
                            errors="coerce"
                        )

                        # keep NULL support
                        df[col] = df[col].astype("Int64")

                    # FLOAT TYPES
                    elif pg_type in [
                        "numeric",
                        "double precision",
                        "real",
                        "decimal"
                    ]:

                        df[col] = pd.to_numeric(
                            df[col],
                            errors="coerce"
                        )

                    # BOOLEAN
                    elif pg_type == "boolean":

                        def convert_bool(v):

                            if pd.isna(v):
                                return None

                            # already boolean
                            if isinstance(v, bool):
                                return v

                            # string handling
                            if isinstance(v, str):

                                val = v.strip().lower()

                                if val in ["true", "1", "yes", "y"]:
                                    return True

                                if val in ["false", "0", "no", "n"]:
                                    return False

                            # numeric handling
                            if isinstance(v, (int, float)):

                                if v == 1:
                                    return True

                                if v == 0:
                                    return False

                            return None

                        # IMPORTANT:
                        # force python native bool
                        df[col] = df[col].apply(convert_bool)

                        # force object dtype
                        df[col] = df[col].astype(object)

                    # TIMESTAMP / DATE
                    # TIMESTAMP / DATE
                    elif pg_type in [
                        "timestamp without time zone",
                        "timestamp with time zone",
                        "date"
                    ]:

                        df[col] = pd.to_datetime(
                            df[col],
                            errors="coerce"
                        )

                        # remove timezone if exists
                        try:
                            df[col] = df[col].dt.tz_localize(None)
                        except Exception:
                            pass

                        # DATE COLUMN
                        if pg_type == "date":

                            df[col] = df[col].apply(
                                lambda x:
                                    x.date()
                                    if pd.notna(x)
                                    else None
                            )

                        # TIMESTAMP COLUMN
                        else:

                            df[col] = df[col].apply(
                                lambda x:
                                    x.to_pydatetime()
                                    if pd.notna(x)
                                    else None
                            )

                        df[col] = df[col].astype(object)
                    
                    # EVERYTHING ELSE -> STRING
                    else:
                        df[col] = df[col].astype(str)

                except Exception as cast_error:
                    print(
                        f"[TYPE CAST WARNING] "
                        f"Column={col}, "
                        f"PG Type={pg_type}, "
                        f"Error={cast_error}"
                    )

            # =================================================
            # 5. INSERT DATA
            # =================================================
            records = [
                tuple(
                    None if pd.isna(v) else v
                    for v in row
                )
                for row in df.to_records(index=False)
            ]

            await db.copy_records_to_table(
                table_name,
                records=records,
                columns=list(df.columns),
                schema_name=schema
            )

            print(f"Inserted into DB: {schema}.{table_name}")

    print("File Successfully Saved!")
