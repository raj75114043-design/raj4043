# app/services/job_execution_tracker.py

from datetime import datetime
import json
from asyncpg import Connection

from app.utils.timezone import get_datetime_now_without_zone

def json_serializer(obj):

    if isinstance(obj, set):
        return list(obj)

    return str(obj)




async def update_job_execution_status(
    db: Connection,
    job_id: str,
    execution_log: dict,
    status: str,
    started_at,
    completed_at=None,
    error: str = None,
    extra_data: dict = None
):

    completed_at = completed_at or get_datetime_now_without_zone()

    execution_result = {
        "job_id": job_id,
        "status": status,
        "started_at": str(started_at),
        "completed_at": str(completed_at),
        "execution_log": execution_log,
        "extra_data": extra_data or {},
        "error": error
    }

    # execution_result_json = json.dumps(execution_result)
    execution_result_json = json.dumps(
        execution_result,
        default=json_serializer
    )

    # =====================================================
    # UPDATE MAIN JOB TABLE
    # =====================================================

    is_approval_required = True
    # current_status = None

    if status == "DRAFTED SUCCESS":
        # current_status = "MAIL DRAFTED"
        time_now = get_datetime_now_without_zone()

        await db.execute(
            """
            UPDATE macro_email_doc_agent.email_doc_usecase_jobs
            SET
                last_run_at = $1,
                last_run_status = $2,
                last_executed_result = $3::jsonb,
                is_approval_required = $4,
                approval_status = NULL,
                updated_at = $5
            WHERE job_id = $6
            """,
            completed_at,
            status,
            execution_result_json,
            is_approval_required,
            time_now,
            job_id
        )


    elif status == "MAIL SENT SUCCESS":
        # current_status = "MAIL TRANSACTION DONE"
        
        # ============================================
        # 2. CHECK IF ALL ROWS ARE APPROVED
        # ============================================

        pending_check = await db.fetchval(
            """
            SELECT COUNT(*)
            FROM macro_email_doc_agent.email_doc_usecase_jobs_email_send
            WHERE job_id = $1
              AND is_approval_required = TRUE
              AND is_approved IS NULL
            """,
            job_id
        )

        # ============================================
        # 3. IF NO PENDING APPROVALS → UPDATE JOB TABLE
        # ============================================
        if pending_check == 0:
            is_approval_required = False
            time_now = get_datetime_now_without_zone()

            await db.execute(
                """
                UPDATE macro_email_doc_agent.email_doc_usecase_jobs
                SET
                    last_run_at = $1,
                    last_run_status = $2,
                    last_executed_result = $3::jsonb,
                    is_approval_required = $4,
                    updated_at = $5
                WHERE job_id = $6
                """,
                completed_at,
                status,
                execution_result_json,
                is_approval_required,
                time_now,
                job_id
            )

        else:   

            time_now = get_datetime_now_without_zone()

            await db.execute(
                """
                UPDATE macro_email_doc_agent.email_doc_usecase_jobs
                SET
                    last_run_at = $1,
                    last_run_status = $2,
                    last_executed_result = $3::jsonb,
                    is_approval_required = $4,
                    approval_status = NULL,
                    updated_at = $5
                WHERE job_id = $6
                """,
                completed_at,
                status,
                execution_result_json,
                is_approval_required,
                time_now,
                job_id
            )


    # =====================================================
    # INSERT RUN HISTORY
    # =====================================================
    time_now = get_datetime_now_without_zone()

    await db.execute(
        """
        INSERT INTO macro_email_doc_agent.email_doc_usecase_jobs_run_status
        (
            job_id,
            job_started_at,
            job_completed_at,
            job_execution_result,
            run_status,
            run_error,
            created_at,
            updated_at
        )
        VALUES
        (
            $1,
            $2,
            $3,
            $4::jsonb,
            $5,
            $6,
            $7,
            $8
        )
        """,
        job_id,
        started_at,
        completed_at,
        execution_result_json,
        status,
        error,
        time_now,
        time_now
    )




async def update_job_current_status(
    db: Connection,
    job_id: str,
    current_status: str
):
    try: 

        await db.execute(
            """
            UPDATE macro_email_doc_agent.email_doc_usecase_jobs
            SET
                current_status = $1
            WHERE job_id = $2
            """,
            current_status,
            job_id
        )

    except Exception as e:
        raise Exception(f"Current Status Update Failed: {str(e)}")
