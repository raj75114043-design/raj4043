import os
from functools import lru_cache


@lru_cache
def get_config():
    return {
        "azure_doc_intelligence": {
          "endpoint": "https://pm-copilot.cognitiveservices.azure.com/",
          "key": "3sjQmwls3h3fmMGe6oqAhI6EQZ42YJVPEQT2mUk2WUd9UFnInubNJQQJ99BGAC5RqLJXJ3w3AAALACOGjU0Y"
        },
        "document_models": {
            "default": "prebuilt-layout",
            "models": [
              { "id": "prebuilt-read", "category": "generic", "description": "Fast OCR text extraction" },
              { "id": "prebuilt-layout", "category": "generic", "description": "Best general structured extraction" },
              { "id": "prebuilt-contract", "category": "legal", "description": "Contract parsing" },
              { "id": "prebuilt-healthInsuranceCard.us", "category": "healthcare", "description": "Health insurance cards" },
              { "id": "prebuilt-idDocument", "category": "identity", "description": "ID documents" },
              { "id": "prebuilt-invoice", "category": "finance", "description": "Invoices" },
              { "id": "prebuilt-receipt", "category": "finance", "description": "Receipts" },
              { "id": "prebuilt-marriageCertificate.us", "category": "legal", "description": "Marriage certificates" },
              { "id": "prebuilt-creditCard", "category": "finance", "description": "Credit cards" },
              { "id": "prebuilt-check.us", "category": "finance", "description": "Bank checks" },
              { "id": "prebuilt-payStub.us", "category": "finance", "description": "Pay stubs" },
              { "id": "prebuilt-bankStatement", "category": "finance", "description": "Bank statements" },
              { "id": "prebuilt-mortgage.us.1003", "category": "mortgage", "description": "Mortgage 1003" },
              { "id": "prebuilt-mortgage.us.1004", "category": "mortgage", "description": "Mortgage 1004" },
              { "id": "prebuilt-mortgage.us.1005", "category": "mortgage", "description": "Mortgage 1005" },
              { "id": "prebuilt-mortgage.us.1008", "category": "mortgage", "description": "Mortgage 1008" },
              { "id": "prebuilt-mortgage.us.closingDisclosure", "category": "mortgage", "description": "Closing disclosure" },
              { "id": "prebuilt-tax.us", "category": "tax", "description": "General tax" },
              { "id": "prebuilt-tax.us.w2", "category": "tax", "description": "W2" },
              { "id": "prebuilt-tax.us.w4", "category": "tax", "description": "W4" },
              { "id": "prebuilt-tax.us.1040", "category": "tax", "description": "1040" },
              { "id": "prebuilt-tax.us.1095A", "category": "tax", "description": "1095A" },
              { "id": "prebuilt-tax.us.1095C", "category": "tax", "description": "1095C" },
              { "id": "prebuilt-tax.us.1098", "category": "tax", "description": "1098" },
              { "id": "prebuilt-tax.us.1098E", "category": "tax", "description": "1098E" },
              { "id": "prebuilt-tax.us.1098T", "category": "tax", "description": "1098T" },
              { "id": "prebuilt-tax.us.1099", "category": "tax", "description": "1099" },
              { "id": "prebuilt-tax.us.1099SSA", "category": "tax", "description": "1099SSA" }
            ]
        },
        "supported_formats": {
          "mime_types": [
            "application/pdf",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "image/jpeg",
            "image/png",
            "image/bmp",
            "image/tiff",
            "text/html"
          ]
        },
        "limits": {
            "max_file_size_mb": 200,
            "max_text_length": 15000
        }
    }