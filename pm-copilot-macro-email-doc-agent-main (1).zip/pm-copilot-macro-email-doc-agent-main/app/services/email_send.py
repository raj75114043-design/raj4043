import base64
import csv
import io
import json
import requests
import asyncio
import re
import time
from uuid import UUID
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Tuple
from asyncpg import Connection
from langchain_openai import ChatOpenAI
from app.core.llm_client import get_llm_client

from app.utils.timezone import get_datetime_now_without_zone
from app.config.data_fetch_config import EMAIL_DOC_AGENT_SCHEMA

from app.services.send_email_gateway import (
    get_session_id,
    send_email_via_gateway,
)


async def send_email(
    db,
    user_id: str,
    token_id: str,
    scheduled_id: str,
    to_list: List[str],
    cc_list: List[str],
    bcc_list: List[str],
    subject: str,
    email_body: str,
    attachments: Optional[List[Dict[str, str]]] = None,
    progress_callback=None,
) -> Dict[str, Any]:
    
    if progress_callback:
        progress_callback("ENTERED INTO SEND-MAIL MODULE")

    email_status = "failed"
    failed_error = None
    result = None
    formatted_attachments  = []
    time_taken_by_api = None

    if isinstance(attachments, str):
        try:
            attachments = json.loads(attachments)
            if not isinstance(attachments, list):
                attachments = []
        except Exception as e:
            print(f"[INVALID ATTACHMENTS JSON] {repr(e)}")
            attachments = []

    try:     
        for att in attachments:
            try:
                if isinstance(att, dict):
                    filedata = att.get("filedata")
                    filename = att.get("filename")
                else:
                    filedata = getattr(att, "filedata", None)
                    filename = getattr(att, "filename", None)
                if not filedata:
                    continue

                formatted_attachments.append({
                    "filename": filename or "attachment.txt",
                    "filedata": filedata
                })

            except Exception as e:
                print(f"[ATTACHMENT SKIPPED] {repr(e)}")
                continue

        start_time = time.perf_counter()

        session_id = await asyncio.to_thread(get_session_id)
        if progress_callback:
            progress_callback("MAIL_GATEWAY_AUTHENTICATED")


        # print("formatted_attachments", formatted_attachments)


        result = await asyncio.to_thread(
            send_email_via_gateway,
            session_id,
            to_list,
            cc_list,
            bcc_list,
            subject,
            email_body,
            formatted_attachments,
        )
        end_time = time.perf_counter()
        time_taken_by_api = end_time - start_time
        if progress_callback:
            progress_callback("EMAIL_SENT")

        if result and isinstance(result, dict):
            email_status = result.get("result", {}).get("status", "unknown")
            if email_status.lower().startswith("success"):
                email_status = "sent"
            else:
                failed_error = str(result)
        else:
            failed_error = f"Invalid gateway response: {result}"

    except Exception as e:
        if 'start_time' in locals():
            end_time = time.perf_counter()
            time_taken_by_api = end_time - start_time
        failed_error = str(e)
        email_status = "failed"
        print(f"[EMAIL ERROR] {e}")

    finally:
        pass
    
    try:
        DATE_TIME = get_datetime_now_without_zone()
        await db.execute(
            f"""
            INSERT INTO {EMAIL_DOC_AGENT_SCHEMA}.email_sent_history (
                token_id,
                scheduled_id,
                to_list,
                cc_list,
                bcc_list,
                subject,
                email_body,
                attachments,
                sent_at,
                mail_status,
                failed_error,
                user_id,
                time_taken_by_api
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
            """,
            token_id,
            scheduled_id,
            to_list,
            cc_list,
            bcc_list,
            subject,
            email_body,
            json.dumps(formatted_attachments),
            DATE_TIME,
            email_status,
            failed_error,
            user_id,
            round(time_taken_by_api, 2) if time_taken_by_api is not None else None,
        )

        print(f"[Email Sent History Table] DB Updated")
        
    except Exception as db_error:
        print(f"[HISTORY INSERT FAILED] {db_error}")
        
    return {
        "status": email_status,
        "subject": subject,
        "gateway_response": result,
    }




async def send_email_without_status(
    db,
    token_id: str,
    user_id: str,
    to_list: List[str],
    cc_list: List[str],
    bcc_list: List[str],
    subject: str,
    email_body: str,
    attachments: Optional[List[Dict[str, str]]] = None,
) -> Dict[str, Any]:

    email_status = "failed"
    failed_error = None
    result = None
    formatted_attachments  = []
    time_taken_by_api = None


    if isinstance(attachments, str):
        try:
            attachments = json.loads(attachments)
            if not isinstance(attachments, list):
                attachments = []
        except Exception as e:
            print(f"[INVALID ATTACHMENTS JSON] {repr(e)}")
            attachments = []

    try:     
        for att in attachments:
            try:
                if isinstance(att, dict):
                    filedata = att.get("filedata")
                    filename = att.get("filename")
                else:
                    filedata = getattr(att, "filedata", None)
                    filename = getattr(att, "filename", None)
                if not filedata:
                    continue

                formatted_attachments.append({
                    "filename": filename or "attachment.txt",
                    "filedata": filedata
                })

            except Exception as e:
                print(f"[ATTACHMENT SKIPPED] {repr(e)}")
                continue

        start_time = time.perf_counter()
        session_id = await asyncio.to_thread(get_session_id)
        print("MAIL GATEWAY AUTHENTICATED")

        # print("formatted_attachments", formatted_attachments)

        result = await asyncio.to_thread(
            send_email_via_gateway,
            session_id,
            to_list,
            cc_list,
            bcc_list,
            subject,
            email_body,
            formatted_attachments,
        )
        end_time = time.perf_counter()
        time_taken_by_api = end_time - start_time
        
        if result and isinstance(result, dict):
            email_status = result.get("result", {}).get("status", "unknown")
            if email_status.lower().startswith("success"):
                email_status = "sent"
            else:
                failed_error = str(result)
        else:
            failed_error = f"Invalid gateway response: {result}"

        print(f"MAIL STATUS: {email_status}")

    except Exception as e:
        if 'start_time' in locals():
            end_time = time.perf_counter()
            time_taken_by_api = end_time - start_time
        failed_error = str(e)
        email_status = "failed"
        print(f"[EMAIL ERROR] {e}")
    
    finally:
        DATE_TIME = get_datetime_now_without_zone()

        await db.execute(
            f"""
            INSERT INTO {EMAIL_DOC_AGENT_SCHEMA}.email_sent_history (
                token_id,
                to_list,
                cc_list,
                bcc_list,
                subject,
                email_body,
                attachments,
                sent_at,
                mail_status,
                failed_error,
                user_id,
                time_taken_by_api
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
            """,
            token_id,
            to_list,
            cc_list,
            bcc_list,
            subject,
            email_body,
            json.dumps(formatted_attachments),
            DATE_TIME,
            email_status,
            failed_error,
            user_id,
            round(time_taken_by_api, 2) if time_taken_by_api is not None else None,
        )
        print(f"[Email Sent History Table] DB Updated")
        
    return {
        "token_id": token_id,
        "status": email_status,
        "subject": subject,
        "gateway_response": result,
    }
