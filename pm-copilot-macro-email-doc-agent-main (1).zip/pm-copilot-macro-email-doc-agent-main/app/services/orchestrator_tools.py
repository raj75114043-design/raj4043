# import os
# import json
# from typing import List, Dict, Any, Optional
# from loguru import logger

# from app.db.pool import get_connection
# from app.services.s3_service import S3Service

# from app.services.azure_doc_parsing import DocumentService

# s3_service = S3Service()
# document_service = DocumentService()

# # ============================================================
# # TOOL 1
# # input: bucket_name, s3_key
# # return: file_name, file_type, file_data (base64)
# # ============================================================

# async def tool1_get_files_with_data(
#     bucket_name: str,
#     s3_key: str
# ) -> List[Dict[str, Any]]:
#     """
#     Fetch all files from S3 along with base64 data
#     """

#     results = []

#     try:
#         files = await s3_service.list_files(bucket_name, prefix=s3_key)

#         for f in files:
#             key = f.get("key")
#             file_name = os.path.basename(key)
#             file_type = file_name.split(".")[-1] if "." in file_name else "unknown"

#             file_data = await s3_service.get_file_as_base64(bucket_name, key)

#             results.append({
#                 "file_name": file_name,
#                 "file_type": file_type,
#                 "file_data": file_data.get("file_data_base64"),
#                 "key": key
#             })

#         return results

#     except Exception as e:
#         logger.error(f"[TOOL1 ERROR] {str(e)}")
#         raise Exception(f"Tool1 failed: {str(e)}")


# # ============================================================
# # TOOL 2
# # input: bucket_name, folder_path
# # return: file_name, file_type, file_date
# # ============================================================

# async def tool2_list_files_with_metadata(
#     bucket_name: str,
#     folder_path: str
# ) -> List[Dict[str, Any]]:
#     """
#     List files with metadata (for delta/latest logic)
#     """

#     results = []

#     try:
#         async with s3_service._session().client(
#             "s3",
#             endpoint_url=s3_service.endpoint_url,
#             aws_access_key_id=s3_service.access_key,
#             aws_secret_access_key=s3_service.secret_key,
#         ) as s3:

#             paginator = s3.get_paginator("list_objects_v2")

#             async for page in paginator.paginate(
#                 Bucket=bucket_name,
#                 Prefix=folder_path
#             ):
#                 for obj in page.get("Contents", []):

#                     key = obj["Key"]
#                     file_name = os.path.basename(key)
#                     file_type = file_name.split(".")[-1] if "." in file_name else "unknown"

#                     results.append({
#                         "file_name": file_name,
#                         "file_type": file_type,
#                         "file_date": str(obj.get("LastModified")),
#                         "key": key
#                     })

#         return results

#     except Exception as e:
#         logger.error(f"[TOOL2 ERROR] {str(e)}")
#         raise Exception(f"Tool2 failed: {str(e)}")


# # ============================================================
# # TOOL 3
# # input: schema_name, table_name, filters, limit
# # return: rows (list of dict)
# # ============================================================

# async def tool3_get_table_data(
#     schema_name: str,
#     table_name: str,
#     filters: Optional[Dict[str, Any]] = None,
#     limit: int = 100
# ) -> List[Dict[str, Any]]:
#     """
#     Fetch table data with optional filters
#     """

#     filters = filters or {}

#     try:
#         async with get_connection() as conn:

#             query = f'SELECT * FROM "{schema_name}"."{table_name}"'
#             conditions = []
#             values = []

#             for idx, (col, val) in enumerate(filters.items()):
#                 conditions.append(f'"{col}" = ${idx + 1}')
#                 values.append(val)

#             if conditions:
#                 query += " WHERE " + " AND ".join(conditions)

#             query += f" LIMIT {limit}"

#             rows = await conn.fetch(query, *values)

#             return [dict(r) for r in rows]

#     except Exception as e:
#         logger.error(f"[TOOL3 ERROR] {str(e)}")
#         raise Exception(f"Tool3 failed: {str(e)}")


# # ============================================================
# # TOOL 4
# # input: file_data (base64), fields_extraction, model_id
# # return: extracted fields
# # ============================================================

# async def tool4_extract_fields_with_llm(
#     file_data_base64: str,
#     file_name: str,
#     fields_extraction: List[Dict[str, Any]],
#     model_id: str,
#     content_type: str = "application/octet-stream"
# ) -> Dict[str, Any]:
#     """
#     Extract fields using LLM (DocumentService)
#     """

#     try:
#         import base64

#         file_bytes = base64.b64decode(file_data_base64)

#         extracted = await document_service.extract_fields(
#             file_bytes=file_bytes,
#             content_type=content_type,
#             fields=fields_extraction,
#             model=model_id
#         )

#         return {
#             "file_name": file_name,
#             "extracted_data": extracted,
#             "fields_schema": fields_extraction
#         }

#     except Exception as e:
#         logger.error(f"[TOOL4 ERROR] {str(e)}")
#         raise Exception(f"Tool4 failed: {str(e)}")