import base64
from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential


class AzureDocumentService:

    def __init__(self, endpoint: str, key: str):
        self.client = DocumentAnalysisClient(
            endpoint=endpoint,
            credential=AzureKeyCredential(key)
        )

    async def analyze_file(self, file_bytes: bytes, content_type: str, model: str):
        # Azure SDK is sync → run in thread if needed
        poller = self.client.begin_analyze_document(
            model,
            document=file_bytes
        )

        result = poller.result()

        # Extract full text
        content = ""
        for page in result.pages:
            for line in page.lines:
                content += line.content + "\n"

        return {
            "content": content,
            "model_used": model
        }