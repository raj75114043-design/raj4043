import asyncio
import json
from asyncpg import Connection
from app.db.pool import get_connection
from app.services.workflow_email_send import(
    send_workflow_step_email,
)
from app.utils.timezone import get_datetime_now_without_zone
from app.config.data_fetch_config import EMAIL_DOC_AGENT_SCHEMA

CHECK_WORKFLOW_EMAIL_INTERVAL = 300  #seconds

async def safe_workflow_email_task(**kwargs):

    try:

        return await asyncio.wait_for(
            send_workflow_step_email(**kwargs),
            timeout=180
        )

    except asyncio.TimeoutError:
        print("[EMAIL TASK TIMEOUT]")

        return {
            "status": "timeout",
            "error": "Execution exceeded time limit"
        }
    
    except Exception as e:
        print(f"[EMAIL TASK FAILED] {repr(e)}")
        return {
            "status": "failed",
            "error": str(e)
        }

async def run_workflow_email_scheduler():

    while True:

        try: 
            DATE_TIME_WITHOUT_ZONE = get_datetime_now_without_zone()
            print(f"[{DATE_TIME_WITHOUT_ZONE}] Checking schedules...")

            async with get_connection() as db:

                QUERY = f"""
                    WITH base_time AS (
                        SELECT
                            (
                                ($1::timestamp AT TIME ZONE 'Asia/Kolkata')
                                AT TIME ZONE COALESCE(w.schedule_time_zone, 'Asia/Kolkata')
                            ) AS local_ts,
                            w.*
                        FROM {EMAIL_DOC_AGENT_SCHEMA}.workflow_email_scheduled_jobs w
                    )

                    SELECT *
                    FROM base_time
                    WHERE is_enabled = TRUE
                    AND schedule_time <= (local_ts)::time

                    AND TRIM(UPPER(
                        TO_CHAR(local_ts, 'DAY')
                    )) = ANY(days_of_week)

                    AND (
                        last_run_time IS NULL

                        OR (
                            (last_run_time AT TIME ZONE COALESCE(schedule_time_zone, 'Asia/Kolkata'))::date
                            < (local_ts)::date
                        )

                        OR (
                            LOWER(last_run_mail_status) <> 'sent'
                            AND
                            (last_run_time AT TIME ZONE COALESCE(schedule_time_zone, 'Asia/Kolkata'))::date
                            = (local_ts)::date
                        )
                    )

                    ORDER BY step_id;
                """

                rows = await db.fetch(
                    QUERY,
                    DATE_TIME_WITHOUT_ZONE,
                )

            print(
                f"[WORKFLOW EMAIL JOB START] Schedules found: {[(r['workflow_name'], r['step_id']) for r in rows]}"
            )

            tasks = []
            for r in rows:

                global_filters = r.get("global_filters")
                if isinstance(global_filters, str):
                    try:
                        global_filters = json.loads(global_filters)
                    except Exception:
                        global_filters = {}
     

                tasks.append(
                    safe_workflow_email_task(
                        db=db,
                        token_id=r['token_id'],
                        scheduled_id=r['scheduled_id'],
                        workflow_name=r["workflow_name"],
                        step_id=r["step_id"],
                        to_list=r["to_list"],
                        cc_list=r["cc_list"],
                        bcc_list=r["bcc_list"],
                        allowed_sites=r["allowed_sites"],
                        columns_name=r.get("columns_name") or [],
                        global_filters=global_filters or {},
                        user_id=r["scheduled_by"],
                    )
                )

            results = await asyncio.gather(*tasks, return_exceptions=True)

            for r, result in zip(rows, results):

                if isinstance(result, Exception):
                    status = "failed"
                    print(f"[TASK ERROR] {result}")
                else:
                    status = result.get("status", "failed")

                print(f"WORKFLOW EMAIL COMPLETED {r['workflow_name']} : step {r['step_id']} - {status} for scheduled_id: {r['scheduled_id']}")

                DATE_TIME_WITHOUT_ZONE = get_datetime_now_without_zone()

                await db.execute(
                    f"""
                    UPDATE {EMAIL_DOC_AGENT_SCHEMA}.workflow_email_scheduled_jobs
                    SET last_run_time = $3,
                        last_run_mail_status = $2
                    WHERE scheduled_id = $1
                    """,
                    r["scheduled_id"],
                    status,
                    DATE_TIME_WITHOUT_ZONE
                )
                print(f"[WORKFLOW EMAIL JOB DONE] Workflow Schedule Tracker Updated for  {r['workflow_name']} : {r['step_id']}")

        except Exception as e:
            print(f"[SCHEDULER ERROR] {e}")

        await asyncio.sleep(CHECK_WORKFLOW_EMAIL_INTERVAL)
    