import json
from typing import List, Dict, Optional
from app.core.llm_client import get_llm_client
from app.services.azure_doc_api_endpoint import AzureDocumentService


class DocumentService:

    def __init__(self, config: dict):
        self.azure = AzureDocumentService(
            endpoint=config["azure_doc_intelligence"]["endpoint"],
            key=config["azure_doc_intelligence"]["key"]
        )

        self.models = config["document_models"]["models"]
        self.default_model = config["document_models"]["default"]

        self.model_map = {m["id"]: m for m in self.models}
        self.allowed_models = set(self.model_map.keys())

        self.max_text_length = config["limits"]["max_text_length"]

    def validate_model(self, model: Optional[str]) -> str:
        if not model:
            return self.default_model
        if model not in self.allowed_models:
            raise ValueError(f"Model '{model}' not allowed")
        return model


    async def extract_raw_fields(
        self,
        file_bytes: bytes,
        content_type: str,
        model: Optional[str]
    ):
        model = self.validate_model(model)

        parsed = await self.azure.analyze_file(
            file_bytes=file_bytes,
            content_type=content_type,
            model=model
        )

        return parsed.get("content", "")


    async def extract_fields(
        self,
        file_bytes: bytes,
        content_type: str,
        fields: List[Dict],
        model: Optional[str],
        parsing_context: Optional[str] = None   # NEW (optional, backward safe)
    ):
        

        model = self.validate_model(model)

        parsed = await self.azure.analyze_file(
            file_bytes=file_bytes,
            content_type=content_type,
            model=model
        )

        text = parsed.get("content", "")
        print(">>>>>>>>>> Dcoument Extraction usign Azure Doc Done - Now using LLM")

        if len(text) > self.max_text_length:
            text = text[:self.max_text_length]

        llm = get_llm_client("medium")

        prompt = f"""
You are a strict information extraction engine.

EXTRACTION CONTEXT:
{parsing_context if parsing_context else "General document extraction"}

SCHEMA (STRICT OUTPUT KEYS):
{fields}

IMPORTANT RULES:

1. OUTPUT FORMAT

- If document contains ONLY ONE logical record:
  return a SINGLE JSON OBJECT

Example:
{{
  "Field_1": "value",
  "Field_2": "value"
}}

- If document contains MULTIPLE logical records / rows:
  return a JSON ARRAY OF OBJECTS

Example:
[
  {{
    "Field_1": "value",
    "Field_2": "value"
  }},
  {{
    "Field_1": "value",
    "Field_2": "value"
  }}
]

2. FIELD RULES

- Output JSON keys MUST EXACTLY match "name" field in schema
- DO NOT use synonyms as output keys
- Synonyms are only hints for understanding
- If multiple synonyms match, map to correct schema field
- Use null if value not found
- Do NOT add extra keys
- Every row/object MUST contain ALL schema fields

3. OUTPUT RULES

- Output ONLY valid JSON
- No markdown
- No explanation
- No comments
- No extra text before or after JSON

INPUT TEXT:
{text}
"""

        response = llm.invoke(prompt)
        content = response.content.strip()

        if content.startswith("```"):
            content = content.split("```")[1].strip()

        try:
            data = json.loads(content)
        except Exception:
            data = {}

        if isinstance(data, list):

            final_rows = []

            for row in data:
                final_rows.append(
                    self._enforce_types(fields, row)
                )

            return final_rows

        return self._enforce_types(fields, data)




    def _enforce_types(self, fields, data):

        def cast(v, t):
            try:
                if v is None:
                    return None
                if t == "int":
                    return int(v)
                if t == "float":
                    return float(v)
                return str(v)
            except:
                return None

        result = {}

        for f in fields:
            key = f["name"]
            dtype = f["type"]

            # ONLY strict match
            value = data.get(key)

            result[key] = cast(value, dtype)

        return result
    

