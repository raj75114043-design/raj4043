import base64
import csv
import io
import json
import requests
import asyncio
import re
import time
from uuid import UUID
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Tuple
from asyncpg import Connection
from app.utils.timezone import get_datetime_now_without_zone
from app.config.email_config import(
    AUTH_URL,
    SEND_MAIL_URL,
    AUTH_PAYLOAD,
)

# ---------------------------------------------------------------------------
# Mail gateway
# ---------------------------------------------------------------------------

def get_session_id() -> str:

    session = requests.Session()

    resp = session.post(
        AUTH_URL,
        json=AUTH_PAYLOAD,
        headers={"Content-Type": "application/json"},
        timeout=300,
    )

    resp.raise_for_status()
    session_id = session.cookies.get("session_id")

    if not session_id:
        raise RuntimeError("Authentication failed — session_id missing")
    return session_id


def send_email_via_gateway(
    session_id: str,
    to_list: List[str],
    cc_list: List[str],
    bcc_list: List[str],
    subject: str,
    body: str,
    attachments: List[Dict[str, str]],
) -> Dict[str, Any]:

    # log("Sending email via gateway")

    payload = {
        "params": {
            # "from_mail":"shalini.a.ext@nokia.com",
            "tolist": to_list,
            "cclist": cc_list,
            "bcclist": bcc_list,
            "subject": subject,
            "body": body,
            "file": attachments,
        }
    }

    resp = requests.post(
        SEND_MAIL_URL,
        json=payload,
        headers={
            "Content-Type": "application/json",
            "Cookie": f"session_id={session_id}",
        },
        # timeout=120,
    )

    resp.raise_for_status()
    return resp.json()
