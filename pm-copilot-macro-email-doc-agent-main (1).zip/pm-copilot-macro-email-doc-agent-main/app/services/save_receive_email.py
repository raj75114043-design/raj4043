import json
import base64
from typing import List, Optional
from datetime import datetime
from app.utils.timezone import get_datetime_now_without_zone
from app.config.data_fetch_config import EMAIL_DOC_AGENT_SCHEMA

async def save_received_email(
    db,
    email_from: str,
    to_list: List[str],
    cc_list: List[str],
    subject: str,
    body: str,
    received_time: str,
    attachments: Optional[List[dict]] = None,
):
    """
    Save received email into DB
    """

    try:
        time_now = get_datetime_now_without_zone()

        query = f"""
            INSERT INTO {EMAIL_DOC_AGENT_SCHEMA}.email_received_tracker (
                email_from,
                to_list,
                cc_list,
                subject,
                body,
                received_time,
                attachments
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb)
            RETURNING id
        """

        result = await db.fetchrow(
            query,
            email_from,
            to_list,              
            cc_list,
            subject,
            body,
            received_time,
            json.dumps(attachments or [])
        )


        return {
            "id": result["id"],
            "message": "Email stored successfully"
        }

    except Exception as e:
        raise