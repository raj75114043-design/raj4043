import base64
import csv
import io
import json
import asyncio
import re
import time
from uuid import UUID
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Tuple
from asyncpg import Connection
from langchain_openai import ChatOpenAI
from app.utils.timezone import get_datetime_now_without_zone
from app.core.llm_client import get_llm_client
from app.services.workflow_load_execution import load_latest_workflow_execution
from app.config.data_fetch_config import EMAIL_DOC_AGENT_SCHEMA
from app.services.send_email_gateway import (
    get_session_id,
    send_email_via_gateway,
)

AllowedSites = Literal["FAIL", "PASS", "ALL"]

# ---------------------------------------------------------------------------
# Step config
# ---------------------------------------------------------------------------

async def fetch_step_config(
    db: Connection,
    workflow_name: str,
    step_id: str,
) -> Dict[str, Any]:

    # log(f"Fetching step config | workflow={workflow_name} step_id={step_id}")

    execution_data = await load_latest_workflow_execution(db, workflow_name)

    step_results: List[Dict[str, Any]] = execution_data.get("step_results", [])

    for step in step_results:
        if str(step.get("step_id", "")) == str(step_id):
            return step

    raise ValueError(f"Step '{step_id}' not found in workflow '{workflow_name}'.")


# ---------------------------------------------------------------------------
# Output table fetch
# ---------------------------------------------------------------------------

def _normalize_identifier(name: str) -> str:
    return re.sub(r"\s+", "_", name.strip()).lower()


async def fetch_step_output(
    db: Connection,
    allowed_sites: AllowedSites,
    columns_name: List[str] = None,
    global_filters: Dict[str, List[str]] = None,
    step_config: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:

    output_table: Optional[str] = step_config.get("output_table")

    if not output_table:
        return []

    try:
        if columns_name:
            selected_columns = ", ".join(columns_name)
        else:
            selected_columns = "*"
            
        query = f"SELECT DISTINCT {selected_columns} FROM {output_table}"

        conditions = []
        values = []
        param_index = 1

        if allowed_sites != "ALL":
            conditions.append(f"final_status = ${param_index}")
            values.append(allowed_sites)
            param_index += 1

        if global_filters:
            for column, filter_values in global_filters.items():
                if not filter_values:
                    continue

                placeholders = []
                normalized_values = []

                for val in filter_values:
                    placeholders.append(f"${param_index}")
                    normalized_values.append(val.lower())
                    param_index += 1

                values.extend(normalized_values)
                conditions.append(f"LOWER({column}) IN ({', '.join(placeholders)})")

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        # print("QUERY:", query)
        # print("VALUES:", values)

        rows = await db.fetch(query, *values)

    except Exception as e:
        print(f"[FETCH ERROR] {e}")
        raise

    return [dict(row) for row in rows]


# ---------------------------------------------------------------------------
# CSV builder
# ---------------------------------------------------------------------------

def build_csv_attachment(rows: List[Dict[str, Any]], filename: str) -> Dict[str, str]:

    if not rows:
        encoded = base64.b64encode(b"No data available").decode()
        return {"filename": filename, "filedata": encoded}

    buf = io.StringIO()

    writer = csv.DictWriter(buf, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

    encoded = base64.b64encode(buf.getvalue().encode()).decode()
    # print("Encoded: ", encoded)

    return {"filename": filename, "filedata": encoded}


# ---------------------------------------------------------------------------
# LLM email generation
# ---------------------------------------------------------------------------

def generate_email_content(
    llm: ChatOpenAI,
    workflow_name: str,
    step_config: Dict[str, Any],
    rows: List[Dict[str, Any]],
    allowed_sites,
) -> Tuple[str, str]:

    current_time = datetime.now().isoformat()
    sample = rows[:5] if rows else []

    prompt = f"""
You are generating a professional workflow notification email for a telecom network operations team.

Context:
- Workflow      : {workflow_name}
- Step ID       : {step_config.get("step_id")}
- Step Name     : {step_config.get("step_name")}
- Description   : {step_config.get("step_description")}
- Phase         : {step_config.get("phase_name")}
- Filter        : final_status = {allowed_sites}
- Rows in email : {len(rows)}
- Generated at  : {current_time}

Return ONLY valid JSON.

Format:
{{
  "subject": "<concise: [PMCopilot] Workflow | Step Name | Filter | N sites>",
  "body": "<complete HTML email with inline CSS only>"
}}

Rules:
- Do NOT include markdown fences
- Do NOT include explanation text
- Do NOT inlcude any raw data
- Escape quotes properly inside HTML
- Dont add links or email addresses
"""

    response = llm.invoke(prompt)
    raw = response.content.strip()

    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]

    raw = raw.strip()

    # Extract JSON block safely
    match = re.search(r"\{.*\}", raw, re.DOTALL)

    if not match:
        raise ValueError(f"LLM did not return valid JSON:\n{raw}")

    json_text = match.group(0)

    try:
        parsed = json.loads(json_text)

    except json.JSONDecodeError:
        # Attempt repair for common escape issues
        json_text = json_text.replace("\\", "\\\\")
        parsed = json.loads(json_text)

    subject = parsed.get("subject", "Workflow Notification")
    body = parsed.get("body", "<html><body>Email content unavailable</body></html>")

    return subject, body


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------

async def send_workflow_step_email(
    db,
    user_id: str,
    token_id: str,
    scheduled_id: str,
    workflow_name: str,
    step_id: int,
    to_list: List[str],
    cc_list: List[str],
    bcc_list: List[str],
    allowed_sites: AllowedSites,
    columns_name: List[str],
    global_filters: Dict[str, List[str]],
    llm: Optional[ChatOpenAI] = None,
    progress_callback=None,
) -> Dict[str, Any]:
        
    if llm is None:
        llm = get_llm_client("medium")
        
    step_config = await fetch_step_config(db, workflow_name, step_id)
    if progress_callback:
        progress_callback("OUTPUT_DATA_LOADING...")

    rows = await fetch_step_output(
        db,
        allowed_sites,
        columns_name,
        global_filters,
        step_config,
    )
    if progress_callback:
        progress_callback("EMAIL BODY GENERATING...")

    skip_email = False
    email_status = "failed"
    failed_error = None

    if len(rows) == 0:
        skip_email = True
        email_status = "failed"
        failed_error = f"No rows found"

    is_success = False
    subject = None
    result = None
    csv_filename = None
    time_taken_by_api = None

    try:

        if not skip_email:

            subject, body = await asyncio.to_thread(
                generate_email_content,
                llm,
                workflow_name,
                step_config,
                rows,
                allowed_sites,
            )
            if progress_callback:
                progress_callback("BUILDING OUTPUT AS ATTACHMENT FILE...")

            step_name_safe = _normalize_identifier(
                step_config.get("step_name", step_id)
            )

            csv_filename = f"{_normalize_identifier(workflow_name)}_{step_name_safe}_{allowed_sites}.csv"
            attachment = build_csv_attachment(rows, csv_filename)
            if progress_callback:
                progress_callback("CONNECTING WITH NERVE CENTRE API...")

            start_time = time.perf_counter()

            session_id = await asyncio.to_thread(get_session_id)
            if progress_callback:
                progress_callback("MAIL_GATEWAY_AUTHENTICATED AND SENDING...")

            result = await asyncio.to_thread(
                send_email_via_gateway,
                session_id,
                to_list,
                cc_list,
                bcc_list,
                subject,
                body,
                [attachment],
            )
            end_time = time.perf_counter()
            time_taken_by_api = end_time - start_time
            if progress_callback:
                progress_callback("EMAIL_SENT")

            if result and isinstance(result, dict):
                email_status = result.get("result", {}).get("status", "unknown")
                if email_status.lower().startswith("success"):
                    email_status = "sent"
                else:
                    failed_error = str(result)
            else:
                failed_error = f"Invalid gateway response: {result}"

    except Exception as e:
        if 'start_time' in locals():
            end_time = time.perf_counter()
            time_taken_by_api = end_time - start_time
        failed_error = str(e)
        email_status = "failed"
        print(f"[EMAIL ERROR] {e}")

    finally:
        DATE_TIME = get_datetime_now_without_zone()

        try:
            await db.execute(
                f"""
                INSERT INTO {EMAIL_DOC_AGENT_SCHEMA}.workflow_email_sent_history (
                    token_id,
                    scheduled_id,
                    workflow_name,
                    step_id,
                    allowed_sites,
                    columns_name,
                    global_filters,
                    to_list,
                    cc_list,
                    bcc_list,
                    sent_at,
                    mail_status,
                    failed_error,
                    user_id,
                    time_taken_by_api
                )
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
                """,
                token_id,
                scheduled_id,
                workflow_name,
                step_id,
                allowed_sites,
                columns_name,
                json.dumps(global_filters),
                to_list,
                cc_list,
                bcc_list,
                DATE_TIME,
                email_status,
                failed_error,
                user_id,
                round(time_taken_by_api, 2) if time_taken_by_api is not None else None,
            )

            print(f"[Email Sent History] DB Updated for {workflow_name} - {step_id}")

        except Exception as db_error:
            print(f"[HISTORY INSERT FAILED] {db_error}")
        
    return {
        "status": email_status,
        "subject": subject,
        "step_name": step_config.get("step_name"),
        "total_rows": len(rows),
        "attachment": csv_filename,
        "gateway_response": result,
    }

