import re
from app.utils.users_email import USER_CACHE

EMAIL_REGEX = re.compile(
    r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"
)


def normalize_email(email: str):
    return email.strip().lower()


def is_email(value: str):
    return "@" in value


def validate_email(email: str):
    return bool(EMAIL_REGEX.match(email))


def is_valid_nokia_email(email: str):
    return email.lower().endswith("@nokia.com")


def split_recipients(values):

    direct_emails = []
    unresolved_names = []

    for item in values:

        item = item.strip()

        if not item:
            continue

        if is_email(item):

            email = normalize_email(item)

            if not validate_email(email):
                continue

            if not is_valid_nokia_email(email):
                continue

            direct_emails.append(email)

        else:
            unresolved_names.append(item.lower())

    return direct_emails, unresolved_names




# =========================================================
# NORMALIZE
# =========================================================
def normalize(text: str) -> str:
    return text.lower().strip()


def tokenize(text: str):
    return set(normalize(text).split())


# =========================================================
# CORE RESOLVER (DEBUG ENABLED)
# =========================================================
def resolve_user(name: str):

    # print("\n================ RESOLVE USER ================\n")
    # print("RAW NAME:", repr(name))

    name = normalize(name)
    query_tokens = tokenize(name)

    # print("NORMALIZED NAME:", name)
    # print("QUERY TOKENS:", query_tokens)

    prefix_matches = []
    suffix_matches = []
    token_matches = []

    # =====================================================
    # LOOP CACHE
    # =====================================================
    for cached_name, email in USER_CACHE["data"]:

        cached_name_norm = normalize(cached_name)
        cached_tokens = tokenize(cached_name_norm)

        # print("\n--- CHECKING ---")
        # print("CACHED NAME:", cached_name_norm)
        # print("EMAIL:", email)
        # print("CACHED TOKENS:", cached_tokens)

        # =================================================
        # EXACT MATCH
        # =================================================
        if name == cached_name_norm:
            # print(">>> EXACT MATCH FOUND")
            return {
                "status": "resolved",
                "email": email
            }

        # =================================================
        # PREFIX MATCH
        # =================================================
        if cached_name_norm.startswith(name):
            # print(">>> PREFIX MATCH")
            prefix_matches.append(email)

        # =================================================
        # SUFFIX MATCH
        # =================================================
        elif cached_name_norm.endswith(name):
            # print(">>> SUFFIX MATCH")
            suffix_matches.append(email)

        # =================================================
        # TOKEN MATCH
        # =================================================
        elif query_tokens & cached_tokens:
            # print(">>> TOKEN MATCH:", query_tokens & cached_tokens)
            token_matches.append(email)

        # else:
        #     # print(">>> NO MATCH")

    # =====================================================
    # DEDUPE
    # =====================================================
    def dedupe(lst):
        return list(set(lst))

    prefix_matches = dedupe(prefix_matches)
    suffix_matches = dedupe(suffix_matches)
    token_matches = dedupe(token_matches)

    # print("\n================ MATCH SUMMARY ================")
    # print("PREFIX:", prefix_matches)
    # print("SUFFIX:", suffix_matches)
    # print("TOKEN :", token_matches)

    # =====================================================
    # PRIORITY DECISION
    # =====================================================

    final = []

    if prefix_matches:
        # print(">>> USING PREFIX MATCHES")
        final = prefix_matches

    elif suffix_matches:
        # print(">>> USING SUFFIX MATCHES")
        final = suffix_matches

    else:
        # print(">>> USING TOKEN MATCHES")
        final = token_matches

    # print("FINAL CANDIDATES:", final)

    # =====================================================
    # RETURN LOGIC
    # =====================================================

    if len(final) == 1:
        # s(">>> RESOLVED")
        return {
            "status": "resolved",
            "email": final[0]
        }

    if len(final) > 1:
        # print(">>> AMBIGUOUS")
        return {
            "status": "ambiguous",
            "matches": final
        }

    # print(">>> NOT FOUND")
    return {
        "status": "not_found"
    }