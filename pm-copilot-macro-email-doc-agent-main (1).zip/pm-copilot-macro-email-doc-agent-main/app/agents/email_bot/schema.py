from typing import List, Dict, Optional
from pydantic import BaseModel, Field


class AmbiguousRecipient(BaseModel):
    query: str
    matches: List[str]


class UnresolvedRecipient(BaseModel):
    name: str
    type: str   # "to" | "cc" | "bcc"


class EmailState(BaseModel):

    # INPUT
    user_id: str
    user_input: str

    # RAW EXTRACTION
    raw_to: List[str] = Field(default_factory=list)
    raw_cc: List[str] = Field(default_factory=list)
    raw_bcc: List[str] = Field(default_factory=list)

    # FINAL RESOLVED
    to_list: List[str] = Field(default_factory=list)
    cc_list: List[str] = Field(default_factory=list)
    bcc_list: List[str] = Field(default_factory=list)

    # SPLIT TRACKING
    unresolved: List[UnresolvedRecipient] = Field(default_factory=list)

    # AMBIGUITY
    ambiguous_recipients: List[AmbiguousRecipient] = Field(default_factory=list)

    # EMAIL CONTENT
    subject: Optional[str] = None
    body: Optional[str] = None
    attachments: List[Dict] = Field(default_factory=list)

    # FLOW CONTROL
    requires_human: bool = False
    human_message: Optional[str] = None
    is_ready: bool = False
    

class ResolutionItem(BaseModel):
    query: str
    selected_email: str


class ActionRequest(BaseModel):
    draft_id: str
    user_id: str
    resolutions: List[ResolutionItem]
    confirm: bool = False