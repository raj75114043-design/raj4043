import json
import re

from app.core.llm_client import get_llm_client
from .schema import AmbiguousRecipient, UnresolvedRecipient
from .prompts import build_extract_prompt
from .tools import split_recipients, resolve_user

llm = get_llm_client(tier="low")


def clean_llm_json(raw: str):
    cleaned = re.sub(r"```json|```", "", raw).strip()
    return json.loads(cleaned)


# =========================================================
# EXTRACT
# =========================================================
async def extract_intent(state):

    prompt = build_extract_prompt(
        user_id=state.user_id,
        user_input=state.user_input
    )

    response = await llm.ainvoke(prompt)
    print("LLM Response: ", response)

    data = clean_llm_json(response.content)

    state.raw_to = data.get("to", []) or []
    state.raw_cc = data.get("cc", []) or []
    state.raw_bcc = data.get("bcc", []) or []

    if isinstance(state.raw_to, str):
        state.raw_to = [state.raw_to]
    if isinstance(state.raw_cc, str):
        state.raw_cc = [state.raw_cc]
    if isinstance(state.raw_bcc, str):
        state.raw_bcc = [state.raw_bcc]

    state.subject = data.get("subject")
    state.body = data.get("body")

    return state


# =========================================================
# VALIDATE
# =========================================================
async def validate_intent(state):
    if not state.raw_to:
        raise ValueError("At least one recipient required")
    return state


# =========================================================
# SPLIT RECIPIENTS (FIXED)
# =========================================================
async def split_all_recipients(state):

    state.unresolved = []  # RESET

    to_direct, to_names = split_recipients(state.raw_to)
    cc_direct, cc_names = split_recipients(state.raw_cc)
    bcc_direct, bcc_names = split_recipients(state.raw_bcc)

    state.to_list.extend(to_direct)
    state.cc_list.extend(cc_direct)
    state.bcc_list.extend(bcc_direct)

    for name in to_names:
        state.unresolved.append(UnresolvedRecipient(name=name, type="to"))

    for name in cc_names:
        state.unresolved.append(UnresolvedRecipient(name=name, type="cc"))

    for name in bcc_names:
        state.unresolved.append(UnresolvedRecipient(name=name, type="bcc"))

    print("[SPLIT] TO:", state.to_list)
    print("[SPLIT] CC:", state.cc_list)
    print("[SPLIT] BCC:", state.bcc_list)
    print("[SPLIT] UNRESOLVED:", state.unresolved)

    return state


# =========================================================
# ROUTER
# =========================================================
def recipient_router(state):
    return "resolve" if state.unresolved else "draft"


# =========================================================
# RESOLVE (FIXED ROUTING)
# =========================================================
async def resolve_recipients(state):

    new_unresolved = []

    for item in state.unresolved:

        name = item.name
        rtype = item.type

        result = resolve_user(name)

        if result["status"] == "resolved":

            email = result["email"]

            if rtype == "to":
                state.to_list.append(email)
            elif rtype == "cc":
                state.cc_list.append(email)
            elif rtype == "bcc":
                state.bcc_list.append(email)

        elif result["status"] == "ambiguous":

            state.requires_human = True

            state.ambiguous_recipients.append(
                AmbiguousRecipient(
                    query=f"{rtype}:{name}",
                    matches=result["matches"]
                )
            )

        else:
            new_unresolved.append(item)

    state.unresolved = new_unresolved

    return state


# =========================================================
# HUMAN ROUTER
# =========================================================
def human_router(state):
    if state.requires_human and state.ambiguous_recipients:
        return "human"
    return "draft"


# =========================================================
# HUMAN REVIEW (FIXED STRING BUG)
# =========================================================
async def human_review(state):

    messages = []

    for item in state.ambiguous_recipients:
        text = f"\nWhich '{item.query}' do you mean?\n"

        for idx, email in enumerate(item.matches, start=1):
            text += f"{idx}. {email}\n"

        messages.append(text)

    state.human_message = "\n".join(messages)
    state.is_ready = False

    return state


# =========================================================
# DRAFT
# =========================================================
async def draft_email(state):

    if state.requires_human and state.ambiguous_recipients:
        raise ValueError("Cannot draft email: unresolved recipients exist")

    state.to_list = list(set(state.to_list))
    state.cc_list = list(set(state.cc_list))
    state.bcc_list = list(set(state.bcc_list))

    state.subject = state.subject or "Request"

    state.body = state.body or """
<p>Hi Team,</p>
<p>Please ignore this mail.</p>
<p>Thanks</p>
"""

    state.is_ready = True
    return state