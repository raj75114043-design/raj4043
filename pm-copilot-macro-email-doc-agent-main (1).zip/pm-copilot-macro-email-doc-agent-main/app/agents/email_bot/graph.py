from langgraph.graph import StateGraph, END
from .schema import EmailState
from .nodes import (
    extract_intent,
    validate_intent,
    split_all_recipients,
    recipient_router,
    resolve_recipients,
    human_router,
    human_review,
    draft_email,
)


def build_graph():

    graph = StateGraph(EmailState)

    graph.add_node("extract", extract_intent)
    graph.add_node("validate", validate_intent)
    graph.add_node("split", split_all_recipients)
    graph.add_node("resolve", resolve_recipients)
    graph.add_node("human_review", human_review)
    graph.add_node("draft", draft_email)

    graph.set_entry_point("extract")

    graph.add_edge("extract", "validate")
    graph.add_edge("validate", "split")

    graph.add_conditional_edges(
        "split",
        recipient_router,
        {"resolve": "resolve", "draft": "draft"}
    )

    graph.add_conditional_edges(
        "resolve",
        human_router,
        {"human": "human_review", "draft": "draft"}
    )

    graph.add_edge("human_review", END)
    graph.add_edge("draft", END)

    return graph.compile()


send_email_bot_graph = build_graph()