from enum import Enum
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from app.services.workflow_email_send import AllowedSites

class APIModel(BaseModel):
    """Base API model with unified serialization."""

    def to_dict(self) -> dict:
        return self.model_dump(exclude_none=True)
    

class WeekDay(str, Enum):
    MONDAY = "MONDAY"
    TUESDAY = "TUESDAY"
    WEDNESDAY = "WEDNESDAY"
    THURSDAY = "THURSDAY"
    FRIDAY = "FRIDAY"
    SATURDAY = "SATURDAY"
    SUNDAY = "SUNDAY"


class SendEmailAttachment(BaseModel):
    filename: str
    filedata: Optional[str] = None
    # s3_bucket_name: str = None
    # s3_key: str = None

class SendEmailRequest(BaseModel):
    user_id: str
    to_list: List[str]
    cc_list: List[str] = []
    bcc_list: List[str] = []
    subject: str
    email_body: str
    attachments: List[SendEmailAttachment] = []

class SendEmailStartResponse(BaseModel):
    token_id: str
    status: str

class SendEmailStatusResponse(BaseModel):
    token_id: str
    status: str
    stage: str
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

class ScheduleEmailRequest(BaseModel):
    user_id: str
    to_list: List[str]
    cc_list: List[str] = []
    bcc_list: List[str] = []
    subject: str
    email_body: str
    attachments: List[SendEmailAttachment] = []
    is_recurring: bool = True
    schedule_time: Optional[List[str]]
    schedule_time_zone: str = "UTC"
    days_of_week: Optional[List[WeekDay]]

class ScheduleEmailResponse(BaseModel):
    token_id: str
    status: str


class ReceivedEmailAttachment(BaseModel):
    file_name: str
    s3_bucket_name: str
    s3_key: str

class SaveReceivedEmail(BaseModel):
    email_from: str
    to_list: List[str]
    cc_list: List[str]
    subject: str
    body: str
    receivedTime: str
    attachments: Optional[List[ReceivedEmailAttachment]] = []