from pydantic import BaseModel
from typing import List, Dict


class ColumnInfo(BaseModel):
    column_name: str
    data_type: str


class TableInfo(BaseModel):
    table_name: str
    schema_name: str
    columns: List[ColumnInfo]


class TableMetadataResponse(BaseModel):
    table_count: int
    tables: List[TableInfo]
    message: str = None


class EmailIdItem(BaseModel):
    name: str
    email: str
