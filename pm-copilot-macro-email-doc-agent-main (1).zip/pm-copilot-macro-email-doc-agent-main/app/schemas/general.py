from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional

class APIModel(BaseModel):
    """Base API model with unified serialization."""

    def to_dict(self) -> dict:
        return self.model_dump(exclude_none=True)

class UserInfoRequest(BaseModel):
    user_id: str
    
class MessageResponse(BaseModel):
    """Generic message response."""

    message: str
    success: bool = True


class UpdateJobConfigRequest(BaseModel):
    json_config: Dict[str, Any]


from pydantic import BaseModel
from typing import List, Optional


class ReviewDraftMailRequest(BaseModel):
    reviewed_to_list: Optional[List[str]] = []
    reviewed_cc_list: Optional[List[str]] = []
    reviewed_bcc_list: Optional[List[str]] = []
    reviewed_email_subject: Optional[str] = None
    reviewed_email_body: Optional[str] = None
    reviewed_attachments: Optional[list] = []
    remarks: Optional[str] = None
    approved_by: Optional[str] = None



class CreateUseCaseRequest(BaseModel):
    json_config: Dict[str, Any]
    job_owner: List[str]
    schedule_run_times: List[str] = []
    days_of_week: List[str] = []
    timezone: str = "Asia/Kolkata"
    job_trigger_point: str  # RECEIVED_EMAIL / SCHEDULED_TIME
    view_to_all: bool = True