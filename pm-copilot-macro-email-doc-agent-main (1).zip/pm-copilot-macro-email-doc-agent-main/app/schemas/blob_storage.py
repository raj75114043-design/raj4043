from pydantic import BaseModel
from typing import Dict, List, Any, Union, Literal, Optional

AllowedSites = Literal["FAIL", "PASS", "ALL"]

class APIModel(BaseModel):
    """Base API model with unified serialization."""

    def to_dict(self) -> dict:
        return self.model_dump(exclude_none=True)
    

class WorkflowStepOutputtoBlob(BaseModel):
    workflow_name: str
    step_id: int
    allowed_sites: AllowedSites
    columns_name: List[str] = None,
    global_filters: Dict[str, List[str]] = None


class TableFilter(BaseModel):
    column: str
    values: List[str]

class TableToS3Request(BaseModel):
    schema_name: str
    table_name: str
    filters: Optional[List[TableFilter]] = []
    limit: Optional[int] = 1000