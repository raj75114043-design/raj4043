from pydantic import BaseModel
from typing import List, Literal, Optional, Dict
from enum import Enum

FieldType = Literal["string", "int", "float"]


class DocumentModelEnum(str, Enum):
    PREBUILT_READ = "prebuilt-read"
    PREBUILT_LAYOUT = "prebuilt-layout"
    PREBUILT_CONTRACT = "prebuilt-contract"
    PREBUILT_HEALTH_INSURANCE = "prebuilt-healthInsuranceCard.us"
    PREBUILT_ID = "prebuilt-idDocument"
    PREBUILT_INVOICE = "prebuilt-invoice"
    PREBUILT_RECEIPT = "prebuilt-receipt"
    PREBUILT_MARRIAGE = "prebuilt-marriageCertificate.us"
    PREBUILT_CREDIT_CARD = "prebuilt-creditCard"
    PREBUILT_CHECK = "prebuilt-check.us"
    PREBUILT_PAYSTUB = "prebuilt-payStub.us"
    PREBUILT_BANK = "prebuilt-bankStatement"

    PREBUILT_MORTGAGE_1003 = "prebuilt-mortgage.us.1003"
    PREBUILT_MORTGAGE_1004 = "prebuilt-mortgage.us.1004"
    PREBUILT_MORTGAGE_1005 = "prebuilt-mortgage.us.1005"
    PREBUILT_MORTGAGE_1008 = "prebuilt-mortgage.us.1008"
    PREBUILT_MORTGAGE_CLOSING = "prebuilt-mortgage.us.closingDisclosure"

    PREBUILT_TAX = "prebuilt-tax.us"
    PREBUILT_TAX_W2 = "prebuilt-tax.us.w2"
    PREBUILT_TAX_W4 = "prebuilt-tax.us.w4"
    PREBUILT_TAX_1040 = "prebuilt-tax.us.1040"
    PREBUILT_TAX_1095A = "prebuilt-tax.us.1095A"
    PREBUILT_TAX_1095C = "prebuilt-tax.us.1095C"
    PREBUILT_TAX_1098 = "prebuilt-tax.us.1098"
    PREBUILT_TAX_1098E = "prebuilt-tax.us.1098E"
    PREBUILT_TAX_1098T = "prebuilt-tax.us.1098T"
    PREBUILT_TAX_1099 = "prebuilt-tax.us.1099"
    PREBUILT_TAX_1099SSA = "prebuilt-tax.us.1099SSA"



class FieldSchema(BaseModel):
    name: str
    type: str


class ExtractFieldsRequest(BaseModel):
    name: str
    type: str
    synonyms: List[str] = []


class ExtractRawRequest(BaseModel):
    model: Optional[str] = None


class ExtractRawResponse(BaseModel):
    file_name: str
    model_id: str
    extracted_data: Dict


class ExtractRequest(BaseModel):
    fields: List[ExtractFieldsRequest]
    model: Optional[str] = None


class ExtractResponse(BaseModel):
    file_name: str
    model_id: Optional[str] = None
    fields_schema: Optional[List[ExtractFieldsRequest]] = None
    user_input: Optional[str] = None
    extracted_data: Dict

    
class ModelInfo(BaseModel):
    id: str
    category: str
    description: str


class DocumentChatRequest(BaseModel):
    session_id: str
    query: str
