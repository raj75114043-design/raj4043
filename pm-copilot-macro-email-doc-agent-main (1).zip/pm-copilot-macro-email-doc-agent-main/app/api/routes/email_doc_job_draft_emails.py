
import asyncio
import uuid
import json
import time
import json
import uuid
import uuid
import asyncio
from app.schemas.general import UserInfoRequest
from datetime import datetime
from typing import List, Optional, Dict, Any
from asyncpg import Connection
from app.db.pool import get_db
from typing import Literal
from typing import get_args
from fastapi import APIRouter, Depends, HTTPException, status, Body
from pydantic import BaseModel
from app.core.llm_client import get_llm_client
from pathlib import Path
from fastapi import APIRouter, Depends, BackgroundTasks, HTTPException
from app.services.azure_doc_parsing import DocumentService
from app.dependencies.azure_doc_intelligence import get_document_service
from app.services.s3_blob_management import S3Service
from app.dependencies.s3_blob import get_s3_service
from app.config.azure_doc_settings import get_config
from app.db.pool import get_db
from app.schemas.general import UpdateJobConfigRequest, ReviewDraftMailRequest, CreateUseCaseRequest
from fastapi import UploadFile, File, Form
from typing import get_args, get_origin
from pydantic import BaseModel
from app.utils.timezone import get_datetime_now_without_zone


from app.email_doc_job_engine.main_orchestrator.orchestrator import run_job


from app.email_doc_job_engine.utils.execution_store import (
    create_execution
)

from app.email_doc_job_engine.utils.execution_store import get_execution
    
from app.email_doc_job_engine.job_schema.job_config_class import JobConfig


router = APIRouter(prefix="/email-doc/job-orchestrator", tags=["Email-Document Job Draft Emails"])

JOB_TYPE = Literal["Email", "Document"]


# =========================================================
# GET ALL JOB IDs where APPROVAL REQUIRED
# =========================================================

@router.get("/live-status/{job_type}/get/job-ids/for-approval")
async def get_jobs_for_approval(
    job_type: JOB_TYPE,
    user_id: str,
    db: Connection = Depends(get_db),
):

    try:

        rows = await db.fetch(
            """
            SELECT job_id
            FROM macro_email_doc_agent.email_doc_usecase_jobs
            WHERE is_approval_required = TRUE
              AND approval_status IS NULL
              AND job_type = $1
            ORDER BY created_at DESC
            """,
            job_type,
        )

        job_ids = [row["job_id"] for row in rows]

        return {
            "status": "SUCCESS",
            "job_type": job_type,
            "count": len(job_ids),
            "job_ids": job_ids
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch jobs for approval: {str(e)}"
        )


# =========================================================
# GET ALL PENDING DRAFTED MAILS
# =========================================================

@router.get("/live-status/{job_type}/get/drafted-mails/{job_id}")
async def get_pending_mails(
    job_type: JOB_TYPE,
    job_id: str,
    user_id: str,
    db: Connection = Depends(get_db),
):

    try:

        records = await db.fetch(
            """
            SELECT
                id,
                job_id,
                to_list,
                cc_list,
                bcc_list,
                email_subject,
                email_body,
                attachments,
                is_approval_required,
                is_approved,
                created_at,
                updated_at,
                mail_status
            FROM macro_email_doc_agent.email_doc_usecase_jobs_email_send
            WHERE job_id = $1
            AND is_approval_required = TRUE
            AND is_approved IS NULL
            ORDER BY created_at DESC
            """,
            job_id
        )

        return {
            "status": "SUCCESS",
            "job_type": job_type,
            "user_id": user_id,
            "total": len(records),
            "data": [dict(r) for r in records]
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch drafted mails: {str(e)}"
        )
    

# =========================================================
# APPROVE / REVIEW DRAFT MAIL
# =========================================================

@router.post("/live-status/{job_type}/approve/drafted-mail/{job_id}/{id}/{approval_status}")
async def approve_drafted_mail(
    job_type: JOB_TYPE,
    job_id: str,
    id: int,
    approval_status: bool,
    user_id: str,
    payload: ReviewDraftMailRequest,
    db: Connection = Depends(get_db),
):

    try:
        mail_status=None
        now = datetime.now()

        # ============================================
        # 1. UPDATE SINGLE DRAFT MAIL
        # ============================================
        if approval_status:
            mail_status = "APPROVED"
        else:
            mail_status = "REJECTED"    


        record = await db.fetchrow(
            """
            UPDATE macro_email_doc_agent.email_doc_usecase_jobs_email_send
            SET
                reviewed_to_list = $1,
                reviewed_cc_list = $2,
                reviewed_bcc_list = $3,
                reviewed_email_subject = $4,
                reviewed_email_body = $5,
                reviewed_attachments = $6::jsonb,

                is_approved = $12,
                approved_by = $7,
                approved_at = $8,

                mail_status = $14,
                remarks = $9,

                updated_at = $10

            WHERE id = $11
            AND job_id = $13
            AND is_approval_required = TRUE
            RETURNING job_id
            """,
            payload.reviewed_to_list,
            payload.reviewed_cc_list,
            payload.reviewed_bcc_list,

            payload.reviewed_email_subject,
            payload.reviewed_email_body,

            json.dumps(payload.reviewed_attachments or []),

            payload.approved_by or str(user_id),
            now,

            payload.remarks,
            now,

            id,
            approval_status,
            job_id,
            mail_status
        )

        if not record:
            raise HTTPException(status_code=404, detail="Draft mail not found")

        job_id = record["job_id"]

        # ============================================
        # 2. CHECK IF ALL ROWS ARE APPROVED
        # ============================================

        pending_check = await db.fetchval(
            """
            SELECT COUNT(*)
            FROM macro_email_doc_agent.email_doc_usecase_jobs_email_send
            WHERE job_id = $1
              AND is_approval_required = TRUE
              AND is_approved IS NULL
            """,
            job_id
        )

        # ============================================
        # 3. IF NO PENDING APPROVALS → UPDATE JOB TABLE
        # ============================================

        if pending_check == 0:

            await db.execute(
                """
                UPDATE macro_email_doc_agent.email_doc_usecase_jobs
                SET
                    approval_status = TRUE,
                    updated_at = NOW()
                WHERE job_id = $1
                AND is_approval_required = TRUE
                """,
                job_id
            )

        return {
            "status": "SUCCESS",
            "message": "Draft mail approved successfully",
            "draft_mail_id": id,
            "job_id": job_id,
            "job_approval_status_updated": pending_check == 0,
            "approved_at": str(now)
        }

    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to approve drafted mail: {str(e)}"
        )
