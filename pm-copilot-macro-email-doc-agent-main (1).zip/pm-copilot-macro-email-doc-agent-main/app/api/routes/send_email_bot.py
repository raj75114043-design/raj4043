import asyncio
import uuid
import time

from fastapi import APIRouter, HTTPException

from app.agents.email_bot.graph import send_email_bot_graph
from app.agents.email_bot.schema import EmailState, ActionRequest
from app.services.workflow_email_send import send_email_via_gateway, get_session_id

router = APIRouter(prefix="/send-email-bot", tags=["Send Email Bot"])

DRAFT_STORE = {}
DRAFT_TTL = 300  # 5 minutes


# =========================================================
# CLEANUP TASK (optional)
# =========================================================

async def cleanup_drafts():
    while True:
        now = time.time()

        expired_keys = [
            k for k, v in DRAFT_STORE.items()
            if now - v["created_at"] > DRAFT_TTL
        ]

        for k in expired_keys:
            del DRAFT_STORE[k]

        await asyncio.sleep(300)


# =========================================================
# UTILS
# =========================================================
def is_expired(draft):
    return time.time() - draft["created_at"] > DRAFT_TTL


# =========================================================
# PREPARE
# =========================================================
@router.post("/prepare")
async def prepare_email_hitl(user_id: str, user_input: str):

    draft_id = str(uuid.uuid4())
    state = EmailState(user_id=user_id, user_input=user_input)

    try:
        result = await send_email_bot_graph.ainvoke(state)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    # =====================================================
    # BASE DRAFT
    # =====================================================
    draft = {
        "user_id": user_id,
        "created_at": time.time(),
        "email_data": {
            "to_list": result.get("to_list", []),
            "cc_list": result.get("cc_list", []),
            "bcc_list": result.get("bcc_list", []),
            "subject": result.get("subject"),
            "body": result.get("body"),
            "attachments": result.get("attachments", []),
        },
        "requires_human": bool(result.get("requires_human")),
        "ambiguities": {},
        "resolved_map": {}
    }

    # =====================================================
    # HITL CASE (FIXED STRUCTURE)
    # =====================================================
    if result.get("requires_human"):

        draft["ambiguities"] = {}

        for item in result.get("ambiguous_recipients", []):

            # IMPORTANT: extract clean query from "bcc:venkat"
            raw_query = item.query

            if ":" in raw_query:
                rtype, query = raw_query.split(":", 1)
            else:
                rtype, query = "to", raw_query

            draft["ambiguities"][query] = {
                "matches": item.matches,
                "type": rtype
            }

        DRAFT_STORE[draft_id] = draft

        return {
            "draft_id": draft_id,
            "status": "needs_clarification",
            "questions": [
                {
                    "query": item.query,   # UI keeps original format
                    "options": item.matches
                }
                for item in result.get("ambiguous_recipients", [])
            ]
        }

    # =====================================================
    # NO RECIPIENT CASE
    # =====================================================
    if not result.get("to_list"):
        raise HTTPException(status_code=400, detail="No recipient found")

    DRAFT_STORE[draft_id] = draft

    return {
        "draft_id": draft_id,
        "confirmation_required": True,
        "message": "Please confirm to send email",
        "email_preview": draft["email_data"]
    }

@router.post("/action")
async def resolve_and_confirm_email(payload: ActionRequest):

    # =====================================================
    # VALIDATION
    # =====================================================
    if payload.draft_id not in DRAFT_STORE:
        raise HTTPException(status_code=404, detail="Invalid draft_id")

    draft = DRAFT_STORE[payload.draft_id]

    if draft["user_id"] != payload.user_id:
        raise HTTPException(status_code=403, detail="Unauthorized user")

    if is_expired(draft):
        del DRAFT_STORE[payload.draft_id]
        raise HTTPException(status_code=410, detail="Draft expired")

    # =====================================================
    # APPLY RESOLUTIONS (FIXED)
    # =====================================================
    for item in payload.resolutions:

        raw_query = item.query
        selected_email = item.selected_email

        # -------------------------------------------------
        # extract type + clean key from "bcc:venkat"
        # -------------------------------------------------
        if ":" in raw_query:
            rtype, query = raw_query.split(":", 1)
            rtype = rtype.strip().lower()
            query = query.strip()
        else:
            rtype = "to"
            query = raw_query.strip()

        # =================================================
        # FIX: always lookup CLEAN query ONLY
        # =================================================
        if query not in draft["ambiguities"]:
            raise HTTPException(status_code=400, detail=f"Invalid query: {query}")

        ambiguity = draft["ambiguities"][query]
        options = ambiguity["matches"]

        if selected_email not in options:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid selection for {query}"
            )

        # =================================================
        # SAFE TYPE RESOLUTION
        # =================================================
        final_type = ambiguity["type"] or rtype

        if final_type == "to":
            draft["email_data"]["to_list"].append(selected_email)

        elif final_type == "cc":
            draft["email_data"]["cc_list"].append(selected_email)

        elif final_type == "bcc":
            draft["email_data"]["bcc_list"].append(selected_email)

        else:
            raise HTTPException(status_code=400, detail=f"Unknown type: {final_type}")

        # track resolution
        draft["resolved_map"][raw_query] = selected_email

        # remove using CLEAN key
        del draft["ambiguities"][query]

    # =====================================================
    # DEDUPE
    # =====================================================
    draft["email_data"]["to_list"] = list(set(draft["email_data"]["to_list"]))
    draft["email_data"]["cc_list"] = list(set(draft["email_data"]["cc_list"]))
    draft["email_data"]["bcc_list"] = list(set(draft["email_data"]["bcc_list"]))

    # =====================================================
    # CASE 1
    # =====================================================
    if draft["ambiguities"]:
        return {
            "status": "partially_resolved",
            "pending": draft["ambiguities"],
            "email_preview": draft["email_data"],
            "message": "Resolve remaining ambiguities"
        }

    draft["requires_human"] = False

    # =====================================================
    # CASE 2
    # =====================================================
    if not payload.confirm:
        return {
            "status": "resolved",
            "email_preview": draft["email_data"],
            "message": "Confirm to send email"
        }

    # =====================================================
    # CASE 3
    # =====================================================
    email_data = draft["email_data"]

    session_id = await asyncio.to_thread(get_session_id)

    response = await asyncio.to_thread(
        send_email_via_gateway,
        session_id,
        email_data["to_list"],
        email_data["cc_list"],
        email_data["bcc_list"],
        email_data.get("subject", "Test"),
        email_data.get("body", "Testing"),
        email_data.get("attachments", []),
    )

    status = "unknown"
    error = None

    if isinstance(response, dict):
        status_raw = response.get("result", {}).get("status", "")

        if "success" in str(status_raw).lower():
            status = "sent"
            DRAFT_STORE.pop(payload.draft_id, None)
        else:
            status = "failed"
            error = str(response)

    return {
        "status": status,
        "error": error,
        "email_data": email_data,
        "response": response
    }






# =========================================================
# AUTO SEND
# =========================================================
@router.post("/auto-send")
async def auto_send_email(user_id: str, user_input: str):

    try:
        state = EmailState(user_id=user_id, user_input=user_input)

        result = await send_email_bot_graph.ainvoke(state)

        if result.get("requires_human"):
            return {
                "status": "requires_clarification",
                "ambiguous": [
                    {
                        "query": f"Which {item.query} do you mean?",
                        "matches": item.matches
                    }
                    for item in result.get("ambiguous_recipients", [])
                ]
            }

        if not result.get("to_list"):
            raise HTTPException(status_code=400, detail="No recipient found")

        cc_list = list({
            *(e.strip().lower() for e in result.get("cc_list", []) if e),
            user_id.strip().lower()
        })

        session_id = await asyncio.to_thread(get_session_id)

        response = await asyncio.to_thread(
            send_email_via_gateway,
            session_id,
            result["to_list"],
            cc_list,
            result["bcc_list"],
            result.get("subject", "Test"),
            result.get("body", "Testing"),
            result.get("attachments", []),
        )

        status = "unknown"
        error = None

        if isinstance(response, dict):
            status_raw = response.get("result", {}).get("status", "")

            if "success" in str(status_raw).lower():
                status = "sent"
            else:
                error = str(response)

        return {
            "status": status,
            "error": error,
            "email_data": {
                "to_list": result.get("to_list"),
                "cc_list": cc_list,
                "subject": result.get("subject"),
            },
            "response": response
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Email send failed: {str(e)}")
    



# # =========================================================
# # RESOLVE
# # =========================================================
# @router.post("/resolve")
# async def resolve_recipient(
#     draft_id: str,
#     query: str,
#     selected_email: str,
#     user_id: str
# ):

#     # =====================================================
#     # VALIDATION
#     # =====================================================
#     if draft_id not in DRAFT_STORE:
#         raise HTTPException(status_code=404, detail="Invalid draft_id")

#     draft = DRAFT_STORE[draft_id]

#     if draft["user_id"] != user_id:
#         raise HTTPException(status_code=403, detail="Unauthorized user")

#     if is_expired(draft):
#         del DRAFT_STORE[draft_id]
#         raise HTTPException(status_code=410, detail="Draft expired")

#     # =====================================================
#     # CHECK AMBIGUITY
#     # =====================================================
#     if query not in draft["ambiguities"]:
#         raise HTTPException(status_code=400, detail="Invalid ambiguity query")

#     options = draft["ambiguities"][query]

#     if selected_email not in options:
#         raise HTTPException(status_code=400, detail="Invalid selection")

#     # =====================================================
#     # APPLY RESOLUTION
#     # =====================================================
#     draft["email_data"]["to_list"].append(selected_email)

#     draft["resolved_map"][query] = selected_email

#     # remove resolved ambiguity
#     del draft["ambiguities"][query]

#     # cleanup duplicates
#     draft["email_data"]["to_list"] = list(set(draft["email_data"]["to_list"]))

#     # =====================================================
#     # RESPONSE
#     # =====================================================
#     if draft["ambiguities"]:
#         return {
#             "status": "partially_resolved",
#             "pending": draft["ambiguities"],
#             "email_preview": draft["email_data"]
#         }

#     draft["requires_human"] = False

#     return {
#         "status": "resolved",
#         "email_preview": draft["email_data"]
#     }


# # =========================================================
# # CONFIRM SEND
# # =========================================================
# @router.post("/confirm")
# async def confirm_and_send_email(draft_id: str, user_id: str, confirm: bool):

#     if draft_id not in DRAFT_STORE:
#         raise HTTPException(status_code=404, detail="Invalid draft_id")

#     draft = DRAFT_STORE[draft_id]

#     if is_expired(draft):
#         del DRAFT_STORE[draft_id]
#         raise HTTPException(status_code=410, detail="Draft expired")

#     if draft["user_id"] != user_id:
#         raise HTTPException(status_code=403, detail="Unauthorized user")

#     if not confirm:
#         del DRAFT_STORE[draft_id]
#         return {"status": "cancelled"}

#     email_data = draft["email_data"]

#     session_id = await asyncio.to_thread(get_session_id)

#     response = await asyncio.to_thread(
#         send_email_via_gateway,
#         session_id,
#         email_data["to_list"],
#         email_data["cc_list"],
#         email_data["bcc_list"],
#         email_data.get("subject", "Test"),
#         email_data.get("body", "Testing"),
#         email_data.get("attachments", []),
#     )

#     status = "unknown"
#     error = None

#     if isinstance(response, dict):
#         status_raw = response.get("result", {}).get("status", "")

#         if "success" in str(status_raw).lower():
#             status = "sent"
#             DRAFT_STORE.pop(draft_id, None)
#         else:
#             status = "failed"
#             error = str(response)

#     return {
#         "status": status,
#         "error": error,
#         "email_data": email_data,
#         "response": response
#     }

