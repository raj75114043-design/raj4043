import uuid
import asyncio
import json
import asyncio
import uuid
import time

from datetime import datetime
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException
from asyncpg import Connection
from app.core.llm_client import get_llm_client
from app.services.send_email_gateway import send_email_via_gateway, get_session_id
from app.db.pool import get_db

router = APIRouter(prefix="/email-agent", tags=["Email Agent"])

@router.get("/health")
async def check_health():
    """
    Generate structured email JSON from user prompt
    """
    try:
        message = "Good! Email Agent Endpoints Coming soon..."
        return message

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    