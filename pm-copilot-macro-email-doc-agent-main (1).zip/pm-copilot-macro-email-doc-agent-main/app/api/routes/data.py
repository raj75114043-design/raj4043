import tempfile
from typing import List, Dict, Any,  Set, Union
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from asyncpg import Connection
from app.db.pool import get_db
from app.config.data_fetch_config import BASE_SCHEMA
from app.schemas.general import UserInfoRequest
from app.schemas.data import (
    EmailIdItem,
    TableMetadataResponse,
) 


router = APIRouter(prefix="/data", tags=["Data"])


def _extract_name_from_email(email: str) -> str:
    local_part = email.split("@")[0]
    parts = [p for p in local_part.split(".") if p.lower() != "ext"]
    return " ".join(p.capitalize() for p in parts)


@router.get("/input/postgre/tables/info", response_model=TableMetadataResponse)
async def get_available_staging_tables_info(
    db: Connection = Depends(get_db),
):
    """
    Returns schema, table, column name, and data type
    for all tables available in the backend schema.
    """
    try:
        records = await db.fetch(
            """
            SELECT
                table_schema AS schema_name,
                table_name,
                column_name,
                data_type
            FROM information_schema.columns
            WHERE table_schema = $1
            ORDER BY table_name, ordinal_position
            """,
            BASE_SCHEMA,
        )

        if not records:
            return {
                "table_count": 0,
                "tables": [],
                "message": "No tables or columns found in schema",
            }

        tables_map: dict[str, dict] = {}

        for row in records:
            table_name = row["table_name"]

            if table_name not in tables_map:
                tables_map[table_name] = {
                    "table_name": table_name,
                    "schema_name": row["schema_name"],
                    "columns": [],
                }

            tables_map[table_name]["columns"].append(
                {
                    "column_name": row["column_name"],
                    "data_type": row["data_type"],
                }
            )

        return {
            "table_count": len(tables_map),
            "tables": list(tables_map.values()),
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch table metadata: {e}",
        )


@router.get("/available/email-ids", response_model=List[EmailIdItem])
async def get_available_email_ids(
    db: Connection = Depends(get_db),
):
    try:
        records = await db.fetch(
            """
            SELECT name, email 
            FROM osdp_pwc_sch.users
            ORDER BY name, email
            """
        )

        return [
            {
                "name": record["name"],
                "email": record["email"]
            }
            for record in records
        ]

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch email ids: {str(e)}",
        )
