import asyncio
import uuid
import json
import time
import json
import uuid
import uuid
import asyncio
from app.schemas.general import UserInfoRequest
from datetime import datetime
from typing import List, Optional, Dict, Any
from asyncpg import Connection
from app.db.pool import get_db
from typing import Literal
from typing import get_args
from fastapi import APIRouter, Depends, HTTPException, status, Body
from pydantic import BaseModel
from app.core.llm_client import get_llm_client
from pathlib import Path
from fastapi import APIRouter, Depends, BackgroundTasks, HTTPException
from app.services.azure_doc_parsing import DocumentService
from app.dependencies.azure_doc_intelligence import get_document_service
from app.services.s3_blob_management import S3Service
from app.dependencies.s3_blob import get_s3_service
from app.config.azure_doc_settings import get_config
from app.db.pool import get_db
from app.schemas.general import UpdateJobConfigRequest, ReviewDraftMailRequest, CreateUseCaseRequest
from fastapi import UploadFile, File, Form
from typing import get_args, get_origin
from pydantic import BaseModel
from app.utils.timezone import get_datetime_now_without_zone


from app.email_doc_job_engine.main_orchestrator.orchestrator import run_job


from app.email_doc_job_engine.utils.execution_store import (
    create_execution
)


from app.email_doc_job_engine.utils.execution_store import get_execution
    
from app.email_doc_job_engine.job_schema.job_config_class import JobConfig


router = APIRouter(prefix="/email-doc/job-orchestrator", tags=["Email-Document Job Drill Down Tables"])

JOB_TYPE = Literal["Email", "Document"]

TABLE_SCHEMA = "macro_email_doc_agent"
TABLE_NAME = "email_doc_usecase_jobs"

EDITABLE_COLUMNS = [
    "schedule_run_times",
    "days_of_week",
    "timezone",
    "is_active",
    "job_owner",
    "job_type",
    "job_trigger_point",
    "is_approval_required",
    "approval_status",
    "view_to_all",
    "is_exandable",
    "linked_tables",
]


@router.get("/live-status/{job_type}/get/table/drill-down-tables/{job_id}")
async def get_live_status_drill_down_tables(
    job_type: JOB_TYPE,
    job_id: str,
    user_id: str,
    db: Connection = Depends(get_db),
):

    try:

        # =====================================================
        # FIXED TABLES
        # =====================================================

        FIXED_TABLES_EMAIL_JOB = [
            "macro_email_doc_agent.email_doc_usecase_jobs",
            "macro_email_doc_agent.email_doc_usecase_jobs_email_send",
            "macro_email_doc_agent.email_doc_usecase_jobs_run_status"
        ]

        FIXED_TABLES_DOCUMENT_JOB = [
            "macro_email_doc_agent.email_doc_usecase_jobs",
            "macro_email_doc_agent.email_doc_usecase_jobs_email_send",
            "macro_email_doc_agent.email_doc_usecase_jobs_run_status"
        ]

        # =====================================================
        # SELECT BASE TABLES
        # =====================================================

        if job_type == "Email":

            FIXED_TABLES = FIXED_TABLES_EMAIL_JOB

        elif job_type == "Document":

            FIXED_TABLES = FIXED_TABLES_DOCUMENT_JOB

        else:

            FIXED_TABLES = []

        # =====================================================
        # --> FETCH LINKED TABLES
        # =====================================================

        linked_table_query = """
            SELECT linked_tables
            FROM macro_email_doc_agent.email_doc_usecase_jobs
            WHERE job_id = $1
            AND job_type = $2
            LIMIT 1
        """

        linked_table_row = await db.fetchrow(
            linked_table_query,
            job_id,
            job_type
        )

        if linked_table_row:

            linked_tables = (
                linked_table_row.get("linked_tables")
                or []
            )

            # append linked tables
            FIXED_TABLES.extend(linked_tables)

        # =====================================================
        # REMOVE DUPLICATES
        # =====================================================

        FIXED_TABLES = list(set(FIXED_TABLES))

        tables = []

        # =====================================================
        # FETCH DATA
        # =====================================================

        for table_name in FIXED_TABLES:

            try:

                query = f"""
                    SELECT *
                    FROM {table_name}
                    LIMIT 1000
                """

                # Apply filter only to known tables
                if table_name in [
                    "macro_email_doc_agent.email_doc_usecase_jobs",
                    "macro_email_doc_agent.email_doc_usecase_jobs_email_send",
                    "macro_email_doc_agent.email_doc_usecase_jobs_run_status"
                ]:

                    query = f"""
                        SELECT *
                        FROM {table_name}
                        WHERE job_id = $1
                        ORDER BY created_at DESC
                        LIMIT 1000
                    """

                    rows = await db.fetch(
                        query,
                        job_id
                    )

                else:

                    rows = await db.fetch(query)


                data = [
                    dict(row)
                    for row in rows
                ]

                tables.append({
                    "table_name": table_name,
                    "rows": len(data),
                    "data": data
                })

            except Exception as table_error:

                # Prevent one bad table from breaking all response
                tables.append({
                    "table_name": table_name,
                    "rows": 0,
                    "data": [],
                    "error": str(table_error)
                })

        # =====================================================
        # RESPONSE
        # =====================================================

        return {
            "job_type": job_type,
            "job_id": job_id,
            "user_id": user_id,
            "table_count": len(tables),
            "tables": tables
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch drill down tables: {str(e)}"
        )


