from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
import requests
from fastapi import APIRouter, Depends, BackgroundTasks, HTTPException


router = APIRouter(prefix="/trigger", tags=["Trigger Sharepoint to Blob Storage"])

POWER_AUTOMATE_URL = (
    "https://default5d4717519675428d917b70f44f9630.b0.environment.api.powerplatform.com:443/"
    "powerautomate/automations/direct/workflows/058e87a8aa0842638c93cc7df260b22a/"
    "triggers/manual/paths/invoke"
    "?api-version=1"
    "&sp=%2Ftriggers%2Fmanual%2Frun"
    "&sv=1.0"
    "&sig=L84JdiIP-qbWRvEw8kRpZAWkZr_h7FOg5vtMT7WbDag"
)


@router.post("/trigger-power-automate")
async def trigger_power_automate():

    headers = {
        "Content-Type": "application/json"
    }

    payload = {}

    try:

        response = requests.post(
            POWER_AUTOMATE_URL,
            headers=headers,
            json=payload,
            timeout=30
        )

        # ==========================================
        # SUCCESS
        # ==========================================
        if response.status_code == 202:

            return JSONResponse(
                status_code=202,
                content={
                    "message": "Power Automate flow triggered successfully"
                }
            )

        # ==========================================
        # FAILURE
        # ==========================================
        elif response.status_code == 400:

            return JSONResponse(
                status_code=400,
                content={
                    "error": response.text
                }
            )

        # ==========================================
        # OTHER ERRORS
        # ==========================================
        else:

            return JSONResponse(
                status_code=response.status_code,
                content={
                    "error": response.text
                }
            )

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )