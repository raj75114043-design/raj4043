import json
import os
import uuid
import time
import asyncio
import json
from typing import List, Literal, Optional, Dict
from pydantic import ValidationError
from fastapi import Form
from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from app.schemas.document import ExtractRawResponse, ExtractFieldsRequest, ExtractResponse
from app.services.azure_doc_parsing import DocumentService
from app.dependencies.azure_doc_intelligence import get_document_service
from app.services.s3_blob_management import S3Service
from app.dependencies.s3_blob import get_s3_service
from app.config.azure_doc_settings import get_config
from app.schemas.document import DocumentModelEnum, DocumentChatRequest
from app.core.llm_client import get_llm_client
from pydantic import TypeAdapter

router = APIRouter(prefix="/document", tags=["Document Parser"])

SESSION_STORE = {}
SESSION_TIMEOUT_SECONDS = 5 * 60  # 5 minutes

SUPPORTED_FILE_TYPE_FOR_AZURE = [
    {
        "extension": ".pdf",
        "mime_type": "application/pdf",
        "description": "PDF documents"
    },
    {
        "extension": ".png",
        "mime_type": "image/png",
        "description": "PNG images"
    },
    {
        "extension": ".jpg",
        "mime_type": "image/jpeg",
        "description": "JPG images"
    },
    {
        "extension": ".jpeg",
        "mime_type": "image/jpeg",
        "description": "JPEG images"
    }
]


AZURE_DOC_INTELLIGENCE_MODELS = [
    {
        "model_name": "Read OCR",
        "model_id": DocumentModelEnum.PREBUILT_READ,
        "description": (
            "OCR-focused model that extracts plain text from scanned "
            "documents, images, and handwritten content."
        )
    },
    {
        "model_name": "Layout Parser",
        "model_id": DocumentModelEnum.PREBUILT_LAYOUT,
        "description": (
            "Extracts document structure including paragraphs, tables, "
            "lines, selection marks, and reading order."
        )
    },
    {
        "model_name": "Contract Parser",
        "model_id": DocumentModelEnum.PREBUILT_CONTRACT,
        "description": (
            "Extracts key information from contracts such as parties, "
            "dates, terms, clauses, and signatures."
        )
    },
    {
        "model_name": "Health Insurance Card",
        "model_id": DocumentModelEnum.PREBUILT_HEALTH_INSURANCE,
        "description": (
            "Parses US health insurance cards and extracts member, "
            "provider, policy, and group details."
        )
    },
    {
        "model_name": "ID Document",
        "model_id": DocumentModelEnum.PREBUILT_ID,
        "description": (
            "Extracts fields from identity documents like passports, "
            "driver licenses, and national IDs."
        )
    },
    {
        "model_name": "Invoice Parser",
        "model_id": DocumentModelEnum.PREBUILT_INVOICE,
        "description": (
            "Extracts invoice details including invoice number, vendor, "
            "billing information, totals, taxes, and line items."
        )
    },
    {
        "model_name": "Receipt Parser",
        "model_id": DocumentModelEnum.PREBUILT_RECEIPT,
        "description": (
            "Parses retail receipts and extracts merchant, items, "
            "totals, taxes, and payment details."
        )
    },
    {
        "model_name": "Marriage Certificate",
        "model_id": DocumentModelEnum.PREBUILT_MARRIAGE,
        "description": (
            "Extracts structured data from US marriage certificates."
        )
    },
    {
        "model_name": "Credit Card Parser",
        "model_id": DocumentModelEnum.PREBUILT_CREDIT_CARD,
        "description": (
            "Extracts card-related details from credit card documents."
        )
    },
    {
        "model_name": "Check Parser",
        "model_id": DocumentModelEnum.PREBUILT_CHECK,
        "description": (
            "Extracts information from US bank checks including payee, "
            "amount, routing number, and account details."
        )
    },
    {
        "model_name": "Pay Stub Parser",
        "model_id": DocumentModelEnum.PREBUILT_PAYSTUB,
        "description": (
            "Parses US pay stubs and extracts earnings, deductions, "
            "taxes, and employee details."
        )
    },
    {
        "model_name": "Bank Statement Parser",
        "model_id": DocumentModelEnum.PREBUILT_BANK,
        "description": (
            "Extracts account details, balances, and transaction data "
            "from bank statements."
        )
    },

    {
        "model_name": "Mortgage 1003",
        "model_id": DocumentModelEnum.PREBUILT_MORTGAGE_1003,
        "description": (
            "Parses Uniform Residential Loan Application (Form 1003)."
        )
    },
    {
        "model_name": "Mortgage 1004",
        "model_id": DocumentModelEnum.PREBUILT_MORTGAGE_1004,
        "description": (
            "Extracts information from Uniform Residential Appraisal "
            "Report (Form 1004)."
        )
    },
    {
        "model_name": "Mortgage 1005",
        "model_id": DocumentModelEnum.PREBUILT_MORTGAGE_1005,
        "description": (
            "Parses appraisal update and completion reports (Form 1005)."
        )
    },
    {
        "model_name": "Mortgage 1008",
        "model_id": DocumentModelEnum.PREBUILT_MORTGAGE_1008,
        "description": (
            "Extracts underwriting and transmittal summary data "
            "from Form 1008."
        )
    },
    {
        "model_name": "Mortgage Closing Disclosure",
        "model_id": DocumentModelEnum.PREBUILT_MORTGAGE_CLOSING,
        "description": (
            "Parses mortgage closing disclosure documents including "
            "loan terms, payments, and closing costs."
        )
    },

    {
        "model_name": "US Tax Document",
        "model_id": DocumentModelEnum.PREBUILT_TAX,
        "description": (
            "General parser for US tax-related documents."
        )
    },
    {
        "model_name": "W-2 Form",
        "model_id": DocumentModelEnum.PREBUILT_TAX_W2,
        "description": (
            "Extracts employee wage and tax information from W-2 forms."
        )
    },
    {
        "model_name": "W-4 Form",
        "model_id": DocumentModelEnum.PREBUILT_TAX_W4,
        "description": (
            "Parses employee withholding certificate (W-4)."
        )
    },
    {
        "model_name": "1040 Tax Form",
        "model_id": DocumentModelEnum.PREBUILT_TAX_1040,
        "description": (
            "Extracts income tax return details from IRS Form 1040."
        )
    },
    {
        "model_name": "1095-A Form",
        "model_id": DocumentModelEnum.PREBUILT_TAX_1095A,
        "description": (
            "Parses Health Insurance Marketplace Statement (1095-A)."
        )
    },
    {
        "model_name": "1095-C Form",
        "model_id": DocumentModelEnum.PREBUILT_TAX_1095C,
        "description": (
            "Extracts employer-provided health insurance information "
            "from Form 1095-C."
        )
    },
    {
        "model_name": "1098 Form",
        "model_id": DocumentModelEnum.PREBUILT_TAX_1098,
        "description": (
            "Parses mortgage interest statements (Form 1098)."
        )
    },
    {
        "model_name": "1098-E Form",
        "model_id": DocumentModelEnum.PREBUILT_TAX_1098E,
        "description": (
            "Extracts student loan interest information from Form 1098-E."
        )
    },
    {
        "model_name": "1098-T Form",
        "model_id": DocumentModelEnum.PREBUILT_TAX_1098T,
        "description": (
            "Parses tuition statements and education payment details "
            "from Form 1098-T."
        )
    },
    {
        "model_name": "1099 Form",
        "model_id": DocumentModelEnum.PREBUILT_TAX_1099,
        "description": (
            "Extracts miscellaneous income and contractor payment "
            "information from 1099 forms."
        )
    },
    {
        "model_name": "1099-SSA Form",
        "model_id": DocumentModelEnum.PREBUILT_TAX_1099SSA,
        "description": (
            "Parses Social Security Benefit Statements (SSA-1099)."
        )
    }
]


SUPPORTED_FIELDS_DATA_TYPES = [
    "Integer",
    "String",
    "Float",
    "Date",
    "Time"
]


def validate_file_type(s3_key: str):
    ext = os.path.splitext(s3_key.lower())[1]

    allowed_extensions = {
        file_type["extension"]
        for file_type in SUPPORTED_FILE_TYPE_FOR_AZURE
    }

    if ext not in allowed_extensions:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Unsupported file type '{ext}'. "
                f"Supported types are: {', '.join(sorted(allowed_extensions))}"
            )
        )
    

async def cleanup_sessions():
    while True:
        now = time.time()
        to_delete = []

        for session_id, session in SESSION_STORE.items():
            last_accessed = session.get("last_accessed", now)

            if now - last_accessed > SESSION_TIMEOUT_SECONDS:
                to_delete.append(session_id)

        for session_id in to_delete:
            del SESSION_STORE[session_id]

        await asyncio.sleep(60)  # run every 1 min



def extract_using_prompt(
    parsed_text: str,
    user_input: str
) -> dict:

    llm = get_llm_client("medium")

    prompt = f"""
You are a JSON-only document extraction engine.

USER TASK:
{user_input}

STRICT RULES:
- Return ONLY valid JSON
- No markdown
- No explanation
- No comments
- JSON must be parseable with Python json.loads()
- Response must start with {{
- Response must end with }}

DOCUMENT:
-------------------
{parsed_text}
"""

    response = llm.invoke(prompt)

    content = response.content.strip()

    # cleanup
    content = (
        content
        .replace("```json", "")
        .replace("```", "")
        .strip()
    )

    try:
        return json.loads(content)

    except Exception:

        # second-pass repair
        repair_prompt = f"""
Fix this into valid JSON.

Return ONLY valid JSON.

CONTENT:
----------------
{content}
"""

        repaired = llm.invoke(repair_prompt)

        repaired_content = (
            repaired.content
            .replace("```json", "")
            .replace("```", "")
            .strip()
        )

        return json.loads(repaired_content)
    
    

def format_raw_content_to_markdown(raw_content: str) -> str:
    llm = get_llm_client("medium")

    prompt = f"""
You are a professional document formatter.

Convert the below raw OCR/document parsed content into:
- Proper Markdown
- Proper headings
- Tables wherever applicable
- Bullet points
- Preserve all information
- Clean formatting
- Human readable structure

DO NOT summarize.
DO NOT remove data.
Return ONLY markdown.

RAW CONTENT:
------------------------
{raw_content}
"""

    response = llm.invoke(prompt)
    return response.content.strip()


@router.get("/supported-file-types")
async def get_supported_file_types():
    return {
        "total_supported_types": len(SUPPORTED_FILE_TYPE_FOR_AZURE),
        "supported_file_types": SUPPORTED_FILE_TYPE_FOR_AZURE
    }

@router.get("/supported-models")
async def get_supported_models():
    return {
        "total_models": len(AZURE_DOC_INTELLIGENCE_MODELS),
        "models": AZURE_DOC_INTELLIGENCE_MODELS
    }


@router.get("/supported-fields-data-types")
async def get_supported_fields_data_types():
    return {
        "total_models": len(SUPPORTED_FIELDS_DATA_TYPES),
        "supported_fields_data_types": SUPPORTED_FIELDS_DATA_TYPES
    }

# =========================


@router.post("/extract-raw-content-s3-upload", response_model=ExtractRawResponse)
async def extract_raw_document_s3(
    file: UploadFile = File(None),
    bucket_name: str = Form(None),
    s3_key: str = Form(None),
    model: DocumentModelEnum = Form(None),
    service: DocumentService = Depends(get_document_service),
    s3: S3Service = Depends(get_s3_service)
):
    config = get_config()
    max_size = config["limits"]["max_file_size_mb"] * 1024 * 1024

    if not file and not (bucket_name and s3_key):
        raise HTTPException(
            status_code=400,
            detail="Provide either file OR (bucket_name + s3_key)"
        )

    if file and (bucket_name and s3_key):
        raise HTTPException(
            status_code=400,
            detail="Please provide only one source"
        )

    try:

        # ============================================
        # FILE UPLOAD
        # ============================================
        if file:

            supported_mime_types = [
                item["mime_type"]
                for item in SUPPORTED_FILE_TYPE_FOR_AZURE
            ]

            if file.content_type not in supported_mime_types:
                raise HTTPException(
                    status_code=400,
                    detail="Unsupported file type"
                )

            file_bytes = await file.read()

            content_type = file.content_type
            source_name = file.filename

        # ============================================
        # S3 FILE
        # ============================================
        else:

            validate_file_type(s3_key)

            file_bytes = await s3.get_file_bytes(
                bucket_name,
                s3_key
            )

            ext = os.path.splitext(s3_key.lower())[1]

            content_type = next(
                (
                    item["mime_type"]
                    for item in SUPPORTED_FILE_TYPE_FOR_AZURE
                    if item["extension"] == ext
                ),
                None
            )

            source_name = s3_key

        # ============================================
        # SIZE VALIDATION
        # ============================================
        if len(file_bytes) > max_size:
            raise HTTPException(
                status_code=400,
                detail="File too large"
            )

        # ============================================
        # AZURE PARSING
        # ============================================
        parsed_text = await service.extract_raw_fields(
            file_bytes=file_bytes,
            content_type=content_type,
            model=model
        )

        # ============================================
        # MARKDOWN FORMATTER
        # ============================================
        markdown_content = format_raw_content_to_markdown(
            parsed_text
        )

    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

    return ExtractRawResponse(
        file_name=source_name,
        model_id=model,
        extracted_data={
            "raw_content": parsed_text,
            "markdown_content": markdown_content
        }
    )




@router.post(
    "/extract-fields-with-llm-s3-upload", response_model=ExtractResponse
)
async def extract_document_s3(
    request: str = Form(None),
    user_input: Optional[str] = Form(None),
    file: UploadFile = File(None),
    bucket_name: str = Form(None),
    s3_key: str = Form(None),
    model: Optional[DocumentModelEnum] = Form(None),
    service: DocumentService = Depends(get_document_service),
    s3: S3Service = Depends(get_s3_service)
):

    request_obj = None
    config = get_config()
    max_size = config["limits"]["max_file_size_mb"] * 1024 * 1024

    # ============================================
    # SOURCE VALIDATION
    # ============================================
    if not file and not (bucket_name and s3_key):
        raise HTTPException(
            status_code=400,
            detail="Provide either file OR (bucket_name + s3_key)"
        )

    if file and (bucket_name and s3_key):
        raise HTTPException(
            status_code=400,
            detail="Please provide only one source"
        )

    # ============================================
    # INPUT VALIDATION
    # ============================================

    if not request and not user_input:
        raise HTTPException(
            status_code=400,
            detail="Provide either request OR user_input"
        )

    if request and user_input:
        raise HTTPException(
            status_code=400,
            detail="Provide only one: request OR user_input"
        )


    if request:

        try:
            parsed_request = json.loads(request)

            request_obj = TypeAdapter(
                List[ExtractFieldsRequest]
            ).validate_python(parsed_request)

        except (json.JSONDecodeError, ValidationError):

            # fallback to prompt mode
            user_input = request
            request_obj = None

    try:

        # ============================================
        # FILE UPLOAD
        # ============================================
        if file:

            supported_mime_types = [
                item["mime_type"]
                for item in SUPPORTED_FILE_TYPE_FOR_AZURE
            ]

            if file.content_type not in supported_mime_types:
                raise HTTPException(
                    status_code=400,
                    detail="Unsupported file type"
                )

            file_bytes = await file.read()

            content_type = file.content_type

            source_name = file.filename

        # ============================================
        # S3 FILE
        # ============================================
        else:

            validate_file_type(s3_key)

            file_bytes = await s3.get_file_bytes(
                bucket_name,
                s3_key
            )

            ext = os.path.splitext(
                s3_key.lower()
            )[1]

            content_type = next(
                (
                    item["mime_type"]
                    for item in SUPPORTED_FILE_TYPE_FOR_AZURE
                    if item["extension"] == ext
                ),
                None
            )

            source_name = s3_key

        # ============================================
        # SIZE VALIDATION
        # ============================================
        if len(file_bytes) > max_size:
            raise HTTPException(
                status_code=400,
                detail="File too large"
            )


        # ============================================
        # FIELD EXTRACTION
        # ============================================

        if request_obj:
            data = await service.extract_fields(
                file_bytes=file_bytes,
                content_type=content_type,
                fields=[
                    field.model_dump()
                    for field in request_obj
                ],
                model=model
            )

        # ============================================
        # PROMPT MODE
        # ============================================
        else:
            parsed_text = await service.extract_raw_fields(
                file_bytes=file_bytes,
                content_type=content_type,
                model=model
            )

            data = extract_using_prompt(
                parsed_text=parsed_text,
                user_input=user_input
            )


    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )

    return ExtractResponse(
        file_name=source_name,
        model_id=model,
        fields_schema=request_obj,
        user_input=user_input,
        extracted_data=data
    )





# -----------------



@router.post("/chat/create-session", include_in_schema=False)
async def create_session(
    file: UploadFile = File(None),
    model: DocumentModelEnum = Form(None),
    bucket_name: str = Form(None),
    s3_key: str = Form(None),
    service: DocumentService = Depends(get_document_service),
    s3: S3Service = Depends(get_s3_service)
):
    config = get_config()

    if not file and not (bucket_name and s3_key):
        raise HTTPException(
            status_code=400,
            detail="Provide file OR (bucket_name + s3_key)"
        )
    
    # if file and (bucket_name and s3_key):
    #     raise HTTPException(
    #         status_code=400,
    #         detail="Please Give Only one File either from bucket_name OR s3_key"
    #     )
    
    if file.content_type not in config["supported_formats"]["mime_types"]:
        raise HTTPException(status_code=400, detail="Unsupported file type")

    validate_file_type(s3_key)

    parsed_texts = []

    if file:
        file_bytes = await file.read()

        text = await service.extract_raw_fields(
            file_bytes=file_bytes,
            content_type=file.content_type,
            model=model
        )

        parsed_texts.append({
            "source": file.filename,
            "content": text
        })

    if bucket_name and s3_key:
    # else:    
        file_bytes = await s3.get_file_bytes(bucket_name, s3_key)

        ext = os.path.splitext(s3_key.lower())[1]
        content_type_map = {
            ".pdf": "application/pdf",
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg"
        }

        text = await service.extract_raw_fields(
            file_bytes=file_bytes,
            content_type=content_type_map.get(ext),
            model=None
        )

        parsed_texts.append({
            "source": s3_key,
            "content": text
        })


    merged_content = "\n\n".join(
        f"[SOURCE: {p['source']}]\n{p['content']}"
        for p in parsed_texts
    )
    
    session_id = str(uuid.uuid4())
    # SESSION_STORE[session_id] = {
    #     "sources": [p["source"] for p in parsed_texts],
    #     "content": merged_content
    # }

    SESSION_STORE[session_id] = {
        "sources": [p["source"] for p in parsed_texts],
        "content": merged_content,
        "last_accessed": time.time()
    }

    return {
        "session_id": session_id,
        "sources": SESSION_STORE[session_id]["sources"]
    }


@router.post("/chat/query", include_in_schema=False)
async def chat_with_document(
    request: DocumentChatRequest,
    service: DocumentService = Depends(get_document_service)
):
    session = SESSION_STORE.get(request.session_id)

    if not session:
        raise HTTPException(status_code=404, detail="Session not found")
    session["last_accessed"] = time.time()

    if not session:
        raise HTTPException(status_code=404, detail="Session not found")

    context = session["content"]    
    llm = get_llm_client("medium")

    prompt = f"""
You are an intelligent document assistant.

Document Content:
-------------------
{context}

User Question:
--------------
{request.query}

Answer based only on the document content.
"""

    response = llm.invoke(prompt)
    content = response.content.strip()

    return {
        "session_id": request.session_id,
        "answer": content
    }
