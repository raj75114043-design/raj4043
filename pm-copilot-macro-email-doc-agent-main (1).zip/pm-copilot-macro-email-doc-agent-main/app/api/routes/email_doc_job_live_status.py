import asyncio
import uuid
import json
import time
import json
import uuid
import uuid
import asyncio
from app.schemas.general import UserInfoRequest
from datetime import datetime
from typing import List, Optional, Dict, Any
from asyncpg import Connection
from app.db.pool import get_db
from typing import Literal
from typing import get_args
from fastapi import APIRouter, Depends, HTTPException, status, Body
from pydantic import BaseModel
from app.core.llm_client import get_llm_client
from pathlib import Path
from fastapi import APIRouter, Depends, BackgroundTasks, HTTPException
from app.services.azure_doc_parsing import DocumentService
from app.dependencies.azure_doc_intelligence import get_document_service
from app.services.s3_blob_management import S3Service
from app.dependencies.s3_blob import get_s3_service
from app.config.azure_doc_settings import get_config
from app.db.pool import get_db
from app.schemas.general import UpdateJobConfigRequest, ReviewDraftMailRequest, CreateUseCaseRequest
from fastapi import UploadFile, File, Form
from typing import get_args, get_origin
from pydantic import BaseModel
from app.utils.timezone import get_datetime_now_without_zone


from app.email_doc_job_engine.main_orchestrator.orchestrator import run_job


from app.email_doc_job_engine.utils.execution_store import (
    create_execution
)


from app.email_doc_job_engine.utils.execution_store import get_execution
    
from app.email_doc_job_engine.job_schema.job_config_class import JobConfig


router = APIRouter(prefix="/email-doc/job-orchestrator", tags=["Email-Document Job Live Status"])

JOB_TYPE = Literal["Email", "Document"]

TABLE_SCHEMA = "macro_email_doc_agent"
TABLE_NAME = "email_doc_usecase_jobs"

EDITABLE_COLUMNS = [
    "schedule_run_times",
    "days_of_week",
    "timezone",
    "is_active",
    "job_owner",
    "job_type",
    "job_trigger_point",
    "is_approval_required",
    "approval_status",
    "view_to_all",
    "is_exandable",
    "linked_tables",
]

# =========================================================
# CREATE USE CASE REQUEST SCHEMA
# =========================================================


@router.get("/live-status/job-types")
async def get_job_types():
    """
    Return supported job types.
    """
    return {
        "job_types": list(get_args(JOB_TYPE))
    }


@router.get("/live-status/{job_type}/table")
async def get_live_status_table(
    job_type: JOB_TYPE,
    user_id: str,
    db: Connection = Depends(get_db),
):
    try:

        records = await db.fetch(
            """
            SELECT
            job_id,
            job_name,
            description,
            job_category as team,
            is_active,
            current_status,
            job_owner,
            schedule_run_times,
            days_of_week,
            timezone,
            last_run_at,
            last_run_status,
            created_at,
            job_trigger_point,
            is_approval_required,
            approval_status,
            view_to_all,
            is_exandable,
            approved_by,
            approved_at
            FROM macro_email_doc_agent.email_doc_usecase_jobs
            WHERE (
                $1 = ANY(job_owner)
                OR view_to_all = TRUE
            )
            AND job_type = $2
            ORDER BY job_id
            """,
            user_id,
            job_type
        )

        data = [
            dict(record)
            for record in records
        ]

        return {
            "job_type": job_type,
            "user_id": user_id,
            "rows": len(data),
            "data": data
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch job table: {str(e)}"
        )
    


@router.get("/live-status/{job_type}/{job_id}/current-status")
async def get_job_current_status(
    job_type: JOB_TYPE,
    db: Connection = Depends(get_db),
):
    """
    Get only current status for a specific job.
    """

    try:

        record = await db.fetchrow(
            """
            SELECT
                job_type,
                job_id,
                current_status
            FROM macro_email_doc_agent.email_doc_usecase_jobs
            WHERE job_type = $1
            """,
            job_type
        )

        if not record:
            raise HTTPException(
                status_code=404,
                detail="Job not found"
            )

        return dict(record)

    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch current status: {str(e)}"
        )