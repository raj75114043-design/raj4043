import uuid
import asyncio
import json
from datetime import datetime
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from asyncpg import Connection

from app.services.email_send import(
    send_email,
    send_email_without_status,
)

from app.config.data_fetch_config import EMAIL_DOC_AGENT_SCHEMA
from app.db.pool import get_connection

from app.schemas.email import(
    SendEmailRequest,
    SendEmailStartResponse,
    SendEmailStatusResponse,
    ScheduleEmailRequest,
    ScheduleEmailResponse,
)

router = APIRouter(tags=["Send/Schedule Email"])

EMAIL_JOBS: Dict[str, Dict[str, Any]] = {}

async def _save_email_schedule(token_id: str, request: ScheduleEmailRequest):

    base_query  = f"""
    INSERT INTO {EMAIL_DOC_AGENT_SCHEMA}.email_scheduled_jobs
    (
        token_id,
        scheduled_id,
        to_list,
        cc_list,
        bcc_list,
        subject,
        email_body,
        attachments,
        is_recurring,
        schedule_time,
        schedule_time_zone,
        days_of_week,
        scheduled_by
    )
    VALUES
    """

    try:
        schedule_time = None
        if len(request.schedule_time) > 4:
            raise HTTPException(
                status_code=400,
                detail="Maximum 4 schedule times allowed"
            )
        
        days_of_week = [day.value for day in request.days_of_week]

        values_clause = []
        params = []
        param_index = 1

        schedule_ids = []

        for time_str in request.schedule_time:

            try:
                schedule_time = datetime.strptime(time_str, "%H:%M").time()
            except ValueError:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid time format: {time_str}. Use HH:MM"
                )

            schedule_id = str(uuid.uuid4())
            schedule_ids.append(schedule_id)

            # Build placeholders dynamically
            placeholders = []
            row_values = [
                token_id,
                schedule_id,
                request.to_list,
                request.cc_list,
                request.bcc_list,
                request.subject,
                request.email_body,
                json.dumps([att.dict() for att in request.attachments]),
                request.is_recurring, 
                schedule_time,
                request.schedule_time_zone,
                request.days_of_week,
                request.user_id,
            ]

            placeholders = [
                f"${i}" for i in range(param_index, param_index + len(row_values))
            ]
            param_index += len(row_values)

            values_clause.append(f"({', '.join(placeholders)})")
            params.extend(row_values)

        final_query = base_query.strip() + " " + ", ".join(values_clause)

        async with get_connection() as db:
            await db.execute(final_query, *params)

        return schedule_ids

    except Exception as e:
        raise RuntimeError(f"Email scheduling failed: {str(e)}")
    

async def _run_email_job(
    token_id: str,
    request: SendEmailRequest,
):

    EMAIL_JOBS[token_id]["status"] = "RUNNING"
    EMAIL_JOBS[token_id]["stage"] = "INITIALIZING"

    try:
        EMAIL_JOBS[token_id]["stage"] = "LOADING_WORKFLOW"
        async with get_connection() as db:
            result = await send_email(
                db,
                user_id=request.user_id,
                token_id=token_id,
                scheduled_id=None,
                to_list=request.to_list,
                cc_list=request.cc_list,
                bcc_list=request.bcc_list,
                subject=request.subject,
                email_body=request.email_body,
                attachments=request.attachments,
                progress_callback=lambda stage: EMAIL_JOBS[token_id].update(
                    {"stage": stage}
                ),
            )

        EMAIL_JOBS[token_id]["status"] = result.get("status", "COMPLETED")
        EMAIL_JOBS[token_id]["stage"] = "COMPLETED"
        EMAIL_JOBS[token_id]["result"] = result

    except Exception as e:
        EMAIL_JOBS[token_id]["status"] = "FAILED"
        EMAIL_JOBS[token_id]["stage"] = "FAILED"
        EMAIL_JOBS[token_id]["error"] = str(e)


@router.post(
    "/send/email",
    response_model=SendEmailStartResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Start email job",
)
async def send_email_endpoint(
    request: SendEmailRequest,
):
    """
{
  "user_id": "talib.raza.ext@nokia.com",
  "to_list": ["talib.raza.ext@nokia.com"],
  "cc_list": [],
  "bcc_list": [],
  "subject": "Test",
  "email_body": "Test",
  "attachments": [
    {
      "filedata": "cmduX3JlZ2lvbixzbXBfbmFtZQ0KU09VVEgsQUhMT0IgTW9kZXJuaXphdGlvbg0K",
      "filename": "test1.csv"
    },
    {
      "filedata": "cmduX3JlZ2lvbixzbXBfbmFtZQ0KU09VVEgsQUhMT0IgTW9kZXJuaXphdGlvbg0K",
      "filename": "test2.csv"
    }
  ]
}
    """
    token_id = str(uuid.uuid4())

    EMAIL_JOBS[token_id] = {
        "status": "PENDING",
        "stage": "JOB_CREATED",
        "result": None,
        "error": None,
    }

    asyncio.create_task(
        _run_email_job(
            token_id,
            request,
        )
    )

    return {
        "token_id": token_id,
        "status": "PENDING",
    }


# ---------------------------------------------------------------------------
# Job Status Endpoint
# ---------------------------------------------------------------------------

@router.get(
    "/send/email/running-status/{token_id}",
    response_model=SendEmailStatusResponse,
    summary="Check email job status",
)
async def get_email_job_status(token_id: str):

    job = EMAIL_JOBS.get(token_id)

    if not job:
        raise HTTPException(
            status_code=404,
            detail="Token ID not found",
        )

    return {
        "token_id": token_id,
        "status": job["status"],
        "stage": job.get("stage"),
        "result": job.get("result"),
        "error": job.get("error"),
    }


@router.post(
    "/schedule/email",
    response_model=ScheduleEmailResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Schedule email job",
)
async def schedule_email_endpoint(
    request: ScheduleEmailRequest,
):
    token_id = str(uuid.uuid4())

    try:

        if request.is_recurring:
            if not request.schedule_time:
                raise HTTPException(
                    status_code=400,
                    detail="schedule_time required for recurring emails"
                )

            if not request.schedule_time_zone:
                raise HTTPException(
                    status_code=400,
                    detail="Time Zone required for emails"
                )

            if len(request.schedule_time) > 4:
                raise HTTPException(
                    status_code=400,
                    detail="Maximum 4 schedule times allowed"
                )
            
            if not request.days_of_week:
                raise HTTPException(
                    status_code=400,
                    detail="days_of_week is required for recurring emails"
                )
            
            await _save_email_schedule(token_id, request)

            return {
                "token_id": token_id,
                "status": "SCHEDULED"
            }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Email schedule failed: {str(e)}",
        )
    


# ---------------------------------------------------------------------------
# Job Status Endpoint
# ---------------------------------------------------------------------------

@router.post("/send/email/without-batch-processing", summary="Send email Without Status",)
async def send_email_wihout_status_endpoint(
    request: SendEmailRequest,
):
    token_id = str(uuid.uuid4())

    try:
        async with get_connection() as db:
            result = await send_email_without_status(
                db,
                user_id = request.user_id,
                token_id = token_id,
                to_list=request.to_list,
                cc_list=request.cc_list,
                bcc_list=request.bcc_list,
                subject=request.subject,
                email_body=request.email_body,
                attachments=request.attachments,
            )

        return result

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Email send failed: {str(e)}",
        )
    
