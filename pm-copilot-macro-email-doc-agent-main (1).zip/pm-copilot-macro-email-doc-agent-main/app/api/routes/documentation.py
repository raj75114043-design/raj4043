from fastapi import APIRouter, HTTPException
from pathlib import Path
from app.docs.guidance import JOB_CONFIGURATION_GUIDANCE

router = APIRouter(prefix="/documentation", tags=["Email Job Config Documentation"])

# =========================================================
# FILE LOCATION
# =========================================================
@router.get("/job-config/guidance")
async def get_job_configuration_guidance():

    try:

        return {
            "success": True,
            "markdown": JOB_CONFIGURATION_GUIDANCE
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=str(e)
        )