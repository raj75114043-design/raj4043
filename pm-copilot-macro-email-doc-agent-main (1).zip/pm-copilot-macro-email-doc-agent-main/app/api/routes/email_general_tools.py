import json
from typing import Optional, Dict, Any, List

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.core.llm_client import get_llm_client


router = APIRouter(
    prefix="/email/general-tools",
    tags=["Email General Tools"]
)


# =========================================================
# AVAILABLE OPTIONS
# =========================================================

AVAILABLE_TONES = [
    "Professional",
    "Formal",
    "Friendly",
    "Casual",
    "Urgent",
    "Polite",
    "Confident",
    "Apologetic",
    "Persuasive",
    "Neutral",
    "Normal"
]

AVAILABLE_LANGUAGES = [
    "English",
    "Hindi",
    "Spanish",
    "French",
    "German",
    "Chinese",
    "Japanese",
    "Arabic",
    "Russian",
    "Portuguese",
    "Italian",
    "Korean"
]


# =========================================================
# SCHEMAS
# =========================================================

class RephraserRequest(BaseModel):
    user_id: str
    email_input: str
    tone: str


class ReplierRequest(BaseModel):
    user_id: str
    email_input: str
    tone: str


class TranslatorRequest(BaseModel):
    user_id: str
    email_input: str
    output_language: str


class EmailResponse(BaseModel):
    subject: str
    email_html: str
    error: Optional[str] = None


class AvailableTonesResponse(BaseModel):
    total_tones: int
    tones: List[str]


class AvailableLanguagesResponse(BaseModel):
    total_languages: int
    languages: List[str]



class EmailGeneratorRequest(BaseModel):
    user_id: str
    user_input: str
    tone: str = "Professional"

class GeneratedEmailResponse(BaseModel):
    to_list: List[str]
    cc_list: List[str]
    bcc_list: List[str]
    subject: str
    email_html: str
    attachments: List[str]
    error: Optional[str] = None


# =========================================================
# SHARED LLM UTIL
# =========================================================

def run_llm(llm, prompt: str) -> Dict[str, Any]:

    response = llm.invoke(prompt)

    content = response.content.strip()

    # cleanup markdown fences
    content = (
        content
        .replace("```json", "")
        .replace("```", "")
        .strip()
    )

    try:
        return json.loads(content)

    except Exception:

        return {
            "subject": "Parsing Failed",
            "email_html": content,
            "error": "Invalid JSON from LLM"
        }



# =========================================================
# PROMPT BUILDERS
# =========================================================

def build_email_generator_prompt(
    user_id: str,
    user_input: str,
    tone: str
) -> str:

    return f"""
You are an AI Enterprise Email Composer specialized in Telecom Industry communication.

TASK:
Generate a professional enterprise email from the user's instruction.

TONE:
{tone}

EMAIL HTML RULES:
- Return clean production-ready HTML email body
- Return ONLY HTML fragment for email body
- Do NOT return markdown
- Do NOT return full HTML document
- Do NOT include <html>, <head>, or <body> tags
- Use inline CSS only
- Use semantic HTML tags:
  <p>, <br>, <ul>, <ol>, <li>, <table>, <tr>, <td>, <strong>
- Use proper paragraph spacing
- Use bullet points for action items when needed
- Use numbered lists for instructions or steps
- Highlight important text using:
  <strong>important text</strong>
- Highlight urgent text using:
  <span style="color:red;font-weight:bold;">URGENT:</span>
- Keep formatting enterprise-grade and readable
- Ensure compatibility with Outlook and Gmail
- Keep HTML lightweight and clean

CONTENT RULES:
- Generate a professional and crisp email
- Create a strong enterprise-ready subject line
- Keep communication concise and actionable
- Use telecom enterprise communication style
- Include action items if relevant
- Do not hallucinate technical information
- Preserve any IDs, names, ticket references, dates exactly if provided
- If recipients are mentioned, extract them into to_list/cc_list/bcc_list
- If no recipients are provided, return empty arrays

ATTACHMENT RULES:
- If attachments are mentioned, include filenames in attachments[]
- Otherwise return empty array

STRICT OUTPUT RULES:
- Return ONLY valid JSON
- Do NOT use markdown code fences
- Do NOT add explanations
- Do NOT add extra text before or after JSON
- Response MUST be parseable using Python json.loads()
- Output must start with {{
- Output must end with }}

OUTPUT FORMAT:
{{
  "to_list": ["string"],
  "cc_list": ["string"],
  "bcc_list": ["string"],
  "subject": "string",
  "email_html": "string",
  "attachments": ["string"]
}}

USER INPUT:
\"\"\"
{user_input}
\"\"\"

USER:
{user_id}
"""




def build_rephrase_prompt(
    user_id: str,
    email_input: str,
    tone: str
) -> str:

    return f"""
You are an AI Email Enhancement Assistant specialized in Telecom Industry communication.

TASK:
Rephrase and improve the email while preserving the original meaning and intent.

TONE:
{tone}

EMAIL HTML RULES:
- Return clean production-ready HTML email body
- Return ONLY HTML fragment for email body
- Do NOT return markdown
- Do NOT return full HTML document
- Do NOT include <html>, <head>, or <body> tags
- Use inline CSS only
- Use professional enterprise email formatting
- Use semantic HTML tags:
  <p>, <br>, <ul>, <ol>, <li>, <table>, <tr>, <td>, <strong>
- Use proper spacing between paragraphs
- Highlight important text using:
  <strong>important text</strong>
- If urgency or escalation exists, highlight using:
  <span style="color:red;font-weight:bold;">URGENT:</span>
- Use bullet points for action items when appropriate
- Use numbered lists for instructions or steps
- Use tables if structured information exists
- Keep formatting clean, readable, and email-client friendly
- Ensure compatibility with Outlook and Gmail
- Do NOT over-format simple emails

CONTENT RULES:
- Maintain original intent
- Improve grammar and clarity
- Make language concise and professional
- Preserve names, dates, ticket IDs, references, and technical values exactly
- Do not invent information
- Keep telecom communication style professional and operational

STRICT OUTPUT RULES:
- Return ONLY valid JSON
- Do NOT use markdown code fences
- Do NOT add explanations
- Do NOT add extra text before or after JSON
- Response MUST be parseable using Python json.loads()
- Output must start with {{
- Output must end with }}

OUTPUT FORMAT:
{{
  "subject": "string",
  "email_html": "string"
}}

EMAIL CONTENT:
\"\"\"
{email_input}
\"\"\"

USER:
{user_id}
"""


def build_reply_prompt(
    user_id: str,
    email_input: str,
    tone: str
) -> str:

    return f"""
You are an AI Email Reply Assistant specialized in Telecom Industry communication.

TASK:
Generate a professional, context-aware, and enterprise-ready email reply.

TONE:
{tone}

EMAIL HTML RULES:
- Return clean production-ready HTML email body
- Return ONLY HTML fragment for email body
- Do NOT return markdown
- Do NOT return full HTML document
- Do NOT include <html>, <head>, or <body> tags
- Use inline CSS only
- Use semantic HTML tags:
  <p>, <br>, <ul>, <ol>, <li>, <table>, <tr>, <td>, <strong>
- Use proper paragraph spacing
- Use bullet points for updates or action items
- Use numbered lists when giving steps
- Highlight important information using:
  <strong>important text</strong>
- Highlight urgent or escalated items using:
  <span style="color:red;font-weight:bold;">URGENT:</span>
- Keep formatting clean and suitable for enterprise email systems
- Ensure compatibility with Outlook and Gmail
- Keep reply concise and readable

CONTENT RULES:
- Understand the complete context before replying
- Generate a crisp, professional, and relevant response
- Do not add unnecessary information
- Do not hallucinate technical details
- Include acknowledgement where appropriate
- Preserve important references if present
- Keep telecom communication operational and professional
- Generate an appropriate professional subject line

STRICT OUTPUT RULES:
- Return ONLY valid JSON
- Do NOT use markdown code fences
- Do NOT add explanations
- Do NOT add extra text outside JSON
- Response MUST be parseable using Python json.loads()
- Output must start with {{
- Output must end with }}

OUTPUT FORMAT:
{{
  "subject": "string",
  "email_html": "string"
}}

INCOMING EMAIL:
\"\"\"
{email_input}
\"\"\"

USER:
{user_id}
"""


def build_translate_prompt(
    user_id: str,
    email_input: str,
    output_language: str
) -> str:

    return f"""
You are an AI Email Translator specialized in Telecom Industry communication.

TASK:
Translate the email into: {output_language}

EMAIL HTML RULES:
- Return translated email as clean production-ready HTML
- Return ONLY HTML fragment for email body
- Do NOT return markdown
- Do NOT return full HTML document
- Do NOT include <html>, <head>, or <body> tags
- Use inline CSS only
- Preserve HTML formatting if already present
- Preserve paragraph spacing
- Preserve bullet points and numbering
- Preserve tables if present
- Preserve bold formatting
- Preserve urgency highlighting
- If urgent text exists, preserve or use:
  <span style="color:red;font-weight:bold;">URGENT:</span>
- Keep formatting clean and professional
- Ensure compatibility with Outlook and Gmail

CONTENT RULES:
- Preserve exact meaning
- Preserve communication tone and intent
- Do NOT summarize
- Do NOT remove details
- Preserve technical terminology accurately
- Preserve ticket IDs, references, dates, names, and telecom terms exactly
- Ensure translation sounds natural and enterprise professional

STRICT OUTPUT RULES:
- Return ONLY valid JSON
- Do NOT use markdown code fences
- Do NOT add explanations
- Do NOT add extra text outside JSON
- Response MUST be parseable using Python json.loads()
- Output must start with {{
- Output must end with }}

OUTPUT FORMAT:
{{
  "subject": "string",
  "email_html": "string"
}}

EMAIL CONTENT:
\"\"\"
{email_input}
\"\"\"

USER:
{user_id}
"""

# =========================================================
# API 1 - GET AVAILABLE TONES
# =========================================================

@router.get(
    "/available-tones",
    response_model=AvailableTonesResponse
)
async def get_available_tones():

    return AvailableTonesResponse(
        total_tones=len(AVAILABLE_TONES),
        tones=AVAILABLE_TONES
    )


# =========================================================
# API 2 - GET AVAILABLE LANGUAGES
# =========================================================

@router.get(
    "/available-languages",
    response_model=AvailableLanguagesResponse
)
async def get_available_languages():

    return AvailableLanguagesResponse(
        total_languages=len(AVAILABLE_LANGUAGES),
        languages=AVAILABLE_LANGUAGES
    )


# =========================================================
# API 3 - REPHRASE EMAIL
# =========================================================

@router.post(
    "/rephrase-email",
    response_model=EmailResponse
)
async def rephrase_email(payload: RephraserRequest):

    if not payload.email_input.strip():
        raise HTTPException(
            status_code=400,
            detail="Email input cannot be empty"
        )

    if payload.tone not in AVAILABLE_TONES:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported tone. Use one of: {AVAILABLE_TONES}"
        )

    llm = get_llm_client("low")

    prompt = build_rephrase_prompt(
        payload.user_id,
        payload.email_input,
        payload.tone
    )

    return run_llm(llm, prompt)


# =========================================================
# API 4 - TRANSLATE EMAIL
# =========================================================

@router.post(
    "/translate-email",
    response_model=EmailResponse
)
async def translate_email(payload: TranslatorRequest):

    if not payload.email_input.strip():
        raise HTTPException(
            status_code=400,
            detail="Email input cannot be empty"
        )

    # if payload.output_language not in AVAILABLE_LANGUAGES:
    #     raise HTTPException(
    #         status_code=400,
    #         detail=f"Unsupported language. Use one of: {AVAILABLE_LANGUAGES}"
    #     )

    llm = get_llm_client("low")

    prompt = build_translate_prompt(
        payload.user_id,
        payload.email_input,
        payload.output_language
    )

    return run_llm(llm, prompt)



# =========================================================
# API 5 - GENERATE REPLY
# =========================================================
    #  include_in_schema=False

@router.post(
    "/generate-reply",
    response_model=EmailResponse,
)
async def generate_reply(payload: ReplierRequest):

    if not payload.email_input.strip():
        raise HTTPException(
            status_code=400,
            detail="Email input cannot be empty"
        )

    if payload.tone not in AVAILABLE_TONES:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported tone. Use one of: {AVAILABLE_TONES}"
        )

    llm = get_llm_client("low")

    prompt = build_reply_prompt(
        payload.user_id,
        payload.email_input,
        payload.tone
    )

    return run_llm(llm, prompt)




# =========================================================
# API 6 - GENERATE EMAIL
# =========================================================

@router.post(
    "/generate-email",
    response_model=GeneratedEmailResponse
)
async def generate_email(payload: EmailGeneratorRequest):

    if not payload.user_input.strip():
        raise HTTPException(
            status_code=400,
            detail="User input cannot be empty"
        )

    if payload.tone not in AVAILABLE_TONES:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported tone. Use one of: {AVAILABLE_TONES}"
        )

    llm = get_llm_client("low")

    prompt = build_email_generator_prompt(
        payload.user_id,
        payload.user_input,
        payload.tone
    )

    return run_llm(llm, prompt)