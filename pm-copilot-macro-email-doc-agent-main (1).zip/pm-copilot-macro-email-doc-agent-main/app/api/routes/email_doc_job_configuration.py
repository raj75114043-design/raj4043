import asyncio
import uuid
import json
import time
import json
import uuid
import uuid
import asyncio
from app.schemas.general import UserInfoRequest
from datetime import datetime
from typing import List, Optional, Dict, Any
from asyncpg import Connection
from app.db.pool import get_db
from typing import Literal
from typing import get_args
from fastapi import APIRouter, Depends, HTTPException, status, Body
from pydantic import BaseModel
from app.core.llm_client import get_llm_client
from pathlib import Path
from fastapi import APIRouter, Depends, BackgroundTasks, HTTPException
from app.services.azure_doc_parsing import DocumentService
from app.dependencies.azure_doc_intelligence import get_document_service
from app.services.s3_blob_management import S3Service
from app.dependencies.s3_blob import get_s3_service
from app.config.azure_doc_settings import get_config
from app.db.pool import get_db
from app.schemas.general import UpdateJobConfigRequest, ReviewDraftMailRequest, CreateUseCaseRequest
from fastapi import UploadFile, File, Form
from typing import get_args, get_origin
from pydantic import BaseModel
from app.utils.timezone import get_datetime_now_without_zone


from app.email_doc_job_engine.main_orchestrator.orchestrator import run_job


from app.email_doc_job_engine.utils.execution_store import (
    create_execution
)

from app.email_doc_job_engine.utils.execution_store import get_execution
    
from app.email_doc_job_engine.job_schema.job_config_class import JobConfig


router = APIRouter(prefix="/email-doc/job-orchestrator", tags=["Email-Document Job Configuration"])

JOB_TYPE = Literal["Email", "Document"]

# =========================================================
# CREATE USE CASE REQUEST SCHEMA
# =========================================================

# =========================================================
# DELETE WORKFLOW
# =========================================================

DELETE_PASSWORD = "admin_delete_123"


class DeleteWorkflowRequest(BaseModel):
    job_type: JOB_TYPE
    job_id: str
    password: str


@router.get("/workflow/schema")
async def get_workflow_schema():

    return JobConfig.model_json_schema()



# =========================================================
# GET JSON CONFIGURATION OF ANY JOB
# =========================================================


@router.get("/live-status/{job_type}/get/config/{job_id}")
async def get_job_config(
    job_type: JOB_TYPE,
    job_id: str,
    user_id: str,
    db: Connection = Depends(get_db),
):

    try:

        record = await db.fetchrow(
            """
            SELECT
                job_id,
                json_config
            FROM macro_email_doc_agent.email_doc_usecase_jobs
            WHERE (
                $1 = ANY(job_owner)
                OR view_to_all = TRUE
            )
            AND job_type = $2
            AND job_id = $3
            LIMIT 1
            """,
            user_id,
            job_type,
            job_id
        )

        if not record:
            raise HTTPException(
                status_code=404,
                detail="Job config not found"
            )

        record_dict = dict(record)

        # Parse JSON string -> Python dict
        if isinstance(record_dict.get("json_config"), str):
            import json
            record_dict["json_config"] = json.loads(record_dict["json_config"])


        return {
            "status": "SUCCESS",
            "job_type": job_type,
            "user_id": user_id,
            "data": record_dict
        }

    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch job config: {str(e)}"
        )


# =========================================================
# CREATE WORKFLOW
# =========================================================
@router.post("/workflow/create")
async def create_workflow(
    payload: JobConfig,
    db=Depends(get_db)
):

    try:

        await db.execute(
            """
            INSERT INTO macro_email_doc_agent.email_doc_usecase_jobs (

                job_id,
                job_name,
                description,
                job_category,
                json_config,

                current_status,
                job_owner,
                schedule_run_times,
                days_of_week,
                timezone,
                is_active,

                job_type,
                job_trigger_point,

                view_to_all,

                linked_tables

            )
            VALUES (

                $1, $2, $3, $4, $5,
                $6, $7, $8, $9, $10,
                $11, $12, $13, $14, $15
            )
            """,

            # ======================================
            # BASIC INFO
            # ======================================

            payload.meta_data.job_id,
            payload.meta_data.job_name,
            payload.meta_data.job_description,
            payload.meta_data.job_category,

            # ======================================
            # FULL JSON CONFIG
            # ======================================

            json.dumps(
                payload.model_dump(mode="json")
            ),

            # ======================================
            # METADATA
            # ======================================

            payload.meta_data.current_status,
            payload.meta_data.job_owner,
            [t.strftime("%H:%M") for t in payload.meta_data.schedule_run_times],
            payload.meta_data.days_of_week,
            payload.meta_data.timezone,
            payload.meta_data.is_active,

            payload.meta_data.job_type,
            payload.meta_data.job_trigger_point,

            payload.meta_data.view_to_all,

            payload.meta_data.linked_tables
        )

        return {
            "success": True,
            "message": "Workflow Created Successfully"
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to Add New Workflow: {str(e)}"
        )
    
    
# =========================================================
# UPDATE WORKFLOW
# =========================================================
@router.post("/workflow/update/{job_id}")
async def update_workflow(
    job_id: str,
    payload: JobConfig,
    db=Depends(get_db)
):

    try:

        # ==========================================
        # CHECK WORKFLOW EXISTS
        # ==========================================

        existing = await db.fetchrow(
            """
            SELECT job_id
            FROM macro_email_doc_agent.email_doc_usecase_jobs
            WHERE job_id = $1
            """,
            job_id
        )

        if not existing:

            raise HTTPException(
                status_code=404,
                detail=f"Workflow '{job_id}' not found"
            )

        # ==========================================
        # UPDATE WORKFLOW
        # ==========================================

        await db.execute(
            """
            UPDATE macro_email_doc_agent.email_doc_usecase_jobs
            SET

                job_name = $1,
                description = $2,
                job_category = $3,
                json_config = $4,

                current_status = $5,
                job_owner = $6,
                schedule_run_times = $7,
                days_of_week = $8,
                timezone = $9,
                is_active = $10,

                job_type = $11,
                job_trigger_point = $12,

                view_to_all = $13,

                linked_tables = $14,

                updated_at = NOW()

            WHERE job_id = $15
            """,

            # ======================================
            # BASIC INFO
            # ======================================

            payload.meta_data.job_name,
            payload.meta_data.job_description,
            payload.meta_data.job_category,

            # ======================================
            # FULL JSON CONFIG
            # ======================================

            json.dumps(
                payload.model_dump(mode="json")
            ),

            # ======================================
            # METADATA
            # ======================================

            payload.meta_data.current_status,
            payload.meta_data.job_owner,
            [t.strftime("%H:%M") for t in payload.meta_data.schedule_run_times],
            payload.meta_data.days_of_week,
            payload.meta_data.timezone,
            payload.meta_data.is_active,

            payload.meta_data.job_type,
            payload.meta_data.job_trigger_point,

            payload.meta_data.view_to_all,

            payload.meta_data.linked_tables,

            # ======================================
            # WHERE
            # ======================================

            job_id
        )

        return {
            "success": True,
            "message": f"Workflow '{job_id}' Updated Successfully"
        }

    except HTTPException:
        raise

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to Update Workflow: {str(e)}"
        )
    




@router.delete("/workflow/delete")
async def delete_workflow(
    payload: DeleteWorkflowRequest,
    db: Connection = Depends(get_db)
):

    try:

        # ==========================================
        # VALIDATE PASSWORD
        # ==========================================

        if payload.password != DELETE_PASSWORD:

            raise HTTPException(
                status_code=401,
                detail="Invalid password"
            )

        # ==========================================
        # CHECK WORKFLOW EXISTS
        # ==========================================

        existing = await db.fetchrow(
            """
            SELECT job_id
            FROM macro_email_doc_agent.email_doc_usecase_jobs
            WHERE job_id = $1
            AND job_type = $2
            """,
            payload.job_id,
            payload.job_type
        )

        if not existing:

            raise HTTPException(
                status_code=404,
                detail="Workflow not found"
            )

        # ==========================================
        # DELETE WORKFLOW
        # ==========================================

        await db.execute(
            """
            DELETE FROM macro_email_doc_agent.email_doc_usecase_jobs
            WHERE job_id = $1
            AND job_type = $2
            """,
            payload.job_id,
            payload.job_type
        )

        return {
            "success": True,
            "job_type": payload.job_type,
            "job_id": payload.job_id,
            "message": "Workflow deleted successfully"
        }

    except HTTPException:
        raise

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to delete workflow: {str(e)}"
        )