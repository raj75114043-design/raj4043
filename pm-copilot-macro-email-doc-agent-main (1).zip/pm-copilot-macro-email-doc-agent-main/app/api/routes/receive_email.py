import uuid
import asyncio
import json
from datetime import datetime
from typing import List, Optional, Dict, Any
from enum import Enum
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from asyncpg import Connection

from app.services.azure_doc_parsing import DocumentService
from app.dependencies.azure_doc_intelligence import get_document_service
from app.services.s3_blob_management import S3Service
from app.dependencies.s3_blob import get_s3_service


from app.services.save_receive_email import(
    save_received_email,
)

from app.db.pool import get_db

from app.schemas.email import(
    SaveReceivedEmail,
)


from app.email_job_auto_trigger.received_email_job_trigger_service import (
    start_received_email_jobs_background
)

router = APIRouter(prefix="/email", tags=["Receive Email"])

class EmailReceiveCreateRequest(BaseModel):
    subject: Optional[str] = None
    # email_from: Optional[str] = None
    # email_to: Optional[str] = None

class EmailReceiveDeleteRequest(BaseModel):
    subject: Optional[str] = None
    # email_from: Optional[str] = None
    # email_to: Optional[str] = None

# =========================================================
# SHAREPOINT LINK REQUESTS
# =========================================================

class SharepointLinkCreateRequest(BaseModel):
    sharepoint_link: str
    type: str


class SharepointLinkDeleteRequest(BaseModel):
    id: int



@router.post("/received/email")
async def save_received_email_db(
    request: SaveReceivedEmail,
    db: Connection=Depends(get_db)
    ):
    try:

        received_time = datetime.fromisoformat(
            request.receivedTime.replace("Z", "+00:00")
        ).replace(tzinfo=None)
            
        attachments = request.attachments or []
        attachments_data = [
            att.dict() for att in attachments
        ]

        result = await save_received_email(
            db=db,
            email_from=request.email_from,
            to_list=request.to_list,
            cc_list=request.cc_list,
            subject=request.subject,
            body=request.body,
            received_time=received_time,
            attachments=attachments_data
        )

        # FIRE-AND-FORGET
        start_received_email_jobs_background()

        return result

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=str(e)
        )
    

@router.get("/received/email/track-ids")
async def get_email_receive_track_ids(
    db: Connection = Depends(get_db),
):
    try:
        query = """
            SELECT subject
            FROM macro_email_doc_agent.email_receive_subjects
        """

        records = await db.fetch(query)

        return {
            "subjects": list(set(r["subject"] for r in records if r["subject"]))
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch email ids: {str(e)}",
        )
    
@router.post("/received/email/track-ids")
async def add_email_receive_track_id(
    request: EmailReceiveCreateRequest,
    db: Connection = Depends(get_db),
):
    try:
        query = """
            INSERT INTO macro_email_doc_agent.email_receive_subjects
            (subject)
            VALUES ($1)
        """

        await db.execute(
            query,
            request.subject,
        )

        return {"message": "Record inserted successfully"}

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to insert record: {str(e)}",
        )
    

@router.delete("/received/email/track-ids")
async def delete_email_receive_track_id(
    request: EmailReceiveDeleteRequest,
    db: Connection = Depends(get_db),
):
    try:
        conditions = []
        values = []
        idx = 1

        if request.subject:
            conditions.append(f"subject = ${idx}")
            values.append(request.subject)
            idx += 1

        if not conditions:
            raise HTTPException(
                status_code=400,
                detail="At least one field must be provided for deletion",
            )

        query = f"""
            DELETE FROM macro_email_doc_agent.email_receive_subjects
            WHERE {' AND '.join(conditions)}
        """

        await db.execute(query, *values)

        return {"message": "Record(s) deleted successfully"}

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to delete record: {str(e)}",
        )
    


# =========================================================
# GET ALL SHAREPOINT LINKS
# =========================================================

@router.get("/sharepoint-sync-links")
async def get_sharepoint_sync_links(
    db: Connection = Depends(get_db),
):

    try:

        query = """
            SELECT
                id,
                sharepoint_link,
                type
            FROM macro_email_doc_agent.sharepoint_to_blob_sync_links
            ORDER BY id DESC
        """

        records = await db.fetch(query)

        return {
            "total": len(records),
            "data": [
                dict(record)
                for record in records
            ]
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch sharepoint links: {str(e)}"
        )
    

# =========================================================
# ADD SHAREPOINT LINK
# =========================================================

@router.post("/sharepoint-sync-links")
async def add_sharepoint_sync_link(
    request: SharepointLinkCreateRequest,
    db: Connection = Depends(get_db),
):

    try:

        query = """
            INSERT INTO macro_email_doc_agent.sharepoint_to_blob_sync_links
            (
                sharepoint_link,
                type
            )
            VALUES
            (
                $1,
                $2
            )
        """

        await db.execute(
            query,
            request.sharepoint_link,
            request.type
        )

        return {
            "success": True,
            "message": "Sharepoint link added successfully"
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to add sharepoint link: {str(e)}"
        )
    
    
# =========================================================
# DELETE SHAREPOINT LINK
# =========================================================

@router.delete("/sharepoint-sync-links")
async def delete_sharepoint_sync_link(
    request: SharepointLinkDeleteRequest,
    db: Connection = Depends(get_db),
):

    try:

        query = """
            DELETE FROM macro_email_doc_agent.sharepoint_to_blob_sync_links
            WHERE id = $1
        """

        result = await db.execute(
            query,
            request.id
        )

        return {
            "success": True,
            "message": "Sharepoint link deleted successfully"
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to delete sharepoint link: {str(e)}"
        )
    


# =========================================================
# GET RECEIVED EMAILS WITH PAGINATION
# =========================================================

@router.get("/received/emails")
async def get_received_emails(
    limit: int = 20,
    offset: int = 0,
    db: Connection = Depends(get_db),
):

    try:

        # =====================================================
        # VALIDATE LIMIT
        # =====================================================

        if limit <= 0:
            limit = 20

        if limit > 100:
            limit = 100

        if offset < 0:
            offset = 0

        # =====================================================
        # TOTAL COUNT
        # =====================================================

        count_query = """
            SELECT COUNT(*) AS total
            FROM macro_email_doc_agent.email_received_tracker
        """

        total_records = await db.fetchval(count_query)

        # =====================================================
        # FETCH RECORDS
        # =====================================================

        query = """
            SELECT
                id,
                email_from,
                to_list,
                cc_list,
                subject,
                body,
                received_time,
                attachments,
                created_at
            FROM macro_email_doc_agent.email_received_tracker
            ORDER BY created_at DESC
            LIMIT $1
            OFFSET $2
        """

        records = await db.fetch(
            query,
            limit,
            offset
        )

        # =====================================================
        # RESPONSE
        # =====================================================

        return {
            "success": True,

            "pagination": {
                "limit": limit,
                "offset": offset,
                "total": total_records,
                "has_next": (offset + limit) < total_records,
                "current_page": (offset // limit) + 1
            },

            "data": [
                dict(record)
                for record in records
            ]
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch received emails: {str(e)}"
        )
    

# =========================================================
# DELETE OLD RECEIVED EMAILS
# Keeps only last 14 days records
# =========================================================

@router.delete("/received/emails/cleanup")
async def cleanup_old_received_emails(
    db: Connection = Depends(get_db),
):

    try:

        query = """
            DELETE FROM macro_email_doc_agent.email_received_tracker
            WHERE created_at < NOW() - INTERVAL '14 days'
        """

        result = await db.execute(query)

        return {
            "success": True,
            "message": "Old received emails deleted successfully (kept last 14 days only)",
            "db_response": result
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to cleanup received emails: {str(e)}"
        )