import asyncio
import uuid
import json
import time
import json
import uuid
import uuid
import asyncio
from app.schemas.general import UserInfoRequest
from datetime import datetime
from typing import List, Optional, Dict, Any
from asyncpg import Connection
from app.db.pool import get_db
from typing import Literal
from fastapi import APIRouter, Depends, BackgroundTasks, HTTPException, status, Body
from pydantic import BaseModel

from pathlib import Path

from app.services.azure_doc_parsing import DocumentService
from app.dependencies.azure_doc_intelligence import get_document_service
from app.services.s3_blob_management import S3Service
from app.dependencies.s3_blob import get_s3_service

from app.db.pool import get_db
from pydantic import BaseModel
from app.utils.timezone import get_datetime_now_without_zone


from app.email_doc_job_engine.main_orchestrator.orchestrator import run_job


from app.email_doc_job_engine.main_orchestrator.job_queue_manager import (
    enqueue_job,
    get_job_queue_state
)


from app.email_doc_job_engine.utils.execution_store import get_execution
    
from app.email_doc_job_engine.job_schema.job_config_class import JobConfig


router = APIRouter(prefix="/email-doc/job-orchestrator", tags=["Email-Document Job Runner"])

# =========================================================
# RUN ANY JOB
# =========================================================


@router.post("/run/email-job/{job_id}")
async def run_job_api(
    job_id: str, 
    db: Connection=Depends(get_db),
    service: DocumentService = Depends(get_document_service),
    s3: S3Service = Depends(get_s3_service)
    ):
    try:
        result = await run_job(
            db=db, 
            azure_service=service, 
            s3_service=s3, 
            job_id=job_id
            )
        return {"status": "SUCCESS", "job_id": job_id, "result": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

# ----------- Make batch processing



# =========================================================
# RUN JOB (ASYNC / BATCH)
# =========================================================

@router.post("/run/email-job-new/{job_id}")
async def run_job_api(
    job_id: str
):

    result = await enqueue_job(
        job_id=job_id
    )

    if not result["success"]:

        raise HTTPException(
            status_code=429,
            detail=result
        )

    return result


# =========================================================
# GET EXECUTION STATUS
# =========================================================
@router.get("/run/email-job/status/{execution_id}")
async def get_execution_status(
    execution_id: str
):

    execution = await get_execution(execution_id)

    if not execution:
        raise HTTPException(
            status_code=404,
            detail="Execution ID not found or expired"
        )

    return execution



@router.get("/queue/status")
async def get_queue_status():

    return await get_job_queue_state()