# import asyncio
# import uuid
# import json
# import time
# import json
# import uuid
# import uuid
# import asyncio
# from app.schemas.general import UserInfoRequest
# from datetime import datetime
# from typing import List, Optional, Dict, Any
# from asyncpg import Connection
# from app.db.pool import get_db
# from typing import Literal
# from typing import get_args
# from fastapi import APIRouter, Depends, HTTPException, status, Body
# from pydantic import BaseModel
# from app.core.llm_client import get_llm_client
# from pathlib import Path
# from fastapi import APIRouter, Depends, BackgroundTasks, HTTPException
# from app.services.azure_doc_parsing import DocumentService
# from app.dependencies.azure_doc_intelligence import get_document_service
# from app.services.s3_blob_management import S3Service
# from app.dependencies.s3_blob import get_s3_service
# from app.config.azure_doc_settings import get_config
# from app.db.pool import get_db
# from app.schemas.general import UpdateJobConfigRequest, ReviewDraftMailRequest, CreateUseCaseRequest
# from fastapi import UploadFile, File, Form
# from typing import get_args, get_origin
# from pydantic import BaseModel
# from app.utils.timezone import get_datetime_now_without_zone


# from app.email_doc_job_engine.main_orchestrator.orchestrator import run_job


# from app.email_doc_job_engine.utils.execution_store import (
#     create_execution
# )


# from app.email_doc_job_engine.utils.execution_store import get_execution
    
# from app.email_doc_job_engine.job_schema.job_config_class import JobConfig


# router = APIRouter(prefix="/email-doc/job-orchestrator", tags=["Email-Document Job Orchestrator"])

# JOB_TYPE = Literal["Email", "Document"]

# TABLE_SCHEMA = "macro_email_doc_agent"
# TABLE_NAME = "email_doc_usecase_jobs"

# EDITABLE_COLUMNS = [
#     "schedule_run_times",
#     "days_of_week",
#     "timezone",
#     "is_active",
#     "job_owner",
#     "job_type",
#     "job_trigger_point",
#     "is_approval_required",
#     "approval_status",
#     "view_to_all",
#     "is_exandable",
#     "linked_tables",
# ]

# # =========================================================
# # CREATE USE CASE REQUEST SCHEMA
# # =========================================================


# @router.get("/health")
# async def check_health():
#     """
#     Generate structured email JSON from user prompt
#     """
#     try:
#         message = "Good! Email / DOcument Job Orchestrator Endpoints Running..."
#         return message

#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))


# @router.get("/workflow/schema")
# async def get_workflow_schema():

#     return JobConfig.model_json_schema()


# # =========================================================
# # CREATE WORKFLOW
# # =========================================================
# @router.post("/workflow/create")
# async def create_workflow(
#     payload: JobConfig,
#     db=Depends(get_db)
# ):

#     try:

#         await db.execute(
#             """
#             INSERT INTO macro_email_doc_agent.email_doc_usecase_jobs (

#                 job_id,
#                 job_name,
#                 description,
#                 job_category,
#                 json_config,

#                 current_status,
#                 job_owner,
#                 schedule_run_times,
#                 days_of_week,
#                 timezone,
#                 is_active,

#                 job_type,
#                 job_trigger_point,

#                 view_to_all,

#                 linked_tables

#             )
#             VALUES (

#                 $1, $2, $3, $4, $5,
#                 $6, $7, $8, $9, $10,
#                 $11, $12, $13, $14, $15
#             )
#             """,

#             # ======================================
#             # BASIC INFO
#             # ======================================

#             payload.meta_data.job_id,
#             payload.meta_data.job_name,
#             payload.meta_data.job_description,
#             payload.meta_data.job_category,

#             # ======================================
#             # FULL JSON CONFIG
#             # ======================================

#             json.dumps(
#                 payload.model_dump(mode="json")
#             ),

#             # ======================================
#             # METADATA
#             # ======================================

#             payload.meta_data.current_status,
#             payload.meta_data.job_owner,
#             [t.strftime("%H:%M") for t in payload.meta_data.schedule_run_times],
#             payload.meta_data.days_of_week,
#             payload.meta_data.timezone,
#             payload.meta_data.is_active,

#             payload.meta_data.job_type,
#             payload.meta_data.job_trigger_point,

#             payload.meta_data.view_to_all,

#             payload.meta_data.linked_tables
#         )

#         return {
#             "success": True,
#             "message": "Workflow Created Successfully"
#         }

#     except Exception as e:

#         raise HTTPException(
#             status_code=500,
#             detail=f"Failed to Add New Workflow: {str(e)}"
#         )
    
    
# # =========================================================
# # UPDATE WORKFLOW
# # =========================================================
# @router.post("/workflow/update/{job_id}")
# async def update_workflow(
#     job_id: str,
#     payload: JobConfig,
#     db=Depends(get_db)
# ):

#     try:

#         # ==========================================
#         # CHECK WORKFLOW EXISTS
#         # ==========================================

#         existing = await db.fetchrow(
#             """
#             SELECT job_id
#             FROM macro_email_doc_agent.email_doc_usecase_jobs
#             WHERE job_id = $1
#             """,
#             job_id
#         )

#         if not existing:

#             raise HTTPException(
#                 status_code=404,
#                 detail=f"Workflow '{job_id}' not found"
#             )

#         # ==========================================
#         # UPDATE WORKFLOW
#         # ==========================================

#         await db.execute(
#             """
#             UPDATE macro_email_doc_agent.email_doc_usecase_jobs
#             SET

#                 job_name = $1,
#                 description = $2,
#                 job_category = $3,
#                 json_config = $4,

#                 current_status = $5,
#                 job_owner = $6,
#                 schedule_run_times = $7,
#                 days_of_week = $8,
#                 timezone = $9,
#                 is_active = $10,

#                 job_type = $11,
#                 job_trigger_point = $12,

#                 view_to_all = $13,

#                 linked_tables = $14,

#                 updated_at = NOW()

#             WHERE job_id = $15
#             """,

#             # ======================================
#             # BASIC INFO
#             # ======================================

#             payload.meta_data.job_name,
#             payload.meta_data.job_description,
#             payload.meta_data.job_category,

#             # ======================================
#             # FULL JSON CONFIG
#             # ======================================

#             json.dumps(
#                 payload.model_dump(mode="json")
#             ),

#             # ======================================
#             # METADATA
#             # ======================================

#             payload.meta_data.current_status,
#             payload.meta_data.job_owner,
#             [t.strftime("%H:%M") for t in payload.meta_data.schedule_run_times],
#             payload.meta_data.days_of_week,
#             payload.meta_data.timezone,
#             payload.meta_data.is_active,

#             payload.meta_data.job_type,
#             payload.meta_data.job_trigger_point,

#             payload.meta_data.view_to_all,

#             payload.meta_data.linked_tables,

#             # ======================================
#             # WHERE
#             # ======================================

#             job_id
#         )

#         return {
#             "success": True,
#             "message": f"Workflow '{job_id}' Updated Successfully"
#         }

#     except HTTPException:
#         raise

#     except Exception as e:

#         raise HTTPException(
#             status_code=500,
#             detail=f"Failed to Update Workflow: {str(e)}"
#         )
    

    
# @router.get("/live-status/job-types")
# async def get_job_types():
#     """
#     Return supported job types.
#     """

#     return {
#         "job_types": list(get_args(JOB_TYPE))
#     }


# @router.get("/live-status/{job_type}/table")
# async def get_live_status_table(
#     job_type: JOB_TYPE,
#     user_id: str,
#     db: Connection = Depends(get_db),
# ):
#     try:

#         records = await db.fetch(
#             """
#             SELECT
#             job_id,
#             job_name,
#             description,
#             job_category as team,
#             is_active,
#             current_status,
#             job_owner,
#             schedule_run_times,
#             days_of_week,
#             timezone,
#             last_run_at,
#             last_run_status,
#             created_at,
#             last_executed_result,
#             job_trigger_point,
#             is_approval_required,
#             approval_status,
#             view_to_all,
#             is_exandable,
#             approved_by,
#             approved_at
#             FROM macro_email_doc_agent.email_doc_usecase_jobs
#             WHERE (
#                 $1 = ANY(job_owner)
#                 OR view_to_all = TRUE
#             )
#             AND job_type = $2
#             ORDER BY job_id
#             """,
#             user_id,
#             job_type
#         )

#         data = [
#             dict(record)
#             for record in records
#         ]

#         return {
#             "job_type": job_type,
#             "user_id": user_id,
#             "rows": len(data),
#             "data": data
#         }

#     except Exception as e:
#         raise HTTPException(
#             status_code=500,
#             detail=f"Failed to fetch job table: {str(e)}"
#         )
    


# @router.get("/live-status/{job_type}/get/table/drill-down-tables/{job_id}")
# async def get_live_status_drill_down_tables(
#     job_type: JOB_TYPE,
#     job_id: str,
#     user_id: str,
#     db: Connection = Depends(get_db),
# ):

#     try:

#         # =====================================================
#         # FIXED TABLES
#         # =====================================================

#         FIXED_TABLES_EMAIL_JOB = [
#             "macro_email_doc_agent.email_doc_usecase_jobs",
#             "macro_email_doc_agent.email_doc_usecase_jobs_email_send",
#             "macro_email_doc_agent.email_doc_usecase_jobs_run_status"
#         ]

#         FIXED_TABLES_DOCUMENT_JOB = [
#             "macro_email_doc_agent.email_doc_usecase_jobs",
#             "macro_email_doc_agent.email_doc_usecase_jobs_email_send",
#             "macro_email_doc_agent.email_doc_usecase_jobs_run_status"
#         ]

#         # =====================================================
#         # SELECT BASE TABLES
#         # =====================================================

#         if job_type == "Email":

#             FIXED_TABLES = FIXED_TABLES_EMAIL_JOB

#         elif job_type == "Document":

#             FIXED_TABLES = FIXED_TABLES_DOCUMENT_JOB

#         else:

#             FIXED_TABLES = []

#         # =====================================================
#         # --> FETCH LINKED TABLES
#         # =====================================================

#         linked_table_query = """
#             SELECT linked_tables
#             FROM macro_email_doc_agent.email_doc_usecase_jobs
#             WHERE job_id = $1
#             AND job_type = $2
#             LIMIT 1
#         """

#         linked_table_row = await db.fetchrow(
#             linked_table_query,
#             job_id,
#             job_type
#         )

#         if linked_table_row:

#             linked_tables = (
#                 linked_table_row.get("linked_tables")
#                 or []
#             )

#             # append linked tables
#             FIXED_TABLES.extend(linked_tables)

#         # =====================================================
#         # REMOVE DUPLICATES
#         # =====================================================

#         FIXED_TABLES = list(set(FIXED_TABLES))

#         tables = []

#         # =====================================================
#         # FETCH DATA
#         # =====================================================

#         for table_name in FIXED_TABLES:

#             try:

#                 query = f"""
#                     SELECT *
#                     FROM {table_name}
#                     LIMIT 1000
#                 """

#                 # Apply filter only to known tables
#                 if table_name in [
#                     "macro_email_doc_agent.email_doc_usecase_jobs",
#                     "macro_email_doc_agent.email_doc_usecase_jobs_email_send",
#                     "macro_email_doc_agent.email_doc_usecase_jobs_run_status"
#                 ]:

#                     query = f"""
#                         SELECT *
#                         FROM {table_name}
#                         WHERE job_id = $1
#                         ORDER BY created_at DESC
#                         LIMIT 1000
#                     """

#                     rows = await db.fetch(
#                         query,
#                         job_id
#                     )

#                 else:

#                     rows = await db.fetch(query)


#                 data = [
#                     dict(row)
#                     for row in rows
#                 ]

#                 tables.append({
#                     "table_name": table_name,
#                     "rows": len(data),
#                     "data": data
#                 })

#             except Exception as table_error:

#                 # Prevent one bad table from breaking all response
#                 tables.append({
#                     "table_name": table_name,
#                     "rows": 0,
#                     "data": [],
#                     "error": str(table_error)
#                 })

#         # =====================================================
#         # RESPONSE
#         # =====================================================

#         return {
#             "job_type": job_type,
#             "job_id": job_id,
#             "user_id": user_id,
#             "table_count": len(tables),
#             "tables": tables
#         }

#     except Exception as e:

#         raise HTTPException(
#             status_code=500,
#             detail=f"Failed to fetch drill down tables: {str(e)}"
#         )



# # =========================================================
# # RUN ANY JOB
# # =========================================================


# @router.post("/run/email-job/{job_id}")
# async def run_job_api(
#     job_id: str, 
#     db: Connection=Depends(get_db),
#     service: DocumentService = Depends(get_document_service),
#     s3: S3Service = Depends(get_s3_service)
#     ):
#     try:
#         result = await run_job(
#             db=db, 
#             azure_service=service, 
#             s3_service=s3, 
#             job_id=job_id
#             )
#         return {"status": "SUCCESS", "job_id": job_id, "result": result}
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))
    

# # ----------- Make batch processing



# # =========================================================
# # RUN JOB (ASYNC / BATCH)
# # =========================================================

# @router.post("/run/email-job-new/{job_id}")
# async def run_job_api(
#     job_id: str,
#     # db: Connection = Depends(get_db),
#     service: DocumentService = Depends(get_document_service),
#     s3: S3Service = Depends(get_s3_service)
# ):

#     execution_id = str(uuid.uuid4())

#     await create_execution(
#         execution_id=execution_id,
#         job_id=job_id
#     )

#     asyncio.create_task(
#         execute_job_background(
#             execution_id=execution_id,
#             service=service,
#             s3=s3,
#             job_id=job_id
#         )
#     )

#     return {
#         "status": "QUEUED",
#         "execution_id": execution_id,
#         "job_id": job_id
#     }


# # =========================================================
# # GET EXECUTION STATUS
# # =========================================================
# @router.get("/run/email-job/status/{execution_id}")
# async def get_execution_status(
#     execution_id: str
# ):

#     execution = await get_execution(execution_id)

#     if not execution:
#         raise HTTPException(
#             status_code=404,
#             detail="Execution ID not found or expired"
#         )

#     return execution


# # =========================================================
# # GET JSON CONFIGURATION OF ANY JOB
# # =========================================================


# @router.get("/live-status/{job_type}/get/config/{job_id}")
# async def get_job_config(
#     job_type: JOB_TYPE,
#     job_id: str,
#     user_id: str,
#     db: Connection = Depends(get_db),
# ):

#     try:

#         record = await db.fetchrow(
#             """
#             SELECT
#                 job_id,
#                 json_config
#             FROM macro_email_doc_agent.email_doc_usecase_jobs
#             WHERE (
#                 $1 = ANY(job_owner)
#                 OR view_to_all = TRUE
#             )
#             AND job_type = $2
#             AND job_id = $3
#             LIMIT 1
#             """,
#             user_id,
#             job_type,
#             job_id
#         )

#         if not record:
#             raise HTTPException(
#                 status_code=404,
#                 detail="Job config not found"
#             )

#         record_dict = dict(record)

#         # Parse JSON string -> Python dict
#         if isinstance(record_dict.get("json_config"), str):
#             import json
#             record_dict["json_config"] = json.loads(record_dict["json_config"])


#         return {
#             "status": "SUCCESS",
#             "job_type": job_type,
#             "user_id": user_id,
#             "data": record_dict
#         }

#     except HTTPException:
#         raise

#     except Exception as e:
#         raise HTTPException(
#             status_code=500,
#             detail=f"Failed to fetch job config: {str(e)}"
#         )


# # =========================================================
# # UPDATE CONFIG
# # =========================================================

# @router.post("/live-status/{job_type}/update/config/{job_id}")
# async def update_job_config(
#     job_type: JOB_TYPE,
#     job_id: str,
#     user_id: str,
#     payload: UpdateJobConfigRequest,
#     db: Connection = Depends(get_db),
# ):

#     try:

#         config_data = payload.json_config
        
#         if isinstance(config_data, str):
#             try:
#                 config_data = json.loads(config_data)
#             except json.JSONDecodeError:
#                 raise HTTPException(
#                     status_code=400,
#                     detail="Invalid JSON format in json_config"
#                 )


#         updated_record = await db.fetchrow(
#             """
#             UPDATE macro_email_doc_agent.email_doc_usecase_jobs
#             SET
#                 json_config = $4::jsonb,
#                 updated_at = NOW()
#             WHERE (
#                 $1 = ANY(job_owner)
#                 OR view_to_all = TRUE
#             )
#             AND job_type = $2
#             AND job_id = $3
#             RETURNING
#                 job_id,
#                 job_name,
#                 job_type,
#                 json_config,
#                 updated_at
#             """,
#             user_id,
#             job_type,
#             job_id,
#             json.dumps(config_data)
#         )

#         if not updated_record:
#             raise HTTPException(
#                 status_code=404,
#                 detail="Job config not found or access denied"
#             )

#         # Once user save this also update schedule time and day and timezone if user has changed

#         return {
#             "status": "SUCCESS",
#             "message": "Job config updated successfully",
#             "job_type": job_type,
#             "job_id": job_id,
#             "updated_data": dict(updated_record)
#         }

#     except HTTPException:
#         raise

#     except Exception as e:
#         raise HTTPException(
#             status_code=500,
#             detail=f"Failed to update job config: {str(e)}"
#         )





# # =========================================================
# # REQUEST MODEL
# # =========================================================

# class UpdateColumnValueRequest(BaseModel):

#     column_name: str
#     new_value: Any


# # =========================================================
# # GET EDITABLE FIELDS
# # =========================================================

# @router.get("/job-config/editable-fields/{job_id}")
# async def get_editable_fields(
#     job_id: str,
#     db: Connection = Depends(get_db),
# ):

#     try:

#         # =====================================================
#         # FETCH CURRENT RECORD
#         # =====================================================

#         query = f"""
#         SELECT *
#         FROM {TABLE_SCHEMA}.{TABLE_NAME}
#         WHERE job_id = $1
#         LIMIT 1
#         """

#         row = await db.fetchrow(query, job_id)

#         if not row:

#             raise HTTPException(
#                 status_code=404,
#                 detail="Job not found"
#             )

#         row_dict = dict(row)

#         # =====================================================
#         # FETCH COLUMN DATA TYPES
#         # =====================================================

#         datatype_query = """
#         SELECT
#             column_name,
#             data_type,
#             udt_name
#         FROM information_schema.columns
#         WHERE table_schema = $1
#         AND table_name = $2
#         """

#         datatype_rows = await db.fetch(
#             datatype_query,
#             TABLE_SCHEMA,
#             TABLE_NAME
#         )

#         datatype_map = {
#             r["column_name"]: {
#                 "data_type": r["data_type"],
#                 "postgres_type": r["udt_name"]
#             }
#             for r in datatype_rows
#         }

#         # =====================================================
#         # BUILD RESPONSE
#         # =====================================================

#         editable_fields = []

#         for column_name in EDITABLE_COLUMNS:

#             editable_fields.append({
#                 "column_name": column_name,
#                 "current_value": row_dict.get(column_name),
#                 "data_type": datatype_map.get(column_name, {}).get("data_type"),
#                 "postgres_type": datatype_map.get(column_name, {}).get("postgres_type")
#             })

#         return {
#             "job_id": job_id,
#             "table_name": f"{TABLE_SCHEMA}.{TABLE_NAME}",
#             "editable_fields": editable_fields
#         }

#     except HTTPException:
#         raise

#     except Exception as e:

#         raise HTTPException(
#             status_code=500,
#             detail=f"Failed to fetch editable fields: {str(e)}"
#         )


# # =========================================================
# # UPDATE COLUMN VALUE
# # =========================================================

# @router.post("/job-config/update-field/{job_id}")
# async def update_editable_field(
#     job_id: str,
#     payload: UpdateColumnValueRequest,
#     db: Connection = Depends(get_db),
# ):

#     try:

#         column_name = payload.column_name
#         new_value = payload.new_value

#         # =====================================================
#         # VALIDATE COLUMN
#         # =====================================================

#         if column_name not in EDITABLE_COLUMNS:

#             raise HTTPException(
#                 status_code=400,
#                 detail=f"Column '{column_name}' is not editable"
#             )

#         # =====================================================
#         # UPDATE QUERY
#         # =====================================================

#         query = f"""
#         UPDATE {TABLE_SCHEMA}.{TABLE_NAME}
#         SET
#             {column_name} = $1,
#             updated_at = NOW()
#         WHERE job_id = $2
#         RETURNING
#             job_id,
#             {column_name}
#         """

#         updated_row = await db.fetchrow(
#             query,
#             new_value,
#             job_id
#         )

#         if not updated_row:

#             raise HTTPException(
#                 status_code=404,
#                 detail="Job not found"
#             )

#         return {
#             "status": "SUCCESS",
#             "job_id": updated_row["job_id"],
#             "updated_column": column_name,
#             "new_value": updated_row[column_name]
#         }

#     except HTTPException:
#         raise

#     except Exception as e:

#         raise HTTPException(
#             status_code=500,
#             detail=f"Failed to update field: {str(e)}"
#         )
    

# # =========================================================
# # GET ALL JOB IDs where APPROVAL REQUIRED
# # =========================================================

# @router.get("/live-status/{job_type}/get/job-ids/for-approval")
# async def get_jobs_for_approval(
#     job_type: JOB_TYPE,
#     user_id: str,
#     db: Connection = Depends(get_db),
# ):

#     try:

#         rows = await db.fetch(
#             """
#             SELECT job_id
#             FROM macro_email_doc_agent.email_doc_usecase_jobs
#             WHERE is_approval_required = TRUE
#               AND approval_status IS NULL
#               AND job_type = $1
#             ORDER BY created_at DESC
#             """,
#             job_type,
#         )

#         job_ids = [row["job_id"] for row in rows]

#         return {
#             "status": "SUCCESS",
#             "job_type": job_type,
#             "count": len(job_ids),
#             "job_ids": job_ids
#         }

#     except Exception as e:
#         raise HTTPException(
#             status_code=500,
#             detail=f"Failed to fetch jobs for approval: {str(e)}"
#         )


# # =========================================================
# # GET ALL PENDING DRAFTED MAILS
# # =========================================================

# @router.get("/live-status/{job_type}/get/drafted-mails/{job_id}")
# async def get_pending_mails(
#     job_type: JOB_TYPE,
#     job_id: str,
#     user_id: str,
#     db: Connection = Depends(get_db),
# ):

#     try:

#         records = await db.fetch(
#             """
#             SELECT
#                 id,
#                 job_id,
#                 to_list,
#                 cc_list,
#                 bcc_list,
#                 email_subject,
#                 email_body,
#                 attachments,
#                 is_approval_required,
#                 is_approved,
#                 created_at,
#                 updated_at,
#                 mail_status
#             FROM macro_email_doc_agent.email_doc_usecase_jobs_email_send
#             WHERE job_id = $1
#             AND is_approval_required = TRUE
#             AND is_approved IS NULL
#             ORDER BY created_at DESC
#             """,
#             job_id
#         )

#         return {
#             "status": "SUCCESS",
#             "job_type": job_type,
#             "user_id": user_id,
#             "total": len(records),
#             "data": [dict(r) for r in records]
#         }

#     except Exception as e:
#         raise HTTPException(
#             status_code=500,
#             detail=f"Failed to fetch drafted mails: {str(e)}"
#         )
    

# # =========================================================
# # APPROVE / REVIEW DRAFT MAIL
# # =========================================================

# @router.post("/live-status/{job_type}/approve/drafted-mail/{job_id}/{id}/{approval_status}")
# async def approve_drafted_mail(
#     job_type: JOB_TYPE,
#     job_id: str,
#     id: int,
#     approval_status: bool,
#     user_id: str,
#     payload: ReviewDraftMailRequest,
#     db: Connection = Depends(get_db),
# ):

#     try:
#         mail_status=None
#         now = datetime.now()

#         # ============================================
#         # 1. UPDATE SINGLE DRAFT MAIL
#         # ============================================
#         if approval_status:
#             mail_status = "APPROVED"
#         else:
#             mail_status = "REJECTED"    


#         record = await db.fetchrow(
#             """
#             UPDATE macro_email_doc_agent.email_doc_usecase_jobs_email_send
#             SET
#                 reviewed_to_list = $1,
#                 reviewed_cc_list = $2,
#                 reviewed_bcc_list = $3,
#                 reviewed_email_subject = $4,
#                 reviewed_email_body = $5,
#                 reviewed_attachments = $6::jsonb,

#                 is_approved = $12,
#                 approved_by = $7,
#                 approved_at = $8,

#                 mail_status = $14,
#                 remarks = $9,

#                 updated_at = $10

#             WHERE id = $11
#             AND job_id = $13
#             AND is_approval_required = TRUE
#             RETURNING job_id
#             """,
#             payload.reviewed_to_list,
#             payload.reviewed_cc_list,
#             payload.reviewed_bcc_list,

#             payload.reviewed_email_subject,
#             payload.reviewed_email_body,

#             json.dumps(payload.reviewed_attachments or []),

#             payload.approved_by or str(user_id),
#             now,

#             payload.remarks,
#             now,

#             id,
#             approval_status,
#             job_id,
#             mail_status
#         )

#         if not record:
#             raise HTTPException(status_code=404, detail="Draft mail not found")

#         job_id = record["job_id"]

#         # ============================================
#         # 2. CHECK IF ALL ROWS ARE APPROVED
#         # ============================================

#         pending_check = await db.fetchval(
#             """
#             SELECT COUNT(*)
#             FROM macro_email_doc_agent.email_doc_usecase_jobs_email_send
#             WHERE job_id = $1
#               AND is_approval_required = TRUE
#               AND is_approved IS NULL
#             """,
#             job_id
#         )

#         # ============================================
#         # 3. IF NO PENDING APPROVALS → UPDATE JOB TABLE
#         # ============================================

#         if pending_check == 0:

#             await db.execute(
#                 """
#                 UPDATE macro_email_doc_agent.email_doc_usecase_jobs
#                 SET
#                     approval_status = TRUE,
#                     updated_at = NOW()
#                 WHERE job_id = $1
#                 AND is_approval_required = TRUE
#                 """,
#                 job_id
#             )

#         return {
#             "status": "SUCCESS",
#             "message": "Draft mail approved successfully",
#             "draft_mail_id": id,
#             "job_id": job_id,
#             "job_approval_status_updated": pending_check == 0,
#             "approved_at": str(now)
#         }

#     except HTTPException:
#         raise

#     except Exception as e:
#         raise HTTPException(
#             status_code=500,
#             detail=f"Failed to approve drafted mail: {str(e)}"
#         )
