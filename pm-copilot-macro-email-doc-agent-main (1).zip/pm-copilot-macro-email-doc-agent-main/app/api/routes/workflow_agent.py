import uuid
import asyncio
import json
from datetime import datetime
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from asyncpg import Connection

from app.services.workflow_email_send import(
    send_workflow_step_email
)

from app.config.data_fetch_config import EMAIL_DOC_AGENT_SCHEMA
from app.db.pool import get_connection

from app.schemas.worklfow_email import(
    SendWorkflowEmailRequest,
    SendWorkflowEmailStartResponse,
    SendWorkflowEmailStatusResponse,
    ScheduleWorkflowEmailRequest,
    ScheduleWorkflowEmailResponse,
)

router = APIRouter(prefix="/worklflow-agent", tags=["Workflow Agent Plugins"])

WORKFLOW_EMAIL_JOBS: Dict[str, Dict[str, Any]] = {}

async def _save_workflow_email_schedule(token_id: str, request: ScheduleWorkflowEmailRequest):

    base_query  = f"""
    INSERT INTO {EMAIL_DOC_AGENT_SCHEMA}.workflow_email_scheduled_jobs
    (
        token_id,
        scheduled_id,
        workflow_name,
        step_id,
        allowed_sites,
        columns_name,
        global_filters,
        to_list,
        cc_list,
        bcc_list,
        is_recurring,
        schedule_time,
        schedule_time_zone,
        days_of_week,
        scheduled_by
    )
    VALUES
    """

    try:
        schedule_time = None

        if len(request.schedule_time) > 4:
            raise HTTPException(
                status_code=400,
                detail="Maximum 4 schedule times allowed"
            )
        
        days_of_week = [day.value for day in request.days_of_week]

        values_clause = []
        params = []
        param_index = 1

        generated_ids = []

        for time_str in request.schedule_time:

            try:
                schedule_time = datetime.strptime(time_str, "%H:%M").time()
            except ValueError:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid time format: {time_str}. Use HH:MM"
                )

            schedule_id = str(uuid.uuid4())
            generated_ids.append(schedule_id)

            placeholders = []
            row_values = [
                token_id,
                schedule_id,
                request.workflow_name,
                request.step_id,
                request.allowed_sites,
                request.columns_name,
                json.dumps(request.global_filters), 
                request.to_list,
                request.cc_list,
                request.bcc_list,
                request.is_recurring,
                schedule_time,
                request.schedule_time_zone,
                days_of_week,
                request.user_id,
            ]

            placeholders = [
                f"${i}" for i in range(param_index, param_index + len(row_values))
            ]
            param_index += len(row_values)

            values_clause.append(f"({', '.join(placeholders)})")
            params.extend(row_values)

        final_query = base_query.strip() + " " + ", ".join(values_clause)

        async with get_connection() as db:
            await db.execute(final_query, *params)

        return generated_ids

    except Exception as e:
        raise RuntimeError(f"Email scheduling failed: {str(e)}")
    

async def _run_workflow_email_job(
    token_id: str,
    request: SendWorkflowEmailRequest,
):

    WORKFLOW_EMAIL_JOBS[token_id]["status"] = "RUNNING"
    WORKFLOW_EMAIL_JOBS[token_id]["stage"] = "INITIALIZING"

    try:


        WORKFLOW_EMAIL_JOBS[token_id]["stage"] = "LOADING_WORKFLOW"

        async with get_connection() as db:

            result = await send_workflow_step_email(
                db,
                user_id=request.user_id,
                token_id=token_id,
                scheduled_id=None,
                workflow_name=request.workflow_name,
                step_id=request.step_id,
                to_list=request.to_list,
                cc_list=request.cc_list,
                bcc_list=request.bcc_list,
                allowed_sites=request.allowed_sites,
                columns_name=request.columns_name,
                global_filters=request.global_filters,
                progress_callback=lambda stage: WORKFLOW_EMAIL_JOBS[token_id].update(
                    {"stage": stage}
                ),
            )

        WORKFLOW_EMAIL_JOBS[token_id]["status"] = result.get("status", "COMPLETED")
        WORKFLOW_EMAIL_JOBS[token_id]["stage"] = "COMPLETED"
        WORKFLOW_EMAIL_JOBS[token_id]["result"] = result

    except Exception as e:

        WORKFLOW_EMAIL_JOBS[token_id]["status"] = "FAILED"
        WORKFLOW_EMAIL_JOBS[token_id]["stage"] = "FAILED"
        WORKFLOW_EMAIL_JOBS[token_id]["error"] = str(e)


@router.post(
    "/send/email",
    response_model=SendWorkflowEmailStartResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Start workflow step email job",
)
async def send_workflow_step_email_endpoint(
    request: SendWorkflowEmailRequest,
):

    token_id = str(uuid.uuid4())

    WORKFLOW_EMAIL_JOBS[token_id] = {
        "status": "PENDING",
        "stage": "JOB_CREATED",
        "result": None,
        "error": None,
    }

    asyncio.create_task(
        _run_workflow_email_job(
            token_id,
            request,
        )
    )

    return {
        "token_id": token_id,
        "status": "PENDING",
    }


# ---------------------------------------------------------------------------
# Job Status Endpoint
# ---------------------------------------------------------------------------

@router.get(
    "/send/email/running-status/{token_id}",
    response_model=SendWorkflowEmailStatusResponse,
    summary="Check email job status",
)
async def get_email_job_status(token_id: str):

    job = WORKFLOW_EMAIL_JOBS.get(token_id)

    if not job:
        raise HTTPException(
            status_code=404,
            detail="Token ID not found",
        )

    return {
        "token_id": token_id,
        "status": job["status"],
        "stage": job.get("stage"),
        "result": job.get("result"),
        "error": job.get("error"),
    }


@router.post(
    "/schedule/email",
    response_model=ScheduleWorkflowEmailResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Schedule workflow step email job",
)
async def send_workflow_step_email_endpoint(
    request: ScheduleWorkflowEmailRequest,
):

    token_id = str(uuid.uuid4())

    if request.is_recurring:

        if not request.schedule_time:
            raise HTTPException(
                status_code=400,
                detail="schedule_time required for recurring emails"
            )

        if not request.schedule_time_zone:
            raise HTTPException(
                status_code=400,
                detail="Time Zone required for emails"
            )

        if len(request.schedule_time) > 4:
            raise HTTPException(
                status_code=400,
                detail="Maximum 4 schedule times allowed"
            )
        
        if not request.days_of_week:
            raise HTTPException(
                status_code=400,
                detail="days_of_week is required for recurring emails"
            )
        
        await _save_workflow_email_schedule(token_id, request)

        return {
            "token_id": token_id,
            "status": "SCHEDULED"
        }


