import os
# import psutil
from datetime import datetime
from fastapi import APIRouter
from app.db.pool import DatabasePool
from app.schemas.health import HealthCheckResponse

router = APIRouter(tags=["Health"])


# process = psutil.Process(os.getpid())

# mem_info = process.memory_info()

# print(f"RSS (MB): {mem_info.rss / 1024 / 1024:.2f}")
# print(f"VMS (MB): {mem_info.vms / 1024 / 1024:.2f}")


@router.get("/")
async def root():
    """Root endpoint returning API information."""
    return {
        "name": "Email Document Agent API",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health",
        "since": "08-04-2026"
    }

@router.get("/db/health", response_model=HealthCheckResponse)
async def health_check():
    """Check the health of the application and database connection."""
    db_healthy = await DatabasePool.health_check()

    return HealthCheckResponse(
        status="healthy" if db_healthy else "degraded",
        database=db_healthy,
        timestamp=datetime.now().isoformat(),
    )

