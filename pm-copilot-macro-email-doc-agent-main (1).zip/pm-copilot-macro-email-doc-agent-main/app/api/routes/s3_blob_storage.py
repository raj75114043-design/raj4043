import base64
import json
import asyncio
import os
import re
from typing import List, Optional
from fastapi import APIRouter, UploadFile, File, HTTPException, Form, Depends
from fastapi.responses import StreamingResponse
from asyncpg import Connection
from app.schemas.general import(
    UserInfoRequest,
)
from app.schemas.blob_storage import(
    WorkflowStepOutputtoBlob,
    TableFilter,
    TableToS3Request,   
)
from app.services.workflow_email_send import(
    fetch_step_config,
    fetch_step_output,
    build_csv_attachment,
)
from app.db.pool import get_db
from app.services.s3_blob_management import S3Service
from app.dependencies.s3_blob import get_s3_service
router = APIRouter(prefix="/blob", tags=["Blob Storage"])

MAX_SIZE = 50 * 1024 * 1024  # 50MB

def _normalize_identifier(name: str) -> str:
    return re.sub(r"\s+", "_", name.strip()).lower()

# =========================
# BUCKET
# =========================

@router.get("/buckets")
async def list_buckets(s3: S3Service = Depends(get_s3_service)):
    return {"buckets": await s3.list_buckets()}


@router.post("/bucket")
async def create_bucket(bucket: str, s3: S3Service = Depends(get_s3_service)):
    return {"message": await s3.create_bucket(bucket)}


@router.delete("/bucket")
async def delete_bucket(bucket: str, s3: S3Service = Depends(get_s3_service)):
    return {"message": await s3.delete_bucket_new(bucket)}


# =========================
# LISTING
# =========================

@router.get("/files")
async def list_files(bucket: str, prefix: str = "", s3: S3Service = Depends(get_s3_service)):
    return {"files": await s3.list_files(bucket, prefix)}


@router.get("/tree")
async def get_s3_tree(
    format: str = "json",
    s3: S3Service = Depends(get_s3_service)
):

    try:

        buckets = await s3.list_buckets()

        result = []

        # ============================================
        # BUILD TREE
        # ============================================

        for bucket in buckets:

            try:
                files = await s3.list_files(bucket)

                tree = {}

                for f in files:

                    key = f.get("key")
                    if not key:
                        continue

                    parts = key.strip("/").split("/")
                    current = tree

                    for i, part in enumerate(parts):

                        is_file = (i == len(parts) - 1)

                        if is_file:

                            current.setdefault("__files__", [])

                            current["__files__"].append({
                                "name": part,
                                "key": key,
                                "filetype": part.split(".")[-1] if "." in part else "unknown",
                                "last_modified": str(f.get("last_modified"))
                            })

                        else:

                            current.setdefault(part, {})
                            current = current[part]

                result.append({
                    "bucket": bucket,
                    "tree": tree
                })

            except Exception as e:

                result.append({
                    "bucket": bucket,
                    "error": str(e)
                })

        # ============================================
        # JSON RESPONSE (CLEAN)
        # ============================================

        if format.lower() == "json":

            return {
                "format": "json",
                "buckets": [
                    {
                        "name": b["bucket"],
                        "tree": b.get("tree", {}),
                        "error": b.get("error")
                    }
                    for b in result
                ]
            }

        # ============================================
        # MARKDOWN RESPONSE (READABLE TREE)
        # ============================================

        elif format.lower() == "markdown":

            lines = []

            def render(node, level=0):

                indent = "  " * level

                # folders first
                for k in sorted([x for x in node.keys() if x != "__files__"]):

                    lines.append(f"{indent}- 📁 {k}/")
                    render(node[k], level + 1)

                # files
                for f in node.get("__files__", []):
                    lines.append(
                        f"{indent}- 📄 {f['name']} "
                        f"(type: {f['filetype']}, "
                        f"modified: {f['last_modified']})"
                    )

            for b in result:

                lines.append(f"# 🪣 {b['bucket']}")

                if "tree" in b:
                    render(b["tree"])

                if "error" in b:
                    lines.append(f"⚠️ ERROR: {b['error']}")

                lines.append("")

            return {
                "format": "markdown",
                "markdown": "\n".join(lines)
            }

        # ============================================
        # INVALID FORMAT
        # ============================================

        raise HTTPException(
            status_code=400,
            detail="format must be 'json' or 'markdown'"
        )

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to build S3 tree: {str(e)}"
        )
    

    
@router.get("/folders")
async def list_folders(bucket: str, prefix: str = "", s3: S3Service = Depends(get_s3_service)):
    return {"folders": await s3.list_folders(bucket, prefix)}

@router.get("/bucket/size")
async def bucket_size(bucket: str, s3: S3Service = Depends(get_s3_service)):
    return await s3.get_bucket_size(bucket)

@router.get("/s3-file-as-base64")
async def get_s3_file_as_base64(bucket: str, key: str, s3: S3Service = Depends(get_s3_service)):
    return await s3.get_file_as_base64(bucket, key)


@router.get("/s3-file-as-bytes")
async def get_s3_file_as_bytes(bucket: str, key: str, s3: S3Service = Depends(get_s3_service)):
    return await s3.get_file_as_bytes(bucket, key)


# =========================
# DELETE FILES
# =========================

@router.delete("/file")
async def delete_file(bucket: str, key: str, s3: S3Service = Depends(get_s3_service)):
    return await s3.delete_file(bucket, key)


# =========================
# UPLOAD FILES
# =========================

@router.post("/upload")
async def upload_file(bucket: str, key: str, file: UploadFile = File(...), s3: S3Service = Depends(get_s3_service)):
    try:
        data = await file.read()

        if len(data) > MAX_SIZE:
            raise HTTPException(400, "File too large")

        await s3.upload_bytes(
            bucket=bucket,
            key=key,
            data=data,
            content_type=file.content_type or "application/octet-stream"
        )

        return {
            "message": "Uploaded",
            "key": key,
            "size_bytes": len(data)
        }

    except Exception as e:
        raise HTTPException(500, str(e))


@router.post("/upload/multi-files")
async def upload_multi_files(
    bucket: str = Form(...),
    keys: Optional[List[str]] = Form(None),
    files: List[UploadFile] = File(...),
    s3: S3Service = Depends(get_s3_service)
):
    try:
        if keys:
            if len(keys) == 1 and "," in keys[0]:
                keys = [k.strip() for k in keys[0].split(",") if k.strip()]
            else:
                keys = [k.strip() for k in keys]

        print("Keys: ", keys)        

        if keys and len(keys) != len(files):
            raise HTTPException(
                status_code=400,
                detail=f"keys count ({len(keys)}) must match files count ({len(files)})"
            )

        tasks = []
        uploaded_files = []

        for i, file in enumerate(files):
            data = await file.read()

            if not data:
                continue

            if len(data) > MAX_SIZE:
                raise HTTPException(400, f"{file.filename} too large")

            key = keys[i] if keys else file.filename

            tasks.append(
                s3.upload_bytes(
                    bucket=bucket,
                    key=key,
                    data=data,
                    content_type=file.content_type or "application/octet-stream"
                )
            )

            uploaded_files.append({
                "original_name": file.filename,
                "key": key
            })

        await asyncio.gather(*tasks)

        return {
            "status": "SUCCESS",
            "message": "Uploaded successfully",
            "files": uploaded_files
        }

    except Exception as e:
        raise HTTPException(500, str(e))



@router.post("/upload/file-base64-to-s3")
async def upload_base64_file(
    bucket: str,
    key: str,
    file_data_base64: str,
    s3: S3Service = Depends(get_s3_service)
):
    return await s3.upload_base64_file(
        bucket=bucket,
        key=key,
        file_data_base64=file_data_base64
    )


@router.post("/upload/file-base64-to-s3/multi")
async def upload_multiple_base64_files(
    bucket: str,
    files: List[dict],
    s3: S3Service = Depends(get_s3_service)
):
    """
    Example:
    [
        {"key": "file1.pdf", "file_data_base64": "..."},
        {"key": "file2.png", "file_data_base64": "..."}
    ]
    """
    return await s3.upload_multiple_base64_files(bucket, files)



@router.post("/upload/file-bytes-to-s3",  include_in_schema=False)
async def upload_bytes_file(
    bucket: str,
    key: str,
    file_data_bytes: str,  # bytes coming as string
    s3: S3Service = Depends(get_s3_service)
):
    try:
        data = file_data_bytes.encode("utf-8")

        if len(data) > MAX_SIZE:
            raise HTTPException(400, "File too large")

        await s3.upload_bytes(
            bucket=bucket,
            key=key,
            data=data,
            content_type="application/octet-stream"
        )

        return {
            "status": "SUCCESS",
            "bucket": bucket,
            "key": key,
            "size_bytes": len(data)
        }

    except Exception as e:
        raise HTTPException(500, str(e))
    

@router.post("/upload/file-bytes-to-s3/multi",  include_in_schema=False)
async def upload_multiple_bytes_files(
    bucket: str,
    files: List[dict],
    s3: S3Service = Depends(get_s3_service)
):
    """
    Example:
    [
        {"key": "file1.pdf", "file_data_bytes": "..."},
        {"key": "file2.png", "file_data_bytes": "..."}
    ]
    """
    try:
        tasks = []
        uploaded_files = []

        for f in files:
            key = f.get("key")
            bytes_str = f.get("file_data_bytes")

            if not key or not bytes_str:
                continue

            data = bytes_str.encode("utf-8")

            if len(data) > MAX_SIZE:
                raise HTTPException(400, f"{key} too large")

            tasks.append(
                s3.upload_bytes(
                    bucket=bucket,
                    key=key,
                    data=data,
                    content_type="application/octet-stream"
                )
            )

            uploaded_files.append({
                "key": key,
                "size_bytes": len(data)
            })

        await asyncio.gather(*tasks)

        return {
            "status": "SUCCESS",
            "bucket": bucket,
            "files": uploaded_files
        }

    except Exception as e:
        raise HTTPException(500, str(e))
    


# =========================
# DOWNLOAD FILES
# =========================

@router.get("/download")
async def download_file(bucket: str, key: str, s3: S3Service = Depends(get_s3_service)):
    try:
        session = s3._session()

        async def stream():
            async with session.client(
                "s3",
                endpoint_url=s3.endpoint_url,
                aws_access_key_id=s3.access_key,
                aws_secret_access_key=s3.secret_key,
            ) as client:

                obj = await client.get_object(Bucket=bucket, Key=key)
                body = obj["Body"]

                async for chunk in body.iter_chunks():
                    yield chunk

        return StreamingResponse(
            stream(),
            media_type="application/octet-stream",
            headers={
                "Content-Disposition": f'attachment; filename="{key.split("/")[-1]}"'
            }
        )

    except Exception as e:
        raise HTTPException(500, str(e))


# =========================
# Conversions
# =========================

@router.post("/convert-file-to-base64")
async def convert_file_to_base64(file: UploadFile = File(...), s3: S3Service = Depends(get_s3_service)):
    try:
        data = await file.read()
        encoded = base64.b64encode(data).decode("utf-8")

        return {
            "file_name": file.filename,
            "file_data_base64": encoded,
            "size_mb": round(len(data) / (1024 * 1024), 2)
        }

    except Exception as e:
        raise HTTPException(500, str(e))


@router.post("/convert-file-to-bytes",  include_in_schema=False)
async def convert_file_to_bytes(file: UploadFile = File(...), s3: S3Service = Depends(get_s3_service)):
    try:
        data = await file.read()

        return {
            "file_name": file.filename,
            # encode to base64 because raw bytes can't go in JSON
            "file_data_bytes": base64.b64encode(data).decode("utf-8"),
            "note": "Bytes are base64-encoded for safe JSON transport",
            "size_mb": round(len(data) / (1024 * 1024), 2)
        }

    except Exception as e:
        raise HTTPException(500, str(e))


@router.post("/convert-bytes-to-base64",  include_in_schema=False)
async def convert_bytes_to_base64(data_bytes: str, s3: S3Service = Depends(get_s3_service)):
    try:
        # assume incoming string is base64-encoded representation of bytes
        raw_bytes = base64.b64decode(data_bytes)
        encoded = base64.b64encode(raw_bytes).decode("utf-8")

        return {
            "input_bytes_base64": data_bytes,
            "output_base64": encoded
        }

    except Exception as e:
        raise HTTPException(500, str(e))


@router.post("/convert-base64-to-bytes",  include_in_schema=False)
async def convert_base64_to_bytes(data_base64: str, s3: S3Service = Depends(get_s3_service)):
    try:
        data_bytes = base64.b64decode(data_base64)

        return {
            "input_base64": data_base64,
            "output_bytes_base64": base64.b64encode(data_bytes).decode("utf-8"),
            "note": "Returned bytes are base64-encoded for JSON safety"
        }

    except Exception as e:
        raise HTTPException(500, str(e))
    
    
# =========================
# PRESIGNED URL
# =========================

@router.get("/presigned-url")
def presigned_url(bucket: str, key: str, expiry: int = 3600, s3: S3Service = Depends(get_s3_service)):
    return s3.generate_presigned_url(bucket, key, expiry)


# =========================
# Postgre Integration with Blob Storage
# =========================


@router.post("/upload/workflow/step/output-to-s3")
async def upload_workflow_step_output_to_s3(
    user_info: UserInfoRequest,
    request: WorkflowStepOutputtoBlob,
    db: Connection = Depends(get_db),
    s3: S3Service = Depends(get_s3_service)
):
    try:
        step_config = await fetch_step_config(
            db=db,
            workflow_name=request.workflow_name,
            step_id=request.step_id
        )

        rows = await fetch_step_output(
            db=db,
            allowed_sites=request.allowed_sites,
            columns_name=request.columns_name,
            global_filters=request.global_filters,
            step_config=step_config,
        )

        if not rows:
            return {
                "workflow_name": request.workflow_name,
                "step_id": request.step_id,
                "message": "No data found",
                "s3_key": None
            }

        step_name_safe = _normalize_identifier(
            step_config.get("step_name", request.step_id)
        )

        csv_filename = f"{_normalize_identifier(request.workflow_name)}_{step_name_safe}_{request.allowed_sites}.csv"
        attachment = build_csv_attachment(rows, csv_filename)
        file_bytes = base64.b64decode(attachment["filedata"])

        bucket = "pmcopilot-email-doc-postgre-tables"
        key = csv_filename   # you can also add folder structure here

        await s3.upload_bytes(
            bucket=bucket,
            key=key,
            data=file_bytes,
            content_type="text/csv"
        )

        return {
            "workflow_name": request.workflow_name,
            "step_id": request.step_id,
            "s3_bucket": bucket,
            "s3_key": key,
            "message": "File uploaded successfully"
        }

    except Exception as e:
        raise HTTPException(500, str(e))
    

@router.post("/upload/table-to-s3")
async def upload_table_to_s3(
    user_info: UserInfoRequest,
    request: TableToS3Request,
    db: Connection = Depends(get_db),
    s3: S3Service = Depends(get_s3_service)
):
    try:
        query = f'SELECT * FROM "{request.schema_name}"."{request.table_name}"'
        conditions = []
        values = []
        idx = 1

        if request.filters:
            for f in request.filters:
                if not f.values:
                    continue

                if len(f.values) == 1:
                    conditions.append(f'"{f.column}" = ${idx}')
                    values.append(f.values[0])
                    idx += 1
                else:
                    conditions.append(f'"{f.column}" = ANY(${idx})')
                    values.append(f.values)
                    idx += 1

        if conditions:
            query += " WHERE " + " AND ".join(conditions)
        if request.limit:
            query += f" LIMIT {request.limit}"
        rows = await db.fetch(query, *values)

        if not rows:
            return {
                "status": "SUCCESS",
                "message": "No data found",
                "bucket": "pmcopilot-email-doc-postgre-tables",
                "key": None
            }

        rows = [dict(r) for r in rows]
        file_name = f"{_normalize_identifier(request.schema_name)}_{_normalize_identifier(request.table_name)}.csv"
        attachment = build_csv_attachment(rows, file_name)
        file_bytes = base64.b64decode(attachment["filedata"])

        bucket = "pmcopilot-email-doc-postgre-tables"
        key = f"{_normalize_identifier(request.schema_name)}/{_normalize_identifier(request.table_name)}/{file_name}"

        await s3.upload_bytes(
            bucket=bucket,
            key=key,
            data=file_bytes,
            content_type="text/csv"
        )

        return {
            "status": "SUCCESS",
            "bucket": bucket,
            "key": key,
            "rows": len(rows)
        }

    except Exception as e:
        raise HTTPException(500, str(e))