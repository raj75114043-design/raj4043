# app\email_job_auto_trigger\start_scheduler.py

import asyncio

from datetime import datetime
from zoneinfo import ZoneInfo

from app.email_job_auto_trigger.job_schedule_checker import (
    check_and_run_scheduled_jobs
)

# =====================================================
# CONFIG
# =====================================================

DEFAULT_TIMEZONE = "Asia/Kolkata"

# every 10 min
SCHEDULER_INTERVAL_SECONDS = 600

# prevent overlapping cycles
_scheduler_lock = asyncio.Lock()


# =====================================================
# SINGLE CYCLE
# =====================================================

async def run_scheduler_cycle():

    if _scheduler_lock.locked():

        # print(
        #     "[JOB Scheduler] Previous cycle still running. "
        #     "Skipping this cycle."
        # )

        return

    async with _scheduler_lock:

        started_at = datetime.now(
            ZoneInfo(DEFAULT_TIMEZONE)
        )

        try:

            # print(
            #     f"[JOB Scheduler] Cycle started at "
            #     f"{started_at.strftime('%Y-%m-%d %H:%M:%S')}"
            # )

            await check_and_run_scheduled_jobs()

        except Exception as e:

            print(
                "[JOB Scheduler] Cycle failed:",
                str(e)
            )

        finally:

            ended_at = datetime.now(
                ZoneInfo(DEFAULT_TIMEZONE)
            )

            duration = (
                ended_at - started_at
            ).total_seconds()

            # print(
            #     f"[JOB Scheduler] Cycle completed "
            #     f"in {duration:.2f}s"
            # )


# =====================================================
# MAIN LOOP
# =====================================================

async def email_doc_job_runner_scheduler_loop():

    print("[JOB Scheduler] Scheduler loop started")

    while True:

        cycle_started = asyncio.get_event_loop().time()

        try:

            await run_scheduler_cycle()

        except asyncio.CancelledError:

            # print("[JOB Scheduler] Scheduler cancelled")

            raise

        except Exception as e:

            print(
                "[Scheduler Loop Error]",
                str(e)
            )


        # =================================================
        # DRIFT SAFE SLEEP
        # =================================================

        elapsed = (
            asyncio.get_event_loop().time()
            - cycle_started
        )

        sleep_for = max(
            1,
            SCHEDULER_INTERVAL_SECONDS - elapsed
        )

        await asyncio.sleep(sleep_for)