# app\email_job_auto_trigger\job_schedule_checker.py


from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

from app.db.pool import get_connection

from app.email_doc_job_engine.main_orchestrator.job_queue_manager import (
    enqueue_job
)

from app.dependencies.azure_doc_intelligence import (
    get_document_service
)

from app.dependencies.s3_blob import (
    get_s3_service
)

# =====================================================
# CONFIG
# =====================================================

DEFAULT_TIMEZONE = "Asia/Kolkata"

VALID_DAYS = {
    "MON",
    "TUE",
    "WED",
    "THU",
    "FRI",
    "SAT",
    "SUN",
    "ALL"
}

# scheduler runs every 60 sec
# allow small delay tolerance
SCHEDULER_LOOKBACK_MINUTES = 10


# =====================================================
# ENSURE TZ AWARE
# =====================================================

def ensure_timezone_aware(
    dt: datetime | None,
    timezone_name: str
) -> datetime | None:

    if dt is None:
        return None

    # already aware
    if dt.tzinfo is not None:
        return dt

    tz = ZoneInfo(timezone_name)

    return dt.replace(tzinfo=tz)

# =====================================================
# NORMALIZE DAY
# =====================================================

def normalize_day(day: str) -> str:

    if not day:
        return ""

    day = day.strip().upper()

    mapping = {
        "MONDAY": "MON",
        "TUESDAY": "TUE",
        "WEDNESDAY": "WED",
        "THURSDAY": "THU",
        "FRIDAY": "FRI",
        "SATURDAY": "SAT",
        "SUNDAY": "SUN"
    }

    return mapping.get(day, day)


# =====================================================
# NORMALIZE DAYS
# =====================================================

def normalize_days(days: list[str] | None) -> list[str]:

    if not days:
        return []

    normalized = []

    for day in days:

        d = normalize_day(day)

        if d in VALID_DAYS:
            normalized.append(d)

    return sorted(list(set(normalized)))


# =====================================================
# NORMALIZE TIME
# =====================================================

def normalize_time_str(value: str) -> str | None:

    try:

        if not value:
            return None

        value = value.strip()

        parsed = datetime.strptime(
            value,
            "%H:%M"
        )

        return parsed.strftime("%H:%M")

    except Exception:

        return None


# =====================================================
# NORMALIZE SCHEDULE TIMES
# =====================================================

def normalize_schedule_times(
    schedule_times: list[str] | None
) -> list[str]:

    if not schedule_times:
        return []

    valid = []

    for value in schedule_times:

        parsed = normalize_time_str(value)

        if parsed:
            valid.append(parsed)

    return sorted(list(set(valid)))


# =====================================================
# BUILD SCHEDULE DATETIME
# =====================================================

def build_schedule_datetime(
    current_dt: datetime,
    schedule_time: str
) -> datetime:

    hour, minute = map(
        int,
        schedule_time.split(":")
    )

    return current_dt.replace(
        hour=hour,
        minute=minute,
        second=0,
        microsecond=0
    )


# =====================================================
# SHOULD RUN JOB
# =====================================================

def should_run_job(
    *,
    now: datetime,
    days_of_week: list[str],
    schedule_run_times: list[str],
    last_run_at: datetime | None
) -> bool:

    # =================================================
    # VALIDATE DAYS
    # =================================================

    normalized_days = normalize_days(
        days_of_week
    )

    if not normalized_days:
        return False

    current_day = normalize_day(
        now.strftime("%A")
    )

    day_match = (
        "ALL" in normalized_days
        or current_day in normalized_days
    )

    if not day_match:
        return False

    # =================================================
    # VALIDATE TIMES
    # =================================================

    normalized_times = normalize_schedule_times(
        schedule_run_times
    )

    if not normalized_times:
        return False

    # =================================================
    # LOOKBACK WINDOW
    # =================================================

    window_start = now - timedelta(
        minutes=SCHEDULER_LOOKBACK_MINUTES
    )

    for schedule_time in normalized_times:

        scheduled_dt = build_schedule_datetime(
            current_dt=now,
            schedule_time=schedule_time
        )

        # ---------------------------------------------
        # schedule not reached yet
        # ---------------------------------------------

        if scheduled_dt > now:
            continue

        # ---------------------------------------------
        # outside execution window
        # Example:
        # scheduler wakes too late after hours
        # ---------------------------------------------

        if scheduled_dt < window_start:
            continue

        # ---------------------------------------------
        # never executed
        # ---------------------------------------------

        if last_run_at is None:
            return True

        # ---------------------------------------------
        # already executed AFTER this schedule
        # ---------------------------------------------

        if last_run_at >= scheduled_dt:
            continue

        return True

    return False


# =====================================================
# UPDATE LAST RUN
# =====================================================

async def update_last_run(
    db,
    job_id: str,
    executed_at: datetime
):

    query = """
        UPDATE macro_email_doc_agent.email_doc_usecase_jobs
        SET
            last_run_at = $1,
            updated_at = NOW()
        WHERE job_id = $2
    """

    await db.execute(
        query,
        executed_at,
        job_id
    )


# =====================================================
# FETCH ELIGIBLE JOBS
# =====================================================

async def get_jobs_to_run(db):

    query = """
        SELECT
            job_id,
            schedule_run_times,
            days_of_week,
            timezone,
            last_run_at
        FROM macro_email_doc_agent.email_doc_usecase_jobs
        WHERE job_trigger_point = 'SCHEDULED_TIME'
        AND is_active = TRUE
        AND schedule_run_times IS NOT NULL
        AND days_of_week IS NOT NULL
        AND timezone IS NOT NULL
        ORDER BY created_at ASC
    """

    rows = await db.fetch(query)

    jobs_to_run = []

    for row in rows:

        try:

            job_id = row["job_id"]

            timezone_name = (
                row["timezone"]
                or DEFAULT_TIMEZONE
            )

            try:

                tz = ZoneInfo(timezone_name)

            except Exception:

                print(
                    f"[JOB Scheduler] Invalid timezone "
                    f"for job={job_id}. "
                    f"Using default timezone."
                )

                timezone_name = DEFAULT_TIMEZONE

                tz = ZoneInfo(DEFAULT_TIMEZONE)

            now = datetime.now(tz)

            schedule_run_times = (
                row["schedule_run_times"]
                or []
            )

            days_of_week = (
                row["days_of_week"]
                or []
            )

            last_run_at = ensure_timezone_aware(
                row["last_run_at"],
                timezone_name
            )

            eligible = should_run_job(
                now=now,
                days_of_week=days_of_week,
                schedule_run_times=schedule_run_times,
                last_run_at=last_run_at
            )

            if eligible:

                jobs_to_run.append({
                    "job_id": job_id,
                    "timezone_name": timezone_name
                })

                print(
                    f"[JOB Scheduler] ELIGIBLE "
                    f"job={job_id}"
                )

        except Exception as e:

            print(
                "[JOB Scheduler] Failed processing row:",
                str(e)
            )


    return jobs_to_run


# =====================================================
# EXECUTE SINGLE JOB
# =====================================================

async def execute_scheduled_job(
    *,
    job_id: str,
    timezone_name: str
):

    try:

        print(
            f"[JOB Scheduler] STARTED "
            f"job={job_id}"
        )

        result = await enqueue_job(
            job_id=job_id
        )

        print(result)

        executed_at = datetime.now(
            ZoneInfo(timezone_name)
        )

        print(
            f"[JOB Scheduler] COMPLETED "
            f"job={job_id}"
        )

    except Exception as e:

        print(
            f"[JOB Scheduler] FAILED "
            f"job={job_id}: {str(e)}"
        )



# =====================================================
# MAIN SCHEDULER
# =====================================================

async def check_and_run_scheduled_jobs():

    try:

        print("[JOB Scheduler] Checking jobs")

        async with get_connection() as db:

            jobs_to_run = await get_jobs_to_run(db)

            if not jobs_to_run:

                print(
                    "[JOB Scheduler] No jobs eligible"
                )

                return

            print(
                f"[JOB Scheduler] Jobs to run="
                f"{len(jobs_to_run)}"
            )

            # shared services
            azure_service = get_document_service()
            s3_service = get_s3_service()

            # =========================================
            # RUN ONE BY ONE
            # =========================================

            for job in jobs_to_run:

                await execute_scheduled_job(
                    job_id=job["job_id"],
                    timezone_name=job["timezone_name"]
                )

        print("[JOB Scheduler] Completed cycle")

    except Exception as e:

        print(
            "[JOB Scheduler] Main failure:",
            str(e)
        )

