# app\email_job_auto_trigger\received_email_job_trigger_service.py

import asyncio

from app.db.pool import get_connection


from app.email_doc_job_engine.main_orchestrator.job_queue_manager import (
    enqueue_job
)

from app.dependencies.azure_doc_intelligence import get_document_service
from app.dependencies.s3_blob import get_s3_service


# =====================================================
# GLOBAL LOCK
# Prevent duplicate parallel runners
# =====================================================

_received_email_job_lock = asyncio.Lock()


# =====================================================
# MAIN TRIGGER
# =====================================================

async def trigger_received_email_jobs():

    # Prevent multiple concurrent executions
    if _received_email_job_lock.locked():
        print("RECEIVED_EMAIL jobs already running")
        return

    async with _received_email_job_lock:

        try:

            async with get_connection() as db:

                query = """
                    SELECT job_id
                    FROM macro_email_doc_agent.email_doc_usecase_jobs
                    WHERE job_trigger_point = 'RECEIVED_EMAIL'
                    AND is_active = TRUE
                """

                rows = await db.fetch(query)

                if not rows:

                    print("No RECEIVED_EMAIL jobs found")
                    return

                print(
                    f"Found {len(rows)} RECEIVED_EMAIL jobs"
                )

                tasks = []

                for row in rows:

                    job_id = row["job_id"]

                    tasks.append(
                        execute_single_job(job_id)
                    )

                # RUN ALL JOBS CONCURRENTLY
                await asyncio.gather(
                    *tasks,
                    return_exceptions=True
                )

        except Exception as e:

            print(
                "FAILED TO TRIGGER RECEIVED_EMAIL JOBS:",
                str(e)
            )


# =====================================================
# EXECUTE SINGLE JOB
# =====================================================

async def execute_single_job(job_id: str):

    try:

        print(f"QUEUEING JOB: {job_id}")

        result = await enqueue_job(
            job_id=job_id
        )

        print(
            f"JOB QUEUE RESULT: {job_id} | "
            f"STATUS={result.get('status')} | "
            f"MESSAGE={result.get('message')}"
        )

    except Exception as e:

        print(
            f"FAILED JOB: {job_id} | {str(e)}"
        )

    # ============================================
    # EXPECTED BUSINESS CASE
    # ============================================

    except ValueError as e:

        if "No matching email found" in str(e):

            print(
                f"SKIPPED JOB: {job_id} | No matching email found"
            )

            return

        print(
            f"FAILED JOB: {job_id} | {str(e)}"
        )

    # ============================================
    # UNEXPECTED ERRORS
    # ============================================

    except Exception as e:

        print(
            f"FAILED JOB: {job_id} | {str(e)}"
        )


# =====================================================
# FIRE & FORGET
# =====================================================

def start_received_email_jobs_background():

    asyncio.create_task(
        trigger_received_email_jobs()
    )