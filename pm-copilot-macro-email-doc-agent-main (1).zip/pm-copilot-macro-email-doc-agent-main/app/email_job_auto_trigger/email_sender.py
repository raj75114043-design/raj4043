import asyncio

from app.services.send_email_gateway import (
    get_session_id,
    send_email_via_gateway,
)

# =====================================================
# SEND SINGLE EMAIL
# =====================================================

async def send_single_email(
    email_cfg: dict,
    body: str,
    attachments: list
):

    try:

        # =========================
        # AUTHENTICATE
        # =========================

        session_id = await asyncio.to_thread(
            get_session_id
        )

        print(
            "[EmailSender] "
            "Email API Gateway Authenticated"
        )

        # =========================
        # SEND EMAIL
        # =========================

        response = await asyncio.to_thread(

            send_email_via_gateway,

            session_id,

            to_list=email_cfg.get("to", []),
            cc_list=email_cfg.get("cc", []),
            bcc_list=email_cfg.get("bcc", []),
            subject=email_cfg.get(
                "subject",
                "Report"
            ),
            body=body,
            attachments=attachments,
        )

        print(
            "[EmailSender] "
            f"Email Sent Successfully: "
            f"{response}"
        )

        return response

    except Exception as e:

        print(
            "[EmailSender] Failed:",
            str(e)
        )

        raise