import asyncio
import json
from datetime import datetime
from zoneinfo import ZoneInfo

from app.db.pool import get_connection

from app.email_job_auto_trigger.email_sender import (
    send_single_email
)


# =====================================================
# CONFIG
# =====================================================
# every 3 min --
CHECK_INTERVAL_SECONDS = 180
DEFAULT_TIMEZONE = "Asia/Kolkata"

_scheduler_lock = asyncio.Lock()


# =====================================================
# FETCH EMAILS QUERY
# =====================================================

FETCH_PENDING_EMAILS_QUERY = """
SELECT
    id,
    job_id,
    to_list,
    cc_list,
    bcc_list,
    email_subject,
    email_body,
    reviewed_to_list,
    reviewed_cc_list,
    reviewed_bcc_list,
    reviewed_email_subject,
    reviewed_email_body,
    attachments,
    reviewed_attachments
FROM macro_email_doc_agent.email_doc_usecase_jobs_email_send
WHERE sent_at IS NULL
AND mail_status = 'APPROVED'
ORDER BY created_at ASC
FOR UPDATE SKIP LOCKED
"""


# =====================================================
# UPDATE SUCCESS
# =====================================================

UPDATE_SUCCESS_QUERY = """
UPDATE macro_email_doc_agent.email_doc_usecase_jobs_email_send
SET
    sent_at = NOW(),
    updated_at = NOW(),
    remarks = COALESCE(remarks, '') || ' | Email sent successfully'
WHERE id = $1
"""


# =====================================================
# UPDATE FAILURE
# =====================================================

UPDATE_FAILURE_QUERY = """
UPDATE macro_email_doc_agent.email_doc_usecase_jobs_email_send
SET
    updated_at = NOW(),
    remarks = $2
WHERE id = $1
"""


# =====================================================
# PROCESS SINGLE EMAIL
# =====================================================

async def process_single_email(
    db,
    row
):

    email_id = row["id"]

    try:

        print(
            f"[EmailScheduler] Processing "
            f"email_id={email_id}"
        )

        # =========================================
        # REVIEWED VALUES TAKE PRIORITY
        # =========================================

        email_cfg = {

            "to": (
                row["reviewed_to_list"]
                or row["to_list"]
                or []
            ),

            "cc": (
                row["reviewed_cc_list"]
                or row["cc_list"]
                or []
            ),

            "bcc": (
                row["reviewed_bcc_list"]
                or row["bcc_list"]
                or []
            ),

            "subject": (
                row["reviewed_email_subject"]
                or row["email_subject"]
                or "Subject Not Found"
            )
        }

        body = (
            row["reviewed_email_body"]
            or row["email_body"]
            or ""
        )

        attachments = (
            row["reviewed_attachments"]
            or row["attachments"]
            or []
        )

        # =========================================
        # HANDLE JSON STRING
        # =========================================

        if isinstance(attachments, str):

            try:

                attachments = json.loads(
                    attachments
                )

            except Exception:

                raise Exception(
                    "Invalid attachments JSON"
                )

        # =========================================
        # VALIDATION
        # =========================================

        if not email_cfg["to"]:

            raise Exception(
                "Missing to_list"
            )

        if not isinstance(attachments, list):

            raise Exception(
                "Attachments must be list"
            )

        # =========================================
        # VALIDATE ATTACHMENTS
        # =========================================

        for item in attachments:

            if not isinstance(item, dict):

                raise Exception(
                    "Attachment item must be dict"
                )

            if "filename" not in item:

                raise Exception(
                    "Attachment missing filename"
                )

            if "filedata" not in item:

                raise Exception(
                    "Attachment missing filedata"
                )

        print(
            f"[EmailScheduler] "
            f"Attachments count="
            f"{len(attachments)}"
        )

        # =========================================
        # SEND EMAIL
        # =========================================

        await send_single_email(
            email_cfg=email_cfg,
            body=body,
            attachments=attachments
        )

        # =========================================
        # UPDATE SUCCESS
        # =========================================

        await db.execute(
            UPDATE_SUCCESS_QUERY,
            email_id
        )

        print(
            f"[EmailScheduler] SUCCESS "
            f"email_id={email_id}"
        )


    except Exception as e:

        error_message = (
            f"Email send failed: {str(e)}"
        )

        print(
            f"[EmailScheduler] FAILED "
            f"email_id={email_id}: {str(e)}"
        )


        await db.execute(
            UPDATE_FAILURE_QUERY,
            email_id,
            error_message[:5000]
        )


# =====================================================
# RUN SCHEDULER CYCLE
# =====================================================

async def run_email_send_scheduler_cycle():

    if _scheduler_lock.locked():

        print(
            "[EmailScheduler] Previous cycle "
            "still running"
        )

        return

    async with _scheduler_lock:

        started_at = datetime.now(
            ZoneInfo(DEFAULT_TIMEZONE)
        )

        try:

            async with get_connection() as db:

                async with db.transaction():

                    rows = await db.fetch(
                        FETCH_PENDING_EMAILS_QUERY
                    )

                    total_emails = len(rows)

                    print(
                        f"[EmailScheduler] "
                        f"Pending emails count="
                        f"{total_emails}"
                    )

                    if not rows:
                        return

                    # =================================
                    # PROCESS ONE BY ONE
                    # =================================

                    for row in rows:

                        await process_single_email(
                            db=db,
                            row=row
                        )

        except Exception as e:

            print(
                "[EmailScheduler] Cycle failed:",
                str(e)
            )


        finally:

            ended_at = datetime.now(
                ZoneInfo(DEFAULT_TIMEZONE)
            )

            duration = (
                ended_at - started_at
            ).total_seconds()

            print(
                f"[EmailScheduler] Cycle completed "
                f"in {duration:.2f} sec"
            )


# =====================================================
# MAIN LOOP
# =====================================================

async def run_email_send_scheduler():

    print(
        "[EmailScheduler] Started"
    )

    while True:

        try:

            cycle_start = (
                asyncio.get_event_loop().time()
            )

            await run_email_send_scheduler_cycle()

            elapsed = (
                asyncio.get_event_loop().time()
                - cycle_start
            )

            sleep_time = max(
                1,
                CHECK_INTERVAL_SECONDS - elapsed
            )

            print(
                f"[EmailScheduler] Sleeping "
                f"{sleep_time:.2f} sec"
            )

            await asyncio.sleep(sleep_time)

        except asyncio.CancelledError:

            print(
                "[EmailScheduler] Cancelled"
            )

            raise

        except Exception as e:

            print(
                "[EmailScheduler] Main loop failed:",
                str(e)
            )


            await asyncio.sleep(5)