import io
import json
from fastapi import APIRouter, UploadFile, File, HTTPException, Query, Form
from app.services.doc_intelligence import AzureDocumentService
from fastapi.responses import StreamingResponse
from app.core.llm_client import get_llm_client
from typing import List, Dict

router = APIRouter(prefix="/document-intelligence", tags=["Azure Document Intelligence"])

azure_service = AzureDocumentService(
    endpoint="https://pm-copilot.cognitiveservices.azure.com/",
    key="3sjQmwls3h3fmMGe6oqAhI6EQZ42YJVPEQT2mUk2WUd9UFnInubNJQQJ99BGAC5RqLJXJ3w3AAALACOGjU0Y"
)

MAX_FILE_SIZE = 20 * 1024 * 1024
MAX_TEXT_LENGTH = 15000

ALLOWED_TYPES = {
    "application/pdf",
    "image/jpeg",
    "image/png",
    "image/tiff",
    "image/bmp"
}

@router.get("/health")
async def health():
    return azure_service.health_check()


@router.post("/analyze")
async def analyze_document(
    file: UploadFile = File(...),
    model: str = Query(default="prebuilt-layout"),
    output_format: str = Query(default="markdown")
):
    """
    Upload and analyze document (PDF/Image)
    """

    try:
        # Validate content type
        if file.content_type not in ALLOWED_TYPES:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file type: {file.content_type}"
            )

        file_bytes = await file.read()

        if not file_bytes:
            raise HTTPException(status_code=400, detail="Empty file")

        result = await azure_service.analyze_file(
            file_bytes=file_bytes,
            content_type=file.content_type,
            model=model,
            output_format=output_format
        )

        return result

        # result = await azure_service.analyze_file(
        #     file_bytes=file_bytes,
        #     content_type=file.content_type,
        #     model=model,
        #     output_format="text" 
        # )

        # if "error" in result:
        #     raise HTTPException(status_code=500, detail=result["error"])

        # content = result.get("content", "")

        # # Convert to file
        # file_stream = io.BytesIO(content.encode("utf-8"))

        # return StreamingResponse(
        #     file_stream,
        #     media_type="text/plain",
        #     headers={
        #         "Content-Disposition": f"attachment; filename={file.filename}.txt"
        #     }
        # )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    


@router.post("/analyze/parse-fields-with-ai")
async def analyze_and_extract(
    file: UploadFile = File(...),
    fields: str = Form(...),
    model: str = Form(default="prebuilt-layout")
):
    """
    Upload document → Extract structured fields using AI

    fields example:
    [
      {"name": "Total Test Locations", "type": "int"},
      {"name": "Stationary Tests Completed", "type": "int"},
      {"name": "Mobility Tests Completed", "type": "int"},
      {"name": "Equipment Requirements", "type": "string"}
    ]
    """

    try:
        if file.content_type not in ALLOWED_TYPES:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file type: {file.content_type}"
            )

        file_bytes = await file.read()

        if not file_bytes:
            raise HTTPException(400, "Empty file")

        if len(file_bytes) > MAX_FILE_SIZE:
            raise HTTPException(
                status_code=400,
                detail="File too large. Max allowed is 20MB"
            )

        try:
            fields_list: List[Dict] = json.loads(fields)
        except:
            raise HTTPException(400, "Invalid fields JSON format")

        # Validate schema
        for f in fields_list:
            if "name" not in f or "type" not in f:
                raise HTTPException(400, "Each field must have name and type")

            if f["type"] not in ["string", "int", "float"]:
                raise HTTPException(400, f"Invalid type: {f['type']}")

        parsed_result = await azure_service.analyze_file(
            file_bytes=file_bytes,
            content_type=file.content_type,
            model=model,
            output_format="text"
        )

        if "error" in parsed_result:
            raise HTTPException(500, parsed_result["error"])

        document_text = parsed_result.get("content", "")

        document_text = document_text[:MAX_TEXT_LENGTH]

        llm = get_llm_client("medium")

        prompt = f"""
You are a strict JSON extraction engine.

Extract fields from the document based on schema.

Schema:
{fields_list}

Rules:
- Output MUST be valid JSON
- Keys = field names
- Respect data types strictly:
    - string → text
    - int → integer only
    - float → decimal number
- If value not found → null
- Do NOT hallucinate
- Do NOT add extra keys

Document:
\"\"\"
{document_text}
\"\"\"
"""

        response = llm.invoke(prompt)
        content = response.content.strip()

        if content.startswith("```"):
            content = content.split("```")[1].strip()

        try:
            extracted_data = json.loads(content)
        except:
            extracted_data = {
                "raw_response": content,
                "error": "Invalid JSON from LLM"
            }

        def enforce_type(value, dtype):
            if value is None:
                return None
            try:
                if dtype == "int":
                    return int(value)
                elif dtype == "float":
                    return float(value)
                return str(value)
            except:
                return None

        structured_output = {}

        for f in fields_list:
            name = f["name"]
            dtype = f["type"]

            value = extracted_data.get(name)
            structured_output[name] = enforce_type(value, dtype)

        return {
            "file_name": file.filename,
            "fields_schema": fields_list,
            "extracted_data": structured_output
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))