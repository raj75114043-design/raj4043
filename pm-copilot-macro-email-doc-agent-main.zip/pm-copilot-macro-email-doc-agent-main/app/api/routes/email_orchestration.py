import uuid
import asyncio
import json
from datetime import datetime
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status, Body
from pydantic import BaseModel
from asyncpg import Connection
from app.core.llm_client import get_llm_client

from app.services.email_service import(
    send_workflow_step_email,
    send_email,
    schedule_email,
)

from app.db.pool import(
    get_db,
    get_connection
)


router = APIRouter(prefix="/email-orchestrator", tags=["Email Orchestrator"])


@router.post("/generate-reply")
async def generate_email_reply(
    email_body: str = Body(...),
    instructions: str = Body(default="Generate a professional reply")
):
    """
    Generate a professional email reply using LLM
    """

    try:
        if not email_body.strip():
            raise HTTPException(400, "Email body cannot be empty")

        llm = get_llm_client("medium")

        prompt = f"""
You are an AI Email Assistant.

Your task is to generate a professional email reply.

---

Guidelines:
- Understand the full context before responding
- Keep response concise and structured
- Maintain professional and polite tone
- Avoid unnecessary jargon or long paragraphs
- Do not repeat content
- Extract key points if input is long
- Include action items if present
- If context is unclear → respond gracefully

---

Output Format (STRICT JSON):

{{
  "subject": "string",
  "email_markdown": "string"
}}

---

Email Markdown Format:

Summary:
<one line summary>

Main Content:
<clear response in paragraphs>

Action Items:
- item 1
- item 2

Closing:
<polite closing>

---

Input Email:
\"\"\"
{email_body}
\"\"\"

Instructions:
{instructions}
"""

        response = llm.invoke(prompt)
        content = response.content.strip()

        # Clean markdown/code block
        if content.startswith("```"):
            content = content.split("```")[1].strip()

        try:
            parsed = json.loads(content)
        except:
            parsed = {
                "subject": "Unable to generate subject",
                "email_markdown": content,
                "error": "Invalid JSON from LLM"
            }

        return parsed

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))