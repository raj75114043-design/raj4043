import base64
from fastapi import APIRouter, UploadFile, File, HTTPException
from fastapi.responses import StreamingResponse
from app.services.blob_storage import S3Service


router = APIRouter(prefix="/blob", tags=["Blob Storage"])
s3 = S3Service()

MAX_SIZE = 50 * 1024 * 1024  # 50MB


# =========================
# BUCKET
# =========================

@router.get("/buckets")
async def list_buckets():
    return {"buckets": await s3.list_buckets()}


@router.post("/bucket")
async def create_bucket(bucket: str):
    return {"message": await s3.create_bucket(bucket)}


@router.delete("/bucket")
async def delete_bucket(bucket: str):
    return {"message": await s3.delete_bucket(bucket)}


# =========================
# FILE
# =========================

@router.post("/upload")
async def upload_file(bucket: str, key: str, file: UploadFile = File(...)):
    try:
        data = await file.read()

        if len(data) > MAX_SIZE:
            raise HTTPException(400, "File too large")

        await s3.upload_bytes(
            bucket=bucket,
            key=key,
            data=data,
            content_type=file.content_type or "application/octet-stream"
        )

        return {
            "message": "Uploaded",
            "key": key,
            "size_bytes": len(data)
        }

    except Exception as e:
        raise HTTPException(500, str(e))


@router.get("/download")
async def download_file(bucket: str, key: str):
    try:
        session = s3._session()

        async def stream():
            async with session.client(
                "s3",
                endpoint_url=s3.endpoint_url,
                aws_access_key_id=s3.access_key,
                aws_secret_access_key=s3.secret_key,
            ) as client:

                obj = await client.get_object(Bucket=bucket, Key=key)
                body = obj["Body"]

                async for chunk in body.iter_chunks():
                    yield chunk

        return StreamingResponse(
            stream(),
            media_type="application/octet-stream",
            headers={
                "Content-Disposition": f'attachment; filename="{key.split("/")[-1]}"'
            }
        )

    except Exception as e:
        raise HTTPException(500, str(e))
    

@router.delete("/file")
async def delete_file(bucket: str, key: str):
    return await s3.delete_file(bucket, key)


# =========================
# LISTING
# =========================

@router.get("/files")
async def list_files(bucket: str, prefix: str = ""):
    return {"files": await s3.list_files(bucket, prefix)}


@router.get("/folders")
async def list_folders(bucket: str, prefix: str = ""):
    return {"folders": await s3.list_folders(bucket, prefix)}


@router.get("/bucket/size")
async def bucket_size(bucket: str):
    return await s3.get_bucket_size(bucket)


# =========================
# BASE64
# =========================

@router.post("/upload-to-base64")
async def upload_to_base64(file: UploadFile = File(...)):
    try:
        data = await file.read()

        encoded = base64.b64encode(data).decode()

        return {
            "file_name": file.filename,
            "base64": encoded,
            "size_mb": round(len(encoded) / (1024 * 1024), 2)
        }

    except Exception as e:
        raise HTTPException(500, str(e))


@router.get("/file-to-base64")
async def file_to_base64(bucket: str, key: str):
    return await s3.file_to_base64(bucket, key)


# =========================
# PRESIGNED URL
# =========================

@router.get("/presigned-url")
def presigned_url(bucket: str, key: str, expiry: int = 3600):
    return s3.generate_presigned_url(bucket, key, expiry)