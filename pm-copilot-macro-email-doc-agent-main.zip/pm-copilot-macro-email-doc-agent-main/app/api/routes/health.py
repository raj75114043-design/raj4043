from datetime import datetime
from fastapi import APIRouter
from app.db.pool import DatabasePool
from app.schemas.health import HealthCheckResponse

router = APIRouter(tags=["Health"])

@router.get("/")
async def root():
    """Root endpoint returning API information."""
    return {
        "name": "Email Document Agent API",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health",
        "since": "08-04-2026"
    }

@router.get("/health", response_model=HealthCheckResponse)
async def health_check():
    """Check the health of the application and database connection."""
    db_healthy = await DatabasePool.health_check()

    return HealthCheckResponse(
        status="healthy" if db_healthy else "degraded",
        database=db_healthy,
        timestamp=datetime.now().isoformat(),
    )

