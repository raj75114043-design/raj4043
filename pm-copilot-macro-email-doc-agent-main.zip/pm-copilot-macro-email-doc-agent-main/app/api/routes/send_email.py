import uuid
import asyncio
import json
from datetime import datetime
from typing import List, Optional, Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from asyncpg import Connection

from app.services.email_service import(
    send_workflow_step_email,
    send_email,
    schedule_email,
)

from app.db.pool import(
    get_db,
    get_connection
)

from app.schemas.email import(
    SendEmailRequest,
    ScheduleEmailRequest,
    SendWorkflowEmailRequest,
    SendWorkflowEmailStartResponse,
    SendWorkflowEmailStatusResponse,
    ScheduleWorkflowEmailRequest,
    ScheduleWorkflowEmailResponse,

)

router = APIRouter(prefix="/email", tags=["Send Email"])


EMAIL_JOBS: Dict[str, Dict[str, Any]] = {}


async def _save_workflow_email_schedule(token_id: str, request: SendWorkflowEmailRequest):

    base_query  = """
    INSERT INTO pwc_workflow_agent_schema.workflow_email_schedule
    (
        token_id,
        workflow_name,
        step_id,
        allowed_sites,
        columns_name,
        global_filters,
        to_list,
        cc_list,
        bcc_list,
        is_recurring,
        schedule_time,
        schedule_time_zone,
        days_of_week,
        scheduled_by
    )
    VALUES
    """

    try:
        schedule_time = None

        if len(request.schedule_time) > 4:
            raise HTTPException(
                status_code=400,
                detail="Maximum 4 schedule times allowed"
            )
        
        # Convert Enum → string list
        days_of_week = [day.value for day in request.days_of_week]
        # print(days_of_week)


        values_clause = []
        params = []
        param_index = 1

        generated_tokens = []

        for time_str in request.schedule_time:

            try:
                schedule_time = datetime.strptime(time_str, "%H:%M").time()
            except ValueError:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid time format: {time_str}. Use HH:MM"
                )

            schedule_token = str(uuid.uuid4())
            generated_tokens.append(schedule_token)

            # Build placeholders dynamically
            placeholders = []
            row_values = [
                schedule_token,
                request.workflow_name,
                request.step_id,
                request.allowed_sites,
                request.columns_name,
                json.dumps(request.global_filters), 
                request.to_list,
                request.cc_list,
                request.bcc_list,
                request.is_recurring,
                schedule_time,
                request.schedule_time_zone,
                days_of_week,
                request.user_id,
            ]

            placeholders = [
                f"${i}" for i in range(param_index, param_index + len(row_values))
            ]
            param_index += len(row_values)

            values_clause.append(f"({', '.join(placeholders)})")
            params.extend(row_values)

        final_query = base_query.strip() + " " + ", ".join(values_clause)

        async with get_connection() as db:
            await db.execute(final_query, *params)

        return generated_tokens

    except Exception as e:
        raise RuntimeError(f"Email scheduling failed: {str(e)}")
    

async def run_email_job(
    token_id: str,
    request: SendWorkflowEmailRequest,
):

    EMAIL_JOBS[token_id]["status"] = "RUNNING"
    EMAIL_JOBS[token_id]["stage"] = "INITIALIZING"

    try:


        EMAIL_JOBS[token_id]["stage"] = "LOADING_WORKFLOW"

        async with get_connection() as db:

            result = await send_workflow_step_email(
                db,
                user_id=request.user_id,
                scheduled_id=None,
                workflow_name=request.workflow_name,
                step_id=request.step_id,
                to_list=request.to_list,
                cc_list=request.cc_list,
                bcc_list=request.bcc_list,
                allowed_sites=request.allowed_sites,
                columns_name=request.columns_name,
                global_filters=request.global_filters,
                progress_callback=lambda stage: EMAIL_JOBS[token_id].update(
                    {"stage": stage}
                ),
            )

        EMAIL_JOBS[token_id]["status"] = result.get("status", "COMPLETED")
        EMAIL_JOBS[token_id]["stage"] = "COMPLETED"
        EMAIL_JOBS[token_id]["result"] = result

    except Exception as e:

        EMAIL_JOBS[token_id]["status"] = "FAILED"
        EMAIL_JOBS[token_id]["stage"] = "FAILED"
        EMAIL_JOBS[token_id]["error"] = str(e)


# ---------------------------------------------------------------------------
# Start Email Job Endpoint
# ---------------------------------------------------------------------------

@router.post(
    "/send/workflow-email",
    response_model=SendWorkflowEmailStartResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Start workflow step email job",
)
async def send_workflow_step_email_endpoint(
    request: SendWorkflowEmailRequest,
):

    token_id = str(uuid.uuid4())

    EMAIL_JOBS[token_id] = {
        "status": "PENDING",
        "stage": "JOB_CREATED",
        "result": None,
        "error": None,
    }

    asyncio.create_task(
        run_email_job(
            token_id,
            request,
        )
    )

    return {
        "token_id": token_id,
        "status": "PENDING",
    }


@router.post(
    "/schedule/workflow-email",
    response_model=ScheduleWorkflowEmailResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Schedule workflow step email job",
)
async def send_workflow_step_email_endpoint(
    request: ScheduleWorkflowEmailRequest,
):

    token_id = str(uuid.uuid4())

    if request.is_recurring:

        if not request.schedule_time:
            raise HTTPException(
                status_code=400,
                detail="schedule_time required for recurring emails"
            )

        if not request.schedule_time_zone:
            raise HTTPException(
                status_code=400,
                detail="Time Zone required for emails"
            )

        if len(request.schedule_time) > 4:
            raise HTTPException(
                status_code=400,
                detail="Maximum 4 schedule times allowed"
            )
        
        if not request.days_of_week:
            raise HTTPException(
                status_code=400,
                detail="days_of_week is required for recurring emails"
            )
        

        await _save_workflow_email_schedule(token_id, request)

        return {
            "token_id": token_id,
            "status": "SCHEDULED"
        }


# ---------------------------------------------------------------------------
# Job Status Endpoint
# ---------------------------------------------------------------------------

@router.get(
    "/send/workflow-email/status/{token_id}",
    response_model=SendWorkflowEmailStatusResponse,
    summary="Check email job status",
)
async def get_email_job_status(token_id: str):

    job = EMAIL_JOBS.get(token_id)

    if not job:
        raise HTTPException(
            status_code=404,
            detail="Token ID not found",
        )

    return {
        "token_id": token_id,
        "status": job["status"],
        "stage": job.get("stage"),
        "result": job.get("result"),
        "error": job.get("error"),
    }


@router.post("/send/email", summary="Send email",)
async def send_email_endpoint(
    request: SendEmailRequest,
):

    try:

        result = await send_email(
            to_list=request.to_list,
            cc_list=request.cc_list,
            bcc_list=request.bcc_list,
            subject=request.subject,
            email_body=request.email_body,
            attachments=request.attachments,
        )

        return result

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Email send failed: {str(e)}",
        )
    

@router.post("/schedule/email", summary="Schedule email")
async def schedule_email_endpoint(
    request: ScheduleEmailRequest,
):

    try:
        async with get_connection() as db:

            result = await schedule_email(
                db=db,
                to_list=request.to_list,
                cc_list=request.cc_list,
                bcc_list=request.bcc_list,
                subject=request.subject,
                email_body=request.email_body,
                attachments=request.attachments,
                schedule_time=request.schedule_time,
                schedule_time_zone=request.schedule_time_zone,
                days_of_week=request.days_of_week,
            )

        return result

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Email schedule failed: {str(e)}",
        )
    
