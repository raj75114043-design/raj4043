import uuid
import asyncio
import json
from datetime import datetime
from typing import List, Optional, Dict, Any
from enum import Enum
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from asyncpg import Connection

from app.services.email_receiver import(
    save_received_email,
)

from app.db.pool import(
    get_db,
    get_connection
)

from app.schemas.email import(
    SaveReceivedEmail,
)


router = APIRouter(prefix="/email", tags=["Receive Email"])


@router.post("/received/email")
async def save_received_email_db(request: SaveReceivedEmail):
    try:
        async with get_connection() as db:

            try:
                received_time = datetime.fromisoformat(request.receivedTime)

            except Exception:
                raise HTTPException(
                    status_code=400,
                    detail="Invalid receivedTime format. Use ISO format."
                )
            
            attachments = attachments or []

            attachments_data = [
                att.dict() for att in attachments
            ]

            result = await save_received_email(
                db=db,
                email_from=request.email_from,
                to_list=request.to_list,
                cc_list=request.cc_list,
                subject=request.subject,
                body=request.body,
                received_time=received_time,
                attachments=attachments_data
            )

            return result

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail="Internal Server Error"
        )