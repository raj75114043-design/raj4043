from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional

class APIModel(BaseModel):
    """Base API model with unified serialization."""

    def to_dict(self) -> dict:
        return self.model_dump(exclude_none=True)