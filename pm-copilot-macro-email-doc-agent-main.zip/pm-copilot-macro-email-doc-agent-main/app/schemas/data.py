from pydantic import BaseModel
from typing import Dict, List, Any, Union

class APIModel(BaseModel):
    """Base API model with unified serialization."""

    def to_dict(self) -> dict:
        return self.model_dump(exclude_none=True)
    
