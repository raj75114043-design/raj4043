from enum import Enum
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from app.services.email_service import AllowedSites

class APIModel(BaseModel):
    """Base API model with unified serialization."""

    def to_dict(self) -> dict:
        return self.model_dump(exclude_none=True)
    

class WeekDay(str, Enum):
    MONDAY = "MONDAY"
    TUESDAY = "TUESDAY"
    WEDNESDAY = "WEDNESDAY"
    THURSDAY = "THURSDAY"
    FRIDAY = "FRIDAY"
    SATURDAY = "SATURDAY"
    SUNDAY = "SUNDAY"


class SendWorkflowEmailRequest(BaseModel):
    user_id: str
    workflow_name: str
    step_id: int
    to_list: List[str]
    cc_list: List[str] = []
    bcc_list: List[str] = []
    allowed_sites: AllowedSites = "ALL"
    columns_name: List[str] = []
    global_filters: Dict[str, List[str]] = {}

class SendWorkflowEmailStartResponse(BaseModel):
    token_id: str
    status: str

class SendWorkflowEmailStatusResponse(BaseModel):
    token_id: str
    status: str
    stage: str
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

class ScheduleWorkflowEmailRequest(BaseModel):
    user_id: str
    workflow_name: str
    step_id: int
    to_list: List[str]
    cc_list: List[str] = []
    bcc_list: List[str] = []
    allowed_sites: AllowedSites = "ALL"
    columns_name: List[str] = []
    global_filters: Dict[str, List[str]] = {}
    is_recurring: bool = True
    schedule_time: Optional[List[str]]
    schedule_time_zone: str = "UTC"
    days_of_week: Optional[List[WeekDay]] = None

class ScheduleWorkflowEmailResponse(BaseModel):
    token_id: str
    status: str


class SendEmailAttachment(BaseModel):
    file_name: str
    content_base64: Optional[str] = None
    s3_url: Optional[str] = None

class SendEmailRequest(BaseModel):
    to_list: List[str]
    cc_list: List[str] = []
    bcc_list: List[str] = []
    subject: str
    email_body: str
    attachments: List[SendEmailAttachment] = []

class ScheduleEmailRequest(BaseModel):
    to_list: List[str]
    cc_list: List[str] = []
    bcc_list: List[str] = []
    subject: str
    attachments: List[SendEmailAttachment] = []
    is_recurring: bool = True
    schedule_time: Optional[List[str]]
    schedule_time_zone: str = "UTC"
    days_of_week: Optional[List[WeekDay]]


class ReceivedEmailAttachment(BaseModel):
    file_name: str
    file_type: str
    file_content: Optional[str] = None  # base64
    file_url: Optional[str] = None

class SaveReceivedEmail(BaseModel):
    email_from: str
    to_list: List[str]
    cc_list: List[str]
    subject: str
    body: str
    receivedTime: str
    attachments: Optional[List[ReceivedEmailAttachment]] = []