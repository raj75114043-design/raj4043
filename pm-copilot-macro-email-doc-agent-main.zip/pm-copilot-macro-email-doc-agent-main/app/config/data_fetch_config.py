from typing import Dict
from typing import List, Dict, Any,  Set

BASE_SCHEMA = "pwc_macro_staging_schema"
WORKFLOW_OUTPUT_SCHEMA = "pwc_workflow_agent_schema"

STAGING_SOURCE_SCHEMA = 'public'
STAGING_TARGET_SCHEMA = 'pwc_macro_staging_schema'
STAGING_PREFIX = 'stg_'

DB_CONFIG = {
    'host': '10.208.241.129',
    'port': 30924,
    'database': 'postgres', 
    'user': 'osdp_pwc_read_role',
    'password': 'Nokia@osdp@pwc@2025'
}
