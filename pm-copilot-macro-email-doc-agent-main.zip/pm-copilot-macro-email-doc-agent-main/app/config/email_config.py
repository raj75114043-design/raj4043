from typing import Dict
from typing import List, Dict, Any,  Set

AUTH_URL = "https://nokiaosdp-gsd-staging.aibi-americas-002.dyn.nesc.nokia.net/web/session/authenticate"
SEND_MAIL_URL = "https://nokiaosdp-gsd-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/send_mail"

AUTH_PAYLOAD = {
    "jsonrpc": "2.0",
    "method": "call",
    "params": {
        "db": "postgres",
        "login": "pwc_osdp_user",
        "password": "pwc_osdp_user",
    },
}