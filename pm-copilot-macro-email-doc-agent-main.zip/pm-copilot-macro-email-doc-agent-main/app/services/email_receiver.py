import json
import base64
from typing import List, Optional
from datetime import datetime
from app.utils.timezone import get_datetime_now_without_zone


async def save_received_email(
    db,
    email_from: str,
    to_list: List[str],
    cc_list: List[str],
    subject: str,
    body: str,
    received_time: datetime,
    attachments: Optional[List[dict]] = None,
):
    """
    Save received email into DB
    """

    try:
        time_now = get_datetime_now_without_zone()

        query = """
            INSERT INTO pwc_workflow_agent_schema.email_received_tracker (
                email_from,
                to_list,
                cc_list,
                subject,
                body,
                received_time,
                attachments,
                created_at
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8)
            RETURNING id
        """

        result = await db.fetchrow(
            query,
            email_from,
            to_list,              
            cc_list,
            subject,
            body,
            received_time,
            json.dumps(attachments or []),
            time_now,
        )


        return {
            "id": result["id"],
            "message": "Email stored successfully"
        }

    except Exception as e:
        raise