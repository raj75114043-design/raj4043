import os
import base64
import aioboto3
import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
from loguru import logger


class S3Service:
    def __init__(self):
        self.endpoint_url = "https://ch-dc-s3-gsn-33.eecloud.nsn-net.net"
        self.access_key = "9RGT2HHNYIS1YJYIYQ89"
        self.secret_key = "0poVaw69SIIAwRJpCAVZkdQWmPixxVlFnYYx6Qag"
        self.region = "us-east-1"

        # Sync client (for presigned URL)
        self.s3 = boto3.client(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
            config=Config(signature_version="s3v4"),
            region_name=self.region
        )

    def _session(self):
        return aioboto3.Session()

    # =========================
    # BUCKET
    # =========================

    async def list_buckets(self):
        async with self._session().client(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
        ) as s3:
            resp = await s3.list_buckets()
            return [b["Name"] for b in resp.get("Buckets", [])]

    async def create_bucket(self, bucket):
        async with self._session().client(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
        ) as s3:
            await s3.create_bucket(Bucket=bucket)
            return f"Bucket {bucket} created"

    async def delete_bucket(self, bucket):
        async with self._session().client(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
        ) as s3:
            await s3.delete_bucket(Bucket=bucket)
            return f"Bucket {bucket} deleted"

    # =========================
    # FILE
    # =========================

    async def upload_bytes(self, bucket, key, data: bytes, content_type: str):
        async with self._session().client(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
        ) as s3:
            await s3.put_object(
                Bucket=bucket,
                Key=key,
                Body=data,
                ContentType=content_type
            )
            return {"key": key}

    async def stream_file(self, bucket, key):
        session = self._session()

        async with session.client(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
        ) as s3:

            obj = await s3.get_object(Bucket=bucket, Key=key)

            return {
                "body": obj["Body"],
                "content_type": obj.get("ContentType", "application/octet-stream"),
                "content_length": obj.get("ContentLength", 0)
            }

    async def delete_file(self, bucket, key):
        async with self._session().client(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
        ) as s3:
            await s3.delete_object(Bucket=bucket, Key=key)
            return {"deleted": key}

    # =========================
    # LISTING
    # =========================

    async def list_files(self, bucket, prefix=""):
        files = []

        async with self._session().client(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
        ) as s3:

            paginator = s3.get_paginator("list_objects_v2")

            async for page in paginator.paginate(Bucket=bucket, Prefix=prefix):
                for obj in page.get("Contents", []):
                    files.append({
                        "key": obj["Key"],
                        "size": obj["Size"]
                    })

        return files

    async def list_folders(self, bucket, prefix=""):
        async with self._session().client(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
        ) as s3:

            resp = await s3.list_objects_v2(
                Bucket=bucket,
                Prefix=prefix,
                Delimiter="/"
            )

            return [cp["Prefix"] for cp in resp.get("CommonPrefixes", [])]

    async def get_bucket_size(self, bucket):
        total_size = 0
        total_files = 0

        async with self._session().client(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
        ) as s3:

            paginator = s3.get_paginator("list_objects_v2")

            async for page in paginator.paginate(Bucket=bucket):
                for obj in page.get("Contents", []):
                    total_size += obj["Size"]
                    total_files += 1

        return {
            "total_size_bytes": total_size,
            "total_files": total_files
        }

    # =========================
    # BASE64
    # =========================

    async def file_to_base64(self, bucket, key):
        async with self._session().client(
            "s3",
            endpoint_url=self.endpoint_url,
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
        ) as s3:

            obj = await s3.get_object(Bucket=bucket, Key=key)
            data = await obj["Body"].read()

            encoded = base64.b64encode(data).decode("utf-8")

            return {
                "key": key,
                "base64": encoded,
                "size_mb": round(len(encoded) / (1024 * 1024), 2)
            }

    # =========================
    # PRESIGNED URL
    # =========================

    def generate_presigned_url(self, bucket, key, expiry=3600):
        try:
            url = self.s3.generate_presigned_url(
                "get_object",
                Params={"Bucket": bucket, "Key": key},
                ExpiresIn=expiry
            )
            return {"url": url}
        except ClientError as e:
            logger.error(str(e))
            raise Exception("Presigned URL generation failed")