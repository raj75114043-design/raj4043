import asyncio
import json
from asyncpg import Connection
from app.db.pool import get_db, get_connection
from app.services.email_service import send_workflow_step_email
from app.utils.timezone import get_datetime_now_without_zone

CHECK_INTERVAL = 300  #seconds

async def safe_email_task(**kwargs):

    try:
        async with get_connection() as db:
            return await asyncio.wait_for(
                send_workflow_step_email(db=db, **kwargs),
                timeout=120
            )
        
    except Exception as e:
        print(f"[EMAIL TASK FAILED] {e}")
        return {
            "status": "failed",
            "error": str(e)
        }

async def run_scheduler():

    while True:

        try: 

            DATE_TIME_WITHOUT_ZONE = get_datetime_now_without_zone()

            # CURRENT_TIME = DATE_TIME_WITHOUT_ZONE.time()
            # CURRENT_DATE = DATE_TIME_WITHOUT_ZONE.date()

            print(f"[{DATE_TIME_WITHOUT_ZONE}] Checking schedules...")


            async with get_connection() as db:

                QUERY = """
                    WITH base_time AS (
                        SELECT
                            (
                                ($1::timestamp AT TIME ZONE 'Asia/Kolkata')
                                AT TIME ZONE COALESCE(w.schedule_time_zone, 'Asia/Kolkata')
                            ) AS local_ts,
                            w.*
                        FROM pwc_workflow_agent_schema.workflow_email_schedule w
                    )

                    SELECT *
                    FROM base_time
                    WHERE is_enabled = TRUE
                    AND schedule_time <= (local_ts)::time

                    AND TRIM(UPPER(
                        TO_CHAR(local_ts, 'DAY')
                    )) = ANY(days_of_week)

                    AND (
                        last_run_time IS NULL

                        OR (
                            (last_run_time AT TIME ZONE COALESCE(schedule_time_zone, 'Asia/Kolkata'))::date
                            < (local_ts)::date
                        )

                        OR (
                            LOWER(mail_status) = 'failed'
                            AND
                            (last_run_time AT TIME ZONE COALESCE(schedule_time_zone, 'Asia/Kolkata'))::date
                            = (local_ts)::date
                        )
                    )

                    ORDER BY step_id;
                """

                rows = await db.fetch(
                    QUERY,
                    DATE_TIME_WITHOUT_ZONE,
                )

            print(
                f"[EMAIL JOB START] Schedules found: "
                f"{[(r['workflow_name'], r['step_id']) for r in rows]}"
            )

            tasks = []
            for r in rows:

                global_filters = r.get("global_filters")
                if isinstance(global_filters, str):
                    try:
                        global_filters = json.loads(global_filters)
                    except Exception:
                        global_filters = {}

                tasks.append(
                    safe_email_task(
                        workflow_name=r["workflow_name"],
                        step_id=r["step_id"],
                        to_list=r["to_list"],
                        cc_list=r["cc_list"],
                        bcc_list=r["bcc_list"],
                        allowed_sites=r["allowed_sites"],
                        columns_name=r.get("columns_name") or [],
                        global_filters=global_filters or {},
                        user_id=r["scheduled_by"],
                        scheduled_id=r['id'],
                    )
                )

            results = await asyncio.gather(*tasks, return_exceptions=True)

            async with get_connection() as db:
                for r, result in zip(rows, results):

                    if isinstance(result, Exception):
                        status = "failed"
                        print(f"[TASK ERROR] {result}")
                    else:
                        status = result.get("status", "failed")

                    print(f"Completed {r['workflow_name']} : step {r['step_id']} - {status} for token_id: {r['token_id']}")

                    DATE_TIME_WITHOUT_ZONE = get_datetime_now_without_zone()

                    await db.execute(
                        """
                        UPDATE pwc_workflow_agent_schema.workflow_email_schedule
                        SET last_run_time = $3,
                            mail_status = $2
                        WHERE token_id = $1
                        """,
                        r["token_id"],
                        status,
                        DATE_TIME_WITHOUT_ZONE
                    )
                    print(f"[EMAIL JOB DONE] Workflow Schedule Tracker Updated for  {r['workflow_name']} : {r['step_id']}")

        except Exception as e:
            print(f"[SCHEDULER ERROR] {e}")

        await asyncio.sleep(CHECK_INTERVAL)
        