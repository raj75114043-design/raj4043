import traceback
from typing import Dict
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.ai.documentintelligence.models import (
    DocumentContentFormat,
    AnalyzeResult
)
from azure.core.credentials import AzureKeyCredential


class AzureDocumentService:
    def __init__(self, endpoint: str, key: str):
        try:
            self.client = DocumentIntelligenceClient(
                endpoint=endpoint,
                credential=AzureKeyCredential(key)
            )
        except Exception:
            raise Exception(f"Azure Client Init Failed: {traceback.format_exc()}")

    async def analyze_file(
        self,
        file_bytes: bytes,
        content_type: str,
        model: str = "prebuilt-layout",
        output_format: str = "markdown"
    ) -> Dict:
        """
        Analyze uploaded file (PDF/Image)
        """

        try:
            poller = self.client.begin_analyze_document(
                model_id=model,
                body=file_bytes,
                content_type=content_type,
                output_content_format=(
                    DocumentContentFormat.MARKDOWN
                    if output_format == "markdown"
                    else DocumentContentFormat.TEXT
                )
            )

            result = poller.result()

            return self._format_response(result, model)

        except Exception:
            return {"error": traceback.format_exc()}

    def _format_response(self, result: AnalyzeResult, model: str) -> Dict:
        """
        Clean structured response
        """
        return {
            "model_used": model,
            "content": result.content,
            "pages": [
                {
                    "page_number": p.page_number,
                    "width": p.width,
                    "height": p.height,
                    "unit": p.unit
                }
                for p in (result.pages or [])
            ],
            "tables_count": len(result.tables) if result.tables else 0,
            "lines_count": sum(len(p.lines) for p in result.pages) if result.pages else 0
        }

    def health_check(self):
        return {"status": "Azure Document Intelligence service is running"}