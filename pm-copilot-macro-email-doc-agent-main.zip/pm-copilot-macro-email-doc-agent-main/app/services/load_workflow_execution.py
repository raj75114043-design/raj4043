import json
from typing import Dict, Any
from asyncpg import Connection


async def load_latest_workflow_execution(
    db: Connection,
    workflow_name: str,
) -> Dict[str, Any]:

    row = await db.fetchrow(
        """
        SELECT executed_result
          FROM pwc_workflow_agent_schema.workflow_yaml_pipelines
         WHERE workflow_name = $1
        """,
        workflow_name,
    )

    if row is None or row["executed_result"] is None:
        raise FileNotFoundError(f"No execution found for workflow '{workflow_name}'")

    result = row["executed_result"]

    if isinstance(result, str):
        result = json.loads(result)

    return result["executions"][0]
