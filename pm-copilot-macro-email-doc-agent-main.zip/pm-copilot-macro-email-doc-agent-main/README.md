# Nokia PM CoPilot - Email Document Agent Microservice

## Developers

- **Talib K Raza** - PwC India

## Overview


### Key Features


## Project Structure



## Prerequisites

- Python 3.14+
- Poetry (recommended) or pip
- PostgreSQL database
- Access to an LLM API endpoint (Azure OpenAI compatible)

## Installation

### Using Poetry (Recommended)

1. Install Poetry if not already installed:
   ```bash
   pip install poetry
   ```

2. Clone the repository and navigate to the project directory:
   ```bash
   cd email_doc_agent
   ```

3. Install dependencies:
   ```bash
   poetry install
   ```

4. Activate the virtual environment:
   ```bash
   poetry shell
   ```

### Using pip

```bash
pip install -r requirements.txt
```

## Configuration

Create a `.env` file in the project root with the following variables:

```env
# Application
APP_NAME=Email Document Agent
DEBUG=false

# Database
DATABASE_URL=postgresql+asyncpg://user:password@host:port/database

# LLM Configuration
LLM_API_KEY=your-api-key
LLM_API_KEY_URL=https://your-llm-endpoint/v1
WORKSPACE_NAME=your-workspace

# Optional
LLM_DEFAULT_TIER=medium
```

## Running the Application

### Development Mode

Using Poetry:
```bash
poetry run uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Or with the virtual environment activated:
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### Production Mode

```bash
poetry run uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

### Using Python directly

```bash
python main.py
```

## API Documentation
