"""
Email Document Agent FastAPI Application.

This is the main entry point for the Email Document Agent API.
It sets up the FastAPI application with:
- PostgreSQL connection pooling
- API routes for Email Document management
- Health check endpoints
- CORS middleware
"""
import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.llm_config import get_settings
from app.db.pool import DatabasePool
from app.api.routes import (
    health,
    data,
    send_email,
    azure_blob_storage,
    receive_email,
    doc_agent_endpoint,
    email_orchestration,
)
from app.services.email_scheduler import run_scheduler

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan manager.

    Handles startup and shutdown events:
    - Startup: Initialize database connection pool
    - Shutdown: Close database connection pool gracefully
    """
    # Startup
    settings = get_settings()
    print(f"Starting {settings.app_name}...")

    try:
        await DatabasePool.create_pool()
        print("Database pool initialized successfully")
        # START EMAIL SCHEDULER
        # asyncio.create_task(run_scheduler())
        
    except Exception as e:
        print(f"Warning: Failed to initialize database pool: {e}")
        print("API will start but database features may not work")

    yield
    # Shutdown
    print("Shutting down...")
    await DatabasePool.close_pool()
    print("Database pool closed")


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    settings = get_settings()

    app = FastAPI(
        title=settings.app_name,
        description="""
## Email Document Agent API

A modular Email Document agent for managing and executing Scheduled Emails OR Documents Processing.

""",
        version="1.0.0",
        lifespan=lifespan,
    )

    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure appropriately for production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Include routers
    app.include_router(health.router)
    app.include_router(data.router, prefix="/api/v1")
    app.include_router(send_email.router, prefix="/api/v1")
    app.include_router(receive_email.router, prefix="/api/v1")
    app.include_router(azure_blob_storage.router, prefix="/api/v1")
    app.include_router(doc_agent_endpoint.router, prefix="/api/v1")
    app.include_router(email_orchestration.router, prefix="/api/v1")
    

    return app


# Create the application instance
app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
    )
