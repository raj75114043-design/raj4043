-- Database initialization for Simulator/Scheduler Agent

-- Enable pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Create tables for chat history
CREATE TABLE IF NOT EXISTS chat_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id VARCHAR(255) NOT NULL,
    user_id VARCHAR(255),
    messages JSONB DEFAULT '[]'::jsonb,
    context JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_chat_history_session ON chat_history(session_id);
CREATE INDEX idx_chat_history_user ON chat_history(user_id);

-- Create tables for HITL sessions
CREATE TABLE IF NOT EXISTS hitl_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id VARCHAR(255) NOT NULL UNIQUE,
    simulation_run_id UUID,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    questions JSONB DEFAULT '[]'::jsonb,
    answers JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    responded_at TIMESTAMP,
    timeout_at TIMESTAMP
);

CREATE INDEX idx_hitl_session ON hitl_sessions(session_id);
CREATE INDEX idx_hitl_status ON hitl_sessions(status);

-- Create tables for simulation runs
CREATE TABLE IF NOT EXISTS simulation_runs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id VARCHAR(255) NOT NULL,
    user_id VARCHAR(255),
    query TEXT NOT NULL,
    intent VARCHAR(100),
    parameters JSONB DEFAULT '{}'::jsonb,
    status VARCHAR(50) NOT NULL DEFAULT 'pending',
    results JSONB DEFAULT '{}'::jsonb,
    trace JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    duration_ms INTEGER
);

CREATE INDEX idx_simulation_session ON simulation_runs(session_id);
CREATE INDEX idx_simulation_user ON simulation_runs(user_id);
CREATE INDEX idx_simulation_status ON simulation_runs(status);

-- Create tables for agent traces
CREATE TABLE IF NOT EXISTS agent_traces (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    simulation_run_id UUID REFERENCES simulation_runs(id),
    agent_name VARCHAR(100) NOT NULL,
    action VARCHAR(100) NOT NULL,
    input JSONB DEFAULT '{}'::jsonb,
    output JSONB DEFAULT '{}'::jsonb,
    duration_ms INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_trace_run ON agent_traces(simulation_run_id);

-- Create tables for user feedback
CREATE TABLE IF NOT EXISTS user_feedback (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id VARCHAR(255) NOT NULL,
    simulation_run_id UUID REFERENCES simulation_runs(id),
    rating INTEGER CHECK (rating >= 1 AND rating <= 5),
    feedback_text TEXT,
    corrections JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_feedback_session ON user_feedback(session_id);

-- Create tables for prompt templates
CREATE TABLE IF NOT EXISTS prompt_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL UNIQUE,
    version INTEGER NOT NULL DEFAULT 1,
    template TEXT NOT NULL,
    description TEXT,
    variables JSONB DEFAULT '[]'::jsonb,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE UNIQUE INDEX idx_prompt_name_version ON prompt_templates(name, version);

-- Create tables for document embeddings
CREATE TABLE IF NOT EXISTS document_embeddings (
    id SERIAL PRIMARY KEY,
    content TEXT NOT NULL,
    metadata JSONB,
    embedding vector(1536),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create IVFFlat index for similarity search (after data is loaded)
-- CREATE INDEX idx_embeddings ON document_embeddings USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);

-- Insert default prompt templates
INSERT INTO prompt_templates (name, version, template, description, variables) VALUES
('orchestrator_system', 1, 'You are the Orchestrator for Nokia''s MACRO Simulation System...', 'Main orchestrator system prompt', '["project_track"]'),
('query_refiner_system', 1, 'You are the Query Refiner for Nokia''s MACRO Simulation System...', 'Query refiner system prompt', '[]'),
('analyzer_system', 1, 'You are the Analyzer for Nokia''s MACRO Simulation System...', 'Result analyzer system prompt', '[]')
ON CONFLICT (name) DO NOTHING;

-- Grant permissions
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO postgres;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO postgres;