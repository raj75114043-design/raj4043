"""
Tests for Simulation Engine Models
"""

from datetime import date, timedelta

import pytest

from app.agents.simulator_agent.simulation_engine.models.schedule_model import (
    ScheduleModel,
    ScheduleParams,
)
from app.agents.simulator_agent.simulation_engine.models.capacity_model import (
    CapacityModel,
    CapacityParams,
)
from app.agents.simulator_agent.simulation_engine.models.prerequisite_model import (
    PrerequisiteModel,
    PrerequisiteParams,
)
from app.agents.simulator_agent.simulation_engine.models.risk_model import (
    RiskModel,
    RiskParams,
)
from app.agents.simulator_agent.simulation_engine.models.calendar_model import (
    CalendarModel,
    CalendarParams,
)
from app.agents.simulator_agent.simulation_engine.engine import SimulationEngine


class TestScheduleModel:
    """Tests for ScheduleModel."""
    
    def test_simulate_achievable_target(self):
        """Test simulation where target is achievable."""
        model = ScheduleModel()
        params = ScheduleParams(
            target_sites=100,
            ready_to_start=150,
            weekly_capacity=25,
            start_date=date(2025, 2, 1),
            end_date=date(2025, 3, 31),
        )
        
        result = model.simulate(params)
        
        assert result["target_achievable"] is True
        assert result["total_achievable"] >= 100
        assert result["gap"] == 0
        assert len(result["weekly_plan"]) > 0
    
    def test_simulate_unachievable_target(self):
        """Test simulation where target cannot be met."""
        model = ScheduleModel()
        params = ScheduleParams(
            target_sites=500,
            ready_to_start=50,
            weekly_capacity=25,
            start_date=date(2025, 2, 1),
            end_date=date(2025, 2, 28),
        )
        
        result = model.simulate(params)
        
        assert result["target_achievable"] is False
        assert result["gap"] > 0
    
    def test_simulate_weekly_plan_structure(self):
        """Test that weekly plan has correct structure."""
        model = ScheduleModel()
        params = ScheduleParams(
            target_sites=50,
            ready_to_start=100,
            weekly_capacity=20,
            start_date=date(2025, 2, 1),
            end_date=date(2025, 3, 1),
        )
        
        result = model.simulate(params)
        
        for week in result["weekly_plan"]:
            assert "week_number" in week
            assert "start_date" in week
            assert "end_date" in week
            assert "planned" in week
            assert "completed" in week
            assert "remaining" in week
            assert "crew_utilization" in week


class TestCapacityModel:
    """Tests for CapacityModel."""
    
    def test_calculate_capacity(self):
        """Test capacity calculation."""
        model = CapacityModel()
        params = CapacityParams(
            total_crews=25,
            available_crews=20,
            crew_productivity=1.0,
            working_days_per_week=5,
            vendors=[
                {"name": "Vendor A", "total_crews": 10, "available_crews": 8},
                {"name": "Vendor B", "total_crews": 15, "available_crews": 12},
            ],
        )
        
        result = model.calculate(params)
        
        assert result["total_crews"] == 25
        assert result["available_crews"] == 20
        assert result["weekly_capacity"] == 100  # 20 crews * 5 days * 1.0 productivity
        assert result["utilization"] == 0.8  # 20/25
    
    def test_calculate_required_crews(self):
        """Test required crews calculation."""
        model = CapacityModel()
        
        result = model.calculate_required_crews(
            target_sites=500,
            weeks=10,
            productivity=1.0,
            working_days=5,
        )
        
        assert result["crews_needed"] == 11  # 500 / (10 weeks * 5 days) + 1


class TestPrerequisiteModel:
    """Tests for PrerequisiteModel."""
    
    def test_calculate_readiness(self):
        """Test prerequisite readiness calculation."""
        model = PrerequisiteModel()
        params = PrerequisiteParams(
            total_sites=100,
            prerequisites={
                "power": 80,
                "fiber": 60,
                "permits": 90,
                "material": 70,
                "site_access": 95,
                "intp": 50,
            },
            lead_times={
                "power": 14,
                "fiber": 21,
                "permits": 7,
                "material": 10,
                "site_access": 3,
                "intp": 5,
            },
        )
        
        result = model.calculate(params)
        
        # Sites ready = minimum across all prerequisites
        assert result["sites_ready_to_start"] == 50  # min is intp at 50
        assert result["bottleneck"] == "intp"
        assert len(result["prereq_status"]) == 6


class TestRiskModel:
    """Tests for RiskModel."""
    
    def test_monte_carlo_high_success(self):
        """Test Monte Carlo with high success probability."""
        model = RiskModel()
        params = RiskParams(
            target_sites=100,
            achievable_sites=120,
            ready_sites=150,
            prereq_bottleneck="None",
            historical_variance=0.1,
            num_simulations=1000,
        )
        
        result = model.monte_carlo(params)
        
        assert result["success_probability"] > 0.7
        assert result["confidence_level"] in ["HIGH", "MEDIUM"]
    
    def test_monte_carlo_low_success(self):
        """Test Monte Carlo with low success probability."""
        model = RiskModel()
        params = RiskParams(
            target_sites=200,
            achievable_sites=100,
            ready_sites=50,
            prereq_bottleneck="power",
            historical_variance=0.2,
            num_simulations=1000,
        )
        
        result = model.monte_carlo(params)
        
        assert result["success_probability"] < 0.5
        assert len(result["risks"]) > 0


class TestCalendarModel:
    """Tests for CalendarModel."""
    
    def test_calculate_working_days(self):
        """Test working days calculation."""
        model = CalendarModel()
        params = CalendarParams(
            start_date=date(2025, 2, 3),  # Monday
            end_date=date(2025, 2, 14),   # Friday
            working_days_per_week=5,
            holidays=[],
        )
        
        result = model.calculate(params)
        
        assert result["total_working_days"] == 10  # 2 weeks * 5 days
        assert result["total_weeks"] == 2
    
    def test_calculate_with_holidays(self):
        """Test calculation with holidays."""
        model = CalendarModel()
        params = CalendarParams(
            start_date=date(2025, 2, 3),
            end_date=date(2025, 2, 14),
            working_days_per_week=5,
            holidays=[date(2025, 2, 10)],  # One holiday
        )
        
        result = model.calculate(params)
        
        assert result["total_working_days"] == 9  # 10 - 1 holiday
        assert result["holiday_count"] == 1


class TestSimulationEngine:
    """Tests for the full simulation engine."""
    
    def test_run_simulation_schedule(self):
        """Test running schedule simulation."""
        engine = SimulationEngine()
        
        result = engine.run_simulation(
            models=["Schedule", "Capacity", "Calendar"],
            data={
                "site_status": {"ready_to_start": 100, "total_sites": 200},
                "crew_capacity": {"available_crews": 20, "total_crews": 25, "vendors": []},
                "prereq_status": {
                    "total_sites": 200,
                    "power_ready": 150,
                    "fiber_ready": 120,
                    "permits_ready": 180,
                    "material_ready": 140,
                    "access_ready": 190,
                    "intp_ready": 100,
                },
            },
            parameters={
                "target_sites": 150,
                "market": "Chicago",
                "timeframe": {
                    "start_date": "2025-02-01",
                    "end_date": "2025-03-31",
                    "working_days_per_week": 5,
                },
                "constraints": {
                    "crew_productivity": 1.0,
                },
            },
        )
        
        assert "models_executed" in result
        assert "Schedule" in result["models_executed"]
        assert "combined_result" in result
        assert "execution_time_ms" in result