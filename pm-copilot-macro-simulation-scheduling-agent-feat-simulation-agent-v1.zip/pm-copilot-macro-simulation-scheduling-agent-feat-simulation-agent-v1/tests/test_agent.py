"""
Tests for Agent Integration
"""

from datetime import date
from unittest.mock import AsyncMock, patch

import pytest

from app.agents.simulator_agent.agent import run_simulator, build_simulator_graph
from app.agents.scheduler_agent.agent import run_scheduler, build_scheduler_graph
from app.core.models import ProjectTrack, SimulationStatus


class TestSimulatorAgent:
    """Tests for Simulator Agent."""
    
    def test_build_graph(self):
        """Test that simulator graph builds correctly."""
        graph = build_simulator_graph()
        
        assert graph is not None
        # Check that nodes are present
        assert hasattr(graph, 'nodes')
    
    @pytest.mark.asyncio
    async def test_run_simulator_basic(
        self,
        sample_query: str,
        sample_session_id: str,
        mock_llm,
    ):
        """Test basic simulator execution."""
        with patch(
            "app.agents.simulator_agent.nodes.query_refiner.get_llm",
            return_value=mock_llm
        ):
            result = await run_simulator(
                query=sample_query,
                session_id=sample_session_id,
                project_track=ProjectTrack.TMO_RPM,
            )
        
        assert result is not None
        assert result.scenario_id == sample_session_id
        # Should either complete or need clarification
        assert result.status in [
            SimulationStatus.COMPLETED,
            SimulationStatus.PENDING_CLARIFICATION,
            SimulationStatus.FAILED,
        ]
    
    @pytest.mark.asyncio
    async def test_run_simulator_with_parameters(
        self,
        sample_query: str,
        sample_session_id: str,
        sample_parameters,
    ):
        """Test simulator with pre-extracted parameters."""
        result = await run_simulator(
            query=sample_query,
            session_id=sample_session_id,
            project_track=ProjectTrack.TMO_RPM,
            parameters=sample_parameters,
        )
        
        assert result is not None


class TestSchedulerAgent:
    """Tests for Scheduler Agent."""
    
    def test_build_graph(self):
        """Test that scheduler graph builds correctly."""
        graph = build_scheduler_graph()
        
        assert graph is not None
    
    @pytest.mark.asyncio
    async def test_run_scheduler_basic(self, sample_session_id: str):
        """Test basic scheduler execution."""
        result = await run_scheduler(
            query="Create weekly schedule for Chicago",
            session_id=sample_session_id,
            market="Chicago",
            start_date=date(2025, 2, 1),
            end_date=date(2025, 3, 31),
            target_sites=100,
        )
        
        assert result is not None
        assert result["session_id"] == sample_session_id
        assert result["status"] in ["success", "error"]
    
    @pytest.mark.asyncio
    async def test_scheduler_output_structure(self, sample_session_id: str):
        """Test that scheduler output has correct structure."""
        result = await run_scheduler(
            query="Create schedule",
            session_id=sample_session_id,
            market="Chicago",
            start_date=date(2025, 2, 1),
            end_date=date(2025, 2, 28),
            target_sites=50,
        )
        
        if result["status"] == "success":
            schedule = result["schedule"]
            assert "summary" in schedule
            assert "weekly_plan" in schedule


class TestAgentState:
    """Tests for agent state management."""
    
    def test_create_simulator_state(self, mock_state_factory):
        """Test creating simulator state."""
        state = mock_state_factory.create(
            query="Test query",
            session_id="test-001",
        )
        
        assert state["query"] == "Test query"
        assert state["session_id"] == "test-001"
        assert state["status"] == SimulationStatus.PENDING_CLARIFICATION
    
    def test_state_with_parameters(self, mock_state_factory, sample_parameters):
        """Test state with parameters."""
        state = mock_state_factory.create(
            query="Test query",
            session_id="test-002",
            parameters=sample_parameters,
            user_confirmed=True,
            status=SimulationStatus.CONFIRMED,
        )
        
        assert state["parameters"] == sample_parameters
        assert state["user_confirmed"] is True
        assert state["status"] == SimulationStatus.CONFIRMED