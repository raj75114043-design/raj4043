"""
Tests for API Endpoints
"""

import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_health_check(async_client: AsyncClient):
    """Test health check endpoint."""
    response = await async_client.get("/api/v1/health")
    
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"


@pytest.mark.asyncio
async def test_scenarios_list(async_client: AsyncClient):
    """Test scenarios list endpoint."""
    response = await async_client.get("/api/v1/agents/scenarios")
    
    assert response.status_code == 200
    data = response.json()
    assert "scenarios" in data


@pytest.mark.asyncio
async def test_simulate_endpoint(async_client: AsyncClient, sample_query: str):
    """Test simulate endpoint."""
    response = await async_client.post(
        "/api/v1/agents/simulate",
        json={
            "query": sample_query,
            "project_track": "tmo_rpm",
        },
    )
    
    # Should return 200 with either result or clarification
    assert response.status_code in [200, 202]
    data = response.json()
    assert "session_id" in data
    assert "status" in data


@pytest.mark.asyncio
async def test_schedule_endpoint(async_client: AsyncClient):
    """Test schedule endpoint."""
    response = await async_client.post(
        "/api/v1/agents/schedule",
        json={
            "query": "Create schedule for Chicago",
            "market": "Chicago",
            "start_date": "2025-02-01",
            "end_date": "2025-03-31",
            "target_sites": 100,
        },
    )
    
    assert response.status_code in [200, 202]
    data = response.json()
    assert "session_id" in data


@pytest.mark.asyncio
async def test_chat_sync_endpoint(async_client: AsyncClient, sample_query: str):
    """Test synchronous chat endpoint."""
    response = await async_client.post(
        "/api/v1/chat/sync",
        json={
            "message": sample_query,
            "session_id": "test-chat-001",
        },
    )
    
    assert response.status_code == 200
    data = response.json()
    assert "response" in data or "result" in data


@pytest.mark.asyncio
async def test_invalid_request(async_client: AsyncClient):
    """Test handling of invalid request."""
    response = await async_client.post(
        "/api/v1/agents/simulate",
        json={
            # Missing required fields
        },
    )
    
    assert response.status_code == 422  # Validation error