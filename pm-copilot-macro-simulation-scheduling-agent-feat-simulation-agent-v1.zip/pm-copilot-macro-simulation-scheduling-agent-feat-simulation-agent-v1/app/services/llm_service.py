"""
LLM Service
Abstraction layer for LLM providers (OpenAI, Anthropic)
"""

from typing import Any, Dict, List, Optional, Union

import structlog
from langchain_anthropic import ChatAnthropic
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage, AIMessage
from langchain_openai import ChatOpenAI

from app.core.config import settings

logger = structlog.get_logger(__name__)


class LLMService:
    """Service for managing LLM interactions."""
    
    def __init__(
        self,
        provider: str = "openai",
        model: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ):
        """
        Initialize LLM service.
        
        Args:
            provider: LLM provider ("openai" or "anthropic")
            model: Model name override
            temperature: Temperature override
            max_tokens: Max tokens override
        """
        self.provider = provider.lower()
        self.temperature = temperature or settings.LLM_TEMPERATURE
        self.max_tokens = max_tokens or settings.LLM_MAX_TOKENS
        
        if self.provider == "openai":
            self.model = model or settings.OPENAI_MODEL
            self._llm = ChatOpenAI(
                model=self.model,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                api_key=settings.OPENAI_API_KEY,
            )
        elif self.provider == "anthropic":
            self.model = model or settings.ANTHROPIC_MODEL
            self._llm = ChatAnthropic(
                model=self.model,
                temperature=self.temperature,
                max_tokens=self.max_tokens,
                api_key=settings.ANTHROPIC_API_KEY,
            )
        else:
            raise ValueError(f"Unsupported LLM provider: {provider}")
        
        logger.info(
            "LLM service initialized",
            provider=self.provider,
            model=self.model,
            temperature=self.temperature,
        )
    
    @property
    def llm(self) -> BaseChatModel:
        """Get the underlying LLM instance."""
        return self._llm
    
    async def invoke(
        self,
        messages: List[Union[BaseMessage, Dict[str, str]]],
        **kwargs,
    ) -> AIMessage:
        """
        Invoke the LLM with messages.
        
        Args:
            messages: List of messages (can be BaseMessage or dict with role/content)
            **kwargs: Additional arguments passed to the LLM
            
        Returns:
            AI response message
        """
        # Convert dict messages to LangChain messages
        converted_messages = []
        for msg in messages:
            if isinstance(msg, BaseMessage):
                converted_messages.append(msg)
            elif isinstance(msg, dict):
                role = msg.get("role", "human")
                content = msg.get("content", "")
                if role == "system":
                    converted_messages.append(SystemMessage(content=content))
                elif role == "assistant":
                    converted_messages.append(AIMessage(content=content))
                else:
                    converted_messages.append(HumanMessage(content=content))
            else:
                raise ValueError(f"Unsupported message type: {type(msg)}")
        
        logger.debug(
            "Invoking LLM",
            provider=self.provider,
            model=self.model,
            message_count=len(converted_messages),
        )
        
        response = await self._llm.ainvoke(converted_messages, **kwargs)
        
        logger.debug(
            "LLM response received",
            response_length=len(response.content) if response.content else 0,
        )
        
        return response
    
    def bind_tools(self, tools: List[Any]) -> BaseChatModel:
        """
        Bind tools to the LLM for function calling.
        
        Args:
            tools: List of tools to bind
            
        Returns:
            LLM with bound tools
        """
        return self._llm.bind_tools(tools)


def get_llm(
    provider: str = "openai",
    model: Optional[str] = None,
    temperature: Optional[float] = None,
) -> BaseChatModel:
    """
    Factory function to get an LLM instance.
    
    Args:
        provider: LLM provider
        model: Model name
        temperature: Temperature setting
        
    Returns:
        LLM instance
    """
    service = LLMService(provider=provider, model=model, temperature=temperature)
    return service.llm