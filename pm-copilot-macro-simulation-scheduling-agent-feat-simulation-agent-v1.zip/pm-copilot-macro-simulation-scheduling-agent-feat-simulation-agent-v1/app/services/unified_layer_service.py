"""
Unified/Foundation Layer Service
Client for interacting with the Global Context/Semantic CURD API
"""

from typing import Any, Dict, List, Optional

import httpx
import structlog

from app.core.config import settings

logger = structlog.get_logger(__name__)


class UnifiedLayerService:
    """Client for the Global Context/Unified Layer API."""
    
    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: float = 30.0,
    ):
        """
        Initialize the unified layer service.
        
        Args:
            base_url: API base URL
            api_key: API key for authentication
            timeout: Request timeout in seconds
        """
        self.base_url = (base_url or settings.UNIFIED_LAYER_URL).rstrip("/")
        self.api_key = api_key or settings.UNIFIED_LAYER_API_KEY
        self.timeout = timeout
        
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=self.timeout,
            headers=self._get_headers(),
        )
        
        logger.info("Unified Layer service initialized", base_url=self.base_url)
    
    def _get_headers(self) -> Dict[str, str]:
        """Get request headers."""
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers
    
    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()
    
    # =========================================================================
    # KPI Catalog
    # =========================================================================
    
    async def get_kpi(self, kpi_name: str) -> Optional[Dict[str, Any]]:
        """
        Get KPI definition from catalog.
        
        Args:
            kpi_name: Name of the KPI
            
        Returns:
            KPI definition or None if not found
        """
        try:
            response = await self._client.get(f"/api/v1/kpi/{kpi_name}")
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                logger.warning("KPI not found", kpi_name=kpi_name)
                return None
            raise
    
    async def list_kpis(self, category: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List KPIs from catalog.
        
        Args:
            category: Optional category filter
            
        Returns:
            List of KPI definitions
        """
        params = {}
        if category:
            params["category"] = category
        
        response = await self._client.get("/api/v1/kpi", params=params)
        response.raise_for_status()
        return response.json()
    
    # =========================================================================
    # Question Bank
    # =========================================================================
    
    async def search_questions(
        self,
        query: str,
        limit: int = 5,
    ) -> List[Dict[str, Any]]:
        """
        Search question bank for similar questions.
        
        Args:
            query: Search query
            limit: Maximum results
            
        Returns:
            List of matching Q&A pairs
        """
        response = await self._client.post(
            "/api/v1/question-bank/search",
            json={"query": query, "limit": limit},
        )
        response.raise_for_status()
        return response.json()
    
    # =========================================================================
    # Simulation Bank
    # =========================================================================
    
    async def get_simulation_scenario(
        self,
        scenario_id: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Get simulation scenario definition.
        
        Args:
            scenario_id: Scenario identifier
            
        Returns:
            Scenario definition or None
        """
        try:
            response = await self._client.get(f"/api/v1/simulation/scenario/{scenario_id}")
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                return None
            raise
    
    async def search_simulation_scenarios(
        self,
        query: str,
        project_track: Optional[str] = None,
        limit: int = 5,
    ) -> List[Dict[str, Any]]:
        """
        Search for similar simulation scenarios.
        
        Args:
            query: Search query
            project_track: Filter by project track (TMO_RPM, NAS, DEC)
            limit: Maximum results
            
        Returns:
            List of matching scenarios
        """
        payload = {"query": query, "limit": limit}
        if project_track:
            payload["project_track"] = project_track
        
        response = await self._client.post(
            "/api/v1/simulation/search",
            json=payload,
        )
        response.raise_for_status()
        return response.json()
    
    # =========================================================================
    # Schema Metadata
    # =========================================================================
    
    async def get_table_schema(
        self,
        table_name: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Get enriched table schema metadata.
        
        Args:
            table_name: Table name
            
        Returns:
            Schema metadata or None
        """
        try:
            response = await self._client.get(f"/api/v1/schema/table/{table_name}")
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                return None
            raise
    
    async def search_columns(
        self,
        query: str,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """
        Search for columns by natural language query.
        
        Args:
            query: Natural language search
            limit: Maximum results
            
        Returns:
            List of matching columns with table context
        """
        response = await self._client.post(
            "/api/v1/schema/search",
            json={"query": query, "limit": limit},
        )
        response.raise_for_status()
        return response.json()
    
    # =========================================================================
    # Pre-processed Queries
    # =========================================================================
    
    async def get_cached_query(
        self,
        query_name: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Optional[Dict[str, Any]]:
        """
        Get pre-processed/cached query result.
        
        Args:
            query_name: Name of the cached query
            params: Query parameters
            
        Returns:
            Query result or None
        """
        try:
            response = await self._client.post(
                f"/api/v1/queries/cached/{query_name}",
                json=params or {},
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                return None
            raise
    
    # =========================================================================
    # Calendar Registry
    # =========================================================================
    
    async def get_calendar(
        self,
        market: str,
        start_date: str,
        end_date: str,
    ) -> Dict[str, Any]:
        """
        Get calendar information for a market.
        
        Args:
            market: Market name
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            
        Returns:
            Calendar data with working days and holidays
        """
        response = await self._client.get(
            "/api/v1/calendar",
            params={
                "market": market,
                "start_date": start_date,
                "end_date": end_date,
            },
        )
        response.raise_for_status()
        return response.json()
    
    # =========================================================================
    # SQL Execution
    # =========================================================================
    
    async def execute_sql(
        self,
        sql: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Execute SQL query via the unified layer.
        
        Args:
            sql: SQL query string
            params: Query parameters
            
        Returns:
            Query results
        """
        response = await self._client.post(
            "/api/v1/sql/execute",
            json={"sql": sql, "params": params or {}},
        )
        response.raise_for_status()
        return response.json()


# Global service instance
_unified_service: Optional[UnifiedLayerService] = None


async def get_unified_layer_service() -> UnifiedLayerService:
    """Get or create the unified layer service instance."""
    global _unified_service
    if _unified_service is None:
        _unified_service = UnifiedLayerService()
    return _unified_service