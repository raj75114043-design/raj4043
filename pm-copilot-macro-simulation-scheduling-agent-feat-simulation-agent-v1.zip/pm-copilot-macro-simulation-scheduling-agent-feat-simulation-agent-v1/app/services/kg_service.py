"""
Knowledge Graph Service
Client for interacting with the Knowledge Graph Consumption API (Neo4j/FalkorDB)
"""

from typing import Any, Dict, List, Optional

import httpx
import structlog

from app.core.config import settings

logger = structlog.get_logger(__name__)


class KnowledgeGraphService:
    """Client for the Knowledge Graph API."""
    
    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        timeout: float = 30.0,
    ):
        """
        Initialize the knowledge graph service.
        
        Args:
            base_url: API base URL
            api_key: API key for authentication
            timeout: Request timeout in seconds
        """
        self.base_url = (base_url or settings.KG_API_URL).rstrip("/")
        self.api_key = api_key or settings.KG_API_KEY
        self.timeout = timeout
        
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=self.timeout,
            headers=self._get_headers(),
        )
        
        logger.info("Knowledge Graph service initialized", base_url=self.base_url)
    
    def _get_headers(self) -> Dict[str, str]:
        """Get request headers."""
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers
    
    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()
    
    # =========================================================================
    # Entity Operations
    # =========================================================================
    
    async def get_entity(
        self,
        entity_type: str,
        entity_id: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Get an entity from the knowledge graph.
        
        Args:
            entity_type: Type of entity (Site, Project, Vendor, Market, etc.)
            entity_id: Entity identifier
            
        Returns:
            Entity data or None
        """
        try:
            response = await self._client.get(
                f"/api/v1/entity/{entity_type}/{entity_id}"
            )
            response.raise_for_status()
            return response.json()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                return None
            raise
    
    async def search_entities(
        self,
        entity_type: str,
        query: str,
        limit: int = 10,
    ) -> List[Dict[str, Any]]:
        """
        Search entities by natural language query.
        
        Args:
            entity_type: Type of entity to search
            query: Search query
            limit: Maximum results
            
        Returns:
            List of matching entities
        """
        response = await self._client.post(
            f"/api/v1/entity/{entity_type}/search",
            json={"query": query, "limit": limit},
        )
        response.raise_for_status()
        return response.json()
    
    # =========================================================================
    # Graph Traversal
    # =========================================================================
    
    async def get_neighbors(
        self,
        entity_type: str,
        entity_id: str,
        relationship_types: Optional[List[str]] = None,
        depth: int = 1,
    ) -> Dict[str, Any]:
        """
        Get neighboring entities in the graph.
        
        Args:
            entity_type: Type of starting entity
            entity_id: Starting entity ID
            relationship_types: Filter by relationship types
            depth: Traversal depth
            
        Returns:
            Graph neighborhood data
        """
        params = {"depth": depth}
        if relationship_types:
            params["relationship_types"] = ",".join(relationship_types)
        
        response = await self._client.get(
            f"/api/v1/entity/{entity_type}/{entity_id}/neighbors",
            params=params,
        )
        response.raise_for_status()
        return response.json()
    
    async def find_path(
        self,
        start_type: str,
        start_id: str,
        end_type: str,
        end_id: str,
        max_depth: int = 5,
    ) -> Optional[List[Dict[str, Any]]]:
        """
        Find shortest path between two entities.
        
        Args:
            start_type: Starting entity type
            start_id: Starting entity ID
            end_type: Ending entity type
            end_id: Ending entity ID
            max_depth: Maximum path length
            
        Returns:
            Path as list of nodes/edges or None
        """
        response = await self._client.post(
            "/api/v1/graph/path",
            json={
                "start_type": start_type,
                "start_id": start_id,
                "end_type": end_type,
                "end_id": end_id,
                "max_depth": max_depth,
            },
        )
        response.raise_for_status()
        result = response.json()
        return result.get("path")
    
    # =========================================================================
    # Business Entity Queries
    # =========================================================================
    
    async def get_market_vendors(
        self,
        market: str,
    ) -> List[Dict[str, Any]]:
        """
        Get all vendors assigned to a market.
        
        Args:
            market: Market name
            
        Returns:
            List of vendor entities with capacity info
        """
        response = await self._client.get(
            f"/api/v1/market/{market}/vendors"
        )
        response.raise_for_status()
        return response.json()
    
    async def get_site_dependencies(
        self,
        site_code: str,
    ) -> Dict[str, Any]:
        """
        Get all dependencies for a site.
        
        Args:
            site_code: Site code identifier
            
        Returns:
            Site dependencies (prerequisites, blockers, etc.)
        """
        response = await self._client.get(
            f"/api/v1/site/{site_code}/dependencies"
        )
        response.raise_for_status()
        return response.json()
    
    async def get_vendor_sites(
        self,
        vendor_name: str,
        market: Optional[str] = None,
        status: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Get sites assigned to a vendor.
        
        Args:
            vendor_name: Vendor name
            market: Optional market filter
            status: Optional status filter
            
        Returns:
            List of site entities
        """
        params = {}
        if market:
            params["market"] = market
        if status:
            params["status"] = status
        
        response = await self._client.get(
            f"/api/v1/vendor/{vendor_name}/sites",
            params=params,
        )
        response.raise_for_status()
        return response.json()
    
    # =========================================================================
    # Cypher Query (Advanced)
    # =========================================================================
    
    async def execute_cypher(
        self,
        query: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Execute a raw Cypher query.
        
        Args:
            query: Cypher query string
            params: Query parameters
            
        Returns:
            Query results
        """
        response = await self._client.post(
            "/api/v1/graph/cypher",
            json={"query": query, "params": params or {}},
        )
        response.raise_for_status()
        return response.json()
    
    # =========================================================================
    # Analytics
    # =========================================================================
    
    async def get_market_summary(
        self,
        market: str,
    ) -> Dict[str, Any]:
        """
        Get summary statistics for a market.
        
        Args:
            market: Market name
            
        Returns:
            Market summary with site counts, vendor counts, etc.
        """
        response = await self._client.get(
            f"/api/v1/analytics/market/{market}/summary"
        )
        response.raise_for_status()
        return response.json()
    
    async def get_prerequisite_summary(
        self,
        market: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Get prerequisite status summary.
        
        Args:
            market: Optional market filter
            
        Returns:
            Prerequisite summary by type
        """
        params = {}
        if market:
            params["market"] = market
        
        response = await self._client.get(
            "/api/v1/analytics/prerequisites/summary",
            params=params,
        )
        response.raise_for_status()
        return response.json()


# Global service instance
_kg_service: Optional[KnowledgeGraphService] = None


async def get_kg_service() -> KnowledgeGraphService:
    """Get or create the knowledge graph service instance."""
    global _kg_service
    if _kg_service is None:
        _kg_service = KnowledgeGraphService()
    return _kg_service