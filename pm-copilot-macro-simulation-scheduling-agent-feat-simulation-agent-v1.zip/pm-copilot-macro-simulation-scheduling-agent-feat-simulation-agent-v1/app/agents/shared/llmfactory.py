"""
A unified wrapper for initializing and managing large language models. It dynamically selects
between OpenAI (ChatOpenAI) and Azure OpenAI (AzureChatOpenAI) implementations
based on application configuration.

Key Features:
- Supports both OpenAI and Azure OpenAI backends.
- Centralized configuration using application settings.
- Pass-through support for additional model-specific parameters.
- Secure API key handling using Pydantic SecretStr.
- Structured exception handling with detailed logging.

This abstraction ensures consistent LLM initialization across the application
while keeping provider-specific logic encapsulated and configurable.
"""

from typing import Any, List, Optional

from langchain_anthropic import ChatAnthropic
from langchain_core.language_models import BaseChatModel
from langchain_openai import ChatOpenAI

from app.core.config import settings


def get_llm(
    provider: str = "openai",
    model: Optional[str] = None,
    temperature: float = 0.1,
    max_tokens: int = 4096,
    streaming: bool = False,
) -> BaseChatModel:
    """
    Factory function to create an LLM instance.
    
    Args:
        provider: LLM provider ("openai" or "anthropic")
        model: Model name (uses default if not specified)
        temperature: Temperature for generation
        max_tokens: Maximum tokens to generate
        streaming: Enable streaming mode
        
    Returns:
        Configured LLM instance
    """
    provider = provider.lower()
    
    if provider == "openai":
        return ChatOpenAI(
            model=model or settings.OPENAI_MODEL,
            temperature=temperature,
            max_tokens=max_tokens,
            api_key=settings.OPENAI_API_KEY,
            streaming=streaming,
        )
    elif provider == "anthropic":
        return ChatAnthropic(
            model=model or settings.ANTHROPIC_MODEL,
            temperature=temperature,
            max_tokens=max_tokens,
            api_key=settings.ANTHROPIC_API_KEY,
            streaming=streaming,
        )
    else:
        raise ValueError(f"Unsupported LLM provider: {provider}")


def get_llm_with_tools(
    tools: List[Any],
    provider: str = "openai",
    model: Optional[str] = None,
    temperature: float = 0.1,
) -> BaseChatModel:
    """
    Create an LLM with tools bound for function calling.
    
    Args:
        tools: List of tools to bind
        provider: LLM provider
        model: Model name
        temperature: Temperature for generation
        
    Returns:
        LLM with bound tools
    """
    llm = get_llm(
        provider=provider,
        model=model,
        temperature=temperature,
    )
    return llm.bind_tools(tools)