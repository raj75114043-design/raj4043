"""
Base Tools
Common tools shared across all agents
"""

from typing import Any, Dict, List, Optional

import structlog
from langchain_core.tools import tool
from pydantic import BaseModel, Field

logger = structlog.get_logger(__name__)


# ============================================================================
# Tool Input Schemas
# ============================================================================

class SQLQueryInput(BaseModel):
    """Input for SQL query tool."""
    query: str = Field(..., description="SQL query to execute")
    params: Optional[Dict[str, Any]] = Field(default=None, description="Query parameters")


class CachedQueryInput(BaseModel):
    """Input for cached query tool."""
    query_name: str = Field(..., description="Name of the cached query")
    params: Optional[Dict[str, Any]] = Field(default=None, description="Query parameters")


class KPIInput(BaseModel):
    """Input for KPI lookup tool."""
    kpi_name: str = Field(..., description="Name of the KPI")
    market: Optional[str] = Field(default=None, description="Market filter")


class CalendarInput(BaseModel):
    """Input for calendar tool."""
    market: str = Field(..., description="Market name")
    start_date: str = Field(..., description="Start date (YYYY-MM-DD)")
    end_date: str = Field(..., description="End date (YYYY-MM-DD)")


class SearchInput(BaseModel):
    """Input for search tools."""
    query: str = Field(..., description="Search query")
    limit: int = Field(default=5, description="Maximum results")


# ============================================================================
# Data Tools
# ============================================================================

@tool(args_schema=SQLQueryInput)
async def execute_sql(query: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Execute a SQL query against the project database.
    Use this for custom data retrieval that isn't available via cached queries.
    """
    from app.services.unified_layer_service import get_unified_layer_service
    
    logger.debug("Executing SQL query", query=query[:100])
    
    try:
        service = await get_unified_layer_service()
        result = await service.execute_sql(query, params)
        return result
    except Exception as e:
        logger.error("SQL execution failed", error=str(e))
        return {"error": str(e), "success": False}


@tool(args_schema=CachedQueryInput)
async def get_cached_data(query_name: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Get pre-processed/cached data from the unified layer.
    Available queries: site_status, crew_capacity, prereq_status, run_rate, vendor_performance
    """
    from app.services.unified_layer_service import get_unified_layer_service
    
    logger.debug("Getting cached data", query_name=query_name, params=params)
    
    try:
        service = await get_unified_layer_service()
        result = await service.get_cached_query(query_name, params)
        return result or {"error": "Query not found", "success": False}
    except Exception as e:
        logger.error("Cached query failed", error=str(e))
        return {"error": str(e), "success": False}


@tool(args_schema=KPIInput)
async def get_kpi(kpi_name: str, market: Optional[str] = None) -> Dict[str, Any]:
    """
    Get KPI definition and current value from the KPI catalog.
    KPIs include: FTR_rate, civil_completion_delay, rework_rate, crew_utilization, etc.
    """
    from app.services.unified_layer_service import get_unified_layer_service
    
    logger.debug("Getting KPI", kpi_name=kpi_name, market=market)
    
    try:
        service = await get_unified_layer_service()
        kpi = await service.get_kpi(kpi_name)
        
        if not kpi:
            return {"error": f"KPI not found: {kpi_name}", "success": False}
        
        # If market specified, get current value
        if market:
            value_result = await service.get_cached_query(
                f"kpi_{kpi_name}",
                {"market": market}
            )
            kpi["current_value"] = value_result
        
        return kpi
    except Exception as e:
        logger.error("KPI lookup failed", error=str(e))
        return {"error": str(e), "success": False}


@tool(args_schema=CalendarInput)
async def get_calendar(market: str, start_date: str, end_date: str) -> Dict[str, Any]:
    """
    Get calendar information including working days and holidays for a market.
    """
    from app.services.unified_layer_service import get_unified_layer_service
    
    logger.debug("Getting calendar", market=market, start_date=start_date, end_date=end_date)
    
    try:
        service = await get_unified_layer_service()
        result = await service.get_calendar(market, start_date, end_date)
        return result
    except Exception as e:
        logger.error("Calendar lookup failed", error=str(e))
        return {"error": str(e), "success": False}


# ============================================================================
# Knowledge Graph Tools
# ============================================================================

@tool
async def get_market_summary(market: str) -> Dict[str, Any]:
    """
    Get summary statistics for a market including site counts, vendor counts, etc.
    """
    from app.services.kg_service import get_kg_service
    
    logger.debug("Getting market summary", market=market)
    
    try:
        service = await get_kg_service()
        result = await service.get_market_summary(market)
        return result
    except Exception as e:
        logger.error("Market summary failed", error=str(e))
        return {"error": str(e), "success": False}


@tool
async def get_vendor_capacity(market: str) -> List[Dict[str, Any]]:
    """
    Get vendor capacity information for a market including crew counts and availability.
    """
    from app.services.kg_service import get_kg_service
    
    logger.debug("Getting vendor capacity", market=market)
    
    try:
        service = await get_kg_service()
        result = await service.get_market_vendors(market)
        return result
    except Exception as e:
        logger.error("Vendor capacity failed", error=str(e))
        return [{"error": str(e), "success": False}]


@tool
async def get_site_dependencies(site_code: str) -> Dict[str, Any]:
    """
    Get all dependencies and blockers for a specific site.
    """
    from app.services.kg_service import get_kg_service
    
    logger.debug("Getting site dependencies", site_code=site_code)
    
    try:
        service = await get_kg_service()
        result = await service.get_site_dependencies(site_code)
        return result
    except Exception as e:
        logger.error("Site dependencies failed", error=str(e))
        return {"error": str(e), "success": False}


@tool
async def get_prerequisite_summary(market: Optional[str] = None) -> Dict[str, Any]:
    """
    Get prerequisite status summary (power, fiber, permits, material, etc.)
    Optionally filtered by market.
    """
    from app.services.kg_service import get_kg_service
    
    logger.debug("Getting prerequisite summary", market=market)
    
    try:
        service = await get_kg_service()
        result = await service.get_prerequisite_summary(market)
        return result
    except Exception as e:
        logger.error("Prerequisite summary failed", error=str(e))
        return {"error": str(e), "success": False}


# ============================================================================
# Search Tools
# ============================================================================

@tool(args_schema=SearchInput)
async def search_similar_scenarios(query: str, limit: int = 5) -> List[Dict[str, Any]]:
    """
    Search for similar simulation scenarios from the scenario bank.
    Use this to find examples of how similar queries were handled.
    """
    from app.services.unified_layer_service import get_unified_layer_service
    
    logger.debug("Searching similar scenarios", query=query[:50])
    
    try:
        service = await get_unified_layer_service()
        result = await service.search_simulation_scenarios(query, limit=limit)
        return result
    except Exception as e:
        logger.error("Scenario search failed", error=str(e))
        return [{"error": str(e), "success": False}]


@tool(args_schema=SearchInput)
async def search_schema(query: str, limit: int = 10) -> List[Dict[str, Any]]:
    """
    Search for database columns and tables by natural language query.
    Use this to discover available data for simulation.
    """
    from app.services.unified_layer_service import get_unified_layer_service
    
    logger.debug("Searching schema", query=query[:50])
    
    try:
        service = await get_unified_layer_service()
        result = await service.search_columns(query, limit=limit)
        return result
    except Exception as e:
        logger.error("Schema search failed", error=str(e))
        return [{"error": str(e), "success": False}]


# ============================================================================
# Tool Collections
# ============================================================================

DATA_TOOLS = [
    execute_sql,
    get_cached_data,
    get_kpi,
    get_calendar,
]

KG_TOOLS = [
    get_market_summary,
    get_vendor_capacity,
    get_site_dependencies,
    get_prerequisite_summary,
]

SEARCH_TOOLS = [
    search_similar_scenarios,
    search_schema,
]

ALL_TOOLS = DATA_TOOLS + KG_TOOLS + SEARCH_TOOLS