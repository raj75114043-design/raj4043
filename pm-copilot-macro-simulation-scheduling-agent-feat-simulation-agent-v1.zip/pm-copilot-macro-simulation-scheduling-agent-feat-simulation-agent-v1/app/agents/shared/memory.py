"""
Conversation Memory
Manages conversation history and context
"""

from typing import Any, Dict, List, Optional
from datetime import datetime

import structlog
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, BaseMessage

logger = structlog.get_logger(__name__)


class ConversationMemory:
    """
    Manages conversation memory for agent sessions.
    Stores messages and provides context retrieval.
    """
    
    def __init__(
        self,
        session_id: str,
        max_messages: int = 50,
        max_tokens: int = 8000,
    ):
        """
        Initialize conversation memory.
        
        Args:
            session_id: Unique session identifier
            max_messages: Maximum messages to retain
            max_tokens: Approximate maximum tokens to retain
        """
        self.session_id = session_id
        self.max_messages = max_messages
        self.max_tokens = max_tokens
        self.messages: List[Dict[str, Any]] = []
        self.context: Dict[str, Any] = {}
        self.created_at = datetime.utcnow()
        self.updated_at = datetime.utcnow()
    
    def add_message(
        self,
        role: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Add a message to the conversation history.
        
        Args:
            role: Message role (user, assistant, system, tool)
            content: Message content
            metadata: Optional metadata
        """
        message = {
            "role": role,
            "content": content,
            "metadata": metadata or {},
            "timestamp": datetime.utcnow().isoformat(),
        }
        
        self.messages.append(message)
        self.updated_at = datetime.utcnow()
        
        # Trim if exceeding limits
        self._trim_messages()
        
        logger.debug(
            "Message added to memory",
            session_id=self.session_id,
            role=role,
            message_count=len(self.messages),
        )
    
    def add_user_message(self, content: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Add a user message."""
        self.add_message("user", content, metadata)
    
    def add_assistant_message(self, content: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Add an assistant message."""
        self.add_message("assistant", content, metadata)
    
    def add_system_message(self, content: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Add a system message."""
        self.add_message("system", content, metadata)
    
    def add_tool_message(
        self,
        tool_name: str,
        result: Any,
        tool_call_id: str,
    ) -> None:
        """Add a tool result message."""
        self.add_message(
            "tool",
            str(result),
            {
                "tool_name": tool_name,
                "tool_call_id": tool_call_id,
            },
        )
    
    def get_messages(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get messages from history.
        
        Args:
            limit: Optional limit on number of messages
            
        Returns:
            List of messages
        """
        if limit:
            return self.messages[-limit:]
        return self.messages
    
    def get_langchain_messages(self, limit: Optional[int] = None) -> List[BaseMessage]:
        """
        Get messages as LangChain message objects.
        
        Args:
            limit: Optional limit on number of messages
            
        Returns:
            List of LangChain messages
        """
        messages = self.get_messages(limit)
        lc_messages = []
        
        for msg in messages:
            role = msg["role"]
            content = msg["content"]
            
            if role == "user":
                lc_messages.append(HumanMessage(content=content))
            elif role == "assistant":
                lc_messages.append(AIMessage(content=content))
            elif role == "system":
                lc_messages.append(SystemMessage(content=content))
            # Tool messages require special handling
        
        return lc_messages
    
    def set_context(self, key: str, value: Any) -> None:
        """Set a context value."""
        self.context[key] = value
        self.updated_at = datetime.utcnow()
    
    def get_context(self, key: str, default: Any = None) -> Any:
        """Get a context value."""
        return self.context.get(key, default)
    
    def update_context(self, updates: Dict[str, Any]) -> None:
        """Update multiple context values."""
        self.context.update(updates)
        self.updated_at = datetime.utcnow()
    
    def clear(self) -> None:
        """Clear all messages and context."""
        self.messages = []
        self.context = {}
        self.updated_at = datetime.utcnow()
        logger.debug("Memory cleared", session_id=self.session_id)
    
    def _trim_messages(self) -> None:
        """Trim messages to stay within limits."""
        if len(self.messages) > self.max_messages:
            # Keep the most recent messages
            self.messages = self.messages[-self.max_messages:]
            logger.debug(
                "Messages trimmed",
                session_id=self.session_id,
                new_count=len(self.messages),
            )
    
    def _estimate_tokens(self) -> int:
        """Estimate total tokens in memory."""
        # Rough estimate: 4 characters per token
        total_chars = sum(len(msg["content"]) for msg in self.messages)
        return total_chars // 4
    
    def to_dict(self) -> Dict[str, Any]:
        """Serialize memory to dictionary."""
        return {
            "session_id": self.session_id,
            "messages": self.messages,
            "context": self.context,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConversationMemory":
        """Deserialize memory from dictionary."""
        memory = cls(session_id=data["session_id"])
        memory.messages = data.get("messages", [])
        memory.context = data.get("context", {})
        return memory


# In-memory store for active sessions
_memory_store: Dict[str, ConversationMemory] = {}


def get_memory(session_id: str) -> ConversationMemory:
    """
    Get or create conversation memory for a session.
    
    Args:
        session_id: Session identifier
        
    Returns:
        ConversationMemory instance
    """
    if session_id not in _memory_store:
        _memory_store[session_id] = ConversationMemory(session_id)
    return _memory_store[session_id]


def clear_memory(session_id: str) -> None:
    """Clear memory for a session."""
    if session_id in _memory_store:
        del _memory_store[session_id]