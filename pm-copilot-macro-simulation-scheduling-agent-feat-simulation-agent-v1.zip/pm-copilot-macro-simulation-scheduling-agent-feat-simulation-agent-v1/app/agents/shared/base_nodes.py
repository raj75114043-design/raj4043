"""
Base Nodes
Reusable node functions for agent graphs
"""

from typing import Any, Dict, List, Optional, TypeVar

import structlog
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

logger = structlog.get_logger(__name__)

# Type variable for state
StateType = TypeVar("StateType")


async def log_state_transition(
    state: Dict[str, Any],
    node_name: str,
    action: str,
) -> None:
    """Log state transition for observability."""
    logger.info(
        "State transition",
        node=node_name,
        action=action,
        status=state.get("status"),
        step_count=len(state.get("execution_trace", [])),
    )


def add_trace_step(
    state: Dict[str, Any],
    agent: str,
    action: str,
    input_data: Dict[str, Any],
    output_data: Dict[str, Any],
    duration_ms: int = 0,
) -> Dict[str, Any]:
    """Add a step to the execution trace."""
    from uuid import uuid4
    from datetime import datetime
    
    trace = state.get("execution_trace", [])
    trace.append({
        "step_id": str(uuid4()),
        "agent": agent,
        "action": action,
        "input": input_data,
        "output": output_data,
        "duration_ms": duration_ms,
        "timestamp": datetime.utcnow().isoformat(),
    })
    
    return {**state, "execution_trace": trace}


def format_messages_for_llm(
    system_prompt: str,
    user_query: str,
    context: Optional[Dict[str, Any]] = None,
    history: Optional[List[Dict[str, str]]] = None,
) -> List[Any]:
    """Format messages for LLM invocation."""
    messages = [SystemMessage(content=system_prompt)]
    
    # Add history if provided
    if history:
        for msg in history:
            if msg["role"] == "user":
                messages.append(HumanMessage(content=msg["content"]))
            elif msg["role"] == "assistant":
                messages.append(AIMessage(content=msg["content"]))
    
    # Add context to user query if provided
    if context:
        context_str = "\n".join([f"- {k}: {v}" for k, v in context.items()])
        user_query = f"{user_query}\n\nContext:\n{context_str}"
    
    messages.append(HumanMessage(content=user_query))
    
    return messages


def extract_tool_calls(message: AIMessage) -> List[Dict[str, Any]]:
    """Extract tool calls from an AI message."""
    if not hasattr(message, "tool_calls") or not message.tool_calls:
        return []
    
    return [
        {
            "id": call.get("id", ""),
            "name": call.get("name", ""),
            "args": call.get("args", {}),
        }
        for call in message.tool_calls
    ]


async def execute_tool_calls(
    tool_calls: List[Dict[str, Any]],
    tools: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """Execute tool calls and return results."""
    results = []
    
    for call in tool_calls:
        tool_name = call["name"]
        tool_args = call["args"]
        
        if tool_name not in tools:
            results.append({
                "tool_call_id": call["id"],
                "name": tool_name,
                "error": f"Unknown tool: {tool_name}",
            })
            continue
        
        try:
            tool = tools[tool_name]
            result = await tool.ainvoke(tool_args)
            results.append({
                "tool_call_id": call["id"],
                "name": tool_name,
                "result": result,
            })
        except Exception as e:
            logger.error("Tool execution failed", tool=tool_name, error=str(e))
            results.append({
                "tool_call_id": call["id"],
                "name": tool_name,
                "error": str(e),
            })
    
    return results


def create_tool_messages(tool_results: List[Dict[str, Any]]) -> List[ToolMessage]:
    """Create ToolMessage objects from tool results."""
    return [
        ToolMessage(
            content=str(result.get("result", result.get("error", ""))),
            tool_call_id=result["tool_call_id"],
            name=result["name"],
        )
        for result in tool_results
    ]


def should_continue_tools(state: Dict[str, Any]) -> str:
    """
    Determine if tool execution should continue.
    Returns "continue" or "end".
    """
    messages = state.get("messages", [])
    if not messages:
        return "end"
    
    last_message = messages[-1]
    
    # Check if there are pending tool calls
    if hasattr(last_message, "tool_calls") and last_message.tool_calls:
        return "continue"
    
    return "end"


def should_request_clarification(state: Dict[str, Any]) -> bool:
    """
    Determine if HITL clarification is needed.
    """
    missing_params = state.get("missing_parameters", [])
    clarification_count = state.get("clarification_count", 0)
    max_clarifications = state.get("max_clarifications", 3)
    
    return len(missing_params) > 0 and clarification_count < max_clarifications


def validate_parameters(
    params: Dict[str, Any],
    required_fields: List[str],
) -> tuple[bool, List[str]]:
    """
    Validate that required parameters are present.
    Returns (is_valid, missing_fields).
    """
    missing = []
    for field in required_fields:
        if field not in params or params[field] is None:
            missing.append(field)
    
    return len(missing) == 0, missing