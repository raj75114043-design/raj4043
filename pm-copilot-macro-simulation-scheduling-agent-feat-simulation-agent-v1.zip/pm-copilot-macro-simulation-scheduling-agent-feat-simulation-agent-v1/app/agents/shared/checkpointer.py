"""
Checkpointer
LangGraph checkpoint management for state persistence
"""

from typing import Optional

import structlog
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.checkpoint.memory import MemorySaver

from app.core.config import settings

logger = structlog.get_logger(__name__)

# Global checkpointer instance
_checkpointer: Optional[BaseCheckpointSaver] = None


def get_checkpointer() -> BaseCheckpointSaver:
    """
    Get or create the checkpointer instance.
    
    In production, this would use PostgreSQL or Redis.
    For development, uses in-memory storage.
    
    Returns:
        Checkpointer instance
    """
    global _checkpointer
    
    if _checkpointer is None:
        if settings.APP_ENV == "production":
            # In production, use PostgreSQL checkpointer
            # from langgraph.checkpoint.postgres import PostgresSaver
            # _checkpointer = PostgresSaver(connection_string=settings.DATABASE_URL)
            logger.info("Using memory checkpointer (configure PostgreSQL for production)")
            _checkpointer = MemorySaver()
        else:
            # Development uses in-memory storage
            logger.info("Using in-memory checkpointer for development")
            _checkpointer = MemorySaver()
    
    return _checkpointer


def reset_checkpointer() -> None:
    """Reset the global checkpointer instance."""
    global _checkpointer
    _checkpointer = None
    logger.info("Checkpointer reset")