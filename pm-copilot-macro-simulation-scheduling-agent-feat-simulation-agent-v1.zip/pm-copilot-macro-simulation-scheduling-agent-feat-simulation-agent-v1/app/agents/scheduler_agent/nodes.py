"""
Scheduler Agent Nodes
Graph nodes for schedule planning
"""

from datetime import datetime, timedelta
from typing import Any, Dict, List

import structlog

from app.agents.scheduler_agent.state import SchedulerState, ScheduleTask
from app.agents.shared.base_tools import get_cached_data, get_vendor_capacity

logger = structlog.get_logger(__name__)


async def fetch_scheduling_data(state: SchedulerState) -> Dict[str, Any]:
    """
    Fetch all data needed for scheduling.
    """
    logger.info("Fetching scheduling data", market=state["market"])
    
    start_time = datetime.utcnow()
    
    market = state["market"]
    
    # Fetch site data
    try:
        sites_data = await get_cached_data.ainvoke({
            "query_name": "site_status",
            "params": {"market": market},
        })
    except Exception:
        sites_data = _get_mock_sites(market)
    
    # Fetch crew data
    try:
        crew_data = await get_vendor_capacity.ainvoke(market)
    except Exception:
        crew_data = _get_mock_crews(market)
    
    # Fetch prerequisite status
    try:
        prereq_data = await get_cached_data.ainvoke({
            "query_name": "prereq_status",
            "params": {"market": market},
        })
    except Exception:
        prereq_data = _get_mock_prereqs(market)
    
    duration_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
    
    trace_step = {
        "node": "fetch_scheduling_data",
        "duration_ms": duration_ms,
        "timestamp": datetime.utcnow().isoformat(),
    }
    
    return {
        "available_sites": sites_data.get("sites", []) if isinstance(sites_data, dict) else [],
        "crew_availability": crew_data.get("crews", []) if isinstance(crew_data, dict) else [],
        "prereq_status": prereq_data if isinstance(prereq_data, dict) else {},
        "vendor_capacity": crew_data if isinstance(crew_data, dict) else {},
        "status": "planning",
        "execution_trace": state.get("execution_trace", []) + [trace_step],
    }


async def create_weekly_plan(state: SchedulerState) -> Dict[str, Any]:
    """
    Create a weekly schedule plan.
    """
    logger.info("Creating weekly plan", market=state["market"])
    
    start_time = datetime.utcnow()
    
    start_date = state["start_date"]
    end_date = state["end_date"]
    target_sites = state["target_sites"]
    working_days = state["working_days_per_week"]
    
    # Calculate number of weeks
    total_days = (end_date - start_date).days
    num_weeks = total_days // 7 + 1
    
    # Get available capacity
    vendor_capacity = state.get("vendor_capacity", {})
    total_crews = vendor_capacity.get("total_crews", 10)
    weekly_capacity = total_crews * working_days
    
    # Build weekly plan
    weekly_plan = []
    remaining = target_sites
    current_date = start_date
    
    for week_num in range(1, num_weeks + 1):
        week_start = current_date
        week_end = current_date + timedelta(days=6)
        
        # Plan sites for this week
        sites_this_week = min(weekly_capacity, remaining)
        remaining -= sites_this_week
        
        # Distribute across vendors
        vendors = vendor_capacity.get("vendors", [])
        vendor_allocation = _allocate_to_vendors(sites_this_week, vendors)
        
        weekly_plan.append({
            "week_number": week_num,
            "start_date": week_start.isoformat(),
            "end_date": week_end.isoformat(),
            "sites_planned": sites_this_week,
            "sites_remaining": remaining,
            "vendor_allocation": vendor_allocation,
            "capacity_utilization": sites_this_week / weekly_capacity if weekly_capacity > 0 else 0,
        })
        
        current_date = week_end + timedelta(days=1)
        
        if remaining <= 0:
            break
    
    duration_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
    
    trace_step = {
        "node": "create_weekly_plan",
        "weeks_planned": len(weekly_plan),
        "duration_ms": duration_ms,
        "timestamp": datetime.utcnow().isoformat(),
    }
    
    return {
        "weekly_plan": weekly_plan,
        "status": "optimizing",
        "execution_trace": state.get("execution_trace", []) + [trace_step],
    }


async def create_daily_schedule(state: SchedulerState) -> Dict[str, Any]:
    """
    Create detailed daily schedule with crew assignments.
    """
    logger.info("Creating daily schedule", market=state["market"])
    
    start_time = datetime.utcnow()
    
    weekly_plan = state.get("weekly_plan", [])
    available_sites = state.get("available_sites", [])
    crew_availability = state.get("crew_availability", [])
    
    daily_plan = []
    schedule_tasks = []
    
    # Create daily breakdown for first 2 weeks (detailed view)
    for week in weekly_plan[:2]:
        week_start = datetime.fromisoformat(week["start_date"]).date()
        sites_per_day = week["sites_planned"] // 5  # 5 working days
        
        for day_offset in range(5):  # 5 working days
            day_date = week_start + timedelta(days=day_offset)
            
            # Assign sites to crews
            day_tasks = []
            for task_idx in range(sites_per_day):
                task_id = f"T-{week['week_number']:02d}-{day_offset+1}-{task_idx+1:03d}"
                
                day_tasks.append({
                    "task_id": task_id,
                    "site_id": f"SITE-{len(schedule_tasks) + task_idx + 1:05d}",
                    "task_type": "integration",
                    "scheduled_date": day_date.isoformat(),
                    "status": "scheduled",
                })
                
                schedule_tasks.append(ScheduleTask(
                    task_id=task_id,
                    site_id=f"SITE-{len(schedule_tasks) + task_idx + 1:05d}",
                    task_type="integration",
                    vendor="TBD",
                    crew_id=None,
                    scheduled_date=day_date,
                    priority=1,
                    dependencies=[],
                    status="scheduled",
                    notes=None,
                ))
            
            daily_plan.append({
                "date": day_date.isoformat(),
                "day_of_week": day_date.strftime("%A"),
                "week_number": week["week_number"],
                "tasks_count": len(day_tasks),
                "tasks": day_tasks,
            })
    
    duration_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
    
    trace_step = {
        "node": "create_daily_schedule",
        "days_planned": len(daily_plan),
        "tasks_created": len(schedule_tasks),
        "duration_ms": duration_ms,
        "timestamp": datetime.utcnow().isoformat(),
    }
    
    return {
        "daily_plan": daily_plan,
        "current_schedule": schedule_tasks,
        "status": "completed",
        "execution_trace": state.get("execution_trace", []) + [trace_step],
    }


async def generate_schedule_output(state: SchedulerState) -> Dict[str, Any]:
    """
    Generate final schedule output.
    """
    logger.info("Generating schedule output")
    
    start_time = datetime.utcnow()
    
    weekly_plan = state.get("weekly_plan", [])
    daily_plan = state.get("daily_plan", [])
    
    # Build summary
    total_sites = sum(w.get("sites_planned", 0) for w in weekly_plan)
    total_weeks = len(weekly_plan)
    
    final_schedule = {
        "summary": {
            "market": state["market"],
            "start_date": state["start_date"].isoformat(),
            "end_date": state["end_date"].isoformat(),
            "target_sites": state["target_sites"],
            "planned_sites": total_sites,
            "weeks_required": total_weeks,
            "achievable": total_sites >= state["target_sites"],
        },
        "weekly_plan": weekly_plan,
        "daily_plan": daily_plan[:10],  # First 10 days
        "fast_track_opportunities": _identify_fast_track(weekly_plan),
        "risks": _identify_scheduling_risks(state),
        "generated_at": datetime.utcnow().isoformat(),
    }
    
    duration_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
    
    trace_step = {
        "node": "generate_schedule_output",
        "duration_ms": duration_ms,
        "timestamp": datetime.utcnow().isoformat(),
    }
    
    return {
        "final_schedule": final_schedule,
        "status": "completed",
        "completed_at": datetime.utcnow(),
        "execution_trace": state.get("execution_trace", []) + [trace_step],
    }


def _allocate_to_vendors(
    sites: int,
    vendors: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Allocate sites to vendors proportionally."""
    if not vendors:
        return [{"vendor": "Default", "sites": sites}]
    
    total_capacity = sum(v.get("available_crews", 1) for v in vendors)
    
    allocation = []
    remaining = sites
    
    for vendor in vendors:
        vendor_capacity = vendor.get("available_crews", 1)
        vendor_share = int(sites * vendor_capacity / total_capacity)
        vendor_share = min(vendor_share, remaining)
        
        allocation.append({
            "vendor": vendor.get("name", "Unknown"),
            "sites": vendor_share,
            "crews": vendor_capacity,
        })
        
        remaining -= vendor_share
    
    # Assign remaining to first vendor
    if remaining > 0 and allocation:
        allocation[0]["sites"] += remaining
    
    return allocation


def _identify_fast_track(weekly_plan: List[Dict[str, Any]]) -> List[str]:
    """Identify fast-track opportunities."""
    opportunities = []
    
    for week in weekly_plan:
        utilization = week.get("capacity_utilization", 0)
        if utilization < 0.8:
            opportunities.append(
                f"Week {week['week_number']}: {int((1-utilization)*100)}% capacity available for fast-track"
            )
    
    return opportunities[:5]


def _identify_scheduling_risks(state: SchedulerState) -> List[Dict[str, str]]:
    """Identify scheduling risks."""
    risks = []
    
    if state["target_sites"] > sum(w.get("sites_planned", 0) for w in state.get("weekly_plan", [])):
        risks.append({
            "risk": "Target may not be achievable with current capacity",
            "severity": "HIGH",
            "mitigation": "Add crews or extend timeline",
        })
    
    return risks


def _get_mock_sites(market: str) -> Dict[str, Any]:
    """Mock site data."""
    return {
        "sites": [{"site_id": f"SITE-{i:05d}", "status": "ready"} for i in range(100)],
        "total": 100,
    }


def _get_mock_crews(market: str) -> Dict[str, Any]:
    """Mock crew data."""
    return {
        "total_crews": 20,
        "vendors": [
            {"name": "Vendor A", "available_crews": 8},
            {"name": "Vendor B", "available_crews": 7},
            {"name": "Vendor C", "available_crews": 5},
        ],
        "crews": [],
    }


def _get_mock_prereqs(market: str) -> Dict[str, Any]:
    """Mock prerequisite data."""
    return {"ready_sites": 100, "blocked_sites": 50}