"""
Scheduler Agent State
Defines the state schema for the scheduler agent graph
"""

from datetime import date, datetime
from typing import Annotated, Any, Dict, List, Optional, Sequence, TypedDict

from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages

from app.core.models import ProjectTrack


class ScheduleTask(TypedDict):
    """Individual task in the schedule."""
    task_id: str
    site_id: str
    task_type: str  # civil, integration, commissioning, etc.
    vendor: str
    crew_id: Optional[str]
    scheduled_date: date
    priority: int
    dependencies: List[str]
    status: str  # scheduled, in_progress, completed, blocked
    notes: Optional[str]


class SchedulerState(TypedDict):
    """
    State schema for the Scheduler Agent.
    """
    # Session info
    session_id: str
    user_id: Optional[str]
    project_track: ProjectTrack
    
    # Request
    query: str
    messages: Annotated[Sequence[BaseMessage], add_messages]
    
    # Planning parameters
    market: str
    start_date: date
    end_date: date
    target_sites: int
    working_days_per_week: int
    
    # Data
    available_sites: List[Dict[str, Any]]
    crew_availability: List[Dict[str, Any]]
    prereq_status: Dict[str, Any]
    vendor_capacity: Dict[str, Any]
    
    # Schedule state
    current_schedule: List[ScheduleTask]
    weekly_plan: List[Dict[str, Any]]
    daily_plan: List[Dict[str, Any]]
    
    # Optimization
    optimization_constraints: Dict[str, Any]
    optimization_result: Dict[str, Any]
    
    # Output
    final_schedule: Dict[str, Any]
    
    # Status
    status: str  # pending, planning, optimizing, completed, failed
    error: Optional[str]
    
    # Trace
    execution_trace: List[Dict[str, Any]]
    
    # Timestamps
    started_at: Optional[datetime]
    completed_at: Optional[datetime]


def create_scheduler_state(
    query: str,
    session_id: str,
    market: str,
    start_date: date,
    end_date: date,
    project_track: ProjectTrack = ProjectTrack.TMO_RPM,
    target_sites: int = 0,
) -> SchedulerState:
    """Create initial scheduler state."""
    return SchedulerState(
        session_id=session_id,
        user_id=None,
        project_track=project_track,
        query=query,
        messages=[],
        market=market,
        start_date=start_date,
        end_date=end_date,
        target_sites=target_sites,
        working_days_per_week=5,
        available_sites=[],
        crew_availability=[],
        prereq_status={},
        vendor_capacity={},
        current_schedule=[],
        weekly_plan=[],
        daily_plan=[],
        optimization_constraints={},
        optimization_result={},
        final_schedule={},
        status="pending",
        error=None,
        execution_trace=[],
        started_at=datetime.utcnow(),
        completed_at=None,
    )