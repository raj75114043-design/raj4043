"""
Scheduler Agent
LangGraph-based agent for schedule planning and optimization
"""

from datetime import date, datetime
from typing import Any, AsyncGenerator, Dict, Optional

import structlog
from langgraph.graph import END, StateGraph
from langgraph.graph.graph import CompiledGraph

from app.agents.scheduler_agent.state import SchedulerState, create_scheduler_state
from app.agents.scheduler_agent.nodes import (
    fetch_scheduling_data,
    create_weekly_plan,
    create_daily_schedule,
    generate_schedule_output,
)
from app.agents.shared.checkpointer import get_checkpointer
from app.core.models import ProjectTrack

logger = structlog.get_logger(__name__)


def build_scheduler_graph() -> CompiledGraph:
    """
    Build the scheduler agent graph.
    
    Graph Structure:
    start -> fetch_data -> create_weekly_plan -> create_daily_schedule -> generate_output -> end
    """
    graph = StateGraph(SchedulerState)
    
    # Add nodes
    graph.add_node("fetch_data", fetch_scheduling_data)
    graph.add_node("create_weekly_plan", create_weekly_plan)
    graph.add_node("create_daily_schedule", create_daily_schedule)
    graph.add_node("generate_output", generate_schedule_output)
    
    # Set entry point
    graph.set_entry_point("fetch_data")
    
    # Add edges
    graph.add_edge("fetch_data", "create_weekly_plan")
    graph.add_edge("create_weekly_plan", "create_daily_schedule")
    graph.add_edge("create_daily_schedule", "generate_output")
    graph.add_edge("generate_output", END)
    
    # Compile
    checkpointer = get_checkpointer()
    compiled = graph.compile(checkpointer=checkpointer)
    
    return compiled


# Global compiled graph
scheduler_graph = build_scheduler_graph()


async def run_scheduler(
    query: str,
    session_id: str,
    market: str,
    start_date: date,
    end_date: date,
    target_sites: int = 0,
    project_track: ProjectTrack = ProjectTrack.TMO_RPM,
) -> Dict[str, Any]:
    """
    Run the scheduler to create a schedule.
    
    Args:
        query: Natural language request
        session_id: Unique session identifier
        market: Target market
        start_date: Schedule start date
        end_date: Schedule end date
        target_sites: Target number of sites
        project_track: Project track context
        
    Returns:
        Schedule result
    """
    logger.info(
        "Starting scheduler",
        session_id=session_id,
        market=market,
        target_sites=target_sites,
    )
    
    # Create initial state
    initial_state = create_scheduler_state(
        query=query,
        session_id=session_id,
        market=market,
        start_date=start_date,
        end_date=end_date,
        target_sites=target_sites,
        project_track=project_track,
    )
    
    config = {"configurable": {"thread_id": session_id}}
    
    try:
        final_state = await scheduler_graph.ainvoke(initial_state, config)
        
        logger.info(
            "Scheduler completed",
            session_id=session_id,
            status=final_state.get("status"),
        )
        
        return {
            "status": "success",
            "session_id": session_id,
            "schedule": final_state.get("final_schedule", {}),
            "execution_trace": final_state.get("execution_trace", []),
        }
        
    except Exception as e:
        logger.error("Scheduler failed", error=str(e), session_id=session_id)
        return {
            "status": "error",
            "session_id": session_id,
            "error": str(e),
        }


async def stream_scheduler(
    query: str,
    session_id: str,
    market: str,
    start_date: date,
    end_date: date,
    target_sites: int = 0,
) -> AsyncGenerator[Dict[str, Any], None]:
    """
    Stream scheduler execution events.
    """
    logger.info("Starting streaming scheduler", session_id=session_id)
    
    initial_state = create_scheduler_state(
        query=query,
        session_id=session_id,
        market=market,
        start_date=start_date,
        end_date=end_date,
        target_sites=target_sites,
    )
    
    config = {"configurable": {"thread_id": session_id}}
    
    try:
        async for event in scheduler_graph.astream(initial_state, config):
            for node_name, node_output in event.items():
                if node_name == "__end__":
                    continue
                
                yield {
                    "type": "node_execution",
                    "node": node_name,
                    "status": node_output.get("status", ""),
                }
                
                if node_output.get("weekly_plan"):
                    yield {
                        "type": "weekly_plan",
                        "data": node_output["weekly_plan"],
                    }
                
                if node_output.get("final_schedule"):
                    yield {
                        "type": "result",
                        "data": node_output["final_schedule"],
                    }
        
        yield {"type": "done", "message": "Schedule created successfully."}
        
    except Exception as e:
        logger.error("Streaming scheduler error", error=str(e))
        yield {"type": "error", "message": str(e)}