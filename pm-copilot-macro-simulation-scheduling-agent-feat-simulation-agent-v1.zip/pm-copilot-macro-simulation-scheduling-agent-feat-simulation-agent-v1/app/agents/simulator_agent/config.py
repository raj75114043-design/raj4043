"""
Simulator Agent Configuration
"""

from typing import Dict, List

from pydantic import BaseModel

from app.core.config import settings


class SimulatorConfig(BaseModel):
    """Configuration for the simulator agent."""
    
    # LLM settings
    llm_provider: str = "openai"
    llm_model: str = settings.OPENAI_MODEL
    llm_temperature: float = 0.1
    
    # HITL settings
    hitl_timeout_seconds: int = settings.HITL_TIMEOUT_SECONDS
    max_clarifications: int = settings.HITL_MAX_CLARIFICATIONS
    
    # Simulation settings
    max_simulation_weeks: int = settings.SIMULATION_MAX_WEEKS
    default_working_days: int = settings.SIMULATION_DEFAULT_WORKING_DAYS
    default_crew_productivity: float = settings.SIMULATION_DEFAULT_CREW_PRODUCTIVITY
    
    # Retry settings
    max_retries: int = 3
    retry_delay_seconds: float = 1.0
    
    # Output settings
    max_recommendations: int = 5
    max_risks: int = 10


# Default configuration
DEFAULT_CONFIG = SimulatorConfig()


# Model selection by intent
INTENT_MODEL_MAPPING: Dict[str, List[str]] = {
    "schedule": ["Schedule", "Capacity", "Calendar", "Prerequisite"],
    "resource_impact": ["Capacity", "Impact", "Schedule"],
    "process_change": ["Impact", "Prerequisite", "Schedule"],
    "risk_assessment": ["Risk", "Schedule", "Calendar"],
    "vendor_performance": ["Capacity", "Impact", "Risk"],
    "capacity_planning": ["Capacity", "Schedule", "Calendar"],
    "what_if": ["Impact", "Schedule", "Risk"],
}


# Required parameters by intent
REQUIRED_PARAMETERS: Dict[str, List[str]] = {
    "schedule": ["market", "target_sites", "timeframe"],
    "resource_impact": ["market", "resource_type", "change_amount"],
    "process_change": ["process", "change_amount", "scope"],
    "risk_assessment": ["risk_factor", "scope"],
    "vendor_performance": ["market"],
    "capacity_planning": ["target_sites", "timeframe"],
    "what_if": ["scenario_description"],
}


# Data source mappings
CACHED_QUERY_NAMES = [
    "site_status",
    "crew_capacity",
    "prereq_status",
    "run_rate",
    "vendor_performance",
    "milestone_progress",
    "quality_metrics",
]


# KPI catalog names
KPI_NAMES = [
    "FTR_rate",
    "civil_completion_delay",
    "rework_rate",
    "crew_utilization",
    "prerequisite_lead_time",
    "on_air_delay",
    "vendor_delivery_rate",
]