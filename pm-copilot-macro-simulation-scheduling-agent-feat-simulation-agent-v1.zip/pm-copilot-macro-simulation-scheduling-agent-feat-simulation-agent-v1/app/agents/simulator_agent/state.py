"""
Simulator Agent State
Defines the state schema for the simulator agent graph
"""

from datetime import datetime
from typing import Annotated, Any, Dict, List, Optional, Sequence, TypedDict

from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages

from app.core.models import (
    SimulationIntent,
    SimulationStatus,
    SimulationParameters,
    ClarificationQuestion,
    ProjectTrack,
)


class SimulatorState(TypedDict):
    """
    State schema for the Simulator Agent.
    
    This state is shared across all nodes in the graph and
    tracks the complete simulation lifecycle.
    """
    
    # Session information
    session_id: str
    user_id: Optional[str]
    project_track: ProjectTrack
    
    # Original query
    query: str
    
    # Messages for LLM context (using add_messages reducer)
    messages: Annotated[Sequence[BaseMessage], add_messages]
    
    # Query understanding
    intent: Optional[SimulationIntent]
    extracted_entities: Dict[str, Any]
    
    # HITL state
    status: SimulationStatus
    clarification_needed: bool
    clarification_questions: List[ClarificationQuestion]
    clarification_count: int
    max_clarifications: int
    user_confirmed: bool
    confirmed_answers: Dict[str, Any]
    
    # Validated parameters
    parameters: Optional[SimulationParameters]
    missing_parameters: List[str]
    
    # Planning state
    data_requirements: List[Dict[str, Any]]
    models_needed: List[str]
    execution_plan: Dict[str, Any]
    
    # Data collection state
    collected_data: Dict[str, Any]
    data_collection_complete: bool
    
    # Simulation state
    simulation_results: Dict[str, Any]
    simulation_complete: bool
    
    # Analysis state
    analysis_results: Dict[str, Any]
    risks_identified: List[Dict[str, Any]]
    recommendations: List[str]
    
    # Output state
    final_output: Dict[str, Any]
    output_format: str  # table, chart, summary, full
    
    # Execution trace for observability
    execution_trace: List[Dict[str, Any]]
    
    # Error handling
    error: Optional[str]
    retry_count: int
    max_retries: int
    
    # Timestamps
    started_at: Optional[datetime]
    completed_at: Optional[datetime]


def create_initial_state(
    query: str,
    session_id: str,
    project_track: ProjectTrack = ProjectTrack.TMO_RPM,
    user_id: Optional[str] = None,
    parameters: Optional[Dict[str, Any]] = None,
) -> SimulatorState:
    """
    Create initial state for a new simulation.
    
    Args:
        query: User's simulation query
        session_id: Unique session identifier
        project_track: Project track (TMO_RPM, NAS, DEC)
        user_id: Optional user identifier
        parameters: Optional pre-extracted parameters
        
    Returns:
        Initial SimulatorState
    """
    return SimulatorState(
        # Session
        session_id=session_id,
        user_id=user_id,
        project_track=project_track,
        
        # Query
        query=query,
        messages=[],
        
        # Query understanding
        intent=None,
        extracted_entities={},
        
        # HITL
        status=SimulationStatus.PENDING_CLARIFICATION,
        clarification_needed=False,
        clarification_questions=[],
        clarification_count=0,
        max_clarifications=3,
        user_confirmed=False,
        confirmed_answers=parameters or {},
        
        # Parameters
        parameters=None,
        missing_parameters=[],
        
        # Planning
        data_requirements=[],
        models_needed=[],
        execution_plan={},
        
        # Data
        collected_data={},
        data_collection_complete=False,
        
        # Simulation
        simulation_results={},
        simulation_complete=False,
        
        # Analysis
        analysis_results={},
        risks_identified=[],
        recommendations=[],
        
        # Output
        final_output={},
        output_format="full",
        
        # Trace
        execution_trace=[],
        
        # Error handling
        error=None,
        retry_count=0,
        max_retries=3,
        
        # Timestamps
        started_at=datetime.utcnow(),
        completed_at=None,
    )


# Reducer functions for state updates
def merge_collected_data(
    existing: Dict[str, Any],
    new_data: Dict[str, Any],
) -> Dict[str, Any]:
    """Merge new collected data with existing data."""
    merged = existing.copy()
    merged.update(new_data)
    return merged


def append_trace_step(
    trace: List[Dict[str, Any]],
    step: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """Append a step to the execution trace."""
    return trace + [step]