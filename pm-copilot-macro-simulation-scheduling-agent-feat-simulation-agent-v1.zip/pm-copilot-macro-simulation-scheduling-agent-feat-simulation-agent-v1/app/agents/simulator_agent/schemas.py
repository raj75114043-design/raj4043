"""
Simulator Agent Schemas
Input and output schemas for the simulator agent
"""

from datetime import date, datetime
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field

from app.core.models import (
    SimulationIntent,
    SimulationStatus,
    ProjectTrack,
)


# ============================================================================
# Input Schemas
# ============================================================================

class SimulatorInput(BaseModel):
    """Input schema for simulator agent invocation."""
    
    query: str = Field(..., description="Natural language simulation query")
    session_id: str = Field(..., description="Unique session identifier")
    project_track: ProjectTrack = Field(
        default=ProjectTrack.TMO_RPM,
        description="Project track context"
    )
    user_id: Optional[str] = Field(default=None, description="User identifier")
    parameters: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Pre-extracted parameters"
    )
    history: Optional[List[Dict[str, str]]] = Field(
        default=None,
        description="Conversation history"
    )


class HITLConfirmInput(BaseModel):
    """Input schema for HITL confirmation."""
    
    session_id: str
    answers: Dict[str, Any]
    confirmed: bool = True


# ============================================================================
# Output Schemas
# ============================================================================

class ExtractedEntities(BaseModel):
    """Entities extracted from query."""
    
    market: Optional[str] = None
    region: Optional[str] = None
    target_sites: Optional[int] = None
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    duration_weeks: Optional[int] = None
    working_days_per_week: int = 5
    holidays: List[date] = Field(default_factory=list)
    constraints: Dict[str, Any] = Field(default_factory=dict)
    vendors: List[str] = Field(default_factory=list)


class ClarificationQuestion(BaseModel):
    """A question for HITL clarification."""
    
    question: str
    options: Optional[List[str]] = None
    default_value: Optional[Any] = None
    required: bool = True
    parameter_key: str = ""


class QueryRefinementResult(BaseModel):
    """Result of query refinement."""
    
    intent: SimulationIntent
    confidence: float
    extracted_entities: ExtractedEntities
    missing_parameters: List[str]
    clarification_questions: List[ClarificationQuestion]
    default_assumptions: Dict[str, Any]


class DataRequirement(BaseModel):
    """A data requirement for simulation."""
    
    name: str
    data_type: str  # cached, sql, kpi, calendar
    params: Dict[str, Any] = Field(default_factory=dict)
    query: Optional[str] = None


class ExecutionStep(BaseModel):
    """A step in the execution plan."""
    
    step: int
    action: str  # fetch_data, run_model, analyze
    target: Union[str, List[str]]
    depends_on: List[int] = Field(default_factory=list)


class ExecutionPlan(BaseModel):
    """Simulation execution plan."""
    
    data_requirements: List[DataRequirement]
    models_needed: List[str]
    execution_sequence: List[ExecutionStep]
    dependencies: Dict[str, List[str]]


class WeeklyPlanEntry(BaseModel):
    """A single week in the execution plan."""
    
    week_number: int
    start_date: date
    end_date: date
    sites_ready_at_start: int
    crew_capacity: int
    sites_planned: int
    sites_completed: int
    sites_remaining: int
    crew_utilization: float
    blockers: List[str] = Field(default_factory=list)
    fast_track_actions: List[str] = Field(default_factory=list)


class FeasibilityAssessment(BaseModel):
    """Feasibility assessment result."""
    
    achievable: bool
    confidence: float  # 0.0 - 1.0
    target: int
    achievable_count: int
    gap: int
    primary_bottleneck: str
    constraints: List[str]


class RiskEntry(BaseModel):
    """A risk identified in analysis."""
    
    risk: str
    category: str
    probability: str  # LOW, MEDIUM, HIGH
    impact: str  # LOW, MEDIUM, HIGH
    mitigation: str


class SimulationOutput(BaseModel):
    """Complete simulation output."""
    
    # Status
    status: SimulationStatus
    session_id: str
    
    # Query understanding
    intent: SimulationIntent
    parameters: Dict[str, Any]
    
    # Results
    feasibility: FeasibilityAssessment
    weekly_plan: List[WeeklyPlanEntry]
    
    # Analysis
    risks: List[RiskEntry]
    recommendations: List[str]
    
    # Metadata
    execution_trace: List[Dict[str, Any]]
    duration_ms: int
    completed_at: datetime


class StreamingEvent(BaseModel):
    """Event for SSE streaming."""
    
    event_type: str
    data: Dict[str, Any]
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    sequence: int = 0