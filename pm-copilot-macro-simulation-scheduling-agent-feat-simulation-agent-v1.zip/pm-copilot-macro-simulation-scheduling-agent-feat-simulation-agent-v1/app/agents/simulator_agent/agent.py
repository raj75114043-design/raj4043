"""
Simulator Agent
Main LangGraph-based agent for simulation scenarios
"""

from datetime import datetime
from typing import Any, AsyncGenerator, Dict, List, Optional

import structlog
from langgraph.graph import END, StateGraph
from langgraph.graph.graph import CompiledGraph

from app.agents.simulator_agent.state import SimulatorState, create_initial_state
from app.agents.simulator_agent.nodes.orchestrator import orchestrator_node, route_orchestrator
from app.agents.simulator_agent.nodes.query_refiner import query_refiner_node
from app.agents.simulator_agent.nodes.planner import planner_node
from app.agents.simulator_agent.nodes.data_collector import data_collector_node
from app.agents.simulator_agent.nodes.simulator import simulator_node
from app.agents.simulator_agent.nodes.analyzer import analyzer_node
from app.agents.simulator_agent.nodes.output_generator import output_generator_node
from app.agents.shared.checkpointer import get_checkpointer
from app.core.models import (
    SimulationResult,
    SimulationStatus,
    ProjectTrack,
    ClarificationQuestion,
)

logger = structlog.get_logger(__name__)


def build_simulator_graph() -> CompiledGraph:
    """
    Build the simulator agent graph.
    
    Graph Structure:
    start -> orchestrator -> [query_refiner | planner | data_collector | simulator | analyzer | output_generator | end]
    
    The orchestrator routes to the appropriate node based on current state.
    """
    # Create graph with state schema
    graph = StateGraph(SimulatorState)
    
    # Add nodes
    graph.add_node("orchestrator", orchestrator_node)
    graph.add_node("query_refiner", query_refiner_node)
    graph.add_node("planner", planner_node)
    graph.add_node("data_collector", data_collector_node)
    graph.add_node("simulator", simulator_node)
    graph.add_node("analyzer", analyzer_node)
    graph.add_node("output_generator", output_generator_node)
    
    # Add HITL wait node (returns state unchanged, waits for user input)
    graph.add_node("hitl_wait", lambda state: state)
    
    # Set entry point
    graph.set_entry_point("orchestrator")
    
    # Add conditional edges from orchestrator
    graph.add_conditional_edges(
        "orchestrator",
        route_orchestrator,
        {
            "query_refiner": "query_refiner",
            "planner": "planner",
            "data_collector": "data_collector",
            "simulator": "simulator",
            "analyzer": "analyzer",
            "output_generator": "output_generator",
            "hitl_wait": "hitl_wait",
            "end": END,
        },
    )
    
    # Add edges from each node back to orchestrator
    graph.add_edge("query_refiner", "orchestrator")
    graph.add_edge("planner", "orchestrator")
    graph.add_edge("data_collector", "orchestrator")
    graph.add_edge("simulator", "orchestrator")
    graph.add_edge("analyzer", "orchestrator")
    graph.add_edge("output_generator", END)
    graph.add_edge("hitl_wait", END)  # HITL wait ends the graph for user input
    
    # Compile with checkpointer
    checkpointer = get_checkpointer()
    compiled = graph.compile(checkpointer=checkpointer)
    
    return compiled


# Global compiled graph
simulator_graph = build_simulator_graph()


async def run_simulator(
    query: str,
    session_id: str,
    project_track: ProjectTrack = ProjectTrack.TMO_RPM,
    user_id: Optional[str] = None,
    parameters: Optional[Dict[str, Any]] = None,
) -> SimulationResult:
    """
    Run a simulation for the given query.
    
    Args:
        query: Natural language simulation query
        session_id: Unique session identifier
        project_track: Project track context
        user_id: Optional user identifier
        parameters: Optional pre-extracted parameters
        
    Returns:
        SimulationResult with results or clarification request
    """
    logger.info(
        "Starting simulation",
        session_id=session_id,
        query=query[:100],
        project_track=project_track,
    )
    
    # Create initial state
    initial_state = create_initial_state(
        query=query,
        session_id=session_id,
        project_track=project_track,
        user_id=user_id,
        parameters=parameters,
    )
    
    # Run the graph
    config = {"configurable": {"thread_id": session_id}}
    
    try:
        final_state = await simulator_graph.ainvoke(initial_state, config)
        
        # Build result from final state
        result = _build_result(final_state)
        
        logger.info(
            "Simulation completed",
            session_id=session_id,
            status=result.status,
        )
        
        return result
        
    except Exception as e:
        logger.error("Simulation failed", error=str(e), session_id=session_id)
        return SimulationResult(
            scenario_id=session_id,
            status=SimulationStatus.FAILED,
            parameters={},
            execution_trace=[{"error": str(e)}],
        )


async def continue_simulation(
    session_id: str,
    confirmed_answers: Dict[str, Any],
) -> SimulationResult:
    """
    Continue a simulation after HITL confirmation.
    
    Args:
        session_id: Session to continue
        confirmed_answers: User-confirmed parameters
        
    Returns:
        SimulationResult
    """
    logger.info(
        "Continuing simulation after HITL",
        session_id=session_id,
    )
    
    config = {"configurable": {"thread_id": session_id}}
    
    # Get current state from checkpointer
    state = await simulator_graph.aget_state(config)
    
    if not state or not state.values:
        raise ValueError(f"No state found for session: {session_id}")
    
    # Update state with confirmed answers
    current_state = state.values
    current_state["user_confirmed"] = True
    current_state["confirmed_answers"] = confirmed_answers
    current_state["status"] = SimulationStatus.CONFIRMED
    
    # Continue execution
    final_state = await simulator_graph.ainvoke(current_state, config)
    
    return _build_result(final_state)


async def stream_simulator(
    query: str,
    session_id: str,
    project_track: ProjectTrack = ProjectTrack.TMO_RPM,
    history: Optional[List[Dict[str, str]]] = None,
) -> AsyncGenerator[Dict[str, Any], None]:
    """
    Stream simulation execution events.
    
    Yields events for each step of the simulation process.
    """
    logger.info(
        "Starting streaming simulation",
        session_id=session_id,
    )
    
    initial_state = create_initial_state(
        query=query,
        session_id=session_id,
        project_track=project_track,
    )
    
    config = {"configurable": {"thread_id": session_id}}
    
    try:
        async for event in simulator_graph.astream(initial_state, config):
            # Extract node name and state
            for node_name, node_output in event.items():
                if node_name == "__end__":
                    continue
                
                # Emit node event
                yield {
                    "type": "node_execution",
                    "node": node_name,
                    "status": node_output.get("status", ""),
                }
                
                # Check for clarification
                if node_output.get("clarification_needed"):
                    yield {
                        "type": "clarification",
                        "questions": [
                            q.dict() if hasattr(q, "dict") else q
                            for q in node_output.get("clarification_questions", [])
                        ],
                        "context": node_output.get("extracted_entities", {}),
                    }
                
                # Check for simulation progress
                if node_name == "simulator":
                    yield {
                        "type": "simulation_start",
                        "models": node_output.get("models_needed", []),
                        "parameters": node_output.get("parameters", {}),
                    }
                
                # Check for completion
                if node_output.get("final_output"):
                    yield {
                        "type": "result",
                        "data": node_output["final_output"],
                    }
        
        # Final message
        yield {"type": "message", "content": "Simulation completed."}
        
    except Exception as e:
        logger.error("Streaming error", error=str(e))
        yield {"type": "error", "message": str(e)}


def _build_result(state: Dict[str, Any]) -> SimulationResult:
    """Build SimulationResult from final state."""
    status = state.get("status", SimulationStatus.FAILED)
    
    # Handle clarification case
    if status == SimulationStatus.PENDING_CLARIFICATION:
        return SimulationResult(
            scenario_id=state.get("session_id", ""),
            status=status,
            parameters=state.get("parameters") or {},
            clarification_questions=[
                q if isinstance(q, ClarificationQuestion) else ClarificationQuestion(**q)
                for q in state.get("clarification_questions", [])
            ],
            execution_trace=state.get("execution_trace", []),
        )
    
    # Build full result
    final_output = state.get("final_output", {})
    analysis = state.get("analysis_results", {})
    
    return SimulationResult(
        scenario_id=state.get("session_id", ""),
        status=status,
        parameters=state.get("parameters") or {},
        weekly_plan=final_output.get("weekly_plan", []),
        feasibility=final_output.get("status", {}),
        risks=final_output.get("risk_matrix", []),
        recommendations=[a["action"] for a in final_output.get("action_plan", [])],
        confidence_level=analysis.get("key_metrics", {}).get("confidence", 0),
        execution_trace=state.get("execution_trace", []),
    )