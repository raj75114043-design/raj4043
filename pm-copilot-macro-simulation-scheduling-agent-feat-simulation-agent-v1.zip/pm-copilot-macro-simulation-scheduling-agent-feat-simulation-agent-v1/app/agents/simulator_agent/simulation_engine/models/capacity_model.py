"""
Capacity Model
Deterministic model for crew utilization and vendor capacity
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class VendorCapacity:
    """Vendor capacity data."""
    name: str
    total_crews: int
    available_crews: int
    sites_assigned: int
    productivity_rate: float = 1.0


@dataclass
class CapacityParams:
    """Parameters for capacity simulation."""
    total_crews: int
    available_crews: int
    crew_productivity: float = 1.0  # sites per crew per day
    working_days_per_week: int = 5
    vendors: List[Dict[str, Any]] = field(default_factory=list)


class CapacityModel:
    """
    Capacity simulation model.
    
    Calculates crew utilization and capacity constraints:
    - Weekly capacity = crews × days × productivity
    - Vendor-level capacity breakdown
    - Utilization rates
    """
    
    def calculate(self, params: CapacityParams) -> Dict[str, Any]:
        """
        Calculate capacity metrics.
        
        Args:
            params: Capacity parameters
            
        Returns:
            Capacity analysis results
        """
        # Calculate overall capacity
        daily_capacity = params.available_crews * params.crew_productivity
        weekly_capacity = int(daily_capacity * params.working_days_per_week)
        
        # Calculate utilization
        utilization = (
            params.available_crews / params.total_crews
            if params.total_crews > 0
            else 0
        )
        
        # Parse vendor capacities
        vendor_breakdown = []
        total_vendor_capacity = 0
        
        for vendor_data in params.vendors:
            vendor = VendorCapacity(
                name=vendor_data.get("name", "Unknown"),
                total_crews=vendor_data.get("total_crews", 0),
                available_crews=vendor_data.get("available_crews", 0),
                sites_assigned=vendor_data.get("sites_assigned", 0),
                productivity_rate=vendor_data.get("productivity_rate", params.crew_productivity),
            )
            
            vendor_weekly = int(
                vendor.available_crews * 
                vendor.productivity_rate * 
                params.working_days_per_week
            )
            
            vendor_utilization = (
                vendor.available_crews / vendor.total_crews
                if vendor.total_crews > 0
                else 0
            )
            
            vendor_breakdown.append({
                "name": vendor.name,
                "total_crews": vendor.total_crews,
                "available_crews": vendor.available_crews,
                "sites_assigned": vendor.sites_assigned,
                "weekly_capacity": vendor_weekly,
                "utilization": round(vendor_utilization, 2),
            })
            
            total_vendor_capacity += vendor_weekly
        
        # Identify capacity constraints
        constraints = self._identify_constraints(
            params.total_crews,
            params.available_crews,
            utilization,
            vendor_breakdown,
        )
        
        return {
            "total_crews": params.total_crews,
            "available_crews": params.available_crews,
            "crew_productivity": params.crew_productivity,
            "daily_capacity": int(daily_capacity),
            "weekly_capacity": weekly_capacity,
            "utilization": round(utilization, 2),
            "vendor_breakdown": vendor_breakdown,
            "total_vendor_capacity": total_vendor_capacity,
            "constraints": constraints,
        }
    
    def _identify_constraints(
        self,
        total_crews: int,
        available_crews: int,
        utilization: float,
        vendor_breakdown: List[Dict[str, Any]],
    ) -> List[str]:
        """Identify capacity constraints."""
        constraints = []
        
        if available_crews == 0:
            constraints.append("No crews available")
        elif utilization < 0.5:
            constraints.append(f"Low crew utilization ({int(utilization*100)}%)")
        
        # Check for vendor imbalances
        if vendor_breakdown:
            utilizations = [v["utilization"] for v in vendor_breakdown]
            if max(utilizations) - min(utilizations) > 0.3:
                constraints.append("Uneven vendor utilization")
            
            # Check for overloaded vendors
            for vendor in vendor_breakdown:
                if vendor["utilization"] > 0.95:
                    constraints.append(f"Vendor {vendor['name']} at capacity")
        
        return constraints
    
    def calculate_required_crews(
        self,
        target_sites: int,
        weeks: int,
        productivity: float = 1.0,
        working_days: int = 5,
    ) -> Dict[str, Any]:
        """
        Calculate crews required to meet a target.
        
        Args:
            target_sites: Sites to complete
            weeks: Weeks available
            productivity: Sites per crew per day
            working_days: Working days per week
            
        Returns:
            Required crew calculation
        """
        sites_per_week_per_crew = productivity * working_days
        total_crew_weeks_needed = target_sites / sites_per_week_per_crew
        crews_needed = total_crew_weeks_needed / weeks
        
        return {
            "target_sites": target_sites,
            "weeks": weeks,
            "sites_per_week_per_crew": sites_per_week_per_crew,
            "crews_needed": int(crews_needed) + 1,  # Round up
            "weekly_capacity_needed": int(target_sites / weeks) + 1,
        }