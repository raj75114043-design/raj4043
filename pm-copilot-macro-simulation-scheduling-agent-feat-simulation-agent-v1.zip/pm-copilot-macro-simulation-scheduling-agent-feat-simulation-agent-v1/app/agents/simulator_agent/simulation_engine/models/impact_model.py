"""
Impact Model
What-if analysis and sensitivity calculations
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class ImpactParams:
    """Parameters for impact analysis."""
    baseline: Dict[str, Any]
    change_type: str  # crews, material_tat, working_days, etc.
    change_amount: float  # Absolute or percentage change
    affected_scope: str = "all"  # all, market, vendor
    is_percentage: bool = False


class ImpactModel:
    """
    Impact simulation model.
    
    Calculates the effect of changes on outcomes:
    - What-if scenarios
    - Sensitivity analysis
    - Delta calculations
    """
    
    # Impact multipliers for different change types
    IMPACT_MULTIPLIERS = {
        "crews": 1.0,  # Direct linear impact
        "crew_productivity": 1.0,
        "working_days": 0.8,  # Slightly less than linear
        "material_tat": -0.5,  # Negative impact
        "power_lead_time": -0.3,
        "fiber_lead_time": -0.3,
        "vendor_count": 0.7,
    }
    
    def calculate(self, params: ImpactParams) -> Dict[str, Any]:
        """
        Calculate impact of a change.
        
        Args:
            params: Impact parameters
            
        Returns:
            Impact analysis results
        """
        baseline = params.baseline
        
        # Get baseline metrics
        baseline_capacity = baseline.get("weekly_capacity", 0)
        baseline_sites = baseline.get("achievable_sites", 0)
        baseline_weeks = baseline.get("weeks_required", 0)
        
        # Calculate change effect
        multiplier = self.IMPACT_MULTIPLIERS.get(params.change_type, 0.5)
        
        if params.is_percentage:
            change_factor = 1 + (params.change_amount / 100 * multiplier)
        else:
            # Absolute change - convert to relative
            baseline_value = self._get_baseline_value(baseline, params.change_type)
            if baseline_value > 0:
                relative_change = params.change_amount / baseline_value
                change_factor = 1 + (relative_change * multiplier)
            else:
                change_factor = 1 + (params.change_amount * multiplier * 0.1)
        
        # Apply change to metrics
        new_capacity = int(baseline_capacity * change_factor)
        new_sites = int(baseline_sites * change_factor)
        
        # Weeks change inversely with capacity
        if change_factor > 0:
            new_weeks = int(baseline_weeks / change_factor)
        else:
            new_weeks = baseline_weeks * 2
        
        # Calculate deltas
        capacity_delta = new_capacity - baseline_capacity
        sites_delta = new_sites - baseline_sites
        weeks_delta = new_weeks - baseline_weeks
        
        return {
            "change_type": params.change_type,
            "change_amount": params.change_amount,
            "is_percentage": params.is_percentage,
            "affected_scope": params.affected_scope,
            "baseline": {
                "weekly_capacity": baseline_capacity,
                "achievable_sites": baseline_sites,
                "weeks_required": baseline_weeks,
            },
            "after_change": {
                "weekly_capacity": new_capacity,
                "achievable_sites": new_sites,
                "weeks_required": max(1, new_weeks),
            },
            "delta": {
                "weekly_capacity": capacity_delta,
                "achievable_sites": sites_delta,
                "weeks_required": weeks_delta,
            },
            "impact_summary": self._summarize_impact(
                params.change_type,
                params.change_amount,
                sites_delta,
                weeks_delta,
            ),
        }
    
    def sensitivity_analysis(
        self,
        baseline: Dict[str, Any],
        variables: list[str],
        range_pct: float = 20,
    ) -> Dict[str, Any]:
        """
        Perform sensitivity analysis on multiple variables.
        
        Args:
            baseline: Baseline metrics
            variables: Variables to analyze
            range_pct: Percentage range to test (+/-)
            
        Returns:
            Sensitivity analysis results
        """
        results = {}
        
        for variable in variables:
            # Test +range%
            params_plus = ImpactParams(
                baseline=baseline,
                change_type=variable,
                change_amount=range_pct,
                is_percentage=True,
            )
            impact_plus = self.calculate(params_plus)
            
            # Test -range%
            params_minus = ImpactParams(
                baseline=baseline,
                change_type=variable,
                change_amount=-range_pct,
                is_percentage=True,
            )
            impact_minus = self.calculate(params_minus)
            
            # Calculate sensitivity
            sites_range = (
                impact_plus["after_change"]["achievable_sites"] -
                impact_minus["after_change"]["achievable_sites"]
            )
            
            results[variable] = {
                "increase_impact": impact_plus["delta"]["achievable_sites"],
                "decrease_impact": impact_minus["delta"]["achievable_sites"],
                "sensitivity_range": sites_range,
                "sensitivity_rank": abs(sites_range),
            }
        
        # Rank by sensitivity
        ranked = sorted(
            results.items(),
            key=lambda x: x[1]["sensitivity_rank"],
            reverse=True,
        )
        
        return {
            "variables_analyzed": len(variables),
            "range_tested": f"+/- {range_pct}%",
            "results": results,
            "ranked_sensitivity": [
                {"variable": var, **data}
                for var, data in ranked
            ],
            "most_sensitive": ranked[0][0] if ranked else None,
        }
    
    def _get_baseline_value(
        self,
        baseline: Dict[str, Any],
        change_type: str,
    ) -> float:
        """Get the baseline value for a change type."""
        mapping = {
            "crews": baseline.get("available_crews", 10),
            "crew_productivity": baseline.get("crew_productivity", 1.0),
            "working_days": baseline.get("working_days_per_week", 5),
            "material_tat": baseline.get("material_lead_time", 10),
            "power_lead_time": baseline.get("power_lead_time", 14),
            "fiber_lead_time": baseline.get("fiber_lead_time", 21),
            "vendor_count": baseline.get("vendor_count", 3),
        }
        return mapping.get(change_type, 1)
    
    def _summarize_impact(
        self,
        change_type: str,
        change_amount: float,
        sites_delta: int,
        weeks_delta: int,
    ) -> str:
        """Generate impact summary."""
        direction = "increase" if change_amount > 0 else "decrease"
        
        if sites_delta > 0:
            return f"A {abs(change_amount)} {direction} in {change_type} would enable {abs(sites_delta)} more sites"
        elif sites_delta < 0:
            return f"A {abs(change_amount)} {direction} in {change_type} would reduce capacity by {abs(sites_delta)} sites"
        else:
            return f"A {abs(change_amount)} {direction} in {change_type} has minimal impact"