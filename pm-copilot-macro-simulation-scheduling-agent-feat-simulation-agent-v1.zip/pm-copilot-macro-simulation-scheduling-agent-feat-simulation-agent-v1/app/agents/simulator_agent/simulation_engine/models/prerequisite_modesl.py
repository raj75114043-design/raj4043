"""
Prerequisite Model
Deterministic model for lead time calculation and dependency chains
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass
class PrerequisiteParams:
    """Parameters for prerequisite simulation."""
    total_sites: int
    prerequisites: Dict[str, int]  # {prereq_type: ready_count}
    lead_times: Dict[str, int]  # {prereq_type: avg_days}
    pipeline: Dict[str, int] = field(default_factory=dict)  # {prereq_type: in_progress_count}


class PrerequisiteModel:
    """
    Prerequisite simulation model.
    
    Calculates:
    - Sites ready to start (all prerequisites met)
    - Prerequisite bottlenecks
    - Lead time projections
    - Weekly pipeline of sites becoming ready
    """
    
    # Prerequisite types in dependency order
    PREREQ_ORDER = [
        "permits",
        "power",
        "fiber",
        "material",
        "site_access",
        "intp",
    ]
    
    def calculate(self, params: PrerequisiteParams) -> Dict[str, Any]:
        """
        Calculate prerequisite readiness.
        
        Args:
            params: Prerequisite parameters
            
        Returns:
            Prerequisite analysis results
        """
        # Calculate sites ready (all prerequisites met)
        # A site is ready only if ALL prerequisites are met
        prereq_counts = params.prerequisites
        
        # Find the minimum across all prerequisites
        min_ready = min(prereq_counts.values()) if prereq_counts else 0
        
        # Calculate per-prerequisite status
        prereq_status = []
        bottleneck = None
        bottleneck_gap = 0
        
        for prereq_type in self.PREREQ_ORDER:
            ready = prereq_counts.get(prereq_type, 0)
            blocked = params.total_sites - ready
            lead_time = params.lead_times.get(prereq_type, 7)
            in_progress = params.pipeline.get(prereq_type, 0)
            
            prereq_status.append({
                "type": prereq_type,
                "ready": ready,
                "blocked": blocked,
                "in_progress": in_progress,
                "lead_time_days": lead_time,
                "pct_ready": round(ready / params.total_sites * 100, 1) if params.total_sites > 0 else 0,
            })
            
            # Track bottleneck (highest number of blocked sites)
            if blocked > bottleneck_gap:
                bottleneck_gap = blocked
                bottleneck = prereq_type
        
        # Calculate weekly pipeline (sites becoming ready per week)
        weekly_pipeline = self._calculate_pipeline(
            prereq_status,
            params.lead_times,
            params.pipeline,
            weeks=8,
        )
        
        # Calculate expected ready date for all sites
        weeks_to_all_ready = self._estimate_weeks_to_ready(
            prereq_status,
            params.lead_times,
        )
        
        return {
            "total_sites": params.total_sites,
            "sites_ready_to_start": min_ready,
            "sites_blocked": params.total_sites - min_ready,
            "bottleneck": bottleneck or "None",
            "bottleneck_gap": bottleneck_gap,
            "prereq_status": prereq_status,
            "weekly_pipeline": weekly_pipeline,
            "weeks_to_all_ready": weeks_to_all_ready,
        }
    
    def _calculate_pipeline(
        self,
        prereq_status: List[Dict[str, Any]],
        lead_times: Dict[str, int],
        pipeline: Dict[str, int],
        weeks: int = 8,
    ) -> List[Dict[str, Any]]:
        """Calculate weekly pipeline of sites becoming ready."""
        weekly = []
        
        for week in range(1, weeks + 1):
            # Estimate sites becoming ready this week
            # Based on lead times and in-progress counts
            becoming_ready = 0
            
            for prereq in prereq_status:
                prereq_type = prereq["type"]
                lead_time_weeks = lead_times.get(prereq_type, 7) / 7
                in_progress = pipeline.get(prereq_type, prereq["blocked"] // weeks)
                
                # Distribute in-progress over lead time
                if lead_time_weeks > 0 and week >= lead_time_weeks:
                    weekly_rate = in_progress / lead_time_weeks
                    becoming_ready += int(weekly_rate)
            
            weekly.append({
                "week": week,
                "becoming_ready": becoming_ready,
                "cumulative": sum(w.get("becoming_ready", 0) for w in weekly) + becoming_ready,
            })
        
        return weekly
    
    def _estimate_weeks_to_ready(
        self,
        prereq_status: List[Dict[str, Any]],
        lead_times: Dict[str, int],
    ) -> int:
        """Estimate weeks until all sites are ready."""
        max_weeks = 0
        
        for prereq in prereq_status:
            blocked = prereq["blocked"]
            lead_time = lead_times.get(prereq["type"], 7)
            
            if blocked > 0:
                # Assume average processing rate
                weeks_needed = (lead_time / 7) + (blocked / 10)  # Simplified estimate
                max_weeks = max(max_weeks, int(weeks_needed))
        
        return max_weeks