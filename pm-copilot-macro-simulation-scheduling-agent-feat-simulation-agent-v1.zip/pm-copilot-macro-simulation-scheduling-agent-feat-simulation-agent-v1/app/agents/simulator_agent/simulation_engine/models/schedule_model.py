"""
Schedule Model
Deterministic model for weekly/daily rollout planning
"""

from dataclasses import dataclass
from datetime import date, timedelta
from typing import Any, Dict, List, Optional


@dataclass
class ScheduleParams:
    """Parameters for schedule simulation."""
    target_sites: int
    ready_to_start: int
    weekly_capacity: int
    start_date: date
    end_date: date
    working_days_per_week: int = 5
    max_weeks: int = 52
    prereq_pipeline: List[Dict[str, Any]] = None
    
    def __post_init__(self):
        if self.prereq_pipeline is None:
            self.prereq_pipeline = []


@dataclass
class WeekResult:
    """Result for a single week."""
    week_number: int
    start_date: date
    end_date: date
    ready_at_start: int
    capacity: int
    planned: int
    completed: int
    remaining: int
    crew_utilization: float
    cumulative_completed: int
    fast_track_actions: List[str]


class ScheduleModel:
    """
    Schedule simulation model.
    
    Calculates week-by-week site completion based on:
    - Ready sites (prerequisites met)
    - Crew capacity
    - Working days
    - Prerequisite pipeline
    """
    
    def simulate(self, params: ScheduleParams) -> Dict[str, Any]:
        """
        Run schedule simulation.
        
        Args:
            params: Schedule parameters
            
        Returns:
            Simulation results with weekly plan
        """
        weeks: List[WeekResult] = []
        remaining = params.target_sites
        current_ready = params.ready_to_start
        cumulative_completed = 0
        current_date = params.start_date
        
        # Calculate number of weeks
        total_days = (params.end_date - params.start_date).days
        num_weeks = min(total_days // 7 + 1, params.max_weeks)
        
        for week_num in range(1, num_weeks + 1):
            week_start = current_date
            week_end = current_date + timedelta(days=6)
            
            # Get additional sites becoming ready this week from pipeline
            pipeline_ready = 0
            if params.prereq_pipeline and week_num <= len(params.prereq_pipeline):
                pipeline_ready = params.prereq_pipeline[week_num - 1].get("becoming_ready", 0)
            
            current_ready += pipeline_ready
            
            # Can only complete sites that are ready, up to capacity
            completable = min(current_ready, params.weekly_capacity, remaining)
            
            # Calculate utilization
            utilization = completable / params.weekly_capacity if params.weekly_capacity > 0 else 0
            
            # Determine fast-track actions if underutilized
            fast_track_actions = []
            if utilization < 0.8 and remaining > completable:
                fast_track_actions = self._suggest_fast_track_actions(
                    current_ready, params.weekly_capacity, remaining
                )
            
            # Update counters
            remaining -= completable
            current_ready -= completable
            cumulative_completed += completable
            
            weeks.append(WeekResult(
                week_number=week_num,
                start_date=week_start,
                end_date=week_end,
                ready_at_start=current_ready + completable,
                capacity=params.weekly_capacity,
                planned=completable,
                completed=completable,
                remaining=remaining,
                crew_utilization=utilization,
                cumulative_completed=cumulative_completed,
                fast_track_actions=fast_track_actions,
            ))
            
            current_date = week_end + timedelta(days=1)
            
            # Stop if all sites completed
            if remaining <= 0:
                break
        
        # Calculate summary
        total_achievable = cumulative_completed
        target_achievable = total_achievable >= params.target_sites
        gap = params.target_sites - total_achievable
        
        # Determine bottleneck
        bottleneck = self._identify_bottleneck(
            params.ready_to_start,
            params.weekly_capacity,
            params.target_sites,
            num_weeks,
        )
        
        # Calculate confidence (simplified)
        confidence = self._calculate_confidence(
            target_achievable, gap, params.target_sites
        )
        
        return {
            "target": params.target_sites,
            "total_achievable": total_achievable,
            "target_achievable": target_achievable,
            "gap": max(0, gap),
            "weeks_required": len(weeks),
            "bottleneck": bottleneck,
            "confidence": confidence,
            "weekly_plan": [
                {
                    "week_number": w.week_number,
                    "start_date": w.start_date.isoformat(),
                    "end_date": w.end_date.isoformat(),
                    "ready_at_start": w.ready_at_start,
                    "capacity": w.capacity,
                    "planned": w.planned,
                    "completed": w.completed,
                    "remaining": w.remaining,
                    "crew_utilization": round(w.crew_utilization, 2),
                    "cumulative_completed": w.cumulative_completed,
                    "fast_track_actions": w.fast_track_actions,
                }
                for w in weeks
            ],
        }
    
    def _identify_bottleneck(
        self,
        ready_sites: int,
        weekly_capacity: int,
        target: int,
        weeks: int,
    ) -> str:
        """Identify the primary bottleneck."""
        total_capacity = weekly_capacity * weeks
        
        if ready_sites == 0:
            return "Prerequisites (0 sites ready)"
        elif ready_sites < target * 0.2:
            return f"Prerequisites ({ready_sites} ready, need {target})"
        elif total_capacity < target:
            return f"Crew capacity ({total_capacity} max vs {target} target)"
        else:
            return "None identified"
    
    def _calculate_confidence(
        self,
        achievable: bool,
        gap: int,
        target: int,
    ) -> float:
        """Calculate confidence level."""
        if achievable:
            return 0.85  # High confidence if achievable
        else:
            # Lower confidence based on gap percentage
            gap_pct = gap / target if target > 0 else 1
            return max(0.1, 0.8 - gap_pct)
    
    def _suggest_fast_track_actions(
        self,
        ready_sites: int,
        capacity: int,
        remaining: int,
    ) -> List[str]:
        """Suggest actions to fast-track sites."""
        actions = []
        
        if ready_sites < capacity:
            actions.append(f"Expedite prerequisites for {capacity - ready_sites} sites")
        
        if remaining > capacity * 4:
            actions.append("Consider adding crews to increase capacity")
        
        return actions