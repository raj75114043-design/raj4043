"""
Risk Model
Monte Carlo simulation and scenario comparison
"""

import random
from dataclasses import dataclass
from typing import Any, Dict, List


@dataclass
class RiskParams:
    """Parameters for risk simulation."""
    target_sites: int
    achievable_sites: int
    ready_sites: int
    prereq_bottleneck: str
    historical_variance: float = 0.15  # Standard deviation
    num_simulations: int = 1000


class RiskModel:
    """
    Risk simulation model.
    
    Performs Monte Carlo simulation to assess:
    - Probability of meeting target
    - Confidence intervals
    - Risk identification and categorization
    """
    
    def monte_carlo(self, params: RiskParams) -> Dict[str, Any]:
        """
        Run Monte Carlo simulation for risk assessment.
        
        Args:
            params: Risk parameters
            
        Returns:
            Risk analysis results
        """
        # Run simulations
        results = []
        for _ in range(params.num_simulations):
            # Apply random variance to achievable sites
            variance = random.gauss(0, params.historical_variance)
            simulated = int(params.achievable_sites * (1 + variance))
            simulated = max(0, simulated)  # Can't be negative
            results.append(simulated)
        
        # Calculate statistics
        results.sort()
        mean_result = sum(results) / len(results)
        
        # Percentiles
        p10 = results[int(len(results) * 0.10)]
        p50 = results[int(len(results) * 0.50)]
        p90 = results[int(len(results) * 0.90)]
        
        # Success probability
        successes = sum(1 for r in results if r >= params.target_sites)
        success_probability = successes / len(results)
        
        # Identify risks
        risks = self._identify_risks(params, success_probability)
        
        # Determine confidence level
        confidence = self._calculate_confidence(success_probability)
        
        return {
            "target": params.target_sites,
            "mean_outcome": int(mean_result),
            "p10": p10,
            "p50": p50,
            "p90": p90,
            "success_probability": round(success_probability, 2),
            "confidence_level": confidence,
            "simulations_run": params.num_simulations,
            "risks": risks,
            "summary": self._generate_summary(
                params.target_sites, success_probability, confidence, risks
            ),
        }
    
    def _identify_risks(
        self,
        params: RiskParams,
        success_prob: float,
    ) -> List[Dict[str, Any]]:
        """Identify and categorize risks."""
        risks = []
        
        # Gap risk
        gap = params.target_sites - params.achievable_sites
        if gap > 0:
            gap_pct = gap / params.target_sites if params.target_sites > 0 else 0
            risks.append({
                "risk": f"Target gap of {gap} sites ({int(gap_pct*100)}%)",
                "category": "Schedule",
                "probability": "HIGH" if gap_pct > 0.3 else "MEDIUM" if gap_pct > 0.1 else "LOW",
                "impact": "HIGH",
                "mitigation": "Add crews, expedite prerequisites, extend timeline",
            })
        
        # Prerequisite risk
        if params.ready_sites < params.target_sites * 0.5:
            risks.append({
                "risk": f"Low prerequisite readiness ({params.ready_sites} ready vs {params.target_sites} target)",
                "category": "Prerequisite",
                "probability": "HIGH",
                "impact": "HIGH",
                "mitigation": f"Focus on {params.prereq_bottleneck} bottleneck",
            })
        
        # Success probability risk
        if success_prob < 0.5:
            risks.append({
                "risk": f"Low success probability ({int(success_prob*100)}%)",
                "category": "Schedule",
                "probability": "HIGH",
                "impact": "HIGH",
                "mitigation": "Revise target or add resources",
            })
        elif success_prob < 0.8:
            risks.append({
                "risk": f"Moderate success probability ({int(success_prob*100)}%)",
                "category": "Schedule",
                "probability": "MEDIUM",
                "impact": "MEDIUM",
                "mitigation": "Monitor closely, prepare contingency",
            })
        
        # Variance risk
        if params.historical_variance > 0.2:
            risks.append({
                "risk": "High historical variance in execution",
                "category": "Execution",
                "probability": "MEDIUM",
                "impact": "MEDIUM",
                "mitigation": "Improve process standardization",
            })
        
        return risks
    
    def _calculate_confidence(self, success_prob: float) -> str:
        """Determine confidence level label."""
        if success_prob >= 0.9:
            return "HIGH"
        elif success_prob >= 0.7:
            return "MEDIUM"
        elif success_prob >= 0.5:
            return "LOW"
        else:
            return "VERY LOW"
    
    def _generate_summary(
        self,
        target: int,
        success_prob: float,
        confidence: str,
        risks: List[Dict[str, Any]],
    ) -> str:
        """Generate risk summary."""
        if success_prob >= 0.9:
            return f"Target of {target} sites is achievable with {confidence} confidence."
        elif success_prob >= 0.7:
            return f"Target of {target} sites is likely achievable ({int(success_prob*100)}% probability). Monitor {len(risks)} identified risks."
        elif success_prob >= 0.5:
            return f"Target of {target} sites is at risk ({int(success_prob*100)}% probability). {len(risks)} risks require mitigation."
        else:
            return f"Target of {target} sites is unlikely to be met ({int(success_prob*100)}% probability). Recommend revising target or adding significant resources."
    
    def compare_scenarios(
        self,
        scenarios: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """
        Compare multiple scenarios.
        
        Args:
            scenarios: List of scenario results
            
        Returns:
            Comparison analysis
        """
        comparison = {
            "scenarios": [],
            "best_scenario": None,
            "recommendation": "",
        }
        
        best_prob = 0
        best_idx = 0
        
        for idx, scenario in enumerate(scenarios):
            prob = scenario.get("success_probability", 0)
            comparison["scenarios"].append({
                "name": scenario.get("name", f"Scenario {idx+1}"),
                "success_probability": prob,
                "mean_outcome": scenario.get("mean_outcome", 0),
                "risks": len(scenario.get("risks", [])),
            })
            
            if prob > best_prob:
                best_prob = prob
                best_idx = idx
        
        comparison["best_scenario"] = comparison["scenarios"][best_idx]["name"]
        comparison["recommendation"] = f"Recommend {comparison['best_scenario']} with {int(best_prob*100)}% success probability"
        
        return comparison