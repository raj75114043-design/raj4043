"""
Calendar Model
Working days, holidays, and weather window calculations
"""

from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Any, Dict, List, Optional


@dataclass
class CalendarParams:
    """Parameters for calendar calculations."""
    start_date: date
    end_date: date
    working_days_per_week: int = 5
    holidays: List[date] = field(default_factory=list)
    market: Optional[str] = None
    weather_impact_days: int = 0


class CalendarModel:
    """
    Calendar simulation model.
    
    Calculates:
    - Working days in a period
    - Holiday impact
    - Weather window adjustments
    - Weekly breakdowns
    """
    
    # Default US holidays (simplified)
    US_HOLIDAYS_2025 = [
        date(2025, 1, 1),   # New Year
        date(2025, 1, 20),  # MLK Day
        date(2025, 2, 17),  # Presidents Day
        date(2025, 5, 26),  # Memorial Day
        date(2025, 7, 4),   # Independence Day
        date(2025, 9, 1),   # Labor Day
        date(2025, 11, 27), # Thanksgiving
        date(2025, 12, 25), # Christmas
    ]
    
    US_HOLIDAYS_2026 = [
        date(2026, 1, 1),   # New Year
        date(2026, 1, 19),  # MLK Day
        date(2026, 2, 16),  # Presidents Day
        date(2026, 5, 25),  # Memorial Day
        date(2026, 7, 3),   # Independence Day (observed)
        date(2026, 9, 7),   # Labor Day
        date(2026, 11, 26), # Thanksgiving
        date(2026, 12, 25), # Christmas
    ]
    
    def calculate(self, params: CalendarParams) -> Dict[str, Any]:
        """
        Calculate calendar metrics.
        
        Args:
            params: Calendar parameters
            
        Returns:
            Calendar analysis results
        """
        # Combine default holidays with provided holidays
        all_holidays = set(params.holidays)
        if params.start_date.year == 2025:
            all_holidays.update(self.US_HOLIDAYS_2025)
        elif params.start_date.year == 2026:
            all_holidays.update(self.US_HOLIDAYS_2026)
        
        # Filter holidays to date range
        holidays_in_range = [
            h for h in all_holidays
            if params.start_date <= h <= params.end_date
        ]
        
        # Calculate working days
        total_days = (params.end_date - params.start_date).days + 1
        
        working_days = 0
        weekend_days = 0
        weekly_breakdown = []
        current_date = params.start_date
        
        week_start = current_date
        week_working = 0
        
        while current_date <= params.end_date:
            is_weekend = current_date.weekday() >= (7 - params.working_days_per_week)
            is_holiday = current_date in holidays_in_range
            
            if is_weekend:
                weekend_days += 1
            elif not is_holiday:
                working_days += 1
                week_working += 1
            
            # Check for week boundary (Sunday)
            if current_date.weekday() == 6 or current_date == params.end_date:
                weekly_breakdown.append({
                    "week_start": week_start.isoformat(),
                    "week_end": current_date.isoformat(),
                    "working_days": week_working,
                    "holidays": [
                        h.isoformat() for h in holidays_in_range
                        if week_start <= h <= current_date
                    ],
                })
                week_start = current_date + timedelta(days=1)
                week_working = 0
            
            current_date += timedelta(days=1)
        
        # Apply weather impact
        effective_working_days = max(0, working_days - params.weather_impact_days)
        
        # Calculate weeks
        total_weeks = len(weekly_breakdown)
        avg_working_days_per_week = working_days / total_weeks if total_weeks > 0 else 0
        
        return {
            "start_date": params.start_date.isoformat(),
            "end_date": params.end_date.isoformat(),
            "total_days": total_days,
            "total_working_days": working_days,
            "effective_working_days": effective_working_days,
            "weekend_days": weekend_days,
            "holiday_count": len(holidays_in_range),
            "holidays": [h.isoformat() for h in sorted(holidays_in_range)],
            "weather_impact_days": params.weather_impact_days,
            "total_weeks": total_weeks,
            "avg_working_days_per_week": round(avg_working_days_per_week, 1),
            "weekly_breakdown": weekly_breakdown,
        }
    
    def get_next_working_day(
        self,
        from_date: date,
        holidays: List[date] = None,
    ) -> date:
        """Get the next working day from a given date."""
        holidays = holidays or []
        current = from_date + timedelta(days=1)
        
        while True:
            if current.weekday() < 5 and current not in holidays:
                return current
            current += timedelta(days=1)
    
    def add_working_days(
        self,
        from_date: date,
        days: int,
        holidays: List[date] = None,
    ) -> date:
        """Add a number of working days to a date."""
        holidays = holidays or []
        current = from_date
        remaining = days
        
        while remaining > 0:
            current += timedelta(days=1)
            if current.weekday() < 5 and current not in holidays:
                remaining -= 1
        
        return current