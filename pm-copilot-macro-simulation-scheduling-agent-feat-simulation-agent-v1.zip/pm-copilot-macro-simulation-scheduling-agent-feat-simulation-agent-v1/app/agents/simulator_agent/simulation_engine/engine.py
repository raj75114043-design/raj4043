"""
Simulation Engine
Main engine that coordinates all simulation models
"""

from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional

import structlog

from app.agents.simulator_agent.simulation_engine.models.schedule_model import (
    ScheduleModel,
    ScheduleParams,
)
from app.agents.simulator_agent.simulation_engine.models.capacity_model import (
    CapacityModel,
    CapacityParams,
)
from app.agents.simulator_agent.simulation_engine.models.prerequisite_model import (
    PrerequisiteModel,
    PrerequisiteParams,
)
from app.agents.simulator_agent.simulation_engine.models.risk_model import (
    RiskModel,
    RiskParams,
)
from app.agents.simulator_agent.simulation_engine.models.impact_model import (
    ImpactModel,
    ImpactParams,
)
from app.agents.simulator_agent.simulation_engine.models.calendar_model import (
    CalendarModel,
    CalendarParams,
)

logger = structlog.get_logger(__name__)


class SimulationEngine:
    """
    Deterministic Simulation Engine.
    
    Coordinates all mathematical models to execute simulations.
    NO LLM involvement - all computations are deterministic Python.
    """
    
    def __init__(self):
        """Initialize simulation engine with all models."""
        self.schedule_model = ScheduleModel()
        self.capacity_model = CapacityModel()
        self.prerequisite_model = PrerequisiteModel()
        self.risk_model = RiskModel()
        self.impact_model = ImpactModel()
        self.calendar_model = CalendarModel()
        
        logger.info("Simulation engine initialized")
    
    def run_simulation(
        self,
        models: List[str],
        data: Dict[str, Any],
        parameters: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Run simulation with specified models.
        
        Args:
            models: List of model names to run
            data: Collected data from Data Agent
            parameters: Confirmed simulation parameters
            
        Returns:
            Combined simulation results
        """
        logger.info("Running simulation", models=models)
        
        results = {
            "models_executed": [],
            "model_results": {},
            "combined_result": {},
            "execution_time_ms": 0,
        }
        
        start_time = datetime.utcnow()
        
        # Build calendar first if needed
        calendar_data = None
        if "Calendar" in models:
            calendar_data = self._run_calendar_model(data, parameters)
            results["model_results"]["Calendar"] = calendar_data
            results["models_executed"].append("Calendar")
        
        # Run prerequisite model
        prereq_result = None
        if "Prerequisite" in models:
            prereq_result = self._run_prerequisite_model(data, parameters)
            results["model_results"]["Prerequisite"] = prereq_result
            results["models_executed"].append("Prerequisite")
        
        # Run capacity model
        capacity_result = None
        if "Capacity" in models:
            capacity_result = self._run_capacity_model(data, parameters)
            results["model_results"]["Capacity"] = capacity_result
            results["models_executed"].append("Capacity")
        
        # Run schedule model (depends on prerequisite and capacity)
        schedule_result = None
        if "Schedule" in models:
            schedule_result = self._run_schedule_model(
                data, parameters, prereq_result, capacity_result, calendar_data
            )
            results["model_results"]["Schedule"] = schedule_result
            results["models_executed"].append("Schedule")
        
        # Run impact model
        impact_result = None
        if "Impact" in models:
            impact_result = self._run_impact_model(data, parameters)
            results["model_results"]["Impact"] = impact_result
            results["models_executed"].append("Impact")
        
        # Run risk model
        risk_result = None
        if "Risk" in models:
            risk_result = self._run_risk_model(
                data, parameters, schedule_result, prereq_result
            )
            results["model_results"]["Risk"] = risk_result
            results["models_executed"].append("Risk")
        
        # Combine results
        results["combined_result"] = self._combine_results(results["model_results"])
        
        end_time = datetime.utcnow()
        results["execution_time_ms"] = int((end_time - start_time).total_seconds() * 1000)
        
        logger.info(
            "Simulation completed",
            models_executed=results["models_executed"],
            execution_time_ms=results["execution_time_ms"],
        )
        
        return results
    
    def _run_calendar_model(
        self,
        data: Dict[str, Any],
        parameters: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Run calendar model."""
        timeframe = parameters.get("timeframe", {})
        
        params = CalendarParams(
            start_date=date.fromisoformat(timeframe.get("start_date", str(date.today()))),
            end_date=date.fromisoformat(
                timeframe.get("end_date", str(date.today() + timedelta(weeks=8)))
            ),
            working_days_per_week=timeframe.get("working_days_per_week", 5),
            holidays=timeframe.get("holidays", []),
            market=parameters.get("market"),
        )
        
        return self.calendar_model.calculate(params)
    
    def _run_prerequisite_model(
        self,
        data: Dict[str, Any],
        parameters: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Run prerequisite model."""
        prereq_data = data.get("prereq_status", {})
        
        params = PrerequisiteParams(
            total_sites=prereq_data.get("total_sites", 0),
            prerequisites={
                "power": prereq_data.get("power_ready", 0),
                "fiber": prereq_data.get("fiber_ready", 0),
                "permits": prereq_data.get("permits_ready", 0),
                "material": prereq_data.get("material_ready", 0),
                "site_access": prereq_data.get("access_ready", 0),
                "intp": prereq_data.get("intp_ready", 0),
            },
            lead_times={
                "power": prereq_data.get("power_lead_time", 14),
                "fiber": prereq_data.get("fiber_lead_time", 21),
                "permits": prereq_data.get("permits_lead_time", 7),
                "material": prereq_data.get("material_lead_time", 10),
                "site_access": prereq_data.get("access_lead_time", 3),
                "intp": prereq_data.get("intp_lead_time", 5),
            },
        )
        
        return self.prerequisite_model.calculate(params)
    
    def _run_capacity_model(
        self,
        data: Dict[str, Any],
        parameters: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Run capacity model."""
        capacity_data = data.get("crew_capacity", {})
        
        params = CapacityParams(
            total_crews=capacity_data.get("total_crews", 0),
            available_crews=capacity_data.get("available_crews", 0),
            crew_productivity=parameters.get("constraints", {}).get("crew_productivity", 1.0),
            working_days_per_week=parameters.get("timeframe", {}).get("working_days_per_week", 5),
            vendors=capacity_data.get("vendors", []),
        )
        
        return self.capacity_model.calculate(params)
    
    def _run_schedule_model(
        self,
        data: Dict[str, Any],
        parameters: Dict[str, Any],
        prereq_result: Optional[Dict[str, Any]],
        capacity_result: Optional[Dict[str, Any]],
        calendar_data: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Run schedule model."""
        site_data = data.get("site_status", {})
        timeframe = parameters.get("timeframe", {})
        
        # Get ready sites from prerequisite result or data
        ready_sites = 0
        if prereq_result:
            ready_sites = prereq_result.get("sites_ready_to_start", 0)
        else:
            ready_sites = site_data.get("ready_to_start", 0)
        
        # Get weekly capacity from capacity result
        weekly_capacity = 0
        if capacity_result:
            weekly_capacity = capacity_result.get("weekly_capacity", 0)
        else:
            crews = data.get("crew_capacity", {}).get("available_crews", 1)
            productivity = parameters.get("constraints", {}).get("crew_productivity", 1.0)
            days = timeframe.get("working_days_per_week", 5)
            weekly_capacity = int(crews * productivity * days)
        
        # Get working days from calendar
        total_working_days = 0
        if calendar_data:
            total_working_days = calendar_data.get("total_working_days", 0)
        
        params = ScheduleParams(
            target_sites=parameters.get("target_sites", 0),
            ready_to_start=ready_sites,
            weekly_capacity=weekly_capacity,
            start_date=date.fromisoformat(timeframe.get("start_date", str(date.today()))),
            end_date=date.fromisoformat(
                timeframe.get("end_date", str(date.today() + timedelta(weeks=8)))
            ),
            working_days_per_week=timeframe.get("working_days_per_week", 5),
            max_weeks=52,
            prereq_pipeline=prereq_result.get("weekly_pipeline", []) if prereq_result else [],
        )
        
        return self.schedule_model.simulate(params)
    
    def _run_impact_model(
        self,
        data: Dict[str, Any],
        parameters: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Run impact model."""
        params = ImpactParams(
            baseline=data.get("baseline", {}),
            change_type=parameters.get("change_type", ""),
            change_amount=parameters.get("change_amount", 0),
            affected_scope=parameters.get("scope", "all"),
        )
        
        return self.impact_model.calculate(params)
    
    def _run_risk_model(
        self,
        data: Dict[str, Any],
        parameters: Dict[str, Any],
        schedule_result: Optional[Dict[str, Any]],
        prereq_result: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Run risk model."""
        params = RiskParams(
            target_sites=parameters.get("target_sites", 0),
            achievable_sites=schedule_result.get("total_achievable", 0) if schedule_result else 0,
            ready_sites=prereq_result.get("sites_ready_to_start", 0) if prereq_result else 0,
            prereq_bottleneck=prereq_result.get("bottleneck", "") if prereq_result else "",
            historical_variance=data.get("historical_variance", 0.15),
            num_simulations=1000,
        )
        
        return self.risk_model.monte_carlo(params)
    
    def _combine_results(
        self,
        model_results: Dict[str, Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Combine results from all models into unified output."""
        combined = {
            "feasibility": {},
            "weekly_plan": [],
            "risks": [],
            "summary": {},
        }
        
        # Get schedule results
        if "Schedule" in model_results:
            schedule = model_results["Schedule"]
            combined["feasibility"] = {
                "achievable": schedule.get("target_achievable", False),
                "target": schedule.get("target", 0),
                "achievable_count": schedule.get("total_achievable", 0),
                "gap": schedule.get("gap", 0),
                "confidence": schedule.get("confidence", 0),
                "bottleneck": schedule.get("bottleneck", ""),
            }
            combined["weekly_plan"] = schedule.get("weekly_plan", [])
        
        # Get risk results
        if "Risk" in model_results:
            risk = model_results["Risk"]
            combined["risks"] = risk.get("risks", [])
            combined["feasibility"]["confidence"] = risk.get("success_probability", 0)
        
        # Get capacity insights
        if "Capacity" in model_results:
            capacity = model_results["Capacity"]
            combined["summary"]["crew_utilization"] = capacity.get("utilization", 0)
            combined["summary"]["weekly_capacity"] = capacity.get("weekly_capacity", 0)
        
        # Get prerequisite insights
        if "Prerequisite" in model_results:
            prereq = model_results["Prerequisite"]
            combined["summary"]["sites_ready"] = prereq.get("sites_ready_to_start", 0)
            combined["summary"]["prereq_bottleneck"] = prereq.get("bottleneck", "")
        
        return combined