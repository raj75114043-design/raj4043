"""
Simulator Node
Executes the deterministic simulation engine
"""

from datetime import datetime
from typing import Any, Dict

import structlog

from app.agents.simulator_agent.state import SimulatorState
from app.agents.simulator_agent.simulation_engine.engine import SimulationEngine
from app.core.models import SimulationStatus

logger = structlog.get_logger(__name__)


async def simulator_node(state: SimulatorState) -> Dict[str, Any]:
    """
    Simulator node - executes deterministic simulation models.
    
    This node runs the mathematical simulation engine.
    NO LLM involvement - all computations are deterministic Python.
    """
    logger.info(
        "Simulator executing",
        session_id=state["session_id"],
        models=state.get("models_needed", []),
    )
    
    start_time = datetime.utcnow()
    
    models_needed = state.get("models_needed", [])
    collected_data = state.get("collected_data", {})
    parameters = state.get("parameters", {})
    
    # Initialize simulation engine
    engine = SimulationEngine()
    
    try:
        # Run simulation
        results = engine.run_simulation(
            models=models_needed,
            data=collected_data,
            parameters=parameters,
        )
        
        simulation_complete = True
        error = None
        
    except Exception as e:
        logger.error("Simulation execution failed", error=str(e))
        results = {
            "error": str(e),
            "models_executed": [],
            "model_results": {},
            "combined_result": {},
        }
        simulation_complete = False
        error = str(e)
    
    # Build trace step
    duration_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
    
    trace_step = {
        "agent": "simulator",
        "action": "execute_models",
        "input": {
            "models": models_needed,
            "data_keys": list(collected_data.keys()),
        },
        "output": {
            "models_executed": results.get("models_executed", []),
            "success": simulation_complete,
        },
        "duration_ms": duration_ms,
        "timestamp": datetime.utcnow().isoformat(),
    }
    
    updates = {
        "simulation_results": results,
        "simulation_complete": simulation_complete,
        "status": SimulationStatus.ANALYZING if simulation_complete else SimulationStatus.FAILED,
        "execution_trace": state.get("execution_trace", []) + [trace_step],
    }
    
    if error:
        updates["error"] = error
    
    logger.info(
        "Simulator completed",
        models_executed=results.get("models_executed", []),
        execution_time_ms=results.get("execution_time_ms", 0),
    )
    
    return updates