"""
Orchestrator Node
Coordinates the simulation workflow and manages state transitions
"""

from datetime import datetime
from typing import Any, Dict, Literal

import structlog
from langchain_core.messages import HumanMessage, SystemMessage

from app.agents.simulator_agent.state import SimulatorState
from app.agents.simulator_agent.prompts import ORCHESTRATOR_SYSTEM_PROMPT
from app.agents.shared.llm_factory import get_llm
from app.core.models import SimulationStatus

logger = structlog.get_logger(__name__)


async def orchestrator_node(state: SimulatorState) -> Dict[str, Any]:
    """
    Orchestrator node - coordinates the simulation workflow.
    
    Responsibilities:
    - Determine next step in workflow
    - Manage state transitions
    - Handle error recovery
    """
    logger.info(
        "Orchestrator executing",
        session_id=state["session_id"],
        current_status=state["status"],
    )
    
    # Add trace step
    trace_step = {
        "agent": "orchestrator",
        "action": "coordinate",
        "input": {"status": state["status"].value if isinstance(state["status"], SimulationStatus) else state["status"]},
        "timestamp": datetime.utcnow().isoformat(),
    }
    
    updates = {
        "execution_trace": state.get("execution_trace", []) + [trace_step],
    }
    
    # Determine next action based on current status
    status = state["status"]
    
    if status == SimulationStatus.PENDING_CLARIFICATION:
        if state.get("user_confirmed"):
            # User confirmed, move to planning
            updates["status"] = SimulationStatus.PLANNING
            logger.info("User confirmed, moving to planning")
        else:
            # Still waiting for clarification
            logger.info("Waiting for user clarification")
    
    elif status == SimulationStatus.CONFIRMED:
        # Parameters confirmed, start planning
        updates["status"] = SimulationStatus.PLANNING
        logger.info("Parameters confirmed, starting planning")
    
    elif status == SimulationStatus.PLANNING:
        if state.get("execution_plan"):
            # Plan ready, collect data
            updates["status"] = SimulationStatus.DATA_COLLECTION
            logger.info("Plan ready, collecting data")
    
    elif status == SimulationStatus.DATA_COLLECTION:
        if state.get("data_collection_complete"):
            # Data ready, execute simulation
            updates["status"] = SimulationStatus.EXECUTING
            logger.info("Data collected, executing simulation")
    
    elif status == SimulationStatus.EXECUTING:
        if state.get("simulation_complete"):
            # Simulation done, analyze results
            updates["status"] = SimulationStatus.ANALYZING
            logger.info("Simulation complete, analyzing")
    
    elif status == SimulationStatus.ANALYZING:
        if state.get("analysis_results"):
            # Analysis done
            updates["status"] = SimulationStatus.COMPLETED
            updates["completed_at"] = datetime.utcnow()
            logger.info("Analysis complete, finishing")
    
    elif status == SimulationStatus.FAILED:
        # Check if retry is possible
        if state.get("retry_count", 0) < state.get("max_retries", 3):
            updates["retry_count"] = state.get("retry_count", 0) + 1
            updates["status"] = SimulationStatus.PENDING_CLARIFICATION
            updates["error"] = None
            logger.info("Retrying after failure", retry_count=updates["retry_count"])
        else:
            logger.error("Max retries exceeded")
    
    trace_step["output"] = {"new_status": updates.get("status", status)}
    
    return updates


def route_orchestrator(state: SimulatorState) -> Literal[
    "query_refiner",
    "planner",
    "data_collector",
    "simulator",
    "analyzer",
    "output_generator",
    "hitl_wait",
    "end",
]:
    """
    Route from orchestrator to the appropriate next node.
    """
    status = state["status"]
    
    if status == SimulationStatus.PENDING_CLARIFICATION:
        if state.get("clarification_needed") and not state.get("user_confirmed"):
            return "hitl_wait"
        elif not state.get("intent"):
            return "query_refiner"
        else:
            return "query_refiner"
    
    elif status == SimulationStatus.CONFIRMED:
        return "planner"
    
    elif status == SimulationStatus.PLANNING:
        if state.get("execution_plan"):
            return "data_collector"
        else:
            return "planner"
    
    elif status == SimulationStatus.DATA_COLLECTION:
        if state.get("data_collection_complete"):
            return "simulator"
        else:
            return "data_collector"
    
    elif status == SimulationStatus.EXECUTING:
        if state.get("simulation_complete"):
            return "analyzer"
        else:
            return "simulator"
    
    elif status == SimulationStatus.ANALYZING:
        if state.get("analysis_results"):
            return "output_generator"
        else:
            return "analyzer"
    
    elif status == SimulationStatus.COMPLETED:
        return "end"
    
    elif status == SimulationStatus.FAILED:
        if state.get("retry_count", 0) < state.get("max_retries", 3):
            return "query_refiner"
        else:
            return "end"
    
    return "end"