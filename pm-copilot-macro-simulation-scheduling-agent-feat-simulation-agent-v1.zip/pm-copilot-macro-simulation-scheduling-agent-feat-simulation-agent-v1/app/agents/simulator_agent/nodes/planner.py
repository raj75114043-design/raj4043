"""
Planner Node
Decomposes simulation requirements into data needs and model execution plan
"""

import json
from datetime import datetime
from typing import Any, Dict, List

import structlog
from langchain_core.messages import HumanMessage, SystemMessage

from app.agents.simulator_agent.state import SimulatorState
from app.agents.simulator_agent.prompts import (
    PLANNER_SYSTEM_PROMPT,
    PLANNER_DECOMPOSITION_PROMPT,
)
from app.agents.simulator_agent.config import INTENT_MODEL_MAPPING
from app.agents.shared.llm_factory import get_llm
from app.core.models import SimulationStatus

logger = structlog.get_logger(__name__)


async def planner_node(state: SimulatorState) -> Dict[str, Any]:
    """
    Planner node - creates execution plan for simulation.
    
    Responsibilities:
    - Identify data requirements
    - Select simulation models
    - Determine execution sequence
    - Map dependencies
    """
    logger.info(
        "Planner executing",
        session_id=state["session_id"],
        intent=state.get("intent"),
    )
    
    start_time = datetime.utcnow()
    
    intent = state.get("intent")
    parameters = state.get("parameters", {})
    project_track = state["project_track"]
    
    # Get default models for this intent
    default_models = INTENT_MODEL_MAPPING.get(
        intent.value if intent else "what_if",
        ["Schedule", "Capacity", "Risk"]
    )
    
    # Use LLM to refine the plan
    llm = get_llm(temperature=0.1)
    
    decomposition_prompt = PLANNER_DECOMPOSITION_PROMPT.format(
        intent=intent.value if intent else "unknown",
        parameters=json.dumps(parameters, indent=2, default=str),
        project_track=project_track.value,
    )
    
    messages = [
        SystemMessage(content=PLANNER_SYSTEM_PROMPT),
        HumanMessage(content=decomposition_prompt),
    ]
    
    response = await llm.ainvoke(messages)
    
    # Parse response
    try:
        content = response.content
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0]
        elif "```" in content:
            content = content.split("```")[1].split("```")[0]
        
        plan = json.loads(content.strip())
    except json.JSONDecodeError as e:
        logger.warning("Failed to parse plan, using defaults", error=str(e))
        plan = _create_default_plan(parameters, default_models)
    
    # Ensure required fields
    data_requirements = plan.get("data_requirements", [])
    models_needed = plan.get("models_needed", default_models)
    execution_sequence = plan.get("execution_sequence", [])
    dependencies = plan.get("dependencies", {})
    
    # Add standard data requirements if missing
    data_requirements = _ensure_data_requirements(data_requirements, parameters)
    
    # Build execution plan
    execution_plan = {
        "data_requirements": data_requirements,
        "models_needed": models_needed,
        "execution_sequence": execution_sequence,
        "dependencies": dependencies,
    }
    
    # Build trace step
    duration_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
    
    trace_step = {
        "agent": "planner",
        "action": "create_execution_plan",
        "input": {"intent": intent.value if intent else None, "parameters": parameters},
        "output": {
            "models": models_needed,
            "data_requirements_count": len(data_requirements),
        },
        "duration_ms": duration_ms,
        "timestamp": datetime.utcnow().isoformat(),
    }
    
    updates = {
        "data_requirements": data_requirements,
        "models_needed": models_needed,
        "execution_plan": execution_plan,
        "status": SimulationStatus.DATA_COLLECTION,
        "execution_trace": state.get("execution_trace", []) + [trace_step],
    }
    
    logger.info(
        "Planner completed",
        models=models_needed,
        data_requirements=len(data_requirements),
    )
    
    return updates


def _create_default_plan(
    parameters: Dict[str, Any],
    models: List[str],
) -> Dict[str, Any]:
    """Create a default execution plan."""
    market = parameters.get("market", "")
    
    return {
        "data_requirements": [
            {"name": "site_status", "type": "cached", "params": {"market": market}},
            {"name": "crew_capacity", "type": "cached", "params": {"market": market}},
            {"name": "prereq_status", "type": "cached", "params": {"market": market}},
        ],
        "models_needed": models,
        "execution_sequence": [
            {"step": 1, "action": "fetch_data", "target": ["site_status", "crew_capacity", "prereq_status"]},
            {"step": 2, "action": "run_model", "target": "Prerequisite"},
            {"step": 3, "action": "run_model", "target": "Capacity"},
            {"step": 4, "action": "run_model", "target": "Schedule"},
            {"step": 5, "action": "run_model", "target": "Risk"},
        ],
        "dependencies": {
            "Schedule": ["site_status", "crew_capacity", "Prerequisite", "Capacity"],
            "Risk": ["Schedule", "Prerequisite"],
        },
    }


def _ensure_data_requirements(
    requirements: List[Dict[str, Any]],
    parameters: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """Ensure standard data requirements are included."""
    market = parameters.get("market", "")
    
    required_queries = {
        "site_status": {"market": market},
        "crew_capacity": {"market": market},
        "prereq_status": {"market": market},
    }
    
    existing_names = {r.get("name") for r in requirements}
    
    for name, params in required_queries.items():
        if name not in existing_names:
            requirements.append({
                "name": name,
                "type": "cached",
                "params": params,
            })
    
    return requirements