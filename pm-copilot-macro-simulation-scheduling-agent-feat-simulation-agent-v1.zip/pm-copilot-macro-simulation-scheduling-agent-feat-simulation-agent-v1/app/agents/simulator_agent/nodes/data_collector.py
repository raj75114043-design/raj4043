"""
Data Collector Node
Fetches all required data for simulation
"""

from datetime import datetime
from typing import Any, Dict, List

import structlog

from app.agents.simulator_agent.state import SimulatorState
from app.agents.shared.base_tools import (
    get_cached_data,
    execute_sql,
    get_kpi,
    get_calendar,
    get_market_summary,
    get_vendor_capacity,
    get_prerequisite_summary,
)
from app.core.models import SimulationStatus

logger = structlog.get_logger(__name__)


async def data_collector_node(state: SimulatorState) -> Dict[str, Any]:
    """
    Data Collector node - fetches all required data.
    """
    logger.info(
        "Data Collector executing",
        session_id=state["session_id"],
        requirements_count=len(state.get("data_requirements", [])),
    )
    
    start_time = datetime.utcnow()
    
    data_requirements = state.get("data_requirements", [])
    parameters = state.get("parameters", {})
    collected_data = state.get("collected_data", {}).copy()
    errors = []
    
    for requirement in data_requirements:
        req_name = requirement.get("name", "")
        req_type = requirement.get("type", "cached")
        req_params = requirement.get("params", {})
        
        logger.debug("Fetching data", name=req_name, type=req_type)
        
        try:
            if req_type == "cached":
                result = await get_cached_data.ainvoke({
                    "query_name": req_name,
                    "params": req_params,
                })
            elif req_type == "sql":
                result = await execute_sql.ainvoke({
                    "query": requirement.get("query", ""),
                    "params": req_params,
                })
            elif req_type == "kpi":
                result = await get_kpi.ainvoke({
                    "kpi_name": req_name,
                    "market": req_params.get("market"),
                })
            elif req_type == "calendar":
                timeframe = parameters.get("timeframe", {})
                result = await get_calendar.ainvoke({
                    "market": req_params.get("market", ""),
                    "start_date": timeframe.get("start_date", ""),
                    "end_date": timeframe.get("end_date", ""),
                })
            elif req_type == "kg_market":
                result = await get_market_summary.ainvoke(req_params.get("market", ""))
            elif req_type == "kg_vendor":
                result = await get_vendor_capacity.ainvoke(req_params.get("market", ""))
            elif req_type == "kg_prereq":
                result = await get_prerequisite_summary.ainvoke(req_params.get("market"))
            else:
                result = {"error": f"Unknown data type: {req_type}"}
            
            if isinstance(result, dict) and result.get("error"):
                errors.append({"name": req_name, "error": result["error"]})
                collected_data[req_name] = _get_mock_data(req_name, req_params)
            else:
                collected_data[req_name] = result
                
        except Exception as e:
            logger.error(f"Failed to fetch {req_name}", error=str(e))
            errors.append({"name": req_name, "error": str(e)})
            collected_data[req_name] = _get_mock_data(req_name, req_params)
    
    duration_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
    
    trace_step = {
        "agent": "data_collector",
        "action": "fetch_data",
        "input": {"requirements": [r.get("name") for r in data_requirements]},
        "output": {"collected": list(collected_data.keys()), "errors": len(errors)},
        "duration_ms": duration_ms,
        "timestamp": datetime.utcnow().isoformat(),
    }
    
    data_complete = len(errors) == 0 or len(collected_data) >= len(data_requirements)
    
    updates = {
        "collected_data": collected_data,
        "data_collection_complete": data_complete,
        "status": SimulationStatus.EXECUTING if data_complete else state["status"],
        "execution_trace": state.get("execution_trace", []) + [trace_step],
    }
    
    logger.info("Data Collector completed", collected=len(collected_data), errors=len(errors))
    return updates


def _get_mock_data(name: str, params: Dict[str, Any]) -> Dict[str, Any]:
    """Get mock data for development/testing."""
    market = params.get("market", "Chicago")
    
    mock_data = {
        "site_status": {
            "market": market, "total_sites": 1379, "completed": 771, "in_progress": 300,
            "pending": 308, "ready_to_start": 45, "blocked": 263,
        },
        "crew_capacity": {
            "market": market, "total_crews": 25, "available_crews": 20,
            "vendors": [
                {"name": "Nettxio", "total_crews": 10, "available_crews": 8, "sites_assigned": 150},
                {"name": "TechCrew", "total_crews": 8, "available_crews": 7, "sites_assigned": 100},
                {"name": "WaveTech", "total_crews": 7, "available_crews": 5, "sites_assigned": 80},
            ],
        },
        "prereq_status": {
            "market": market, "total_sites": 608, "power_ready": 450, "fiber_ready": 380,
            "permits_ready": 520, "material_ready": 400, "access_ready": 550, "intp_ready": 320,
            "power_lead_time": 14, "fiber_lead_time": 21, "permits_lead_time": 7,
            "material_lead_time": 10, "access_lead_time": 3, "intp_lead_time": 5,
        },
        "run_rate": {"market": market, "weekly_average": 35, "monthly_average": 140, "trend": "stable"},
        "vendor_performance": {
            "market": market,
            "vendors": [
                {"name": "Nettxio", "ftr_rate": 0.85, "on_time_rate": 0.78},
                {"name": "TechCrew", "ftr_rate": 0.92, "on_time_rate": 0.88},
                {"name": "WaveTech", "ftr_rate": 0.80, "on_time_rate": 0.75},
            ],
        },
    }
    return mock_data.get(name, {"error": "No mock data available"})