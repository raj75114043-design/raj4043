"""
Analyzer Node
Interprets simulation results and identifies risks
"""

from datetime import datetime
from typing import Any, Dict, List

import structlog
from langchain_core.messages import HumanMessage, SystemMessage

from app.agents.simulator_agent.state import SimulatorState
from app.agents.simulator_agent.prompts import ANALYZER_SYSTEM_PROMPT
from app.agents.shared.llm_factory import get_llm
from app.core.models import SimulationStatus

logger = structlog.get_logger(__name__)


async def analyzer_node(state: SimulatorState) -> Dict[str, Any]:
    """
    Analyzer node - interprets simulation results.
    
    Responsibilities:
    - Interpret simulation outputs for business meaning
    - Identify risks, bottlenecks, and constraints
    - Generate actionable recommendations
    """
    logger.info(
        "Analyzer executing",
        session_id=state["session_id"],
    )
    
    start_time = datetime.utcnow()
    
    simulation_results = state.get("simulation_results", {})
    parameters = state.get("parameters", {})
    collected_data = state.get("collected_data", {})
    
    # Extract key results from simulation
    combined = simulation_results.get("combined_result", {})
    model_results = simulation_results.get("model_results", {})
    
    # Get feasibility from results
    feasibility = combined.get("feasibility", {})
    weekly_plan = combined.get("weekly_plan", [])
    
    # Analyze risks
    risks = _analyze_risks(
        feasibility=feasibility,
        model_results=model_results,
        parameters=parameters,
    )
    
    # Generate recommendations
    recommendations = _generate_recommendations(
        feasibility=feasibility,
        risks=risks,
        parameters=parameters,
    )
    
    # Use LLM for executive summary
    llm = get_llm(temperature=0.2)
    
    summary_prompt = f"""
    Analyze these simulation results and provide a brief executive summary:
    
    Target: {parameters.get('target_sites', 0)} sites in {parameters.get('market', 'unknown market')}
    Achievable: {feasibility.get('achievable_count', 0)} sites
    Gap: {feasibility.get('gap', 0)} sites
    Confidence: {feasibility.get('confidence', 0):.0%}
    Bottleneck: {feasibility.get('bottleneck', 'unknown')}
    
    Key Risks: {len(risks)}
    
    Provide a 2-3 sentence executive summary for a Project Manager.
    Be direct and quantitative.
    """
    
    messages = [
        SystemMessage(content=ANALYZER_SYSTEM_PROMPT),
        HumanMessage(content=summary_prompt),
    ]
    
    response = await llm.ainvoke(messages)
    executive_summary = response.content.strip()
    
    # Build analysis results
    analysis_results = {
        "executive_summary": executive_summary,
        "feasibility": feasibility,
        "risks": risks,
        "recommendations": recommendations,
        "key_metrics": {
            "target": parameters.get("target_sites", 0),
            "achievable": feasibility.get("achievable_count", 0),
            "gap": feasibility.get("gap", 0),
            "confidence": feasibility.get("confidence", 0),
            "bottleneck": feasibility.get("bottleneck", ""),
            "weeks_required": len(weekly_plan),
        },
    }
    
    # Build trace step
    duration_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
    
    trace_step = {
        "agent": "analyzer",
        "action": "analyze_results",
        "input": {"has_simulation_results": bool(simulation_results)},
        "output": {
            "risks_identified": len(risks),
            "recommendations": len(recommendations),
        },
        "duration_ms": duration_ms,
        "timestamp": datetime.utcnow().isoformat(),
    }
    
    updates = {
        "analysis_results": analysis_results,
        "risks_identified": risks,
        "recommendations": recommendations,
        "status": SimulationStatus.COMPLETED,
        "execution_trace": state.get("execution_trace", []) + [trace_step],
    }
    
    logger.info(
        "Analyzer completed",
        risks=len(risks),
        recommendations=len(recommendations),
    )
    
    return updates


def _analyze_risks(
    feasibility: Dict[str, Any],
    model_results: Dict[str, Any],
    parameters: Dict[str, Any],
) -> List[Dict[str, Any]]:
    """Analyze and categorize risks."""
    risks = []
    
    # Gap risk
    gap = feasibility.get("gap", 0)
    target = parameters.get("target_sites", 0)
    
    if gap > 0 and target > 0:
        gap_pct = gap / target
        risks.append({
            "risk": f"Target gap of {gap} sites ({gap_pct:.0%})",
            "category": "Schedule",
            "probability": "HIGH" if gap_pct > 0.3 else "MEDIUM" if gap_pct > 0.1 else "LOW",
            "impact": "HIGH",
            "mitigation": "Add crews, expedite prerequisites, or revise target",
        })
    
    # Prerequisite bottleneck risk
    bottleneck = feasibility.get("bottleneck", "")
    if "prerequisite" in bottleneck.lower() or "ready" in bottleneck.lower():
        risks.append({
            "risk": f"Prerequisite bottleneck: {bottleneck}",
            "category": "Prerequisite",
            "probability": "HIGH",
            "impact": "HIGH",
            "mitigation": "Focus on expediting prerequisites for blocked sites",
        })
    
    # Capacity risk
    if "Capacity" in model_results:
        capacity = model_results["Capacity"]
        utilization = capacity.get("utilization", 0)
        
        if utilization < 0.5:
            risks.append({
                "risk": f"Low crew utilization ({utilization:.0%})",
                "category": "Resource",
                "probability": "MEDIUM",
                "impact": "MEDIUM",
                "mitigation": "Improve site readiness to maximize crew utilization",
            })
        elif utilization > 0.95:
            risks.append({
                "risk": "Crews at maximum capacity",
                "category": "Resource",
                "probability": "HIGH",
                "impact": "HIGH",
                "mitigation": "Add crews or extend timeline",
            })
    
    # Low confidence risk
    confidence = feasibility.get("confidence", 0)
    if confidence < 0.5:
        risks.append({
            "risk": f"Low success probability ({confidence:.0%})",
            "category": "Execution",
            "probability": "HIGH",
            "impact": "HIGH",
            "mitigation": "Address bottlenecks and prepare contingency plan",
        })
    
    return risks[:10]  # Limit to top 10 risks


def _generate_recommendations(
    feasibility: Dict[str, Any],
    risks: List[Dict[str, Any]],
    parameters: Dict[str, Any],
) -> List[str]:
    """Generate prioritized recommendations."""
    recommendations = []
    
    gap = feasibility.get("gap", 0)
    bottleneck = feasibility.get("bottleneck", "")
    achievable = feasibility.get("achievable", True)
    
    if not achievable:
        recommendations.append(
            f"CRITICAL: Revise target to achievable level of {feasibility.get('achievable_count', 0)} sites"
        )
    
    if "prerequisite" in bottleneck.lower():
        recommendations.append(
            "PRIORITY: Expedite prerequisite clearance for blocked sites"
        )
    
    if "crew" in bottleneck.lower() or "capacity" in bottleneck.lower():
        recommendations.append(
            "PRIORITY: Add crews or shift volume to available vendors"
        )
    
    if gap > 0:
        recommendations.append(
            f"Address gap of {gap} sites through prerequisite acceleration"
        )
    
    # Add risk-based recommendations
    high_risks = [r for r in risks if r.get("probability") == "HIGH"]
    for risk in high_risks[:2]:
        recommendations.append(f"Mitigate: {risk.get('mitigation', '')}")
    
    # Standard recommendations
    recommendations.append("Monitor weekly progress and adjust plan as needed")
    
    return recommendations[:5]  # Limit to top 5