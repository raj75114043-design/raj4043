"""
Query Refiner Node
Extracts intent, entities, and identifies clarification needs
"""

import json
from datetime import datetime
from typing import Any, Dict

import structlog
from langchain_core.messages import HumanMessage, SystemMessage

from app.agents.simulator_agent.state import SimulatorState
from app.agents.simulator_agent.prompts import (
    QUERY_REFINER_SYSTEM_PROMPT,
    QUERY_REFINER_EXTRACTION_PROMPT,
)
from app.agents.shared.llm_factory import get_llm
from app.core.models import SimulationIntent, SimulationStatus, ClarificationQuestion

logger = structlog.get_logger(__name__)


async def query_refiner_node(state: SimulatorState) -> Dict[str, Any]:
    """
    Query Refiner node - extracts intent and parameters from query.
    
    Responsibilities:
    - Classify simulation intent
    - Extract entities (market, target, timeframe, etc.)
    - Identify missing parameters
    - Generate clarification questions if needed
    """
    logger.info(
        "Query Refiner executing",
        session_id=state["session_id"],
        query=state["query"][:100],
    )
    
    start_time = datetime.utcnow()
    
    # Get LLM
    llm = get_llm(temperature=0.1)
    
    # Format the extraction prompt
    extraction_prompt = QUERY_REFINER_EXTRACTION_PROMPT.format(
        query=state["query"],
        project_track=state["project_track"].value,
    )
    
    # Call LLM
    messages = [
        SystemMessage(content=QUERY_REFINER_SYSTEM_PROMPT),
        HumanMessage(content=extraction_prompt),
    ]
    
    response = await llm.ainvoke(messages)
    
    # Parse response
    try:
        # Extract JSON from response
        content = response.content
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0]
        elif "```" in content:
            content = content.split("```")[1].split("```")[0]
        
        extraction = json.loads(content.strip())
    except json.JSONDecodeError as e:
        logger.error("Failed to parse LLM response", error=str(e))
        extraction = {
            "intent": "what_if",
            "confidence": 0.5,
            "extracted": {},
            "missing_parameters": ["market", "target_sites", "timeframe"],
            "clarification_questions": [],
            "default_assumptions": {},
        }
    
    # Map intent string to enum
    intent_str = extraction.get("intent", "what_if")
    try:
        intent = SimulationIntent(intent_str)
    except ValueError:
        intent = SimulationIntent.WHAT_IF
    
    # Build clarification questions
    clarification_questions = []
    for q in extraction.get("clarification_questions", []):
        clarification_questions.append(ClarificationQuestion(
            question=q.get("question", ""),
            options=q.get("options"),
            default_value=q.get("default"),
            required=q.get("required", True),
        ))
    
    # Determine if clarification is needed
    missing_params = extraction.get("missing_parameters", [])
    clarification_count = state.get("clarification_count", 0)
    needs_clarification = (
        len(missing_params) > 0 and 
        clarification_count < state.get("max_clarifications", 3) and
        not state.get("user_confirmed", False)
    )
    
    # Build updates
    duration_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
    
    trace_step = {
        "agent": "query_refiner",
        "action": "extract_and_clarify",
        "input": {"query": state["query"]},
        "output": {
            "intent": intent.value,
            "confidence": extraction.get("confidence", 0),
            "missing_params": missing_params,
            "needs_clarification": needs_clarification,
        },
        "duration_ms": duration_ms,
        "timestamp": datetime.utcnow().isoformat(),
    }
    
    updates = {
        "intent": intent,
        "extracted_entities": extraction.get("extracted", {}),
        "missing_parameters": missing_params,
        "clarification_needed": needs_clarification,
        "clarification_questions": clarification_questions if needs_clarification else [],
        "clarification_count": clarification_count + (1 if needs_clarification else 0),
        "execution_trace": state.get("execution_trace", []) + [trace_step],
    }
    
    # If no clarification needed, build parameters and move to confirmed
    if not needs_clarification:
        parameters = _build_parameters(
            extraction.get("extracted", {}),
            extraction.get("default_assumptions", {}),
            state.get("confirmed_answers", {}),
        )
        updates["parameters"] = parameters
        updates["status"] = SimulationStatus.CONFIRMED
        updates["user_confirmed"] = True
    else:
        updates["status"] = SimulationStatus.PENDING_CLARIFICATION
    
    logger.info(
        "Query Refiner completed",
        intent=intent.value,
        needs_clarification=needs_clarification,
        missing_params=len(missing_params),
    )
    
    return updates


def _build_parameters(
    extracted: Dict[str, Any],
    defaults: Dict[str, Any],
    confirmed: Dict[str, Any],
) -> Dict[str, Any]:
    """Build simulation parameters from extracted entities and defaults."""
    # Start with defaults
    params = defaults.copy()
    
    # Override with extracted entities
    params.update(extracted)
    
    # Override with user-confirmed values
    params.update(confirmed)
    
    # Ensure timeframe structure
    if "timeframe" not in params:
        params["timeframe"] = {}
    
    if "start_date" in extracted:
        params["timeframe"]["start_date"] = extracted["start_date"]
    if "end_date" in extracted:
        params["timeframe"]["end_date"] = extracted["end_date"]
    if "duration_weeks" in extracted:
        params["timeframe"]["duration_weeks"] = extracted["duration_weeks"]
    
    # Ensure constraints structure
    if "constraints" not in params:
        params["constraints"] = {}
    
    if "crew_productivity" in defaults:
        params["constraints"]["crew_productivity"] = defaults["crew_productivity"]
    
    return params