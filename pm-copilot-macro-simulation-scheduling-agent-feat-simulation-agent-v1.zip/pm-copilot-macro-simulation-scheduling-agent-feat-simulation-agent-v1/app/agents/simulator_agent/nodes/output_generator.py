"""
Output Generator Node
Creates actionable, PM-friendly outputs from simulation results
"""

from datetime import datetime
from typing import Any, Dict, List

import structlog

from app.agents.simulator_agent.state import SimulatorState
from app.core.models import SimulationStatus

logger = structlog.get_logger(__name__)


async def output_generator_node(state: SimulatorState) -> Dict[str, Any]:
    """
    Output Generator node - formats results for PM consumption.
    
    Responsibilities:
    - Format simulation results for clear communication
    - Create week-by-week execution plans
    - Generate comparison tables for what-if scenarios
    - Produce action plans with owners and timelines
    """
    logger.info(
        "Output Generator executing",
        session_id=state["session_id"],
    )
    
    start_time = datetime.utcnow()
    
    simulation_results = state.get("simulation_results", {})
    analysis_results = state.get("analysis_results", {})
    parameters = state.get("parameters", {})
    
    # Get components
    combined = simulation_results.get("combined_result", {})
    feasibility = analysis_results.get("feasibility", combined.get("feasibility", {}))
    weekly_plan = combined.get("weekly_plan", [])
    risks = state.get("risks_identified", [])
    recommendations = state.get("recommendations", [])
    
    # Build final output
    final_output = {
        # Status summary
        "status": {
            "achievable": feasibility.get("achievable", False),
            "target": feasibility.get("target", parameters.get("target_sites", 0)),
            "achievable_count": feasibility.get("achievable_count", 0),
            "gap": feasibility.get("gap", 0),
            "confidence": _format_confidence(feasibility.get("confidence", 0)),
            "bottleneck": feasibility.get("bottleneck", "None identified"),
        },
        
        # Executive summary
        "executive_summary": analysis_results.get(
            "executive_summary",
            _generate_default_summary(feasibility, parameters)
        ),
        
        # Weekly plan table
        "weekly_plan": _format_weekly_plan(weekly_plan),
        
        # Risk matrix
        "risk_matrix": _format_risk_matrix(risks),
        
        # Action plan
        "action_plan": _format_action_plan(recommendations, risks),
        
        # Metadata
        "metadata": {
            "session_id": state["session_id"],
            "query": state.get("query", ""),
            "intent": state.get("intent", "").value if state.get("intent") else "",
            "market": parameters.get("market", ""),
            "timeframe": parameters.get("timeframe", {}),
            "models_used": state.get("models_needed", []),
            "generated_at": datetime.utcnow().isoformat(),
        },
    }
    
    # Build trace step
    duration_ms = int((datetime.utcnow() - start_time).total_seconds() * 1000)
    
    trace_step = {
        "agent": "output_generator",
        "action": "generate_output",
        "input": {"has_analysis": bool(analysis_results)},
        "output": {"output_sections": list(final_output.keys())},
        "duration_ms": duration_ms,
        "timestamp": datetime.utcnow().isoformat(),
    }
    
    updates = {
        "final_output": final_output,
        "status": SimulationStatus.COMPLETED,
        "completed_at": datetime.utcnow(),
        "execution_trace": state.get("execution_trace", []) + [trace_step],
    }
    
    logger.info("Output Generator completed")
    
    return updates


def _format_confidence(confidence: float) -> str:
    """Format confidence level as label."""
    if confidence >= 0.9:
        return f"HIGH ({confidence:.0%})"
    elif confidence >= 0.7:
        return f"MEDIUM ({confidence:.0%})"
    elif confidence >= 0.5:
        return f"LOW ({confidence:.0%})"
    else:
        return f"VERY LOW ({confidence:.0%})"


def _generate_default_summary(
    feasibility: Dict[str, Any],
    parameters: Dict[str, Any],
) -> str:
    """Generate a default executive summary."""
    target = parameters.get("target_sites", 0)
    market = parameters.get("market", "the market")
    achievable = feasibility.get("achievable_count", 0)
    gap = feasibility.get("gap", 0)
    bottleneck = feasibility.get("bottleneck", "")
    
    if gap == 0:
        return f"Target of {target} sites in {market} is achievable with current resources."
    else:
        return f"Target of {target} sites in {market} has a gap of {gap} sites. Primary bottleneck: {bottleneck}. Recommend addressing prerequisites and considering additional crews."


def _format_weekly_plan(weekly_plan: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Format weekly plan for display."""
    formatted = []
    
    for week in weekly_plan:
        formatted.append({
            "week": week.get("week_number", 0),
            "start_date": week.get("start_date", ""),
            "end_date": week.get("end_date", ""),
            "ready_sites": week.get("ready_at_start", 0),
            "capacity": week.get("capacity", 0),
            "planned": week.get("planned", 0),
            "completed": week.get("completed", 0),
            "remaining": week.get("remaining", 0),
            "utilization": f"{week.get('crew_utilization', 0):.0%}",
            "cumulative": week.get("cumulative_completed", 0),
            "actions": week.get("fast_track_actions", []),
        })
    
    return formatted


def _format_risk_matrix(risks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Format risks as a matrix."""
    formatted = []
    
    for risk in risks:
        formatted.append({
            "risk": risk.get("risk", ""),
            "category": risk.get("category", ""),
            "probability": risk.get("probability", "MEDIUM"),
            "impact": risk.get("impact", "MEDIUM"),
            "mitigation": risk.get("mitigation", ""),
            "priority": _calculate_priority(
                risk.get("probability", "MEDIUM"),
                risk.get("impact", "MEDIUM")
            ),
        })
    
    # Sort by priority
    priority_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    formatted.sort(key=lambda x: priority_order.get(x["priority"], 2))
    
    return formatted


def _calculate_priority(probability: str, impact: str) -> str:
    """Calculate overall priority from probability and impact."""
    if probability == "HIGH" and impact == "HIGH":
        return "CRITICAL"
    elif probability == "HIGH" or impact == "HIGH":
        return "HIGH"
    elif probability == "MEDIUM" or impact == "MEDIUM":
        return "MEDIUM"
    else:
        return "LOW"


def _format_action_plan(
    recommendations: List[str],
    risks: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Format action plan with priorities and owners."""
    actions = []
    
    for idx, rec in enumerate(recommendations[:5], 1):
        # Determine priority from recommendation text
        if "CRITICAL" in rec.upper():
            priority = "CRITICAL"
            owner = "PM / Leadership"
        elif "PRIORITY" in rec.upper():
            priority = "HIGH"
            owner = "PM"
        else:
            priority = "MEDIUM"
            owner = "Team Lead"
        
        actions.append({
            "id": idx,
            "action": rec.replace("CRITICAL: ", "").replace("PRIORITY: ", ""),
            "priority": priority,
            "owner": owner,
            "status": "Open",
            "due": "This week" if priority in ["CRITICAL", "HIGH"] else "Next 2 weeks",
        })
    
    return actions