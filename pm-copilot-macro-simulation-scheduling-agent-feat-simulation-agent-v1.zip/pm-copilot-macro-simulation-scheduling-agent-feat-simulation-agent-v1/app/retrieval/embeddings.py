"""
Embedding Service
Generates embeddings for semantic search
"""

from typing import List, Optional

import structlog
from langchain_openai import OpenAIEmbeddings

from app.core.config import settings

logger = structlog.get_logger(__name__)


class EmbeddingService:
    """
    Service for generating text embeddings.
    Uses OpenAI embeddings by default.
    """
    
    def __init__(self, model: str = "text-embedding-3-small"):
        """
        Initialize embedding service.
        
        Args:
            model: Embedding model name
        """
        self.model = model
        self._embeddings: Optional[OpenAIEmbeddings] = None
    
    @property
    def embeddings(self) -> OpenAIEmbeddings:
        """Lazy-load embeddings model."""
        if self._embeddings is None:
            self._embeddings = OpenAIEmbeddings(
                model=self.model,
                openai_api_key=settings.OPENAI_API_KEY,
            )
        return self._embeddings
    
    async def embed_text(self, text: str) -> List[float]:
        """
        Generate embedding for a single text.
        
        Args:
            text: Text to embed
            
        Returns:
            Embedding vector
        """
        try:
            result = await self.embeddings.aembed_query(text)
            return result
        except Exception as e:
            logger.error("Embedding failed", error=str(e))
            raise
    
    async def embed_texts(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple texts.
        
        Args:
            texts: List of texts to embed
            
        Returns:
            List of embedding vectors
        """
        try:
            results = await self.embeddings.aembed_documents(texts)
            return results
        except Exception as e:
            logger.error("Batch embedding failed", error=str(e))
            raise
    
    def get_dimension(self) -> int:
        """Get embedding dimension for the model."""
        dimensions = {
            "text-embedding-3-small": 1536,
            "text-embedding-3-large": 3072,
            "text-embedding-ada-002": 1536,
        }
        return dimensions.get(self.model, 1536)


# Global instance
_embedding_service: Optional[EmbeddingService] = None


def get_embedding_service() -> EmbeddingService:
    """Get or create embedding service instance."""
    global _embedding_service
    if _embedding_service is None:
        _embedding_service = EmbeddingService()
    return _embedding_service