"""
Context Builder
Combines semantic search and knowledge graph retrieval
to build rich context for agents
"""

from typing import Any, Dict, List, Optional

import structlog

from app.retrieval.semantic_search.vector_store import get_vector_store
from app.retrieval.knowledge_graph.graph_client import get_graph_client

logger = structlog.get_logger(__name__)


class ContextBuilder:
    """
    Builds context by combining multiple retrieval strategies:
    - Semantic search for similar documents/scenarios
    - Knowledge graph for entity relationships
    - Structured data from the foundation layer
    """
    
    def __init__(self):
        """Initialize context builder."""
        self.vector_store = get_vector_store()
        self._graph_client = None
    
    async def get_graph_client(self):
        """Lazy-load graph client."""
        if self._graph_client is None:
            self._graph_client = await get_graph_client()
        return self._graph_client
    
    async def build_context(
        self,
        query: str,
        market: Optional[str] = None,
        entities: Optional[Dict[str, Any]] = None,
        include_semantic: bool = True,
        include_graph: bool = True,
        semantic_k: int = 5,
    ) -> Dict[str, Any]:
        """
        Build comprehensive context for a query.
        
        Args:
            query: User query
            market: Optional market filter
            entities: Optional extracted entities
            include_semantic: Include semantic search results
            include_graph: Include knowledge graph context
            semantic_k: Number of semantic search results
            
        Returns:
            Combined context dictionary
        """
        context = {
            "query": query,
            "semantic_results": [],
            "graph_context": {},
            "market_info": {},
            "entity_info": {},
        }
        
        # Semantic search
        if include_semantic:
            try:
                semantic_results = await self.vector_store.similarity_search(
                    query=query,
                    k=semantic_k,
                    filter_metadata={"market": market} if market else None,
                )
                context["semantic_results"] = [
                    {"content": content, "score": score, "metadata": metadata}
                    for content, score, metadata in semantic_results
                ]
            except Exception as e:
                logger.warning("Semantic search failed", error=str(e))
        
        # Knowledge graph context
        if include_graph:
            graph_client = await self.get_graph_client()
            
            # Get market info
            if market:
                try:
                    market_sites = await graph_client.get_market_sites(market)
                    context["market_info"] = {
                        "market": market,
                        "site_count": len(market_sites),
                        "sites_sample": market_sites[:10],
                    }
                except Exception as e:
                    logger.warning("Market info retrieval failed", error=str(e))
            
            # Get entity relationships
            if entities:
                for entity_type, entity_id in entities.items():
                    if entity_type == "site" and entity_id:
                        try:
                            deps = await graph_client.get_site_dependencies(entity_id)
                            context["entity_info"][entity_id] = {
                                "type": "site",
                                "dependencies": deps,
                            }
                        except Exception as e:
                            logger.warning(f"Entity info failed for {entity_id}", error=str(e))
                    
                    elif entity_type == "vendor" and entity_id:
                        try:
                            sites = await graph_client.get_vendor_sites(entity_id, market)
                            context["entity_info"][entity_id] = {
                                "type": "vendor",
                                "assigned_sites": len(sites),
                            }
                        except Exception as e:
                            logger.warning(f"Vendor info failed for {entity_id}", error=str(e))
        
        return context
    
    async def find_similar_scenarios(
        self,
        query: str,
        k: int = 5,
    ) -> List[Dict[str, Any]]:
        """
        Find similar historical scenarios.
        
        Args:
            query: Current query
            k: Number of results
            
        Returns:
            List of similar scenarios
        """
        try:
            results = await self.vector_store.similarity_search(
                query=query,
                k=k,
                filter_metadata={"type": "scenario"},
            )
            return [
                {
                    "scenario": content,
                    "similarity": score,
                    "metadata": metadata,
                }
                for content, score, metadata in results
            ]
        except Exception as e:
            logger.warning("Similar scenarios search failed", error=str(e))
            return []
    
    async def get_entity_context(
        self,
        entity_type: str,
        entity_id: str,
        depth: int = 2,
    ) -> Dict[str, Any]:
        """
        Get rich context for an entity from the knowledge graph.
        
        Args:
            entity_type: Type of entity (Site, Vendor, Market, etc.)
            entity_id: Entity identifier
            depth: Traversal depth for relationships
            
        Returns:
            Entity context with relationships
        """
        graph_client = await self.get_graph_client()
        
        context = {
            "entity_type": entity_type,
            "entity_id": entity_id,
            "entity": None,
            "neighbors": [],
        }
        
        try:
            # Get the entity itself
            entity = await graph_client.get_entity(entity_type, entity_id)
            context["entity"] = entity
            
            # Get neighbors
            neighbors = await graph_client.get_neighbors(
                entity_type=entity_type,
                entity_id=entity_id,
                depth=depth,
            )
            context["neighbors"] = neighbors
            
        except Exception as e:
            logger.warning("Entity context retrieval failed", error=str(e))
        
        return context


# Global instance
_context_builder: Optional[ContextBuilder] = None


def get_context_builder() -> ContextBuilder:
    """Get or create context builder instance."""
    global _context_builder
    if _context_builder is None:
        _context_builder = ContextBuilder()
    return _context_builder