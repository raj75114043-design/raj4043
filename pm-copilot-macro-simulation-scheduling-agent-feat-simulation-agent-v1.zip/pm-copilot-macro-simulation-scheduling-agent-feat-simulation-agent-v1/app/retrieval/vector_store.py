"""
Vector Store
PGVector-based vector storage and similarity search
"""

from typing import Any, Dict, List, Optional, Tuple

import structlog
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.retrieval.semantic_search.embeddings import get_embedding_service

logger = structlog.get_logger(__name__)


class VectorStore:
    """
    Vector store using PGVector for similarity search.
    """
    
    def __init__(self, table_name: str = "document_embeddings"):
        """
        Initialize vector store.
        
        Args:
            table_name: Name of the embeddings table
        """
        self.table_name = table_name
        self.embedding_service = get_embedding_service()
    
    async def create_table(self, db: AsyncSession) -> None:
        """Create the embeddings table if it doesn't exist."""
        dimension = self.embedding_service.get_dimension()
        
        query = text(f"""
            CREATE TABLE IF NOT EXISTS {self.table_name} (
                id SERIAL PRIMARY KEY,
                content TEXT NOT NULL,
                metadata JSONB,
                embedding vector({dimension}),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        await db.execute(query)
        await db.commit()
        
        # Create index for similarity search
        index_query = text(f"""
            CREATE INDEX IF NOT EXISTS {self.table_name}_embedding_idx 
            ON {self.table_name} 
            USING ivfflat (embedding vector_cosine_ops)
            WITH (lists = 100)
        """)
        
        try:
            await db.execute(index_query)
            await db.commit()
        except Exception as e:
            logger.warning("Index creation skipped", error=str(e))
    
    async def add_documents(
        self,
        documents: List[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
        db: Optional[AsyncSession] = None,
    ) -> List[int]:
        """
        Add documents to the vector store.
        
        Args:
            documents: List of document texts
            metadatas: Optional list of metadata dicts
            db: Database session
            
        Returns:
            List of inserted document IDs
        """
        if db is None:
            async with get_db() as db:
                return await self._add_documents_impl(documents, metadatas, db)
        return await self._add_documents_impl(documents, metadatas, db)
    
    async def _add_documents_impl(
        self,
        documents: List[str],
        metadatas: Optional[List[Dict[str, Any]]],
        db: AsyncSession,
    ) -> List[int]:
        """Implementation of add_documents."""
        # Generate embeddings
        embeddings = await self.embedding_service.embed_texts(documents)
        
        if metadatas is None:
            metadatas = [{}] * len(documents)
        
        ids = []
        for doc, embedding, metadata in zip(documents, embeddings, metadatas):
            query = text(f"""
                INSERT INTO {self.table_name} (content, metadata, embedding)
                VALUES (:content, :metadata, :embedding)
                RETURNING id
            """)
            
            result = await db.execute(query, {
                "content": doc,
                "metadata": metadata,
                "embedding": embedding,
            })
            
            row = result.fetchone()
            if row:
                ids.append(row[0])
        
        await db.commit()
        return ids
    
    async def similarity_search(
        self,
        query: str,
        k: int = 5,
        filter_metadata: Optional[Dict[str, Any]] = None,
        db: Optional[AsyncSession] = None,
    ) -> List[Tuple[str, float, Dict[str, Any]]]:
        """
        Search for similar documents.
        
        Args:
            query: Search query
            k: Number of results to return
            filter_metadata: Optional metadata filter
            db: Database session
            
        Returns:
            List of (content, score, metadata) tuples
        """
        if db is None:
            async with get_db() as db:
                return await self._similarity_search_impl(query, k, filter_metadata, db)
        return await self._similarity_search_impl(query, k, filter_metadata, db)
    
    async def _similarity_search_impl(
        self,
        query: str,
        k: int,
        filter_metadata: Optional[Dict[str, Any]],
        db: AsyncSession,
    ) -> List[Tuple[str, float, Dict[str, Any]]]:
        """Implementation of similarity_search."""
        # Generate query embedding
        query_embedding = await self.embedding_service.embed_text(query)
        
        # Build query
        sql = f"""
            SELECT content, metadata, 1 - (embedding <=> :embedding) as similarity
            FROM {self.table_name}
        """
        
        if filter_metadata:
            conditions = []
            for key, value in filter_metadata.items():
                conditions.append(f"metadata->>'{key}' = :{key}")
            sql += " WHERE " + " AND ".join(conditions)
        
        sql += " ORDER BY embedding <=> :embedding LIMIT :k"
        
        params = {"embedding": query_embedding, "k": k}
        if filter_metadata:
            params.update(filter_metadata)
        
        result = await db.execute(text(sql), params)
        rows = result.fetchall()
        
        return [(row[0], row[2], row[1] or {}) for row in rows]


# Global instance
_vector_store: Optional[VectorStore] = None


def get_vector_store(table_name: str = "document_embeddings") -> VectorStore:
    """Get or create vector store instance."""
    global _vector_store
    if _vector_store is None:
        _vector_store = VectorStore(table_name)
    return _vector_store