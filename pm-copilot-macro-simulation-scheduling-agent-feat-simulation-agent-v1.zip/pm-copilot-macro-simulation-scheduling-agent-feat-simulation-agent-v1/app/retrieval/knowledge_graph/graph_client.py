"""
Graph Client
Neo4j/FalkorDB client for knowledge graph operations
"""

from typing import Any, Dict, List, Optional

import structlog

from app.core.config import settings

logger = structlog.get_logger(__name__)


class GraphClient:
    """
    Client for knowledge graph operations.
    Supports both Neo4j and FalkorDB backends.
    """
    
    def __init__(self, backend: str = "neo4j"):
        """
        Initialize graph client.
        
        Args:
            backend: Graph database backend (neo4j or falkordb)
        """
        self.backend = backend
        self._driver = None
    
    async def connect(self) -> None:
        """Establish connection to graph database."""
        if self.backend == "neo4j":
            try:
                from neo4j import AsyncGraphDatabase
                self._driver = AsyncGraphDatabase.driver(
                    settings.NEO4J_URI,
                    auth=(settings.NEO4J_USER, settings.NEO4J_PASSWORD),
                )
                logger.info("Connected to Neo4j")
            except ImportError:
                logger.warning("Neo4j driver not available, using mock mode")
        elif self.backend == "falkordb":
            try:
                import falkordb
                self._driver = falkordb.FalkorDB(
                    host=settings.FALKOR_HOST,
                    port=settings.FALKOR_PORT,
                )
                logger.info("Connected to FalkorDB")
            except ImportError:
                logger.warning("FalkorDB driver not available, using mock mode")
    
    async def close(self) -> None:
        """Close connection."""
        if self._driver and hasattr(self._driver, 'close'):
            await self._driver.close()
    
    async def execute_cypher(
        self,
        query: str,
        parameters: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Execute a Cypher query.
        
        Args:
            query: Cypher query string
            parameters: Query parameters
            
        Returns:
            List of result records
        """
        if not self._driver:
            logger.warning("No graph driver, returning mock data")
            return self._get_mock_result(query)
        
        try:
            if self.backend == "neo4j":
                async with self._driver.session() as session:
                    result = await session.run(query, parameters or {})
                    records = await result.data()
                    return records
            else:
                # FalkorDB
                graph = self._driver.select_graph("macro")
                result = graph.query(query, parameters)
                return [dict(r) for r in result.result_set]
        except Exception as e:
            logger.error("Cypher query failed", error=str(e))
            return []
    
    async def get_entity(
        self,
        entity_type: str,
        entity_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Get an entity by type and ID."""
        query = f"""
            MATCH (e:{entity_type} {{id: $id}})
            RETURN e
        """
        results = await self.execute_cypher(query, {"id": entity_id})
        return results[0] if results else None
    
    async def get_neighbors(
        self,
        entity_type: str,
        entity_id: str,
        relationship_type: Optional[str] = None,
        depth: int = 1,
    ) -> List[Dict[str, Any]]:
        """Get neighboring entities."""
        rel_pattern = f"[:{relationship_type}]" if relationship_type else "[]"
        query = f"""
            MATCH (e:{entity_type} {{id: $id}})-{rel_pattern}*1..{depth}-(n)
            RETURN DISTINCT n
        """
        return await self.execute_cypher(query, {"id": entity_id})
    
    async def find_path(
        self,
        start_type: str,
        start_id: str,
        end_type: str,
        end_id: str,
    ) -> List[Dict[str, Any]]:
        """Find shortest path between two entities."""
        query = f"""
            MATCH path = shortestPath(
                (start:{start_type} {{id: $start_id}})-[*]-(end:{end_type} {{id: $end_id}})
            )
            RETURN nodes(path) as nodes, relationships(path) as rels
        """
        return await self.execute_cypher(query, {
            "start_id": start_id,
            "end_id": end_id,
        })
    
    async def get_market_sites(self, market: str) -> List[Dict[str, Any]]:
        """Get all sites in a market."""
        query = """
            MATCH (m:Market {name: $market})-[:CONTAINS]->(s:Site)
            RETURN s.id as site_id, s.status as status, s.vendor as vendor
        """
        return await self.execute_cypher(query, {"market": market})
    
    async def get_site_dependencies(self, site_id: str) -> List[Dict[str, Any]]:
        """Get dependencies for a site."""
        query = """
            MATCH (s:Site {id: $site_id})-[:DEPENDS_ON]->(d)
            RETURN d.type as dependency_type, d.status as status, d.ready_date as ready_date
        """
        return await self.execute_cypher(query, {"site_id": site_id})
    
    async def get_vendor_sites(
        self,
        vendor: str,
        market: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Get sites assigned to a vendor."""
        if market:
            query = """
                MATCH (v:Vendor {name: $vendor})-[:ASSIGNED]->(s:Site)<-[:CONTAINS]-(m:Market {name: $market})
                RETURN s.id as site_id, s.status as status
            """
            return await self.execute_cypher(query, {"vendor": vendor, "market": market})
        else:
            query = """
                MATCH (v:Vendor {name: $vendor})-[:ASSIGNED]->(s:Site)
                RETURN s.id as site_id, s.status as status
            """
            return await self.execute_cypher(query, {"vendor": vendor})
    
    def _get_mock_result(self, query: str) -> List[Dict[str, Any]]:
        """Return mock data for development."""
        if "Market" in query:
            return [
                {"site_id": f"SITE-{i:05d}", "status": "ready", "vendor": "Vendor A"}
                for i in range(10)
            ]
        elif "Vendor" in query:
            return [
                {"site_id": f"SITE-{i:05d}", "status": "assigned"}
                for i in range(5)
            ]
        return []


# Global instance
_graph_client: Optional[GraphClient] = None


async def get_graph_client(backend: str = "neo4j") -> GraphClient:
    """Get or create graph client instance."""
    global _graph_client
    if _graph_client is None:
        _graph_client = GraphClient(backend)
        await _graph_client.connect()
    return _graph_client