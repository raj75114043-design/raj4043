"""
Health Check Endpoints
"""

from datetime import datetime
from typing import Dict, Any

from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

from app.core.config import settings
from app.db.database import get_db_session

router = APIRouter()


@router.get("/health")
async def health_check() -> Dict[str, Any]:
    """Basic health check endpoint."""
    return {
        "status": "healthy",
        "service": settings.APP_NAME,
        "version": "2.0.0",
        "timestamp": datetime.utcnow().isoformat(),
    }


@router.get("/health/ready")
async def readiness_check(
    db: AsyncSession = Depends(get_db_session),
) -> Dict[str, Any]:
    """
    Readiness check - verifies all dependencies are available.
    """
    checks = {
        "database": False,
        "unified_layer": False,
        "knowledge_graph": False,
    }
    
    # Check database
    try:
        await db.execute(text("SELECT 1"))
        checks["database"] = True
    except Exception:
        pass
    
    # Check unified layer
    try:
        from app.services.unified_layer_service import get_unified_layer_service
        service = await get_unified_layer_service()
        # Simple ping
        checks["unified_layer"] = True
    except Exception:
        pass
    
    # Check knowledge graph
    try:
        from app.services.kg_service import get_kg_service
        service = await get_kg_service()
        checks["knowledge_graph"] = True
    except Exception:
        pass
    
    all_healthy = all(checks.values())
    
    return {
        "status": "ready" if all_healthy else "degraded",
        "checks": checks,
        "timestamp": datetime.utcnow().isoformat(),
    }


@router.get("/health/live")
async def liveness_check() -> Dict[str, str]:
    """Liveness check - verifies the service is running."""
    return {"status": "alive"}