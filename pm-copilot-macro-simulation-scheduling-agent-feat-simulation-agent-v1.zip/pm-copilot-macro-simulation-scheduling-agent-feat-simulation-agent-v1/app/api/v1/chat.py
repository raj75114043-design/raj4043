"""
Chat Endpoints with SSE Streaming
Real-time chat interface for simulation agent
"""

import asyncio
import json
from datetime import datetime
from typing import Any, AsyncGenerator, Dict, Optional
from uuid import uuid4

import structlog
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sse_starlette.sse import EventSourceResponse

from app.core.config import settings
from app.core.models import ProjectTrack

router = APIRouter()
logger = structlog.get_logger(__name__)


# ============================================================================
# Request/Response Models
# ============================================================================

class ChatMessage(BaseModel):
    """Single chat message."""
    role: str = Field(..., description="Message role: user, assistant, system")
    content: str = Field(..., description="Message content")
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class ChatRequest(BaseModel):
    """Chat request body."""
    message: str = Field(..., description="User message")
    session_id: Optional[str] = Field(default=None)
    user_id: Optional[str] = Field(default=None)
    project_track: ProjectTrack = Field(default=ProjectTrack.TMO_RPM)
    history: list[ChatMessage] = Field(default_factory=list)


class ChatEvent(BaseModel):
    """SSE event for chat streaming."""
    event: str  # message, token, thinking, tool_call, error, done
    data: Dict[str, Any]


# ============================================================================
# SSE Streaming
# ============================================================================

async def generate_chat_events(
    message: str,
    session_id: str,
    project_track: ProjectTrack,
    history: list[ChatMessage],
) -> AsyncGenerator[str, None]:
    """
    Generate SSE events for chat streaming.
    
    Yields events in the format:
    event: <event_type>
    data: <json_data>
    """
    try:
        # Import the simulator agent
        from app.agents.simulator_agent.agent import stream_simulator
        
        # Send thinking event
        yield format_sse_event("thinking", {"message": "Analyzing your query..."})
        
        # Stream from the agent
        async for event in stream_simulator(
            query=message,
            session_id=session_id,
            project_track=project_track,
            history=[h.dict() for h in history],
        ):
            if event.get("type") == "token":
                yield format_sse_event("token", {"content": event["content"]})
            
            elif event.get("type") == "tool_call":
                yield format_sse_event("tool_call", {
                    "tool": event["tool"],
                    "input": event.get("input", {}),
                })
            
            elif event.get("type") == "tool_result":
                yield format_sse_event("tool_result", {
                    "tool": event["tool"],
                    "result": event.get("result", {}),
                })
            
            elif event.get("type") == "clarification":
                yield format_sse_event("clarification", {
                    "questions": event["questions"],
                    "context": event.get("context", {}),
                })
            
            elif event.get("type") == "simulation_start":
                yield format_sse_event("simulation_start", {
                    "models": event.get("models", []),
                    "parameters": event.get("parameters", {}),
                })
            
            elif event.get("type") == "simulation_progress":
                yield format_sse_event("simulation_progress", {
                    "step": event["step"],
                    "total_steps": event.get("total_steps", 0),
                    "message": event.get("message", ""),
                })
            
            elif event.get("type") == "result":
                yield format_sse_event("result", event["data"])
            
            elif event.get("type") == "message":
                yield format_sse_event("message", {"content": event["content"]})
        
        # Send done event
        yield format_sse_event("done", {"timestamp": datetime.utcnow().isoformat()})
        
    except Exception as e:
        logger.error("Chat streaming error", error=str(e), session_id=session_id)
        yield format_sse_event("error", {"message": str(e)})


def format_sse_event(event_type: str, data: Dict[str, Any]) -> str:
    """Format data as SSE event."""
    return f"event: {event_type}\ndata: {json.dumps(data)}\n\n"


# ============================================================================
# Endpoints
# ============================================================================

@router.post("/chat")
async def chat(request: ChatRequest):
    """
    Chat endpoint with SSE streaming.
    
    Returns a stream of events as the agent processes the query.
    """
    session_id = request.session_id or str(uuid4())
    
    logger.info(
        "Chat request received",
        session_id=session_id,
        message=request.message[:100],
        project_track=request.project_track,
    )
    
    return EventSourceResponse(
        generate_chat_events(
            message=request.message,
            session_id=session_id,
            project_track=request.project_track,
            history=request.history,
        ),
        media_type="text/event-stream",
    )


@router.post("/chat/sync")
async def chat_sync(request: ChatRequest) -> Dict[str, Any]:
    """
    Synchronous chat endpoint (non-streaming).
    
    Waits for complete response before returning.
    """
    session_id = request.session_id or str(uuid4())
    
    logger.info(
        "Sync chat request received",
        session_id=session_id,
        message=request.message[:100],
    )
    
    try:
        from app.agents.simulator_agent.agent import run_simulator
        
        result = await run_simulator(
            query=request.message,
            session_id=session_id,
            project_track=request.project_track,
            parameters=None,
        )
        
        return {
            "success": True,
            "session_id": session_id,
            "result": result.dict() if result else None,
            "timestamp": datetime.utcnow().isoformat(),
        }
        
    except Exception as e:
        logger.error("Sync chat failed", error=str(e))
        raise HTTPException(
            status_code=500,
            detail=str(e),
        )


@router.get("/chat/{session_id}/history")
async def get_chat_history(session_id: str) -> Dict[str, Any]:
    """
    Get chat history for a session.
    """
    from sqlalchemy import select
    from app.db.database import get_db
    from app.db.models import ChatHistory
    
    async with get_db() as db:
        result = await db.execute(
            select(ChatHistory)
            .where(ChatHistory.session_id == session_id)
            .order_by(ChatHistory.created_at)
        )
        messages = result.scalars().all()
    
    return {
        "session_id": session_id,
        "messages": [
            {
                "role": msg.role,
                "content": msg.content,
                "timestamp": msg.created_at.isoformat(),
            }
            for msg in messages
        ],
        "count": len(messages),
    }