"""
Agent Execution Endpoints
REST API for running simulations and schedules
"""

from datetime import datetime
from typing import Any, Dict, Optional
from uuid import uuid4

import structlog
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.models import (
    SimulationRequest,
    SimulationResponse,
    SimulationResult,
    SimulationStatus,
    SimulationIntent,
    ScheduleRequest,
    ScheduleResponse,
    HITLResponse,
    ProjectTrack,
)
from app.db.database import get_db_session
from app.db.models import SimulationRun, HITLSession

router = APIRouter()
logger = structlog.get_logger(__name__)


# ============================================================================
# Request/Response Models
# ============================================================================

class SimulateRequest(BaseModel):
    """Request body for simulation endpoint."""
    query: str = Field(..., description="Natural language simulation query")
    session_id: Optional[str] = Field(default=None, description="Session ID for HITL")
    user_id: Optional[str] = Field(default=None, description="User identifier")
    project_track: ProjectTrack = Field(default=ProjectTrack.TMO_RPM)
    parameters: Optional[Dict[str, Any]] = Field(default=None)


class HITLConfirmRequest(BaseModel):
    """Request to confirm HITL parameters."""
    session_id: str
    answers: Dict[str, Any]
    confirmed: bool = True


class SchedulePlanRequest(BaseModel):
    """Request body for schedule planning endpoint."""
    market: str
    target_sites: int
    target_date: str  # YYYY-MM-DD
    user_id: Optional[str] = None
    constraints: Optional[Dict[str, Any]] = None


# ============================================================================
# Simulation Endpoints
# ============================================================================

@router.post("/simulate", response_model=SimulationResponse)
async def run_simulation(
    request: SimulateRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db_session),
) -> SimulationResponse:
    """
    Run a simulation based on natural language query.
    
    This endpoint accepts what-if scenarios and returns simulation results.
    If clarification is needed, it will return HITL questions.
    """
    session_id = request.session_id or str(uuid4())
    
    logger.info(
        "Simulation request received",
        session_id=session_id,
        query=request.query[:100],
        project_track=request.project_track,
    )
    
    # Create simulation run record
    simulation_run = SimulationRun(
        session_id=session_id,
        user_id=request.user_id or "anonymous",
        query=request.query,
        parameters=request.parameters or {},
        status="pending",
    )
    db.add(simulation_run)
    await db.commit()
    
    try:
        # Import and run the simulator agent
        from app.agents.simulator_agent.agent import run_simulator
        
        result = await run_simulator(
            query=request.query,
            session_id=session_id,
            project_track=request.project_track,
            parameters=request.parameters,
        )
        
        # Update simulation run
        simulation_run.status = result.status.value
        simulation_run.result = result.dict() if result else {}
        simulation_run.completed_at = datetime.utcnow()
        await db.commit()
        
        # Check if HITL clarification is needed
        if result.status == SimulationStatus.PENDING_CLARIFICATION:
            return SimulationResponse(
                success=True,
                message="Clarification needed before simulation",
                clarification_needed=True,
                clarification_questions=result.clarification_questions,
                trace_id=str(simulation_run.id),
            )
        
        return SimulationResponse(
            success=True,
            message="Simulation completed successfully",
            result=result,
            trace_id=str(simulation_run.id),
        )
        
    except Exception as e:
        logger.error("Simulation failed", error=str(e), session_id=session_id)
        simulation_run.status = "failed"
        simulation_run.error_message = str(e)
        await db.commit()
        
        raise HTTPException(
            status_code=500,
            detail=f"Simulation failed: {str(e)}",
        )


@router.post("/simulate/confirm", response_model=SimulationResponse)
async def confirm_simulation(
    request: HITLConfirmRequest,
    db: AsyncSession = Depends(get_db_session),
) -> SimulationResponse:
    """
    Confirm HITL parameters and continue simulation.
    """
    logger.info(
        "HITL confirmation received",
        session_id=request.session_id,
        confirmed=request.confirmed,
    )
    
    # Get the HITL session
    from sqlalchemy import select
    result = await db.execute(
        select(HITLSession).where(HITLSession.session_id == request.session_id)
    )
    hitl_session = result.scalar_one_or_none()
    
    if not hitl_session:
        raise HTTPException(
            status_code=404,
            detail=f"HITL session not found: {request.session_id}",
        )
    
    # Update HITL session
    hitl_session.answers = request.answers
    hitl_session.status = "confirmed" if request.confirmed else "cancelled"
    hitl_session.confirmed_at = datetime.utcnow()
    await db.commit()
    
    if not request.confirmed:
        return SimulationResponse(
            success=False,
            message="Simulation cancelled by user",
        )
    
    try:
        # Continue simulation with confirmed parameters
        from app.agents.simulator_agent.agent import continue_simulation
        
        result = await continue_simulation(
            session_id=request.session_id,
            confirmed_answers=request.answers,
        )
        
        return SimulationResponse(
            success=True,
            message="Simulation completed successfully",
            result=result,
        )
        
    except Exception as e:
        logger.error("Simulation failed after confirmation", error=str(e))
        raise HTTPException(
            status_code=500,
            detail=f"Simulation failed: {str(e)}",
        )


# ============================================================================
# Schedule Endpoints
# ============================================================================

@router.post("/schedule", response_model=ScheduleResponse)
async def create_schedule(
    request: SchedulePlanRequest,
    db: AsyncSession = Depends(get_db_session),
) -> ScheduleResponse:
    """
    Create a schedule plan for site deployment.
    """
    logger.info(
        "Schedule request received",
        market=request.market,
        target_sites=request.target_sites,
        target_date=request.target_date,
    )
    
    try:
        from app.agents.scheduler_agent.agent import run_scheduler
        
        result = await run_scheduler(
            market=request.market,
            target_sites=request.target_sites,
            target_date=request.target_date,
            constraints=request.constraints,
        )
        
        return result
        
    except Exception as e:
        logger.error("Schedule creation failed", error=str(e))
        raise HTTPException(
            status_code=500,
            detail=f"Schedule creation failed: {str(e)}",
        )


# ============================================================================
# Scenario Endpoints
# ============================================================================

@router.get("/scenarios")
async def list_scenarios(
    project_track: Optional[ProjectTrack] = None,
) -> Dict[str, Any]:
    """
    List available simulation scenarios.
    """
    from app.services.unified_layer_service import get_unified_layer_service
    
    service = await get_unified_layer_service()
    scenarios = await service.search_simulation_scenarios(
        query="*",
        project_track=project_track.value if project_track else None,
        limit=100,
    )
    
    return {
        "scenarios": scenarios,
        "count": len(scenarios),
    }


@router.get("/scenarios/{scenario_id}")
async def get_scenario(scenario_id: str) -> Dict[str, Any]:
    """
    Get details of a specific scenario.
    """
    from app.services.unified_layer_service import get_unified_layer_service
    
    service = await get_unified_layer_service()
    scenario = await service.get_simulation_scenario(scenario_id)
    
    if not scenario:
        raise HTTPException(
            status_code=404,
            detail=f"Scenario not found: {scenario_id}",
        )
    
    return scenario