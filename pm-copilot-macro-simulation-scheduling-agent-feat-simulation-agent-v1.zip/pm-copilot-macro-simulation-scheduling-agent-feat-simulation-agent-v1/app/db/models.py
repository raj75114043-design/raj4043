"""
SQLAlchemy Database Models
Defines the database schema for agent utility tables
"""

from datetime import datetime
from typing import Any, Dict, Optional
from uuid import uuid4

from sqlalchemy import (
    JSON,
    Boolean,
    Column,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    Index,
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from app.db.database import Base


def generate_uuid() -> str:
    """Generate a new UUID string."""
    return str(uuid4())


class ChatHistory(Base):
    """Chat history table for storing conversation sessions."""
    
    __tablename__ = "chat_history"
    
    id = Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    session_id = Column(String(255), nullable=False, index=True)
    user_id = Column(String(255), nullable=False, index=True)
    role = Column(String(50), nullable=False)  # user, assistant, system
    content = Column(Text, nullable=False)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    __table_args__ = (
        Index("ix_chat_history_session_user", "session_id", "user_id"),
    )


class HITLSession(Base):
    """HITL session table for tracking human-in-the-loop interactions."""
    
    __tablename__ = "hitl_sessions"
    
    id = Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    session_id = Column(String(255), nullable=False, unique=True, index=True)
    user_id = Column(String(255), nullable=False, index=True)
    status = Column(String(50), nullable=False, default="pending")  # pending, confirmed, timeout, cancelled
    questions = Column(JSON, nullable=False, default=list)
    answers = Column(JSON, default=dict)
    context = Column(JSON, default=dict)
    timeout_at = Column(DateTime, nullable=True)
    confirmed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class SimulationRun(Base):
    """Simulation run table for tracking simulation executions."""
    
    __tablename__ = "simulation_runs"
    
    id = Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    session_id = Column(String(255), nullable=False, index=True)
    user_id = Column(String(255), nullable=False, index=True)
    query = Column(Text, nullable=False)
    intent = Column(String(100), nullable=True)
    parameters = Column(JSON, default=dict)
    status = Column(String(50), nullable=False, default="pending")
    result = Column(JSON, default=dict)
    error_message = Column(Text, nullable=True)
    execution_trace = Column(JSON, default=list)
    duration_ms = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    completed_at = Column(DateTime, nullable=True)
    
    __table_args__ = (
        Index("ix_simulation_runs_session_user", "session_id", "user_id"),
        Index("ix_simulation_runs_status", "status"),
    )


class AgentTrace(Base):
    """Agent execution trace table for observability."""
    
    __tablename__ = "agent_traces"
    
    id = Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    simulation_run_id = Column(UUID(as_uuid=False), ForeignKey("simulation_runs.id"), nullable=False)
    agent_name = Column(String(100), nullable=False)
    action = Column(String(255), nullable=False)
    input_data = Column(JSON, default=dict)
    output_data = Column(JSON, default=dict)
    duration_ms = Column(Integer, nullable=True)
    error = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    
    simulation_run = relationship("SimulationRun", backref="traces")
    
    __table_args__ = (
        Index("ix_agent_traces_simulation_run", "simulation_run_id"),
        Index("ix_agent_traces_agent_name", "agent_name"),
    )


class UserFeedback(Base):
    """User feedback table for tracking simulation feedback."""
    
    __tablename__ = "user_feedback"
    
    id = Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    session_id = Column(String(255), nullable=False, index=True)
    simulation_run_id = Column(UUID(as_uuid=False), ForeignKey("simulation_runs.id"), nullable=True)
    user_id = Column(String(255), nullable=False, index=True)
    rating = Column(Integer, nullable=True)  # 1-5
    feedback_type = Column(String(50), nullable=True)  # thumbs_up, thumbs_down, correction
    feedback_text = Column(Text, nullable=True)
    metadata = Column(JSON, default=dict)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)


class PromptTemplate(Base):
    """Prompt template table for managing agent prompts."""
    
    __tablename__ = "prompt_templates"
    
    id = Column(UUID(as_uuid=False), primary_key=True, default=generate_uuid)
    name = Column(String(255), nullable=False, unique=True, index=True)
    agent_name = Column(String(100), nullable=False, index=True)
    version = Column(Integer, nullable=False, default=1)
    template = Column(Text, nullable=False)
    description = Column(Text, nullable=True)
    variables = Column(JSON, default=list)  # List of expected variables
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    __table_args__ = (
        Index("ix_prompt_templates_agent_active", "agent_name", "is_active"),
    )