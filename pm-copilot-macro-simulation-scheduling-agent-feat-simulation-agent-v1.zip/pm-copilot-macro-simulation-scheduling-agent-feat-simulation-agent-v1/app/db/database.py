"""
Provides asynchronous database configuration and session management
for a PostgreSQL backend using SQLAlchemy 2.0 async capabilities.

Key Features:
- Async engine initialization with connection pooling.
- Centralized session factory configuration.
- Context-managed transactional session handling.
- Automatic commit/rollback with proper error logging.
- Application-wide singleton database manager instance.
- FastAPI-compatible dependency injection helper.

This module ensures consistent, safe, and scalable database access
across the application while encapsulating engine and session lifecycle
management.
"""

from contextlib import asynccontextmanager
from typing import AsyncGenerator, Optional

import structlog
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import declarative_base

from app.core.config import settings

logger = structlog.get_logger(__name__)

# Global engine and session factory
_engine: Optional[AsyncEngine] = None
_session_factory: Optional[async_sessionmaker[AsyncSession]] = None

# Base class for SQLAlchemy models
Base = declarative_base()


async def init_db() -> None:
    """Initialize database connection."""
    global _engine, _session_factory
    
    logger.info("Initializing database connection", url=settings.DATABASE_URL[:50] + "...")
    
    _engine = create_async_engine(
        settings.DATABASE_URL,
        pool_size=settings.DATABASE_POOL_SIZE,
        max_overflow=settings.DATABASE_MAX_OVERFLOW,
        pool_pre_ping=True,
        echo=settings.DEBUG,
    )
    
    _session_factory = async_sessionmaker(
        bind=_engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autocommit=False,
        autoflush=False,
    )
    
    logger.info("Database initialized successfully")


async def close_db() -> None:
    """Close database connection."""
    global _engine
    
    if _engine:
        logger.info("Closing database connection")
        await _engine.dispose()
        _engine = None
        logger.info("Database connection closed")


@asynccontextmanager
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """Get async database session."""
    if _session_factory is None:
        raise RuntimeError("Database not initialized. Call init_db() first.")
    
    session = _session_factory()
    try:
        yield session
        await session.commit()
    except Exception as e:
        await session.rollback()
        logger.error("Database session error", error=str(e))
        raise
    finally:
        await session.close()


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency for database session."""
    async with get_db() as session:
        yield session