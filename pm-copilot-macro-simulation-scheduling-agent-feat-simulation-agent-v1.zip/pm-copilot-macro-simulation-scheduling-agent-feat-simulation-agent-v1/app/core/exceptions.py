"""
Custom Exceptions for Simulator & Scheduler Agent
Nokia MACRO Project - PM CoPilot Phase 2
"""

from typing import Optional, Dict, Any


class SimulatorBaseException(Exception):
    """Base exception for all simulator/scheduler errors."""
    
    def __init__(
        self,
        message: str,
        error_code: str = "SIMULATOR_ERROR",
        details: Optional[Dict[str, Any]] = None
    ):
        self.message = message
        self.error_code = error_code
        self.details = details or {}
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "error_code": self.error_code,
            "message": self.message,
            "details": self.details
        }


# HITL Exceptions
class HITLException(SimulatorBaseException):
    """Base exception for Human-in-the-Loop operations."""
    pass


class HITLTimeoutException(HITLException):
    """Raised when HITL confirmation times out."""
    
    def __init__(self, timeout_seconds: int, query: str):
        super().__init__(
            message=f"HITL confirmation timed out after {timeout_seconds} seconds",
            error_code="HITL_TIMEOUT",
            details={"timeout_seconds": timeout_seconds, "query": query}
        )


class HITLCancelledException(HITLException):
    """Raised when user cancels HITL operation."""
    
    def __init__(self, reason: Optional[str] = None):
        super().__init__(
            message="User cancelled the simulation request",
            error_code="HITL_CANCELLED",
            details={"reason": reason}
        )


class HITLMaxClarificationsException(HITLException):
    """Raised when max clarification attempts exceeded."""
    
    def __init__(self, max_attempts: int):
        super().__init__(
            message=f"Maximum clarification attempts ({max_attempts}) exceeded",
            error_code="HITL_MAX_CLARIFICATIONS",
            details={"max_attempts": max_attempts}
        )


# Query Refinement Exceptions
class QueryRefinementException(SimulatorBaseException):
    """Base exception for query refinement errors."""
    pass


class AmbiguousQueryException(QueryRefinementException):
    """Raised when query cannot be unambiguously interpreted."""
    
    def __init__(self, query: str, missing_params: list):
        super().__init__(
            message="Query is ambiguous and requires clarification",
            error_code="AMBIGUOUS_QUERY",
            details={"query": query, "missing_parameters": missing_params}
        )


class InvalidIntentException(QueryRefinementException):
    """Raised when query intent cannot be classified."""
    
    def __init__(self, query: str):
        super().__init__(
            message="Unable to classify query intent",
            error_code="INVALID_INTENT",
            details={"query": query}
        )


# Data Agent Exceptions
class DataAgentException(SimulatorBaseException):
    """Base exception for data agent errors."""
    pass


class DataNotFoundError(DataAgentException):
    """Raised when required data is not found."""
    
    def __init__(self, data_type: str, filters: Optional[Dict] = None):
        super().__init__(
            message=f"Required data not found: {data_type}",
            error_code="DATA_NOT_FOUND",
            details={"data_type": data_type, "filters": filters}
        )


class SQLExecutionError(DataAgentException):
    """Raised when SQL query execution fails."""
    
    def __init__(self, query: str, error: str):
        super().__init__(
            message="SQL query execution failed",
            error_code="SQL_EXECUTION_ERROR",
            details={"query": query, "error": error}
        )


class InsufficientDataError(DataAgentException):
    """Raised when data is insufficient for simulation."""
    
    def __init__(self, required_fields: list, available_fields: list):
        super().__init__(
            message="Insufficient data available for simulation",
            error_code="INSUFFICIENT_DATA",
            details={
                "required_fields": required_fields,
                "available_fields": available_fields,
                "missing_fields": list(set(required_fields) - set(available_fields))
            }
        )


# Simulation Engine Exceptions
class SimulationEngineException(SimulatorBaseException):
    """Base exception for simulation engine errors."""
    pass


class InvalidSimulationParameters(SimulationEngineException):
    """Raised when simulation parameters are invalid."""
    
    def __init__(self, param_name: str, value: Any, expected: str):
        super().__init__(
            message=f"Invalid simulation parameter: {param_name}",
            error_code="INVALID_SIMULATION_PARAM",
            details={
                "parameter": param_name,
                "value": value,
                "expected": expected
            }
        )


class SimulationTimeoutError(SimulationEngineException):
    """Raised when simulation exceeds time limit."""
    
    def __init__(self, timeout_seconds: int, scenario_type: str):
        super().__init__(
            message=f"Simulation timed out after {timeout_seconds} seconds",
            error_code="SIMULATION_TIMEOUT",
            details={
                "timeout_seconds": timeout_seconds,
                "scenario_type": scenario_type
            }
        )


class ModelNotFoundError(SimulationEngineException):
    """Raised when required simulation model is not found."""
    
    def __init__(self, model_name: str):
        super().__init__(
            message=f"Simulation model not found: {model_name}",
            error_code="MODEL_NOT_FOUND",
            details={"model_name": model_name}
        )


class InfeasibleScenarioError(SimulationEngineException):
    """Raised when scenario is mathematically infeasible."""
    
    def __init__(self, reason: str, constraints: Dict[str, Any]):
        super().__init__(
            message=f"Scenario is infeasible: {reason}",
            error_code="INFEASIBLE_SCENARIO",
            details={"reason": reason, "constraints": constraints}
        )


# Scheduler Exceptions
class SchedulerException(SimulatorBaseException):
    """Base exception for scheduler agent errors."""
    pass


class ResourceConflictError(SchedulerException):
    """Raised when resource allocation conflict occurs."""
    
    def __init__(self, resource_type: str, conflict_details: Dict):
        super().__init__(
            message=f"Resource conflict detected for: {resource_type}",
            error_code="RESOURCE_CONFLICT",
            details={"resource_type": resource_type, "conflict": conflict_details}
        )


class DependencyViolationError(SchedulerException):
    """Raised when scheduling violates dependencies."""
    
    def __init__(self, task: str, dependency: str, violation_type: str):
        super().__init__(
            message=f"Dependency violation: {task} -> {dependency}",
            error_code="DEPENDENCY_VIOLATION",
            details={
                "task": task,
                "dependency": dependency,
                "violation_type": violation_type
            }
        )


class CapacityExceededError(SchedulerException):
    """Raised when capacity limits are exceeded."""
    
    def __init__(self, resource: str, required: float, available: float):
        super().__init__(
            message=f"Capacity exceeded for {resource}",
            error_code="CAPACITY_EXCEEDED",
            details={
                "resource": resource,
                "required": required,
                "available": available,
                "deficit": required - available
            }
        )


# External Service Exceptions
class UnifiedContextServiceError(SimulatorBaseException):
    """Raised when Unified Context Layer service fails."""
    
    def __init__(self, operation: str, error: str):
        super().__init__(
            message=f"Unified Context Layer error: {operation}",
            error_code="UNIFIED_CONTEXT_ERROR",
            details={"operation": operation, "error": error}
        )


class KnowledgeGraphServiceError(SimulatorBaseException):
    """Raised when Knowledge Graph service fails."""
    
    def __init__(self, operation: str, error: str):
        super().__init__(
            message=f"Knowledge Graph service error: {operation}",
            error_code="KNOWLEDGE_GRAPH_ERROR",
            details={"operation": operation, "error": error}
        )


class LLMServiceError(SimulatorBaseException):
    """Raised when LLM service fails."""
    
    def __init__(self, provider: str, error: str):
        super().__init__(
            message=f"LLM service error from {provider}",
            error_code="LLM_SERVICE_ERROR",
            details={"provider": provider, "error": error}
        )