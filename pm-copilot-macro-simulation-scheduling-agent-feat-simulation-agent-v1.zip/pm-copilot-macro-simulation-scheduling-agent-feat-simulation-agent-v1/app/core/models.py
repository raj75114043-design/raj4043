"""
Core Pydantic Models
Shared data models across the application
"""

from datetime import date, datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, Field


# ============================================================================
# Enums
# ============================================================================

class SimulationIntent(str, Enum):
    """Types of simulation scenarios."""
    SCHEDULE = "schedule"
    RESOURCE_IMPACT = "resource_impact"
    PROCESS_CHANGE = "process_change"
    RISK_ASSESSMENT = "risk_assessment"
    VENDOR_PERFORMANCE = "vendor_performance"
    CAPACITY_PLANNING = "capacity_planning"
    WHAT_IF = "what_if"


class SimulationStatus(str, Enum):
    """Status of simulation execution."""
    PENDING_CLARIFICATION = "pending_clarification"
    CONFIRMED = "confirmed"
    PLANNING = "planning"
    DATA_COLLECTION = "data_collection"
    EXECUTING = "executing"
    ANALYZING = "analyzing"
    COMPLETED = "completed"
    FAILED = "failed"


class ProjectTrack(str, Enum):
    """Nokia MACRO project tracks."""
    TMO_RPM = "TMO_RPM"  # Telecom Rollout Project Management
    NAS = "NAS"          # Network Activation Services
    DEC = "DEC"          # Delivery Excellence & Compliance


class SiteStatus(str, Enum):
    """Site deployment status."""
    NOT_STARTED = "not_started"
    IN_PROGRESS = "in_progress"
    BLOCKED = "blocked"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class PrerequisiteType(str, Enum):
    """Types of site prerequisites."""
    POWER = "power"
    FIBER = "fiber"
    SITE_ACCESS = "site_access"
    PERMITS = "permits"
    MATERIAL = "material"
    INTP = "intp"
    NTP = "ntp"
    SPO = "spo"


# ============================================================================
# Base Models
# ============================================================================

class BaseRequest(BaseModel):
    """Base request model with common fields."""
    session_id: Optional[str] = None
    user_id: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)


class BaseResponse(BaseModel):
    """Base response model with common fields."""
    success: bool = True
    message: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    trace_id: Optional[str] = None


# ============================================================================
# Simulation Models
# ============================================================================

class TimeFrame(BaseModel):
    """Time frame for simulation."""
    start_date: date
    end_date: date
    working_days_per_week: int = 5
    holidays: List[date] = Field(default_factory=list)


class SimulationConstraints(BaseModel):
    """Constraints for simulation."""
    crew_productivity: float = 1.0  # sites/crew/day
    prerequisite_lead_times: str = "standard"
    max_crews: Optional[int] = None
    buffer_days: int = 0


class SimulationParameters(BaseModel):
    """Extracted and confirmed simulation parameters."""
    market: Optional[str] = None
    region: Optional[str] = None
    target_sites: Optional[int] = None
    timeframe: Optional[TimeFrame] = None
    constraints: Optional[SimulationConstraints] = None
    vendors: Optional[List[str]] = None
    site_types: Optional[List[str]] = None


class ClarificationQuestion(BaseModel):
    """Question for HITL clarification."""
    question: str
    options: Optional[List[str]] = None
    default_value: Optional[Any] = None
    required: bool = True


class SimulationRequest(BaseRequest):
    """Request to run a simulation."""
    query: str
    intent: Optional[SimulationIntent] = None
    parameters: Optional[SimulationParameters] = None
    project_track: ProjectTrack = ProjectTrack.TMO_RPM


class SimulationResult(BaseModel):
    """Result from simulation engine."""
    scenario_id: str
    status: SimulationStatus
    parameters: SimulationParameters
    weekly_plan: Optional[List[Dict[str, Any]]] = None
    feasibility: Optional[Dict[str, Any]] = None
    risks: Optional[List[Dict[str, Any]]] = None
    recommendations: Optional[List[str]] = None
    confidence_level: Optional[float] = None
    execution_trace: Optional[List[Dict[str, Any]]] = None


class SimulationResponse(BaseResponse):
    """Response from simulation."""
    result: Optional[SimulationResult] = None
    clarification_needed: bool = False
    clarification_questions: Optional[List[ClarificationQuestion]] = None


# ============================================================================
# Scheduler Models
# ============================================================================

class ScheduleTask(BaseModel):
    """Individual task in a schedule."""
    task_id: str
    site_code: str
    task_type: str
    planned_start: date
    planned_end: date
    actual_start: Optional[date] = None
    actual_end: Optional[date] = None
    assigned_crew: Optional[str] = None
    assigned_vendor: Optional[str] = None
    dependencies: List[str] = Field(default_factory=list)
    status: SiteStatus = SiteStatus.NOT_STARTED


class WeeklyPlan(BaseModel):
    """Weekly execution plan."""
    week_number: int
    start_date: date
    end_date: date
    sites_ready: int
    sites_planned: int
    sites_completed: int
    crew_capacity: int
    crew_utilization: float
    blockers: List[str] = Field(default_factory=list)
    actions: List[str] = Field(default_factory=list)


class ScheduleRequest(BaseRequest):
    """Request to create a schedule."""
    market: str
    target_sites: int
    target_date: date
    constraints: Optional[SimulationConstraints] = None


class ScheduleResponse(BaseResponse):
    """Response with schedule plan."""
    weekly_plans: List[WeeklyPlan] = Field(default_factory=list)
    total_weeks: int = 0
    achievable_sites: int = 0
    gap: int = 0
    risks: List[str] = Field(default_factory=list)


# ============================================================================
# Data Models (from Foundation Layer)
# ============================================================================

class SiteData(BaseModel):
    """Site data from database."""
    site_code: str
    project_id: str
    market: str
    region: Optional[str] = None
    status: SiteStatus
    vendor: Optional[str] = None
    prerequisites: Dict[PrerequisiteType, bool] = Field(default_factory=dict)
    milestone_dates: Dict[str, Optional[date]] = Field(default_factory=dict)


class VendorCapacity(BaseModel):
    """Vendor capacity information."""
    vendor_name: str
    market: str
    total_crews: int
    available_crews: int
    sites_assigned: int
    productivity_rate: float = 1.0


class PrerequisiteStatus(BaseModel):
    """Prerequisite readiness status."""
    prerequisite_type: PrerequisiteType
    total_sites: int
    ready_sites: int
    blocked_sites: int
    avg_lead_time_days: float


# ============================================================================
# HITL Models
# ============================================================================

class HITLRequest(BaseModel):
    """HITL clarification request."""
    session_id: str
    questions: List[ClarificationQuestion]
    context: Dict[str, Any] = Field(default_factory=dict)
    timeout_seconds: int = 300


class HITLResponse(BaseModel):
    """HITL clarification response."""
    session_id: str
    answers: Dict[str, Any]
    confirmed: bool = False
    timestamp: datetime = Field(default_factory=datetime.utcnow)


# ============================================================================
# Agent State Models
# ============================================================================

class AgentMessage(BaseModel):
    """Message in agent communication."""
    role: str  # "user", "assistant", "system", "tool"
    content: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class TraceStep(BaseModel):
    """Single step in execution trace."""
    step_id: str
    agent: str
    action: str
    input: Dict[str, Any]
    output: Dict[str, Any]
    duration_ms: int
    timestamp: datetime = Field(default_factory=datetime.utcnow)