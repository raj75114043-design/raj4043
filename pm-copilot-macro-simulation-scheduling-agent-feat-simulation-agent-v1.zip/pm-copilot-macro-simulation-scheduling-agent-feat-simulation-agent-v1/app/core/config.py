"""
Application Configuration
Manages all environment variables and settings
"""

from functools import lru_cache
from typing import List, Optional

from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    # Application
    APP_NAME: str = "simulator-scheduler-agent"
    APP_ENV: str = "development"
    DEBUG: bool = True
    LOG_LEVEL: str = "INFO"
    
    # Server
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    
    # Database
    DATABASE_URL: str = "postgresql+asyncpg://postgres:password@localhost:5432/macro_db"
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20
    
    # LLM Settings
    OPENAI_API_KEY: Optional[str] = None
    OPENAI_MODEL: str = "gpt-4-turbo-preview"
    ANTHROPIC_API_KEY: Optional[str] = None
    ANTHROPIC_MODEL: str = "claude-3-sonnet-20240229"
    LLM_TEMPERATURE: float = 0.1
    LLM_MAX_TOKENS: int = 4096
    
    # Unified/Foundation Layer
    UNIFIED_LAYER_URL: str = "http://global-context-api:8000"
    UNIFIED_LAYER_API_KEY: Optional[str] = None
    
    # Knowledge Graph
    KG_API_URL: str = "http://knowledge-graph-api:8000"
    KG_API_KEY: Optional[str] = None
    NEO4J_URI: str = "bolt://localhost:7687"
    NEO4J_USER: str = "neo4j"
    NEO4J_PASSWORD: str = "password"
    FALKOR_URI: str = "redis://localhost:6379"
    
    # Vector Database
    PGVECTOR_HOST: str = "localhost"
    PGVECTOR_PORT: int = 5432
    PGVECTOR_DATABASE: str = "macro_vector_db"
    PGVECTOR_USER: str = "postgres"
    PGVECTOR_PASSWORD: str = "password"
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379/0"
    
    # HITL Settings
    HITL_TIMEOUT_SECONDS: int = 300
    HITL_MAX_CLARIFICATIONS: int = 3
    
    # Simulation Settings
    SIMULATION_MAX_WEEKS: int = 52
    SIMULATION_DEFAULT_WORKING_DAYS: int = 5
    SIMULATION_DEFAULT_CREW_PRODUCTIVITY: float = 1.0
    
    # Scheduler Settings
    SCHEDULER_MAX_LOOKAHEAD_WEEKS: int = 12
    SCHEDULER_DEFAULT_BUFFER_DAYS: int = 2
    
    # Observability
    OTEL_EXPORTER_OTLP_ENDPOINT: str = "http://localhost:4317"
    OTEL_SERVICE_NAME: str = "simulator-scheduler-agent"
    
    # Security
    JWT_SECRET_KEY: str = "your-jwt-secret-key"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # CORS
    CORS_ORIGINS: List[str] = Field(default_factory=lambda: ["*"])
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()


settings = get_settings()