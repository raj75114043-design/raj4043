# Simulator & Scheduler Agent — Project Documentation

## 1) What this project is

`simulator_scheduler_agent` is a Python 3.11+ service intended to expose:

- A **FastAPI HTTP API** (health + agent endpoints + chat/SSE streaming)
- Two **LangGraph** graphs (agents):
  - `simulator`: multi-step “what-if” simulation workflow (with HITL clarification)
  - `scheduler`: deterministic schedule planning workflow
- Integrations to:
  - Postgres (async SQLAlchemy) for persistence + LangGraph checkpointing
  - A “Unified/Foundation Layer” HTTP API for enterprise data access
  - A Knowledge Graph HTTP API (and/or Neo4j/Falkor configuration)

The graph definitions are also declared in `langgraph.json`.

## 2) High-level architecture

### 2.1 Components

- **API Layer**: `app/api/v1/*`
  - `health.py`: readiness/liveness
  - `chat.py`: chat + SSE streaming to simulator agent (and additional endpoints)
  - `agents.py`: agent-focused endpoints (simulate/schedule/scenarios)
- **Agents**: `app/agents/*`
  - `simulator_agent`: LangGraph state machine (orchestrated workflow)
  - `scheduler_agent`: linear schedule-planning pipeline
  - `shared`: common nodes/tools/checkpointing/streaming utilities
- **Core**: `app/core/*`
  - `config.py`: environment-driven settings
  - `models.py`: pydantic models/enums shared across the system
  - `logging.py`: structured logging configuration
- **Persistence**: `app/db/*`
  - `database.py`: async engine/session, FastAPI dependency
  - `models.py`: chat/HITL/simulation runs + templates + traces
- **Retrieval/Data access**: `app/retrieval/*` and `app/services/*`
  - `services/unified_layer_service.py`: HTTP client wrapper (foundation data)
  - `services/kg_service.py`: HTTP client wrapper (knowledge graph)
  - `retrieval/context_builder.py`, `vector_store.py`, `embeddings.py`: context construction + vector retrieval patterns

### 2.2 Agent runtime flow (conceptual)

```mermaid
flowchart TD
  API["FastAPI endpoint"] -->|invokes| Graph["LangGraph compiled graph"]
  Graph --> Nodes["Agent nodes (LLM + tools + services)"]
  Nodes --> State["Typed state (SimulatorState / SchedulerState)"]
  Nodes --> Checkpointer["Checkpointing (Postgres)"]
  Nodes --> DB["SQLAlchemy async DB (runs, HITL, history)"]
  Nodes --> Services["Unified Layer + KG services (HTTP)"]
```

## 3) Repository layout

Top level:

- `pyproject.toml`: package metadata + dev tooling config (black/isort/mypy/pytest)
- `requirements.txt`: pinned runtime + dev dependencies
- `langgraph.json`: LangGraph graph registry + env var mapping + checkpointer config
- `docker/`: Dockerfile + docker-compose + init SQL
- `app/`: application code
- `tests/`: pytest suite

Code layout (key paths):

- `app/core/config.py`: `Settings` loaded from environment / `.env`
- `app/core/models.py`: shared enums + request/response schemas (Pydantic)
- `app/agents/simulator_agent/agent.py`: defines `simulator_graph` and `run_simulator()/stream_simulator()/continue_simulation()`
- `app/agents/scheduler_agent/agent.py`: defines `scheduler_graph` and `run_scheduler()/stream_scheduler()`
- `app/api/v1/chat.py`: SSE + chat endpoints (streams tokens/events from simulator)
- `app/api/v1/agents.py`: agent endpoints for simulate/schedule/scenarios
- `app/db/database.py`: async Postgres engine + sessions
- `app/db/models.py`: tables for runs/HITL/history/traces/templates/etc.

## 4) Configuration & environment variables

Configuration is defined in `app/core/config.py` via `pydantic-settings`.

Common env vars:

- App/server: `APP_ENV`, `DEBUG`, `LOG_LEVEL`, `HOST`, `PORT`
- LLM:
  - `OPENAI_API_KEY`, `OPENAI_MODEL`
  - `ANTHROPIC_API_KEY`, `ANTHROPIC_MODEL`
  - `LLM_TEMPERATURE`, `LLM_MAX_TOKENS`
- Database:
  - `DATABASE_URL` (also used by `langgraph.json` checkpointer config)
  - pool sizing: `DATABASE_POOL_SIZE`, `DATABASE_MAX_OVERFLOW`
- External services:
  - `UNIFIED_LAYER_URL`, `UNIFIED_LAYER_API_KEY`
  - `KG_API_URL`, `KG_API_KEY`
- KG DB configs (if used directly): `NEO4J_URI`, `NEO4J_USER`, `NEO4J_PASSWORD`, `FALKOR_URI`

`langgraph.json` additionally maps env vars expected by LangGraph and declares two graphs:

- `app.agents.simulator_agent.agent:simulator_graph`
- `app.agents.scheduler_agent.agent:scheduler_graph`

## 5) The Simulator Agent (LangGraph)

### 5.1 Purpose

The simulator agent is designed to take a natural language query (e.g., “If we add two integration crews in Chicago, can we hit 100 sites by end of Q2?”), extract parameters, optionally request clarification, collect required data, run a simulation engine, analyze results, and generate a final structured output.

### 5.2 State model

`app/agents/simulator_agent/state.py` defines `SimulatorState` as a `TypedDict` with:

- Session + query: `session_id`, `user_id`, `project_track`, `query`
- LLM context: `messages` (LangGraph `add_messages` reducer)
- Understanding + HITL: `intent`, `extracted_entities`, `clarification_needed`, `clarification_questions`, `confirmed_answers`, etc.
- Execution lifecycle: `status` (`SimulationStatus`), timestamps
- Outputs: `simulation_results`, `analysis_results`, `final_output`
- Observability: `execution_trace`, retry fields

### 5.3 Graph structure

`app/agents/simulator_agent/agent.py:build_simulator_graph()` compiles a graph with these conceptual nodes:

- `orchestrator`: routes next action based on state/status
- `query_refiner`: intent/entity extraction; builds clarification questions if needed
- `planner`: decides data requirements + models to run
- `data_collector`: fetches required datasets from services/tools
- `simulator`: runs the simulation engine given parameters + collected data
- `analyzer`: derives risks/recommendations/feasibility signals
- `output_generator`: formats final output payload
- `hitl_wait`: terminal state while waiting for user confirmation

### 5.4 Node responsibilities (what to look for)

Node modules live under `app/agents/simulator_agent/nodes/`:

- `query_refiner.py`: LLM JSON extraction → `intent`, `missing_parameters`, HITL questions
- `planner.py`: translates intent/parameters into a plan: data requirements + models needed
- `data_collector.py`: queries “Unified Layer”/KG and/or cached tools to build `collected_data`
- `simulator.py`: invokes the simulation engine and writes `simulation_results`
- `analyzer.py`: post-processes results into risks/recommendations
- `output_generator.py`: packages `final_output`
- `orchestartor.py`: orchestrator implementation (routes state transitions)

### 5.5 Simulation engine

`app/agents/simulator_agent/simulation_engine/engine.py` contains an internal `SimulationEngine` that composes multiple “models” (calendar/prerequisite/capacity/schedule/impact/risk) and returns:

- per-model outputs
- `combined_result`
- execution timings

This engine is invoked by the simulator node and is designed to run with data gathered from the retrieval/services layer.

## 6) The Scheduler Agent (LangGraph)

### 6.1 Purpose

The scheduler agent produces a plan for a given market and time window:

- Fetch scheduling context (sites, crews, prerequisites)
- Create a weekly plan based on capacity
- Create a daily schedule (first N weeks/days) with task generation
- Generate final output summary + risks + fast-track opportunities

### 6.2 State model

`app/agents/scheduler_agent/state.py` defines `SchedulerState`:

- Inputs: `market`, `start_date`, `end_date`, `target_sites`, `working_days_per_week`
- Retrieved data: `available_sites`, `crew_availability`, `prereq_status`, `vendor_capacity`
- Outputs: `weekly_plan`, `daily_plan`, `final_schedule`
- Trace/status/error fields

### 6.3 Graph structure

`app/agents/scheduler_agent/agent.py:build_scheduler_graph()`:

```mermaid
flowchart LR
  A["fetch_data"] --> B["create_weekly_plan"] --> C["create_daily_schedule"] --> D["generate_output"] --> E["END"]
```

Node implementations are in `app/agents/scheduler_agent/nodes.py`.

## 7) API layer

> Note: The routers in `app/api/v1/*` define relative paths like `"/health"` and `"/simulate"`. The final URLs (e.g. `/api/v1/health`) depend on how the FastAPI app mounts these routers (see §11.1).

### 7.1 Health endpoints

`app/api/v1/health.py`:

- `GET /api/v1/health`: basic service info
- `GET /api/v1/health/ready`: attempts dependency checks (DB + services)
- `GET /api/v1/health/live`: liveness ping

### 7.2 Chat & streaming

`app/api/v1/chat.py` provides a chat interface and uses SSE (`sse-starlette`) to stream events from the simulator agent (`stream_simulator()`).

Event types are documented in `ChatEvent` (examples: `token`, `tool_call`, `tool_result`, `clarification`, `done`, `error`).

### 7.3 Agent endpoints

`app/api/v1/agents.py` is expected to expose:

- scenario listing (e.g. `GET /api/v1/agents/scenarios`)
- simulate (e.g. `POST /api/v1/agents/simulate`)
- schedule (e.g. `POST /api/v1/agents/schedule`)

See `tests/test_api.py` for the intended public surface and example request payloads.

## 8) Database & persistence

### 8.1 Async DB session

`app/db/database.py`:

- `init_db()` creates an async engine and session factory
- `get_db_session()` yields an `AsyncSession` as a FastAPI dependency

### 8.2 Tables

`app/db/models.py` defines tables used by the API and agents, including:

- `ChatHistory`: persistent conversation storage
- `HITLSession`: human-in-the-loop question/answer lifecycle
- `SimulationRun`: run tracking + result payload + trace
- `AgentTrace`, `UserFeedback`, `PromptTemplate`: observability and prompt management

## 9) Running & developing

### 9.1 Local (without Docker)

From `simulator_scheduler_agent/`:

1. Create and activate a Python 3.11 virtualenv
2. Install deps: `pip install -r requirements.txt`
3. Export required env vars (`OPENAI_API_KEY`, `DATABASE_URL`, etc.)

The Dockerfile expects a FastAPI app at `app.main:app` (see §11 “Known gaps”). If/when `app/main.py` exists, you would run:

- `uvicorn app.main:app --host 0.0.0.0 --port 8000`

### 9.2 Docker

`docker/Dockerfile` starts:

- `uvicorn app.main:app --host 0.0.0.0 --port 8000`

`docker/docker-compose.yml` (if configured) should wire Postgres and any dependent services.

### 9.3 Tests

From `simulator_scheduler_agent/`:

- `pytest -v`

## 10) Coding conventions

Configured in `pyproject.toml`:

- `black` line length 100
- `isort` black profile
- `mypy` ignores missing imports and excludes `tests`

## 11) Known gaps / inconsistencies to be aware of

This section documents code-structure issues that affect “how to run” and import correctness. These are important for onboarding and for making the documentation match actual behavior.

### 11.1 Missing FastAPI app entrypoint

- `docker/Dockerfile` runs `uvicorn app.main:app`, but there is **no** `app/main.py` currently in `app/`.

Practical implication: the service cannot start via the Dockerfile command until an `app/main.py` is added (typically creating a `FastAPI()` instance, registering routers, and initializing/shutting down the DB).

### 11.2 Orchestrator filename mismatch (simulator agent)

- `app/agents/simulator_agent/agent.py` imports `app.agents.simulator_agent.nodes.orchestrator`
- The repository currently contains `app/agents/simulator_agent/nodes/orchestartor.py` (note the spelling).

Practical implication: simulator graph import/build will fail until the module name/import is aligned.

### 11.3 Shared LLM factory naming mismatch

- Some modules import `app.agents.shared.llm_factory`
- The repository contains `app/agents/shared/llmfactory.py`

Practical implication: these imports will fail until the filename and imports match.

### 11.4 Tests vs enum casing / endpoint shapes

`tests/test_api.py` uses values such as `"tmo_rpm"` for `project_track`, but `ProjectTrack` enum values in `app/core/models.py` are `"TMO_RPM"`, `"NAS"`, `"DEC"`.

Practical implication: request validation may fail depending on how endpoints are typed and what coercions are applied.

### 11.5 Scheduler endpoint vs scheduler agent signature

`app/api/v1/agents.py` currently calls `run_scheduler(market=..., target_sites=..., target_date=..., constraints=...)`, but `app/agents/scheduler_agent/agent.py:run_scheduler()` requires `query`, `session_id`, `market`, `start_date`, and `end_date` (and uses `date` types).

Practical implication: the schedule endpoint will raise at runtime until either the endpoint is updated to match `run_scheduler()` or `run_scheduler()` is refactored to match the endpoint contract.

## 12) “Where do I change X?”

- Add/modify API routes: `app/api/v1/*.py`
- Add simulator logic: `app/agents/simulator_agent/nodes/*` and `.../simulation_engine/engine.py`
- Add scheduler logic: `app/agents/scheduler_agent/nodes.py`
- Change env vars / defaults: `app/core/config.py`
- Change shared schemas/enums: `app/core/models.py`
- Add new persistence tables: `app/db/models.py` (and migrations if introduced)
- Integrations:
  - Unified layer: `app/services/unified_layer_service.py`
  - Knowledge graph: `app/services/kg_service.py`