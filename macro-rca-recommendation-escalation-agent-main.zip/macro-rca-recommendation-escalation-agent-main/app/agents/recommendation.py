"""
Recommendation Agent.

Converts RCA analysis into a focused action plan.
"""
from __future__ import annotations

import logging
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage

from models.state import RCAState
from prompts.recommendation_prompt import RECOMMENDATION_SYSTEM
from services.llm_provider import LLMProvider

logger = logging.getLogger(__name__)


def recommendation_node(state: RCAState) -> dict[str, Any]:
    """
    LangGraph node: Recommendation Agent for RCA.

    Reads: refined_query (or user_query), final_response, calculations, errors
    Writes: recommendations, final_response, current_phase, messages
    """
    provider = LLMProvider(model="gpt-4o", temperature=0.1)
    llm = provider.get_llm()

    user_query = state.get("refined_query") or state["user_query"]
    analysis = state.get("final_response", "").strip()
    calculations = state.get("calculations", "").strip()
    errors = state.get("errors", [])

    user_message_parts = [
        f"## Original User Query\n{user_query}",
        f"\n## RCA Analysis\n{analysis or 'No RCA analysis was generated.'}",
    ]

    if calculations:
        user_message_parts.append(f"\n## Calculation Outputs\n{calculations}")

    if errors:
        user_message_parts.append(
            "\n## Errors Encountered\n" +
            "\n".join(f"- {err}" for err in errors)
        )

    user_message_parts.append(
        "\n## Instructions"
        "\nGenerate only the recommendation section for this RCA. Keep it grounded in the "
        "analysis above. Do not repeat the full RCA narrative."
    )

    response = llm.invoke([
        SystemMessage(content=RECOMMENDATION_SYSTEM),
        HumanMessage(content="\n".join(user_message_parts)),
    ])

    recommendations = response.content.strip()
    merged_response = analysis
    if recommendations:
        merged_response = f"{analysis}\n\n---\n\n{recommendations}" if analysis else recommendations

    logger.info("Recommendation agent generated action plan")

    return {
        "recommendations": recommendations,
        "final_response": merged_response,
        "current_phase": "complete",
        "messages": [{
            "agent": "recommendation",
            "content": "Generated recommendation plan",
        }],
    }
