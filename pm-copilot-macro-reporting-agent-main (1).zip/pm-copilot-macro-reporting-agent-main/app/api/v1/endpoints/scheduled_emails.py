"""
Scheduled-email-job CRUD API.

A scheduled job re-runs a saved template at one or more wall-clock times on
selected weekdays and emails the resulting PDF via the Nokia email API.
This file owns the API surface; the cron / worker that actually fires the
jobs lives elsewhere.

Endpoints:
  GET    /api/v1/scheduled-emails?user_id=        list a user's jobs
  GET    /api/v1/scheduled-emails/{id}            fetch one (ownership-checked)
  POST   /api/v1/scheduled-emails                 create a new schedule
  PATCH  /api/v1/scheduled-emails/{id}            partial update (ownership-checked)
  DELETE /api/v1/scheduled-emails/{id}            delete (ownership-checked)

Beyond the Pydantic-level checks (required fields, weekday literal,
non-empty `schedule_time` / `to_list`), the endpoint layer validates:

  * The referenced `template_id` EXISTS and belongs to the same `user_id`
    (prevents a user from scheduling emails against someone else's
    template — leak vector and a foot-gun for the worker).
  * `schedule_time_zone` is a real IANA tz name (`Asia/Kolkata`, etc.)
    so the worker doesn't blow up at fire time.
  * `to_list` / `cc_list` / `bcc_list` entries look like email addresses
    (very loose check — full validation happens at the email-API call site).
  * `schedule_time` and `days_of_week` are deduplicated server-side so a
    job created with `["07:30","07:30"]` doesn't fire twice at 07:30.
"""
from __future__ import annotations

import base64
import logging
import re
from datetime import datetime
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field

from api.v1.endpoints.templates import _rerun_template_selections
from models.scheduled_email import (
    ScheduledEmailJobIn,
    ScheduledEmailJobOut,
    ScheduledEmailJobUpdate,
)
from services import db_service, scheduled_email_service
from services.canvas_export import _safe_filename, render_canvas_pdf

logger = logging.getLogger(__name__)
router = APIRouter(tags=["ScheduledEmails"])

MAX_LIST_LIMIT = 200

# Loose email shape — same posture as the existing _EmailRequest models
# in canvas/templates: format-validate at the email-API call site, just
# catch obvious typos (`foo`, `foo@`, `foo@bar`) at the API boundary.
_EMAIL_LOOSE_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# ── Validators ──────────────────────────────────────────────────────────────


def _assert_template_owned_by_user(template_id: str, user_id: str) -> None:
    """The schedule must point at a template the same user owns. Otherwise
    we'd silently send another user's report to whoever sets up the
    schedule — a leak. 422 chosen over 403 because this is a payload
    validation failure, not an auth-level rejection."""
    template = db_service.get_template(template_id)
    if not template:
        raise HTTPException(
            status_code=422,
            detail=f"Template {template_id} not found — cannot schedule against a missing template.",
        )
    if template.get("user_id") != user_id:
        raise HTTPException(
            status_code=422,
            detail=(f"Template {template_id} does not belong to user {user_id}. "
                    "A user can only schedule emails against their own templates."),
        )


def _assert_valid_timezone(tz_name: str) -> None:
    """Reject a tz string the worker can't actually load. Worker would raise
    at fire time otherwise and silently skip the job — fail fast at create."""
    try:
        ZoneInfo(tz_name)
    except ZoneInfoNotFoundError:
        raise HTTPException(
            status_code=422,
            detail=(f"schedule_time_zone {tz_name!r} is not a valid IANA tz name. "
                    "Examples: 'UTC', 'Asia/Kolkata', 'America/New_York'."),
        )


def _assert_email_list_shape(field_name: str, addrs: list[str]) -> None:
    """Loose `someone@somewhere.tld` check on each address. Catches obvious
    typos before the row hits the worker; full RFC validation happens at
    the email API."""
    for addr in addrs or []:
        if not isinstance(addr, str) or not _EMAIL_LOOSE_RE.match(addr.strip()):
            raise HTTPException(
                status_code=422,
                detail=f"{field_name} contains an invalid email address: {addr!r}",
            )


def _dedupe_preserving_order(seq: list) -> list:
    """Tiny order-preserving dedup. Used for both `schedule_time` and
    `days_of_week` so storage is canonical regardless of what the client
    sent."""
    seen = set()
    out = []
    for x in seq:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out


def _row_to_out(row: dict) -> ScheduledEmailJobOut:
    """Coerce the DB row dict into the response model. Postgres returns
    `time` and `datetime` types directly; arrays as Python lists; `None`
    for null columns."""
    return ScheduledEmailJobOut(**row)


# ── Endpoints ───────────────────────────────────────────────────────────────


@router.get(
    "/scheduled-emails",
    summary="List scheduled email jobs for a user (newest first)",
)
def list_scheduled_emails(
    user_id: str = Query(..., description="Owner of the schedules"),
    limit:   int = Query(default=50, ge=1, le=MAX_LIST_LIMIT),
):
    rows = scheduled_email_service.list_scheduled_email_jobs_by_user(user_id, limit=limit)
    return {"jobs": [_row_to_out(r).model_dump(mode="json") for r in rows]}


@router.get(
    "/scheduled-emails/{job_id}",
    summary="Fetch one scheduled job (ownership-checked)",
)
def get_scheduled_email(
    job_id: int,
    user_id: str = Query(..., description="Owner — server verifies the job belongs to this user"),
):
    row = scheduled_email_service.get_scheduled_email_job(job_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"Scheduled job {job_id} not found")
    if row.get("user_id") != user_id:
        raise HTTPException(status_code=403, detail=f"Job {job_id} does not belong to user {user_id}")
    return _row_to_out(row).model_dump(mode="json")


@router.post(
    "/scheduled-emails",
    summary="Create a new scheduled email job",
)
def create_scheduled_email(payload: ScheduledEmailJobIn):
    # 1. Template must exist AND belong to payload.user_id
    _assert_template_owned_by_user(payload.template_id, payload.user_id)

    # 2. tz must be loadable
    _assert_valid_timezone(payload.schedule_time_zone)

    # 3. Email-list shape (loose). subject / email_body non-empty already
    #    enforced at the Pydantic level via min_length=1.
    _assert_email_list_shape("to_list",  payload.to_list)
    _assert_email_list_shape("cc_list",  payload.cc_list)
    _assert_email_list_shape("bcc_list", payload.bcc_list)

    # 4. Canonicalize: dedupe times + weekdays so storage doesn't carry
    #    redundant entries that would multi-fire.
    times = _dedupe_preserving_order(payload.schedule_time)
    days = _dedupe_preserving_order(payload.days_of_week) if payload.days_of_week else None

    row = scheduled_email_service.create_scheduled_email_job(
        user_id=payload.user_id,
        template_id=payload.template_id,
        is_enabled=payload.is_enabled,
        schedule_time=times,
        schedule_time_zone=payload.schedule_time_zone,
        days_of_week=days,
        to_list=payload.to_list,
        cc_list=payload.cc_list,
        bcc_list=payload.bcc_list,
        subject=payload.subject,
        email_body=payload.email_body,
    )
    if not row:
        raise HTTPException(status_code=500, detail="Failed to persist scheduled email job")
    return _row_to_out(row).model_dump(mode="json")


@router.patch(
    "/scheduled-emails/{job_id}",
    summary="Partial update — change schedule, recipients, body, etc. (ownership-checked)",
)
def update_scheduled_email(
    job_id: int,
    payload: ScheduledEmailJobUpdate,
    user_id: str = Query(..., description="Owner — server verifies the job belongs to this user"),
):
    existing = scheduled_email_service.get_scheduled_email_job(job_id)
    if not existing:
        raise HTTPException(status_code=404, detail=f"Scheduled job {job_id} not found")
    if existing.get("user_id") != user_id:
        raise HTTPException(status_code=403, detail=f"Job {job_id} does not belong to user {user_id}")

    # Per-field validations on whatever the user is changing.
    if payload.schedule_time_zone is not None:
        _assert_valid_timezone(payload.schedule_time_zone)
    if payload.to_list is not None:
        _assert_email_list_shape("to_list", payload.to_list)
    if payload.cc_list is not None:
        _assert_email_list_shape("cc_list", payload.cc_list)
    if payload.bcc_list is not None:
        _assert_email_list_shape("bcc_list", payload.bcc_list)

    fields: dict[str, Any] = payload.model_dump(exclude_unset=True)

    # Dedupe before persistence (same reason as create).
    if "schedule_time" in fields and fields["schedule_time"]:
        fields["schedule_time"] = _dedupe_preserving_order(fields["schedule_time"])
    if "days_of_week" in fields and fields["days_of_week"]:
        fields["days_of_week"] = _dedupe_preserving_order(fields["days_of_week"])

    row = scheduled_email_service.update_scheduled_email_job(job_id, fields)
    if not row:
        raise HTTPException(status_code=500, detail="Failed to update scheduled email job")
    return _row_to_out(row).model_dump(mode="json")


@router.delete(
    "/scheduled-emails/{job_id}",
    summary="Delete a scheduled email job (ownership-checked)",
)
def delete_scheduled_email(
    job_id: int,
    user_id: str = Query(..., description="Owner — server verifies the job belongs to this user"),
):
    existing = scheduled_email_service.get_scheduled_email_job(job_id)
    if not existing:
        raise HTTPException(status_code=404, detail=f"Scheduled job {job_id} not found")
    if existing.get("user_id") != user_id:
        raise HTTPException(status_code=403, detail=f"Job {job_id} does not belong to user {user_id}")

    ok = scheduled_email_service.delete_scheduled_email_job(job_id)
    return {"id": job_id, "deleted": bool(ok)}


# ── Fire-now endpoint ───────────────────────────────────────────────────────


class FireNowIn(BaseModel):
    """Body for `POST /scheduled-emails/send-now`. The endpoint reuses the
    email config (recipients, subject, body) saved on the most-recent
    scheduled job for this user_id + template_id pair — same config the
    background worker would use at fire time, so a manual send and a
    cron-fired send produce identical emails."""
    user_id:     str = Field(..., min_length=1, max_length=100)
    template_id: str = Field(..., min_length=1, max_length=100)

    model_config = ConfigDict(
        extra="ignore",
        json_schema_extra={"example": {
            "user_id":     "u_123",
            "template_id": "tmpl_q2_ntm_runrate",
        }},
    )


@router.post(
    "/scheduled-emails/send-now",
    summary="Re-run a scheduled template's report and return the PDF + email config "
            "(does NOT actually send — caller handles delivery)",
)
def send_now(payload: FireNowIn):
    """Prepare-attachment endpoint for the external scheduler / email worker.

    This endpoint is INTENTIONALLY a "render only" path — it does not POST
    anywhere or call the Nokia email API. The downstream service that owns
    email delivery uses this to fetch a fresh PDF + the saved email config
    in a single round-trip, then constructs and sends its own email payload.

    Pipeline:
      1. Find the most recent scheduled job for (user_id, template_id) — 404 if none.
      2. Verify the template still exists and is owned by the same user_id.
      3. Re-run the template's selections in the sandbox (fresh data + LLM-refreshed insights).
      4. Render the rebuilt selections to a single PDF (matplotlib).
      5. Return:
           - the PDF as a base64-encoded attachment in the same shape
             the Nokia email API expects (`attachments: [{filedata, filename}]`),
           - the saved email config (recipients, subject, body) verbatim from
             the schedule row so the caller doesn't need a second GET.

    No `last_run_*` audit is written — that's the caller's concern, since
    they own the actual send. 500 for rerun / render failures, 404 / 403
    for the lookup checks.
    """
    # 1. Find the saved schedule
    job = scheduled_email_service.find_latest_job_by_user_template(
        payload.user_id, payload.template_id,
    )
    if not job:
        raise HTTPException(
            status_code=404,
            detail=(f"No scheduled email job exists for user {payload.user_id} "
                    f"+ template {payload.template_id}. Create one with "
                    f"POST /scheduled-emails first."),
        )

    # 2. Template still alive + owned
    template = db_service.get_template(payload.template_id)
    if not template:
        raise HTTPException(
            status_code=404,
            detail=f"Template {payload.template_id} no longer exists",
        )
    if template.get("user_id") != payload.user_id:
        raise HTTPException(
            status_code=403,
            detail=(f"Template {payload.template_id} does not belong to user "
                    f"{payload.user_id}"),
        )

    # 3. Re-run selections (fresh data + refreshed insights)
    try:
        rendered_selections, _ = _rerun_template_selections(template)
    except Exception as e:
        logger.exception("send_now: template rerun failed for job %s", job["id"])
        raise HTTPException(status_code=500, detail=f"Template rerun failed: {e}")

    # 4. Render PDF
    title = template.get("title") or "Template Report"
    try:
        pdf_bytes = render_canvas_pdf(title, rendered_selections)
    except Exception as e:
        logger.exception("send_now: PDF render failed for job %s", job["id"])
        raise HTTPException(status_code=500, detail=f"PDF render failed: {e}")
    fname = f"{_safe_filename(title)}.pdf"

    # 5. Build the response — PDF as base64 attachment + saved email config.
    #    The shape of `attachments` matches Nokia's API contract verbatim
    #    so the downstream caller can pipe it through with no transformation.
    return {
        "user_id":          payload.user_id,
        "template_id":      payload.template_id,
        "job_id":           job["id"],

        # Email config from the saved schedule — caller may use as-is or override.
        "to_list":          list(job.get("to_list") or []),
        "cc_list":          list(job.get("cc_list") or []),
        "bcc_list":         list(job.get("bcc_list") or []),
        "subject":          job.get("subject") or title,
        "email_body":       job.get("email_body") or "",

        # The PDF, ready to embed in the Nokia email body's `attachments` array.
        "attachments": [
            {
                "filedata": base64.b64encode(pdf_bytes).decode("ascii"),
                "filename": fname,
            },
        ],

        "attachment_bytes": len(pdf_bytes),
        "rendered_at":      datetime.utcnow().isoformat() + "Z",
    }
