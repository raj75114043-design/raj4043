"""
User-feedback API.

Two endpoints:

  POST /api/v1/feedback
    Create a feedback row. At least one of `stars`, `comment`,
    `is_positive` must be provided (a row with neither stars nor a
    comment nor a thumbs-up/down conveys nothing).

  GET  /api/v1/feedback?user_id=&chart_id=&thread_id=&message_id=&limit=
    List feedback rows newest-first. Every filter is optional. Without
    filters the endpoint returns the most recent `limit` rows globally.

The endpoint layer only handles validation, shaping, and HTTP concerns;
persistence is delegated to `services.feedback_service`.
"""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field

from services import feedback_service

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Feedback"])


class FeedbackCreate(BaseModel):
    """Inbound feedback. `user_id` is required; everything else is optional
    but at least one of {stars, comment, is_positive} MUST be set."""
    user_id:     str
    thread_id:   str  | None = None
    message_id:  str  | None = None
    chart_id:    str  | None = None
    stars:       int  | None = Field(default=None, ge=1, le=5)
    comment:     str  | None = None
    is_positive: bool | None = None

    model_config = ConfigDict(
        extra="ignore",
        json_schema_extra={
            "example": {
                "user_id":     "anonymous",
                "chart_id":    "0c7e9b4a-c3d6-4d2c-9c8a-7b1d5d8f9e10",
                "thread_id":   None,
                "message_id":  None,
                "stars":       5,
                "comment":     "Spot-on insight, exactly what I needed.",
                "is_positive": True,
            }
        },
    )


@router.post("/feedback", summary="Create a feedback row")
def post_feedback(payload: FeedbackCreate) -> dict[str, Any]:
    # At least one of stars / comment / is_positive must be set — otherwise
    # the row carries no signal at all.
    if (payload.stars is None
            and not (payload.comment or "").strip()
            and payload.is_positive is None):
        raise HTTPException(
            status_code=422,
            detail="At least one of `stars`, `comment`, or `is_positive` is required.",
        )

    row = feedback_service.create_feedback(
        user_id     = payload.user_id,
        thread_id   = payload.thread_id,
        message_id  = payload.message_id,
        chart_id    = payload.chart_id,
        stars       = payload.stars,
        comment     = (payload.comment or "").strip() or None,
        is_positive = payload.is_positive,
    )
    if row is None:
        raise HTTPException(status_code=500, detail="Feedback insert failed")
    return row


@router.get("/feedback", summary="List feedback rows (newest first)")
def list_feedback(
    user_id:    str | None = Query(default=None, description="Filter by submitter"),
    chart_id:   str | None = Query(default=None, description="Filter by chart"),
    thread_id:  str | None = Query(default=None, description="Filter by chat thread"),
    message_id: str | None = Query(default=None, description="Filter by AI message / query_id"),
    limit:      int = Query(default=100, ge=1, le=500),
) -> dict[str, Any]:
    rows = feedback_service.list_feedback(
        user_id    = user_id,
        chart_id   = chart_id,
        thread_id  = thread_id,
        message_id = message_id,
        limit      = limit,
    )
    return {"feedback": rows, "count": len(rows)}
