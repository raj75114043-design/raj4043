"""
Top-questions API.

Surfaces the most-frequently-asked-by-users questions, with intent
deduplication done at insert time (see `services.question_embedding`).

GET /api/v1/questions/top?limit=10
  → {
      "questions": [
        {
          "canonical_id":  1,
          "question":      "Give the GC run rate region wise.",
          "asked_by_users": 7,
          "first_asked":   "2026-04-20T10:12:00",
          "last_asked":    "2026-04-27T16:33:00"
        },
        ...
      ]
    }
"""
from __future__ import annotations

import json
import logging
import re

from fastapi import APIRouter, HTTPException, Query
from services.insight_refresh import refresh_rationale
from api.v1.endpoints.templates import _rerun_template_selections
from services import db_service
from services.llm_provider import LLMProvider

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Questions"])

MAX_TOP_QUESTIONS = 10

_FENCE_RE = re.compile(r"^```(?:json)?\s*|\s*```$", re.MULTILINE)


def _strip_fences(s: str) -> str:
    return _FENCE_RE.sub("", (s or "").strip()).strip()


_GRAMMAR_SYSTEM = (
    "You polish ONLY the grammar, capitalization, and punctuation of short business "
    "questions. You MUST NOT change wording, meaning, terminology, abbreviations, "
    "or word order. Do not paraphrase. Do not add or remove words. Acronyms (GC, "
    "NTM, KPI, etc.) stay uppercase. Numbers and named entities stay verbatim.\n"
    "\n"
    "Input is a JSON array of strings. Output is a JSON array of strings of the "
    "SAME LENGTH and SAME ORDER, where each item is the lightly-polished version "
    "of the corresponding input. Return ONLY the JSON array, no prose, no fences."
)


def _grammar_correct(texts: list[str]) -> list[str]:
    """Best-effort grammar/capitalization fix for the top-N questions.

    One batched LLM call for all items. On any failure (LLM error, parse
    error, length mismatch) returns the inputs unchanged so the endpoint
    never breaks because of a polish step.
    """
    if not texts:
        return texts
    try:
        provider = LLMProvider()
        resp = provider.invoke([
            ("system", _GRAMMAR_SYSTEM),
            ("human",  json.dumps(texts, ensure_ascii=False)),
        ])
        raw = _strip_fences(getattr(resp, "content", "") or "")
        polished = json.loads(raw)
        if (isinstance(polished, list)
                and len(polished) == len(texts)
                and all(isinstance(x, str) and x.strip() for x in polished)):
            return polished
        logger.warning("grammar polish returned unexpected shape — falling back")
    except Exception as exc:
        logger.warning("grammar polish failed (%s) — falling back", exc)
    return texts


@router.get(
    "/questions/top",
    summary=f"Top-{MAX_TOP_QUESTIONS} most-frequently-asked questions (intent-deduplicated, grammar-polished)",
)
def get_top_questions(
    limit: int = Query(
        default=MAX_TOP_QUESTIONS,
        ge=1,
        description=f"How many to return. Hard-capped at {MAX_TOP_QUESTIONS}.",
    ),
):
    """Return the top-N questions ranked by **distinct users** who asked
    them. Intents are clustered automatically via embedding similarity:
    "show GC run rate by region" and "what's the GC run rate per region"
    count as the same question, but two different users asking either
    phrasing count as 2.

    The returned `question` text is the canonical's stored `display_text`
    run through one LLM pass for grammar / capitalization / punctuation —
    wording and meaning are preserved verbatim.
    """
    effective_limit = min(max(1, limit), MAX_TOP_QUESTIONS)
    rows = db_service.top_questions(limit=effective_limit)

    polished = _grammar_correct([r["display_text"] for r in rows])
    return {
        "questions": [
            {
                "canonical_id":   r["canonical_id"],
                "question":       polished[i],
                "asked_by_users": r["ask_count"],
                "first_asked":    r["first_asked"],
                "last_asked":     r["last_asked"],
            }
            for i, r in enumerate(rows)
        ],
    }


@router.get(
    "/questions/{canonical_id}/charts",
    summary="Re-run the saved scripts behind an FAQ and return charts with today's data",
)
def get_canonical_charts(canonical_id: int):
    """Fast-path equivalent of asking the question again.

    Pipeline (same as POST /templates/{id}/run, no LLM agent loop):
      1. Find the most recent successful query whose `original_query`
         matches a user-link row for this canonical_id.
      2. Pull the saved charts for that query (each carries the Python+SQL
         `script` the traversal agent originally wrote).
      3. Re-execute every script in the sandbox — scripts use
         CURRENT_DATE / DATE_TRUNC, so they pick up today's rows.
      4. Rebuild each chart's series/categories from the fresh result and
         regenerate `insight` via `refresh_insight` so the takeaway sentence
         reflects the new numbers.

    Returns 404 if no completed query exists yet for this canonical
    (cold-start case — the caller should fall back to the SSE pipeline).
    """
    canonical = db_service.get_canonical_question(canonical_id)
    if not canonical:
        raise HTTPException(status_code=404, detail=f"Canonical {canonical_id} not found")

    query_id = db_service.find_latest_complete_query_for_canonical(canonical_id)
    if not query_id:
        raise HTTPException(
            status_code=404,
            detail=("No completed query exists for this question yet. "
                    "Ask the question normally first to seed the saved charts."),
        )
    
    query_row = db_service.get_query(query_id) or {}
    original_rationale = (query_row.get("rationale") or "").strip()

    chart_rows = db_service.get_charts_for_query(query_id)
    if not chart_rows:
        raise HTTPException(
            status_code=404,
            detail=f"Source query {query_id} has no saved charts to re-run",
        )

    # Wrap each saved chart as a synthetic "selection" so we can reuse the
    # template re-run helper (sandbox execute → rebuild → refresh insight).
    fake_selections = [{
        "chart":    r.get("chart") or {},
        "x":        0.0,
        "y":        0.0,
        "w":        1.0,
        "h":        1.0,
        "position": i,
    } for i, r in enumerate(chart_rows)]

    rendered, script_reports = _rerun_template_selections({"selections": fake_selections})

    charts_out: list[dict] = []
    for slot, row in zip(rendered, chart_rows):
        c = dict(slot["chart"])
        c["created_at"] = row.get("created_at")
        charts_out.append(c)
    
    polished_question = _grammar_correct([canonical["display_text"]])[0]

    refreshed_rationale = refresh_rationale(
        polished_question, original_rationale, charts_out,
    )
    # Polish only the question text we surface back — match /questions/top.

    return {
        "canonical_id":   canonical_id,
        "question":       polished_question,
        "source_query":   query_id,
        "rationale":      refreshed_rationale,
        "charts":         charts_out,
        "script_reports": script_reports,
    }
