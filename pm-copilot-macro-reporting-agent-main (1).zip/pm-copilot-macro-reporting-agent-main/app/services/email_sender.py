"""
Outbound email helper — wraps the Nokia internal email service.

The Nokia API expects:

  POST {NOKIA_EMAIL_API_URL}
  body: {
    "user_id":    "<sender email>",
    "to_list":    ["..."],
    "cc_list":    [...],
    "bcc_list":   [...],
    "subject":    "...",
    "email_body": "...",
    "attachments": [
      { "filedata": "<base64>", "filename": "report.pdf" },
      ...
    ]
  }

  → returns { "token_id": "<uuid>", ... }   (async pipeline; poll status separately)

This module owns ONE thing: take a fully-built payload + a list of file
attachments and POST them to that URL. Callers (`canvas` / `templates`
endpoints) are responsible for building the PDF + composing the request.
"""
from __future__ import annotations

import base64
import logging
from typing import Any

import requests

import config

logger = logging.getLogger(__name__)


def send_email_with_attachment(
    *,
    sender_email: str,
    to_list: list[str],
    subject: str,
    email_body: str,
    attachment_bytes: bytes,
    attachment_filename: str,
    cc_list: list[str] | None = None,
    bcc_list: list[str] | None = None,
) -> dict[str, Any]:
    """POST a single-attachment email to the Nokia email API.

    Returns the parsed JSON response (typically `{"token_id": "...", ...}`).
    Raises `RuntimeError` on non-2xx so the FastAPI caller can convert it
    into a 502 with the upstream detail surfaced to the client.
    """
    payload: dict[str, Any] = {
        "user_id":    sender_email,
        "to_list":    list(to_list or []),
        "cc_list":    list(cc_list or []),
        "bcc_list":   list(bcc_list or []),
        "subject":    subject,
        "email_body": email_body,
        "attachments": [
            {
                "filedata": base64.b64encode(attachment_bytes).decode("ascii"),
                "filename": attachment_filename,
            },
        ],
    }

    print(payload,"Payload")

    headers = {"Content-Type": "application/json"}
    
    print(
        "POST %s — to=%s cc=%s bcc=%s subject=%r attachment=%s (%d bytes)",
        config.NOKIA_EMAIL_API_URL,
        payload["to_list"], payload["cc_list"], payload["bcc_list"],
        subject, attachment_filename, len(attachment_bytes),
    )

    try:
        resp = requests.post(
            config.NOKIA_EMAIL_API_URL,
            json=payload,
            headers=headers
        )

        print(resp,"Response")

    except requests.RequestException as e:
        raise RuntimeError(f"upstream email API unreachable: {e}") from e

    if not (200 <= resp.status_code < 300):
        # Surface the upstream body so the caller can see why it rejected.
        try:
            detail = resp.json()
        except Exception:
            detail = resp.text[:500]
        raise RuntimeError(f"email API returned {resp.status_code}: {detail}")

    try:
        return resp.json()
    except Exception:
        return {"raw": resp.text[:500]}
