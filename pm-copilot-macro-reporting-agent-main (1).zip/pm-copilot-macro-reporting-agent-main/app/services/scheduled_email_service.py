"""
Scheduled-email service — CRUD over `macro_email_doc_agent.reporting_email_scheduled_jobs`.

Kept deliberately separate from `db_service.py`:
  * The schema (`macro_email_doc_agent`) is owned by another pipeline,
    so this service can evolve / migrate independently of the reporting
    tables.
  * Same connection-pool semantics — `_conn()` is reused from `db_service`.
  * Same error-handling convention — DB failures are logged but never
    raised; the caller decides how to surface a failure to the user.
"""
from __future__ import annotations

import logging
from typing import Any

from services.db_service import (
    _EMAIL_SCHEDULED_JOBS_SCHEMA,
    _conn,
    _fetch_row,
    _fetch_rows,
)

logger = logging.getLogger(__name__)


_EMAIL_JOB_COLS = (
    "id, user_id, template_id, is_enabled, "
    "schedule_time, schedule_time_zone, days_of_week, "
    "to_list, cc_list, bcc_list, subject, email_body, "
    "last_run_time, last_run_mail_status, "
    "created_at, updated_at"
)


def create_scheduled_email_job(
    *,
    user_id: str,
    template_id: str,
    schedule_time: list,                      # list[datetime.time]
    schedule_time_zone: str,
    days_of_week: list[str] | None,
    to_list: list[str],
    cc_list: list[str],
    bcc_list: list[str],
    subject: str,
    email_body: str,
    is_enabled: bool = True,
) -> dict | None:
    """Insert one scheduled-email job. Returns the inserted row (with `id`
    populated) or None on DB failure. The caller is responsible for
    higher-level validations (template ownership, time-zone, etc.) before
    invoking this helper.
    """
    try:
        with _conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    INSERT INTO {_EMAIL_SCHEDULED_JOBS_SCHEMA}.reporting_email_scheduled_jobs
                        (user_id, template_id, is_enabled,
                         schedule_time, schedule_time_zone, days_of_week,
                         to_list, cc_list, bcc_list, subject, email_body)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING {_EMAIL_JOB_COLS}
                    """,
                    (
                        user_id, template_id, is_enabled,
                        schedule_time, schedule_time_zone, days_of_week,
                        to_list, cc_list, bcc_list, subject, email_body,
                    ),
                )
                cols = [d[0] for d in cur.description]
                row = cur.fetchone()
                return dict(zip(cols, row)) if row else None
    except Exception as exc:
        logger.error("create_scheduled_email_job failed (user=%s, tmpl=%s): %s",
                     user_id, template_id, exc)
        return None


def get_scheduled_email_job(job_id: int) -> dict | None:
    """One job row by id, regardless of owner. Callers (endpoints) enforce
    the ownership check on top so admin / restore paths still have a way
    to look up rows."""
    return _fetch_row(
        f"""
        SELECT {_EMAIL_JOB_COLS}
        FROM   {_EMAIL_SCHEDULED_JOBS_SCHEMA}.reporting_email_scheduled_jobs
        WHERE  id = %s
        """,
        (job_id,),
    )


def list_scheduled_email_jobs_by_user(user_id: str, limit: int = 50) -> list[dict]:
    """All jobs belonging to a user, newest first by created_at."""
    return _fetch_rows(
        f"""
        SELECT {_EMAIL_JOB_COLS}
        FROM   {_EMAIL_SCHEDULED_JOBS_SCHEMA}.reporting_email_scheduled_jobs
        WHERE  user_id = %s
        ORDER  BY created_at DESC
        LIMIT  %s
        """,
        (user_id, limit),
    )


def find_latest_job_by_user_template(user_id: str, template_id: str) -> dict | None:
    """Most recent scheduled job for a (user_id, template_id) pair.

    Used by the manual `POST /scheduled-emails/send-now` endpoint to look
    up which email config to fire the template with — the worker would
    pick the same row at fire time. Returns None when no schedule exists
    for this pair (caller surfaces 404)."""
    return _fetch_row(
        f"""
        SELECT {_EMAIL_JOB_COLS}
        FROM   {_EMAIL_SCHEDULED_JOBS_SCHEMA}.reporting_email_scheduled_jobs
        WHERE  user_id = %s AND template_id = %s
        ORDER  BY created_at DESC
        LIMIT  1
        """,
        (user_id, template_id),
    )


def record_run_status(job_id: int, status: str) -> None:
    """Stamp `last_run_time = NOW()` and `last_run_mail_status = <status>`
    on the job row. Used by both the manual send-now endpoint and the
    background worker so the audit trail looks identical regardless of
    who fired the job. Errors are logged and swallowed — failing to write
    the audit must NOT break the email-send flow."""
    try:
        with _conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    UPDATE {_EMAIL_SCHEDULED_JOBS_SCHEMA}.reporting_email_scheduled_jobs
                       SET last_run_time = CURRENT_TIMESTAMP,
                           last_run_mail_status = %s,
                           updated_at = CURRENT_TIMESTAMP
                     WHERE id = %s
                    """,
                    (status, job_id),
                )
    except Exception as exc:
        logger.error("record_run_status failed (id=%s): %s", job_id, exc)


# Allow-list of columns the PATCH endpoint may update. `user_id` and
# `template_id` are deliberately NOT here — repointing a schedule's owner
# or template is a re-create, not an in-place edit.
_EMAIL_JOB_PATCHABLE = (
    "is_enabled", "schedule_time", "schedule_time_zone", "days_of_week",
    "to_list", "cc_list", "bcc_list", "subject", "email_body",
)


def update_scheduled_email_job(job_id: int, fields: dict[str, Any]) -> dict | None:
    """Partial update. Only keys in `_EMAIL_JOB_PATCHABLE` with non-None
    values are honored — anything else is silently ignored, so the
    endpoint can pass `payload.model_dump()` directly without filtering.

    Returns the updated row, or the existing row when there is nothing
    to change, or None on hard failure / missing job."""
    sets: list[str] = []
    params: list = []
    for k, v in fields.items():
        if k not in _EMAIL_JOB_PATCHABLE or v is None:
            continue
        sets.append(f"{k} = %s")
        params.append(v)

    if not sets:
        # No-op — return current state so callers don't have to re-fetch.
        return get_scheduled_email_job(job_id)

    sets.append("updated_at = CURRENT_TIMESTAMP")
    params.append(job_id)
    try:
        with _conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    UPDATE {_EMAIL_SCHEDULED_JOBS_SCHEMA}.reporting_email_scheduled_jobs
                       SET {', '.join(sets)}
                     WHERE id = %s
                    RETURNING {_EMAIL_JOB_COLS}
                    """,
                    tuple(params),
                )
                cols = [d[0] for d in cur.description]
                row = cur.fetchone()
                return dict(zip(cols, row)) if row else None
    except Exception as exc:
        logger.error("update_scheduled_email_job failed (id=%s): %s", job_id, exc)
        return None


def delete_scheduled_email_job(job_id: int) -> bool:
    """Hard delete — these rows have no children. Returns True iff a row
    was removed. Caller does the ownership check before invoking."""
    try:
        with _conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    DELETE FROM {_EMAIL_SCHEDULED_JOBS_SCHEMA}.reporting_email_scheduled_jobs
                     WHERE id = %s
                    """,
                    (job_id,),
                )
                return cur.rowcount > 0
    except Exception as exc:
        logger.error("delete_scheduled_email_job failed (id=%s): %s", job_id, exc)
        return False
