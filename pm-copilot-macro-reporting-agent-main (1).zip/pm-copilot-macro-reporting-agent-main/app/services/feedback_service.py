"""
User-feedback persistence for the reporting agent.

Kept separate from `db_service.py` on purpose — feedback has its own CRUD
surface and the rest of the app should not import it indirectly via the
broader services module.

Table (created by `db_service.ensure_tables()`):
    pwc_agent_utility_schema.reporting_user_feedback

Columns:
    feedback_id  BIGSERIAL primary key (server-assigned)
    user_id      who left the feedback                          (required)
    thread_id    chat thread the feedback was attached to       (optional)
    message_id   AI message / query_id the feedback was on      (optional)
    chart_id     specific chart the feedback was on             (optional)
    stars        1-5 rating                                     (optional)
    comment      free-text                                      (optional)
    is_positive  thumbs up / down                               (optional)
    created_at   server timestamp (NOW())                       (auto)

All non-id fields except `user_id` are nullable so the same table can
hold thread-level feedback, message-level feedback, and chart-level
feedback. At least one of {stars, comment, is_positive} should be set
by the caller — the endpoint enforces that.
"""
from __future__ import annotations

import logging
from typing import Any

from services.db_service import _SCHEMA, _conn, _fetch_row, _fetch_rows

logger = logging.getLogger(__name__)

_TABLE = f"{_SCHEMA}.reporting_user_feedback"


def create_feedback(
    *,
    user_id: str,
    thread_id: str | None = None,
    message_id: str | None = None,
    chart_id: str | None = None,
    stars: int | None = None,
    comment: str | None = None,
    is_positive: bool | None = None,
) -> dict | None:
    """Insert a feedback row and return it as a dict.

    Caller is responsible for validating that at least one of
    `stars`, `comment`, `is_positive` is provided — the endpoint enforces
    this, the service does not (so internal callers can post any subset).
    """
    try:
        with _conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"""
                    INSERT INTO {_TABLE}
                        (user_id, thread_id, message_id, chart_id,
                         stars, comment, is_positive)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                    RETURNING feedback_id, created_at
                    """,
                    (user_id, thread_id, message_id, chart_id,
                     stars, comment, is_positive),
                )
                fid, ts = cur.fetchone()
        return {
            "feedback_id": fid,
            "user_id":     user_id,
            "thread_id":   thread_id,
            "message_id":  message_id,
            "chart_id":    chart_id,
            "stars":       stars,
            "comment":     comment,
            "is_positive": is_positive,
            "created_at":  ts,
        }
    except Exception as exc:
        logger.error("create_feedback failed: %s", exc)
        return None


def get_feedback(feedback_id: int) -> dict | None:
    return _fetch_row(
        f"""
        SELECT feedback_id, user_id, thread_id, message_id, chart_id,
               stars, comment, is_positive, created_at
        FROM   {_TABLE}
        WHERE  feedback_id = %s
        """,
        (feedback_id,),
    )


def list_feedback(
    *,
    user_id: str | None = None,
    chart_id: str | None = None,
    thread_id: str | None = None,
    message_id: str | None = None,
    limit: int = 100,
) -> list[dict]:
    """List feedback rows, newest-first. Any filter is optional —
    pass none to get the global feed (capped by `limit`)."""
    where: list[str] = []
    params: list[Any] = []
    if user_id is not None:
        where.append("user_id = %s");    params.append(user_id)
    if chart_id is not None:
        where.append("chart_id = %s");   params.append(chart_id)
    if thread_id is not None:
        where.append("thread_id = %s");  params.append(thread_id)
    if message_id is not None:
        where.append("message_id = %s"); params.append(message_id)

    where_sql = ("WHERE " + " AND ".join(where)) if where else ""
    params.append(int(limit))
    return _fetch_rows(
        f"""
        SELECT feedback_id, user_id, thread_id, message_id, chart_id,
               stars, comment, is_positive, created_at
        FROM   {_TABLE}
        {where_sql}
        ORDER  BY created_at DESC
        LIMIT  %s
        """,
        tuple(params),
    )
