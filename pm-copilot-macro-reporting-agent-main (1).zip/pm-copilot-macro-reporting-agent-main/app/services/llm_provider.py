"""
LLM Provider — instance-based ChatOpenAI wrapper.

Usage:
    from services.llm_provider import LLMProvider

    provider = LLMProvider(model="gpt-4o-mini")
    llm = provider.get_llm()
"""
from __future__ import annotations

import os
from langchain_openai import OpenAIEmbeddings

from langchain_openai import ChatOpenAI

EMBED_MODEL = "text-embedding-3-small"
LLM_BASE_URL = "https://llmgateway-qa-api.nokia.com/v1.2/"
LLM_MODEL = 'gpt-5.4-mini'
LLM_API_KEY ='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyTmFtZSI6IlJvbGxvdXRBZ2VudERldlRvb2wiLCJPYmplY3RJRCI6IjNGRUY4NzI0LUE5RTItNDMyQy1COTk4LTU0NDMwMEZBQjcxMyIsIndvcmtTcGFjZU5hbWUiOiJWUjE4NTdSb2xsb3V0QWdlbnREZXZTcGFjZSIsIm5iZiI6MTc3MDg4NTYyNCwiZXhwIjoxODAyNDIxNjI0LCJpYXQiOjE3NzA4ODU2MjR9.HvO_kB6UNwcNSV4B_MXuh9OK54rYtRRDMPH5Y1EuOhc'
LLM_HEADERS = {
    "api-key": LLM_API_KEY,
    "workspacename": "VR1857RolloutAgentDevSpace",
}


class LLMProvider:
    """
    Instance-based LLM provider.

    Each instance wraps a single ChatOpenAI configured for a specific model.
    """
    def get_llm(temperature: float = 0, max_tokens: int | None = None) -> ChatOpenAI:
        """Return a ChatOpenAI instance configured with Nokia gateway structure."""
        kwargs = {
            "api_key": LLM_API_KEY,
            "model": LLM_MODEL,
            "reasoning_effort":"medium",
            "base_url": LLM_BASE_URL,
            "default_headers": LLM_HEADERS,
            "temperature": temperature,
        }
        if max_tokens:
            kwargs["max_tokens"] = 16000
        else:
            kwargs["max_tokens"] = 16000
        return ChatOpenAI(**kwargs)
    
    def get_embeddings(self):
        return OpenAIEmbeddings(
            api_key=LLM_API_KEY,
            model=EMBED_MODEL,
            base_url=LLM_BASE_URL,
            default_headers=LLM_HEADERS,
        )


    def invoke(self, messages):
        llm = self.get_llm()
        return llm.invoke(messages)

    def stream(self, messages):
        llm = self.get_llm()
        return llm.stream(messages)

    async def ainvoke(self, messages):
        llm = self.get_llm()
        return await llm.ainvoke(messages)
