"""
PowerPoint (.pptx) export for canvases / templates / individual charts.

Mirrors `canvas_export.render_canvas_pdf` but produces a slide deck:
  • Slide 1 — cover with the report name + LLM-generated executive
              summary headline and 3-4 supporting bullets.
  • Slide 2..N — one slide per chart, each carrying:
        - presentation-polished title at the top
        - one-line headline (LLM)
        - the same matplotlib PNG used by the PDF flow (left ~60%)
        - 3-5 punchy bullets on the right (LLM)
        - speaker notes attached for presenter view (LLM)

The chart image is reused verbatim from `canvas_export._render_chart_png`,
so visual parity between PPT and PDF is automatic. The LLM enrichment is
a single call across the whole deck — on any failure the renderer falls
back to the original description + insight layout so the download never
breaks because of a model hiccup.

Slide format: 16:9 (13.33 × 7.5 in) — fills the standard Office template.
"""
from __future__ import annotations

import datetime as _dt
import io
import json
import logging
import re
from typing import Any

from pptx import Presentation
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN
from pptx.util import Emu, Inches, Pt

from services.canvas_export import _render_chart_png
from services.llm_provider import LLMProvider

logger = logging.getLogger(__name__)

# 16:9 widescreen geometry
_SLIDE_W = Inches(13.333)
_SLIDE_H = Inches(7.5)

# Layout zones on a chart slide.
# The layout adapts at runtime based on chart type: dual-axis (combo) charts
# need extra horizontal room for the second Y-axis, so they get a wider
# chart slot and a narrower side panel. `_layout_for_chart()` returns the
# right tuple for either case.
_TITLE_LEFT,   _TITLE_TOP,   _TITLE_W,   _TITLE_H   = Inches(0.5),  Inches(0.30), Inches(12.3), Inches(0.6)

# Standard layout (single Y-axis charts)
_CHART_LEFT,   _CHART_TOP,   _CHART_W,   _CHART_H   = Inches(0.5),  Inches(1.0),  Inches(8.2),  Inches(6.0)
_SIDE_LEFT,    _SIDE_TOP,    _SIDE_W,    _SIDE_H    = Inches(9.0),  Inches(1.0),  Inches(3.9),  Inches(6.0)

# Wide layout (dual-axis combo charts — second Y axis on the right needs room)
_WIDE_CHART_LEFT, _WIDE_CHART_W = Inches(0.5),  Inches(10.0)
_WIDE_SIDE_LEFT,  _WIDE_SIDE_W  = Inches(10.7), Inches(2.5)


def _layout_for_chart(chart: dict[str, Any]) -> dict[str, Any]:
    """Pick chart slot + side-panel geometry based on chart shape.

    Dual-axis (combo) charts carry `yAxis` as a list of axis configs —
    matplotlib draws two scales (left + right), which eats horizontal
    space. We give those charts ~22% more width so axis labels and bar
    data labels stay legible inside the slide.
    """
    is_dual = isinstance(chart.get("yAxis"), list) and len(chart["yAxis"]) >= 2
    if is_dual:
        return {
            "chart_left":  _WIDE_CHART_LEFT, "chart_top":   _CHART_TOP,
            "chart_w":     _WIDE_CHART_W,    "chart_h":     _CHART_H,
            "side_left":   _WIDE_SIDE_LEFT,  "side_top":    _SIDE_TOP,
            "side_w":      _WIDE_SIDE_W,     "side_h":      _SIDE_H,
        }
    return {
        "chart_left":  _CHART_LEFT, "chart_top": _CHART_TOP,
        "chart_w":     _CHART_W,    "chart_h":   _CHART_H,
        "side_left":   _SIDE_LEFT,  "side_top":  _SIDE_TOP,
        "side_w":      _SIDE_W,     "side_h":    _SIDE_H,
    }

# Pastel deck palette — soft, low-contrast, presentation-friendly.
# Body text stays charcoal so it's readable; accents are washed-out hues.
_TEXT_DARK  = RGBColor(0x33, 0x3D, 0x52)   # soft charcoal (readable, not harsh black)
_TEXT_BODY  = RGBColor(0x4B, 0x55, 0x6C)   # secondary body text
_MUTED      = RGBColor(0x8A, 0x94, 0xA6)   # muted gray for date / captions

_ACCENT     = RGBColor(0xA8, 0xC8, 0xEC)   # pastel sky blue — primary accent
_ACCENT_DEEP= RGBColor(0x6F, 0x9B, 0xD1)   # slightly deeper pastel blue for emphasis text
_HIGHLIGHT  = RGBColor(0xC9, 0xE4, 0xCA)   # pastel sage — secondary accent

_CARD_BG    = RGBColor(0xF8, 0xF5, 0xEE)   # warm cream card background
_CARD_LINE  = RGBColor(0xEC, 0xE6, 0xD8)   # cream border, just visible

# Kept as aliases so existing call sites in this file keep compiling.
_BRAND_DARK = _TEXT_DARK
_BRAND_BLUE = _ACCENT_DEEP


def _safe_filename(name: str) -> str:
    """Strip path separators / weird chars so the value is safe in
    `Content-Disposition: attachment; filename=...`."""
    bad = '\r\n/\\:*?"<>|'
    return "".join(("_" if c in bad else c) for c in (name or "Report")).strip() or "Report"


# ── LLM enrichment ─────────────────────────────────────────────────────────

_FENCE_RE = re.compile(r"^```(?:json)?\s*|\s*```$", re.MULTILINE)


def _strip_fences(text: str) -> str:
    return _FENCE_RE.sub("", (text or "").strip()).strip()


_ENRICH_SYSTEM = """You are turning a report into a polished PowerPoint deck.

You receive:
  1. The REPORT TITLE.
  2. A list of CHARTS — each has a title, description, and a 2-3 line insight already written against fresh data.

Produce STRICT JSON with this exact shape (no commentary, no fences):

{
  "executive_summary": {
    "headline":   "<one declarative sentence answering the report at a glance (≤14 words)>",
    "bullets":    ["<3-4 declarative findings that support the headline, each ≤12 words, quote concrete numbers>"]
  },
  "slides": [
    {
      "presentation_title": "<polished version of the chart title, ≤9 words, no trailing period>",
      "headline":           "<one declarative sentence summarising the chart (≤14 words), MUST quote a concrete number>",
      "bullets":            ["<3-5 declarative findings, each ≤12 words, see BULLET RULES below>"],
      "speaker_notes":      "<2-3 sentence presenter-cue, plain prose, what the speaker should say while showing the slide>"
    }
  ]
}

BULLET RULES (very important — failing these makes the deck unusable):
  • Each bullet states a FACT, not an instruction or a question.
  • Each bullet must start with a NOUN or NUMBER (e.g. "WEST", "17 sites", "CENTRAL accounts for…").
  • NEVER start a bullet with an imperative verb such as: Show, Highlight, Note, Observe,
    Emphasize, Look, Check, See, Consider, Notice, Compare, Examine.
  • Bullets are not titles or speaker cues — they are the punchy headline numbers the audience reads.

Other constraints:
  • The "slides" array MUST have the SAME LENGTH and SAME ORDER as the input charts.
  • Every number you write must appear in (or be derivable from) the chart's insight / description.
  • Round numbers to at most 2 decimal places.
  • No markdown bullets (•, -, *) in any field — give plain text, the renderer adds visual markers.
  • Acronyms (GC, NTM, KPI, WK10) stay uppercase exactly as written.
  • Return ONLY the JSON object. No prose, no fences.

Good bullet examples:
  • "WEST leads with 17 active sites"
  • "12.67-day average duration in WEST"
  • "CENTRAL trails at 10 sites and 0.0 days"
  • "Top 3 contractors hold 17 of the top sites"

Bad bullet examples (DO NOT do this):
  • "Show WEST region with 17 active sites"   ← imperative
  • "Highlight SOUTH region with 13 active sites"  ← imperative
  • "Note CENTRAL's 10 active sites"  ← imperative
  • "Why is WEST leading?"  ← question
"""


def _enrich_deck(report_title: str, charts: list[dict[str, Any]]) -> dict[str, Any] | None:
    """One LLM call → executive summary + per-slide bundles.

    Returns None on any failure (parse error, length mismatch, LLM error) —
    the slide builder then falls back to the original description/insight
    layout so the .pptx download never breaks because of the model.
    """
    if not charts:
        return None

    items: list[dict[str, Any]] = []
    for c in charts:
        t = c.get("title")
        title = (t.get("text") if isinstance(t, dict) else (t or "")) or ""
        items.append({
            "title":       title.strip(),
            "description": (c.get("description") or "").strip(),
            "insight":     (c.get("insight") or "").strip(),
        })

    try:
        provider = LLMProvider()
        resp = provider.invoke([
            ("system", _ENRICH_SYSTEM),
            ("human",
             f"# Report title\n{(report_title or '').strip() or 'Canvas Report'}\n\n"
             f"# Charts ({len(items)})\n{json.dumps(items, ensure_ascii=False)}\n\n"
             "Return the JSON object now."),
        ])
        raw = _strip_fences(getattr(resp, "content", "") or "")
        parsed = json.loads(raw)
    except Exception as exc:
        logger.warning("PPT enrichment LLM call failed: %s — falling back to plain layout", exc)
        return None

    # Shape validation — the renderer needs both keys with the right cardinality.
    if not isinstance(parsed, dict):
        return None
    exec_sum = parsed.get("executive_summary")
    slides = parsed.get("slides")
    if not isinstance(slides, list) or len(slides) != len(items):
        logger.warning("PPT enrichment returned %d slides for %d charts — falling back",
                       len(slides) if isinstance(slides, list) else -1, len(items))
        return None

    def _coerce_slide(s: Any) -> dict[str, Any]:
        if not isinstance(s, dict):
            return {}
        bullets = s.get("bullets") or []
        if not isinstance(bullets, list):
            bullets = []
        return {
            "presentation_title": str(s.get("presentation_title") or "").strip(),
            "headline":           str(s.get("headline") or "").strip(),
            "bullets":            [str(b).strip() for b in bullets if str(b).strip()],
            "speaker_notes":      str(s.get("speaker_notes") or "").strip(),
        }

    def _coerce_summary(s: Any) -> dict[str, Any]:
        if not isinstance(s, dict):
            return {"headline": "", "bullets": []}
        bullets = s.get("bullets") or []
        if not isinstance(bullets, list):
            bullets = []
        return {
            "headline": str(s.get("headline") or "").strip(),
            "bullets":  [str(b).strip() for b in bullets if str(b).strip()],
        }

    return {
        "executive_summary": _coerce_summary(exec_sum),
        "slides":            [_coerce_slide(s) for s in slides],
    }


# ── slide builders ─────────────────────────────────────────────────────────

def _add_title_slide(
    prs: Presentation,
    title: str,
    n_charts: int,
    summary: dict[str, Any] | None = None,
) -> None:
    """Cover slide — title, generated-on, chart count, plus an
    LLM-generated executive headline + supporting bullets when available."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])   # blank
    today = _dt.date.today().isoformat()

    # Soft pastel accent bar across the top — header without harsh contrast.
    top_bar = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), _SLIDE_W, Inches(0.25),
    )
    top_bar.fill.solid()
    top_bar.fill.fore_color.rgb = _ACCENT
    top_bar.line.fill.background()

    # Title
    tb = slide.shapes.add_textbox(Inches(0.7), Inches(0.8), Inches(12.0), Inches(1.4))
    tf = tb.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.alignment = PP_ALIGN.LEFT
    r = p.add_run()
    r.text = title or "Canvas Report"
    r.font.size = Pt(40)
    r.font.bold = True
    r.font.color.rgb = _BRAND_DARK

    # Date + chart count line
    tb2 = slide.shapes.add_textbox(Inches(0.7), Inches(2.15), Inches(12.0), Inches(0.5))
    p2 = tb2.text_frame.paragraphs[0]
    r2 = p2.add_run()
    r2.text = f"Generated {today}  ·  {n_charts} chart(s)"
    r2.font.size = Pt(14)
    r2.font.color.rgb = _MUTED

    # Executive summary card (only when the LLM enrichment succeeded)
    headline = (summary or {}).get("headline", "").strip()
    bullets  = [b for b in ((summary or {}).get("bullets") or []) if b]

    if headline or bullets:
        # Card background — warm cream panel so the summary stands out
        # without the harsh slate-on-white feel.
        card = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE,
            Inches(0.7), Inches(3.0), Inches(11.9), Inches(3.6),
        )
        card.fill.solid()
        card.fill.fore_color.rgb = _CARD_BG
        card.line.color.rgb      = _CARD_LINE

        body = slide.shapes.add_textbox(Inches(1.0), Inches(3.25), Inches(11.3), Inches(3.2))
        sf = body.text_frame
        sf.word_wrap = True

        if headline:
            hp = sf.paragraphs[0]
            hp.space_after = Pt(10)
            hr = hp.add_run()
            hr.text = headline
            hr.font.size = Pt(22)
            hr.font.bold = True
            hr.font.color.rgb = _BRAND_DARK

        for b in bullets:
            bp = sf.add_paragraph()
            bp.space_after = Pt(6)
            # Filled square marker as a "bullet" via a run prefix.
            mark = bp.add_run()
            mark.text = "▸ "
            mark.font.size = Pt(16)
            mark.font.bold = True
            mark.font.color.rgb = _BRAND_BLUE
            br = bp.add_run()
            br.text = b
            br.font.size = Pt(14)
            br.font.color.rgb = _BRAND_DARK

    # Soft pastel accent bar at the bottom — mirrors the top bar.
    bot = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE,
        Inches(0), Inches(7.25), _SLIDE_W, Inches(0.25),
    )
    bot.fill.solid()
    bot.fill.fore_color.rgb = _ACCENT
    bot.line.fill.background()


def _add_chart_slide(
    prs: Presentation,
    chart: dict[str, Any],
    position: int,
    enrichment: dict[str, Any] | None = None,
) -> None:
    """One slide for one chart: polished title at top, chart PNG on the
    left, LLM-shaped headline + bullets on the right, speaker notes in
    the slide's notes pane. Falls back to plain description/insight
    rendering when `enrichment` is None."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])   # blank

    # ── Title (prefer the LLM-polished version when present) ─────────
    chart_title = ""
    t = chart.get("title")
    if isinstance(t, dict):
        chart_title = t.get("text") or ""
    elif isinstance(t, str):
        chart_title = t
    title_text = (enrichment or {}).get("presentation_title") or chart_title or f"Chart {position}"

    tb = slide.shapes.add_textbox(_TITLE_LEFT, _TITLE_TOP, _TITLE_W, _TITLE_H)
    tf = tb.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    r = p.add_run()
    r.text = title_text
    r.font.size = Pt(24)
    r.font.bold = True
    r.font.color.rgb = _BRAND_DARK

    # ── Chart PNG (reuses the same renderer as the PDF flow) ─────────
    # The slide already shows the LLM-polished title at the top, so render
    # the chart image WITHOUT its own embedded title/subtitle. Otherwise
    # matplotlib would burn a second title into the image and we'd see
    # both stacked on top of each other.
    # Layout adapts for dual-axis charts — they get a wider chart slot
    # and a narrower side panel so the second Y-axis has room to breathe.
    lay = _layout_for_chart(chart)
    chart_for_render = {k: v for k, v in chart.items() if k not in ("title", "subtitle")}
    chart_w_in = float(lay["chart_w"]) / 914400.0   # EMU → inches
    chart_h_in = float(lay["chart_h"]) / 914400.0
    png = _render_chart_png(chart_for_render, chart_w_in, chart_h_in)
    if png:
        slide.shapes.add_picture(io.BytesIO(png), lay["chart_left"], lay["chart_top"], lay["chart_w"], lay["chart_h"])
    else:
        ph = slide.shapes.add_textbox(lay["chart_left"], lay["chart_top"], lay["chart_w"], lay["chart_h"])
        ph.text_frame.text = "(unsupported chart type — could not render)"

    # ── Right-hand panel ─────────────────────────────────────────────
    headline = (enrichment or {}).get("headline", "").strip()
    bullets  = [b for b in ((enrichment or {}).get("bullets") or []) if b]

    side = slide.shapes.add_textbox(lay["side_left"], lay["side_top"], lay["side_w"], lay["side_h"])
    sf = side.text_frame
    sf.word_wrap = True

    if headline or bullets:
        # Enriched layout — bold headline + visual bullets.
        if headline:
            hp = sf.paragraphs[0]
            hp.space_after = Pt(8)
            hr = hp.add_run()
            hr.text = headline
            hr.font.size = Pt(15)
            hr.font.bold = True
            hr.font.color.rgb = _BRAND_DARK

        # Subtle "Key takeaways" caption above the bullets, if any.
        if bullets:
            cap = sf.add_paragraph() if headline else sf.paragraphs[0]
            cap.space_before = Pt(4) if headline else Pt(0)
            cap.space_after  = Pt(4)
            cr = cap.add_run()
            cr.text = "KEY TAKEAWAYS"
            cr.font.size = Pt(10)
            cr.font.bold = True
            cr.font.color.rgb = _BRAND_BLUE

        for b in bullets:
            bp = sf.add_paragraph()
            bp.space_after = Pt(4)
            mark = bp.add_run()
            mark.text = "▸ "
            mark.font.size = Pt(13)
            mark.font.bold = True
            mark.font.color.rgb = _BRAND_BLUE
            br = bp.add_run()
            br.text = b
            br.font.size = Pt(12)
            br.font.color.rgb = _BRAND_DARK
    else:
        # Fallback layout — original description + insight blocks.
        desc = (chart.get("description") or "").strip()
        insight = (chart.get("insight") or "").strip()

        def _add_para(label: str, body: str, label_color: RGBColor) -> None:
            p = sf.add_paragraph() if sf.paragraphs[0].text else sf.paragraphs[0]
            p.space_after = Pt(6)
            lr = p.add_run()
            lr.text = f"{label}\n"
            lr.font.size = Pt(12)
            lr.font.bold = True
            lr.font.color.rgb = label_color
            br = p.add_run()
            br.text = body
            br.font.size = Pt(12)
            br.font.color.rgb = _BRAND_DARK

        if desc:
            _add_para("Description", desc, _MUTED)
        if insight:
            if desc:
                sf.add_paragraph()
            _add_para("Insight", insight, _BRAND_BLUE)
        if not desc and not insight:
            sf.text = ""

    # ── Speaker notes (presenter view only — not on the slide itself) ─
    notes_text = (enrichment or {}).get("speaker_notes", "").strip()
    if notes_text:
        try:
            slide.notes_slide.notes_text_frame.text = notes_text
        except Exception as exc:
            logger.debug("speaker notes attach failed: %s", exc)


# ── public entrypoint ──────────────────────────────────────────────────────

def render_canvas_pptx(title: str, slots: list[dict[str, Any]]) -> bytes:
    """Build a .pptx and return its bytes.

    `slots` is the same shape `render_canvas_pdf` consumes — each slot has
    a `chart` key and (ignored here) layout fields. The slide order follows
    canvas reading order: top-to-bottom by `y`, then left-to-right by `x`.
    """
    prs = Presentation()
    prs.slide_width  = _SLIDE_W
    prs.slide_height = _SLIDE_H

    _NS_P = "{http://schemas.openxmlformats.org/presentationml/2006/main}"
    sld_sz = prs._element.find(f"{_NS_P}sldSz")
    if sld_sz is not None and "type" in sld_sz.attrib:
        del sld_sz.attrib["type"]

    # Canvas position order, matching the PDF flow exactly.
    slots_sorted = sorted(
        slots or [],
        key=lambda s: (
            float(s.get("y") if s.get("y") is not None else 0.0),
            float(s.get("x") if s.get("x") is not None else 0.0),
        ),
    )
    charts = [(s.get("chart") or {}) for s in slots_sorted]
    n = len(charts)

    # One LLM call enriches the whole deck — executive summary for the cover
    # + per-slide headline / bullets / speaker notes. None on any failure;
    # the builders silently fall back to the plain layout in that case.
    enrichment = _enrich_deck(title or "Canvas Report", charts) if n else None
    summary = (enrichment or {}).get("executive_summary") if enrichment else None
    per_slide: list[dict[str, Any]] = (enrichment or {}).get("slides", []) if enrichment else []

    _add_title_slide(prs, title or "Canvas Report", n, summary=summary)
    if n == 0:
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        tb = slide.shapes.add_textbox(Inches(1.0), Inches(3.0), Inches(11.3), Inches(1.0))
        tb.text_frame.text = "This canvas has no charts."
    else:
        for i, ch in enumerate(charts, 1):
            slide_enr = per_slide[i - 1] if i - 1 < len(per_slide) else None
            _add_chart_slide(prs, ch, i, enrichment=slide_enr)

    buf = io.BytesIO()
    prs.save(buf)
    return buf.getvalue()


# ── JSON preview ───────────────────────────────────────────────────────────
#
# Same enrichment + chart PNGs the .pptx renderer uses, but returned as a
# JSON-friendly dict so the React UI can show slides without parsing the
# binary .pptx. The browser renders the layout in HTML/CSS for fast nav.

import base64 as _b64


def render_canvas_slide_preview(title: str, slots: list[dict[str, Any]]) -> dict[str, Any]:
    """Return slide deck content (title slide + chart slides) as a JSON
    dict the UI can render. Each chart slide carries a base64 PNG of the
    chart so the preview shows exactly what the .pptx will look like."""
    slots_sorted = sorted(
        slots or [],
        key=lambda s: (
            float(s.get("y") if s.get("y") is not None else 0.0),
            float(s.get("x") if s.get("x") is not None else 0.0),
        ),
    )
    charts = [(s.get("chart") or {}) for s in slots_sorted]
    n = len(charts)

    enrichment = _enrich_deck(title or "Canvas Report", charts) if n else None
    summary    = (enrichment or {}).get("executive_summary") if enrichment else None
    per_slide  = (enrichment or {}).get("slides", []) if enrichment else []

    slides: list[dict[str, Any]] = []

    # Title slide
    slides.append({
        "type":         "title",
        "title":        title or "Canvas Report",
        "generated_on": _dt.date.today().isoformat(),
        "n_charts":     n,
        "headline":     (summary or {}).get("headline", "") if summary else "",
        "bullets":      [b for b in ((summary or {}).get("bullets") or []) if b] if summary else [],
    })

    for i, ch in enumerate(charts, 1):
        slide_enr = per_slide[i - 1] if i - 1 < len(per_slide) else {}

        # Match the .pptx layout: standard 8.2"×6", dual-axis 10.0"×6".
        is_dual = isinstance(ch.get("yAxis"), list) and len(ch["yAxis"]) >= 2
        chart_w_in = 10.0 if is_dual else 8.2
        chart_h_in = 6.0

        chart_for_render = {k: v for k, v in ch.items() if k not in ("title", "subtitle")}
        png = _render_chart_png(chart_for_render, chart_w_in, chart_h_in)
        png_b64 = _b64.b64encode(png).decode("ascii") if png else None

        chart_title = ""
        t = ch.get("title")
        if isinstance(t, dict): chart_title = t.get("text") or ""
        elif isinstance(t, str): chart_title = t

        slides.append({
            "type":               "chart",
            "chart_id":           ch.get("chart_id"),
            "presentation_title": slide_enr.get("presentation_title") or chart_title or f"Chart {i}",
            "headline":           slide_enr.get("headline", ""),
            "bullets":            slide_enr.get("bullets") or [],
            "speaker_notes":      slide_enr.get("speaker_notes", ""),
            "chart_png_base64":   png_b64,
            "is_dual_axis":       is_dual,
            # Fallback content for when the LLM enrichment fails.
            "description":        (ch.get("description") or "").strip(),
            "insight":            (ch.get("insight") or "").strip(),
        })

    return {
        "title":    title or "Canvas Report",
        "n_slides": len(slides),
        "slides":   slides,
    }
