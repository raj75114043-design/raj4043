"""
Chart-edit service — schema-aware natural-language patcher.

Takes a Highcharts config + an NL instruction (e.g. "make the bars red",
"rotate the pie 30 degrees", "rename the x-axis to Market") and returns the
patched config. The LLM is given the EXACT per-type schema so it knows which
key to mutate without breaking validation.

Two flavours, dispatched on `chart.chart.type`:
  cartesian  → CartesianChart schema
  pie / donut → PieChart schema

Output is validated against `models.chart_types.parse_chart` before returning.
If the LLM produces something off-schema, we raise ValueError so the caller
can surface a clean 400.
"""
from __future__ import annotations

import json
import logging
import time
from typing import Any

from pydantic import ValidationError

from models.chart_types import (
    CARTESIAN_TYPES,
    PIE_TYPES,
    parse_chart,
)
from services.llm_provider import LLMProvider

logger = logging.getLogger(__name__)


# ── Per-type schema cheat sheets the LLM sees ───────────────────────────────

_CARTESIAN_REFERENCE = """\
This is a CARTESIAN chart (chart.type ∈ {column, bar, line, area, spline, areaspline, scatter}).
The underlying numbers do not change on an edit — only the visualization. You may switch
between cartesian sub-types freely (e.g. column → line). You may also switch to pie/donut
ONLY when the chart has exactly one series — set chart.type to "pie" or "donut"; the server
will repackage the categories + values into pie slices automatically. Multi-series cartesian
charts cannot become pies.

DUAL-AXIS (combo) charts: if the chart you are editing has `yAxis` as a LIST of two axis
configs and per-series `yAxis: 0|1` + `type: ...` overrides, it is a combo chart. Treat
it the same way — only the visualization fields below are editable. You MAY:
  * Keep dual-axis structure intact and tweak per-series colors/names/types within the
    cartesian family (e.g. "make the duration line a spline instead").
  * Add or remove the second axis only if the user explicitly asks for it.
NEVER reshape `yAxis` from list to object (or vice versa) silently.
NEVER change which `series[i].yAxis` index a series points at unless asked.

Mutate ONLY these keys:
  chart.type           — within {column, bar, line, area, spline, areaspline, scatter, pie, donut}
  colors[]             — top-level palette; affects every series in order
  series[i].color      — override one series' color
  series[i].name       — series label in legend / tooltip
  series[i].type       — per-series type override (combo chart). Within cartesian family only.
  series[i].yAxis      — 0|1 axis index (combo chart). Don't change unless explicitly asked.
  series[i].stack      — stack group name for column/bar series. Only edit if asked.
  title.text           — chart title
  subtitle.text        — scope context line
  xAxis.categories[]   — x-tick labels (REORDER only — don't drop unless user says)
  xAxis.title.text     — x axis title
  yAxis.title.text     — y axis title (single-axis chart)
  yAxis[0|1].title.text — axis titles when yAxis is a 2-element list (combo chart)
  yAxis.min / max      — bound the y axis if asked
  legend.enabled       — show / hide legend
  tooltip.valueSuffix  — unit suffix
  plotOptions.<type>.dataLabels.enabled — show / hide value labels
  plotOptions.<type>.stacking — "normal" / "percent" for stacked variants
NEVER touch series[i].data values — they are flat numbers and stay as-is.
NEVER reshape series[i].data into objects ({name, y}) — that is the pie shape and is invalid here."""

_PIE_REFERENCE = """\
This is a PIE chart (chart.type ∈ {pie, donut}).
The underlying numbers do not change on an edit — only the visualization. You may switch
between pie and donut freely. You may also switch to a cartesian type (column / bar / line /
area / spline / areaspline / scatter) — set chart.type accordingly; the server will move the
slice names → x-axis categories and slice values → flat numeric data automatically.
Mutate ONLY these keys:
  chart.type            — within {pie, donut, column, bar, line, area, spline, areaspline, scatter}
  colors[]              — slice palette (order matches series[0].data)
  series[0].name        — series label
  series[0].data[i].name  — slice label
  series[0].data[i].color — per-slice color override
  title.text            — chart title
  subtitle.text         — scope context line
  legend.enabled        — show / hide legend
  tooltip.valueSuffix   — unit suffix
  plotOptions.pie.dataLabels.enabled / format — slice labels
  plotOptions.pie.startAngle / innerSize — rotation / donut hole size
NEVER touch series[0].data[i].y values — slice magnitudes stay as-is.
NEVER flatten series[0].data into a list of plain numbers — that is the cartesian shape and is invalid here."""


# Identity / non-visual keys the chart edit MUST NOT touch — script, the
# rendered insight, the chart's stable id, the SQL row pointer, and the
# 1-line description. The prompt tells the LLM to leave them alone, but we
# also force-overwrite them after the round-trip so a modified or dropped
# value can never reach the DB. Visualization edits (colors, titles, legend,
# axis labels, slice names, etc.) are the ONLY things that change.
_IDENTITY_KEYS = ("chart_id", "script", "sql_index", "description", "insight")


def _system_prompt(chart_type: str) -> str:
    if chart_type in CARTESIAN_TYPES:
        type_block = _CARTESIAN_REFERENCE
    elif chart_type in PIE_TYPES:
        type_block = _PIE_REFERENCE
    else:
        type_block = "(Unknown chart type — proceed with caution.)"

    return (
        "You are a Highcharts chart-config editor. You receive a chart's full\n"
        "JSON options object and one natural-language edit instruction. Return\n"
        "the SAME object with the instruction applied.\n\n"
        f"{type_block}\n\n"
        "Hard rules:\n"
        "  * Output ONLY the updated JSON object. No markdown fences, no commentary.\n"
        "  * READ-ONLY keys — copy verbatim, never rephrase, refactor, or drop:\n"
        "      chart_id, script, sql_index, description, insight.\n"
        "    Even if the user's instruction implies a wording change, leave them\n"
        "    untouched. The server will overwrite any modifications you make to these.\n"
        "  * The underlying data values are FIXED — only the visualization changes.\n"
        "  * Never invent, drop, or reshape series data values. Keep series[i].data exactly as given.\n"
        "  * Match the existing color-hex format (e.g. \"#2E86AB\").\n"
        "  * If the instruction is ambiguous, make the smallest, most conservative edit that satisfies it.\n"
        "  * Round any new numeric values you DO add (axis bounds, etc.) to 2 decimals.\n"
    )


def _to_pie_slices(orig_series: list[Any], orig_categories: list[Any] | None) -> list[dict[str, Any]] | None:
    """Repackage a single cartesian series into pie slices: [{name, y}, …].

    Preserves the underlying numbers — only the wrapper changes. Returns None
    if the source isn't safely transformable (e.g. multi-series, no categories,
    or row-count mismatch). Callers fall back to blocking the type change.
    """
    if not orig_series or len(orig_series) != 1:
        return None
    s0 = orig_series[0]
    if not isinstance(s0, dict):
        return None
    data = s0.get("data")
    if not isinstance(data, list) or not data:
        return None
    cats = orig_categories or []
    if not isinstance(cats, list) or len(cats) != len(data):
        return None
    slices: list[dict[str, Any]] = []
    for cat, val in zip(cats, data):
        if not isinstance(cat, str) or not cat.strip():
            return None
        if val is None or not isinstance(val, (int, float)):
            return None
        slices.append({"name": cat, "y": val})
    return slices


def _to_cartesian_data(orig_series: list[Any]) -> tuple[list[str], list[float | int]] | None:
    """Repackage a pie's slice list into (categories, flat-numeric-data)
    for a cartesian chart. Returns None if the source isn't safely
    transformable.
    """
    if not orig_series or len(orig_series) != 1:
        return None
    s0 = orig_series[0]
    if not isinstance(s0, dict):
        return None
    data = s0.get("data")
    if not isinstance(data, list) or not data:
        return None
    cats: list[str] = []
    vals: list[float | int] = []
    for slc in data:
        if not isinstance(slc, dict):
            return None
        name = slc.get("name")
        y    = slc.get("y")
        if not isinstance(name, str) or not name.strip():
            return None
        if y is None or not isinstance(y, (int, float)):
            return None
        cats.append(name)
        vals.append(y)
    return cats, vals


def _strip_fences(text: str) -> str:
    text = (text or "").strip()
    if text.startswith("```"):
        nl = text.find("\n")
        if nl >= 0:
            text = text[nl + 1:]
        if text.rstrip().endswith("```"):
            text = text.rstrip()[:-3]
    return text.strip()


def apply_chart_edit(
    chart_config: dict[str, Any],
    instruction: str,
    model: str = "gpt-4o",
) -> dict[str, Any]:
    """Return a patched copy of `chart_config` reflecting `instruction`.

    The LLM is given the per-type schema for the chart's type so it knows
    which exact key/value to touch. Output is then validated against the
    strict CartesianChart / PieChart Pydantic schema. ValueError is raised
    on empty instruction, invalid LLM JSON, or schema mismatch.
    """
    if not instruction or not instruction.strip():
        raise ValueError("Edit instruction is empty.")

    chart_type = ((chart_config.get("chart") or {}).get("type") or "").lower()
    if chart_type not in CARTESIAN_TYPES and chart_type not in PIE_TYPES:
        raise ValueError(
            f"Cannot edit chart of unknown type {chart_type!r}. "
            f"Allowed: {list(CARTESIAN_TYPES) + list(PIE_TYPES)}"
        )

    # Preserve identity / runtime fields — the LLM is told not to touch them
    # but we re-attach them after the round-trip just in case.
    preserved = {k: chart_config[k] for k in _IDENTITY_KEYS if k in chart_config}

    # Snapshot the chart family + raw data values. These are the schema-load-bearing
    # fields: a pie has list[{name, y}] data and no xAxis; a cartesian has list[number]
    # data and a categorical xAxis. If the LLM crosses families OR reshapes data,
    # `parse_chart` rejects the result. We restamp these from the original after the
    # call so a misbehaving model can't take the edit off-schema.
    original_family = "cartesian" if chart_type in CARTESIAN_TYPES else "pie"
    original_chart_type = chart_type
    original_series = chart_config.get("series") if isinstance(chart_config.get("series"), list) else None

    user_message = (
        f"# Current chart options (JSON)\n{json.dumps(chart_config, default=str)}\n\n"
        f"# Edit instruction\n{instruction.strip()}\n\n"
        "Return the updated options object."
    )

    provider = LLMProvider()
    t0 = time.perf_counter()
    resp = provider.invoke([
        ("system", _system_prompt(chart_type)),
        ("human",  user_message),
    ])
    elapsed_ms = (time.perf_counter() - t0) * 1000

    raw = _strip_fences(getattr(resp, "content", "") or "")
    try:
        patched = json.loads(raw)
    except json.JSONDecodeError as e:
        logger.error("Chart-edit JSON parse failed: %s | preview=%s", e, raw[:200])
        raise ValueError(f"LLM did not return valid JSON: {e}")

    if not isinstance(patched, dict):
        raise ValueError(f"LLM returned a {type(patched).__name__}, expected object.")

    # Force-overwrite identity / non-visual fields. The chart edit operates
    # purely on visualization — script, insight, description, chart_id, and
    # sql_index always come from the original. If the LLM modified them
    # (rephrasing the insight, "fixing" the script, …), those changes are
    # discarded here.
    for k, v in preserved.items():
        patched[k] = v

    # Resolve chart.type. Within-family swaps (column ↔ line, pie ↔ donut)
    # are passed through. Cross-family swaps (cartesian ↔ pie) reshape data,
    # so we either repackage the original numbers into the new shape or — if
    # that isn't safe (e.g. multi-series cartesian → pie) — restamp the type
    # back to the original. The `final_family` we end up with drives the
    # data restamp below.
    new_chart_block = patched.get("chart") if isinstance(patched.get("chart"), dict) else None
    new_type = (new_chart_block or {}).get("type", "").lower() if new_chart_block else ""
    crossed_family = (
        (original_family == "cartesian" and new_type in PIE_TYPES) or
        (original_family == "pie"       and new_type in CARTESIAN_TYPES)
    )
    unknown_type = new_type not in CARTESIAN_TYPES and new_type not in PIE_TYPES

    final_family = original_family
    if unknown_type:
        # LLM dropped or mangled chart.type — keep the original.
        if new_chart_block is None:
            patched["chart"] = {"type": original_chart_type}
        else:
            new_chart_block["type"] = original_chart_type
    elif crossed_family:
        orig_categories = ((chart_config.get("xAxis") or {}).get("categories")
                           if isinstance(chart_config.get("xAxis"), dict) else None)
        if original_family == "cartesian" and new_type in PIE_TYPES:
            slices = _to_pie_slices(original_series or [], orig_categories)
            if slices is None:
                # Not safely transformable — block the type change.
                if new_chart_block is not None:
                    new_chart_block["type"] = original_chart_type
            else:
                # Build the pie shape: drop xAxis/yAxis, write a single
                # pie series with the repackaged slices.
                series0_name = "Series"
                if isinstance(original_series, list) and original_series:
                    s0 = original_series[0]
                    if isinstance(s0, dict) and isinstance(s0.get("name"), str) and s0["name"].strip():
                        series0_name = s0["name"]
                patched["series"] = [{"name": series0_name, "data": slices}]
                patched.pop("xAxis", None)
                patched.pop("yAxis", None)
                final_family = "pie"
        else:  # pie → cartesian
            cv = _to_cartesian_data(original_series or [])
            if cv is None:
                if new_chart_block is not None:
                    new_chart_block["type"] = original_chart_type
            else:
                cats, vals = cv
                series0_name = "Series"
                if isinstance(original_series, list) and original_series:
                    s0 = original_series[0]
                    if isinstance(s0, dict) and isinstance(s0.get("name"), str) and s0["name"].strip():
                        series0_name = s0["name"]
                patched["series"] = [{"name": series0_name, "data": vals}]
                patched["xAxis"]  = {"categories": cats}
                final_family = "cartesian"

    # Pin the data values for in-family edits. The script + numbers are sacred
    # on a chart edit — only visualization changes. (Cross-family branches
    # above already wrote the canonical data into `patched`, so they short-
    # circuit out via final_family.)
    if not crossed_family and isinstance(original_series, list) and isinstance(patched.get("series"), list):
        if final_family == "cartesian":
            for i, orig_s in enumerate(original_series):
                if i >= len(patched["series"]):
                    break
                new_s = patched["series"][i]
                if isinstance(orig_s, dict) and isinstance(new_s, dict) and isinstance(orig_s.get("data"), list):
                    new_s["data"] = orig_s["data"]
        else:  # pie
            for i, orig_s in enumerate(original_series):
                if i >= len(patched["series"]):
                    break
                new_s = patched["series"][i]
                if not (isinstance(orig_s, dict) and isinstance(new_s, dict)):
                    continue
                orig_data = orig_s.get("data")
                new_data = new_s.get("data")
                if not isinstance(orig_data, list):
                    continue
                if not isinstance(new_data, list):
                    new_s["data"] = orig_data
                    continue
                for j, orig_slice in enumerate(orig_data):
                    if j >= len(new_data):
                        break
                    new_slice = new_data[j]
                    if isinstance(orig_slice, dict) and isinstance(new_slice, dict) and "y" in orig_slice:
                        new_slice["y"] = orig_slice["y"]

    # Validate against the strict per-type schema.
    try:
        parse_chart(patched)
    except (ValidationError, ValueError) as e:
        logger.error("Chart-edit produced off-schema output: %s", e)
        raise ValueError(f"Edited chart failed schema validation: {e}")

    patched["_edit_history"] = (chart_config.get("_edit_history") or []) + [{
        "instruction": instruction.strip(),
        "at": time.time(),
        "elapsed_ms": round(elapsed_ms, 2),
    }]
    return patched
