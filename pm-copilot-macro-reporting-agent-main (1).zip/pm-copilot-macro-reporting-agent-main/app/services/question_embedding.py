"""
Question-embedding background service.

When a user asks a question via SSE, we want to remember that intent so
the "top frequently asked" endpoint can rank popularity. Plain text-dedup
loses paraphrases; intent-dedup catches them via embedding similarity.

Public surface:

    record_question(user_id: str, question: str) -> None

Designed to run on a daemon thread fired off from the SSE endpoint —
catches every exception, never raises, never blocks the caller.

Pipeline per call (~250-400ms total, all off the request thread):
  1. Normalize the question (whitespace + casing only — for logging)
  2. Embed via OpenAI text-embedding-3-small (1536-dim)
  3. Load every existing canonical embedding, find argmax cosine
  4. If best similarity ≥ SIMILARITY_THRESHOLD → match
       UPSERT the user-link row; bump canonical.ask_count IF this
       is a new (canonical, user) pair.
     Otherwise → new intent, create canonical + user-link rows.
"""
from __future__ import annotations
from app.services.llm_provider import LLMProvider
import numpy as np

import logging
import math
import os
import re
import threading
from typing import Any

from openai import OpenAI

import config
from services import db_service

logger = logging.getLogger(__name__)


EMBED_MODEL = "text-embedding-3-small"   # 1536-dim, cheap, accurate for short text
# ≥ this = same intent. Picked empirically against text-embedding-3-small
# on real business questions (see scripts/sim_calibration.py):
# - cross-intent similarities top out at ~0.45
# - intra-intent paraphrases drop as low as 0.49 when terminology
#   shifts (e.g. "general contractors" ↔ "GCs")
# 0.60 sits comfortably above the cross-intent ceiling while catching
# almost all real paraphrases. Combined with centroid drift below,
# missed paraphrases get re-united on subsequent calls.
SIMILARITY_THRESHOLD = 0.55

# Process-local lock for the lookup → upsert critical section.
# Two daemon threads finishing their OpenAI embedding at the same moment
# would otherwise both see "no canonical match" and each INSERT a new
# row — duplicate canonicals for the same intent. Serializing just the
# DB step (NOT the OpenAI call) keeps concurrency where it matters.
# Note: this is per-process. With multiple uvicorn workers, would need
# a Postgres advisory lock instead — out of scope here (single-worker).
_REGISTRY_LOCK = threading.Lock()

_WS_RE = re.compile(r"\s+")


def _normalize(q: str) -> str:
    """Light whitespace + casing fixup. The embedding does the heavy lifting."""
    return _WS_RE.sub(" ", (q or "").strip().lower()).rstrip(".!?")


def _openai_client() -> OpenAI:
    return OpenAI(api_key=config.OPENAI_API_KEY or os.getenv("OPENAI_API_KEY"))


def _cosine(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two equal-length float vectors."""
    if not a or not b:
        return 0.0
    n = min(len(a), len(b))
    dot = 0.0
    na  = 0.0
    nb  = 0.0
    for i in range(n):
        x, y = a[i], b[i]
        dot += x * y
        na  += x * x
        nb  += y * y
    if na <= 0.0 or nb <= 0.0:
        return 0.0
    return dot / (math.sqrt(na) * math.sqrt(nb))


def _best_match(query_embedding: list[float],
                canonicals: list[dict[str, Any]]) -> tuple[int | None, float]:
    """Return (canonical_id, best_similarity) for the nearest canonical
    above SIMILARITY_THRESHOLD, else (None, best_similarity_below)."""
    best_id = None
    best_sim = 0.0
    for c in canonicals:
        sim = _cosine(query_embedding, c.get("embedding") or [])
        if sim > best_sim:
            best_sim = sim
            if sim >= SIMILARITY_THRESHOLD:
                best_id = c["canonical_id"]
    return best_id, best_sim


def _blend_centroid(old: list[float], new: list[float], old_count: int) -> list[float]:
    """Weighted running mean — `old` represents `old_count` prior questions,
    `new` is one more. Returns the centroid after adding `new`."""
    n = len(old)
    if n != len(new) or n == 0 or old_count <= 0:
        return list(new)
    denom = old_count + 1
    return [(old[i] * old_count + new[i]) / denom for i in range(n)]


def record_question(user_id: str, question: str) -> None:
    """Background entry-point — never raises.

    Skip silently when:
      * question is empty / whitespace
      * user_id is empty
      * OpenAI key isn't configured
      * any DB / network error happens (just logged)
    """
    try:
        q = (question or "").strip()
        if not q or not user_id:
            return

        provider = LLMProvider()
        embeddings = provider.get_embeddings() 
        v = np.asarray(embeddings.embed_query(q), dtype=np.float32)
        n = np.linalg.norm(v) or 1.0
        embedding = (v/n).tolist()
        # 2 + 3. Lookup-then-upsert is one critical section: any other
        # daemon thread waits, so it will see this insert when it does
        # its own list_canonical_questions() call.
        with _REGISTRY_LOCK:
            canonicals = db_service.list_canonical_questions()
            match_id, best_sim = _best_match(embedding, canonicals)

            # Centroid drift — when a question matches an existing intent,
            # blend its embedding into the canonical's. After N matches
            # the canonical's embedding is the running mean of all the
            # paraphrases it covers, which makes future near-paraphrases
            # easier to catch even when they're far from the FIRST wording.
            matched_canonical_embedding = None
            if match_id is not None:
                for c in canonicals:
                    if c["canonical_id"] == match_id:
                        matched_canonical_embedding = c["embedding"]
                        break

            out = db_service.upsert_question_record(
                user_id=user_id,
                question=q,
                embedding=embedding,
                canonical_id=match_id,
                display_text=q if match_id is None else None,
            )

            # Centroid drift: after a NEW user joins this intent, blend
            # their embedding into the canonical so the centroid follows
            # the cluster's actual mean. ask_count_after is post-update,
            # so the OLD count was (ask_count_after - 1).
            ask_count_after = out.get("ask_count_after")
            if (match_id is not None
                and matched_canonical_embedding is not None
                and out.get("created_user_link")
                and ask_count_after and ask_count_after >= 2
                and len(matched_canonical_embedding) == len(embedding)):
                blended = _blend_centroid(
                    matched_canonical_embedding,
                    embedding,
                    old_count=ask_count_after - 1,
                )
                db_service.update_canonical_embedding(match_id, blended)

        if out.get("created_canonical"):
            logger.info("question:new-intent  user=%s  canonical_id=%s  question=%r",
                        user_id, out.get("canonical_id"), q[:80])
        elif out.get("created_user_link"):
            logger.info("question:new-user→intent  user=%s  canonical_id=%s  sim=%.3f",
                        user_id, match_id, best_sim)
        else:
            logger.debug("question:duplicate-for-user  user=%s  canonical_id=%s  sim=%.3f",
                         user_id, match_id, best_sim)

    except Exception as exc:
        logger.warning("record_question failed (user=%s): %s", user_id, exc)
