"""
Scheduled email job — Pydantic models.

Backs `pwc_agent_utility_schema.reporting_email_scheduled_jobs`. A scheduled
job re-runs a saved template at a wall-clock time on selected weekdays and
emails the resulting PDF via the Nokia email API. The API layer CRUDs these
rows; a separate cron / worker process is responsible for actually firing
the jobs at their `schedule_time`.

Three model flavours follow the project's existing convention:
  * `ScheduledEmailJobIn`     — body for POST (create)
  * `ScheduledEmailJobUpdate` — body for PATCH (partial)
  * `ScheduledEmailJobOut`    — server → client response shape
"""
from __future__ import annotations

from datetime import datetime, time
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

# Email addresses are validated as plain strings to match the existing
# `_EmailRequest` shape in canvas/template endpoints — no extra dependency
# on `pydantic[email]`. Format checking happens at the email-API call site.

# Three-letter weekday codes — matches the array stored in `days_of_week`.
WeekdayCode = Literal["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"]


class ScheduledEmailJobIn(BaseModel):
    """Body for `POST /api/v1/scheduled-emails`.

    `days_of_week` is optional — omit (or send an empty list) to run every
    day at `schedule_time`. `schedule_time_zone` defaults to UTC; use a
    standard tz database name (`Asia/Kolkata`, `America/New_York`, …) when
    the schedule should follow a regional clock.
    """
    user_id:            str = Field(..., min_length=1, max_length=100, description="Owner of the schedule")
    template_id:        str = Field(..., min_length=1, max_length=100, description="Template whose scripts get re-run")

    is_enabled:         bool = Field(default=True, description="Off by default disables firing without deleting the row")

    schedule_time:      list[time] = Field(
        ..., min_length=1,
        description="One or more wall-clock times-of-day (HH:MM:SS each). "
                    "Multiple values fire the job multiple times per active day.",
    )
    schedule_time_zone: str  = Field(default="UTC", max_length=50, description="IANA tz name, e.g. 'Asia/Kolkata'")
    days_of_week:       list[WeekdayCode] | None = Field(
        default=None,
        description="Run only on these weekdays. None / [] = run every day.",
    )

    to_list:            list[str] = Field(..., min_length=1, description="Recipient addresses (≥1)")
    cc_list:            list[str] = Field(default_factory=list)
    bcc_list:           list[str] = Field(default_factory=list)
    subject:            str       = Field(..., min_length=1, description="Email subject line")
    email_body:         str       = Field(..., min_length=1, description="Plain-text email body")

    model_config = ConfigDict(
        extra="ignore",
        json_schema_extra={"example": {
            "user_id":            "u_123",
            "template_id":        "tmpl_q2_ntm_runrate",
            "is_enabled":         True,
            "schedule_time":      ["07:30:00", "19:00:00"],
            "schedule_time_zone": "Asia/Kolkata",
            "days_of_week":       ["MON", "WED", "FRI"],
            "to_list":            ["lead@nokia.com"],
            "cc_list":            ["pmo@nokia.com"],
            "bcc_list":           [],
            "subject":            "Weekly NTM Run-Rate",
            "email_body":         "Hi team — attached is the weekly NTM run-rate report.",
        }},
    )


class ScheduledEmailJobUpdate(BaseModel):
    """Body for `PATCH /api/v1/scheduled-emails/{id}`. Every field optional;
    omitted fields stay as-is. `template_id` and `user_id` are intentionally
    NOT patchable — change those by deleting the job and re-creating."""
    is_enabled:         bool | None = None
    schedule_time:      list[time] | None = Field(default=None, min_length=1)
    schedule_time_zone: str  | None = Field(default=None, max_length=50)
    days_of_week:       list[WeekdayCode] | None = None

    to_list:            list[str] | None = Field(default=None, min_length=1)
    cc_list:            list[str] | None = None
    bcc_list:           list[str] | None = None
    subject:            str | None = Field(default=None, min_length=1)
    email_body:         str | None = Field(default=None, min_length=1)

    model_config = ConfigDict(extra="ignore")


class ScheduledEmailJobOut(BaseModel):
    """Server → client shape. Mirrors the DB row 1:1, includes timestamps
    and the `last_run_*` audit fields the worker writes back."""
    id:                  int
    user_id:             str
    template_id:         str

    is_enabled:          bool
    schedule_time:       list[time]
    schedule_time_zone:  str
    days_of_week:        list[str] | None

    to_list:             list[str]
    cc_list:             list[str]
    bcc_list:            list[str]
    subject:             str
    email_body:          str

    last_run_time:        datetime | None
    last_run_mail_status: str | None

    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(extra="ignore")
