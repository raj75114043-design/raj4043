#!/bin/bash
set -e

exec python -m uvicorn risk_agent.api:app --host 0.0.0.0 --port 8000 --workers 2 --log-config /dev/null
