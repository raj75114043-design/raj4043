#!/usr/bin/env bash
# Simple smoke test — checks that the API comes up and reports healthy.
set -euo pipefail

HOST="${1:-http://localhost:8000}"

echo "[*] checking $HOST/health ..."
curl -fsS "$HOST/health" | grep -q '"ok"' && echo "[+] /health OK"

echo "[*] checking $HOST/ready ..."
curl -fsS "$HOST/ready" | grep -q '"ready"' && echo "[+] /ready OK"

echo "[*] checking $HOST/metrics ..."
curl -fsS "$HOST/metrics" | head -5 && echo "[+] /metrics OK"

echo "[✓] smoke test passed"
