#!/usr/bin/env python
"""Generate a sample risk catalog Excel file for local development.

Usage:
    python scripts/generate_sample_catalog.py [output_path]
"""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd


SAMPLE_ROWS = [
    {
        "category_id": "RISK_NDPD_001",
        "name": "NDPd Missing Sites",
        "description": (
            "Sites that exist in Magenta Build but are missing from NDPd. "
            "Risks delayed project creation and plan achievement."
        ),
        "identification_logic": (
            "Find rows in magenta_build whose project_id does not appear in ndpd_projects, "
            "excluding the excluded POR_PROGRAM_NAME list, where "
            "milestone_4225_construction_start_status = 'P' and "
            "por_hc_release_date is not null."
        ),
        "decision_rules": (
            "Severity HIGH when por_hc_release_date is within the next 60 days\n"
            "Severity MEDIUM when between 60 and 120 days\n"
            "Severity LOW otherwise"
        ),
        "owner": "Network Planning",
        "tags": "ndpd, site-mod, plan-achievement",
    },
    {
        "category_id": "RISK_VENDOR_001",
        "name": "Vendor SLA Breach Precursor",
        "description": (
            "Vendors trending toward SLA breach on in-flight milestones."
        ),
        "identification_logic": (
            "Look at projects in flight (status IN ('active','in_progress')) whose vendor "
            "milestone slippage exceeds 7 days in the last 14 days."
        ),
        "decision_rules": (
            "Severity HIGH when slippage > 14 days\n"
            "Severity MEDIUM when slippage between 7 and 14 days"
        ),
        "owner": "Vendor Management",
        "tags": "vendor, sla",
    },
    {
        "category_id": "RISK_FINANCE_001",
        "name": "Budget Overrun Indicator",
        "description": (
            "Projects where committed spend trends toward exceeding approved budget."
        ),
        "identification_logic": (
            "For each project, compare actual_spend_ytd against budget_approved. "
            "Flag where actual_spend_ytd / budget_approved > 0.85 and project is < 60% complete."
        ),
        "decision_rules": (
            "Severity HIGH when spend ratio > 0.95\n"
            "Severity MEDIUM when between 0.85 and 0.95"
        ),
        "owner": "Finance",
        "tags": "finance, budget",
    },
]


def main() -> int:
    out = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("data/risk_categories.xlsx")
    out.parent.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(SAMPLE_ROWS)
    df.to_excel(out, index=False)
    print(f"Wrote {len(df)} categories to {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
