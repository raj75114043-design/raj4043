# SQL Step Retry Mechanism

## Overview
The planner now automatically retries rejected steps **up to 2 times**, passing the specific rejection reason to the LLM so it can fix the issues.

## Flow Diagram

```
┌─────────────────────────────────────────┐
│ 1. Initial LLM Planning                  │
│ (Generate SQL steps)                     │
└──────────────┬──────────────────────────┘
               │
               ▼
        ┌──────────────┐
        │  Validate    │
        │  Each Step   │
        └──┬────────┬──┘
           │        │
    PASS   │        │ FAIL
           │        │
           ▼        ▼
       ✓ Keep    ✗ Collect error reason
           │        │
           └────┬───┘
                │
                ▼
     ┌─────────────────────┐
     │ Any rejected steps? │
     └────┬────────────┬───┘
          │            │
         NO           YES (go to retry)
          │            │
          │            ▼
          │     ┌─────────────────────────┐
          │     │ RETRY ATTEMPT 1         │
          │     │ (Send LLM feedback)     │
          │     │ Show rejection reasons  │
          │     └─────┬────────────┬──────┘
          │           │            │
          │      PASS │            │ FAIL
          │           │            │
          │           ▼            ▼
          │       ✓ Keep       Collect new
          │           │        error reasons
          │           │            │
          │           └────┬───────┘
          │                │
          │                ▼
          │     ┌──────────────────────────┐
          │     │ Retry attempt 1 < 2?    │
          │     └────┬──────────────────┬──┘
          │          │                  │
          │         YES                NO
          │          │                  │
          │          ▼                  │
          │     ┌──────────────────────┐ │
          │     │ RETRY ATTEMPT 2      │ │
          │     │ (Same process)       │ │
          │     └─────┬────────────┬───┘ │
          │           │            │     │
          │      PASS │            │ FAIL
          │           │            │     │
          │           ▼            ▼     │
          │       ✓ Keep       Give up   │
          │           │          on      │
          │           │        remaining │
          │           │        rejections│
          │           │            │     │
          └───────────┴────┬───────┴─────┘
                            │
                            ▼
                    ┌─────────────────┐
                    │ Return Results  │
                    │ - Accepted steps│
                    │ - Error list    │
                    └─────────────────┘
```

## Example: Before and After

### BEFORE (No Retry)

**Initial LLM Response:**
```json
{
  "steps": [
    {
      "source": "semantic_kpi",
      "name": "Check missing billing_id",
      "sql_query": "UPDATE table SET field='value' WHERE id=1"  // ❌ UPDATE not allowed
    },
    {
      "source": "excel_rule",
      "name": "Count invalid records",
      "sql_query": "DELETE FROM table WHERE status='inactive'"  // ❌ DELETE not allowed
    }
  ]
}
```

**Log Output:**
```
05:35:49.104 │ [WARN] │ risk_agent.agents.planner │ planner.step_rejected │ 
             error="Only SELECT / WITH queries are permitted." index=0
05:35:49.104 │ [WARN] │ risk_agent.agents.planner │ planner.step_rejected │ 
             error="Only SELECT / WITH queries are permitted." index=1
05:35:49.105 │ [INFO] │ risk_agent.agents.planner │ planner.llm.done │ 
             category_id=R04_TMO accepted=0 rejected=2
```

**Result:** ❌ 0 steps accepted, 2 rejected, no retries

---

### AFTER (With Retry Mechanism)

**Initial LLM Response:** (Same as before)

**Planner's Feedback to LLM:**
```
# Previously Rejected Steps (PLEASE FIX)

Step 0:
  Name: Check missing billing_id
  Original SQL: UPDATE table SET field='value' WHERE id=1
  Error: Only SELECT / WITH queries are permitted.
  Source: semantic_kpi
  Rationale: Count records missing billing_id...

Step 1:
  Name: Count invalid records
  Original SQL: DELETE FROM table WHERE status='inactive'
  Error: Only SELECT / WITH queries are permitted.
  Source: excel_rule
  Rationale: Identify records with invalid...
```

**Retried LLM Response (Attempt 1):**
```json
{
  "steps": [
    {
      "source": "semantic_kpi",
      "name": "Check missing billing_id",
      "sql_query": "SELECT COUNT(*) FROM table WHERE billing_id IS NULL"  // ✅ Fixed
    },
    {
      "source": "excel_rule",
      "name": "Count invalid records",
      "sql_query": "SELECT * FROM table WHERE status='inactive'"  // ✅ Fixed
    }
  ]
}
```

**Log Output:**
```
05:35:49.104 │ [WARN] │ risk_agent.agents.planner │ planner.step_rejected │ 
             error="Only SELECT / WITH queries are permitted." index=0
05:35:49.104 │ [WARN] │ risk_agent.agents.planner │ planner.step_rejected │ 
             error="Only SELECT / WITH queries are permitted." index=1
05:35:49.105 │ [INFO] │ risk_agent.agents.planner │ planner.llm.done │ 
             category_id=R04_TMO accepted=0 rejected=2 duration_ms=39405.66

05:35:49.150 │ [INFO ] │ risk_agent.agents.planner │ planner.retry_attempt │ 
             attempt=1 max_retries=2 rejected_count=2
05:35:49.152 │ [INFO ] │ risk_agent.agents.planner │ planner.retry.start │ 
             rejected_count=2
05:36:15.200 │ [INFO ] │ risk_agent.agents.planner │ planner.retry.done │ 
             retry_accepted=2 retry_rejected=0 duration_ms=26048.00

05:36:15.205 │ [INFO ] │ risk_agent.agents.planner │ planner.planning.complete │ 
             category_id=R04_TMO total_accepted=2 total_rejected=0 retry_attempts=1
```

**Result:** ✅ 2 steps accepted after 1 retry, 0 rejected

---

## Key Features

### 1. **Feedback Loop**
The LLM receives the exact error reason for each rejected step:
- `"Only SELECT / WITH queries are permitted"`
- `"SQL contains forbidden keyword (DDL/DML not allowed)"`
- `"Multiple statements are not allowed"`
- `"Empty SQL query"`
- etc.

### 2. **Configurable Retries**
```python
# Default: 2 retries
steps, errors = await _plan_steps(category, semantic)

# Custom: Up to 5 retries
steps, errors = await _plan_steps(category, semantic, max_retries=5)
```

### 3. **Retry Prompts**
Two specialized prompts guide the LLM:
- `PLANNER_RETRY_SYSTEM_PROMPT`: Explains each type of error
- `PLANNER_RETRY_USER_PROMPT`: Shows rejected steps with specific reasons

### 4. **Smart Retry Logic**
- Retries only rejected steps (accepted ones are kept)
- Exits early if all steps pass
- Exits early if still getting errors (avoids infinite loops)
- Maximum of N retries (default: 2)

### 5. **Comprehensive Logging**
New log entries for monitoring:
```
planner.retry_attempt        # Marks start of retry
planner.retry.start          # LLM call start
planner.retry.done           # LLM call result
planner.retry.step_rejected  # Individual failures in retry
planner.planning.complete    # Final summary
```

## SQL Validation Rules (Enforced)

✅ **Allowed:**
- `SELECT * FROM table WHERE ...`
- `SELECT col1, col2 FROM table`
- `WITH cte AS (SELECT ...) SELECT ...`
- Aggregations: `SELECT COUNT(*), SUM(amount) FROM table GROUP BY status`

❌ **Blocked:**
- `INSERT INTO table VALUES (...)`
- `UPDATE table SET col = val`
- `DELETE FROM table WHERE ...`
- `DROP TABLE ...`
- `CREATE TABLE ...`
- `ALTER TABLE ...`
- `TRUNCATE TABLE ...`
- Multiple statements: `SELECT ...; SELECT ...;`

## Integration

No changes needed elsewhere - the retry mechanism is **transparent** to:
- The orchestrator
- The executor
- The generator
- Downstream processing

The planner simply returns more steps (due to retries) with the same interface.

## Configuration

Set retry count in `_plan_steps()` call:
```python
# In orchestrator.py or wherever plan_and_execute_node is called
# No changes needed - defaults to 2 retries
```

Or modify in [planner.py](src/risk_agent/agents/planner.py):
```python
async def _plan_steps(
    category: RiskCategory,
    semantic: SemanticResponse | None,
    max_retries: int = 2,  # ← Change this
) -> tuple[list[TraversalStep], list[str]]:
```
