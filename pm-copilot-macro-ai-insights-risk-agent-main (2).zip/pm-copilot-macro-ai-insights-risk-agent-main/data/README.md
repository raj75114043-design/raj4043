# Place risk_categories.xlsx here.
# Generate a sample with:
#   python scripts/generate_sample_catalog.py data/risk_categories.xlsx
