## Streamlit UI for Risk Agent

Interactive dashboard for the Risk Identification Agent.

### Setup

1. **Install Streamlit dependencies:**
   ```bash
   pip install -r requirements-streamlit.txt
   ```

2. **Ensure the Risk Agent API is running:**
   ```bash
   # Terminal 1: Start the API server
   uvicorn src.risk_agent.api:app --host 0.0.0.0 --port 8000 --reload
   ```

3. **Run the Streamlit app:**
   ```bash
   # Terminal 2: Start the Streamlit UI
   streamlit run app.py
   ```

   The app will open at: `http://localhost:8501`

### Features

#### 🎯 Category Selection
- Browse all available risk categories from the Excel catalog
- View category description and owner
- Select a category to analyze

#### ▶️ Risk Analysis
- Run the full risk identification pipeline
- Real-time progress tracking
- Results displayed immediately

#### 📊 Results Dashboard

**Card View:**
- Each finding displayed as a collapsible card
- Color-coded by risk rating (Critical, High, Medium, Low)
- Quick view of:
  - Risk description
  - Severity level
  - Confidence score
  - Likelihood × Impact assessment
  - Root cause
  - Mitigation actions
  - Recovery plan
  - Supporting evidence & drill-down tables

**Risk Matrix View:**
- Visualize findings by Likelihood × Impact combination
- Summary statistics (Critical, High, Medium/Low counts)
- Distribution across risk categories

**Raw Data View:**
- Full JSON response from the API
- For technical review and debugging

### Environment Variables

```bash
# Optional: specify a different API endpoint
export API_BASE_URL="http://your-api-host:8000"
```

If not set, defaults to `http://localhost:8000`

### Domain Terminology (Telecom Towers)

The UI displays findings using telecom deployment domain terms:
- **GC** = General Contractor
- **NTP** = Notice to Proceed
- **PO** = Purchase Order
- **RFI** = Ready for Installation
- **FTR** = First Time Right
- **Cycle time** = Days from NTP to on-air
- **Run rate** = Daily/weekly site delivery output
- **Crew** = Field installation team under a GC

### Customization

The Streamlit app can be customized by editing `app.py`:
- **Colors**: Modify CSS in the `st.markdown()` section
- **Layout**: Adjust columns and expanders
- **API calls**: Change endpoints or add new ones
- **Data display**: Add new visualization types

### Troubleshooting

**Issue: "Failed to fetch categories"**
- Ensure the API server is running on the configured URL
- Check the `API_BASE_URL` environment variable

**Issue: "Analysis timed out"**
- Increase the timeout in the `requests.post()` call (currently 120 seconds)
- Check API logs for performance issues

**Issue: Streamlit not updating**
- Clear cache: `streamlit run app.py --logger.level=debug`
- Hard refresh in browser: `Ctrl+Shift+R` or `Cmd+Shift+R`

### Development

To add new features:
1. Add UI components using Streamlit API (`st.write()`, `st.metric()`, etc.)
2. Call API endpoints as needed via `requests`
3. Reload automatically on save (Streamlit watches for changes)
