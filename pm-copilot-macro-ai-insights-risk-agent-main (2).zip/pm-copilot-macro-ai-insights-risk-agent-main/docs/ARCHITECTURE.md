# Architecture

## Data flow (one risk category)

1. **Input.** A `RiskCategory` is loaded from the Excel catalog. It carries
   a natural-language description, an NL identification logic, and a list of
   decision rules.
2. **Semantic retrieval.** The category name + description are sent to the
   existing Semantic Context API, which returns the top-K relevant KPI /
   RCA entries, each with `steps_to_get_data_sql` (NL steps) and
   `relevant_kpis`. Hits below `SEMANTIC_MIN_SCORE` are dropped.
3. **Planning.** The Planner prompts Azure OpenAI with the category, the
   semantic hits, the decision rules, and the live Postgres schema. The LLM
   emits a list of **independent** `TraversalStep`s tagged as either
   `SEMANTIC_KPI` or `EXCEL_RULE`. Every emitted SQL is validated by
   `validate_sql` — any step with unsafe SQL is dropped with a logged
   warning.
4. **Parallel execution.** The graph fans out via LangGraph's `Send` —
   one `execute_step_node` instance per step. Each step:
   - opens a read-only Postgres connection,
   - sets a statement-level timeout,
   - runs the query wrapped in `LIMIT max_rows_per_step`,
   - returns a typed `StepResult` carrying rows, timing, status, error.
   The `step_results` key in `AgentState` uses `operator.add` so the
   concurrent appends from parallel branches merge deterministically.
5. **Risk synthesis.** The Risk Identification Agent prompts Azure OpenAI with the
   category + all step results (truncated sample rows + metadata). The LLM
   returns zero or more findings, each with `evidence_step_ids` pointing
   back to specific steps. We resolve those IDs against the actual
   `StepResult`s; any finding without matching evidence is discarded.
6. **Report.** The orchestrator assembles a `RiskReport` with timing,
   counts, and findings.

## State schema

`AgentState` is a `TypedDict` with these keys (all optional except
`category`):

| Key                  | Type                        | Reducer      |
|----------------------|-----------------------------|--------------|
| `category`           | `RiskCategory`              | replace      |
| `semantic_response`  | `SemanticResponse | None`   | replace      |
| `planned_steps`      | `list[TraversalStep]`       | replace      |
| `step_results`       | `list[StepResult]`          | `operator.add` |
| `findings`           | `list[RiskFinding]`         | replace      |
| `summary`            | `str | None`                | replace      |
| `errors`             | `list[str]`                 | `operator.add` |
| `started_at_iso`     | `str`                       | replace      |

The `operator.add` reducer is required on any key written from multiple
parallel branches — otherwise LangGraph raises a `InvalidUpdateError`.

## Prompt strategy

Both prompts use a system message that sets the role + output format, and a
user message that injects structured context:

- **Planner** — receives the category, the rendered semantic hits, the
  decision rules, and the rendered schema. Instructs the LLM to output
  strict JSON with `source`, `name`, `rationale`, `sql_query`,
  `expected_columns`, `related_kpi`, `source_reference`.
- **Generator** — receives the category, the decision rules, and a text
  render of each step result (status, row count, sample rows up to 25).
  Instructs the LLM to output strict JSON with `summary` and `findings`,
  each finding carrying `evidence_step_ids`.

Temperature defaults to `0.1` for both. JSON parsing strips Markdown fences
and locates the first/last braces before `json.loads`.

## Failure modes and mitigations

| Failure                            | Mitigation                                                 |
|------------------------------------|------------------------------------------------------------|
| Semantic API down                  | `tenacity` retry + structured error; category fails fast   |
| Semantic API returns garbage       | Pydantic validation raises `SemanticAPIError`              |
| Planner LLM returns malformed JSON | `parse_llm_json` raises `LLMError`                         |
| Planner emits unsafe SQL           | Step rejected with `UnsafeSQLError`, logged, others proceed|
| Planner emits bad column references| Executor's DB error is caught → `StepResult(status=FAILED)`|
| Postgres slow                      | Per-step `STEP_EXECUTION_TIMEOUT` + `statement_timeout`    |
| Runaway result set                 | `enforce_row_limit` wraps query in outer LIMIT             |
| One step crashes                   | Other steps continue; generator sees partial evidence      |
| Generator hallucinates findings    | Findings without resolvable `evidence_step_ids` dropped    |

## Extensibility

- **Add a new evidence source.** Add a new `StepSource` enum value, a new
  planner prompt section that emits steps tagged with it, and (optionally)
  a dedicated executor node if the execution model differs from SQL.
- **Switch LLM provider.** Replace `build_llm` in `core/llm.py`. All agents
  go through that factory.
- **Persist reports.** Add a post-generator node that writes `RiskReport`
  to a store (S3, Postgres, Kafka). The graph's final edge already points
  from the generator to `END` — insert your node there.
