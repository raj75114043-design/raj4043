# Deployment Guide

## Prerequisites

- Python 3.11+ (for local dev)
- Docker 24+ and docker compose v2 (for container builds)
- kubectl 1.28+ and a target cluster (for k8s deploys)
- Access to: Azure OpenAI, the Semantic Context API, a Postgres instance

## Environments

The `APP_ENV` variable controls environment-specific behaviour:
`development`, `staging`, `production`. It only affects logging defaults
today — keep your own branch of config for environment-specific overrides.

## Building the image

```bash
make docker-build                          # risk-agent:1.0.0
docker tag risk-agent:1.0.0 <registry>/risk-agent:1.0.0
docker push <registry>/risk-agent:1.0.0
```

The image is a two-stage build:
- **Builder stage** installs build toolchain, compiles wheels.
- **Runtime stage** copies only the wheels, runs as UID 1001, uses `tini` as
  PID 1, exposes `/health` for Docker healthcheck.

## Running locally with docker-compose

```bash
cp .env.example .env
# fill in AZURE_OPENAI_*, SEMANTIC_API_URL/KEY
make docker-up
./scripts/smoke_test.sh
```

Postgres is bundled in compose for development only. In production, point
`POSTGRES_*` at your managed Postgres (RDS, Azure Database, Cloud SQL…).

## Kubernetes deployment

### 1. Create the namespace and config

```bash
kubectl apply -f deploy/k8s/00-namespace.yaml
kubectl apply -f deploy/k8s/10-configmap.yaml
```

Edit `10-configmap.yaml` first to set cluster-specific values (Postgres
host, Semantic API URL, etc.).

### 2. Create the secret (do not commit real values)

Either use the template in `20-secret.yaml` as a dev-only placeholder, or —
strongly preferred — integrate with your secret manager:

- **Azure Key Vault + CSI driver** — recommended when hosted on AKS.
- **External Secrets Operator** — provider-agnostic.
- **Sealed Secrets** — if you want GitOps.

Minimum keys required:

```
AZURE_OPENAI_API_KEY
AZURE_OPENAI_ENDPOINT
POSTGRES_PASSWORD
SEMANTIC_API_KEY
SEMANTIC_API_URL
```

### 3. Mount the risk catalog

The catalog is an Excel file. Options:

- **ConfigMap (small/static)**: `kubectl -n risk-agent create configmap
  risk-catalog --from-file=risk_categories.xlsx=./data/risk_categories.xlsx`
- **PVC (large/changing)**: swap the `configMap` volume for a
  `persistentVolumeClaim` in `30-deployment.yaml`.
- **S3/blob + init container**: pull on pod startup.

### 4. Apply the rest

```bash
kubectl apply -f deploy/k8s/
kubectl -n risk-agent rollout status deploy/risk-agent
```

### 5. Smoke test

```bash
kubectl -n risk-agent port-forward svc/risk-agent 8080:80 &
./scripts/smoke_test.sh http://localhost:8080
```

## Scaling guidance

- **Replicas** — HPA scales from 2 to 8 based on CPU (70%) and memory
  (75%). Adjust `maxReplicas` in `50-hpa-pdb.yaml`.
- **Parallelism per request** — controlled by `MAX_PARALLEL_STEPS` (default
  10). Each step opens a Postgres connection; size `POSTGRES_POOL_MAX_SIZE`
  to at least `MAX_PARALLEL_STEPS`.
- **LLM throughput** — Azure OpenAI TPM/RPM quotas are usually the
  bottleneck. Upgrade your deployment quota before adding replicas.
- **DB load** — steps are read-only but can be heavy. Consider routing to
  a read replica in production.

## Rollback

```bash
kubectl -n risk-agent rollout history deploy/risk-agent
kubectl -n risk-agent rollout undo deploy/risk-agent
```

## Observability hooks

- **Logs** — stdout, JSON-structured. Scrape with Fluent Bit / Loki /
  whatever your cluster uses.
- **Metrics** — `/metrics` on port 8000. A `ServiceMonitor` is shipped;
  ensure the `release: kube-prometheus-stack` label matches your Prometheus
  operator install, or adjust.
- **Traces** — not included; add OpenTelemetry middleware to `api.py` if
  needed.

## Production checklist

- [ ] Azure OpenAI quota sized for peak throughput
- [ ] Postgres connection pool tuned (`POSTGRES_POOL_MAX_SIZE` ≥ `MAX_PARALLEL_STEPS` × replicas)
- [ ] Secrets managed via Key Vault / ESO (not committed)
- [ ] Risk catalog mounted read-only
- [ ] NetworkPolicy verified against your egress requirements
- [ ] Image scanned (`docker scout` / Trivy) before promoting
- [ ] Backup / retention policy for reports (if persisted)
- [ ] Alerting on `risk_agent_categories_processed_total{status="failed"}`
- [ ] Alerting on `risk_agent_llm_calls_total{status="failed"}`
