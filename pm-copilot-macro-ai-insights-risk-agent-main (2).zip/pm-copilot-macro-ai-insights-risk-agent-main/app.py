"""Streamlit UI for the Risk Identification Agent.

Run with: streamlit run app.py
"""

import os
import json
from datetime import datetime
from typing import Any

import requests
import streamlit as st
from streamlit_extras.stylable_container import stylable_container

# Configuration
API_BASE_URL = os.getenv("API_BASE_URL", "http://localhost:8000")
# Per-request read timeout (seconds). The pipeline runs semantic retrieval +
# planner + validator + risk-identification LLM calls back-to-back, so a
# single category can legitimately take several minutes. Override with
# API_RUN_TIMEOUT_SECONDS env var if needed.
API_RUN_TIMEOUT_SECONDS = int(os.getenv("API_RUN_TIMEOUT_SECONDS", "600"))

# Page config
st.set_page_config(
    page_title="Risk Agent Dashboard",
    page_icon="⚠️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS for cards
st.markdown("""
<style>
    .risk-card {
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 15px;
        border-left: 4px solid;
    }
    .risk-card.critical {
        background-color: #fff5f5;
        border-left-color: #e53e3e;
    }
    .risk-card.high {
        background-color: #fffaf0;
        border-left-color: #ed8936;
    }
    .risk-card.medium {
        background-color: #fffff0;
        border-left-color: #ecc94b;
    }
    .risk-card.low {
        background-color: #f0fff4;
        border-left-color: #38a169;
    }
    .risk-title {
        font-size: 18px;
        font-weight: bold;
        margin-bottom: 8px;
    }
    .risk-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 12px;
        font-weight: bold;
        margin-right: 8px;
        margin-bottom: 8px;
    }
    .badge-critical { background-color: #e53e3e; color: white; }
    .badge-high { background-color: #ed8936; color: white; }
    .badge-medium { background-color: #ecc94b; color: black; }
    .badge-low { background-color: #38a169; color: white; }
    .badge-likelihood { background-color: #667eea; color: white; }
    .badge-impact { background-color: #f56565; color: white; }
    .details-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 14px;
    }
    .details-table th, .details-table td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #e2e8f0;
    }
    .details-table th {
        background-color: #f7fafc;
        font-weight: bold;
    }
</style>
""", unsafe_allow_html=True)

# ============================================================================
# Header & Layout
# ============================================================================

st.title("⚠️ Telecom Tower Deployment Risk Agent")

# Sidebar
with st.sidebar:
    st.header("Configuration")
    api_url = st.text_input(
        "API Base URL",
        value=API_BASE_URL,
        help="Base URL for the Risk Agent API"
    )
    st.divider()
    mode = st.radio(
        "Pipeline",
        options=["Risk Analysis (Excel)", "KPI Trend Analysis", "Saved Findings", "Risk Chatbot"],
        index=0,
    )
    st.divider()
    st.info(
        "**Domain Terms:**\n"
        "- GC = General Contractor\n"
        "- NTP = Notice to Proceed\n"
        "- PO = Purchase Order\n"
        "- RFI = Ready for Installation\n"
        "- FTR = First Time Right\n"
        "- Cycle time = NTP to on-air"
    )


# ============================================================================
# Shared finding renderer (used by both modes)
# ============================================================================

def render_findings(findings: list[dict[str, Any]], report: dict[str, Any]) -> None:
    """Render findings with card view, risk matrix, and raw JSON tabs."""
    if not findings:
        st.info("No risks detected.")
        return

    st.subheader(f"Risk Findings ({len(findings)})")
    view_tab, matrix_tab, details_tab = st.tabs(["Card View", "Risk Matrix", "Raw Data"])

    with view_tab:
        for idx, finding in enumerate(findings):
            risk_rating = finding.get("risk_rating", "medium").lower()
            likelihood = finding.get("likelihood", "may_happen").lower()
            impact = finding.get("impact", "medium").lower()
            with st.expander(
                f"📌 {finding.get('risk', 'Unnamed Risk')} [{risk_rating.upper()}]",
                expanded=(idx == 0),
            ):
                col1, col2, col3 = st.columns([2, 1, 1])
                with col1:
                    st.markdown(f"**{finding.get('description', 'N/A')}**")
                    st.markdown(finding.get("impact_summary", ""))
                with col2:
                    st.markdown("**Severity**")
                    severity = finding.get("severity", "informational").upper()
                    severity_color = {"CRITICAL": "🔴", "HIGH": "🟠", "MEDIUM": "🟡", "LOW": "🟢", "INFORMATIONAL": "⚪"}
                    st.write(f"{severity_color.get(severity, '⚪')} {severity}")
                with col3:
                    st.markdown("**Confidence**")
                    confidence = finding.get("confidence", 0.5)
                    st.progress(confidence)
                    st.caption(f"{confidence*100:.0f}%")

                st.divider()
                st.markdown("**Risk Assessment Matrix**")
                mc1, mc2, mc3 = st.columns(3)
                with mc1:
                    st.metric("Likelihood", likelihood.replace("_", " ").title())
                with mc2:
                    st.metric("Impact", impact.title())
                with mc3:
                    st.metric("Risk Rating", risk_rating.replace("_", " ").title())
                st.divider()
                st.markdown("**Root Cause**")
                st.write(finding.get("root_cause", "N/A"))
                st.markdown("**Mitigation Actions**")
                for action in finding.get("mitigation_actions", []):
                    st.write(f"• {action}")
                st.markdown("**Recovery Plan**")
                for step in finding.get("recovery_plan", []):
                    st.write(f"• {step}")
                evidence = finding.get("evidence", [])
                if evidence:
                    st.markdown("**Evidence**")
                    for ev in evidence:
                        st.write(f"**Step:** {ev.get('step_name', 'N/A')}")
                        st.caption(f"Source: {ev.get('source', 'N/A')} | Rows: {ev.get('row_count', 0)}")
                        if ev.get("sample_rows"):
                            st.dataframe(ev["sample_rows"], use_container_width=True)
                drill_tables = finding.get("drill_down_tables", [])
                if drill_tables:
                    st.markdown("**Drill-Down Data**")
                    for table in drill_tables:
                        st.write(f"**{table.get('title', 'Table')}**")
                        if "rows" in table and "columns" in table:
                            df_data = [dict(zip(table["columns"], row)) for row in table["rows"]]
                            st.dataframe(df_data, use_container_width=True)

    with matrix_tab:
        st.markdown("### Risk Distribution")
        matrix_data: dict[str, Any] = {}
        for finding in findings:
            lk = finding.get("likelihood", "may_happen").upper()
            im = finding.get("impact", "medium").upper()
            rt = finding.get("risk_rating", "medium").upper()
            key = f"{lk} × {im}"
            if key not in matrix_data:
                matrix_data[key] = {"rating": rt, "count": 0}
            matrix_data[key]["count"] += 1
        if matrix_data:
            cols = st.columns(min(len(matrix_data), 3))
            for (key, data), col in zip(matrix_data.items(), cols):
                with col:
                    st.metric(key, f"{data['rating']} ({data['count']})")
        st.markdown("### Summary Statistics")
        sc1, sc2, sc3 = st.columns(3)
        with sc1:
            st.metric("🔴 Critical", sum(1 for f in findings if f.get("risk_rating") == "critical"))
        with sc2:
            st.metric("🟠 High", sum(1 for f in findings if f.get("risk_rating") == "high"))
        with sc3:
            st.metric("🟡 Medium/Low", sum(1 for f in findings if f.get("risk_rating") in ("medium", "low")))

    with details_tab:
        st.markdown("### Raw JSON Response")
        st.json(report)


# ============================================================================
# Mode: KPI Trend Analysis
# ============================================================================

if mode == "KPI Trend Analysis":
    st.markdown(
        "Automatically analyzes **all KPIs** across all regions, "
        "drilling down Region → Area → Market → Site for anomalous trends."
    )

    col1, col2 = st.columns([3, 1])
    with col2:
        kpi_run_btn = st.button("▶️ Run KPI Analysis", use_container_width=True, type="primary")

    if kpi_run_btn:
        with st.spinner("Running KPI trend analysis (Region → Area → Market → Site)…"):
            try:
                resp = requests.post(f"{api_url}/kpi-analysis", timeout=API_RUN_TIMEOUT_SECONDS)
                resp.raise_for_status()
                st.session_state.kpi_report = resp.json()
            except Exception as e:
                st.error(f"KPI analysis failed: {e}")

    if "kpi_report" in st.session_state:
        kpi_report = st.session_state.kpi_report
        st.divider()
        st.subheader("KPI Analysis Results")

        km1, km2, km3, km4 = st.columns(4)
        with km1:
            st.metric("Findings", len(kpi_report.get("findings", [])))
        with km2:
            st.metric("Steps Run", kpi_report.get("steps_planned", 0))
        with km3:
            st.metric("Succeeded", kpi_report.get("steps_succeeded", 0))
        with km4:
            st.metric("Sites Examined", kpi_report.get("total_rows_examined", 0))

        if kpi_report.get("summary"):
            st.info(kpi_report["summary"])

        st.divider()
        render_findings(kpi_report.get("findings", []), kpi_report)

    st.stop()


# ============================================================================
# Mode: Saved Findings — browse past reports and individual findings from DB
# ============================================================================

_PIPELINE_LABEL = {"excel": "Excel", "kpi_trend": "KPI Trend"}
_PIPELINE_BADGE_COLOR = {"excel": "#667eea", "kpi_trend": "#38a169"}
_SEVERITY_EMOJI = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🟢", "informational": "⚪"}
_PIPELINE_PARAM = {
    "All": None,
    "Excel (Risk Analysis)": "excel",
    "KPI Trend Analysis": "kpi_trend",
}


def _pipeline_badge(pipeline_type: str) -> str:
    label = _PIPELINE_LABEL.get(pipeline_type, pipeline_type.title())
    color = _PIPELINE_BADGE_COLOR.get(pipeline_type, "#718096")
    return (
        f"<span style='background:{color};color:white;padding:2px 8px;"
        f"border-radius:12px;font-size:11px;font-weight:bold'>{label}</span>"
    )


if mode == "Saved Findings":
    st.markdown("Browse previously saved risk reports and individual findings stored in the database.")

    rep_tab, fn_tab = st.tabs(["📋 Past Reports", "🔍 Browse Findings"])

    # -------------------------------------------------------------------------
    # Tab 1: Past Reports
    # -------------------------------------------------------------------------
    with rep_tab:
        fc1, fc2, fc3 = st.columns([2, 1, 1])
        with fc1:
            rpt_pipeline = st.selectbox(
                "Pipeline Type",
                list(_PIPELINE_PARAM.keys()),
                key="rpt_pipeline_filter",
            )
        with fc2:
            rpt_limit = st.slider("Reports to show", 5, 50, 10, key="rpt_limit")
        with fc3:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("🔄 Refresh", key="rpt_refresh"):
                st.session_state.pop("selected_report", None)
                st.session_state.pop("selected_report_id", None)

        rpt_params: dict = {"limit": rpt_limit, "offset": 0}
        pt = _PIPELINE_PARAM[rpt_pipeline]
        if pt:
            rpt_params["pipeline_type"] = pt

        try:
            rpt_resp = requests.get(f"{api_url}/reports", params=rpt_params, timeout=15)
            rpt_resp.raise_for_status()
            rpt_data = rpt_resp.json()
        except Exception as e:
            st.error(f"Failed to fetch reports: {e}")
            rpt_data = {"reports": [], "total": 0}

        reports_list = rpt_data.get("reports", [])
        total_rpts = rpt_data.get("total", 0)

        if not reports_list:
            st.info("No saved reports found. Run a Risk Analysis or KPI Analysis first.")
        else:
            st.caption(f"Showing {len(reports_list)} of {total_rpts} report(s)")

            for rpt in reports_list:
                report_id = rpt.get("report_id", "")
                cat = rpt.get("category") or {}
                cat_name = cat.get("name") or cat.get("category_id") or "Unknown"
                pipeline_type = rpt.get("pipeline_type", "unknown")
                created_at = rpt.get("created_at") or rpt.get("started_at") or ""
                duration_ms = rpt.get("duration_ms")
                steps_ok = rpt.get("steps_succeeded", 0)
                rows_examined = rpt.get("total_rows_examined", 0)
                is_selected = st.session_state.get("selected_report_id") == report_id

                label = f"{'✅ ' if is_selected else ''}📄 {cat_name}  ·  {created_at[:16] if created_at else 'N/A'}"
                with st.expander(label, expanded=is_selected):
                    ic1, ic2, ic3, ic4, ic5 = st.columns([3, 1, 1, 1, 1])
                    with ic1:
                        st.markdown(_pipeline_badge(pipeline_type), unsafe_allow_html=True)
                        st.caption(f"`{report_id[:24]}…`")
                    with ic2:
                        st.metric("Steps OK", steps_ok)
                    with ic3:
                        st.metric("Rows", rows_examined)
                    with ic4:
                        dur_str = f"{duration_ms / 1000:.1f}s" if duration_ms else "—"
                        st.metric("Duration", dur_str)
                    with ic5:
                        st.markdown("<br>", unsafe_allow_html=True)
                        load_btn = st.button(
                            "Load →" if not is_selected else "Reload →",
                            key=f"load_{report_id}",
                            type="primary",
                            use_container_width=True,
                        )

                    if load_btn:
                        with st.spinner("Loading full report…"):
                            try:
                                full_resp = requests.get(
                                    f"{api_url}/reports/{report_id}", timeout=30
                                )
                                full_resp.raise_for_status()
                                st.session_state.selected_report = full_resp.json()
                                st.session_state.selected_report_id = report_id
                                st.rerun()
                            except Exception as e:
                                st.error(f"Failed to load report: {e}")

        # Render the loaded report below the list
        if "selected_report" in st.session_state:
            sel = st.session_state.selected_report
            sel_cat = sel.get("category") or {}
            sel_name = sel_cat.get("name") or sel_cat.get("category_id") or "Report"
            pipeline_type = sel.get("pipeline_type", "")

            st.divider()
            hc1, hc2 = st.columns([5, 1])
            with hc1:
                st.subheader(f"📊 {sel_name}")
                st.markdown(_pipeline_badge(pipeline_type), unsafe_allow_html=True)
            with hc2:
                if st.button("✖ Clear", key="clear_selected_report"):
                    st.session_state.pop("selected_report", None)
                    st.session_state.pop("selected_report_id", None)
                    st.rerun()

            mc1, mc2, mc3, mc4 = st.columns(4)
            with mc1:
                st.metric("Findings", len(sel.get("findings", [])))
            with mc2:
                st.metric("Steps Planned", sel.get("steps_planned", 0))
            with mc3:
                st.metric("Succeeded", sel.get("steps_succeeded", 0))
            with mc4:
                dur = sel.get("duration_ms")
                st.metric("Duration", f"{dur / 1000:.1f}s" if dur else "—")

            if sel.get("summary"):
                st.info(sel["summary"])

            st.divider()
            render_findings(sel.get("findings", []), sel)

    # -------------------------------------------------------------------------
    # Tab 2: Browse Individual Findings
    # -------------------------------------------------------------------------
    with fn_tab:
        bf1, bf2, bf3, bf4 = st.columns([2, 2, 1, 1])
        with bf1:
            fn_pipeline = st.selectbox(
                "Pipeline Type",
                list(_PIPELINE_PARAM.keys()),
                key="fn_pipeline_filter",
            )
        with bf2:
            fn_severity = st.selectbox(
                "Risk Rating",
                ["All", "Critical", "High", "Medium", "Low"],
                key="fn_severity_filter",
            )
        with bf3:
            fn_limit = st.slider("Limit", 5, 100, 20, key="fn_limit")
        with bf4:
            st.markdown("<br>", unsafe_allow_html=True)
            st.button("🔄 Refresh", key="fn_refresh")

        fn_params: dict = {"limit": fn_limit, "offset": 0}
        fn_pt = _PIPELINE_PARAM[fn_pipeline]
        if fn_pt:
            fn_params["pipeline_type"] = fn_pt
        if fn_severity != "All":
            fn_params["risk_rating"] = fn_severity.lower()

        try:
            fn_resp = requests.get(f"{api_url}/risks", params=fn_params, timeout=15)
            fn_resp.raise_for_status()
            fn_data = fn_resp.json()
        except Exception as e:
            st.error(f"Failed to fetch findings: {e}")
            fn_data = {"findings": [], "total": 0}

        fn_list = fn_data.get("findings", [])
        fn_total = fn_data.get("total", 0)

        if not fn_list:
            st.info("No findings found. Adjust the filters or run an analysis first.")
        else:
            st.caption(f"Showing {len(fn_list)} of {fn_total} finding(s)")

            # Summary severity bar
            sev_counts = {}
            for f in fn_list:
                s = f.get("risk_rating") or f.get("severity") or "unknown"
                sev_counts[s] = sev_counts.get(s, 0) + 1

            sbc1, sbc2, sbc3, sbc4 = st.columns(4)
            for col, key in zip([sbc1, sbc2, sbc3, sbc4], ["critical", "high", "medium", "low"]):
                with col:
                    emoji = _SEVERITY_EMOJI.get(key, "")
                    st.metric(f"{emoji} {key.title()}", sev_counts.get(key, 0))

            st.divider()
            render_findings(fn_list, fn_data)

    st.stop()


# ============================================================================
# Mode: Risk Chatbot — pick a risk finding then ask follow-up questions
# ============================================================================

if mode == "Risk Chatbot":
    st.markdown(
        "Pick a saved risk finding and ask follow-up questions. "
        "The assistant answers using only the selected finding's details "
        "(risk, root cause, mitigations, recovery plan, evidence, drill-down data)."
    )

    # ----- Step 1: filters to narrow the finding list ------------------------
    cf1, cf2, cf3 = st.columns([2, 1, 1])
    with cf1:
        chat_severity = st.selectbox(
            "Risk Rating",
            ["All", "Critical", "High", "Medium", "Low"],
            key="chat_severity_filter",
        )
    with cf2:
        chat_limit = st.slider("Limit", 5, 100, 25, key="chat_limit")
    with cf3:
        st.markdown("<br>", unsafe_allow_html=True)
        chat_refresh = st.button("🔄 Refresh", key="chat_refresh", use_container_width=True)

    chat_params: dict = {"limit": chat_limit, "offset": 0}
    if chat_severity != "All":
        chat_params["risk_rating"] = chat_severity.lower()

    try:
        chat_resp = requests.get(f"{api_url}/risks", params=chat_params, timeout=15)
        chat_resp.raise_for_status()
        chat_data = chat_resp.json()
    except Exception as e:
        st.error(f"Failed to fetch findings: {e}")
        chat_data = {"findings": [], "total": 0}

    chat_findings = chat_data.get("findings", [])

    if not chat_findings:
        st.info("No findings match these filters. Run a Risk Analysis or KPI Analysis first, or relax the filters.")
        st.stop()

    # ----- Step 2: pick a specific risk -------------------------------------
    def _label(f: dict) -> str:
        rating = (f.get("risk_rating") or f.get("severity") or "n/a").upper()
        emoji = _SEVERITY_EMOJI.get((f.get("risk_rating") or f.get("severity") or "").lower(), "")
        risk = f.get("risk") or "(untitled risk)"
        cat = f.get("category_id") or "?"
        return f"{emoji} [{rating}] {cat} — {risk}"

    finding_map = {f["finding_id"]: f for f in chat_findings if f.get("finding_id")}
    selected_finding_id = st.selectbox(
        "Select Risk Finding",
        options=list(finding_map.keys()),
        format_func=lambda fid: _label(finding_map[fid]),
        key="chat_selected_finding",
    )

    # Reset chat history when the user switches risks
    if st.session_state.get("chat_active_finding") != selected_finding_id:
        st.session_state.chat_active_finding = selected_finding_id
        st.session_state.chat_history = []

    st.divider()

    # ----- Step 3: Chat interface -------------------------------------------
    st.subheader("💬 Ask about this risk")

    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []

    # Suggested starter questions
    suggestions = [
        "Summarize this risk in 3 bullet points.",
        "What are the top mitigation actions and who should own them?",
        "What is the recovery plan if this risk materializes?",
        "Which evidence rows most strongly support this finding?",
    ]
    sug_cols = st.columns(len(suggestions))
    queued_question: str | None = None
    for i, (col, q) in enumerate(zip(sug_cols, suggestions)):
        with col:
            if st.button(q, key=f"chat_sug_{i}", use_container_width=True):
                queued_question = q

    # Render existing chat history
    for msg in st.session_state.chat_history:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    user_input = st.chat_input("Ask a question about this risk…")
    user_question = queued_question or user_input

    if user_question:
        st.session_state.chat_history.append({"role": "user", "content": user_question})
        with st.chat_message("user"):
            st.markdown(user_question)

        with st.chat_message("assistant"):
            with st.spinner("Thinking…"):
                try:
                    payload = {
                        "finding_id": selected_finding_id,
                        "question": user_question,
                        # Pass prior turns (excluding the just-appended user msg)
                        "history": st.session_state.chat_history[:-1],
                    }
                    chat_api_resp = requests.post(
                        f"{api_url}/chat",
                        json=payload,
                        timeout=API_RUN_TIMEOUT_SECONDS,
                    )
                    chat_api_resp.raise_for_status()
                    answer = chat_api_resp.json().get("answer", "(no answer returned)")
                except Exception as e:
                    answer = f"⚠️ Chat request failed: {e}"
                st.markdown(answer)
                st.session_state.chat_history.append({"role": "assistant", "content": answer})

    cc1, cc2 = st.columns([1, 5])
    with cc1:
        if st.button("🗑️ Clear chat", key="chat_clear"):
            st.session_state.chat_history = []
            st.rerun()

    st.stop()


# ============================================================================
# Mode: Risk Analysis (Excel) — original UI below
# ============================================================================

col1, col2 = st.columns([3, 1])

with col1:
    st.subheader("Select Risk Category")

with col2:
    refresh_btn = st.button("🔄 Refresh Categories", use_container_width=True)

# Fetch categories
@st.cache_data(ttl=300)
def fetch_categories():
    try:
        response = requests.get(f"{api_url}/categories", timeout=10)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        st.error(f"Failed to fetch categories: {e}")
        return []

if refresh_btn:
    st.cache_data.clear()

categories = fetch_categories()

if not categories:
    st.warning("No risk categories available. Please check the API connection.")
    st.stop()

# Create dropdown
category_options = {cat["category_id"]: f"{cat['category_id']} - {cat['name']}" for cat in categories}
selected_category = st.selectbox(
    "Category",
    options=list(category_options.keys()),
    format_func=lambda x: category_options[x],
)

# Get selected category details
selected_cat_obj = next((c for c in categories if c["category_id"] == selected_category), None)

if selected_cat_obj:
    st.markdown(f"**Description:** {selected_cat_obj.get('description', 'N/A')}")
    st.markdown(f"**Owner:** {selected_cat_obj.get('owner', 'N/A')}")

st.divider()

# Run button
if st.button("▶️ Run Risk Analysis", use_container_width=True, type="primary"):
    with st.spinner(f"Analyzing risks for {selected_category}..."):
        try:
            response = requests.post(
                f"{api_url}/run",
                json={"category_id": selected_category},
                timeout=API_RUN_TIMEOUT_SECONDS,
            )
            response.raise_for_status()
            report = response.json()
            st.session_state.current_report = report
        except Exception as e:
            st.error(f"Error running analysis: {e}")
            st.stop()

# Display results if available
if "current_report" in st.session_state:
    report = st.session_state.current_report
    
    st.divider()
    st.subheader("📊 Analysis Results")
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Findings", len(report.get("findings", [])))
    with col2:
        st.metric("Steps Planned", report.get("steps_planned", 0))
    with col3:
        st.metric("Steps Succeeded", report.get("steps_succeeded", 0))
    with col4:
        st.metric("Rows Examined", report.get("total_rows_examined", 0))
    
    # Category info
    st.markdown(f"**Category:** {report.get('category', {}).get('category_id', 'N/A')}")
    st.markdown(f"**Analysis Time:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    st.divider()
    
    # Findings — use shared renderer
    st.divider()
    render_findings(report.get("findings", []), report)

st.divider()
st.caption("Risk Agent v1.0.0 | Telecom Tower Deployment")
