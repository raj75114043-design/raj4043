# Retry Mechanism - Implementation Details

## Files Modified

### 1. `src/risk_agent/prompts/planner.py`
Added two new prompt templates:

#### `PLANNER_RETRY_SYSTEM_PROMPT`
System message that explains:
- What rejection means
- Common error types
- How to fix each type of error
- Retry handling instructions

#### `PLANNER_RETRY_USER_PROMPT`
User message that includes:
- Target table schema (for reference)
- List of rejected steps with:
  - Step name
  - Original SQL query
  - Specific error reason
  - Source type (semantic_kpi or excel_rule)
  - Rationale

### 2. `src/risk_agent/agents/planner.py`
Added retry logic:

#### New Function: `_format_rejected_steps_for_retry()`
```python
def _format_rejected_steps_for_retry(
    rejected_steps: list[dict[str, Any]],
    rejection_reasons: list[str],
) -> str:
    """Format rejected steps with their error reasons for the retry prompt."""
```
**Purpose:** Creates a human-readable list of rejected steps with error reasons

**Returns:** Formatted string like:
```
Step 0:
  Name: Check missing billing_id
  Original SQL: UPDATE table SET field='value' WHERE id=1
  Error: Only SELECT / WITH queries are permitted.
  Source: semantic_kpi
  Rationale: Count records missing billing_id...

Step 1:
  Name: Count invalid records
  ...
```

---

#### New Function: `_retry_rejected_steps()`
```python
async def _retry_rejected_steps(
    rejected_steps: list[dict[str, Any]],
    rejection_reasons: list[str],
    schema_info: tuple[Any, str],
) -> tuple[list[TraversalStep], list[str]]:
    """Retry planning for rejected steps with feedback about what went wrong."""
```

**Parameters:**
- `rejected_steps`: Raw step dicts that failed validation
- `rejection_reasons`: Error messages for each rejected step
- `schema_info`: Tuple of (schema object, fully qualified name)

**Returns:** (accepted_steps, remaining_errors)

**Process:**
1. Builds retry prompt with rejected steps and error reasons
2. Calls LLM with PLANNER_RETRY_SYSTEM_PROMPT + PLANNER_RETRY_USER_PROMPT
3. Parses LLM response as JSON
4. Validates each step's SQL
5. Logs results (accepted/rejected counts)
6. Returns validated steps

**Logging:**
```
planner.retry.start       # Started retry
planner.retry.llm.failed  # LLM call failed
planner.retry.json.parse_failed  # JSON parsing failed
planner.retry.step_rejected      # Individual step rejection
planner.retry.done        # Retry complete (with counts)
```

---

#### Modified Function: `_plan_steps()`
```python
async def _plan_steps(
    category: RiskCategory,
    semantic: SemanticResponse | None,
    max_retries: int = 2,  # ← NEW PARAMETER
) -> tuple[list[TraversalStep], list[str]]:
    """Prompt the LLM to produce a list of independent SQL steps.
    
    If steps are rejected due to validation errors, retry up to max_retries
    times, passing the rejection feedback to the LLM so it can fix the issues.
    """
```

**Process:**
1. Initial LLM call (same as before)
2. Validate each step's SQL
3. Collect rejected steps and their error reasons
4. **NEW: Retry loop (up to max_retries times)**
   - If rejected_steps is not empty:
     - Call `_retry_rejected_steps()` with feedback
     - Merge newly accepted steps into results
     - If still rejections and attempts < max_retries: continue loop
     - Else: break loop

**Logging:**
```
planner.llm.start              # Initial planning started
planner.llm.done               # Initial planning done (with counts)
planner.retry_attempt          # Retry attempt N started
planner.retry.start            # Retry LLM call started
planner.retry.done             # Retry LLM call done
planner.retry_still_has_errors # Retry produced more errors
planner.planning.complete      # All attempts complete (final summary)
```

**Example:** Calling with custom max_retries:
```python
# Default: 2 retries
steps, errors = await _plan_steps(category, semantic)

# Custom: 3 retries max
steps, errors = await _plan_steps(category, semantic, max_retries=3)
```

### 3. `src/risk_agent/prompts/__init__.py`
Updated exports to include:
```python
from risk_agent.prompts.planner import (
    PLANNER_SYSTEM_PROMPT,
    PLANNER_USER_PROMPT,
    PLANNER_RETRY_SYSTEM_PROMPT,    # NEW
    PLANNER_RETRY_USER_PROMPT,      # NEW
)

__all__ = [
    "PLANNER_SYSTEM_PROMPT",
    "PLANNER_USER_PROMPT",
    "PLANNER_RETRY_SYSTEM_PROMPT",    # NEW
    "PLANNER_RETRY_USER_PROMPT",      # NEW
]
```

---

## Behavior Changes

### Before
1. LLM generates steps
2. Invalid steps are rejected
3. ❌ No retry: 0 steps accepted

### After
1. LLM generates steps
2. Invalid steps are rejected
3. ✅ **Retry 1:** LLM sees rejection reasons, fixes steps
4. ✅ **Retry 2:** If needed, LLM retries again
5. All valid steps are returned

---

## Data Flow

### Step Rejection Detection
```python
for idx, raw_step in enumerate(parsed.get("steps", [])):
    try:
        sql = validate_sql(str(raw_step["sql_query"]))  # May raise
        steps.append(TraversalStep(...))
    except Exception as exc:
        # Collect for retry
        rejected_raw_steps.append(raw_step)
        rejection_reasons.append(str(exc))
```

### Retry Logic
```python
while rejected_raw_steps and retry_attempt < max_retries:
    retry_attempt += 1
    
    # Call LLM with feedback
    retry_steps, retry_errors = await _retry_rejected_steps(
        rejected_raw_steps,
        rejection_reasons,
        schema_info
    )
    
    # Merge results
    steps.extend(retry_steps)
    
    if retry_errors:
        errors.extend(retry_errors)
        break  # Stop retrying if still getting errors
```

---

## Error Messages Passed to LLM

From `src/risk_agent/utils/sql_safety.py`:

```python
# Error 1: Wrong query type
"Only SELECT / WITH queries are permitted."

# Error 2: Forbidden keywords
"SQL contains forbidden keyword (DDL/DML not allowed)."

# Error 3: Multiple statements
"Multiple statements are not allowed."

# Error 4: Empty query
"Empty SQL query."

# Error 5: Too long
"SQL exceeds maximum length of 20000 characters."
```

---

## Testing

### Manual Test Case

**Scenario:** LLM generates UPDATE query instead of SELECT

**Input:**
```json
{
  "steps": [
    {
      "source": "semantic_kpi",
      "name": "Fix billing records",
      "sql_query": "UPDATE billing SET status='verified' WHERE amount > 100"
    }
  ]
}
```

**Validation Fails:**
```
Error: "Only SELECT / WITH queries are permitted."
```

**Retry Feedback:**
```
Step 0:
  Name: Fix billing records
  Original SQL: UPDATE billing SET status='verified' WHERE amount > 100
  Error: Only SELECT / WITH queries are permitted.
  Source: semantic_kpi
```

**LLM Retry Response:**
```json
{
  "steps": [
    {
      "source": "semantic_kpi",
      "name": "Find billing records to verify",
      "sql_query": "SELECT COUNT(*) as unverified_count FROM billing WHERE status != 'verified' AND amount > 100"
    }
  ]
}
```

**Result:** ✅ Step accepted on retry

---

## Integration Points

### Called By
- `plan_and_execute_node()` - via `_plan_steps()`
- `planning_node()` - back-compat shim

### Calls
- `load_target_table_schema()` - Load DB schema
- `build_llm()` - Get LLM instance
- `parse_llm_json()` - Parse LLM response
- `validate_sql()` - Check SQL safety

### No Changes Needed To
- Orchestrator
- Executor
- Generator
- Risk category models
- Step result models
- Database pool

---

## Performance Considerations

### Additional LLM Calls
- **Best case:** 0 extra (all steps valid initially)
- **Typical case:** 1 extra LLM call (retry once)
- **Worst case:** 2 extra LLM calls (both retries used)

### Latency Impact
- ~20-40 seconds per LLM call (typical)
- Retries happen sequentially (not parallel)

### Cost Impact
- Minimal - only retries when steps fail
- Retry prompts are smaller (only rejected steps, not all context)

---

## Backward Compatibility

✅ **Fully backward compatible**
- `max_retries` parameter is optional (default: 2)
- Existing code calling `_plan_steps(category, semantic)` works unchanged
- Return type is unchanged
- Function interface is unchanged (except new optional param)

---

## Future Enhancements

Possible improvements:
1. Configurable max_retries via settings.yaml
2. Different retry logic per error type
3. Exponential backoff between retries
4. Persistent retry history logging
5. Per-category retry statistics
6. Adaptive retry count based on failure patterns
