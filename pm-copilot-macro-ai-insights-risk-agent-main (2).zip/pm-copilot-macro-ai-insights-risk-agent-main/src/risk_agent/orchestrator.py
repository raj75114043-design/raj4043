"""High-level orchestrator that runs the graph for a single risk category."""

from __future__ import annotations

import time
from datetime import UTC, datetime

from risk_agent.graph import build_graph
from risk_agent.models import (
    AgentState,
    RiskCategory,
    RiskReport,
    StepStatus,
)
from risk_agent.utils.logging import get_logger
from risk_agent.utils.metrics import (
    categories_processed_total,
    category_duration_seconds,
)

_logger = get_logger(__name__)


class RiskAgentOrchestrator:
    """Runs the LangGraph agent for one category at a time and builds reports."""

    def __init__(self) -> None:
        self._graph = build_graph()

    async def run(self, category: RiskCategory) -> RiskReport:
        """Execute the full agent pipeline for a single risk category."""
        started_at = datetime.now(UTC)
        perf_start = time.perf_counter()

        initial_state: AgentState = {
            "category": category,
            "planned_steps": [],
            "step_results": [],
            "findings": [],
            "errors": [],
            "started_at_iso": started_at.isoformat(),
        }

        _logger.info(
            "orchestrator.run.start",
            category_id=category.category_id,
            name=category.name,
        )

        try:
            final_state = await self._graph.ainvoke(initial_state)
            status = "success"
        except Exception:
            categories_processed_total.labels(status="failed").inc()
            _logger.exception(
                "orchestrator.run.failed", category_id=category.category_id
            )
            raise

        elapsed = time.perf_counter() - perf_start
        category_duration_seconds.observe(elapsed)
        categories_processed_total.labels(status=status).inc()

        finished_at = datetime.now(UTC)
        step_results = final_state.get("step_results", [])
        planned = final_state.get("planned_steps", [])

        report = RiskReport(
            category=category,
            findings=final_state.get("findings", []),
            steps_planned=len(planned),
            steps_succeeded=sum(
                1 for r in step_results if r.status == StepStatus.SUCCESS
            ),
            steps_failed=sum(
                1 for r in step_results if r.status != StepStatus.SUCCESS
            ),
            total_rows_examined=sum(r.row_count for r in step_results),
            started_at=started_at,
            finished_at=finished_at,
            duration_ms=elapsed * 1000,
            summary=final_state.get("summary"),
        )

        _logger.info(
            "orchestrator.run.done",
            category_id=category.category_id,
            findings=len(report.findings),
            steps_planned=report.steps_planned,
            steps_succeeded=report.steps_succeeded,
            steps_failed=report.steps_failed,
            duration_ms=round(elapsed * 1000, 2),
        )

        try:
            from risk_agent.db.store import save_report
            await save_report(report, pipeline_type="excel")
        except Exception as exc:
            _logger.warning("orchestrator.save_report.failed", error=str(exc))

        return report
