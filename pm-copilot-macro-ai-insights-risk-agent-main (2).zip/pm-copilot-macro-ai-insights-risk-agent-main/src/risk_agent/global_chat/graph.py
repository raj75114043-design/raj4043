"""LangGraph ReAct graph for the global chat pipeline.

Topology:
    START → orchestrator → tools → orchestrator → END
                         (forced)   (synthesise)

The orchestrator uses tool_choice="required" on the first pass so the LLM
always hits the database. After tool results are present in the message list
it switches to tool_choice="auto" so the LLM can synthesise a final answer.
"""

from __future__ import annotations

from typing import Any

from langchain_core.messages import ToolMessage
from langgraph.graph import END, START, StateGraph
from langgraph.prebuilt import ToolNode, tools_condition

from risk_agent.core.llm import build_llm
from risk_agent.global_chat.sql_tool import query_risk_findings
from risk_agent.global_chat.state import GlobalChatState

_TOOLS = [query_risk_findings]

# Two LLM instances: one that forces a tool call, one that allows synthesis.
_LLM_FORCED: Any = None   # tool_choice="required" — used before any DB results
_LLM_AUTO: Any = None     # tool_choice="auto"     — used after DB results arrive


def _get_llm_forced():
    global _LLM_FORCED
    if _LLM_FORCED is None:
        _LLM_FORCED = build_llm("generator").bind_tools(_TOOLS, tool_choice="required")
    return _LLM_FORCED


def _get_llm_auto():
    global _LLM_AUTO
    if _LLM_AUTO is None:
        _LLM_AUTO = build_llm("generator").bind_tools(_TOOLS)
    return _LLM_AUTO


async def _orchestrator_node(state: GlobalChatState) -> dict[str, Any]:
    messages = state["messages"]
    # Once any ToolMessage is in the thread the LLM has real data — let it synthesise.
    has_tool_results = any(isinstance(m, ToolMessage) for m in messages)
    llm = _get_llm_auto() if has_tool_results else _get_llm_forced()
    response = await llm.ainvoke(messages)
    return {"messages": [response]}


def build_global_chat_graph() -> Any:
    tool_node = ToolNode(_TOOLS)

    graph = StateGraph(GlobalChatState)
    graph.add_node("orchestrator", _orchestrator_node)
    graph.add_node("tools", tool_node)

    graph.add_edge(START, "orchestrator")
    graph.add_conditional_edges("orchestrator", tools_condition)
    graph.add_edge("tools", "orchestrator")

    return graph.compile()
