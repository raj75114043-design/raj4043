"""Entry point for the global chat pipeline."""

from __future__ import annotations

from langchain_core.messages import HumanMessage, SystemMessage

from risk_agent.global_chat.graph import build_global_chat_graph
from risk_agent.global_chat.prompts import ORCHESTRATOR_SYSTEM_PROMPT, build_project_system_prompt
from risk_agent.utils.logging import get_logger

_logger = get_logger(__name__)


def _build_initial_messages(question: str, history: list[dict], project: str | None = None) -> list:
    system_prompt = build_project_system_prompt(project) if project else ORCHESTRATOR_SYSTEM_PROMPT
    messages: list = [SystemMessage(content=system_prompt)]

    if history:
        history_lines = "\n".join(
            f"{turn['role'].upper()}: {turn['content']}" for turn in history
        )
        user_content = f"CONVERSATION HISTORY:\n{history_lines}\n\nCURRENT QUESTION: {question}"
    else:
        user_content = question

    messages.append(HumanMessage(content=user_content))
    return messages


class GlobalChatOrchestrator:
    def __init__(self) -> None:
        self._graph = build_global_chat_graph()

    async def run_chat(self, question: str, history: list[dict], project: str | None = None) -> str:
        """Stateless chat — caller supplies history, no DB involved."""
        messages = _build_initial_messages(question, history, project=project)
        result = await self._graph.ainvoke({"messages": messages})

        # The last message in state is always the final non-tool-call AI answer.
        last_msg = result["messages"][-1]
        content = getattr(last_msg, "content", None)
        answer = content if isinstance(content, str) else str(content)

        _logger.info("global_chat.orchestrator.done", question=question[:80], project=project)
        return answer

    async def run_chat_with_session(self, question: str, session_id: str, project: str | None = None) -> str:
        """Session-aware chat — history is loaded from and saved to DB."""
        from risk_agent.db.chat_store import (
            append_messages,
            fetch_session,
            fetch_session_history,
            set_session_title,
        )

        history = await fetch_session_history(session_id)
        answer = await self.run_chat(question, history, project=project)

        await append_messages(session_id, [
            {"role": "user", "content": question},
            {"role": "assistant", "content": answer},
        ])

        session = await fetch_session(session_id)
        if session and not session.get("title"):
            await set_session_title(session_id, question[:120])

        _logger.info("global_chat.orchestrator.session_done", session_id=session_id, project=project)
        return answer
