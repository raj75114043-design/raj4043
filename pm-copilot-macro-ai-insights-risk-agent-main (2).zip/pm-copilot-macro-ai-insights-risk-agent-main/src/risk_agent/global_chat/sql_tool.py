"""SQL generator + executor tool for the global chat ReAct agent.

The tool takes a plain-English description of what data is needed, generates
a PostgreSQL SELECT query via LLM, validates it, and executes it.
On failure it retries up to 2 additional times, feeding the error back into
the generation prompt so the LLM can self-correct.
"""

from __future__ import annotations

import json
import re

from langchain_core.tools import tool

from risk_agent.core.llm import build_llm
from risk_agent.db.pool import fetch_all
from risk_agent.global_chat.prompts import SQL_GENERATION_PROMPT
from risk_agent.utils.logging import get_logger
from risk_agent.utils.sql_safety import validate_sql

_logger = get_logger(__name__)

_CODE_FENCE_RE = re.compile(r"```(?:sql)?(.+?)```", re.DOTALL | re.IGNORECASE)


def _clean_sql(raw: str) -> str:
    """Strip markdown code fences if the LLM wrapped the SQL in them."""
    match = _CODE_FENCE_RE.search(raw)
    if match:
        return match.group(1).strip()
    return raw.strip()


def _format_rows(rows: list[dict]) -> str:
    if not rows:
        return "No matching records found in the risk_findings table."
    return json.dumps(rows, indent=2, default=str)


async def _generate_sql(llm, query_description: str, error_ctx: str = "") -> str:
    error_section = (
        f"\n\nPrevious attempt failed with this error: {error_ctx}\nPlease fix the SQL."
        if error_ctx
        else ""
    )
    prompt = SQL_GENERATION_PROMPT.format(
        question=query_description,
        error_section=error_section,
    )
    response = await llm.ainvoke([{"role": "user", "content": prompt}])
    return getattr(response, "content", None) or str(response)


@tool
async def query_risk_findings(query_description: str) -> str:
    """Query the risk findings database. Describe in plain English what data you need.

    Example inputs:
    - 'Count of risks grouped by category_id'
    - 'Which region has the most critical severity risks?'
    - 'List all open risks in the schedule category'
    """
    llm = build_llm("generator")
    error_ctx = ""

    for attempt in range(3):
        try:
            raw_sql = await _generate_sql(llm, query_description, error_ctx)
            sql = _clean_sql(raw_sql)
            validate_sql(sql)
            rows = await fetch_all(sql)
            _logger.info("global_chat.sql_tool.success", attempt=attempt, rows=len(rows))
            return _format_rows(rows)
        except Exception as exc:
            error_ctx = str(exc)
            _logger.warning("global_chat.sql_tool.retry", attempt=attempt, error=error_ctx)

    return f"Could not execute the query after 3 attempts. Last error: {error_ctx}"
