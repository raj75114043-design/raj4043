"""LangGraph graph builder.

New topology (geo-first Excel pipeline with milestone enrichment):

    START
      │
      ▼
  semantic_retrieval       (fetch KPIs + detect project + inject business_context)
      │
      ▼
  fetch_geo_tree           (GET geo hierarchy API → geo_tree in state)
      │
      ▼
  plan_steps               (1 site-level NL query → AI Assistant → SQL stored, not executed)
      │
      ▼
  region_sql_plan          (2 aggregated NL queries → executed → region_agg_results + total_active_results)
      │
      ▼
  analyze_region           (group cached agg data by region → LLM flags regions → region_geo_findings)
      │
      ▼
  analyze_area             (concurrent per flagged region → area_geo_findings)
      │
      ▼
  analyze_market           (concurrent per flagged area → market_geo_findings)
      │
      ▼
  analyze_site             (fresh NL query per flagged market → site rows + LLM analysis → excel_site_step_results)
      │
      ▼
  enrich_milestones        (GET milestone API per flagged site → site_milestones)
      │
      ▼
  risk_identification      (geo analysis JSON + milestone data → one RiskFinding per flagged region)
      │
      ▼
     END
"""

from __future__ import annotations

from typing import Any

from langgraph.graph import END, START, StateGraph

from risk_agent.agents import (
    analyze_area_node,
    analyze_market_node,
    analyze_region_node,
    analyze_site_node,
    fetch_geo_tree_node,
    plan_steps_node,
    region_sql_plan_node,
    risk_identification_node,
    semantic_retrieval_node,
)
from risk_agent.agents.milestone_enricher import enrich_milestones_node
from risk_agent.models import AgentState

# Node names (single source of truth)
NODE_SEMANTIC        = "semantic_retrieval"
NODE_GEO_TREE        = "fetch_geo_tree"
NODE_PLAN            = "plan_steps"
NODE_REGION_SQL_PLAN = "region_sql_plan"
NODE_REGION          = "analyze_region"
NODE_AREA            = "analyze_area"
NODE_MARKET          = "analyze_market"
NODE_SITE            = "analyze_site"
NODE_MILESTONES      = "enrich_milestones"
NODE_GENERATOR       = "risk_identification"


def build_graph() -> Any:
    """Construct and compile the LangGraph state graph (9-node geo-first pipeline)."""
    graph = StateGraph(AgentState)

    graph.add_node(NODE_SEMANTIC,        semantic_retrieval_node)
    graph.add_node(NODE_GEO_TREE,        fetch_geo_tree_node)
    graph.add_node(NODE_PLAN,            plan_steps_node)
    graph.add_node(NODE_REGION_SQL_PLAN, region_sql_plan_node)
    graph.add_node(NODE_REGION,          analyze_region_node)
    graph.add_node(NODE_AREA,            analyze_area_node)
    graph.add_node(NODE_MARKET,          analyze_market_node)
    graph.add_node(NODE_SITE,            analyze_site_node)
    graph.add_node(NODE_MILESTONES,      enrich_milestones_node)
    graph.add_node(NODE_GENERATOR,       risk_identification_node)

    graph.add_edge(START,                NODE_SEMANTIC)
    graph.add_edge(NODE_SEMANTIC,        NODE_GEO_TREE)
    graph.add_edge(NODE_GEO_TREE,        NODE_PLAN)
    graph.add_edge(NODE_PLAN,            NODE_REGION_SQL_PLAN)
    graph.add_edge(NODE_REGION_SQL_PLAN, NODE_REGION)
    graph.add_edge(NODE_REGION,          NODE_AREA)
    graph.add_edge(NODE_AREA,            NODE_MARKET)
    graph.add_edge(NODE_MARKET,          NODE_SITE)
    graph.add_edge(NODE_SITE,            NODE_MILESTONES)
    graph.add_edge(NODE_MILESTONES,      NODE_GENERATOR)
    graph.add_edge(NODE_GENERATOR,       END)

    return graph.compile()
