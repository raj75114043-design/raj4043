"""Risk Identification and Mitigation Agent.

A LangGraph-based agentic workflow that processes one risk category at a
time by combining semantic context (relevant KPIs) and natural-language
identification logic into a fan-out of parallel SQL traversal steps,
then synthesizes structured risk findings.
"""

__version__ = "1.0.0"

__all__ = ["__version__"]
