"""KPI hierarchical trend analysis pipeline.

Analyzes all KPIs across all geographies (Region → Area → Market → Site)
and produces a RiskReport in the same format as the Excel pipeline.
"""

from risk_agent.kpi_analysis.orchestrator import KPIAnalysisOrchestrator

__all__ = ["KPIAnalysisOrchestrator"]
