"""LLM prompt templates for each geographic analysis level.

Each builder function returns a (system_prompt, user_prompt) tuple.
The analyzers feed a per-(KPI, geography) time series — most recent
first — and the LLM compares the latest value against the prior
baseline to decide whether the trend is anomalous.
"""

from __future__ import annotations

from collections import defaultdict
from typing import Any

from risk_agent.kpi_analysis.models import KPIMaster, TrendFinding
from risk_agent.models.domain import StepResult

# Known comment / narrative columns that carry PM and GC operational context.
# Exported so other modules (e.g. report_synthesizer) can reuse the same list.
COMMENT_COLUMNS: list[str] = [
    "pj_construction_start_delay_comments",
    "pj_construction_complete_delay_comments",
    "pj_on_air_delay_code_comments",
    "pj_project_comment_history",
    "wp_notes",
    "site_remarks_from_pm_tracker",
]

_RISK_CATEGORIES = [
    "Schedule",
    "Material Management",
    "Regulatory / Permits",
    "HSE & Safety",
    "GC Risk & Performance",
    "Quality",
    "Governance Risk & Data",
    "Customer",
    "Vendor & SLA",
    "Pre-Construction & Validation",
    "Financial & Strategic Risk",
    "Workforce & Capability",
    "Tools & Systems Access",
    "Market / Region",
]

_TREND_FINDING_SCHEMA = f"""
Return a JSON array of trend finding objects. Each object must have exactly:
{{
  "geo_level": "<region|area|market>",
  "geo_name": "<UPPERCASE name of the geography, copied verbatim from the input>",
  "parent_geo": "<UPPERCASE parent geography name, or null at the region level>",
  "kpi_name": "<KPI name, copied verbatim from the input>",
  "is_anomalous": true,
  "trend_summary": "<1-2 sentence plain-English description of the risk and projected breach>",
  "recent_values": [<last 3-5 (date, value) pairs as objects>],
  "threshold_breached": <true if the value has already crossed the hard threshold, otherwise false>,
  "sla_at_risk": <true if the KPI is already past SLA or trending toward an SLA miss, otherwise false>,
  "risk_category": "<one of the categories listed below>"
}}
Preferred risk_category values (pick the single best fit; use a similar label if none fits exactly):
{chr(10).join(f'  - {c}' for c in _RISK_CATEGORIES)}

Include ONLY anomalous entries. Return [] if nothing is anomalous.
Output raw JSON only — no markdown fences, no commentary.
"""

_SYSTEM_BASE = (
    "You are a telecom KPI risk analyst. You receive a per-KPI per-geography "
    "time series covering the past 30 days (most-recent-first, up to 12 data points) "
    "and identify combinations that present a risk.\n\n"
    "A KPI is flagged if ANY of STEP 2, STEP 3, or STEP 4 is triggered.\n\n"
    "STEP 1 — DIRECTION\n"
    "Determine the bad direction for each KPI from the 'disturbing_trend' field:\n"
    "  - 'dec': falling values are bad (e.g. completion %, compliance rate, throughput).\n"
    "  - 'inc': rising values are bad (e.g. non-compliance rate, alarm count, error rate).\n"
    "  If disturbing_trend is absent, infer the bad direction from the KPI name/description/formula.\n\n"
    "STEP 2 — FLAG ON SUSTAINED DEVIATION (always applies — no SLA/threshold needed)\n"
    "Use ALL available data points from the 30-day window. "
    "Compare the latest value against the earliest value in the window:\n"
    "  - 'dec' KPI: flag if the latest value is ≥10% LOWER than the earliest "
    "(metric has deteriorated over the period).\n"
    "  - 'inc' KPI: flag if the latest value is ≥10% HIGHER than the earliest "
    "(metric has worsened over the period).\n"
    "The deterioration must be sustained — not a single-period spike that immediately reverts. "
    "A consistent multi-week trend in the bad direction across the full 30-day window "
    "is stronger evidence than a short recent drop.\n\n"
    "STEP 3 — FLAG ON SLA BREACH OR APPROACH (requires 'sla(soft)' in KPI definition)\n"
    "Set sla_at_risk=true AND flag the KPI when:\n"
    "  (a) the latest value has already crossed the SLA, OR\n"
    "  (b) the trend over the 30-day window, if continued, will cross the SLA within "
    "2-3 more periods.\n"
    "A KPI that has already breached SLA must still be flagged — the next risk is "
    "whether the hard threshold will also be crossed.\n\n"
    "STEP 4 — FLAG ON THRESHOLD BREACH OR APPROACH (requires 'threshold(hard)' in KPI definition)\n"
    "Set threshold_breached=true AND flag the KPI when:\n"
    "  (a) the latest value has already crossed the hard threshold, OR\n"
    "  (b) the trend over the 30-day window makes a breach within 2-3 periods likely.\n\n"
    "STEP 5 — PRECISION\n"
    "Copy kpi_name and geography names verbatim from the input. "
    "Do not invent, abbreviate, or alter any name.\n\n"
    "STEP 6 — FULLY QUALIFIED GEOGRAPHY NAMES IN NARRATIVE FIELDS ONLY\n"
    "When writing the trend_summary field, always write geography names in full:\n"
    "  - Regions: append ' Region'   (e.g. 'Central Region', not 'Central').\n"
    "  - Areas:   append ' Area'     (e.g. 'Texas Area', not 'Texas').\n"
    "  - Markets: append ' Market'   (e.g. 'Dallas Market', not 'Dallas').\n"
    "CRITICAL: geo_name and parent_geo must be copied VERBATIM from the input — "
    "DO NOT add any suffix to these fields. They are database keys used for exact matching.\n\n"
    "STEP 7 — HISTORICAL DATA / ACTIVE SITES ONLY\n"
    "You are analyzing historical KPI data to identify forward-looking risks. "
    "Sites whose status is 'Completed' (pj_project_status contains 'complet') are "
    "excluded from risk findings — they cannot generate new risk. "
    "Do not flag or reference completed sites in trend_summary or any output field.\n"
)


def _format_master(masters: list[KPIMaster]) -> str:
    """Compact KPI dictionary for the LLM. Includes description, formula, and logic."""
    if not masters:
        return "KPI definitions: (none provided)"
    lines = ["KPI definitions:"]
    for m in masters:
        line = f"  - {m.kpi_name}"
        if m.description:
            line += f": {m.description}"
        if m.formula:
            formula = m.formula.replace("\n", " ").strip()
            if len(formula) > 200:
                formula = formula[:200] + "..."
            line += f" | formula: {formula}"
        if m.logic:
            logic = m.logic.replace("\n", " ").strip()
            if len(logic) > 200:
                logic = logic[:200] + "..."
            line += f" | logic: {logic}"
        if m.disturbing_trend:
            line += f" | disturbing_trend: {m.disturbing_trend}"
        if m.threshold is not None:
            line += f" | threshold(hard): {m.threshold}"
        if m.sla is not None:
            line += f" | sla(soft): {m.sla}"
        if m.phase:
            line += f" | phase: {m.phase}"
        lines.append(line)
    return "\n".join(lines)


def _format_time_series(rows: list[dict[str, Any]]) -> str:
    """Group rows by (kpi_name, geo) and emit a compact per-series view.

    Rows must already be sorted by ``result_date_time`` DESC. Geo column
    is auto-detected: market_name > area_name > region_name.
    """
    groups: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for r in rows:
        geo = r.get("market_name") or r.get("area_name") or r.get("region_name") or "?"
        kpi = r.get("kpi_name") or "?"
        groups[(kpi, geo)].append(r)

    if not groups:
        return "(no data)"

    lines = []
    for (kpi, geo), pts in groups.items():
        pairs = []
        for p in pts:
            v = p.get("value")
            if v is None:
                continue
            dt = p.get("result_date_time")
            date_str = dt.date().isoformat() if hasattr(dt, "date") else str(dt)
            pairs.append(f"({date_str}: {v})")
        if pairs:
            lines.append(f"  KPI={kpi!r} GEO={geo!r}: {', '.join(pairs)}")
    return "\n".join(lines) if lines else "(no numeric values)"


def build_region_prompts(
    kpi_masters: list[KPIMaster],
    data_rows: list[dict[str, Any]],
    kpi_keywords_context: str | None = None,
    project_business_contexts: dict[str, str] | None = None,
) -> tuple[str, str]:
    system = _SYSTEM_BASE + _TREND_FINDING_SCHEMA
    parts = [
        _format_master(kpi_masters),
    ]
    if kpi_keywords_context:
        parts.append(kpi_keywords_context)
    if project_business_contexts:
        for proj in sorted({m.project for m in kpi_masters if m.project}):
            ctx = project_business_contexts.get(proj, "")
            if ctx:
                parts.append(ctx)
    parts.append(
        f"Region-level KPI time series ({len(data_rows)} data points):\n"
        + _format_time_series(data_rows)
    )
    parts.append(
        "Identify all (region, KPI) combinations showing an anomalous trend. "
        "Use geo_level='region', set parent_geo=null, "
        "and copy kpi_name and region name verbatim from the input."
    )
    return system, "\n\n".join(parts)


def build_area_prompts(
    kpi_masters: list[KPIMaster],
    data_rows: list[dict[str, Any]],
    parent_region: str,
    flagged_kpis: list[str],
    kpi_keywords_context: str | None = None,
    project_business_contexts: dict[str, str] | None = None,
    parent_findings: list[TrendFinding] | None = None,
) -> tuple[str, str]:
    relevant_masters = [m for m in kpi_masters if m.kpi_name in flagged_kpis] or kpi_masters
    system = _SYSTEM_BASE + _TREND_FINDING_SCHEMA
    parts = [
        _format_master(relevant_masters),
    ]
    if kpi_keywords_context:
        parts.append(kpi_keywords_context)
    if project_business_contexts:
        for proj in sorted({m.project for m in relevant_masters if m.project}):
            ctx = project_business_contexts.get(proj, "")
            if ctx:
                parts.append(ctx)
    if parent_findings:
        lines = [
            f"PARENT REGION CONTEXT — apply relaxed detection thresholds for these KPIs.",
            f"The region analyzer has already confirmed these KPIs are anomalous in '{parent_region}'.",
            "Your job is to identify WHICH areas are contributing, even if individual deviations are small.",
            "Rules for parent-confirmed KPIs:",
            "  - Flag any area moving in the disturbing direction, even below the normal threshold.",
            "  - If no area shows a clear anomaly, flag the area with the worst/most deteriorating trend",
            "    as a low-severity finding — the region-level signal is already established.",
            "  - Do NOT return [] for a KPI that has a confirmed region-level anomaly.",
            "Region-level findings:",
        ]
        for f in parent_findings:
            lines.append(f"  - {f.kpi_name}: {f.trend_summary}")
        parts.append("\n".join(lines))
    parts.append(
        f"Area-level KPI time series within region '{parent_region}' "
        f"for KPIs {flagged_kpis} ({len(data_rows)} data points):\n"
        + _format_time_series(data_rows)
    )
    parts.append(
        f"Identify all (area, KPI) pairs within region '{parent_region}' showing "
        f"an anomalous trend. Use geo_level='area' and parent_geo='{parent_region}'. "
        "Copy kpi_name and area_name verbatim from the input."
    )
    return system, "\n\n".join(parts)


def build_market_prompts(
    kpi_masters: list[KPIMaster],
    data_rows: list[dict[str, Any]],
    parent_area: str,
    flagged_kpis: list[str],
    kpi_keywords_context: str | None = None,
    project_business_contexts: dict[str, str] | None = None,
    parent_findings: list[TrendFinding] | None = None,
) -> tuple[str, str]:
    relevant_masters = [m for m in kpi_masters if m.kpi_name in flagged_kpis] or kpi_masters
    system = _SYSTEM_BASE + _TREND_FINDING_SCHEMA
    parts = [
        _format_master(relevant_masters),
    ]
    if kpi_keywords_context:
        parts.append(kpi_keywords_context)
    if project_business_contexts:
        for proj in sorted({m.project for m in relevant_masters if m.project}):
            ctx = project_business_contexts.get(proj, "")
            if ctx:
                parts.append(ctx)
    if parent_findings:
        lines = [
            f"PARENT AREA CONTEXT — apply relaxed detection thresholds for these KPIs.",
            f"The area analyzer has already confirmed these KPIs are anomalous in '{parent_area}'.",
            "Your job is to identify WHICH markets are contributing, even if individual deviations are small.",
            "Rules for parent-confirmed KPIs:",
            "  - Flag any market moving in the disturbing direction, even below the normal threshold.",
            "  - If no market shows a clear anomaly, flag the market with the worst/most deteriorating trend",
            "    as a low-severity finding — the area-level signal is already established.",
            "  - Do NOT return [] for a KPI that has a confirmed area-level anomaly.",
            "Area-level findings:",
        ]
        for f in parent_findings:
            lines.append(f"  - {f.kpi_name}: {f.trend_summary}")
        parts.append("\n".join(lines))
    parts.append(
        f"Market-level KPI time series within area '{parent_area}' "
        f"for KPIs {flagged_kpis} ({len(data_rows)} data points):\n"
        + _format_time_series(data_rows)
    )
    parts.append(
        f"Identify all (market, KPI) pairs within area '{parent_area}' showing "
        f"an anomalous trend. Use geo_level='market' and parent_geo='{parent_area}'. "
        "Copy kpi_name and market_name verbatim from the input."
    )
    return system, "\n\n".join(parts)


def build_site_sql_prompt(
    site_table_columns: list[dict[str, Any]],
    site_table_qualified: str,
    market_name: str,
    kpi_name: str,
    trend_summary: str,
    question_bank_context: str | None = None,
    business_context: str | None = None,
) -> tuple[str, str]:
    col_lines = "\n".join(
        f"  {c['column_name']} ({c.get('data_type', 'unknown')})"
        for c in site_table_columns
    )
    system = (
        "You are a PostgreSQL expert for a telecom network database. "
        "Generate TWO SQL queries for a KPI problem in a given market.\n"
        "Rules (apply to both queries):\n"
        "- Target dialect: PostgreSQL. Use only standard PostgreSQL syntax.\n"
        "- Use only SELECT — no INSERT/UPDATE/DELETE/DDL.\n"
        "- Reference only the table and columns listed below.\n"
        "- CRITICAL: Copy column names CHARACTER-FOR-CHARACTER from the list. "
        "Do not guess, abbreviate, or alter any column name in any way — "
        "even a single missing underscore will cause a query failure.\n"
        "- Filter to the given market (case-insensitive).\n"
        "- Column data types are shown in parentheses — compare columns against "
        "values of the matching type (use string literals for 'character varying', "
        "not bare integers).\n"
        "- For NULL-safe comparison/sorting, use COALESCE rather than non-portable functions.\n"
        "- EXCLUDE COMPLETED SITES: If the table has a column named 'pj_project_status', "
        "always add: WHERE pj_project_status NOT ILIKE '%complet%' "
        "(or AND pj_project_status NOT ILIKE '%complet%' if other WHERE conditions exist).\n"
        "- PostgreSQL type-safety rules (CRITICAL — violating these causes runtime errors):\n"
        "  * ROUND(x, n) requires x to be NUMERIC. Cast: ROUND(x::numeric, 2).\n"
        "  * EXTRACT(EPOCH FROM ...) returns DOUBLE PRECISION — cast before ROUND: "
        "ROUND((EXTRACT(EPOCH FROM expr) / 86400.0)::numeric, 1).\n"
        "  * DATE_PART() also returns DOUBLE PRECISION — same rule applies.\n"
        "  * Do NOT use ROUND(double_precision_column, n) directly — always cast first.\n\n"
        "Return a JSON object with exactly two keys — no markdown fences, no extra text:\n"
        "{\n"
        '  "detail_sql": "<SELECT returning individual site rows that breach the KPI condition, '
        'ordered worst-first>",\n'
        '  "count_sql": "<SELECT COUNT(*) AS total_eligible FROM same_table with the same base '
        "filters (market, not-completed, KPI eligibility) BUT WITHOUT the KPI breach/threshold "
        'condition — counts all active eligible sites for this KPI in this market>"\n'
        "}\n"
    )
    comment_col_names = "\n".join(f"  - {c}" for c in COMMENT_COLUMNS)
    question_bank_section = ""
    if question_bank_context:
        question_bank_section = (
            f"\n{question_bank_context}\n"
            "Use the patterns above as inspiration for JOIN structure, WHERE conditions, "
            "and ORDER BY — but adapt them to the actual columns available in this table.\n"
        )
    business_context_section = ""
    if business_context:
        business_context_section = (
            f"\nDeployment process knowledge graph for this project:\n{business_context}\n"
            "IMPORTANT — use the knowledge graph above as your PRIMARY column directory:\n"
            f"  1. Identify which phase(s) the KPI '{kpi_name}' belongs to based on "
            "the KPI name, description, and the phase titles in the graph.\n"
            "  2. Select columns ONLY from the nodes defined in those relevant phase(s). "
            "Do not guess column names from the full table list.\n"
            "  3. Always include the site identifier column from the base node.\n"
            "  4. If no phase clearly matches, fall back to the available columns list.\n"
        )
    user = (
        f"Table: {site_table_qualified}\n"
        f"Available columns (use names exactly as shown):\n{col_lines}\n\n"
        f"Problem: Market '{market_name}' has an anomalous trend for KPI '{kpi_name}'.\n"
        f"Issue details: {trend_summary}\n"
        f"{question_bank_section}"
        f"{business_context_section}\n"
        "Write a SQL query that returns the individual sites in this market "
        "most likely contributing to the KPI issue.\n\n"
        "COLUMN SELECTION RULES — be selective, not exhaustive:\n"
        "1. Always include the site identifier column(s) (e.g. site_id, site_name).\n"
        "2. If a knowledge graph was provided above, use it to pick columns — "
        "select only those from the phase(s) relevant to this KPI. "
        "Otherwise include only the metric / date / status columns that DIRECTLY relate to "
        f"the KPI '{kpi_name}' anomaly — columns that explain "
        "the magnitude, timing, or cause of the problem.\n"
        "3. Do NOT include every available column. Exclude generic metadata, internal "
        "system IDs, or columns unrelated to this specific KPI issue.\n"
        "4. Also include any of the following comment/narrative columns that exist in "
        "the table — they carry the PM's and GC's explanation of the issue:\n"
        f"{comment_col_names}\n"
        "   Also include any other column whose name contains: comment, remark, note, reason, history.\n"
        "5. Order by the most severe / worst-performing sites first."
    )
    return system, user


def build_site_sql_retry_prompt(
    site_table_columns: list[dict[str, Any]],
    site_table_qualified: str,
    market_name: str,
    kpi_name: str,
    trend_summary: str,
    failed_sql: str,
    error_message: str,
    question_bank_context: str | None = None,
    business_context: str | None = None,
) -> tuple[str, str]:
    """Retry prompt: feed the failing SQL + PostgreSQL error back to the LLM."""
    col_lines = "\n".join(
        f"  {c['column_name']} ({c.get('data_type', 'unknown')})"
        for c in site_table_columns
    )
    system = (
        "You are a PostgreSQL expert. Your previous query failed with a database error. "
        "Read the error message carefully — PostgreSQL often suggests the correct column "
        "name in a HINT line. Fix the query and return the corrected result as JSON.\n"
        "Rules:\n"
        "- Target dialect: PostgreSQL.\n"
        "- Use only SELECT — no INSERT/UPDATE/DELETE/DDL.\n"
        "- Use column names EXACTLY as listed below — character-for-character.\n"
        "- If the error mentions a non-existent column, use the suggested column from the HINT, "
        "or pick the closest valid column from the list.\n"
        "- If the error is a syntax error, replace the offending construct with standard "
        "PostgreSQL (e.g., GREATEST/LEAST, COALESCE, CASE WHEN).\n"
        "- Common fix: 'function round(double precision, integer) does not exist' → "
        "cast to numeric first: ROUND(expr::numeric, n).\n"
        "- EXTRACT(EPOCH FROM ...) and DATE_PART() return double precision — "
        "always cast before ROUND: ROUND((EXTRACT(EPOCH FROM x) / 86400.0)::numeric, 1).\n"
        "- EXCLUDE COMPLETED SITES: If 'pj_project_status' exists in the table, "
        "ensure both queries keep: WHERE/AND pj_project_status NOT ILIKE '%complet%'.\n"
        "Return a JSON object with exactly two keys — no markdown fences, no extra text:\n"
        "{\n"
        '  "detail_sql": "<corrected SELECT returning individual site rows that breach the KPI condition>",\n'
        '  "count_sql": "<SELECT COUNT(*) AS total_eligible with same base filters but WITHOUT the KPI breach condition>"\n'
        "}\n"
    )
    comment_col_names = "\n".join(f"  - {c}" for c in COMMENT_COLUMNS)
    question_bank_section = ""
    if question_bank_context:
        question_bank_section = (
            f"\n{question_bank_context}\n"
            "Use these patterns as inspiration — adapt them to the actual columns.\n"
        )
    business_context_section = ""
    if business_context:
        business_context_section = (
            f"\nDeployment process context for this project:\n{business_context}\n"
            "Use the phase and column descriptions above to identify which columns "
            "are directly relevant to the KPI anomaly.\n"
        )
    user = (
        f"Table: {site_table_qualified}\n"
        f"Available columns (use names exactly as shown):\n{col_lines}\n\n"
        f"Original problem: Market '{market_name}' has an anomalous trend for KPI '{kpi_name}'.\n"
        f"Issue details: {trend_summary}\n"
        f"{question_bank_section}"
        f"{business_context_section}\n"
        f"Previous SQL (FAILED):\n{failed_sql}\n\n"
        f"PostgreSQL error:\n{error_message}\n\n"
        "Return the corrected JSON — same intent for both queries but fix the error above.\n\n"
        "COLUMN SELECTION RULES for detail_sql (same as original):\n"
        "1. Site identifier column(s) always included.\n"
        f"2. Only columns that DIRECTLY evidence the '{kpi_name}' anomaly "
        "(metric value, date, status). Do not select all columns.\n"
        "3. Comment/narrative columns that exist in the table:\n"
        f"{comment_col_names}\n"
        "   Plus any column whose name contains: comment, remark, note, reason, history.\n"
        "4. Order worst-performing sites first.\n"
        "count_sql must be: SELECT COUNT(*) AS total_eligible FROM same_table "
        "with the same base filters but WITHOUT the KPI breach condition."
    )
    return system, user


_INVESTIGATION_SYSTEM = """You are a senior risk analyst investigating anomalous KPI trends for a telecom tower deployment program.

AUDIENCE / END USERS
Your findings are read by Project Managers who take operational action on live programs —
calling General Contractors, escalating NTPs, expediting POs, reallocating crews, etc.
Write in business English a PM can paste into a status review.
Mitigation actions and recovery steps must be concrete and PM-ownable — not generic advice
like "monitor the data". When you reference contributors (GC, market, crew), surface them explicitly.

RISK LABEL RULES (risk_label field)
The risk_label must be forward-looking, hierarchical, and quantified. Requirements:
  1. Include the full hierarchy chain: Region → Area(s) → Market(s) → sites count
     e.g. "FTR declining in Southeast Region across 3 areas, 7 markets, 42 active sites"
  2. Use fully qualified geography names (append Region / Area / Market suffix).
  3. State the direction and magnitude: "declining", "at risk of SLA breach", "trending toward threshold".
  4. Quote actual numbers from the input (area count, market count, site count) — never omit them.
  5. Be forward-looking: use phrases like "at risk of", "trending toward", "projected to breach".
  6. NEVER use generic phrases like "Anomalous X trend in Y" or "KPI degradation in Z".
  7. Examples of good labels:
     • "On Air Completion Rate falling in Central Region — 2 areas, 5 markets, 28 sites at risk of SLA miss"
     • "NTP Compliance trending toward hard threshold in West Region across 4 markets"
     • "WIP Backlog rising in Southwest Region — GC-Alpha sites in Dallas Market driving 60% of volume"
  8. If the KPI has a 'Phase:' annotation, you may use the phase NAME as a natural prefix only
     when it distinguishes the risk — e.g. "Tower Work compliance" or "NTP Acceptance".
     NEVER write the phase number (never "Phase 5", "Phase 8", etc.).

GEOGRAPHY NAMES
Always write fully qualified geography names in all text fields:
  - Regions: "<name> Region"   (e.g. "Central Region")
  - Areas:   "<name> Area"     (e.g. "Texas Area")
  - Markets: "<name> Market"   (e.g. "Dallas Market")

RISK ASSESSMENT MATRIX
Evaluate each finding on two dimensions:

1. LIKELIHOOD — How probable is this risk to continue or worsen?
   • unlikely   : <33% chance (isolated, borderline data, single period)
   • may_happen : 33–66% chance (consistent pattern across 2+ periods or geographies)
   • likely     : >66% chance (sustained multi-period decline, broad geographic spread)

2. IMPACT — Calculated from the percentage of eligible sites affected:
   • minor    : ≤5% of total eligible sites impacted
   • major    : 6–9% of total eligible sites impacted
   • critical : ≥10% of total eligible sites impacted
   Note: impact is computed by the system from site counts when available.
   Use your best judgment only when site count data is absent.

The system calculates RISK_RATING = LIKELIHOOD × IMPACT:
┌──────────┬──────────┬─────────┬──────────┐
│          │ Minor    │ Major   │ Critical │
├──────────┼──────────┼─────────┼──────────┤
│ Unlikely │ Low      │ Low     │ Medium   │
│ MayHapp. │ Low      │ Medium  │ High     │
│ Likely   │ Medium   │ High    │ Critical │
└──────────┴──────────┴─────────┴──────────┘

CONFIDENCE CALIBRATION (0.0–1.0):
  • 0.3 or below : single geography, borderline trend, or ambiguous evidence
  • 0.5–0.7      : two or more geographies agree, clear sustained pattern in data
  • 0.8–0.9      : three or more corroborating geographies with decisive site-level evidence

COMMENT / NARRATIVE COLUMNS — PRIMARY ROOT CAUSE SOURCE
When site-level rows contain PM or GC comments, treat them as the primary evidence
for root_cause. Quote the actual text so the PM has operational context without
opening a spreadsheet. Key comment columns:
  • pj_construction_start_delay_comments   (Cx Start delay reason)
  • pj_construction_complete_delay_comments (Cx Complete delay reason)
  • pj_on_air_delay_code_comments          (On Air delay reason)
  • pj_project_comment_history             (full timestamped project comment log)
  • wp_notes                               (work package notes / timestamped site comments)
  • site_remarks_from_pm_tracker           (market PM's site-specific remarks)
  • any other column whose name contains: comment, remark, note, reason, history

DRILL-DOWN TABLES
Build drill_down_tables that expose the evidence hierarchy (area → market → site).
COLUMN DISCIPLINE — for each table select ONLY columns that make the risk visible:
  • Geography identifiers (area_name, market_name, site_id, gc_name)
  • The KPI metric column(s) showing the anomaly (value, threshold, gap)
  • Date/period columns establishing timing of the issue
  • Status, delay-code, or lifecycle stage columns
  • Comment/remark/notes columns carrying PM or GC narrative
Omit internal IDs, redundant keys, and columns that add no additional insight.
Each table element must follow this schema:
  { "title": "...", "columns": ["col1", ...], "rows": [[v1, ...], ...], "source": "area|market|site" }

DOMAIN TERMINOLOGY (telecom tower deployment):
  - GC = General Contractor (vendor who deploys field crews)
  - NTP = Notice to Proceed
  - SPO / PO = Special/Purchase Order (material ordering authority)
  - RFI = Ready for Installation (or Request for Information)
  - NOC = Notice of Commencement
  - WIP = Work In Progress (construction in progress)
  - FTR = First Time Right
  - H&S / HSE = Health & Safety
  - SLA = Service Level Agreement
  - CAPA = Corrective and Preventive Action
  - Run rate = daily/weekly site delivery output
  - Crew = field installation team under a GC
  - Cycle time = days from NTP to on-air

Return STRICT JSON only — no markdown fences, no commentary outside the JSON object.
"""


def _format_trend_findings_for_prompt(findings: list[TrendFinding], label: str) -> str:
    """Format a list of TrendFindings into a compact tabular prompt section."""
    if not findings:
        return f"{label}: none"
    lines = [f"{label} ({len(findings)} flagged):"]
    for f in findings:
        lines.append(f"  • {f.geo_name}: {f.trend_summary}")
    return "\n".join(lines)


def build_investigation_prompt(
    finding: TrendFinding,
    area_findings: list[TrendFinding],
    market_findings: list[TrendFinding],
    kpi_master: KPIMaster | None,
    comment_snippets: list[str] | None = None,
    business_context: str | None = None,
    impacted_sites_count: int | None = None,
    site_rows: list[dict] | None = None,
) -> tuple[str, str]:
    """Build the risk investigation prompt including active site-level rows for deeper analysis."""
    kpi_context = ""
    if kpi_master:
        if kpi_master.phase:
            kpi_context += f"\nPhase: {kpi_master.phase}"
        if kpi_master.description:
            kpi_context += f"\nDescription: {kpi_master.description}"
        if kpi_master.formula:
            formula = kpi_master.formula.replace("\n", " ").strip()
            kpi_context += f"\nFormula: {formula[:300]}"
        if kpi_master.logic:
            logic = kpi_master.logic.replace("\n", " ").strip()
            kpi_context += f"\nLogic: {logic[:300]}"

    recent = ", ".join(
        f"({v.get('date', '?')}: {v.get('value', '?')})"
        for v in (finding.recent_values or [])[:5]
    )

    area_section = _format_trend_findings_for_prompt(area_findings, "Flagged areas")
    market_section = _format_trend_findings_for_prompt(market_findings, "Flagged markets")

    comment_section = ""
    if comment_snippets:
        formatted = "\n".join(f"  • {s}" for s in comment_snippets[:20])
        comment_section = (
            f"\nPM / GC comment excerpts (from delay and project comment columns):\n"
            f"{formatted}\n"
        )

    business_context_section = ""
    if business_context:
        business_context_section = (
            f"\nDeployment process context for this project:\n{business_context}\n"
        )

    site_rows_section = ""
    if site_rows:
        col_keys = list(site_rows[0].keys())
        header = " | ".join(col_keys)
        rows_text = "\n".join(
            " | ".join(str(row.get(k, ""))[:150] for k in col_keys)
            for row in site_rows
        )
        site_rows_section = (
            f"\nSite-level data ({len(site_rows)} active sites — already filtered by KPI condition):\n"
            f"{header}\n{rows_text}\n"
        )

    n_areas = len(area_findings)
    n_markets = len(market_findings)
    area_names = ", ".join(f"{f.geo_name} Area" for f in area_findings) if area_findings else None
    market_names = ", ".join(f"{f.geo_name} Market" for f in market_findings) if market_findings else None
    sites_clause = f", {impacted_sites_count} sites at risk" if impacted_sites_count else ""

    user = (
        f"KPI: {finding.kpi_name}{kpi_context}\n"
        f"Region: {finding.geo_name}\n"
        f"Flagged areas ({n_areas}): {area_names or 'none'}\n"
        f"Flagged markets ({n_markets}): {market_names or 'none'}\n"
        + (f"Impacted sites: {impacted_sites_count}\n" if impacted_sites_count else "")
        + f"Trend summary: {finding.trend_summary}\n"
        f"Recent values (newest first): {recent or 'not available'}\n\n"
        f"{area_section}\n\n"
        f"{market_section}"
        f"{site_rows_section}"
        f"{comment_section}"
        f"{business_context_section}\n"
        "Investigate this KPI anomaly and return a JSON object with exactly these keys:\n"
        "{\n"
        '  "risk_label": "<concise forward-looking label — STRICT rules: '
        f"(1) MAX 50 WORDS. (2) Pattern: '<KPI issue> in {finding.geo_name} Region — "
        f"{n_areas} area(s), {n_markets} market(s) <consequence if trend continues>'. "
        "(3) The consequence must state what will happen if the current trend is not corrected — "
        "e.g. 'projected to breach hard threshold', 'at risk of sustained SLA miss', 'trending toward critical threshold'. "
        "Keep it to one short clause (5-8 words). "
        "(4) DO NOT list area or market names — counts only. "
        "(5) DO NOT mention sites or site count. "
        "(6) NEVER write a phase number ('Phase 5', 'Phase 8', etc.) — phase name only if it adds context. "
        "(7) NEVER use generic phrasing like 'Anomalous X trend in Y'. "
        "Example: 'NTP Acceptance declining in Central Region — 4 areas, 20 markets at risk of sustained SLA breach if trend continues'"
        '>",\n'
        '  "root_cause": "<2-4 sentences. Start by naming the deployment phase (e.g. \'Phase 6 material pickup\' '
        "or 'NTP acceptance') to anchor the lifecycle context. If PM/GC comments are available, "
        "quote them directly and explain the operational issue they reveal. "
        "Otherwise derive from the trend data. Include the phase name naturally — only add the "
        'phase number when it helps distinguish from adjacent phases.>",\n'
        '  "likelihood": "unlikely | may_happen | likely",\n'
        '  "impact": "minor | major | critical",\n'
        '  "confidence": <0.0-1.0 — calibrate per the rules above>,\n'
        '  "mitigation_actions": ["<concrete PM-ownable action that references the phase activity '
        "(e.g. 'Escalate Phase 6 material pickup delays with warehouse team') — "
        "include phase name when it clarifies which workflow step to act on; "
        'skip the phase reference if the action is self-evident without it.>", ...],\n'
        '  "recovery_plan": ["<ordered recovery step — include phase name or number when the step '
        "involves a specific phase milestone or when sequencing between phases matters "
        "(e.g. 'Confirm Phase 6 material pickup complete before mobilising Phase 8 tower crew'); "
        'omit if adding it would be redundant.>", ...]\n'
        "}\n"
        "Note: impact values — minor(≤5% of eligible sites), major(6–9%), critical(≥10%). "
        "The system will override your impact value from site counts when available; "
        "provide your best estimate as a fallback."
    )
    return _INVESTIGATION_SYSTEM, user


_MAX_CELL_CHARS = 300  # truncate long text (e.g. full comment histories) per cell


def build_drilldown_step_prompt(
    finding: TrendFinding,
    step: StepResult,
) -> tuple[str, str]:
    """Build a prompt for ONE site step (one market's rows) → returns a single table object.

    Token budget: 200 rows × ~10 cols × 300 chars ≈ 150k tokens — well within context limits.
    The caller runs one of these per step in parallel and assembles the table list.
    """
    rows = step.rows
    col_keys = list(rows[0].keys()) if rows else []
    comment_keys = [
        k for k in col_keys
        if k in COMMENT_COLUMNS
        or any(kw in k.lower() for kw in ("comment", "remark", "note", "reason", "history"))
    ]
    other_keys = [k for k in col_keys if k not in comment_keys]
    ordered_keys = comment_keys + other_keys

    header = " | ".join(ordered_keys)
    row_lines = [
        " | ".join(str(row.get(k, ""))[:_MAX_CELL_CHARS] for k in ordered_keys)
        for row in rows
    ]
    rows_text = f"{header}\n" + "\n".join(row_lines)

    system = (
        "You are building one evidence table for a PM risk report dashboard.\n"
        "You receive site-level rows for one market contributing to a KPI anomaly.\n\n"
        "Select ONLY the columns that make the risk evidence visible:\n"
        "  • Site identifiers: site_id, site_name, gc_name, market_name\n"
        "  • KPI metric columns showing the anomaly (value, rate, count, gap, percentage)\n"
        "  • Date/period columns establishing timing\n"
        "  • Status or delay-code columns\n"
        "  • Comment/remark/notes columns — HIGH PRIORITY, always include if present:\n"
        "      pj_construction_start_delay_comments, pj_construction_complete_delay_comments,\n"
        "      pj_on_air_delay_code_comments, pj_project_comment_history, wp_notes,\n"
        "      site_remarks_from_pm_tracker, or any column containing: comment, remark, note, reason, history\n"
        "Omit internal IDs and columns unrelated to this specific KPI issue.\n\n"
        "Return ONE JSON object (not an array):\n"
        '{ "title": "short descriptive title", "columns": ["col1", ...], "rows": [[v1, ...], ...], "source": "site" }\n'
        "No markdown, no commentary outside the JSON object."
    )
    user = (
        f"KPI: {finding.kpi_name}\n"
        f"Region: {finding.geo_name}\n"
        f"Issue: {finding.trend_summary}\n"
        f"Step: {step.step_name} "
        f"({step.row_count} rows; comment columns first, values truncated to {_MAX_CELL_CHARS} chars)\n\n"
        f"{rows_text}\n\n"
        "Return a single JSON table object for these site rows."
    )
    return system, user


def build_synthesis_prompt(
    region_findings: list[TrendFinding],
    area_findings: list[TrendFinding],
    market_findings: list[TrendFinding],
    site_row_counts: dict[str, int],
) -> tuple[str, str]:
    system = (
        "You are a telecom risk analyst. Summarize a hierarchical KPI analysis "
        "into a concise narrative for a risk report. Highlight the most impactful issues, "
        "their geographic spread, and recommended actions. Keep it under 200 words."
    )
    user = (
        f"Flagged regions: {len(region_findings)} — "
        + ", ".join(f"{f.geo_name}/{f.kpi_name}" for f in region_findings[:5])
        + ("\n..." if len(region_findings) > 5 else "")
        + f"\n\nFlagged areas: {len(area_findings)}"
        + f"\nFlagged markets: {len(market_findings)}"
        + f"\nSite queries run: {len(site_row_counts)} "
        + f"(total sites affected: {sum(site_row_counts.values())})\n\n"
        "Write a concise narrative summary for this KPI trend analysis report."
    )
    return system, user
