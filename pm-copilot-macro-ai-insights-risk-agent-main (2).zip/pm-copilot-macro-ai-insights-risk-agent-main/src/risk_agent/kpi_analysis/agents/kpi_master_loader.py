"""Load all KPI master records from tmo_macro_kpi_master_details."""

from __future__ import annotations

import asyncio
import re as _re

from risk_agent.config import get_settings
from risk_agent.db.pool import fetch_all
from risk_agent.kpi_analysis.business_context import PROJECT_BUSINESS_CONTEXTS, get_column_phase_map
from risk_agent.kpi_analysis.models import KPIMaster
from risk_agent.kpi_analysis.state import KPIAnalysisState
from risk_agent.models.domain import SemanticResponse
from risk_agent.semantic import SemanticClient
from risk_agent.utils.logging import get_logger

logger = get_logger(__name__)

_TABLE = "tmo_macro_kpi_master_details"


def _format_keywords_for_kpi(response: SemanticResponse) -> str:
    """Format semantic keyword hits into a compact domain-glossary block."""
    if not response.results:
        return "(no domain keyword definitions available)"
    lines = ["Domain keyword definitions relevant to these KPIs:"]
    for hit in response.results:
        c = hit.content

        def _get(*names: str) -> str | None:
            for n in names:
                v = getattr(c, n, None)
                if v:
                    return str(v)
            return None

        term = _get("keyword", "term", "name") or "?"
        desc = _get("description", "definition") or ""
        logic = _get("logic", "computation_logic", "rule") or ""
        cols = _get("mapped_columns", "columns") or ""
        synonyms = _get("synonyms", "domain_synonyms", "aliases") or ""

        line = f"  • {term}"
        if desc:
            line += f": {desc}"
        if logic:
            line += f" | rule: {logic}"
        if cols:
            line += f" | columns: {cols}"
        if synonyms:
            line += f" | also known as: {synonyms}"
        lines.append(line)
    return "\n".join(lines)


def _format_question_bank(response: SemanticResponse) -> str:
    """Format question bank hits into a compact reference SQL block for the site analyzer."""
    if not response.results:
        return "(no reference SQL patterns available)"
    lines = ["Reference SQL patterns from the question bank (use as inspiration for query structure):"]
    for hit in response.results:
        c = hit.content

        def _get(*names: str) -> str | None:
            for n in names:
                v = getattr(c, n, None)
                if v:
                    return str(v)
            return None

        question = _get("question", "nlq", "description", "name") or "?"
        sql = _get("sql", "query", "sql_query") or ""
        lines.append(f"\n  Q: {question}")
        if sql:
            sql_preview = sql.strip().replace("\n", " ")[:500]
            lines.append(f"  SQL: {sql_preview}")
    return "\n".join(lines)


async def _fetch_kpi_question_bank(masters: list[KPIMaster]) -> str:
    """Query the question_bank semantic table using KPI names as the search query.

    Returns a formatted prompt block containing reference SQL patterns that the
    site SQL generator can use as inspiration for structuring its queries.
    """
    if not masters:
        return "(no KPIs loaded)"

    query = " ".join(m.kpi_name for m in masters[:50])
    try:
        async with SemanticClient() as client:
            response = await client.search(query, top_k=10, table="question_bank")
        logger.info("kpi.master_loader.question_bank.done", hits=response.total_results)
        return _format_question_bank(response)
    except Exception as exc:
        logger.warning("kpi.master_loader.question_bank.failed", error=str(exc))
        return "(question bank lookup unavailable)"


async def _fetch_kpi_keywords(masters: list[KPIMaster]) -> str:
    """Call the semantic keywords endpoint with KPI names + descriptions.

    Builds a single combined query from all KPI names and descriptions so the
    keywords table can surface domain term definitions that help the LLM
    interpret ambiguous KPI descriptions (e.g. 'FTR', 'WIP', 'NTP ratio').
    Returns a formatted prompt block, or a fallback string on failure.
    """
    if not masters:
        return "(no KPIs loaded)"

    # Build a combined query — include kpi_name and description for richer matching
    query_parts: list[str] = []
    for m in masters:
        query_parts.append(m.kpi_name)
        if m.description:
            query_parts.append(m.description)
    query = " ".join(query_parts[:500])  # cap to avoid overly long queries

    try:
        async with SemanticClient() as client:
            response = await client.search_keywords(query)
        logger.info("kpi.master_loader.keywords_enrichment.done", hits=response.total_results)
        return _format_keywords_for_kpi(response)
    except Exception as exc:
        logger.warning("kpi.master_loader.keywords_enrichment.failed", error=str(exc))
        return "(domain keyword lookup unavailable)"


def _to_float(v: object) -> float | None:
    try:
        return float(v) if v is not None else None
    except (TypeError, ValueError):
        return None


def _row_to_master(row: dict, columns: list[dict]) -> KPIMaster | None:
    """Map a DB row to KPIMaster. Returns None if the row has no usable name."""
    col_names = {c["column_name"] for c in columns}

    def get(field: str) -> str | None:
        return row.get(field) if field in col_names else None

    kpi_name = row.get("kpi_name") or row.get("name")
    if not kpi_name:
        return None

    return KPIMaster(
        id=row.get("id"),
        kpi_name=str(kpi_name).strip(),
        description=get("description"),
        formula=get("formula"),
        logic=get("logic"),
        national_sql=get("national"),
        region_sql=get("region"),
        area_sql=get("area"),
        market_sql=get("market"),
        project=get("project_name"),
        sla=_to_float(get("sla")),
        threshold=_to_float(get("threshold")),
        disturbing_trend=get("disturbing_trend"),
    )


async def load_kpi_master_node(state: KPIAnalysisState) -> dict:
    kpi_schema = get_settings().agent.kpi_table_schema
    columns = state.get("table_schemas", {}).get(_TABLE, [])

    logger.info("kpi.master_loader.start", table=_TABLE, columns=len(columns))

    try:
        rows = await fetch_all(
            f'SELECT * FROM "{kpi_schema}"."{_TABLE}"',  # noqa: S608
            {},
        )
    except Exception as exc:
        logger.error("kpi.master_loader.failed", error=str(exc))
        return {"kpi_masters": [], "errors": [f"KPI master load failed: {exc}"]}

    masters: list[KPIMaster] = []
    skipped = 0
    for r in rows:
        m = _row_to_master(r, columns)
        if m is None:
            skipped += 1
        else:
            masters.append(m)
    logger.info("kpi.master_loader.done", count=len(masters), skipped=skipped)

    # Derive deployment phase for each KPI from its SQL column references.
    # Scans region/area/market SQL for pj_*/ms_*/scop_* column patterns and
    # maps them to phases via the business context; most-referenced phase wins.
    _col_pattern = _re.compile(r'\b(pj_[a-z0-9_]+|ms_[a-z0-9_]+|scop_[a-z0-9_]+)\b')
    for m in masters:
        if not m.project:
            continue
        phase_map = get_column_phase_map(m.project)
        if not phase_map:
            continue
        sql_blob = " ".join(filter(None, [m.region_sql, m.area_sql, m.market_sql, m.national_sql]))
        phase_hits: dict[str, int] = {}
        for col in _col_pattern.findall(sql_blob):
            if col in phase_map:
                phase_hits[phase_map[col]] = phase_hits.get(phase_map[col], 0) + 1
        if phase_hits:
            m.phase = max(phase_hits, key=lambda k: phase_hits[k])

    # Fetch both keyword definitions and question bank patterns concurrently.
    kpi_keywords_context, kpi_question_bank_context = await asyncio.gather(
        _fetch_kpi_keywords(masters),
        _fetch_kpi_question_bank(masters),
    )

    return {
        "kpi_masters": masters,
        "kpi_keywords_context": kpi_keywords_context,
        "kpi_question_bank_context": kpi_question_bank_context,
        "project_business_contexts": PROJECT_BUSINESS_CONTEXTS,
    }
