"""Market-level KPI drill-down node.

Only runs for areas flagged by analyze_area_node.
"""

from __future__ import annotations

import asyncio

from langchain_core.messages import HumanMessage, SystemMessage

from risk_agent.config import get_settings
from risk_agent.core.llm import build_llm
from risk_agent.db.pool import fetch_all
from risk_agent.kpi_analysis.agents.region_analyzer import _parse_findings
from risk_agent.kpi_analysis.models import GeoLevel, KPIMaster, TrendFinding
from risk_agent.kpi_analysis.prompts import build_market_prompts
from risk_agent.kpi_analysis.state import KPIAnalysisState
from risk_agent.utils.logging import get_logger

logger = get_logger(__name__)

_TABLE = "tmo_macro_kpi_market_output_details_trial"
_MASTER_TABLE = "tmo_macro_kpi_master_details"
_HISTORY_POINTS = 12


async def _analyze_one_area(
    kpi_schema: str,
    area_name: str,
    flagged_kpi_ids: list[int],
    flagged_kpi_names: list[str],
    kpi_masters: list[KPIMaster],
    trend_months: int,
    kpi_keywords_context: str | None = None,
    project_business_contexts: dict[str, str] | None = None,
    parent_findings: list[TrendFinding] | None = None,
) -> list[TrendFinding]:
    if not flagged_kpi_ids:
        return []

    kpi_ids_csv = ",".join(str(int(x)) for x in flagged_kpi_ids)

    sql = f"""
        WITH ranked AS (
          SELECT
            m.kpi_name,
            UPPER(TRIM(mk.region_name)) AS region_name,
            UPPER(TRIM(mk.area_name))   AS area_name,
            UPPER(TRIM(mk.market_name)) AS market_name,
            CASE
              WHEN TRIM(mk.result) ~ '^-?[0-9]+(\\.[0-9]+)?$'
              THEN TRIM(mk.result)::numeric
              ELSE NULL
            END AS value,
            mk.result_date_time,
            ROW_NUMBER() OVER (
              PARTITION BY mk.kpi_id, UPPER(TRIM(mk.market_name))
              ORDER BY mk.result_date_time DESC
            ) AS rn
          FROM "{kpi_schema}"."{_TABLE}" mk
          JOIN "{kpi_schema}"."{_MASTER_TABLE}" m ON m.id = mk.kpi_id
          WHERE mk.kpi_id IN ({kpi_ids_csv})
            AND mk.result_date_time IS NOT NULL
            AND mk.market_name IS NOT NULL
            AND UPPER(TRIM(mk.area_name)) = UPPER(TRIM(:area_name))
            AND mk.result_date_time >= NOW() - INTERVAL '{trend_months} months'
        )
        SELECT kpi_name, region_name, area_name, market_name, value, result_date_time
        FROM ranked
        WHERE rn <= {_HISTORY_POINTS} AND value IS NOT NULL
        ORDER BY kpi_name, market_name, result_date_time DESC
    """  # noqa: S608

    try:
        rows = await fetch_all(sql, {"area_name": area_name})
    except Exception as exc:
        logger.warning("kpi.market_analyzer.query_failed", area=area_name, error=str(exc))
        return []

    if not rows:
        logger.info("kpi.market_analyzer.no_rows", area=area_name)
        return []

    system_prompt, user_prompt = build_market_prompts(
        kpi_masters, rows, area_name.strip().upper(), flagged_kpi_names,
        kpi_keywords_context, project_business_contexts,
        parent_findings=parent_findings,
    )
    try:
        llm = build_llm(role="planner")
        response = await llm.ainvoke([
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt),
        ])
        raw = response.content if hasattr(response, "content") else str(response)
    except Exception as exc:
        logger.warning("kpi.market_analyzer.llm_failed", area=area_name, error=str(exc))
        return []

    return _parse_findings(raw, GeoLevel.MARKET)


async def analyze_market_node(state: KPIAnalysisState) -> dict:
    area_findings: list[TrendFinding] = state.get("area_findings", [])
    if not area_findings:
        logger.info("kpi.market_analyzer.skipped", reason="no flagged areas")
        return {"market_findings": []}

    settings = get_settings().agent
    kpi_schema = settings.kpi_table_schema
    trend_months = settings.kpi_trend_months
    kpi_masters: list[KPIMaster] = state.get("kpi_masters", [])
    kpi_keywords_context: str | None = state.get("kpi_keywords_context")
    project_business_contexts: dict[str, str] = state.get("project_business_contexts", {})
    name_to_id = {m.kpi_name: m.id for m in kpi_masters if m.id is not None}

    area_kpi_ids: dict[str, list[int]] = {}
    area_kpi_names: dict[str, list[str]] = {}
    unresolved: list[str] = []
    for f in area_findings:
        kpi_id = name_to_id.get(f.kpi_name)
        if kpi_id is None:
            unresolved.append(f.kpi_name)
            continue
        area_kpi_ids.setdefault(f.geo_name, []).append(kpi_id)
        area_kpi_names.setdefault(f.geo_name, []).append(f.kpi_name)

    if unresolved:
        logger.warning("kpi.market_analyzer.unresolved_kpis", unresolved=unresolved[:10])

    if not area_kpi_ids:
        logger.info("kpi.market_analyzer.no_resolvable_kpis")
        return {"market_findings": []}

    logger.info("kpi.market_analyzer.start", areas=list(area_kpi_ids.keys()), trend_months=trend_months)

    # Build per-area parent findings map for context passing
    area_findings_map: dict[str, list[TrendFinding]] = {}
    for f in area_findings:
        area_findings_map.setdefault(f.geo_name, []).append(f)

    tasks = [
        _analyze_one_area(
            kpi_schema,
            area,
            area_kpi_ids[area],
            area_kpi_names[area],
            kpi_masters,
            trend_months,
            kpi_keywords_context,
            project_business_contexts or None,
            parent_findings=area_findings_map.get(area),
        )
        for area in area_kpi_ids
    ]
    results = await asyncio.gather(*tasks)
    market_findings = [f for group in results for f in group]

    logger.info("kpi.market_analyzer.done", anomalous=len(market_findings))
    return {"market_findings": market_findings}
