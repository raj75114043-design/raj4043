"""Synthesize all hierarchical findings into a standard RiskReport.

Converts TrendFinding (internal) → RiskFinding (shared domain model)
so the output is identical in shape to the Excel pipeline's output.
"""

from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime

from langchain_core.messages import HumanMessage, SystemMessage

from risk_agent.config import get_settings
from risk_agent.core.llm import build_llm
from risk_agent.kpi_analysis.models import KPIMaster, TrendFinding
from risk_agent.kpi_analysis.prompts import (
    COMMENT_COLUMNS,
    build_investigation_prompt,
    build_synthesis_prompt,
)
from risk_agent.kpi_analysis.state import KPIAnalysisState
from risk_agent.models.domain import (
    RiskCategory,
    RiskEvidence,
    RiskFinding,
    RiskImpact,
    RiskLikelihood,
    RiskRating,
    RiskReport,
    RiskSeverity,
    StepResult,
    StepSource,
    StepStatus,
)
from risk_agent.utils.logging import get_logger
from risk_agent.utils.risk_assessment import calculate_risk_rating

logger = get_logger(__name__)

_llm_sem: asyncio.Semaphore | None = None


def _get_sem() -> asyncio.Semaphore:
    """Return the shared LLM concurrency semaphore, creating it on first call."""
    global _llm_sem
    if _llm_sem is None:
        limit = get_settings().agent.kpi_max_concurrent_llm_calls
        _llm_sem = asyncio.Semaphore(limit)
        logger.info("kpi.synthesizer.semaphore_created", limit=limit)
    return _llm_sem


@dataclass
class _InvestigationResult:
    risk_label: str = ""
    root_cause: str = ""
    likelihood: str = "may_happen"
    impact: str = "medium"
    confidence: float = 0.7
    mitigation_actions: list[str] = field(default_factory=list)
    recovery_plan: list[str] = field(default_factory=list)


_KPI_CATEGORY = RiskCategory(
    category_id="KPI_TREND_ANALYSIS",
    name="KPI Trend Analysis",
    description="Hierarchical KPI trend analysis across Region → Area → Market → Site",
    identification_logic="Detect anomalous KPI trends at region level and drill down",
)


def _norm(s: str | None) -> str:
    """Normalize geography / KPI name strings for comparison.

    Real data has casing inconsistencies — region appears as 'SOUTH', 'South',
    and 'south' across the three output tables — so all string comparisons
    in the synthesizer must go through this normalizer.
    """
    return (s or "").strip().upper()


def _severity_from_rating(rating: RiskRating) -> RiskSeverity:
    return {
        RiskRating.CRITICAL: RiskSeverity.CRITICAL,
        RiskRating.HIGH: RiskSeverity.HIGH,
        RiskRating.MEDIUM: RiskSeverity.MEDIUM,
        RiskRating.LOW: RiskSeverity.LOW,
    }.get(rating, RiskSeverity.MEDIUM)


def _build_drill_down_tables(
    region_f: TrendFinding,
    area_findings: list[TrendFinding],
    market_findings: list[TrendFinding],
    site_results: list[StepResult],
) -> list[dict]:
    """Build drill_down_tables for one region-KPI finding."""
    tables = []

    # Region-level trend — always included so every finding has at least one table
    if region_f.recent_values:
        rv_keys = list(region_f.recent_values[0].keys()) if region_f.recent_values else []
        if rv_keys:
            tables.append({
                "title": f"Region Trend — {region_f.kpi_name} ({region_f.geo_name})",
                "columns": rv_keys,
                "rows": [[str(rv.get(k, "")) for k in rv_keys] for rv in region_f.recent_values],
            })

    # Area sub-findings for this region+KPI
    area_rows = [
        {"area": f.geo_name, "kpi": f.kpi_name, "summary": f.trend_summary}
        for f in area_findings
        if _norm(f.parent_geo) == _norm(region_f.geo_name)
        and _norm(f.kpi_name) == _norm(region_f.kpi_name)
    ]
    if area_rows:
        tables.append({
            "title": f"Flagged Areas in {region_f.geo_name}",
            "columns": ["area", "kpi", "summary"],
            "rows": [[r["area"], r["kpi"], r["summary"]] for r in area_rows],
        })

    # Market sub-findings for the areas above
    area_names_norm = {_norm(r["area"]) for r in area_rows}
    market_rows = [
        {"market": f.geo_name, "area": f.parent_geo, "kpi": f.kpi_name, "summary": f.trend_summary}
        for f in market_findings
        if _norm(f.parent_geo) in area_names_norm
        and _norm(f.kpi_name) == _norm(region_f.kpi_name)
    ]
    if market_rows:
        tables.append({
            "title": f"Flagged Markets",
            "columns": ["market", "area", "kpi", "summary"],
            "rows": [[r["market"], r["area"], r["kpi"], r["summary"]] for r in market_rows],
        })

    # Site query results for these markets — exclude completed sites
    market_names = {r["market"] for r in market_rows}  # noqa: F841 — kept for future per-market filter
    for sr in site_results:
        if sr.status == StepStatus.SUCCESS and _norm(sr.related_kpi) == _norm(region_f.kpi_name):
            active_rows = [
                row for row in (sr.rows or [])
                if not str(row.get("pj_project_status", "")).strip().lower().startswith("complet")
            ]
            if active_rows:
                col_keys = list(active_rows[0].keys())
                tables.append({
                    "title": f"Site Detail — {sr.step_name}",
                    "columns": col_keys,
                    "rows": [[str(row.get(k, "")) for k in col_keys] for row in active_rows[:50]],
                    "source_step_id": str(sr.step_id),
                })

    return tables


def _extract_comment_snippets(finding: TrendFinding, site_results: list[StepResult]) -> list[str]:
    """Pull non-empty comment/narrative column values from site query rows for this KPI."""
    snippets: list[str] = []
    for sr in site_results:
        if sr.status != StepStatus.SUCCESS or _norm(sr.related_kpi) != _norm(finding.kpi_name):
            continue
        for row in (sr.rows or [])[:15]:
            for col in COMMENT_COLUMNS:
                val = row.get(col)
                if val and str(val).strip():
                    snippets.append(f"[{col}] {str(val).strip()[:250]}")
            # Also capture any ad-hoc comment-like columns not in the fixed list
            for col, val in row.items():
                if col in COMMENT_COLUMNS:
                    continue
                col_lower = col.lower()
                if any(k in col_lower for k in ("comment", "remark", "note", "reason", "history")):
                    if val and str(val).strip():
                        snippets.append(f"[{col}] {str(val).strip()[:250]}")
    return snippets[:20]  # cap to keep prompt size manageable


def _filter_for_finding(
    finding: TrendFinding,
    area_findings: list[TrendFinding],
    market_findings: list[TrendFinding],
    site_results: list[StepResult],
) -> tuple[list[TrendFinding], list[TrendFinding], list[StepResult]]:
    """Return area findings, market findings, and site results relevant to one region+KPI."""
    relevant_areas = [
        f for f in area_findings
        if _norm(f.parent_geo) == _norm(finding.geo_name)
        and _norm(f.kpi_name) == _norm(finding.kpi_name)
    ]
    relevant_area_names_norm = {_norm(a.geo_name) for a in relevant_areas}
    relevant_markets = [
        f for f in market_findings
        if _norm(f.kpi_name) == _norm(finding.kpi_name)
        and _norm(f.parent_geo) in relevant_area_names_norm
    ]
    relevant_sites = [
        sr for sr in site_results
        if sr.status == StepStatus.SUCCESS and _norm(sr.related_kpi) == _norm(finding.kpi_name)
    ]
    return relevant_areas, relevant_markets, relevant_sites


async def _investigate(
    finding: TrendFinding,
    area_findings: list[TrendFinding],
    market_findings: list[TrendFinding],
    kpi_masters: list[KPIMaster],
    site_results: list[StepResult],
    project_business_contexts: dict[str, str] | None = None,
) -> _InvestigationResult:
    """Call LLM #1: risk analysis from area/market summaries + site rows + comment snippets."""
    kpi_master = next((m for m in kpi_masters if _norm(m.kpi_name) == _norm(finding.kpi_name)), None)
    relevant_areas, relevant_markets, relevant_sites = _filter_for_finding(
        finding, area_findings, market_findings, site_results
    )
    comment_snippets = _extract_comment_snippets(finding, relevant_sites)
    site_count = sum(sr.row_count for sr in relevant_sites if sr.status == StepStatus.SUCCESS) or None

    # Collect active site rows — SQL already filtered for problematic sites; exclude completed only
    site_rows: list[dict] = []
    for sr in relevant_sites:
        if sr.status == StepStatus.SUCCESS:
            for row in (sr.rows or []):
                if not str(row.get("pj_project_status", "")).strip().lower().startswith("complet"):
                    site_rows.append(row)
                    if len(site_rows) >= 50:
                        break
        if len(site_rows) >= 50:
            break

    business_context: str | None = None
    if project_business_contexts and kpi_master and kpi_master.project:
        business_context = project_business_contexts.get(kpi_master.project) or None

    sys_p, usr_p = build_investigation_prompt(
        finding, relevant_areas, relevant_markets, kpi_master,
        comment_snippets=comment_snippets or None,
        business_context=business_context,
        impacted_sites_count=site_count,
        site_rows=site_rows or None,
    )
    try:
        llm = build_llm(role="generator")
        async with _get_sem():
            response = await llm.ainvoke([SystemMessage(content=sys_p), HumanMessage(content=usr_p)])
        raw = response.content if hasattr(response, "content") else str(response)
        cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw.strip(), flags=re.IGNORECASE | re.MULTILINE)
        data = json.loads(cleaned)
        return _InvestigationResult(
            risk_label=data.get("risk_label", ""),
            root_cause=data.get("root_cause", ""),
            likelihood=str(data.get("likelihood", "may_happen")).lower(),
            impact=str(data.get("impact", "major")).lower(),
            confidence=max(0.0, min(1.0, float(data.get("confidence", 0.7)))),
            mitigation_actions=data.get("mitigation_actions", []),
            recovery_plan=data.get("recovery_plan", []),
        )
    except Exception as exc:
        logger.warning("kpi.synthesizer.investigate_failed", kpi=finding.kpi_name, error=str(exc))
        return _InvestigationResult()



def _region_finding_to_risk_finding(
    region_f: TrendFinding,
    area_findings: list[TrendFinding],
    market_findings: list[TrendFinding],
    site_results: list[StepResult],
    result: _InvestigationResult,
    kpi_project_map: dict[str, str] | None = None,
) -> RiskFinding:
    affected_areas = [
        f for f in area_findings
        if _norm(f.parent_geo) == _norm(region_f.geo_name)
        and _norm(f.kpi_name) == _norm(region_f.kpi_name)
    ]
    affected_area_names_norm = {_norm(a.geo_name) for a in affected_areas}
    affected_markets = [
        f for f in market_findings
        if _norm(f.kpi_name) == _norm(region_f.kpi_name)
        and _norm(f.parent_geo) in affected_area_names_norm
    ]
    n_markets = len(affected_markets)

    risk_label = result.risk_label or (
        f"{region_f.kpi_name} degradation in {region_f.geo_name}"
        + (f" — {n_markets} market(s) affected" if n_markets else "")
    )

    # Use LLM-assigned likelihood with safe enum fallback
    try:
        likelihood = RiskLikelihood(result.likelihood)
    except ValueError:
        likelihood = RiskLikelihood.MAY_HAPPEN

    relevant_site_results = [
        sr for sr in site_results
        if _norm(sr.related_kpi) == _norm(region_f.kpi_name)
    ]
    site_evidence = [
        RiskEvidence(
            step_id=sr.step_id,
            step_name=sr.step_name,
            source=StepSource.SEMANTIC_KPI,
            sample_rows=sr.rows[:5] if sr.status == StepStatus.SUCCESS else [],
            row_count=sr.row_count if sr.status == StepStatus.SUCCESS else 0,
            related_kpi=sr.related_kpi,
        )
        for sr in relevant_site_results
    ]
    impacted_sites_count = sum(
        sr.row_count for sr in relevant_site_results if sr.status == StepStatus.SUCCESS
    ) or None

    # Compute impact deterministically from site count percentage
    # Minor (≤5%), Major (6–9%), Critical (≥10%)
    total_eligible = sum(
        sr.total_eligible_count for sr in relevant_site_results
        if sr.status == StepStatus.SUCCESS and sr.total_eligible_count
    ) or None
    if impacted_sites_count and total_eligible:
        pct = impacted_sites_count / total_eligible * 100
        if pct <= 5:
            impact = RiskImpact.LOW
        elif pct <= 9:
            impact = RiskImpact.MEDIUM
        else:
            impact = RiskImpact.HIGH
        logger.info(
            "kpi.synthesizer.impact_computed",
            kpi=region_f.kpi_name, geo=region_f.geo_name,
            impacted=impacted_sites_count, total=total_eligible,
            pct=round(pct, 1), impact=impact.value,
        )
    else:
        try:
            impact = RiskImpact(result.impact)
        except ValueError:
            impact = RiskImpact.MEDIUM

    risk_rating = calculate_risk_rating(likelihood, impact)
    severity = _severity_from_rating(risk_rating)

    drill_down = _build_drill_down_tables(region_f, area_findings, market_findings, site_results)

    return RiskFinding(
        category_id=region_f.risk_category or "KPI Trend Analysis",
        risk=risk_label,
        title=risk_label,
        region=region_f.geo_name,
        description=region_f.trend_summary,
        root_cause=result.root_cause or (
            f"KPI '{region_f.kpi_name}' shows anomalous trend at region level "
            f"({region_f.geo_name}), propagating to {len(affected_areas)} area(s) "
            f"and {n_markets} market(s)."
        ),
        mitigation_actions=result.mitigation_actions or [
            f"Investigate root cause for {region_f.kpi_name} in {region_f.geo_name}",
            "Review site-level data for specific underperforming sites",
            "Escalate to regional network operations team",
        ],
        recovery_plan=result.recovery_plan or [
            "Identify and remediate the top-3 worst-performing sites",
            "Monitor KPI trend weekly until trend reverses",
            "Post-incident review after stabilisation",
        ],
        drill_down_tables=drill_down,
        evidence=site_evidence,
        severity=severity,
        likelihood=likelihood,
        impact=impact,
        risk_rating=risk_rating,
        confidence=result.confidence,
        project=(kpi_project_map or {}).get(region_f.kpi_name),
        impacted_sites_count=impacted_sites_count,
        area_tags=[f.geo_name for f in affected_areas],
        market_tags=[f.geo_name for f in affected_markets],
    )


async def synthesize_report_node(state: KPIAnalysisState) -> dict:
    region_findings: list[TrendFinding] = state.get("region_findings", [])
    area_findings: list[TrendFinding] = state.get("area_findings", [])
    market_findings: list[TrendFinding] = state.get("market_findings", [])
    site_results: list[StepResult] = state.get("site_step_results", [])
    kpi_masters: list[KPIMaster] = state.get("kpi_masters", [])
    project_business_contexts: dict[str, str] = state.get("project_business_contexts", {})
    errors: list[str] = state.get("errors", [])

    started_at = datetime.now(UTC)
    logger.info(
        "kpi.synthesizer.start",
        regions=len(region_findings),
        areas=len(area_findings),
        markets=len(market_findings),
        site_queries=len(site_results),
    )

    # One LLM call per region finding — risk analysis from area/market summaries + comment snippets.
    # Drill-down tables are built in code (no LLM), so only investigations run concurrently here.
    investigations: list[_InvestigationResult] = list(await asyncio.gather(*[
        _investigate(rf, area_findings, market_findings, kpi_masters, site_results, project_business_contexts or None)
        for rf in region_findings
    ]))

    kpi_project_map: dict[str, str] = {m.kpi_name: m.project for m in kpi_masters if m.project}
    risk_findings = [
        _region_finding_to_risk_finding(
            rf, area_findings, market_findings, site_results, inv, kpi_project_map
        )
        for rf, inv in zip(region_findings, investigations)
    ]

    # LLM narrative summary
    summary = ""
    try:
        site_row_counts = {sr.step_name: sr.row_count for sr in site_results if sr.status == StepStatus.SUCCESS}
        sys_p, usr_p = build_synthesis_prompt(region_findings, area_findings, market_findings, site_row_counts)
        llm = build_llm(role="generator")
        response = await llm.ainvoke([SystemMessage(content=sys_p), HumanMessage(content=usr_p)])
        summary = response.content if hasattr(response, "content") else str(response)
    except Exception as exc:
        logger.warning("kpi.synthesizer.summary_failed", error=str(exc))
        summary = f"KPI trend analysis found {len(risk_findings)} anomalous region-KPI combinations."

    finished_at = datetime.now(UTC)
    report = RiskReport(
        category=_KPI_CATEGORY,
        findings=risk_findings,
        steps_planned=len(region_findings) + len(area_findings) + len(market_findings),
        steps_succeeded=len([sr for sr in site_results if sr.status == StepStatus.SUCCESS]),
        steps_failed=len([sr for sr in site_results if sr.status == StepStatus.FAILED]),
        total_rows_examined=sum(sr.row_count for sr in site_results),
        started_at=started_at,
        finished_at=finished_at,
        duration_ms=(finished_at - started_at).total_seconds() * 1000,
        summary=summary,
    )

    logger.info("kpi.synthesizer.done", findings=len(risk_findings), errors=len(errors))
    return {"report": report}
