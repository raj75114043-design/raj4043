"""Introspect all KPI tables in parallel and store column lists in state."""

from __future__ import annotations

import asyncio
from typing import Any

from risk_agent.config import get_settings
from risk_agent.db.schema import load_table_schema
from risk_agent.kpi_analysis.state import KPIAnalysisState
from risk_agent.utils.logging import get_logger

logger = get_logger(__name__)

# KPI tables all live in KPI_TABLE_SCHEMA (default: public)
_KPI_TABLES = [
    "tmo_macro_kpi_master_details",
    "tmo_macro_kpi_region_output_details_trial",
    "tmo_macro_kpi_area_output_details_trial",
    "tmo_macro_kpi_market_output_details_trial",
]


async def _safe_introspect(schema: str, table: str) -> tuple[str, list[dict[str, Any]]]:
    """Introspect one table; return empty list on error so other tables continue."""
    try:
        t = await load_table_schema(schema, table)
        cols = [
            {
                "column_name": c.name,
                "data_type": c.data_type,
                "is_nullable": c.is_nullable,
            }
            for c in t.columns
        ]
        logger.info("kpi.schema_loader.ok", table=table, columns=len(cols))
        return table, cols
    except Exception as exc:
        logger.warning("kpi.schema_loader.failed", table=table, error=str(exc))
        return table, []


async def introspect_schemas_node(state: KPIAnalysisState) -> dict:
    settings = get_settings().agent
    kpi_schema = get_settings().agent.kpi_table_schema
    site_schema = settings.target_table_schema
    site_table = settings.target_table_name

    tasks = [_safe_introspect(kpi_schema, t) for t in _KPI_TABLES]
    tasks.append(_safe_introspect(site_schema, site_table))

    results = await asyncio.gather(*tasks)
    table_schemas = {name: cols for name, cols in results}
    logger.info("kpi.schema_loader.done", tables=list(table_schemas.keys()))
    return {"table_schemas": table_schemas}
