"""Site-level SQL generation node.

For each flagged market+KPI combo the LLM generates a SQL query
against stg_ndpd_mbt_tmobile_macro_combined to surface affected sites.
"""

from __future__ import annotations

import asyncio
import json
import re
from datetime import UTC, datetime
from uuid import uuid4

from langchain_core.messages import HumanMessage, SystemMessage

from risk_agent.config import get_settings
from risk_agent.core.llm import build_llm
from risk_agent.db.pool import fetch_all
from risk_agent.kpi_analysis.models import KPIMaster, TrendFinding
from risk_agent.kpi_analysis.prompts import build_site_sql_prompt, build_site_sql_retry_prompt
from risk_agent.kpi_analysis.state import KPIAnalysisState
from risk_agent.models.domain import StepResult, StepSource, StepStatus
from risk_agent.utils.logging import get_logger
from risk_agent.utils.sql_safety import enforce_row_limit, validate_sql

logger = get_logger(__name__)
_MAX_SITE_ROWS = 200


def _parse_sql_response(text: str) -> tuple[str, str | None]:
    """Parse LLM response into (detail_sql, count_sql).

    Accepts JSON with detail_sql/count_sql keys, or falls back to treating the
    whole response as a plain detail_sql (backward-compat with old prompt format).
    """
    cleaned = re.sub(r"^```(?:json|sql)?\s*|\s*```$", "", text.strip(), flags=re.IGNORECASE | re.MULTILINE).strip()
    try:
        data = json.loads(cleaned)
        detail = data.get("detail_sql", "").strip()
        count = data.get("count_sql", "").strip() or None
        return detail, count
    except (json.JSONDecodeError, AttributeError):
        return cleaned, None


async def _llm_generate_sql(messages: list) -> tuple[str, str | None] | None:
    """Invoke the LLM and return (detail_sql, count_sql), or None on LLM failure."""
    try:
        llm = build_llm(role="planner")
        response = await llm.ainvoke(messages)
        raw = response.content if hasattr(response, "content") else str(response)
        return _parse_sql_response(raw)
    except Exception:
        return None


async def _generate_and_run(
    finding: TrendFinding,
    site_table_columns: list[dict],
    site_table_qualified: str,
    max_retries: int,
    question_bank_context: str | None = None,
    business_context: str | None = None,
) -> StepResult:
    started_at = datetime.now(UTC)
    step_id = uuid4()
    step_name = f"site_query_{finding.geo_name}_{finding.kpi_name}"

    # Initial generation
    sys_p, usr_p = build_site_sql_prompt(
        site_table_columns, site_table_qualified,
        finding.geo_name, finding.kpi_name, finding.trend_summary,
        question_bank_context=question_bank_context,
        business_context=business_context,
    )
    parsed = await _llm_generate_sql([
        SystemMessage(content=sys_p), HumanMessage(content=usr_p),
    ])
    if parsed is None:
        logger.warning("kpi.site_analyzer.llm_failed", finding=step_name)
        return StepResult(
            step_id=step_id, step_name=step_name, source=StepSource.SEMANTIC_KPI,
            status=StepStatus.FAILED, error="LLM generation failed",
            started_at=started_at, finished_at=datetime.now(UTC),
            related_kpi=finding.kpi_name,
        )

    current_sql, count_sql = parsed
    last_error = ""
    last_executed = current_sql
    # Attempt 0 = initial; attempts 1..max_retries = retries with error feedback
    for attempt in range(max_retries + 1):
        try:
            validate_sql(current_sql)
            limited_sql = enforce_row_limit(current_sql, _MAX_SITE_ROWS)
        except Exception as exc:
            last_error = str(exc)
            last_executed = current_sql
            logger.warning(
                "kpi.site_analyzer.sql_invalid",
                finding=step_name, attempt=attempt, error=last_error,
            )
        else:
            try:
                rows = await fetch_all(limited_sql, {})
                finished_at = datetime.now(UTC)
                duration_ms = (finished_at - started_at).total_seconds() * 1000

                # Run the count query to get total eligible sites for impact %
                total_eligible: int | None = None
                if count_sql:
                    try:
                        validate_sql(count_sql)
                        count_rows = await fetch_all(count_sql, {})
                        if count_rows:
                            raw_val = list(count_rows[0].values())[0]
                            total_eligible = int(raw_val) if raw_val is not None else None
                    except Exception as count_exc:
                        logger.warning(
                            "kpi.site_analyzer.count_query_failed",
                            finding=step_name, error=str(count_exc),
                        )

                logger.info(
                    "kpi.site_analyzer.query_ok",
                    finding=step_name, attempt=attempt, rows=len(rows),
                    total_eligible=total_eligible,
                )
                return StepResult(
                    step_id=step_id, step_name=step_name, source=StepSource.SEMANTIC_KPI,
                    status=StepStatus.SUCCESS, rows=rows, row_count=len(rows),
                    total_eligible_count=total_eligible,
                    executed_sql=limited_sql, started_at=started_at,
                    finished_at=finished_at, duration_ms=duration_ms,
                    related_kpi=finding.kpi_name,
                )
            except Exception as exc:
                last_error = str(exc)
                last_executed = limited_sql
                logger.warning(
                    "kpi.site_analyzer.query_failed",
                    finding=step_name, attempt=attempt, error=last_error,
                )

        # Out of retry budget?
        if attempt >= max_retries:
            break

        # Build retry prompt with the failing SQL + Postgres error and try again
        retry_sys, retry_usr = build_site_sql_retry_prompt(
            site_table_columns, site_table_qualified,
            finding.geo_name, finding.kpi_name, finding.trend_summary,
            last_executed, last_error,
            question_bank_context=question_bank_context,
            business_context=business_context,
        )
        next_parsed = await _llm_generate_sql([
            SystemMessage(content=retry_sys), HumanMessage(content=retry_usr),
        ])
        if next_parsed is None:
            logger.warning("kpi.site_analyzer.retry_llm_failed", finding=step_name, attempt=attempt + 1)
            break
        current_sql, count_sql = next_parsed

    return StepResult(
        step_id=step_id, step_name=step_name, source=StepSource.SEMANTIC_KPI,
        status=StepStatus.FAILED, executed_sql=last_executed, error=last_error,
        started_at=started_at, finished_at=datetime.now(UTC),
        related_kpi=finding.kpi_name,
    )


async def generate_site_sql_node(state: KPIAnalysisState) -> dict:
    market_findings: list[TrendFinding] = state.get("market_findings", [])
    if not market_findings:
        logger.info("kpi.site_analyzer.skipped", reason="no flagged markets")
        return {"site_step_results": []}

    settings = get_settings().agent
    site_table_qualified = settings.target_table_qualified
    site_table_name = settings.target_table_name
    site_table_columns = state.get("table_schemas", {}).get(site_table_name, [])
    max_retries = settings.kpi_site_sql_max_retries
    question_bank_context: str | None = state.get("kpi_question_bank_context") or None
    kpi_masters: list[KPIMaster] = state.get("kpi_masters", [])
    project_business_contexts: dict[str, str] = state.get("project_business_contexts", {})
    kpi_project_map: dict[str, str] = {m.kpi_name: m.project for m in kpi_masters if m.project}

    logger.info("kpi.site_analyzer.start", markets=len(market_findings), max_retries=max_retries)

    def _business_context_for(finding: TrendFinding) -> str | None:
        proj = kpi_project_map.get(finding.kpi_name)
        return project_business_contexts.get(proj, "") or None if proj else None

    tasks = [
        _generate_and_run(
            f, site_table_columns, site_table_qualified, max_retries,
            question_bank_context, _business_context_for(f),
        )
        for f in market_findings
    ]
    results: list[StepResult] = await asyncio.gather(*tasks)
    logger.info("kpi.site_analyzer.done", results=len(results))
    return {"site_step_results": list(results)}
