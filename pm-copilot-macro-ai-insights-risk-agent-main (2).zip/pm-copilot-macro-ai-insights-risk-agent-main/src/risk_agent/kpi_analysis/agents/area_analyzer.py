"""Area-level KPI drill-down node.

Only runs for regions flagged by analyze_region_node.
"""

from __future__ import annotations

import asyncio

from langchain_core.messages import HumanMessage, SystemMessage

from risk_agent.config import get_settings
from risk_agent.core.llm import build_llm
from risk_agent.db.pool import fetch_all
from risk_agent.kpi_analysis.agents.region_analyzer import _parse_findings
from risk_agent.kpi_analysis.models import GeoLevel, KPIMaster, TrendFinding
from risk_agent.kpi_analysis.prompts import build_area_prompts
from risk_agent.kpi_analysis.state import KPIAnalysisState
from risk_agent.utils.logging import get_logger

logger = get_logger(__name__)

_TABLE = "tmo_macro_kpi_area_output_details_trial"
_MASTER_TABLE = "tmo_macro_kpi_master_details"
_HISTORY_POINTS = 12


async def _analyze_one_region(
    kpi_schema: str,
    region_name: str,
    flagged_kpi_ids: list[int],
    flagged_kpi_names: list[str],
    kpi_masters: list[KPIMaster],
    trend_months: int,
    kpi_keywords_context: str | None = None,
    project_business_contexts: dict[str, str] | None = None,
    parent_findings: list[TrendFinding] | None = None,
) -> list[TrendFinding]:
    """Drill into area data for one flagged region + its flagged KPIs."""
    if not flagged_kpi_ids:
        return []

    kpi_ids_csv = ",".join(str(int(x)) for x in flagged_kpi_ids)

    sql = f"""
        WITH ranked AS (
          SELECT
            m.kpi_name,
            UPPER(TRIM(a.region_name)) AS region_name,
            UPPER(TRIM(a.area_name))   AS area_name,
            CASE
              WHEN TRIM(a.result) ~ '^-?[0-9]+(\\.[0-9]+)?$'
              THEN TRIM(a.result)::numeric
              ELSE NULL
            END AS value,
            a.result_date_time,
            ROW_NUMBER() OVER (
              PARTITION BY a.kpi_id, UPPER(TRIM(a.area_name))
              ORDER BY a.result_date_time DESC
            ) AS rn
          FROM "{kpi_schema}"."{_TABLE}" a
          JOIN "{kpi_schema}"."{_MASTER_TABLE}" m ON m.id = a.kpi_id
          WHERE a.kpi_id IN ({kpi_ids_csv})
            AND a.result_date_time IS NOT NULL
            AND a.area_name IS NOT NULL
            AND UPPER(TRIM(a.region_name)) = UPPER(TRIM(:region_name))
            AND a.result_date_time >= NOW() - INTERVAL '{trend_months} months'
        )
        SELECT kpi_name, region_name, area_name, value, result_date_time
        FROM ranked
        WHERE rn <= {_HISTORY_POINTS} AND value IS NOT NULL
        ORDER BY kpi_name, area_name, result_date_time DESC
    """  # noqa: S608

    try:
        rows = await fetch_all(sql, {"region_name": region_name})
    except Exception as exc:
        logger.warning("kpi.area_analyzer.query_failed", region=region_name, error=str(exc))
        return []

    if not rows:
        logger.info("kpi.area_analyzer.no_rows", region=region_name)
        return []

    system_prompt, user_prompt = build_area_prompts(
        kpi_masters, rows, region_name.strip().upper(), flagged_kpi_names,
        kpi_keywords_context, project_business_contexts,
        parent_findings=parent_findings,
    )
    try:
        llm = build_llm(role="planner")
        response = await llm.ainvoke([
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt),
        ])
        raw = response.content if hasattr(response, "content") else str(response)
    except Exception as exc:
        logger.warning("kpi.area_analyzer.llm_failed", region=region_name, error=str(exc))
        return []

    return _parse_findings(raw, GeoLevel.AREA)


async def analyze_area_node(state: KPIAnalysisState) -> dict:
    region_findings: list[TrendFinding] = state.get("region_findings", [])
    if not region_findings:
        logger.info("kpi.area_analyzer.skipped", reason="no flagged regions")
        return {"area_findings": []}

    settings = get_settings().agent
    kpi_schema = settings.kpi_table_schema
    trend_months = settings.kpi_trend_months
    kpi_masters: list[KPIMaster] = state.get("kpi_masters", [])
    kpi_keywords_context: str | None = state.get("kpi_keywords_context")
    project_business_contexts: dict[str, str] = state.get("project_business_contexts", {})
    name_to_id = {m.kpi_name: m.id for m in kpi_masters if m.id is not None}

    # Group flagged kpis per region; resolve kpi_name -> kpi_id via master.
    region_kpi_ids: dict[str, list[int]] = {}
    region_kpi_names: dict[str, list[str]] = {}
    unresolved: list[str] = []
    for f in region_findings:
        kpi_id = name_to_id.get(f.kpi_name)
        if kpi_id is None:
            unresolved.append(f.kpi_name)
            continue
        region_kpi_ids.setdefault(f.geo_name, []).append(kpi_id)
        region_kpi_names.setdefault(f.geo_name, []).append(f.kpi_name)

    if unresolved:
        logger.warning("kpi.area_analyzer.unresolved_kpis", unresolved=unresolved[:10])

    if not region_kpi_ids:
        logger.info("kpi.area_analyzer.no_resolvable_kpis")
        return {"area_findings": []}

    logger.info("kpi.area_analyzer.start", regions=list(region_kpi_ids.keys()), trend_months=trend_months)

    # Build per-region parent findings map for context passing
    region_findings_map: dict[str, list[TrendFinding]] = {}
    for f in region_findings:
        region_findings_map.setdefault(f.geo_name, []).append(f)

    tasks = [
        _analyze_one_region(
            kpi_schema,
            region,
            region_kpi_ids[region],
            region_kpi_names[region],
            kpi_masters,
            trend_months,
            kpi_keywords_context,
            project_business_contexts or None,
            parent_findings=region_findings_map.get(region),
        )
        for region in region_kpi_ids
    ]
    results = await asyncio.gather(*tasks)
    area_findings = [f for group in results for f in group]

    logger.info("kpi.area_analyzer.done", anomalous=len(area_findings))
    return {"area_findings": area_findings}
