"""Region-level KPI trend analysis node."""

from __future__ import annotations

import json
import re

from langchain_core.messages import HumanMessage, SystemMessage

from risk_agent.config import get_settings
from risk_agent.core.llm import build_llm
from risk_agent.db.pool import fetch_all
from risk_agent.kpi_analysis.models import GeoLevel, KPIMaster, TrendFinding
from risk_agent.kpi_analysis.prompts import build_region_prompts
from risk_agent.kpi_analysis.state import KPIAnalysisState
from risk_agent.utils.logging import get_logger

logger = get_logger(__name__)

_TABLE = "tmo_macro_kpi_region_output_details_trial"
_MASTER_TABLE = "tmo_macro_kpi_master_details"
_HISTORY_POINTS = 12


def _parse_findings(text: str, geo_level: GeoLevel) -> list[TrendFinding]:
    """Extract a JSON array of TrendFinding dicts from LLM output."""
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```$", "", text.strip(), flags=re.IGNORECASE | re.MULTILINE)
    start = cleaned.find("[")
    end = cleaned.rfind("]")
    if start == -1 or end == -1:
        return []
    try:
        items = json.loads(cleaned[start : end + 1])
    except json.JSONDecodeError:
        logger.warning("kpi.parse_findings.json_error", raw=cleaned[:300])
        return []
    findings = []
    for item in items:
        if not isinstance(item, dict):
            continue
        try:
            item["geo_level"] = geo_level.value
            findings.append(TrendFinding(**{k: v for k, v in item.items() if k in TrendFinding.model_fields}))
        except Exception as exc:
            logger.warning("kpi.parse_findings.item_error", error=str(exc))
    return findings


async def analyze_region_node(state: KPIAnalysisState) -> dict:
    settings = get_settings().agent
    kpi_schema = settings.kpi_table_schema
    trend_months = settings.kpi_trend_months
    kpi_masters: list[KPIMaster] = state.get("kpi_masters", [])
    kpi_keywords_context: str | None = state.get("kpi_keywords_context")
    project_business_contexts: dict[str, str] = state.get("project_business_contexts", {})

    logger.info("kpi.region_analyzer.start", trend_months=trend_months)

    sql = f"""
        WITH ranked AS (
          SELECT
            m.kpi_name,
            UPPER(TRIM(r.region_name)) AS region_name,
            CASE
              WHEN TRIM(r.result) ~ '^-?[0-9]+(\\.[0-9]+)?$'
              THEN TRIM(r.result)::numeric
              ELSE NULL
            END AS value,
            r.result_date_time,
            ROW_NUMBER() OVER (
              PARTITION BY r.kpi_id, UPPER(TRIM(r.region_name))
              ORDER BY r.result_date_time DESC
            ) AS rn
          FROM "{kpi_schema}"."{_TABLE}" r
          JOIN "{kpi_schema}"."{_MASTER_TABLE}" m ON m.id = r.kpi_id
          WHERE r.kpi_id IS NOT NULL
            AND r.result_date_time IS NOT NULL
            AND r.region_name IS NOT NULL
            AND r.result_date_time >= NOW() - INTERVAL '{trend_months} months'
        )
        SELECT kpi_name, region_name, value, result_date_time
        FROM ranked
        WHERE rn <= {_HISTORY_POINTS} AND value IS NOT NULL
        ORDER BY kpi_name, region_name, result_date_time DESC
    """  # noqa: S608

    try:
        rows = await fetch_all(sql, {})
    except Exception as exc:
        logger.error("kpi.region_analyzer.query_failed", error=str(exc))
        return {"region_findings": [], "errors": [f"Region query failed: {exc}"]}

    if not rows:
        logger.info("kpi.region_analyzer.no_data")
        return {"region_findings": []}

    system_prompt, user_prompt = build_region_prompts(
        kpi_masters, rows, kpi_keywords_context, project_business_contexts or None
    )

    try:
        llm = build_llm(role="planner")
        response = await llm.ainvoke([
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt),
        ])
        raw = response.content if hasattr(response, "content") else str(response)
    except Exception as exc:
        logger.error("kpi.region_analyzer.llm_failed", error=str(exc))
        return {"region_findings": [], "errors": [f"Region LLM failed: {exc}"]}

    findings = _parse_findings(raw, GeoLevel.REGION)
    logger.info(
        "kpi.region_analyzer.done",
        anomalous=len(findings),
        rows_analyzed=len(rows),
    )
    return {"region_findings": findings}
