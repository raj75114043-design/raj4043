"""LangGraph graph for the KPI hierarchical analysis pipeline.

Topology (sequential — each level depends on the prior level's findings):

    START
      → introspect_schemas
      → load_kpi_master
      → analyze_region
      → analyze_area        (no-op if no flagged regions)
      → analyze_market      (no-op if no flagged areas)
      → generate_site_sql   (no-op if no flagged markets)
      → synthesize_report
      → END
"""

from __future__ import annotations

from typing import Any

from langgraph.graph import END, START, StateGraph

from risk_agent.kpi_analysis.agents import (
    analyze_area_node,
    analyze_market_node,
    analyze_region_node,
    generate_site_sql_node,
    introspect_schemas_node,
    load_kpi_master_node,
    synthesize_report_node,
)
from risk_agent.kpi_analysis.state import KPIAnalysisState

NODE_SCHEMAS = "introspect_schemas"
NODE_MASTER = "load_kpi_master"
NODE_REGION = "analyze_region"
NODE_AREA = "analyze_area"
NODE_MARKET = "analyze_market"
NODE_SITE = "generate_site_sql"
NODE_REPORT = "synthesize_report"


def build_kpi_graph() -> Any:
    graph = StateGraph(KPIAnalysisState)

    graph.add_node(NODE_SCHEMAS, introspect_schemas_node)
    graph.add_node(NODE_MASTER, load_kpi_master_node)
    graph.add_node(NODE_REGION, analyze_region_node)
    graph.add_node(NODE_AREA, analyze_area_node)
    graph.add_node(NODE_MARKET, analyze_market_node)
    graph.add_node(NODE_SITE, generate_site_sql_node)
    graph.add_node(NODE_REPORT, synthesize_report_node)

    graph.add_edge(START, NODE_SCHEMAS)
    graph.add_edge(NODE_SCHEMAS, NODE_MASTER)
    graph.add_edge(NODE_MASTER, NODE_REGION)
    graph.add_edge(NODE_REGION, NODE_AREA)
    graph.add_edge(NODE_AREA, NODE_MARKET)
    graph.add_edge(NODE_MARKET, NODE_SITE)
    graph.add_edge(NODE_SITE, NODE_REPORT)
    graph.add_edge(NODE_REPORT, END)

    return graph.compile()
