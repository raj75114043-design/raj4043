"""LangGraph shared state for the KPI analysis pipeline."""

from __future__ import annotations

import operator
from typing import Annotated, Any, TypedDict

from risk_agent.kpi_analysis.models import KPIMaster, TrendFinding
from risk_agent.models.domain import RiskReport, StepResult


class KPIAnalysisState(TypedDict, total=False):
    # Table schemas: table_name → list of column dicts (name, data_type, ...)
    table_schemas: dict[str, list[dict[str, Any]]]

    # KPI master records loaded from tmo_macro_kpi_master_details
    kpi_masters: list[KPIMaster]

    # Domain keyword definitions fetched from the semantic API for KPI descriptions.
    # Formatted as a ready-to-embed prompt block passed to all geo analyzers.
    kpi_keywords_context: str

    # Reference SQL patterns from the question_bank semantic table.
    # Passed to site_analyzer so the LLM can reuse proven query patterns.
    kpi_question_bank_context: str

    # Project-specific business context: project name → formatted prompt block.
    # Keyed by project value from KPI master (e.g. "AHLOA", "NTM", "NAS").
    project_business_contexts: dict[str, str]

    # Hierarchical findings — only anomalous entries propagate to the next level
    region_findings: list[TrendFinding]
    area_findings: list[TrendFinding]
    market_findings: list[TrendFinding]

    # Site-level query results (reuse StepResult from existing domain)
    site_step_results: list[StepResult]

    # Final synthesized report produced by synthesize_report_node
    report: RiskReport

    # Error accumulator — safe to write from multiple nodes
    errors: Annotated[list[str], operator.add]
