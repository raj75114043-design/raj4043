"""Internal domain models for the KPI analysis pipeline.

These are intermediate representations used within the pipeline.
At report-synthesis time they are converted into the standard
RiskFinding / RiskReport models from risk_agent.models.domain.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class GeoLevel(str, Enum):
    NATIONAL = "national"
    REGION = "region"
    AREA = "area"
    MARKET = "market"
    SITE = "site"


class KPIMaster(BaseModel):
    """One row from tmo_macro_kpi_master_details."""

    model_config = ConfigDict(extra="allow")

    id: int | None = None
    kpi_name: str
    description: str | None = None
    formula: str | None = None
    logic: str | None = None
    # The master table stores SQL templates per geo level in these columns:
    national_sql: str | None = None
    region_sql: str | None = None
    area_sql: str | None = None
    market_sql: str | None = None
    project: str | None = None
    sla: float | None = None
    threshold: float | None = None
    disturbing_trend: str | None = None    # "inc" | "dec"
    phase: str | None = None              # derived from SQL column references


class TrendFinding(BaseModel):
    """An anomalous KPI trend detected at one geographic level."""

    model_config = ConfigDict(extra="forbid")

    geo_level: GeoLevel
    geo_name: str = Field(..., description="e.g. 'Southeast' or 'Atlanta'")
    parent_geo: str | None = Field(
        default=None,
        description="Parent geography name — region name when geo_level=area, etc.",
    )
    kpi_name: str
    is_anomalous: bool = True
    trend_summary: str = Field(..., description="Human-readable description of the trend issue")
    recent_values: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Last N rows from the KPI table for this geo+KPI combo",
    )
    threshold_breached: bool = False
    sla_at_risk: bool = False
    risk_category: str | None = Field(
        default=None,
        description="Business risk category this finding belongs to",
    )
