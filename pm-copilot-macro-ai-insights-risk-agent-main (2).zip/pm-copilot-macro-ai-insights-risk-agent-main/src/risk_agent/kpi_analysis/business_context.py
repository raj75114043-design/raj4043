"""Project-specific business context for the KPI analysis pipeline.

Maps project names (AHLOA, NTM, NAS) to pre-formatted prompt blocks that
describe their deployment phases and column meanings. Loaded once at import
time and stored in state by load_kpi_master_node.

To add NTM or NAS context: define the phase schema dict here and populate
the PROJECT_BUSINESS_CONTEXTS entry. The rest of the pipeline picks it up
automatically via the project field on KPIMaster.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# AHLOA phase schema — telecom tower modernisation deployment process
# ---------------------------------------------------------------------------

_PHASE_SCHEMA_AHLOA: dict[int | str, str] = {
    0: """
=== BASE NODES: Core Entities ===

Foundational Nodes - TMobile, Nokia, Site, Vendor and SC Vendor.
TMobile assigns Site (as a project) to Nokia. Vendor works on this Site.
All Market, Area, Region and State filters are from Site node only.
All projects are AHLOA, hence no filters needed.
These nodes have 2 type of properties
1. Magenta (T-Mobile database properties) - Starts with 'pj'.
Note: 'pj_a' is for actual date and 'pj_p' for planned date.
2. NDPD (Nokia database properties) - Starts with 'ms'.

--- NODES ---

1. TMobile

2. Nokia

3. Site
   - s_site_id                          | STRING | Unique site identifier; primary key (e.g., '9NV0517R')
   - s_site_name                        | STRING | Human-readable site name (e.g., 'Nolensville II')
   - s_state                            | STRING | State abbreviation
   - region                             | STRING | Nokia region ("WEST" and "CENTRAL" only)
   - m_area                             | STRING | Market area grouping
   - m_market                           | STRING | Specific market

4. Vendor
   - construction_gc        | STRING | General contractor (Vendor) company name; primary key
""",

    1: """
=== PHASE 1: Project Initialization and Setup ===

Project details like Build Plan Year, Project type (M-Modification General only) and a unique Por ID.
Hard cost, soft cost and Vendor(GC or General Contractor) assignment details like comments, dates etc.
A unique smp_id for every project.

--- NODES ---

1. Phase1_ProjectAssignment
   - pj_project_id   | STRING | Unique project identifier; primary key
   - s_site_id       | STRING | Site ID the project is assigned to
   - assigned_status | STRING | 'Assigned' / 'Not Assigned' only

2. SMP_ID_Creation
   - pj_project_id | STRING | Primary key
   - smp_id        | STRING | SMP WO ID (e.g., 'SMP-WO-1296358')
   - smp_name      | STRING | SMP program name (AHLOB Modernization only)
   - smp_status    | STRING | SMP status ('Active' and 'Cancelled' only)

3. Phase1_Details
   - pj_project_id   | STRING | Primary key
   - pj_project_type | STRING | Project type ('M-Modification General' only)
   - por_por_id      | STRING | POR reference ID

4. Hard_cost_vendor_assignment
   - pj_project_id                     | STRING          | Primary key
   - pj_hard_cost_vendor_assignment_po | STRING          | HC Vendor Name
   - pj_hard_cost_approval_date        | LOCAL_DATE_TIME | HC approval date
   - assigned_status                   | STRING          | 'Assigned' / 'Not Assigned' only

5. Soft_cost_vendor_assignment
   - pj_project_id              | STRING          | Primary key
   - pj_soft_cost_vendor        | STRING          | Soft cost vendor Name
   - pj_soft_cost_approval_date | LOCAL_DATE_TIME | Soft cost approval date
   - assigned_status            | STRING          | 'Assigned' / 'Not Assigned' only

6. Vendor_assignment
   - pj_project_id                | STRING          | Primary key
   - construction_gc              | STRING/FLOAT    | Assigned GC
   - assigned_status              | STRING          | 'Assigned' / 'Not Assigned'
   - pj_a_3775_gc_selected_finish | LOCAL_DATE_TIME | Vendor (GC) assignment date in TMobile DB
   - pj_p_3775_gc_selected_finish | LOCAL_DATE_TIME | <Planned>

7. Drone
   - pj_project_id                        | STRING          | Primary key
   - ms_1321_talon_view_drone_svcs_actual | LOCAL_DATE_TIME | Drone work Assigned Date
""",

    2: """
=== PHASE 2: Pre-Construction Planning and Validation ===

TMobile provides a Precon / Pre-NTP document to Nokia with planned dates for activities like
CD (Construction Drawing), RFDS, BOM (Bill of Materials), SA (Structural Analysis) and MA (Mount Analysis).
TMobile also provides Entitlement Completion (EC) and Talon view survey details.

--- NODES ---

1. Phase2_PreConstruction
   - pj_project_id | STRING | Primary key
   - precon_status | STRING | 'Validated' / 'Pending Validation' / 'Not Yet Submitted'

2. Talon_View
   - pj_project_id                                           | STRING          | Primary key
   - pj_a_1010_talonview_pre_con_site_survey_ordered_finish  | LOCAL_DATE_TIME | Talonview site survey order date
   - pj_a_1015_talonview_pre_con_site_survey_approved_finish | LOCAL_DATE_TIME | Talonview site survey approve date
   - pj_p_1010_talonview_pre_con_site_survey_ordered_finish  | LOCAL_DATE_TIME | <Planned>
   - pj_p_1015_talonview_pre_con_site_survey_approved_finish | LOCAL_DATE_TIME | <Planned>

3. Entitlement_Complete
   - pj_project_id                             | STRING          | Primary key
   - pj_a_3710_ran_entitlement_complete_finish | LOCAL_DATE_TIME | Actual RAN entitlement completion
   - pj_a_3725_all_entitlement_complete_finish | LOCAL_DATE_TIME | Actual all entitlements completion
   - pj_p_3710_ran_entitlement_complete_finish | LOCAL_DATE_TIME | <Planned>
   - pj_p_3725_all_entitlement_complete_finish | LOCAL_DATE_TIME | <Planned>

4. Precon_Milestones
   - pj_project_id                                            | STRING          | Primary key
   - pj_a_3800_pre_ntp_issued_finish                          | LOCAL_DATE_TIME | Pre-NTP / Pre-con issued date
   - pj_a_2225_construction_drawings_received_finish          | LOCAL_DATE_TIME | CDs received date
   - pj_a_2250_construction_drawings_redlines_compiled_finish | LOCAL_DATE_TIME | Corrections in CDs
   - pj_a_2275_final_construction_drawings_approved_finish    | LOCAL_DATE_TIME | Final updated CDs
""",

    3: """
=== PHASE 3: Scoping and Site Assessment ===

Defines the real scope of work. Nokia assigns pre-construction site walks/surveys.
Additional scope of work is identified and compiled into a scoping package.

--- NODES ---

1. Phase3_Scoping
   - pj_project_id  | STRING | Primary key
   - scoping_status | STRING | 'Site Walk Not Assigned' / 'Site Walk/Survey Ongoing' / 'SP Created and Validated'

2. Phase3_Details
   - pj_project_id                                   | STRING          | Primary key
   - pj_a_3825_pre_construction_walk_complete_finish | LOCAL_DATE_TIME | Drone/Manual Survey Complete Date
   - pj_p_3825_pre_construction_walk_complete_finish | LOCAL_DATE_TIME | <Planned>
""",

    4: """
=== PHASE 4: Vendor Quoting and Customer Approval ===

TMobile receives the Scoping Package from Nokia as an 'E-quote'. TMobile reviews and approves it.

--- NODES ---

1. Phase4_Quoting
   - pj_project_id                        | STRING          | Primary key
   - quoting_status                       | STRING          | 'Not Started' / 'Bid Walk Complete' / 'Submitted to Customer' / 'Approved by Customer'
   - pj_a_3815_bid_walk_complete_finish   | LOCAL_DATE_TIME | SP (e-quote) received by TMobile
   - pj_p_3815_bid_walk_complete_finish   | LOCAL_DATE_TIME | <Planned>
   - pj_bid_walk_complete_3815_doc        | STRING          | Name given to the E-quote
   - pj_bid_walk_complete_optional_status | STRING          | 'In Review' or 'Approved'
""",

    5: """
=== PHASE 5: NTP (Notice to Proceed) ===

TMobile provides the Notice to Proceed (NTP) to Nokia for Tower Work (Radio Swap/Upgrade Activity).

--- NODES ---

1. Phase5_NTP
   - pj_project_id                                     | STRING          | Primary key
   - pj_p_4075_construction_ntp_submitted_to_gc_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_4075_construction_ntp_submitted_to_gc_finish | LOCAL_DATE_TIME | Tower work NTP Submitted to Vendor (GC)
   - pj_p_4100_construction_ntp_accepted_by_gc_finish  | LOCAL_DATE_TIME | <Planned>
   - pj_a_4100_construction_ntp_accepted_by_gc_finish  | LOCAL_DATE_TIME | Tower work NTP Accepted by Vendor (GC)
   - ms_1407_tower_ntp_validated_actual                | LOCAL_DATE_TIME | Tower work NTP validated by Nokia
   - ms_1507_tower_ntp_approved_actual                 | LOCAL_DATE_TIME | Tower work NTP approved by Nokia
""",

    6: """
=== PHASE 6: Material Procurement ===

List of Materials is finalized and the Bill of Materials (BOM) is uploaded to the TMobile tool.
As TMobile approves the BOM, materials arrive in the warehouse. Vendor collects the materials.

--- NODES ---

1. Phase6_Material
   - pj_project_id   | STRING | Primary key
   - material_status | STRING | 'Material Pickup Complete' / 'BAT Uploaded' / 'AIMS Uploaded' / 'Pending'

2. BOM_Submission
   - pj_project_id                             | STRING          | Primary key
   - pj_a_3850_bom_submitted_bom_in_bat_finish | LOCAL_DATE_TIME | BOM uploaded to BAT tool (TMobile tool)
   - pj_a_3875_bom_received_bom_in_aims_finish | LOCAL_DATE_TIME | BOM uploaded to AIMS tool (TMobile tool)
   - pj_a_3900_all_bat_orders_received_finish  | LOCAL_DATE_TIME | Material has arrived in warehouse

3. Steel_Submission
   - pj_project_id            | STRING          | Primary key
   - pj_steel_ordered_status  | STRING          | Steel ordered status
   - pj_steel_received_status | STRING          | Steel received status
   - pj_steel_po_number       | STRING          | Steel PO number
   - pj_steel_ordered         | LOCAL_DATE_TIME | Ordered date
   - pj_steel_received_date   | LOCAL_DATE_TIME | Received date

4. Material_Pickup
   - pj_project_id                                      | STRING          | Primary key
   - pj_a_3925_msl_pickup_date_finish                   | LOCAL_DATE_TIME | Vendor picks up material from warehouse
   - ms_1461_pickup_tower_materials_and_validate_actual | LOCAL_DATE_TIME | Updated by Project Manager
   - ms_14610_gc_material_pickup_actual                 | LOCAL_DATE_TIME | Updated by Vendor/GC
""",

    7: """
=== PHASE 7: Tower (swap) Readiness ===

This phase includes all the POs (SPO and CPO — Supplier PO and Customer PO).
These POs together are the pre-requisites for Tower (SWAP) work.

--- NODES ---

1. Phase7_Construction_Readiness
   - pj_project_id                                 | STRING          | Primary key
   - pj_construction_pos_issued                    | FLOAT           | PO issued flag/count
   - ms_1321_talon_view_drone_svcs_spo             | FLOAT           | TalonView SPO
   - ms_1321_talon_view_drone_svcs_spo_issued_date | LOCAL_DATE_TIME | TalonView SPO issued date
   - ms1555_construction_complete_spo              | FLOAT           | Tower completion SPO
   - ms1555_construction_complete_spo_issued_date  | LOCAL_DATE_TIME | Tower SPO issue date
""",

    8: """
=== PHASE 8: Tower Work (SWAP Work or Radio SWAP or Equipment Upgrade) ===

This phase includes the tower work (swap) start and finish dates, delays and comments.

--- NODES ---

1. Phase8_Tower_Work
   - pj_project_id                           | STRING          | Primary key
   - pj_a_4225_construction_start_finish     | LOCAL_DATE_TIME | Actual tower work (swap) start date
   - pj_p_4225_construction_start_finish     | LOCAL_DATE_TIME | <Planned>
   - pj_a_5175_construction_complete_finish  | LOCAL_DATE_TIME | Actual tower work (swap) complete date
   - pj_p_5175_construction_complete_finish  | LOCAL_DATE_TIME | <Planned>
   - pj_construction_start_delay_code        | STRING          | Start delay code
   - pj_construction_start_delay_comments   | STRING          | Start delay comments
   - pj_construction_complete_delay_code     | STRING          | Complete delay code
   - pj_construction_complete_delay_comments | STRING          | Complete delay comments
""",

    9: """
=== PHASE 9: Network Integration ===

Manages the integration of telecom network equipment into the operational network.
Includes integration start and complete milestones, and integration comments.

--- NODES ---

1. Phase9_Integration
   - pj_project_id                                      | STRING          | Primary key
   - pj_a_5270_integration_start_finish                 | LOCAL_DATE_TIME | Actual network integration start date
   - pj_p_5270_integration_start_finish                 | LOCAL_DATE_TIME | <Planned>
   - pj_a_5275_integration_complete_finish              | LOCAL_DATE_TIME | Actual network integration complete date
   - pj_p_5275_integration_complete_finish              | LOCAL_DATE_TIME | <Planned>
   - pj_integration_comments                            | STRING          | Integration comments
   - ms_1899_all_planned_technologies_integrated_actual | LOCAL_DATE_TIME | All techs integrated
""",

    10: """
=== PHASE 10: Post-Integration ===

Integration completion milestones, 72-hour monitoring milestone.
Old AHLOA equipment can be either disposed or returned.

--- NODES ---

1. Phase10_Post_Integration
   - pj_project_id                               | STRING          | Primary key
   - ms_1970_integration_complete_actual         | LOCAL_DATE_TIME | Post Integration completion date
   - ms_2045_72_hours_monitoring_complete_actual | LOCAL_DATE_TIME | +72 hours from 1970 milestone date
   - ms_17050_gc_ahloa_return_actual             | LOCAL_DATE_TIME | Old equipment returned (if not null)
   - ms_17100_gc_ahloa_disposal_actual           | LOCAL_DATE_TIME | Old equipment disposed (if not null)
""",

    11: """
=== PHASE 11: Revenue & Financial Close-Out ===

Revenue milestones (CA, IA, GR, BBR, SO etc.) from Tower (swap), Integration and DEC_COP phases.

--- NODES ---

1. Tower_Revenue
   - pj_project_id                             | STRING          | Primary key
   - ms1555_construction_complete_invoice_date | LOCAL_DATE_TIME | Tower invoice date
   - ms1555_construction_complete_ca_date      | LOCAL_DATE_TIME | Tower CA complete date
   - ms1555_construction_complete_bbr_date     | LOCAL_DATE_TIME | Tower BBR complete date
   - ms1555_construction_complete_gr_date      | LOCAL_DATE_TIME | Tower GR complete date
   - ms1555_construction_complete_ia_date      | LOCAL_DATE_TIME | Tower IA complete date

2. Integration_Revenue
   - pj_project_id                                | STRING          | Primary key
   - ms_1970_integration_complete_ca_date         | LOCAL_DATE_TIME | CA complete date
   - ms_1970_integration_complete_bbr_date        | LOCAL_DATE_TIME | BBR complete date
   - ms_1970_integration_complete_so_inv_date     | LOCAL_DATE_TIME | SO invoice date
   - ms_1970_integration_complete_ia_date         | LOCAL_DATE_TIME | IA complete date
   - ms_1970_integration_complete_gr_date         | LOCAL_DATE_TIME | GR complete date
""",

    "HSE": """
=== HSE: Health, Safety and Environment ===

Records safety compliance during active construction phases. Visit-level records per project.

--- NODES ---

1. Visit
   - pj_project_id             | STRING  | Project identifier
   - visit_num                 | INTEGER | Visit sequence number
   - check_in_status           | STRING  | Crew check-in status
   - check_in_date             | STRING  | Date of the crew check-in
   - ppe_validation            | STRING  | PPE inspection result
   - jsa_completion_status     | STRING  | JSA completion status
   - each_crew_ptid_l2w_status | STRING  | PTID L2W availability status

2. Revisit
   - pj_project_id           | STRING  | Project identifier
   - non_compliance_category | STRING  | Category of non-compliance
   - escalation_l1_to_gc     | STRING  | L1 escalation to GC
   - esaclation_l2_to_cm     | STRING  | L2 escalation to CM
""",

    "DEC_COP": """
=== DEC_COP: Close-Out Package & Punch List Workflow ===

Tracks Nokia's close-out package (COP) submitted to T-Mobile after construction.
Anchors the punch list workflow: submission, returns, re-submission, and final approvals.
Prefixes: pj_ = TMobile DB, ms_ = Nokia DB, scop_ = DEC DB.

--- NODES ---

1. DEC_COP
   - pj_project_id   | STRING | Primary key
   - scop_title      | STRING | COP title
   - approvedpercent | STRING | COP approval percentage by T-Mobile

2. Punch_List_status
   - scop_ndpc_session_cw_pending_pct   | STRING | Civil: pending %
   - scop_ndpc_session_cw_completed_pct | STRING | Civil: completed %
   - scop_ndpc_session_cw_approved_pct  | STRING | Civil: approved %
   - scop_ndpc_session_cw_rejected_pct  | STRING | Civil: rejected %
   - scop_ndpc_session_tw_pending_pct   | STRING | Tower: pending %
   - scop_ndpc_session_tw_completed_pct | STRING | Tower: completed %
   - scop_ndpc_session_tw_approved_pct  | STRING | Tower: approved %
   - scop_ndpc_session_tw_rejected_pct  | STRING | Tower: rejected %

3. PL_Submission
   - ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl | LOCAL_DATE_TIME | 1st submission date
   - pj_a_5500_receive_close_out_binder_finish                     | LOCAL_DATE_TIME | Punch checklist received by TMobile

4. PL_Final_Approval
   - pj_a_5525_approve_close_out_binder_finish | LOCAL_DATE_TIME | Punch list closing date in TMobile DB
   - ms_1559_cop_approved_by_t_mobile_actual   | LOCAL_DATE_TIME | TMobile final approval date in Nokia DB
   - scop_checklist_accepted_by_customer       | STRING          | Same milestone in DEC database
""",
}

# ---------------------------------------------------------------------------
# NTM phase schema — add PHASE_SCHEMA_NTM dict here when ready
# ---------------------------------------------------------------------------

_PHASE_SCHEMA_NTM: dict[int | str, str] = {
    0: """
=== BASE NODES: Core Entities ===

Foundational Nodes - TMobile, Nokia, Site, Vendor and SC Vendor.
TMobile assigns Site (as a project) to Nokia.
A site can have more than 1 project.
There are 3 Vendors that work on this project - Vendor or GC (General Contractor, is appointed by Nokia),
AAV Vendor (appointed by TMO), Power Vendor (appointed by TMO)
All Market, Area, Region and State filters are from Site node only.
All projects are NTM hence no filters needed.
There are 2 type of properties
1. Magenta (T-Mobile database properties) - Starts with 'pj'.
Note: 'pj_a' is for actual date and 'pj_p' for planned date.
2. NDPD (Nokia database properties) - Starts with 'ms'.

--- NODES ---

1. TMobile

2. Nokia

3. Site
   - s_site_id                          | STRING | Unique site identifier; primary key (e.g., '9NV0517R')
   - s_site_name                        | STRING | Human-readable site name (e.g., 'Nolensville II')
   - s_state                            | STRING | State abbreviation
   - region                             | STRING | Nokia region ("SOUTH", "WEST" and "CENTRAL" only)
   - m_area                             | STRING | Market area grouping
   - m_market                           | STRING | Specific market

4. Project
   - pj_project_id      | STRING | Unique project identifier; primary key
   - pj_project_name    | STRING | A name given to the project
   - pj_project_status  | STRING | The status of the project ("Active", "Completed", "Dead" and "On Hold" only)
   - pj_project_type    | STRING | The type of project

5. Vendor
   - construction_gc        | STRING | General Contractor / Vendor name from NDPD DB; primary key
   - pj_general_contractor  | STRING | Vendor name in Magenta DB

6. TMO_AAV_Vendor
   - s_primary_aav_vendor_name_salesforce | STRING | AAV vendor name (soft cost vendor) appointed by TMO; primary key

7. TMO_Power_Vendor
   - s_power_provider_company_name | STRING | Power vendor name appointed by TMO; primary key
""",

    1: """
=== PHASE 1: Project Initialization and Setup ===

Project POR details - POR count, POR ID, and POR (Build Plan Year).
Hard cost, soft cost and Vendor (GC) assignment details.
A unique smp_id for every project.

--- NODES ---

1. Phase1_ProjectAssignment
   - pj_project_id   | STRING | Unique project identifier; primary key
   - s_site_id       | STRING | Site ID the project is assigned to

2. SMP_ID_Creation
   - pj_project_id | STRING | Primary key
   - smp_id        | STRING | SMP WO ID (e.g., 'SMP-WO-1296358')
   - smp_name      | STRING | SMP program name, Always 'NTM'
   - smp_version   | FLOAT  | SMP version
   - smp_status    | STRING | SMP status 'Active' or 'Cancelled'

3. Phase1_Details
   - pj_project_id | STRING | Primary key
   - smp_id        | STRING | SMP_ID
   - pj_por_count  | STRING | POR count (1, 2, 3, and 4 only)
   - por_por_id    | STRING | POR reference ID, unique for every project
   - por           | FLOAT  | Period of Record or Build Plan Year

4. Hard_cost_vendor_assignment
   - pj_project_id                     | STRING          | Primary key
   - pj_hard_cost_vendor_assignment_po | STRING          | HC Vendor Name
   - pj_hard_cost_approval_date        | LOCAL_DATE_TIME | HC approval date

5. Soft_cost_vendor_assignment
   - pj_project_id                        | STRING          | Primary key
   - s_primary_aav_vendor_name_salesforce | STRING          | TMO AAV Vendor name
   - pj_soft_cost_approval_date           | LOCAL_DATE_TIME | Soft cost approval date
""",

    2: """
=== PHASE 2: Pre-Construction Planning and Validation ===

TMO provides a Pre-NTP (Precon) document to Nokia with planned dates for activities like
CD, RFDS, BOM, SA (Structural Analysis) and MA (Mount Analysis).
Nokia validates the drawings & planned dates. Nokia can modify construction drawings (red lines).
Post validation, Nokia can either accept or reject the document.
TMobile also provides Entitlement Completion (EC) to Nokia.

--- NODES ---

1. Phase2_PreConstruction
   - pj_project_id | STRING | Primary key
   - precon_status | STRING | 'Validated' / 'Pending Validation' / 'Not Yet Submitted'

2. Construction_Drawings
   - pj_a_2200_construction_drawings_ordered_finish           | LOCAL_DATE_TIME | CDs ordered date
   - pj_a_2225_construction_drawings_received_finish          | LOCAL_DATE_TIME | CDs received date
   - pj_a_2250_construction_drawings_redlines_compiled_finish | LOCAL_DATE_TIME | Corrections in CDs date
   - pj_a_2275_final_construction_drawings_approved_finish    | LOCAL_DATE_TIME | Final updated CDs
   - pj_a_2286_mw_final_construction_drawings_approved_finish | LOCAL_DATE_TIME | Final MW drawings approved

3. Precon_Milestones
   - pj_project_id                                            | STRING          | Primary key
   - pj_a_3800_pre_ntp_issued_finish                          | LOCAL_DATE_TIME | Pre-NTP / Pre-con issued date
   - pj_p_3800_pre_ntp_issued_finish                          | LOCAL_DATE_TIME | <Planned>
   - ms_1310_pre_construction_package_received_actual         | LOCAL_DATE_TIME | Precon package received by Nokia

4. Precon_Validation
   - pj_project_id                                     | STRING          | Primary key
   - validation_status                                 | STRING/FLOAT    | Validation status
   - pre_con_validation_rejection_reason               | STRING/FLOAT    | Rejection reason (if any)
   - ms_1313_pre_construction_package_validated_actual | LOCAL_DATE_TIME | Validation actual
   - ms_1315_pre_construction_package_rejected_actual  | LOCAL_DATE_TIME | Rejection actual

5. Entitlement_Complete
   - pj_project_id                             | STRING          | Primary key
   - pj_a_3710_ran_entitlement_complete_finish | LOCAL_DATE_TIME | RAN entitlement completion
   - pj_a_3725_all_entitlement_complete_finish | LOCAL_DATE_TIME | All entitlements completion
   - pj_p_3710_ran_entitlement_complete_finish | LOCAL_DATE_TIME | <Planned>
   - pj_p_3725_all_entitlement_complete_finish | LOCAL_DATE_TIME | <Planned>

6. Vendor_assignment
   - pj_project_id                | STRING          | Primary key
   - construction_gc              | STRING/FLOAT    | Assigned GC
   - pj_a_3775_gc_selected_finish | LOCAL_DATE_TIME | Vendor (GC) assignment date in TMobile DB
   - pj_p_3775_gc_selected_finish | LOCAL_DATE_TIME | <Planned>
""",

    3: """
=== PHASE 3: Scoping and Site Assessment ===

Defines the real scope of work. Nokia assigns pre-construction site walks and drone surveys.
Additional scope of work is identified and compiled into a scoping package,
validated internally by Nokia and Vendor and then submitted to TMobile.

--- NODES ---

1. Phase3_Survey_and_Scoping
   - pj_project_id  | STRING | Primary key
   - scoping_status | STRING | 'Site Walk Not Assigned' / 'Site Walk/Survey Ongoing' / 'SP Created and Validated'

2. Manual_Survey
   - pj_project_id                              | STRING          | Primary key
   - pre_con_type                               | STRING          | Walk type - 'Local CM' for Manual walk
   - ms_1316_pre_con_site_walk_completed_actual | LOCAL_DATE_TIME | Site walk date (if pre_con_type = 'Local CM')

3. Drone_Survey
   - pj_project_id                                     | STRING          | Primary key
   - pre_con_type                                      | STRING          | Walk type - 'Drone' for Drone
   - ms_1314_ndpc_survey_request_form_submitted_actual | LOCAL_DATE_TIME | Drone request date
   - ms_1321_talon_view_drone_svcs_actual              | LOCAL_DATE_TIME | Drone survey date
   - ms_1321_talon_view_drone_svcs_spo_issued_date     | LOCAL_DATE_TIME | Drone SPO issue date

4. Scoping_Completion
   - pj_project_id                                        | STRING          | Primary key
   - pj_a_3825_pre_construction_walk_complete_finish      | LOCAL_DATE_TIME | Survey Complete Date (Main milestone)
   - pj_p_3825_pre_construction_walk_complete_finish      | LOCAL_DATE_TIME | <Planned>
   - ms_1323_ready_for_scoping_actual                     | LOCAL_DATE_TIME | Scoping package completed and ready
   - ms_1327_scoping_and_quoting_package_validated_actual | LOCAL_DATE_TIME | Scoping package validated and submitted to TMobile
""",

    4: """
=== PHASE 4: Vendor Quoting and Customer Approval ===

TMobile receives the Scoping Package from Nokia as an 'E-quote'. TMobile reviews and approves it.

--- NODES ---

1. Phase4_Quoting
   - pj_project_id                                        | STRING          | Primary key
   - quoting_status                                       | STRING          | 'Not Started' / 'Bid Walk Complete' / 'Submitted to Customer' / 'Approved by Customer'
   - pj_a_3815_bid_walk_complete_finish                   | LOCAL_DATE_TIME | SP (e-quote) received by TMobile
   - pj_p_3815_bid_walk_complete_finish                   | LOCAL_DATE_TIME | <Planned>
   - pj_bid_walk_complete_3815_doc                        | STRING          | Name of the E-quote
   - pj_bid_walk_complete_optional_status                 | STRING          | 'In Review' or 'Approved'
   - ms_1331_scoping_package_submitted_actual             | LOCAL_DATE_TIME | SP submitted to TMobile for review
   - ms_1333_scoping_package_approved_by_customer_actual | LOCAL_DATE_TIME | SP accepted by TMobile
""",

    5: """
=== PHASE 5: NTP (Notice to Proceed) ===

TMobile provides the NTP to Nokia for two sets of activities:
civil construction work and tower construction work.
Covers all NTP milestones - submitted to vendor, accepted by vendor, validated and approved by Nokia.

--- NODES ---

1. Phase5_NTP
   - pj_project_id | STRING | Primary key

2. Civil_NTP_Magenta
   - pj_p_4025_civil_ntp_submitted_to_gc_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_4025_civil_ntp_submitted_to_gc_finish | LOCAL_DATE_TIME | Civil NTP Submitted to Vendor (GC)
   - pj_p_4050_civil_ntp_accepted_by_gc_finish  | LOCAL_DATE_TIME | <Planned>
   - pj_a_4050_civil_ntp_accepted_by_gc_finish  | LOCAL_DATE_TIME | Civil NTP Accepted by Vendor (GC)

3. Tower_NTP_Magenta
   - pj_p_4075_construction_ntp_submitted_to_gc_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_4075_construction_ntp_submitted_to_gc_finish | LOCAL_DATE_TIME | Tower NTP Submitted to Vendor (GC)
   - pj_p_4100_construction_ntp_accepted_by_gc_finish  | LOCAL_DATE_TIME | <Planned>
   - pj_a_4100_construction_ntp_accepted_by_gc_finish  | LOCAL_DATE_TIME | Tower NTP Accepted by Vendor (GC)

4. NTP_NDPD
   - ms_1407_tower_ntp_validated_actual | LOCAL_DATE_TIME | Tower NTP validated by Nokia
   - ms_1507_tower_ntp_approved_actual  | LOCAL_DATE_TIME | Tower NTP approved by Nokia
""",

    6: """
=== PHASE 6: Material Procurement ===

List of Materials is finalized and the Bill of Materials (BOM) is uploaded to TMobile tools (AIMs and BAT).
As TMobile approves the BOM, materials arrive in the warehouse. Vendor collects the materials.
Steel details include PO number, steel received status, etc.

--- NODES ---

1. Phase6_Material
   - pj_project_id   | STRING | Primary key
   - material_status | STRING | 'Material Pickup Complete' / 'BAT Uploaded' / 'AIMS Uploaded' / 'Pending'

2. BOM_Submission
   - pj_project_id                             | STRING          | Primary key
   - pj_p_3850_bom_submitted_bom_in_bat_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_3850_bom_submitted_bom_in_bat_finish | LOCAL_DATE_TIME | BOM uploaded to BAT tool (TMobile tool)
   - pj_p_3875_bom_received_bom_in_aims_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_3875_bom_received_bom_in_aims_finish | LOCAL_DATE_TIME | BOM uploaded to AIMS tool (TMobile tool)
   - pj_p_3900_all_bat_orders_received_finish  | LOCAL_DATE_TIME | <Planned>
   - pj_a_3900_all_bat_orders_received_finish  | LOCAL_DATE_TIME | Material has arrived in warehouse

3. Steel_Submission
   - pj_project_id            | STRING          | Primary key
   - pj_steel_ordered_status  | STRING          | Steel ordered status
   - pj_steel_received_status | STRING          | Steel received status
   - pj_steel_po_number       | STRING          | Steel PO number
   - pj_steel_ordered         | LOCAL_DATE_TIME | Ordered date
   - pj_steel_received_date   | LOCAL_DATE_TIME | Received date

4. Material_Pickup
   - pj_project_id                                      | STRING          | Primary key
   - pj_p_3925_msl_pickup_date_finish                   | LOCAL_DATE_TIME | <Planned>
   - pj_a_3925_msl_pickup_date_finish                   | LOCAL_DATE_TIME | Vendor picks up material from warehouse
   - ms_1461_pickup_tower_materials_and_validate_actual | LOCAL_DATE_TIME | Same — Project Manager updates this
   - ms_14610_gc_material_pickup_actual                 | LOCAL_DATE_TIME | Same — GC updates
""",

    7: """
=== PHASE 7: Transport and Power Preparation ===

AAV Telco preparation includes AAV Telco walk/survey and AAV Telco design (done by AAV vendor).
Power preparation includes power order, power design and power walk/survey (done by Power vendor).

--- NODES ---

1. Phase7_AAV_and_Power_Planning
   - pj_project_id | STRING | Primary key

2. AAV
   - pj_p_2075_aav_telco_site_walk_complete_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_2075_aav_telco_site_walk_complete_finish | LOCAL_DATE_TIME | Actual AAV site walk complete
   - pj_p_2080_aav_telco_design_complete_finish    | LOCAL_DATE_TIME | <Planned>
   - pj_a_2080_aav_telco_design_complete_finish    | LOCAL_DATE_TIME | Actual AAV design complete

3. Power
   - pj_p_4450_permanent_power_ordered_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_4450_permanent_power_ordered_finish | LOCAL_DATE_TIME | Actual power ordered
   - pj_p_4475_complete_power_walk_finish     | LOCAL_DATE_TIME | <Planned>
   - pj_a_4475_complete_power_walk_finish     | LOCAL_DATE_TIME | Actual power walk
   - pj_p_4500_power_design_approval_finish   | LOCAL_DATE_TIME | <Planned>
   - pj_a_4500_power_design_approval_finish   | LOCAL_DATE_TIME | Actual power design approval
""",

    8: """
=== PHASE 8: Construction Readiness ===

Includes all POs (SPO and CPO — Supplier PO and Customer PO).
These POs together are the pre-requisites for construction work.

--- NODES ---

1. Phase8_Construction_Readiness
   - pj_project_id                                       | STRING          | Primary key
   - pj_p_4200_pull_construction_po_number_finish        | LOCAL_DATE_TIME | <Planned>
   - pj_a_4200_pull_construction_po_number_finish        | LOCAL_DATE_TIME | Actual construction PO pulled
   - pj_construction_pos_issued                          | FLOAT           | PO issued flag/count
   - base_spo_requested_date                             | LOCAL_DATE_TIME | Base SPO requested
   - ms_1551_civil_construction_complete_spo             | FLOAT           | Civil completion SPO
   - ms_1551_civil_construction_complete_spo_issued_date | LOCAL_DATE_TIME | Civil SPO issued
   - ms1555_construction_complete_spo                    | FLOAT           | Tower completion SPO
   - ms1555_construction_complete_spo_issued_date        | LOCAL_DATE_TIME | Tower SPO issued
   - ms_1970_integration_complete_spo                    | FLOAT           | Integration completion SPO
   - ms_1559_cop_approved_by_t_mobile_spo                | FLOAT           | COP approved SPO
   - ms_1559_cop_approved_by_t_mobile_spo_issued_date    | LOCAL_DATE_TIME | COP SPO issued
""",

    9: """
=== PHASE 9: Civil Construction and Power/AAV ===

Civil construction work start and finish dates (done by Vendor/GC).
Power installation work (done by Power vendor).
AAV Telco construction and MW installation (done by AAV vendor).

--- NODES ---

1. Phase9_Civil_Work
   - pj_project_id | STRING | Primary key

2. Civil_Start
   - pj_p_4250_civil_construction_start_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_4250_civil_construction_start_finish | LOCAL_DATE_TIME | Actual civil start

3. Civil_Finish
   - pj_p_4750_civil_construction_complete_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_4750_civil_construction_complete_finish | LOCAL_DATE_TIME | Actual civil complete

4. Power_Installation
   - pj_p_4525_power_ready_finish               | LOCAL_DATE_TIME | <Planned>
   - pj_a_4525_power_ready_finish               | LOCAL_DATE_TIME | Actual power ready
   - pj_p_4550_permanent_power_installed_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_4550_permanent_power_installed_finish | LOCAL_DATE_TIME | Actual permanent power installed

5. AAV_and_MW
   - pj_p_4875_aav_telco_ready_finish          | LOCAL_DATE_TIME | <Planned>
   - pj_a_4875_aav_telco_ready_finish          | LOCAL_DATE_TIME | Actual AAV ready
   - pj_p_4425_mw_installation_complete_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_4425_mw_installation_complete_finish | LOCAL_DATE_TIME | Actual MW install complete
""",

    10: """
=== PHASE 10: Tower Construction ===

Tower construction work start and finish dates, delays and comments.

--- NODES ---

1. Phase10_Tower_Work
   - pj_project_id | STRING | Primary key

2. Tower_Start
   - pj_p_4225_construction_start_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_4225_construction_start_finish | LOCAL_DATE_TIME | Actual tower start

3. Tower_Finish
   - pj_p_5175_construction_complete_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_5175_construction_complete_finish | LOCAL_DATE_TIME | Actual tower complete

4. Tower_Delay
   - pj_construction_start_delay_code        | STRING | Start delay code
   - pj_construction_start_delay_comments    | STRING | Start delay comments
   - pj_construction_complete_delay_code     | STRING | Complete delay code
   - pj_construction_complete_delay_comments | STRING | Complete delay comments
""",

    11: """
=== PHASE 11: Network Integration ===

Integration of telecom network equipment into the tower.
Includes integration start/complete milestones, SCF file validation, integration comments,
E911 test calls, and Airview report.

--- NODES ---

1. Phase11_Integration
   - pj_project_id | STRING | Primary key

2. Integration_Start
   - pj_p_5270_integration_start_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_5270_integration_start_finish | LOCAL_DATE_TIME | Actual integration start (Magenta)

3. Integration_Finish
   - pj_p_5275_integration_complete_finish | LOCAL_DATE_TIME | <Planned>
   - pj_a_5275_integration_complete_finish | LOCAL_DATE_TIME | Actual integration complete (Magenta)
   - pj_integration_comments              | STRING          | Integration comments

4. Integration_Details
   - ms_1564_validate_scf_files_are_available_actual    | LOCAL_DATE_TIME | SCF Files validation date
   - ms_1899_all_planned_technologies_integrated_actual | LOCAL_DATE_TIME | All techs integrated
   - ms_1971_air_view_report_completed_actual           | LOCAL_DATE_TIME | AirView completed
   - ms_2123_planned_e911_test_calls_actual             | LOCAL_DATE_TIME | E911 test calls
""",

    12: """
=== PHASE 12: Post-Integration, RTT & On-Air ===

Final integration completion milestone, RTT (Ready-To-Test),
and network On-Air activation for various spectrum bands.

--- NODES ---

1. Phase12_Post_Integration
   - pj_project_id                                | STRING          | Primary key
   - ms_1970_integration_complete_actual          | LOCAL_DATE_TIME | Final integration complete (NDPD milestone)
   - ms_1970_integration_complete_spo_issued_date | LOCAL_DATE_TIME | SPO issued

2. RTT
   - pj_a_5575_gsm_rtt_finish | LOCAL_DATE_TIME | GSM RTT

3. OnAir
   - pj_a_5600_gsm_onair_finish | LOCAL_DATE_TIME | GSM On-Air
""",

    13: """
=== PHASE 13: Revenue & Financial Close-Out ===

Revenue milestones (CA, IA, GR, BBR, SO etc.) from four project phases:
Civil, Tower, Integration and DEC_COP.

--- NODES ---

1. Phase13_Revenue
   - pj_project_id | STRING | Primary key

2. Civil_Revenue
   - ms_1551_civil_construction_complete_ia_date      | LOCAL_DATE_TIME | Civil IA complete
   - ms_1551_civil_construction_complete_gr_date      | LOCAL_DATE_TIME | Civil GR complete
   - ms_1551_civil_construction_complete_gr_so_number | STRING          | Civil GR SO number
   - ms_1551_civil_construction_complete_invoice_date | LOCAL_DATE_TIME | Civil invoice date
   - ms_1551_civil_construction_complete_ca_date      | LOCAL_DATE_TIME | Civil CA complete

3. Tower_Revenue
   - ms1555_construction_complete_invoice_date | LOCAL_DATE_TIME | Tower invoice date
   - ms1555_construction_complete_ca_date      | LOCAL_DATE_TIME | Tower CA complete
   - ms1555_construction_complete_bbr_date     | LOCAL_DATE_TIME | Tower BBR complete
   - ms1555_construction_complete_gr_date      | LOCAL_DATE_TIME | Tower GR complete
   - ms1555_construction_complete_ia_date      | LOCAL_DATE_TIME | Tower IA complete

4. PL_Revenue
   - ms_1559_cop_approved_by_t_mobile_ia_date  | LOCAL_DATE_TIME | COP IA
   - ms_1559_cop_approved_by_t_mobile_gr_date  | LOCAL_DATE_TIME | COP GR
   - ms_1559_cop_approved_by_t_mobile_ca_date  | LOCAL_DATE_TIME | COP CA
   - ms_1559_cop_approved_by_t_mobile_bbr_date | LOCAL_DATE_TIME | COP BBR

5. Integration_Revenue
   - ms_1970_integration_complete_ca_date     | LOCAL_DATE_TIME | CA complete
   - ms_1970_integration_complete_bbr_date    | LOCAL_DATE_TIME | BBR complete
   - ms_1970_integration_complete_so_inv_date | LOCAL_DATE_TIME | SO invoice date
   - ms_1970_integration_complete_ia_date     | LOCAL_DATE_TIME | IA complete
   - ms_1970_integration_complete_gr_date     | LOCAL_DATE_TIME | GR complete
""",

    "HSE": """
=== HSE: Health, Safety and Environment ===

Records safety compliance during active construction phases. Visit-level records per project.

--- NODES ---

1. HSE
   - pj_project_id | STRING | Unique project identifier; primary key

2. Visit
   - pj_project_id             | STRING  | Project identifier this visit belongs to
   - visit_num                 | INTEGER | Visit sequence number; part of composite key
   - check_in_status           | STRING  | Crew check-in status
   - check_in_date             | STRING  | Date of the crew check-in
   - ppe_validation            | STRING  | PPE inspection result
   - ppe_photo_available       | STRING  | Whether PPE photo was captured
   - jsa_completion_status     | STRING  | JSA completion status
   - each_crew_ptid_l2w_status | STRING  | PTID L2W availability status
""",

    "DEC_COP": """
=== DEC_COP: Close-Out Package & Punch List Workflow ===

Tracks Nokia's close-out package (COP) submitted to T-Mobile after construction.
Anchors the punch list workflow: submission, returns, re-submission, and final approvals.
Prefixes: pj_ = TMobile DB, ms_ = Nokia DB, scop_ = DEC DB.
Civil and tower punch lists are tracked separately in DEC DB.

--- NODES ---

1. DEC_COP
   - pj_project_id   | STRING | Unique project identifier; primary key
   - scop_title      | STRING | COP title
   - approvedpercent | STRING | COP approval percentage by T-Mobile

2. Punch_List_status
   - scop_ndpc_session_cw_pending_pct   | STRING | Civil: pending %
   - scop_ndpc_session_cw_completed_pct | STRING | Civil: completed %
   - scop_ndpc_session_cw_approved_pct  | STRING | Civil: approved %
   - scop_ndpc_session_cw_rejected_pct  | STRING | Civil: rejected %
   - scop_ndpc_session_tw_pending_pct   | STRING | Tower: pending %
   - scop_ndpc_session_tw_completed_pct | STRING | Tower: completed %
   - scop_ndpc_session_tw_approved_pct  | STRING | Tower: approved %
   - scop_ndpc_session_tw_rejected_pct  | STRING | Tower: rejected %

3. PL_Submission
   - ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl | LOCAL_DATE_TIME | Punch checklist 1st submission date (Nokia DB)
   - ms_1558_admin_checklist_submitted_to_t_mobile_actual          | LOCAL_DATE_TIME | Admin checklist 1st submission date (Nokia DB)
   - pj_a_5500_receive_close_out_binder_finish                     | LOCAL_DATE_TIME | Punch checklist received by TMobile
   - pj_p_5500_receive_close_out_binder_finish                     | LOCAL_DATE_TIME | <Planned>

4. PL_Post_Submission
   - pj_a_5400_punch_list_to_gc_finish | LOCAL_DATE_TIME | Vendor receives rejected punch list
   - pj_p_5400_punch_list_to_gc_finish | LOCAL_DATE_TIME | <Planned>

5. PL_Resubmission
   - pj_a_5425_punch_list_complete_finish | LOCAL_DATE_TIME | Punch list resubmission date
   - pj_p_5425_punch_list_complete_finish | LOCAL_DATE_TIME | <Planned>
   - scop_pending_days_for_gc_action      | STRING          | Days pending GC action from 5400

6. PL_Final_Approval
   - pj_a_5525_approve_close_out_binder_finish | LOCAL_DATE_TIME | Punch list closing date in TMobile DB
   - pj_p_5525_approve_close_out_binder_finish | LOCAL_DATE_TIME | <Planned>
   - ms_1559_cop_approved_by_t_mobile_actual   | LOCAL_DATE_TIME | TMobile final approval date in Nokia DB
   - scop_checklist_accepted_by_customer       | STRING          | Same milestone in DEC database
   - magenta_ms_5525_actual                    | LOCAL_DATE_TIME | DEC_COP punchlist completion date in Nokia DB
""",
}

# ---------------------------------------------------------------------------
# NAS phase schema — add PHASE_SCHEMA_NAS dict here when ready
# ---------------------------------------------------------------------------

_PHASE_SCHEMA_NAS: dict[int | str, str] = {
    0: """
=== BASE NODE: Site (Global Context) ===

The Site node is the authoritative root for the entire graph.
ALL queries MUST anchor from Site.

--- CORE NODE ---

Site
- nas_site_id | STRING | Site primary identifier
- name        | STRING | Always 'Site'
- nas_market  | STRING | Market name

--- BASE QUERY RULE ---

Every query MUST start from:
(Site)
""",

    1: """
=== PHASE 1: e911 Readiness & Validation ===

Captures emergency (e911) readiness classification, validation history, PSAP details,
and RIOT vs RFCIQ layer comparisons.
Each site engineer visit is classified as READY, INTP, or NOT_READY.

--- CORE NODES ---

1. Site_e911
   - nas_site_id | STRING | (representative node — site contains multiple e911 instances)

2. READY / INTP / NOT_READY
   - nas_site_id | STRING | (representative classification nodes)

3. e911
   - id                                 | LONG            | Unique ID for every e911 instance
   - nas_site_id                        | STRING          | Site identifier
   - nas_validate_e911_readiness        | STRING          | e911 readiness status (e.g., 'Ready', 'NOT READY', 'INTP', 'LTE TAC Mismatch', etc.)
   - nas_e911_validation_date           | DATE            | The e911 instance completion date
   - nas_e911_validation_reason         | STRING / DOUBLE | Detailed reason mentioned
   - nas_psap_id                        | STRING / DOUBLE | PSAP ID
   - nas_psap_name                      | STRING / DOUBLE | PSAP Name
   - nas_existing_layers                | STRING / DOUBLE | Existing layers detail
   - nas_proposed_layers                | STRING / DOUBLE | New/proposed layers detail
   - nas_consolidation_check_all_layers | STRING          | Consolidation check result
   - nas_engineer                       | STRING / DOUBLE | Engineer Name
   - nas_remarks                        | STRING / DOUBLE | Remarks by engineer
   - e911_visit                         | LONG            | e911 visit number on Site
   - create_date                        | LOCAL_DATE_TIME | Entry created date
   - write_date                         | LOCAL_DATE_TIME | Entry written date

--- RELATIONSHIPS ---

(Site)-[:SITE_E911]->(Site_e911)
(Site_e911)-[:E911_READY]->(READY)-[:READY_E911]->(e911)
(Site_e911)-[:E911_INTP]->(INTP)-[:INTP_E911]->(e911)
(Site_e911)-[:E911_NOT_READY]->(NOT_READY)-[:NOT_READY_E911]->(e911)
""",

    2: """
=== PHASE 2: Planned Outages & Activities ===

Models planned activities including approval flows, vendors, work orders, and outage timelines.

--- CORE NODES ---

1. Site_Planned_Activity
   - nas_site_id | STRING

2. PA_Approved / PA_Pending / PA_Rejected
   - nas_site_id | STRING
   - name        | STRING | 'Approved' / 'Pending' / 'Rejected'

3. Planned_Activity
   - activity_id             | LONG
   - nas_site_id             | STRING
   - nas_status              | STRING
   - nas_activity_details    | STRING / DOUBLE
   - nas_activity_start_date | LOCAL_DATE_TIME
   - nas_activity_end_date   | LOCAL_DATE_TIME
   - nas_request_time        | LOCAL_DATE_TIME
   - nas_workorder_id        | STRING
   - nas_company_name        | STRING
   - nas_nest_type           | STRING
   - activity_order          | LONG
   - create_date             | LOCAL_DATE_TIME
   - write_date              | LOCAL_DATE_TIME

--- RELATIONSHIPS ---

(Site)-[:HAS_PLANNED_ACTIVITIES]->(Site_Planned_Activity)
(Site_Planned_Activity)-[:HAS_APPROVED_ACTIVITIES]->(PA_Approved)
(Site_Planned_Activity)-[:HAS_PENDING_ACTIVITIES]->(PA_Pending)
(Site_Planned_Activity)-[:HAS_REJECTED_ACTIVITIES]->(PA_Rejected)
(PA_Approved / PA_Pending / PA_Rejected)-[:HAS_*_ACTIVITY]->(Planned_Activity)
""",

    3: """
=== PHASE 3: Sessions (NEST / Field Execution) ===

Captures field execution sessions including check-in, check-out, extensions, and rejections.

--- CORE NODES ---

1. Site_Session
   - nas_site_id | STRING
   - name        | STRING | 'Session'

2. Session
   - session_id                    | LONG
   - nas_site_id                   | STRING
   - nas_activity_type             | STRING / DOUBLE
   - nas_company_name              | STRING
   - nas_contact_person            | STRING
   - nas_user_id                   | STRING
   - nas_workorder_id              | STRING
   - nas_nest_type                 | STRING
   - nas_status_nest_active        | STRING
   - nas_last_event                | STRING
   - nas_nest_start_time           | LOCAL_DATE_TIME
   - nas_nest_start_time_requested | LOCAL_DATE_TIME
   - nas_checkout_time             | LOCAL_DATE_TIME
   - nas_checkout_approve_time     | LOCAL_DATE_TIME
   - nas_total_activity_duration   | STRING / DOUBLE
   - session_order                 | LONG

3. Session_Check_In
   - session_id | LONG
   - check_in   | STRING

4. Session_Check_Out
   - session_id | LONG
   - check_out  | STRING

5. Session_Extension
   - session_id | LONG
   - extension  | STRING

6. Session_Rejection
   - session_id      | LONG
   - rejection_reason| STRING
   - rejection_notes | STRING / DOUBLE

--- RELATIONSHIPS ---

(Site)-[:HAS_SESSIONS]->(Site_Session)
(Site_Session)-[:HAS_SESSION]->(Session)
(Session)-[:HAS_CHECK_IN]->(Session_Check_In)
(Session)-[:HAS_CHECK_OUT]->(Session_Check_Out)
(Session)-[:HAS_EXTENSION]->(Session_Extension)
(Session)-[:HAS_REJECTION]->(Session_Rejection)
""",

    4: """
=== PHASE 4: Integration & Call Testing ===

Models integration readiness, call testing, GO email responsibilities, and layer configuration.

--- CORE NODES ---

1. Site_Integration
   - nas_site_id          | STRING
   - nas_integration_date | DATE
   - nas_remarks          | STRING / DOUBLE

2. Site_Call_Test
   - nas_site_id                     | STRING
   - nas_call_test_completed_date    | DATE
   - nas_call_test_completion_status | STRING / DOUBLE
   - nas_remarks                     | STRING / DOUBLE

3. Site_GO_Email
   - nas_site_id                                  | STRING
   - nas_go_email_responsibility                  | STRING / DOUBLE
   - nas_completion_partial_email_responsibility  | STRING / DOUBLE

4. Site_layers
   - nas_site_id        | STRING
   - nas_existing_layer | STRING / DOUBLE
   - nas_proposed_layer | STRING / DOUBLE

--- RELATIONSHIPS ---

(Site)-[:HAS_Integration]->(Site_Integration)
(Site_Integration)-[:HAS_Call_Test]->(Site_Call_Test)
(Site_Integration)-[:HAS_GO_Email]->(Site_GO_Email)
(Site_Integration)-[:HAS_Layers]->(Site_layers)
""",

    5: """
=== PHASE 5: RF010 Milestones ===

Captures RF010 sequencing, MB status, completion tracking, and HOP validation.

--- CORE NODES ---

1. Site_RF010
   - nas_site_id | STRING
   - name        | STRING | 'Site_RF010'

2. RF010
   - rf010_id    | LONG
   - nas_site_id | STRING
   - rf010_order | LONG

3. RF010_MB
   - rf010_id | LONG
   - mb_status| STRING

4. RF010_Completion
   - rf010_id               | LONG
   - task_completed_datetime| LOCAL_DATE_TIME

5. RF010_HOP
   - rf010_id              | LONG
   - hop_validation_status | STRING

--- RELATIONSHIPS ---

(Site)-[:HAS_RF010s]->(Site_RF010)
(Site_RF010)-[:HAS_RF010]->(RF010)
(RF010)-[:HAS_MB]->(RF010_MB)
(RF010)-[:HAS_Completion]->(RF010_Completion)
(RF010)-[:HAS_HOP]->(RF010_HOP)
""",
}


def _format_business_context(phase_dict: dict[int | str, str]) -> str:
    """Convert a phase schema dict into an injectable prompt block.

    Returns an empty string if the dict is empty (no injection for that project).
    """
    if not phase_dict:
        return ""
    lines = ["Deployment process phases and column context for this project:"]
    for phase_key, description in phase_dict.items():
        lines.append(description.strip())
    return "\n\n".join(lines)


# Pre-computed at import time — no per-request overhead.
PROJECT_BUSINESS_CONTEXTS: dict[str, str] = {
    "AHLOA": _format_business_context(_PHASE_SCHEMA_AHLOA),
    "NTM": _format_business_context(_PHASE_SCHEMA_NTM),
    "NAS": _format_business_context(_PHASE_SCHEMA_NAS),
}

# ---------------------------------------------------------------------------
# Column → phase mapping (used by kpi_master_loader to derive KPI phase)
# ---------------------------------------------------------------------------

import re as _re


def _parse_column_phase_map(schema: dict) -> dict[str, str]:
    """Parse a phase schema dict and return {column_name: phase_title}.

    Scans each block for the phase title (=== PHASE N: Title ===) and all
    column definition lines (   - column_name | ...). First phase wins when
    a column appears in more than one block (rare but possible).
    """
    col_to_phase: dict[str, str] = {}
    for block in schema.values():
        title_m = _re.search(r"===\s*(.*?)\s*===", block)
        if not title_m:
            continue
        phase_title = title_m.group(1).strip()
        for col_m in _re.finditer(r"\n\s+-\s+(\w+)\s*\|", block):
            col = col_m.group(1)
            col_to_phase.setdefault(col, phase_title)
    return col_to_phase


_COLUMN_PHASE_MAPS: dict[str, dict[str, str]] = {
    "AHLOA": _parse_column_phase_map(_PHASE_SCHEMA_AHLOA),
    "NTM": _parse_column_phase_map(_PHASE_SCHEMA_NTM),
    "NAS": _parse_column_phase_map(_PHASE_SCHEMA_NAS),
}


def get_column_phase_map(project: str) -> dict[str, str]:
    """Return the column→phase_title map for the given project name."""
    return _COLUMN_PHASE_MAPS.get((project or "").upper(), {})
