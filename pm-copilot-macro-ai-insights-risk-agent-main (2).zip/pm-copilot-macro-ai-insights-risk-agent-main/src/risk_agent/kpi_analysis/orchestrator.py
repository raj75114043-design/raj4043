"""High-level entry point for the KPI analysis pipeline."""

from __future__ import annotations

from risk_agent.kpi_analysis.graph import build_kpi_graph
from risk_agent.kpi_analysis.state import KPIAnalysisState
from risk_agent.models.domain import RiskReport
from risk_agent.utils.logging import get_logger

logger = get_logger(__name__)


class KPIAnalysisOrchestrator:
    """Run the full KPI hierarchical analysis and return a RiskReport.

    Output format is identical to RiskAgentOrchestrator so both pipelines
    can be stored, displayed, and queried through the same interfaces.
    """

    def __init__(self) -> None:
        self._graph = build_kpi_graph()

    async def run(self) -> RiskReport:
        logger.info("kpi_orchestrator.run.start")

        initial_state: KPIAnalysisState = {
            "table_schemas": {},
            "kpi_masters": [],
            "region_findings": [],
            "area_findings": [],
            "market_findings": [],
            "site_step_results": [],
            "errors": [],
        }

        final_state: KPIAnalysisState = await self._graph.ainvoke(initial_state)

        report: RiskReport | None = final_state.get("report")
        if report is None:
            # Fallback: return an empty report rather than crashing the caller
            from datetime import UTC, datetime
            from risk_agent.kpi_analysis.agents.report_synthesizer import _KPI_CATEGORY
            report = RiskReport(
                category=_KPI_CATEGORY,
                findings=[],
                summary="KPI analysis completed with no findings or encountered errors.",
                started_at=datetime.now(UTC),
                finished_at=datetime.now(UTC),
            )

        errors = final_state.get("errors", [])
        if errors:
            logger.warning("kpi_orchestrator.run.errors", count=len(errors), errors=errors[:5])

        logger.info(
            "kpi_orchestrator.run.done",
            findings=len(report.findings),
            errors=len(errors),
        )

        try:
            from risk_agent.db.store import save_report
            await save_report(report, pipeline_type="kpi_trend")
        except Exception as exc:
            logger.warning("kpi_orchestrator.save_report.failed", error=str(exc))

        return report
