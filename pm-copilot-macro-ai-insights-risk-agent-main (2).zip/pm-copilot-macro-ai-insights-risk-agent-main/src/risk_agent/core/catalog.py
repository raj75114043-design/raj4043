"""Risk catalog loader — reads risk categories from the Excel sheet.

Expected columns (case-insensitive, flexible):
    - category_id          (e.g. RISK_NDPD_001)
    - name                 (human-readable title)
    - description          (NL description of the risk)
    - identification_logic (NL logic used to find the risk)
    - decision_rules       (semicolon- or newline-separated list of rules)
    - owner                (optional)
    - tags                 (optional; comma-separated)
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd

from risk_agent.models import RiskCategory
from risk_agent.utils.exceptions import RiskCatalogError
from risk_agent.utils.logging import get_logger

_logger = get_logger(__name__)


_REQUIRED_COLUMNS = {
    "category_id",
    "name",
    "description",
    "identification_logic",
}


def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]
    return df


def _split_multi(value: object) -> list[str]:
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return []
    text = str(value).strip()
    if not text:
        return []
    # Prefer newlines, fall back to semicolons, then commas.
    for sep in ("\n", ";"):
        if sep in text:
            return [part.strip() for part in text.split(sep) if part.strip()]
    # Only split on commas if the string looks like a list of tags.
    if "," in text and len(text) < 200:
        return [part.strip() for part in text.split(",") if part.strip()]
    return [text]


class RiskCatalog:
    """In-memory view of the Excel risk catalog."""

    def __init__(self, categories: list[RiskCategory]) -> None:
        self._categories = categories
        self._by_id = {c.category_id: c for c in categories}

    @classmethod
    def from_excel(cls, path: Path) -> RiskCatalog:
        """Load the risk catalog from an .xlsx file."""
        path = Path(path)
        if not path.exists():
            raise RiskCatalogError(f"Risk catalog not found: {path}")

        _logger.info("loading_risk_catalog", path=str(path))
        try:
            df = pd.read_excel(path)
        except Exception as exc:
            raise RiskCatalogError(f"Unable to read Excel file: {exc}") from exc

        df = _normalize_columns(df)

        missing = _REQUIRED_COLUMNS - set(df.columns)
        if missing:
            raise RiskCatalogError(
                f"Risk catalog missing required columns: {sorted(missing)}. "
                f"Found: {sorted(df.columns)}"
            )

        categories: list[RiskCategory] = []
        for idx, row in df.iterrows():
            try:
                categories.append(
                    RiskCategory(
                        category_id=str(row["category_id"]).strip(),
                        name=str(row["name"]).strip(),
                        description=str(row["description"]).strip(),
                        identification_logic=str(row["identification_logic"]).strip(),
                        decision_rules=_split_multi(row.get("decision_rules")),
                        owner=(
                            None
                            if pd.isna(row.get("owner", None))
                            else str(row["owner"]).strip()
                        ),
                        tags=_split_multi(row.get("tags")),
                    )
                )
            except Exception as exc:
                raise RiskCatalogError(
                    f"Invalid row {idx} in risk catalog: {exc}"
                ) from exc

        _logger.info("risk_catalog_loaded", count=len(categories))
        return cls(categories)

    def all(self) -> list[RiskCategory]:
        return list(self._categories)

    def get(self, category_id: str) -> RiskCategory:
        if category_id not in self._by_id:
            raise RiskCatalogError(f"Unknown category_id: {category_id}")
        return self._by_id[category_id]

    def __len__(self) -> int:
        return len(self._categories)

    def __iter__(self):  # type: ignore[no-untyped-def]
        return iter(self._categories)
