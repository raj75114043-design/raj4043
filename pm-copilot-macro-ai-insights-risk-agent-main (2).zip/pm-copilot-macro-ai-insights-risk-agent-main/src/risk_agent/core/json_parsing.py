"""Robust JSON parsing from LLM responses.

LLMs occasionally wrap JSON in Markdown fences even when told not to.
``parse_llm_json`` strips those before parsing and attempts to repair
common JSON malformations.
"""

from __future__ import annotations

import json
import re
from typing import Any

from risk_agent.utils.exceptions import LLMError

_FENCE_RE = re.compile(r"^```(?:json)?\s*|\s*```$", re.IGNORECASE | re.MULTILINE)


def _repair_json(text: str) -> str:
    """Attempt to repair common JSON malformations from LLM output.
    
    Handles:
    - Unescaped newlines within string values
    - Trailing commas in objects/arrays
    - Missing commas between array elements
    """
    # Fix unescaped newlines within strings by replacing them with \n
    # This is tricky - we need to be careful not to break the JSON structure
    lines = text.split('\n')
    result_lines = []
    in_string = False
    escape_next = False
    
    for line in lines:
        if not in_string:
            result_lines.append(line)
            # Check if line ends with an open string
            in_string = line.count('"') % 2 == 1
        else:
            # We're in a multi-line string - escape newline and continue
            result_lines.append('\\n' + line)
            in_string = line.count('"') % 2 == 1
    
    repaired = '\n'.join(result_lines)
    
    # Remove trailing commas before ] and }
    repaired = re.sub(r',(\s*[}\]])', r'\1', repaired)
    
    return repaired


def parse_llm_json(text: str) -> dict[str, Any]:
    """Parse a JSON object out of an LLM response.
    
    Attempts to:
    1. Strip Markdown fences
    2. Extract JSON from surrounding text
    3. Repair common malformations
    4. Parse the resulting JSON
    """
    if not text:
        raise LLMError("Empty LLM response.")

    cleaned = _FENCE_RE.sub("", text).strip()

    # Some models prefix with "Here is the JSON:" etc. Try to locate the first {.
    first_brace = cleaned.find("{")
    last_brace = cleaned.rfind("}")
    if first_brace == -1 or last_brace == -1 or last_brace <= first_brace:
        raise LLMError(f"No JSON object found in LLM response: {cleaned[:300]}")

    candidate = cleaned[first_brace : last_brace + 1]

    # Try direct parse first
    try:
        return json.loads(candidate)  # type: ignore[no-any-return]
    except json.JSONDecodeError as exc:
        # Attempt to repair and retry
        try:
            repaired = _repair_json(candidate)
            return json.loads(repaired)  # type: ignore[no-any-return]
        except json.JSONDecodeError:
            # If repair fails, raise original error with context
            raise LLMError(
                f"Failed to parse JSON from LLM: {exc}. "
                f"Raw (first 500 chars): {candidate[:500]}"
            ) from exc
