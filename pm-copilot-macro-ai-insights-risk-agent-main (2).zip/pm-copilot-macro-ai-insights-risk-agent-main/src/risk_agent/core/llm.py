from langchain_openai import ChatOpenAI
from risk_agent.config.settings import get_settings


class LLMProvider:
    LLM_API_KEY_URL = "https://llmgateway-qa-api.nokia.com/v1.2/"

    def __init__(self, model=None, temperature=0.0, reasoning_effort="low"):
        llm_settings = get_settings().azure_openai
        self.llm = ChatOpenAI(
            api_key=llm_settings.api_key.get_secret_value(),
            model=model or llm_settings.model,
            base_url=llm_settings.endpoint,
            default_headers={
                "api-key": llm_settings.api_key.get_secret_value(),
                "workspacename": llm_settings.LLM_WORKSPACE,
            },
            temperature=temperature,
            max_tokens=16386,
            verbose=True,
            reasoning_effort=reasoning_effort,
        )

    def get_llm(self):
        return self.llm

    def invoke(self, messages):
        return self.llm.invoke(messages)

    def stream(self, messages):
        return self.llm.stream(messages)

    async def ainvoke(self, messages):
        return await self.llm.ainvoke(messages)


def build_llm(role: str = "planner"):
    """Factory used by agents (planner, generator, validator, executor).

    Returns a configured ChatOpenAI instance. The ``role`` argument selects
    which deployment name from settings to use.
    """
    llm_settings = get_settings().azure_openai

    if role == "planner":
        model = llm_settings.deployment_planner
    elif role == "generator":
        model = llm_settings.deployment_generator
    elif role == "validator":
        model = llm_settings.deployment_validator
    else:
        model = llm_settings.model

    return LLMProvider(model=model).get_llm()
