"""Application settings loaded from environment variables.

Pattern copied from the working ai_insights_risk reference project:
- DATABASE_URL is a full postgresql+asyncpg://... URL read directly from .env
- Password is URL-encoded in the .env (e.g. %40 for @)
- pydantic-settings handles loading
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Literal

from dotenv import load_dotenv
from pydantic import Field, SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

load_dotenv()


class AzureOpenAISettings(BaseSettings):
    """LLM gateway — reads user's LLM_* env names."""

    model_config = SettingsConfigDict(extra="ignore")

    api_key: SecretStr = SecretStr(os.getenv("LLM_API_KEY_VALUE", ""))
    endpoint: str = os.getenv("LLM_BASE_URL", "")
    LLM_WORKSPACE: str = os.getenv("LLM_WORKSPACE", "")
    deployment_planner: str = os.getenv("LLM_MODEL_HEAVY", "")
    deployment_generator: str = os.getenv("LLM_MODEL_HEAVY", "")
    deployment_validator: str = os.getenv(
        "LLM_MODEL_VALIDATOR", os.getenv("LLM_MODEL_HEAVY", "")
    )
    model: str = os.getenv("LLM_MODEL_HEAVY", "")


class PostgresSettings(BaseSettings):
    """Postgres — matches the ai_insights_risk reference pattern."""

    model_config = SettingsConfigDict(extra="ignore")

    # Primary connection URL — full postgresql+asyncpg://... string.
    # This is what SQLAlchemy's create_async_engine takes directly.
    database_url: str = os.getenv("DATABASE_URL", "")

    # Individual components (kept for log messages / health checks).
    host: str = os.getenv("POSTGRES_HOST", "")
    port: int = int(os.getenv("POSTGRES_PORT", "5432"))
    db: str = os.getenv("POSTGRES_DB", "")
    user: str = os.getenv("POSTGRES_USER", "")
    password: SecretStr = SecretStr(os.getenv("POSTGRES_PASSWORD", ""))
    schema_name: str = os.getenv("DB_SCHEMA", "public")

    # Pool tuning (same defaults as reference).
    pool_size: int = int(os.getenv("DATABASE_POOL_SIZE", "20"))
    max_overflow: int = int(os.getenv("DATABASE_MAX_OVERFLOW", "10"))
    pool_timeout: int = int(os.getenv("DATABASE_POOL_TIMEOUT", "30"))

    # Kept only because older code reads this; unused in the SQLAlchemy path.
    query_timeout: float = float(os.getenv("QUERY_TIMEOUT", "30"))

    # Legacy aliases used by existing pool.py call sites.
    @property
    def pool_min_size(self) -> int:
        return 1

    @property
    def pool_max_size(self) -> int:
        return self.pool_size

    @property
    def dsn(self) -> str:
        """Return the SQLAlchemy async URL — exactly what's in .env."""
        return self.database_url

    @property
    def async_dsn(self) -> str:
        return self.database_url


class SemanticAPISettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SEMANTIC_", extra="ignore")
    api_url: str = "https://pm-copilot-macro-gcl-osdp-gsd-gsd-delivery-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/semantic/search"
    keywords_api_url: str = "https://pm-copilot-macro-gcl-osdp-gsd-gsd-delivery-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/semantic/keywords/search"


class AgentSettings(BaseSettings):
    model_config = SettingsConfigDict(extra="ignore")
    max_parallel_steps: int = Field(default=10, alias="MAX_PARALLEL_STEPS")
    step_execution_timeout: int = Field(default=60, alias="STEP_EXECUTION_TIMEOUT")
    max_rows_per_step: int = Field(default=500, alias="MAX_ROWS_PER_STEP")
    risk_catalog_path: Path = Field(
        default=Path("./data/risk_categories.xlsx"),
        alias="RISK_CATALOG_PATH",
    )
    # ------------------------------------------------------------------ #
    # Target table — the single table the planner grounds SQL against.
    # All schema introspection and SQL generation operates on this table
    # only. Override via env vars TARGET_TABLE_SCHEMA / TARGET_TABLE_NAME.
    # ------------------------------------------------------------------ #
    target_table_schema: str = Field(
        default="pwc_macro_staging_schema",
        alias="TARGET_TABLE_SCHEMA",
    )
    target_table_name: str = Field(
        default="stg_ndpd_mbt_tmobile_macro_combined",
        alias="TARGET_TABLE_NAME",
    )

    kpi_table_schema: str = Field(
        default="public",
        alias="KPI_TABLE_SCHEMA",
    )

    kpi_trend_months: int = Field(
        default=1,
        alias="KPI_TREND_MONTHS",
    )

    kpi_site_sql_max_retries: int = Field(
        default=2,
        alias="KPI_SITE_SQL_MAX_RETRIES",
    )

    # Maximum number of site-level StepResult objects passed to a single
    # investigation LLM call. Each step can carry up to MAX_SITE_ROWS rows,
    # so keeping this small prevents context-length errors.
    # Override via KPI_INVESTIGATION_SITE_BATCH env var.
    kpi_investigation_site_batch: int = Field(
        default=4,
        alias="KPI_INVESTIGATION_SITE_BATCH",
    )

    # Maximum number of simultaneous LLM HTTP calls across the entire
    # KPI synthesizer run. Windows select() crashes above ~512 open FDs;
    # keeping this well below that avoids the "too many file descriptors" error.
    # Override via KPI_MAX_CONCURRENT_LLM_CALLS env var.
    kpi_max_concurrent_llm_calls: int = Field(
        default=8,
        alias="KPI_MAX_CONCURRENT_LLM_CALLS",
    )

    geo_tree_api_url: str = Field(
        default="https://pm-copilot-dashboard-osdp-gsd-gsd-delivery-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/dashboard/geography/tree",
        alias="GEO_TREE_API_URL",
    )

    milestone_api_url: str = Field(
        default="https://pm-copilot-kg-consume-osdp-gsd-gsd-delivery-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/status/macro/project",
        alias="MILESTONE_API_URL",
    )

    ahloa_milestone_api_url: str = Field(
        default="https://pm-copilot-kg-consume-osdp-gsd-gsd-delivery-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/status/ahloa/site",
        alias="AHLOA_MILESTONE_API_URL",
    )

    nas_milestone_api_url: str = Field(
        default="https://pm-copilot-kg-consume-osdp-gsd-gsd-delivery-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/status/nas/site",
        alias="NAS_MILESTONE_API_URL",
    )

    kg_workflow_information_api: str = Field(
        default="https://pm-copilot-kg-consume-osdp-gsd-gsd-delivery-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/Graph Traversal/extract_ahloa",
        alias="KG_WORKFLOW_INFORMATION_API_URL",
    )

    nl_sql_api_url: str = Field(
        default="https://pm-copilot-macro-aiassistant3-osdp-gsd-gsd-delivery-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/agents/ai-insight-plugin",
        alias="NL_SQL_API_URL",
    )
    nl_sql_api_timeout: int = Field(default=180, alias="NL_SQL_API_TIMEOUT")

    @property
    def target_table_qualified(self) -> str:
        """Schema-qualified, double-quoted identifier for safe SQL usage."""
        return f'"{self.target_table_schema}"."{self.target_table_name}"'


class APIServerSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="API_", extra="ignore")
    host: str = "0.0.0.0"
    port: int = 8000
    workers: int = 2


class ObservabilitySettings(BaseSettings):
    model_config = SettingsConfigDict(extra="ignore")
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = Field(
        default="INFO", alias="LOG_LEVEL"
    )
    log_format: Literal["json", "console", "text", "color"] = Field(
        default="color", alias="LOG_FORMAT"
    )
    log_file: Path | None = Field(default=None, alias="LOG_FILE")
    metrics_enabled: bool = Field(default=True, alias="METRICS_ENABLED")
    metrics_port: int = Field(default=9090, alias="METRICS_PORT")


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    app_env: Literal["development", "staging", "production"] = Field(
        default="development", alias="APP_ENV"
    )

    azure_openai: AzureOpenAISettings = Field(default_factory=AzureOpenAISettings)
    postgres: PostgresSettings = Field(default_factory=PostgresSettings)
    semantic: SemanticAPISettings = Field(default_factory=SemanticAPISettings)
    agent: AgentSettings = Field(default_factory=AgentSettings)
    api: APIServerSettings = Field(default_factory=APIServerSettings)
    observability: ObservabilitySettings = Field(default_factory=ObservabilitySettings)

    @property
    def is_production(self) -> bool:
        return self.app_env == "production"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    load_dotenv(encoding="utf-8")
    return Settings()  # type: ignore[call-arg]