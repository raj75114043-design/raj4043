"""Semantic context API client package."""

from risk_agent.semantic.client import SemanticClient

__all__ = ["SemanticClient"]
