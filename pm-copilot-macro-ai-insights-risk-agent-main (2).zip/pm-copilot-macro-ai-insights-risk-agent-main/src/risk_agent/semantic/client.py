"""Semantic context API client with resilience and error handling."""

from __future__ import annotations

import socket
from typing import Any

import httpx
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from risk_agent.config import get_settings
from risk_agent.models import SemanticResponse
from risk_agent.utils.exceptions import SemanticAPIError
from risk_agent.utils.logging import get_logger

_logger = get_logger(__name__)


class SemanticClient:
    """Async client for the semantic context API."""

    def __init__(self, client: httpx.AsyncClient | None = None) -> None:
        self._settings = get_settings().semantic
        self._owns_client = client is None
        self._client = client or self._build_client()

    def _build_client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            timeout=httpx.Timeout(30),
            follow_redirects=True,  # ✅ handles 307 safely
        )

    async def __aenter__(self) -> SemanticClient:
        return self

    async def __aexit__(self, *exc_info: Any) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    @retry(
        reraise=True,
        retry=retry_if_exception_type((httpx.TransportError, httpx.HTTPStatusError)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
    )
    async def search(
        self,
        query: str,
        top_k: int = 5,
        table: str = "kpi",
    ) -> SemanticResponse:
        """Call the semantic API with a natural-language query.

        Retries up to 3 times on transport errors (DNS, connection timeouts, etc.)
        with exponential backoff.

        ``table`` selects which semantic source to query — "kpi", "keywords",
        or "question_bank". The backend response shape is unified across
        tables (extra fields pass through via ``extra="allow"``).
        """

        payload = {"query": query, "top_k": top_k, "table": table}

        _logger.info(
            "semantic_search_request",
            query=query,
            top_k=top_k,
            table=table,
            endpoint=self._settings.api_url,
        )

        try:
            # ✅ Use full URL directly (important fix)
            response = await self._client.post(
                self._settings.api_url.rstrip("/"),  # avoid trailing slash redirect
                json=payload,
            )
            response.raise_for_status()

        except httpx.ConnectError as exc:
            # Specific handling for connection errors (includes DNS failures)
            error_msg = str(exc)
            if "getaddrinfo failed" in error_msg or "Name or service not known" in error_msg:
                _logger.error(
                    "semantic_search_dns_error",
                    endpoint=self._settings.api_url,
                    error=error_msg,
                    hint="Check if the endpoint is reachable and DNS is resolving correctly",
                )
            else:
                _logger.error(
                    "semantic_search_connection_error",
                    endpoint=self._settings.api_url,
                    error=error_msg,
                )
            raise

        except httpx.TimeoutException as exc:
            _logger.error(
                "semantic_search_timeout",
                endpoint=self._settings.api_url,
                timeout_seconds=30,
                error=str(exc),
            )
            raise

        except httpx.HTTPStatusError as exc:
            _logger.error(
                "semantic_search_http_error",
                endpoint=self._settings.api_url,
                status=exc.response.status_code,
                body=exc.response.text[:500],
            )
            raise

        except httpx.TransportError as exc:
            _logger.error(
                "semantic_search_transport_error",
                endpoint=self._settings.api_url,
                error=str(exc),
            )
            raise

        try:
            parsed = SemanticResponse.model_validate(response.json())
        except Exception as exc:
            _logger.error("semantic_search_invalid_response", error=str(exc))
            raise SemanticAPIError(f"Invalid semantic API response: {exc}") from exc

        # ✅ Safe fallback if min_score not defined
        min_score = getattr(self._settings, "min_score", 0.0)

        filtered = [r for r in parsed.results if r.similarity_score >= min_score]

        parsed = parsed.model_copy(
            update={
                "results": filtered,
                "total_results": len(filtered),
            }
        )

        _logger.info(
            "semantic_search_response",
            query=query,
            table=table,
            total_results=parsed.total_results,
            min_score=min_score,
        )

        return parsed

    @retry(
        reraise=True,
        retry=retry_if_exception_type((httpx.TransportError, httpx.HTTPStatusError)),
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
    )
    async def search_keywords(
        self,
        query: str,
        top_k: int = 5,
    ) -> SemanticResponse:
        """Call the dedicated keywords search endpoint.

        Uses /api/v1/semantic/keywords/search instead of the generic search
        endpoint — payload has no ``table`` field.
        """
        endpoint = self._settings.keywords_api_url.rstrip("/")
        payload = {"query": query, "top_k": top_k}

        _logger.info(
            "semantic_keywords_search_request",
            query=query,
            top_k=top_k,
            endpoint=endpoint,
        )

        try:
            response = await self._client.post(endpoint, json=payload)
            response.raise_for_status()
        except httpx.ConnectError as exc:
            error_msg = str(exc)
            if "getaddrinfo failed" in error_msg or "Name or service not known" in error_msg:
                _logger.error(
                    "semantic_keywords_search_dns_error",
                    endpoint=endpoint,
                    error=error_msg,
                )
            else:
                _logger.error(
                    "semantic_keywords_search_connection_error",
                    endpoint=endpoint,
                    error=error_msg,
                )
            raise
        except httpx.TimeoutException as exc:
            _logger.error(
                "semantic_keywords_search_timeout",
                endpoint=endpoint,
                timeout_seconds=30,
                error=str(exc),
            )
            raise
        except httpx.HTTPStatusError as exc:
            _logger.error(
                "semantic_keywords_search_http_error",
                endpoint=endpoint,
                status=exc.response.status_code,
                body=exc.response.text[:500],
            )
            raise
        except httpx.TransportError as exc:
            _logger.error(
                "semantic_keywords_search_transport_error",
                endpoint=endpoint,
                error=str(exc),
            )
            raise

        try:
            parsed = SemanticResponse.model_validate(response.json())
        except Exception as exc:
            _logger.error("semantic_keywords_search_invalid_response", error=str(exc))
            raise SemanticAPIError(f"Invalid keywords API response: {exc}") from exc

        min_score = getattr(self._settings, "min_score", 0.0)
        filtered = [r for r in parsed.results if r.similarity_score >= min_score]
        parsed = parsed.model_copy(
            update={"results": filtered, "total_results": len(filtered)}
        )

        _logger.info(
            "semantic_keywords_search_response",
            query=query,
            total_results=parsed.total_results,
            min_score=min_score,
        )
        return parsed

    async def health_check(self) -> dict[str, Any]:
        """Check connectivity and configuration of the semantic API endpoint.
        
        Returns:
            Dictionary with keys:
            - "ok": bool - True if endpoint is reachable
            - "endpoint": str - The configured endpoint URL
            - "error": str (optional) - Error message if unreachable
        """
        endpoint = self._settings.api_url
        try:
            _logger.info("semantic_health_check_start", endpoint=endpoint)
            response = await self._client.head(endpoint, timeout=httpx.Timeout(5))
            response.raise_for_status()
            _logger.info("semantic_health_check_ok", endpoint=endpoint)
            return {
                "ok": True,
                "endpoint": endpoint,
                "status_code": response.status_code,
            }
        except httpx.ConnectError as exc:
            error_msg = str(exc)
            if "getaddrinfo failed" in error_msg:
                msg = f"DNS resolution failed for {endpoint}: {error_msg}"
            else:
                msg = f"Connection failed to {endpoint}: {error_msg}"
            _logger.error("semantic_health_check_failed", message=msg)
            return {"ok": False, "endpoint": endpoint, "error": msg}
        except httpx.TimeoutException as exc:
            msg = f"Health check timed out after 5s for {endpoint}"
            _logger.error("semantic_health_check_timeout", message=msg)
            return {"ok": False, "endpoint": endpoint, "error": msg}
        except Exception as exc:
            msg = f"Health check error for {endpoint}: {exc}"
            _logger.error("semantic_health_check_error", message=msg)
            return {"ok": False, "endpoint": endpoint, "error": msg}