"""FastAPI server exposing the risk agent over HTTP."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any, Literal

ProjectFilter = Literal["AHLOA", "NTM", "NAS"]

import asyncio

from fastapi import BackgroundTasks, Body, FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, Response
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest
from pydantic import BaseModel

from risk_agent.config import get_settings
from risk_agent.core import RiskCatalog
from risk_agent.db import close_pool, init_pool, load_schema
from risk_agent.models import RiskReport
from risk_agent.orchestrator import RiskAgentOrchestrator
from risk_agent.utils.exceptions import RiskCatalogError
from risk_agent.utils.logging import configure_logging, get_logger

_logger = get_logger(__name__)


# --------------------------------------------------------------------------- #
# Application lifespan
# --------------------------------------------------------------------------- #


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    configure_logging()
    _logger.info("api.startup")

    settings = get_settings()

    # Initialize the async Postgres pool and pre-load schema.
    await init_pool()
    try:
        await load_schema()
    except Exception as exc:
        _logger.warning("api.schema_preload_failed", error=str(exc))

    # Load the Excel catalog if present.
    catalog: RiskCatalog | None
    try:
        catalog = RiskCatalog.from_excel(settings.agent.risk_catalog_path)
    except RiskCatalogError as exc:
        _logger.warning("api.catalog_missing", error=str(exc))
        catalog = None

    app.state.catalog = catalog
    app.state.orchestrator = RiskAgentOrchestrator()

    # Ensure SQLite store tables exist (idempotent)
    try:
        from risk_agent.db.store import ensure_tables_exist
        await ensure_tables_exist()
    except Exception as exc:
        _logger.warning("api.store_init_failed", error=str(exc))

    try:
        from risk_agent.db.chat_store import ensure_chat_tables_exist
        await ensure_chat_tables_exist()
    except Exception as exc:
        _logger.warning("api.chat_store_init_failed", error=str(exc))

    try:
        yield
    finally:
        _logger.info("api.shutdown")
        await close_pool()


app = FastAPI(
    title="Risk Identification Agent",
    version="1.0.0",
    description="LangGraph-based risk identification and mitigation agent.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# --------------------------------------------------------------------------- #
# Request / response models
# --------------------------------------------------------------------------- #


class RunByIdRequest(BaseModel):
    category_id: str


class ChatMessage(BaseModel):
    role: Literal["user", "assistant"]
    content: str


class ChatRequest(BaseModel):
    finding_id: str
    question: str
    history: list[ChatMessage] = []


class ChatResponse(BaseModel):
    finding_id: str
    answer: str


class RunAllResponse(BaseModel):
    total_categories: int
    succeeded: int
    failed: int
    reports: list[RiskReport]
    errors: dict[str, str]


class RiskFindingSummary(BaseModel):
    """Minimal risk finding for list view."""
    finding_id: str
    category_id: str
    risk: str
    description: str | None
    likelihood: str | None
    impact: str | None
    severity: str | None
    region: str | None
    project: str | None
    impacted_sites_count: int | None
    area_tags: list[str]
    market_tags: list[str]
    detected_at: str | None
    action_owner: str | None
    status: str
    disabled: bool
    liked: bool
    disliked: bool
    acknowledged: bool
    muted: bool
    feedback: str | None


class RiskFindingDetail(BaseModel):
    """Full risk finding details for drill-down view."""
    finding_id: str
    category_id: str
    risk: str
    description: str | None
    root_cause: str | None
    likelihood: str | None
    impact: str | None
    severity: str | None
    region: str | None
    project: str | None
    impacted_sites_count: int | None
    area_tags: list[str]
    market_tags: list[str]
    mitigation_actions: list | dict | None
    recovery_plan: list | dict | None
    drill_down_tables: list | dict | None
    detected_at: str | None
    action_owner: str | None
    status: str
    disabled: bool


class FindingDisableRequest(BaseModel):
    disabled: bool


class RiskKPIs(BaseModel):
    """Risk findings KPIs."""
    project: str | None
    total_risks: int
    critical_severity_count: int
    high_severity_count: int
    medium_severity_count: int
    low_severity_count: int


class HighchartsPieData(BaseModel):
    """Data point for Highcharts pie chart."""
    name: str
    y: int


class HighchartsPieSeries(BaseModel):
    """Series configuration for Highcharts pie chart."""
    name: str
    colorByPoint: bool
    data: list[HighchartsPieData]


class HighchartsPieChart(BaseModel):
    """Complete Highcharts pie chart configuration."""
    chart: dict[str, Any]
    title: dict[str, str]
    tooltip: dict[str, Any]
    subtitle: dict[str, str]
    plotOptions: dict[str, Any]
    series: list[HighchartsPieSeries]


class InteractionResponse(BaseModel):
    interaction_id: str
    finding_id: str
    user_id: str
    liked: bool
    disliked: bool
    acknowledged: bool
    muted: bool
    feedback: str | None
    created_at: str | None
    updated_at: str | None


class LikeRequest(BaseModel):
    feedback: str | None = None

    model_config = {"json_schema_extra": {"example": {"feedback": "string"}}}


class DislikeRequest(BaseModel):
    feedback: str


class FindingUpdateRequest(BaseModel):
    action_owner: str | None = None
    status: Literal["Open", "InProgress", "Closed"] | None = None


class GlobalChatRequest(BaseModel):
    question: str
    history: list[ChatMessage] = []
    user_id: str | None = None


class GlobalChatResponse(BaseModel):
    question: str
    answer: str
    history: list[ChatMessage]


class CreateSessionRequest(BaseModel):
    user_id: str
    project: ProjectFilter


class SessionResponse(BaseModel):
    session_id: str
    user_id: str
    project: str | None
    title: str | None
    created_at: str | None
    updated_at: str | None


class SessionChatRequest(BaseModel):
    question: str


class SessionChatResponse(BaseModel):
    session_id: str
    question: str
    answer: str


# --------------------------------------------------------------------------- #
# Endpoints
# --------------------------------------------------------------------------- #


@app.get("/", tags=["meta"])
async def root() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/health", tags=["meta"])
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/ready", tags=["meta"])
async def ready() -> dict[str, str]:
    try:
        # Cheap Postgres round-trip.
        from risk_agent.db import fetch_all  # local import to avoid circulars
        await fetch_all("SELECT 1 AS ok")
    except Exception as exc:
        raise HTTPException(status_code=503, detail=f"not ready: {exc}") from exc
    return {"status": "ready"}


@app.get("/metrics", tags=["meta"])
async def metrics() -> Response:
    return Response(content=generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.get("/categories", tags=["catalog"])
async def list_categories() -> JSONResponse:
    catalog: RiskCatalog | None = app.state.catalog
    if catalog is None:
        raise HTTPException(status_code=503, detail="Risk catalog not loaded")
    return JSONResponse(
        [c.model_dump() for c in catalog.all()]
    )


@app.post("/run", response_model=RiskReport, tags=["agent"])
async def run_by_id(req: RunByIdRequest) -> RiskReport:
    catalog: RiskCatalog | None = app.state.catalog
    if catalog is None:
        raise HTTPException(status_code=503, detail="Risk catalog not loaded")
    try:
        category = catalog.get(req.category_id)
    except RiskCatalogError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    orchestrator: RiskAgentOrchestrator = app.state.orchestrator
    report = await orchestrator.run(category)
    return report


@app.post("/run-all", response_model=RunAllResponse, tags=["agent"])
async def run_all_categories() -> RunAllResponse:
    """Run the risk agent for every category in the catalog sequentially."""
    catalog: RiskCatalog | None = app.state.catalog
    if catalog is None:
        raise HTTPException(status_code=503, detail="Risk catalog not loaded")

    orchestrator: RiskAgentOrchestrator = app.state.orchestrator
    categories = catalog.all()
    reports: list[RiskReport] = []
    errors: dict[str, str] = {}

    for category in categories:
        try:
            report = await orchestrator.run(category)
            reports.append(report)
            _logger.info("api.run_all.category_done", category_id=category.category_id, findings=len(report.findings))
        except Exception as exc:
            _logger.warning("api.run_all.category_failed", category_id=category.category_id, error=str(exc))
            errors[category.category_id] = str(exc)

    return RunAllResponse(
        total_categories=len(categories),
        succeeded=len(reports),
        failed=len(errors),
        reports=reports,
        errors=errors,
    )


@app.post("/run-project/{project}", response_model=RunAllResponse, tags=["agent"])
async def run_project_categories(project: ProjectFilter) -> RunAllResponse:
    """Run the risk agent for all categories belonging to a specific project (AHLOA, NTM, or NAS)."""
    from risk_agent.agents.planner import _detect_project

    catalog: RiskCatalog | None = app.state.catalog
    if catalog is None:
        raise HTTPException(status_code=503, detail="Risk catalog not loaded")

    categories = [c for c in catalog.all() if _detect_project(c.category_id) == project]
    if not categories:
        raise HTTPException(status_code=404, detail=f"No categories found for project '{project}'")

    orchestrator: RiskAgentOrchestrator = app.state.orchestrator
    reports: list[RiskReport] = []
    errors: dict[str, str] = {}

    for category in categories:
        try:
            report = await orchestrator.run(category)
            reports.append(report)
            _logger.info("api.run_project.category_done", project=project, category_id=category.category_id, findings=len(report.findings))
        except Exception as exc:
            _logger.warning("api.run_project.category_failed", project=project, category_id=category.category_id, error=str(exc))
            errors[category.category_id] = str(exc)

    return RunAllResponse(
        total_categories=len(categories),
        succeeded=len(reports),
        failed=len(errors),
        reports=reports,
        errors=errors,
    )


async def _run_kpi_analysis_task() -> None:
    from risk_agent.kpi_analysis import KPIAnalysisOrchestrator
    try:
        orchestrator = KPIAnalysisOrchestrator()
        await orchestrator.run()
    except Exception as exc:
        _logger.error("api.kpi_analysis.background_failed", error=str(exc))


@app.post("/kpi-analysis", tags=["agent"], status_code=202)
async def run_kpi_analysis(background_tasks: BackgroundTasks) -> JSONResponse:
    """Start KPI hierarchical trend analysis in the background.

    Returns immediately with 202 Accepted. Results are saved to the DB and
    can be retrieved via GET /risks?pipeline_type=kpi_trend once complete.
    """
    background_tasks.add_task(_run_kpi_analysis_task)
    return JSONResponse(
        status_code=202,
        content={"status": "accepted", "message": "KPI analysis started. Poll GET /risks?pipeline_type=kpi_trend for results."},
    )


# --------------------------------------------------------------------------- #
# Risk store endpoints
# --------------------------------------------------------------------------- #


@app.get("/risks", tags=["store"])
async def get_risks(
    pipeline_type: str | None = Query(default=None, description="excel | kpi_trend"),
    category_id: str | None = Query(default=None),
    risk_rating: str | None = Query(default=None, description="critical | high | medium | low"),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
) -> JSONResponse:
    """Paginated, filterable list of stored risk findings."""
    from risk_agent.db.store import fetch_all_findings
    findings = await fetch_all_findings(
        pipeline_type=pipeline_type,
        category_id=category_id,
        risk_rating=risk_rating,
        limit=limit,
        offset=offset,
    )
    return JSONResponse({"total": len(findings), "offset": offset, "findings": findings})


@app.get("/risks/{finding_id}", tags=["store"])
async def get_risk(finding_id: str) -> JSONResponse:
    """Full detail for a single stored finding."""
    from risk_agent.db.store import fetch_finding
    finding = await fetch_finding(finding_id)
    if finding is None:
        raise HTTPException(status_code=404, detail="Finding not found")
    return JSONResponse(finding)


@app.post("/chat", response_model=ChatResponse, tags=["chat"])
async def chat_about_risk(req: ChatRequest) -> ChatResponse:
    """Answer a question grounded on a specific risk finding.

    The LLM is given the full finding payload as context and answers the
    user's question. Prior turns can be passed via `history` so the
    conversation stays coherent across messages.
    """
    from risk_agent.core.llm import build_llm
    from risk_agent.db.store import fetch_finding

    finding = await fetch_finding(req.finding_id)
    if finding is None:
        raise HTTPException(status_code=404, detail="Finding not found")

    import json as _json

    # drill_down_tables and evidence carry full row dumps that can easily
    # blow past the LLM gateway's 272k-token prompt limit. Keep shape, drop bulk.
    HEAVY_FIELDS = ("drill_down_tables", "evidence")
    trimmed: dict[str, Any] = {k: v for k, v in finding.items() if k not in HEAVY_FIELDS}
    for k in HEAVY_FIELDS:
        v = finding.get(k)
        if isinstance(v, list):
            trimmed[k] = {
                "_summary": f"{len(v)} items omitted to fit context window",
                "sample": v[:2],
            }
        elif isinstance(v, dict):
            trimmed[k] = {
                "_summary": f"{len(v)} keys omitted to fit context window",
                "keys": list(v)[:10],
            }
        else:
            trimmed[k] = v

    finding_json = _json.dumps(trimmed, indent=2, default=str)

    MAX_CHARS = 200_000
    if len(finding_json) > MAX_CHARS:
        finding_json = finding_json[:MAX_CHARS] + "\n…[truncated to fit context window]"

    system_prompt = (
        "You are a risk analyst assistant for a telecom tower deployment program. "
        "Answer the user's question using ONLY the risk finding details below. "
        "If the answer is not contained in or directly inferable from the finding, "
        "say so plainly. Be concise, structured, and reference concrete fields "
        "(risk, root_cause, mitigation_actions, recovery_plan, evidence, "
        "drill_down_tables) when relevant.\n\n"
        f"RISK FINDING (finding_id={req.finding_id}):\n{finding_json}"
    )

    messages: list[dict[str, str]] = [{"role": "system", "content": system_prompt}]
    for turn in req.history:
        messages.append({"role": turn.role, "content": turn.content})
    messages.append({"role": "user", "content": req.question})

    llm = build_llm(role="generator")
    try:
        result = await llm.ainvoke(messages)
    except Exception as exc:
        _logger.error("api.chat.llm_failed", finding_id=req.finding_id, error=str(exc))
        raise HTTPException(status_code=502, detail=f"LLM call failed: {exc}") from exc

    answer = getattr(result, "content", None) or str(result)
    return ChatResponse(finding_id=req.finding_id, answer=answer)


@app.post("/global-chat", response_model=GlobalChatResponse, tags=["chat"])
async def global_chat(req: GlobalChatRequest) -> GlobalChatResponse:
    """Answer analytical questions about the entire risk findings dataset.

    The orchestrator is a ReAct agent that decides when to query the database
    and synthesizes the results into a human-readable answer. Chat history is
    stateless — pass back the `history` from the previous response to maintain
    conversation context.
    """
    from risk_agent.global_chat import GlobalChatOrchestrator

    orchestrator = GlobalChatOrchestrator()
    history_dicts = [m.model_dump() for m in req.history]

    try:
        answer = await orchestrator.run_chat(req.question, history_dicts)
    except Exception as exc:
        _logger.error("api.global_chat.failed", error=str(exc))
        raise HTTPException(status_code=502, detail=f"Chat pipeline failed: {exc}") from exc

    updated_history = req.history + [
        ChatMessage(role="user", content=req.question),
        ChatMessage(role="assistant", content=answer),
    ]
    return GlobalChatResponse(question=req.question, answer=answer, history=updated_history)


@app.post("/global-chat/session", response_model=SessionResponse, tags=["chat"])
async def create_chat_session(req: CreateSessionRequest) -> JSONResponse:
    """Create a new persistent chat session scoped to a specific project.

    The `project` field locks the session to that project's risks — the chatbot will
    only answer questions about risks belonging to the chosen project.
    """
    from risk_agent.db.chat_store import create_session
    session = await create_session(req.user_id, project=req.project)
    return JSONResponse(session)


@app.post("/global-chat/{session_id}", response_model=SessionChatResponse, tags=["chat"])
async def session_chat(session_id: str, req: SessionChatRequest) -> JSONResponse:
    """Send a question within a persistent session.

    History is loaded automatically from the database — no need to send it.
    The session's project scope is enforced automatically: the chatbot only answers
    questions about risks belonging to the project the session was created for.
    """
    from risk_agent.db.chat_store import fetch_session
    from risk_agent.global_chat import GlobalChatOrchestrator

    session = await fetch_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")

    project: str | None = session.get("project")
    orchestrator = GlobalChatOrchestrator()
    try:
        answer = await orchestrator.run_chat_with_session(req.question, session_id, project=project)
    except Exception as exc:
        _logger.error("api.session_chat.failed", session_id=session_id, error=str(exc))
        raise HTTPException(status_code=502, detail=f"Chat pipeline failed: {exc}") from exc

    return JSONResponse({"session_id": session_id, "question": req.question, "answer": answer})


@app.get("/global-chat/{session_id}/history", tags=["chat"])
async def get_session_history(session_id: str) -> JSONResponse:
    """Return the full message history for a chat session."""
    from risk_agent.db.chat_store import fetch_session, fetch_session_messages

    session = await fetch_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail="Session not found")

    messages = await fetch_session_messages(session_id)
    return JSONResponse({"session_id": session_id, "title": session.get("title"), "messages": messages})


@app.delete("/global-chat/session/{session_id}", tags=["chat"], status_code=200)
async def delete_chat_session(session_id: str) -> JSONResponse:
    """Delete a chat session and all its messages permanently."""
    from risk_agent.db.chat_store import delete_session

    deleted = await delete_session(session_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Session not found")
    return JSONResponse({"deleted": True, "session_id": session_id})


@app.get("/global-chat/sessions/{user_id}", tags=["chat"])
async def list_user_sessions(user_id: str) -> JSONResponse:
    """List all chat sessions for a user, ordered by most recently updated."""
    from risk_agent.db.chat_store import list_sessions
    sessions = await list_sessions(user_id)
    return JSONResponse({"user_id": user_id, "sessions": sessions})


@app.get("/reports", tags=["store"])
async def get_reports(
    pipeline_type: str | None = Query(default=None, description="excel | kpi_trend"),
    limit: int = Query(default=50, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
) -> JSONResponse:
    """Paginated list of stored report metadata (no findings payload)."""
    from risk_agent.db.store import fetch_all_reports
    reports = await fetch_all_reports(pipeline_type=pipeline_type, limit=limit, offset=offset)
    return JSONResponse({"total": len(reports), "offset": offset, "reports": reports})


@app.get("/reports/{report_id}", tags=["store"])
async def get_report(report_id: str) -> JSONResponse:
    """Full report including all findings."""
    from risk_agent.db.store import fetch_report
    report = await fetch_report(report_id)
    if report is None:
        raise HTTPException(status_code=404, detail="Report not found")
    return JSONResponse(report)


# --------------------------------------------------------------------------- #
# Risk findings endpoints (paginated list and detail views)
# --------------------------------------------------------------------------- #


@app.get("/findings", response_model=dict, tags=["findings"])
async def get_findings_list(
    project: ProjectFilter | None = Query(default=None, description="Optional project filter: AHLOA | NTM | NAS"),
    category_id: str | None = Query(default=None, description="Optional filter by category_id"),
    user_id: str | None = Query(default=None, description="Optional user_id to include interaction state"),
    risk_rating: str | None = Query(default=None, description="Filter by risk rating: critical | high | medium | low"),
    likelihood: str | None = Query(default=None, description="Filter by likelihood: unlikely | may_happen | likely"),
    impact: str | None = Query(default=None, description="Filter by impact: minor | major | critical"),
    region: str | None = Query(default=None, description="Filter by region name"),
    area: str | None = Query(default=None, description="Filter by impacted area name (exact match within area_tags)"),
    market: str | None = Query(default=None, description="Filter by impacted market name (exact match within market_tags)"),
    limit: int = Query(default=10, ge=1, le=50, description="Page size (default 10, max 50)"),
    offset: int = Query(default=0, ge=0, description="Pagination offset"),
) -> JSONResponse:
    """Paginated list of risk findings with optional filters including region, area and market tags."""
    from risk_agent.db.store import fetch_findings_summary
    result = await fetch_findings_summary(
        project=project,
        category_id=category_id,
        user_id=user_id,
        risk_rating=risk_rating,
        likelihood=likelihood,
        impact=impact,
        region=region,
        area=area,
        market=market,
        limit=limit,
        offset=offset,
    )
    return JSONResponse({
        "total": result["total"],
        "limit": limit,
        "offset": offset,
        "findings": result["findings"],
    })


@app.get("/findings/{finding_id}", response_model=RiskFindingDetail, tags=["findings"])
async def get_finding_detail(finding_id: str) -> JSONResponse:
    """Get detailed information about a specific risk finding."""
    from risk_agent.db.store import fetch_finding_detail
    finding = await fetch_finding_detail(finding_id)
    if finding is None:
        raise HTTPException(status_code=404, detail="Finding not found")
    return JSONResponse(finding)


@app.patch("/findings/{finding_id}", response_model=RiskFindingSummary, tags=["findings"])
async def update_finding(finding_id: str, req: FindingUpdateRequest) -> JSONResponse:
    """Update action_owner and/or status for a finding. Accepted status values: Open | InProgress | Closed."""
    from risk_agent.db.store import update_finding as _update_finding
    kwargs: dict[str, Any] = {}
    if req.action_owner is not None or "action_owner" in req.model_fields_set:
        kwargs["action_owner"] = req.action_owner
    if req.status is not None:
        kwargs["status"] = req.status
    finding = await _update_finding(finding_id=finding_id, **kwargs)
    if finding is None:
        raise HTTPException(status_code=404, detail="Finding not found")
    return JSONResponse(finding)


@app.patch("/findings/{finding_id}/disable", response_model=RiskFindingSummary, tags=["findings"])
async def disable_finding(finding_id: str, req: FindingDisableRequest) -> JSONResponse:
    """Enable or disable a finding. Disabled findings are hidden from all list, KPI, and chart endpoints."""
    from risk_agent.db.store import set_finding_disabled
    finding = await set_finding_disabled(finding_id=finding_id, disabled=req.disabled)
    if finding is None:
        raise HTTPException(status_code=404, detail="Finding not found")
    return JSONResponse(finding)


class ShuffleSeedRequest(BaseModel):
    seed: float


@app.get("/settings/shuffle", tags=["settings"])
async def get_shuffle_settings() -> JSONResponse:
    """Return current shuffle configuration (enabled flag and seed value)."""
    from risk_agent.db.store import get_shuffle_config
    return JSONResponse(get_shuffle_config())


@app.post("/settings/shuffle-seed", tags=["settings"])
async def update_shuffle_seed(req: ShuffleSeedRequest) -> JSONResponse:
    """Update the shuffle seed at runtime (range: -1.0 to 1.0). Takes effect immediately without restart."""
    from risk_agent.db.store import set_shuffle_seed
    new_seed = set_shuffle_seed(req.seed)
    return JSONResponse({"shuffle_seed": new_seed})


@app.get("/kpis", response_model=RiskKPIs, tags=["kpis"])
async def get_risk_kpis(
    project: ProjectFilter | None = Query(default=None, description="Optional project filter: AHLOA | NTM | NAS"),
    region: str | None = Query(default=None, description="Filter by region name"),
    area: str | None = Query(default=None, description="Filter by impacted area name"),
    market: str | None = Query(default=None, description="Filter by impacted market name"),
) -> JSONResponse:
    """Get risk findings KPIs scoped by optional project, region, area, or market."""
    from risk_agent.db.store import fetch_risk_kpis
    kpis = await fetch_risk_kpis(project=project, region=region, area=area, market=market)
    return JSONResponse(kpis)


@app.get("/charts/risk-heatmap", tags=["charts"])
async def get_risk_heatmap(
    project: ProjectFilter | None = Query(default=None, description="Optional project filter: AHLOA | NTM | NAS"),
    region: str | None = Query(default=None, description="Filter by region name"),
    area: str | None = Query(default=None, description="Filter by impacted area name"),
    market: str | None = Query(default=None, description="Filter by impacted market name"),
) -> JSONResponse:
    """Risk findings aggregated into a 3x3 likelihood × impact heatmap grid.

    Each cell contains the risk_rating label and findings broken down by category with counts.
    All 9 cells are always returned, even if empty.
    """
    from risk_agent.db.store import fetch_risk_heatmap
    from risk_agent.models.domain import RiskLikelihood, RiskImpact
    heatmap = await fetch_risk_heatmap(project=project, region=region, area=area, market=market)
    return JSONResponse({
        "likelihood_values": [l.value for l in RiskLikelihood],
        "impact_values": [i.value for i in RiskImpact],
        "heatmap": heatmap,
    })


@app.get("/charts/risk-distribution-data", tags=["charts"])
async def get_risk_distribution_data(
    project: ProjectFilter | None = Query(default=None, description="Optional project filter: AHLOA | NTM | NAS"),
    region: str | None = Query(default=None, description="Filter by region name"),
    area: str | None = Query(default=None, description="Filter by impacted area name"),
    market: str | None = Query(default=None, description="Filter by impacted market name"),
) -> JSONResponse:
    """Risk distribution by category as raw data, with optional geo filters."""
    from risk_agent.db.store import fetch_risk_distribution
    data = await fetch_risk_distribution(project=project, region=region, area=area, market=market)
    return JSONResponse(data)


@app.get("/charts/risk-distribution", response_model=HighchartsPieChart, tags=["charts"])
async def get_risk_distribution_chart(
    project: ProjectFilter | None = Query(default=None, description="Optional project filter: AHLOA | NTM | NAS"),
    region: str | None = Query(default=None, description="Filter by region name"),
    area: str | None = Query(default=None, description="Filter by impacted area name"),
    market: str | None = Query(default=None, description="Filter by impacted market name"),
) -> JSONResponse:
    """Get risk distribution by category in Highcharts pie chart format, with optional geo filters."""
    from risk_agent.db.store import fetch_risk_distribution_by_category
    chart_data = await fetch_risk_distribution_by_category(project=project, region=region, area=area, market=market)
    return JSONResponse(chart_data)


# --------------------------------------------------------------------------- #
# Interaction endpoints
# --------------------------------------------------------------------------- #


@app.post("/interactions/like/{finding_id}", response_model=InteractionResponse, tags=["interactions"])
async def like_finding(finding_id: str, user_id: str = Query(...), req: LikeRequest = Body(default=LikeRequest())) -> JSONResponse:
    """Toggle liked. If already liked and feedback provided, updates feedback without toggling."""
    from risk_agent.db.store import toggle_liked
    return JSONResponse(await toggle_liked(finding_id=finding_id, user_id=user_id, feedback=req.feedback))


@app.post("/interactions/dislike/{finding_id}", response_model=InteractionResponse, tags=["interactions"])
async def dislike_finding(finding_id: str, user_id: str = Query(...), req: DislikeRequest = Body(...)) -> JSONResponse:
    """Toggle disliked. If already disliked and feedback provided, updates feedback without toggling."""
    from risk_agent.db.store import toggle_disliked
    return JSONResponse(await toggle_disliked(finding_id=finding_id, user_id=user_id, feedback=req.feedback))


@app.post("/interactions/acknowledge/{finding_id}", response_model=InteractionResponse, tags=["interactions"])
async def acknowledge_finding(finding_id: str, user_id: str = Query(...)) -> JSONResponse:
    """Toggle acknowledged state for a finding."""
    from risk_agent.db.store import toggle_acknowledged
    return JSONResponse(await toggle_acknowledged(finding_id=finding_id, user_id=user_id))


@app.post("/interactions/mute/{finding_id}", response_model=InteractionResponse, tags=["interactions"])
async def mute_finding(finding_id: str, user_id: str = Query(...)) -> JSONResponse:
    """Toggle muted state for a finding."""
    from risk_agent.db.store import toggle_muted
    return JSONResponse(await toggle_muted(finding_id=finding_id, user_id=user_id))


@app.get("/interactions/user/{user_id}", tags=["interactions"])
async def get_user_interactions(user_id: str) -> JSONResponse:
    """Get all interactions for a user across all findings."""
    from risk_agent.db.store import fetch_user_interactions
    interactions = await fetch_user_interactions(user_id=user_id)
    return JSONResponse({"user_id": user_id, "interactions": interactions})


@app.get("/findings/user/{user_id}/muted", tags=["findings"])
async def get_muted_findings(
    user_id: str,
    project: ProjectFilter | None = Query(default=None, description="Optional project filter: AHLOA | NTM | NAS"),
    region: str | None = Query(default=None, description="Filter by region name"),
    area: str | None = Query(default=None, description="Filter by impacted area name"),
    market: str | None = Query(default=None, description="Filter by impacted market name"),
) -> JSONResponse:
    """Get all findings muted by a user, with optional region/area/market filters."""
    from risk_agent.db.store import fetch_muted_findings
    findings = await fetch_muted_findings(user_id=user_id, project=project, region=region, area=area, market=market)
    return JSONResponse({"user_id": user_id, "findings": findings})


@app.get("/findings/user/{user_id}/acknowledged", tags=["findings"])
async def get_acknowledged_findings(
    user_id: str,
    project: ProjectFilter | None = Query(default=None, description="Optional project filter: AHLOA | NTM | NAS"),
    region: str | None = Query(default=None, description="Filter by region name"),
    area: str | None = Query(default=None, description="Filter by impacted area name"),
    market: str | None = Query(default=None, description="Filter by impacted market name"),
) -> JSONResponse:
    """Get all findings acknowledged by a user, with optional region/area/market filters."""
    from risk_agent.db.store import fetch_acknowledged_findings
    findings = await fetch_acknowledged_findings(user_id=user_id, project=project, region=region, area=area, market=market)
    return JSONResponse({"user_id": user_id, "findings": findings})

