"""Prompt templates for the geo-hierarchical analysis nodes.

Two prompt families:
  1. GEO SQL GENERATOR — asks the LLM to produce 4 parameterised SQL templates
     (region / area / market / site) grounded in the category's risk logic and
     the target table schema.
  2. GEO ANALYZER — asks the LLM to flag anomalous geo units at a given level,
     optionally with parent-level context (relaxed thresholds when parent flagged).
"""

from __future__ import annotations

from typing import Any

from risk_agent.models.domain import GeoFinding, RiskCategory


# ===========================================================================
# GEO SQL GENERATOR
# ===========================================================================

GEO_SQL_GENERATOR_SYSTEM = """You are a senior data engineer generating geo-hierarchical SQL templates for a risk analysis pipeline.

You will receive:
  - A risk category (name, description, identification logic, decision rules)
  - The target Postgres table schema (single table — use ONLY these columns)
  - A business context block describing the project's phases and columns
  - A list of flat traversal steps already planned for this category (metric hints)

Your task: produce EXACTLY 4 SQL templates to support a Region → Area → Market → Site drill-down.

GEOGRAPHIC COLUMNS (always present in the target table):
  - rgn_region  — region name     (use as group-by or filter at region level)
  - m_area      — area name       (use as group-by or filter at area level)
  - m_market    — market name     (use as group-by or filter at market level)

PARAMETERISATION RULES:
  - region_sql: NO parameters — aggregates ALL regions in one query.
  - area_sql:   filter WHERE rgn_region = :region
  - market_sql: filter WHERE m_area = :area
  - site_sql:   filter WHERE m_market = :market

ALWAYS add:  WHERE ... AND pj_project_status NOT ILIKE 'complet%'
to exclude completed sites unless the risk is specifically about completed sites.

CONTENT RULES:
  - region_sql / area_sql / market_sql: aggregate the most risk-relevant metrics.
    Include COUNT(*) AS total_sites plus aggregates (SUM, AVG, COUNT FILTER) of
    the key columns identified by the category's identification logic and decision
    rules. Order by the "worst" metric (most risky first).
  - site_sql: return individual row columns — site ID, site name, geo columns,
    the metric columns that breach the rule (with their values), and any
    comment / remark / notes columns from the schema. Add a WHERE clause that
    filters for the breach condition from the category's decision rules.
    Add LIMIT 200.
  - SCHEMA COLUMNS ONLY — ZERO TOLERANCE FOR INVENTED NAMES:
    Before writing any column name, verify it exists VERBATIM in the
    "Target Table Schema" block in the user message. Do not infer, guess,
    or derive column names from the risk description or business logic.
    Common failure patterns to avoid:
      ✗ risk_bucket, delay_category, milestone_status, overdue_flag
    If a concept does not exist as a column, express it as a SQL expression
    using ONLY real schema columns and give it an alias.
  - Do NOT add LIMIT to region / area / market SQL — the executor wraps them.
  - All 4 SQL strings must be valid Postgres SELECT statements.
  - Cast numeric aggregates; COALESCE nullable columns where appropriate.

COLUMN NAMING CONVENTION — PLANNED vs ACTUAL DATES
The target table follows a strict pattern for milestone date columns:

  pj_p_<number>_<milestone_name>_finish  →  PLANNED date
  pj_a_<number>_<milestone_name>_finish  →  ACTUAL  date

  Examples:
    pj_p_5270_integration_start_finish / pj_a_5270_integration_start_finish
    pj_p_4635_battery_install_finish   / pj_a_4635_battery_install_finish

  The same 4-digit number and milestone name always appear in both columns —
  they are always a pair. This pattern applies to every milestone column in
  the schema.

  In aggregate SQL (region / area / market):
    - Use COUNT(*) FILTER (WHERE pj_a_<n>_<name>_finish IS NULL
                             AND pj_p_<n>_<name>_finish IS NOT NULL)
      to count sites where a planned milestone has no actual (i.e. overdue).
    - Use AVG(EXTRACT(DAY FROM (CURRENT_DATE - pj_p_<n>_<name>_finish)))
      FILTER (WHERE pj_a_<n>_<name>_finish IS NULL)
      to show average days overdue across sites.

  In site_sql:
    - Always SELECT both the planned and actual column together.
    - Add EXTRACT(DAY FROM (CURRENT_DATE - pj_p_<n>_<name>_finish)) AS days_overdue
      for columns where actual is NULL, so the PM can see the overdue count.

OUTPUT: raw JSON only — no Markdown fences, no commentary.
{
  "region_sql": "SELECT rgn_region, COUNT(*) AS total_sites, ... FROM ... WHERE ... GROUP BY rgn_region ORDER BY ...",
  "area_sql":   "SELECT m_area, COUNT(*) AS total_sites, ... FROM ... WHERE rgn_region = :region AND ... GROUP BY m_area",
  "market_sql": "SELECT m_market, COUNT(*) AS total_sites, ... FROM ... WHERE m_area = :area AND ... GROUP BY m_market",
  "site_sql":   "SELECT ... FROM ... WHERE m_market = :market AND ... LIMIT 200"
}
"""


def build_geo_sql_prompt(
    category: RiskCategory,
    business_context: str | None,
    table_schema: str,
    table_fqn: str,
    validated_steps_text: str,
    mandatory_filter: str = "(none — no mandatory filter for this project)",
) -> tuple[str, str]:
    """Return (system_prompt, user_prompt) for the geo SQL generator."""
    user = f"""# Risk Category
category_id: {category.category_id}
name: {category.name}
description: {category.description}

## Identification Logic
{category.identification_logic}

## Decision Rules
{chr(10).join(f"- {r}" for r in category.decision_rules) or "(none)"}

# Mandatory SQL Filter (REQUIRED — include in EVERY WHERE clause without exception)
{mandatory_filter}

# Business Context
{business_context or "(none — unknown project)"}

# Target Table Schema (AUTHORITATIVE — use only these columns)
Fully-qualified name: {table_fqn}

{table_schema}

# Flat Traversal Steps (already planned — use as metric hints)
{validated_steps_text or "(none)"}

# Task
Generate 4 parameterised SQL templates as described in the system prompt.
Output raw JSON only.
"""
    return GEO_SQL_GENERATOR_SYSTEM, user


# ===========================================================================
# GEO ANALYZER
# ===========================================================================

GEO_ANALYZER_SYSTEM = """You are a geo-hierarchical risk analyzer for a telecom tower deployment program.

You receive aggregated rows from a single SQL query for a specific geographic level (region / area / market)
and you must decide which geo units show anomalous behavior for the given risk category.

═══════════════════════════════════════════════════════
DETECTION RULES (apply in order)
═══════════════════════════════════════════════════════

STEP 1 — DIRECTION
  Infer the "bad direction" for each metric from the category's identification_logic
  and decision_rules (e.g., high count of missing dates = bad; low run rate = bad).
  Do NOT flag a metric in the wrong direction.

STEP 2 — SUSTAINED DEVIATION
  Compare the latest value for each geo unit against peer units at the same level.
  Flag a geo unit if its value is ≥10% worse than the peer average in the bad direction,
  and the deviation is not a single-row spike.

STEP 3 — SLA / THRESHOLD CHECK
  If the category's decision_rules specify a numeric threshold or SLA target,
  flag any geo unit at or approaching that threshold (within 5% of breach).

STEP 4 — FALLBACK
  If no numeric threshold is specified, flag geo units that deviate ≥15–25%
  from the peer average in the bad direction.

STEP 5 — PARENT CONTEXT (area and market levels only)
  If a PARENT unit has already been flagged as anomalous (provided in the prompt),
  apply RELAXED thresholds for sub-geographies under it:
    - Flag sub-geos that deviate ≥5% from siblings (instead of ≥10–25%).
    - Do NOT return an empty list for a level whose parent was flagged.
      Identify the most problematic sub-geography and flag it.

STEP 6 — PRECISION (MANDATORY — do this before writing any output)
  geo_code and geo_name MUST be copied CHARACTER-FOR-CHARACTER from the
  "Aggregated Data Rows" section in the user message.

  DO NOT abbreviate, shorten, trim, or rephrase geo names. Common violations:
    ✗ "WEST"        when the row value is "WEST region"   ← WRONG
    ✗ "South"       when the row value is "South Area"    ← WRONG
    ✗ "Dallas"      when the row value is "Dallas, TX"    ← WRONG
    ✗ "NE"          when the row value is "Northeast"     ← WRONG

  Before writing each geo_code / geo_name into your JSON output, locate the
  exact string for that unit in the data rows and paste it unchanged.
  If you cannot find an exact match in the rows, omit that finding entirely.

STEP 7 — EXCLUDE COMPLETED SITES
  The SQL already filters pj_project_status NOT ILIKE 'complet%'.
  If a row sneaks through, ignore it.

═══════════════════════════════════════════════════════
OUTPUT FORMAT
═══════════════════════════════════════════════════════
Return a JSON array of geo finding objects.
Return [] ONLY if there are genuinely NO anomalous units AND no parent was flagged.

[
  {
    "geo_level":        "region" | "area" | "market",
    "geo_code":         "<exact string from data rows — no abbreviation, no trimming>",
    "geo_name":         "<exact string from data rows — must match geo_code character-for-character>",
    "parent_geo_code":  "<parent geo_code or null>",
    "is_anomalous":     true,
    "metric_name":      "<the specific column driving the finding>",
    "summary":          "<1-2 sentence plain-English description of why this unit is anomalous>",
    "category_name":    "<risk category name>"
  }
]

No Markdown fences. No commentary outside the JSON array.
"""


# ===========================================================================
# NEW GEO ANALYSIS PROMPTS — percentage-based, one per geo level
# These replace the old GEO_ANALYZER_SYSTEM for the redesigned pipeline that
# works from pre-aggregated at_risk_count / total_active_count data.
# ===========================================================================

REGION_ANALYSIS_SYSTEM = """You are a senior risk analyst for telecom tower deployment projects.

You receive two raw SQL result sets. The column names were chosen by an AI SQL generator
and may vary (e.g. "Region", "rgn_region", "region_name"). Interpret the data correctly
regardless of column naming.

STEP 1 — IDENTIFY COLUMNS
Inspect the column headers and identify:
  - The REGION column (highest geographic level — covers the whole country in sections)
  - The COUNT column in the at-risk set (number of sites satisfying the risk condition)
  - The COUNT column in the total-active set (total active sites)

STEP 2 — AGGREGATE BY REGION
Sum at-risk counts per distinct region value. Sum total-active counts per distinct region value.
Compute: at_risk_pct = round(at_risk_count / total_active * 100, 1)

STEP 3 — FLAG AND SUMMARIZE
Flag a region as is_flagged=true if at_risk_count > 0.
Write a 1-2 sentence forward-looking summary per region (region level only — no area/market detail).
Use telecom domain terms: GC, NTP, SPO, milestone, cycle time, on-air.
Audience: Project Managers making operational decisions.

LANGUAGE RULES (mandatory for every summary):
- Always label the geo level in your text: write "WEST region" or "CENTRAL region" — never
  just "WEST" or "CENTRAL". The audience cannot see hierarchy labels from the UI.
- Never reference raw database column names or numbers (e.g. do NOT write "rgn_region",
  "pj_p_5270_integration_start_finish", "m_market"). Use business English:
  "region", "integration start milestone", "market", etc.

geo_code MUST be the exact region value copied character-for-character from the data.

OUTPUT: JSON array only — no Markdown fences, no commentary outside the JSON.
[
  {
    "region":        "<exact region value from data>",
    "geo_code":      "<exact region value from data>",
    "at_risk_count": <integer>,
    "total_active":  <integer>,
    "at_risk_pct":   <float, 1 decimal>,
    "is_flagged":    true | false,
    "summary":       "<1-2 sentences, region level only>"
  }
]
"""


AREA_ANALYSIS_SYSTEM = """You are a senior risk analyst for telecom tower deployment projects.

You receive two raw SQL result sets already pre-filtered to one region — column names may vary.

STEP 1 — IDENTIFY COLUMNS
Identify the AREA column (second geographic level within the region) and the COUNT column in each set.

STEP 2 — AGGREGATE BY AREA
Sum at-risk counts and total-active counts per distinct area value.
Compute: at_risk_pct = round(at_risk_count / total_active * 100, 1)

STEP 3 — FLAG AND SUMMARIZE
Flag an area as is_flagged=true if at_risk_count > 0.
Do NOT return an empty list — flag at least the worst area.
Write a 1-2 sentence forward-looking summary at area level only.

LANGUAGE RULES (mandatory for every summary):
- Always label the geo level in your text: write "Great Lakes area" or "Heartland area" —
  never just "Great Lakes" or "Heartland".
- Never reference raw database column names or numbers. Use business English:
  "area", "construction milestone", "market", etc.

geo_code MUST be the exact area value copied character-for-character from the data.

OUTPUT: JSON array only — no Markdown, no commentary.
[
  {
    "area":               "<exact area value from data>",
    "geo_code":           "<exact area value from data>",
    "parent_region_code": "<parent region value>",
    "at_risk_count":      <integer>,
    "total_active":       <integer>,
    "at_risk_pct":        <float, 1 decimal>,
    "is_flagged":         true | false,
    "summary":            "<1-2 sentences, area level only>"
  }
]
"""


MARKET_ANALYSIS_SYSTEM = """You are a senior risk analyst for telecom tower deployment projects.

You receive two raw SQL result sets already pre-filtered to one area — column names may vary.

STEP 1 — IDENTIFY COLUMNS
Identify the MARKET column (lowest geographic level) and the COUNT column in each set.

STEP 2 — AGGREGATE BY MARKET
Sum at-risk counts and total-active counts per distinct market value.
Compute: at_risk_pct = round(at_risk_count / total_active * 100, 1)

STEP 3 — FLAG AND SUMMARIZE
Flag a market as is_flagged=true if at_risk_count > 0.
Do NOT return an empty list — flag the worst market(s).
Write a 1-2 sentence forward-looking summary at market level only.

LANGUAGE RULES (mandatory for every summary):
- Always label the geo level in your text: write "CHICAGO market" or "PORTLAND PO market" —
  never just "CHICAGO" or "PORTLAND PO".
- Never reference raw database column names or numbers. Use business English:
  "market", "tower construction milestone", "on-air date", etc.

geo_code MUST be the exact market value copied character-for-character from the data.

OUTPUT: JSON array only — no Markdown, no commentary.
[
  {
    "market":           "<exact market value from data>",
    "geo_code":         "<exact market value from data>",
    "parent_area_code": "<parent area value>",
    "at_risk_count":    <integer>,
    "total_active":     <integer>,
    "at_risk_pct":      <float, 1 decimal>,
    "is_flagged":       true | false,
    "summary":          "<1-2 sentences, market level only>"
  }
]
"""


def _fmt_raw_rows(rows: list[dict]) -> str:
    """Format raw SQL result rows as a pipe-delimited table (whatever columns are present)."""
    if not rows:
        return "(no data)"
    cols = list(rows[0].keys())
    header = " | ".join(str(c) for c in cols)
    sep = "-" * len(header)
    body = "\n".join(" | ".join(str(r.get(c, "")) for c in cols) for r in rows)
    return f"{header}\n{sep}\n{body}"


def build_region_analysis_prompt(
    category: RiskCategory,
    business_context: str | None,
    agg_rows: list[dict],
    total_rows: list[dict],
) -> tuple[str, str]:
    """Return (system, user) for the region analysis LLM call.

    Passes all raw SQL result rows — LLM identifies column names and aggregates by region.
    """
    rules_text = chr(10).join(f"- {r}" for r in category.decision_rules) or "(none)"
    user = f"""Risk category: {category.name}
Identification logic: {category.identification_logic}
Decision rules:
{rules_text}

Project domain context:
{business_context or "(none)"}

--- AT-RISK SITE COUNTS (raw SQL result — column names may vary) ---
{_fmt_raw_rows(agg_rows)}

--- TOTAL ACTIVE SITE COUNTS (raw SQL result — column names may vary) ---
{_fmt_raw_rows(total_rows)}

Follow the 3-step instructions from the system prompt.
Return JSON array only — no Markdown, no commentary.
"""
    return REGION_ANALYSIS_SYSTEM, user


def build_area_analysis_prompt(
    category: RiskCategory,
    business_context: str | None,
    agg_rows: list[dict],
    total_rows: list[dict],
    parent_region_code: str,
    parent_region_summary: str,
) -> tuple[str, str]:
    """Return (system, user) for the area analysis LLM call.

    Passes raw SQL result rows pre-filtered to the parent region by value-matching.
    LLM identifies the area column and aggregates.
    """
    rules_text = chr(10).join(f"- {r}" for r in category.decision_rules) or "(none)"
    user = f"""Risk category: {category.name}
Identification logic: {category.identification_logic}
Decision rules:
{rules_text}

Project domain context:
{business_context or "(none)"}

Parent region (already flagged): {parent_region_code} — {parent_region_summary}

--- AT-RISK SITE COUNTS for region '{parent_region_code}' (raw SQL result — column names may vary) ---
{_fmt_raw_rows(agg_rows)}

--- TOTAL ACTIVE SITE COUNTS for region '{parent_region_code}' (raw SQL result — column names may vary) ---
{_fmt_raw_rows(total_rows)}

Follow the 3-step instructions from the system prompt.
Return JSON array only — no Markdown, no commentary.
"""
    return AREA_ANALYSIS_SYSTEM, user


def build_market_analysis_prompt(
    category: RiskCategory,
    business_context: str | None,
    agg_rows: list[dict],
    total_rows: list[dict],
    parent_area_code: str,
    parent_area_summary: str,
) -> tuple[str, str]:
    """Return (system, user) for the market analysis LLM call.

    Passes raw SQL result rows pre-filtered to the parent area by value-matching.
    LLM identifies the market column and aggregates.
    """
    rules_text = chr(10).join(f"- {r}" for r in category.decision_rules) or "(none)"
    user = f"""Risk category: {category.name}
Identification logic: {category.identification_logic}
Decision rules:
{rules_text}

Project domain context:
{business_context or "(none)"}

Parent area (already flagged): {parent_area_code} — {parent_area_summary}

--- AT-RISK SITE COUNTS for area '{parent_area_code}' (raw SQL result — column names may vary) ---
{_fmt_raw_rows(agg_rows)}

--- TOTAL ACTIVE SITE COUNTS for area '{parent_area_code}' (raw SQL result — column names may vary) ---
{_fmt_raw_rows(total_rows)}

Follow the 3-step instructions from the system prompt.
Return JSON array only — no Markdown, no commentary.
"""
    return MARKET_ANALYSIS_SYSTEM, user


def build_geo_analysis_prompt(
    category: RiskCategory,
    geo_level: str,
    rows: list[dict[str, Any]],
    business_context: str | None,
    parent_findings: list[GeoFinding] | None = None,
) -> tuple[str, str]:
    """Return (system_prompt, user_prompt) for a geo analyzer node.

    Args:
        category: The risk category being analyzed.
        geo_level: "region" | "area" | "market"
        rows: The SQL result rows for this geo level.
        business_context: Project-specific prompt block.
        parent_findings: Flagged units from the level above (used for relaxed thresholds).
    """
    parent_block = ""
    if parent_findings:
        parent_level = "REGION" if geo_level == "area" else "AREA"
        lines = [
            f"PARENT {parent_level} CONTEXT — already flagged anomalies at the level above:",
        ]
        for f in parent_findings:
            lines.append(
                f"  - {f.geo_name} (geo_code={f.geo_code}): {f.summary} "
                f"(metric: {f.metric_name})"
            )
        lines.append(
            f"Apply RELAXED thresholds for sub-{geo_level}s under these flagged {parent_level.lower()}s. "
            f"Do NOT return [] if any sub-{geo_level} falls under a flagged parent."
        )
        parent_block = "\n".join(lines)

    import json

    rows_json = json.dumps(rows, default=str, indent=2)

    user = f"""# Risk Category
category_id: {category.category_id}
name: {category.name}
description: {category.description}

## Identification Logic
{category.identification_logic}

## Decision Rules
{chr(10).join(f"- {r}" for r in category.decision_rules) or "(none)"}

# Business Context
{business_context or "(none — unknown project)"}

# Geo Level Being Analyzed
{geo_level.upper()}

{parent_block}

# Aggregated Data Rows ({geo_level} level)
{rows_json}

# Task
Apply the detection rules from the system prompt.
Return a JSON array of anomalous {geo_level} geo findings, or [] if none.
"""
    return GEO_ANALYZER_SYSTEM, user
