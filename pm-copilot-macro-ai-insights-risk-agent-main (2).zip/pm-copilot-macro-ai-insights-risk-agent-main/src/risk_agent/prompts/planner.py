"""Prompt templates for the Planner agent."""

from __future__ import annotations

import re as _re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from risk_agent.models.domain import RiskCategory

# ---------------------------------------------------------------------------
# SYSTEM: SQL planner
# ---------------------------------------------------------------------------
PLANNER_SYSTEM_PROMPT = """You are a senior data engineer planning SQL traversal steps for a risk identification agent.

AUDIENCE / END USERS
The findings produced from your SQL output are consumed by **Project Managers
in the telecom tower deployment domain**. They will use the resulting risk
report to decide where to intervene on live tower-deployment programs.
Plan steps so the rows you return give a PM the WHO / WHERE / WHY behind a
risk — not just the metric — because they have to act on it operationally
(call a GC, push an NTP, expedite a PO, etc.).

You operate against a SINGLE target Postgres table. Your job is to:
  1. Read the target table's schema (column names + data types).
  2. Read the risk category definition from Excel (description, identification
     logic, decision rules).
  3. Read THREE complementary semantic context blocks retrieved for this
     category — see "Semantic Context Sources" below.
  4. Plan a list of INDEPENDENT SQL SELECT queries — each one probes a
     different angle of the risk. Later, their results are combined to
     decide if a risk exists.

BUSINESS CONTEXT — PRIMARY COLUMN DIRECTORY (read this FIRST when provided)
When a Business Context block is provided, it describes the project's deployment
phases and the EXACT column names that belong to each phase. Use it as follows:

  STEP A — PHASE MATCHING
  Read the risk category's identification_logic and decision_rules.
  Extract every column name, activity name, or milestone keyword mentioned
  (e.g. "NTP issued", "BOM submitted", "construction start", "pj_a_4075_...").
  Match these to the phase(s) in the Business Context by scanning the phase
  titles (=== PHASE N: Title ===) and node property lists.

  STEP B — FULL PHASE COLUMN EXPANSION
  Once the relevant phase(s) are identified, use ALL columns listed under
  those phase nodes — not just the ones explicitly named in the identification
  logic. This is the key difference: the identification logic names the METRIC
  column; the Business Context gives you the full set of CONTEXT columns
  (planned dates, actual dates, status, delay codes, GC name, comment fields)
  that explain WHY the metric is failing.

  STEP C — ALWAYS INCLUDE BASE NODE
  Always include the site identifier columns from Phase 0 / BASE NODE
  (typically s_site_id, pj_project_id, construction_gc, rgn_region, m_area,
  m_market, s_site_name) in every SQL step — they establish WHO/WHERE.

  STEP D — PLANNED vs ACTUAL DATE PAIRS
  For every phase that has both pj_p_* (planned) and pj_a_* (actual) columns,
  always pull BOTH and compute the gap:
    EXTRACT(DAY FROM (CURRENT_DATE - pj_p_<milestone>_finish)) AS days_overdue
  This gives the generator concrete overdue counts for forward-looking projections.

  STEP E — FALLBACK
  If no Business Context is provided or no phase clearly matches, fall back to
  the raw schema column list.

COLUMN NAMING CONVENTION — PLANNED vs ACTUAL DATES
The target table follows a strict pattern for milestone date columns.
You MUST understand and apply this when writing SQL:

  Pattern:  pj_p_<number>_<milestone_name>_finish  →  PLANNED date
            pj_a_<number>_<milestone_name>_finish  →  ACTUAL date

  Examples:
    pj_p_5270_integration_start_finish   planned date for integration start
    pj_a_5270_integration_start_finish   actual  date for integration start
    pj_p_4635_battery_install_finish     planned date for battery install
    pj_a_4635_battery_install_finish     actual  date for battery install

  Key rule: the SAME 4-digit number and milestone name always appear in both
  the planned (_p_) and actual (_a_) column. They are always a pair.

  How to use them in SQL:
    1. NULL actual + non-NULL planned  → milestone not yet completed; compute
       EXTRACT(DAY FROM (CURRENT_DATE - pj_p_<n>_<name>_finish)) AS days_overdue
    2. Both non-NULL                   → milestone done; compute
       EXTRACT(DAY FROM (pj_a_<n>_<name>_finish - pj_p_<n>_<name>_finish)) AS delay_days
    3. COUNT FILTER for missing actuals:
       COUNT(*) FILTER (WHERE pj_a_<n>_<name>_finish IS NULL
                          AND pj_p_<n>_<name>_finish IS NOT NULL)
       AS sites_with_missing_actual

  Always SELECT both the planned and actual column together — never one without
  the other. This applies to every column pair in the schema that matches this
  pattern, not just the examples listed here.

SEMANTIC CONTEXT SOURCES
You are given THREE complementary blocks. Use them together — they are
intentionally redundant so a weak signal in one is reinforced by another.
  1. **KPI Context** — relevant KPIs, RCA questions, recommendation areas,
     and `steps_to_get_data_sql` fragments. Treat this as the primary
     source for WHICH metrics to compute and the canonical aggregation
     shape.
  2. **Keywords Context** — domain glossary entries: term → description,
     mapped tables/columns, synonyms/aliases, computation logic. Use this
     to translate fuzzy natural-language phrases in the risk description
     into the correct schema columns and expressions on the target table.
     If a keyword's "mapped_columns" includes a column that EXISTS on the
     target table, prefer that column.
  3. **Question Bank Context** — example NL questions paired with reference
     SQL. When the risk closely resembles one of these questions, EMULATE
     the SQL pattern (joins, filters, aggregations) — but always rewrite
     against the SINGLE target table using only its real columns. The
     reference SQL may name other tables; that is illustrative, not
     authoritative.

If a referenced column or table from any of these blocks does NOT appear
in the target schema, do not use it — adapt or skip that angle.

Hard rules:
  - Every SQL query MUST reference ONLY the provided target table. Do not
    invent or reference any other table.

  - SCHEMA COLUMNS ONLY — ZERO TOLERANCE FOR INVENTED NAMES:
    Before writing any column name in a SELECT, WHERE, GROUP BY, or ORDER BY
    clause, verify it exists VERBATIM in the "Target Table Schema" block
    provided in the user message. If it is not listed there, DO NOT use it.
    Do not infer, guess, abbreviate, or derive column names from the risk
    description or business logic — only use what the schema explicitly lists.

    Common failure patterns to avoid:
      ✗ risk_bucket        (not a real column — do not invent derived labels)
      ✗ delay_category     (not a real column — use the actual delay code column)
      ✗ milestone_status   (not a real column — check the schema for the real name)
      ✗ overdue_flag       (not a real column — compute with CASE/EXTRACT inline)

    If a concept you need (e.g. "risk bucket", "overdue flag") does not exist
    as a column, express it as a SQL expression or CASE statement using ONLY
    real schema columns, and alias the result:
      ✓ CASE WHEN pj_a_5270_integration_start_finish IS NULL
              AND pj_p_5270_integration_start_finish < CURRENT_DATE
             THEN 'overdue' ELSE 'on track' END AS overdue_flag

  - Produce ONLY SELECT / WITH statements. Never INSERT/UPDATE/DELETE/DDL.
  - Each step must be INDEPENDENT — it must not depend on the output of
    another step. We execute all steps concurrently.
  - Do NOT add LIMIT clauses yourself — the executor wraps every query
    with an outer LIMIT.
  - Use explicit column lists; avoid SELECT *.
  - Cast numeric aggregates cleanly; use COALESCE for nullable columns
    where it improves robustness.
  - Aim for 4-8 focused steps. Quality over quantity.

ALSO PULL SUPPORTING / CONTEXTUAL COLUMNS
A SQL step must NOT return only the columns named in the rule's threshold.
For every step, scan the schema and INCLUDE adjacent columns that explain
WHY a row is risky and WHO/WHERE it is. Without that context the
downstream agents cannot produce actionable findings for a PM.

Examples of supporting columns to add when present in the schema:
  - For a "delay" category: start date, planned/forecast date, actual date,
    days-of-delay, delay reason / delay comments / status notes columns.
  - For a "missing NTP" category: site_id, GC / vendor name, market /
    region, NTP date, NOC date, project phase, last-updated timestamp.
  - For a "PO / SPO not raised" category: site_id, GC, PO number,
    PO status, requested date, expected date, PO comments / remarks.
  - For a "crew / run rate shortfall" category: GC, market, crew count,
    weekly target, weekly actual, period, comments / notes.

General rule: if the schema has ID, owner, location, date, status, or
free-text comment columns adjacent to the metric being tested, INCLUDE
them in `expected_columns` and the SELECT list. Free-text comment /
remark / reason / notes columns are especially valuable — they often
carry the actual operational explanation a PM needs.

KNOWN COMMENT / NARRATIVE COLUMNS — if ANY of these exist in the target
schema, ALWAYS include them in the SELECT list (they carry PM and GC
narrative that explains the operational reason behind a delay or issue):
  - pj_construction_start_delay_comments   (delay reason for Cx Start)
  - pj_construction_complete_delay_comments (delay reason for Cx Complete)
  - pj_on_air_delay_code_comments          (delay reason for site On Air)
  - pj_project_comment_history             (full timestamped project comment log)
  - wp_notes                               (work package notes / timestamped site comments)
  - site_remarks_from_pm_tracker           (market PM's site-specific remarks)
  - any column whose name contains: comment, remark, note, reason, history.
These columns MUST be checked against the actual schema — only include
those that appear in the provided column list.

For aggregate steps (COUNT/GROUP BY summaries), add a second companion
step that returns the top offending rows WITH supporting columns, so the
generator has both the magnitude and the row-level context.

SQL PATTERNS TO PREFER (cover distinct risk angles):
  - Null/missing checks:   COUNT(*) FILTER (WHERE col IS NULL) to surface gaps
  - Threshold breaches:    rows where a metric exceeds a decision-rule threshold
  - Recency/staleness:     date gaps, MAX(date) comparisons, overdue intervals
  - Cardinality anomalies: unexpected duplication, zero-count groups
  - Distribution summaries: GROUP BY to reveal imbalanced segments or outliers
  The generator reasons better on compact summary rowsets than raw row dumps.

DOMAIN TERMINOLOGY (telecom tower deployment):
  - GC = General Contractor (vendor who deploys field crews)
  - NTP = Notice to Proceed
  - SPO / PO = Special/Purchase Order (material ordering authority)
  - RFI = Ready for Installation (or Request for Information)
  - NOC = Notice of Commencement
  - WIP = Work In Progress (construction in progress)
  - FTR = First Time Right
  - H&S / HSE = Health & Safety
  - SLA = Service Level Agreement
  - CAPA = Corrective and Preventive Action
  - Run rate = daily/weekly site delivery output
  - Crew = field installation team under a GC
  - Cycle time = days from NTP to on-air

When you craft step names and rationales, prefer these domain terms where applicable so the downstream risk generator can map findings to concrete telecom project concepts.

You return a STRICT JSON object that matches the schema in the user
message. No Markdown fences. No commentary outside the JSON.
"""


# ---------------------------------------------------------------------------
# USER: category + semantic hits + target schema => traversal steps
# ---------------------------------------------------------------------------
PLANNER_USER_PROMPT = """# Risk Category (from Excel)
category_id: {category_id}
name: {name}
description: {description}

## Identification Logic (natural language)
{identification_logic}

## Decision Rules
{decision_rules}

# Mandatory SQL Filter (REQUIRED — include in EVERY WHERE clause without exception)
{mandatory_filter}

# Business Context (Project-specific deployment phases and column meanings)
{business_context}

# KPI Context (relevant KPIs, RCA patterns, steps_to_get_data_sql)
{kpi_context}

# Keywords Context (domain glossary — term, description, mapped tables/columns, synonyms, logic)
{keywords_context}

# Question Bank Context (example NL questions and their reference SQL)
{question_bank_context}

# Target Table Schema (AUTHORITATIVE — use only these columns)
Fully-qualified name: {target_table_fqn}

{schema}

# Instructions
Produce a list of independent traversal steps. Each step is either:
  (a) "semantic_kpi"  — derived from one of the semantic context hits above.
  (b) "excel_rule"    — derived directly from the identification logic /
                        decision rules in the Excel row.

Aim to cover distinct risk angles — at minimum: one null/missing check,
one threshold-breach check, and one summary/distribution step.
Avoid duplicate angles.

For EACH step, return:
  - source:           "semantic_kpi" | "excel_rule"
  - name:             short title (e.g. "Sites with missing NTP date")
  - rationale:        why this step is relevant to identifying the risk
  - sql_query:        a standalone Postgres SELECT/WITH statement, grounded
                      in the target table only
  - expected_columns: list of column names the query returns
  - related_kpi:      KPI label if source is "semantic_kpi"; else null
  - source_reference: the hit id (string) when source is "semantic_kpi";
                      a short rule excerpt when source is "excel_rule";
                      null only if neither applies

# Output Format — STRICT JSON (no Markdown fences, no commentary)
{{
  "steps": [
    {{
      "source": "semantic_kpi",
      "name": "string",
      "rationale": "string",
      "sql_query": "SELECT ...",
      "expected_columns": ["col1", "col2"],
      "related_kpi": "string or null",
      "source_reference": "string or null"
    }}
  ]
}}
"""


# ---------------------------------------------------------------------------
# SYSTEM: SQL planner retry (when steps are rejected)
# ---------------------------------------------------------------------------
PLANNER_RETRY_SYSTEM_PROMPT = """You are a senior data engineer refining SQL traversal steps for a risk identification agent.

You previously generated some steps, but several were REJECTED due to validation errors.
Review the rejection reasons below carefully. Common issues:
  - "Only SELECT / WITH queries are permitted" — queries must START with SELECT or WITH,
    never INSERT/UPDATE/DELETE/DROP/ALTER/CREATE/TRUNCATE/GRANT/REVOKE/etc.
  - "SQL contains forbidden keyword" — DDL/DML keywords detected; use read-only SELECT only
  - "Multiple statements are not allowed" — each SQL string has only ONE statement (no semicolon-separated queries)
  - "Empty SQL query" — ensure queries have content
  - Invalid columns — use ONLY columns from the provided schema

Your task:
  1. Review ONLY the rejected steps (listed with their error reasons)
  2. Fix ONLY the `sql_query` and `expected_columns` fields — preserve `source`,
     `name`, `rationale`, `related_kpi`, and `source_reference` exactly as-is
  3. Return only the FIXED steps in the same JSON format
  4. If you cannot fix a step (e.g., all required columns are missing),
     omit it from the response entirely — do not emit a placeholder or empty query

Hard rules (unchanged):
  - ONLY SELECT / WITH queries — no DDL, DML, or other statements
  - Reference ONLY the provided target table and its columns
  - Each step INDEPENDENT; no dependencies on other steps
  - Do NOT add LIMIT yourself
  - Use explicit column lists
  - Cast aggregates cleanly

Return STRICT JSON with the fixed steps. No Markdown. No commentary.
"""


# ---------------------------------------------------------------------------
# USER: retry prompt for rejected steps
# ---------------------------------------------------------------------------
PLANNER_RETRY_USER_PROMPT = """# Target Table Schema (AUTHORITATIVE)
Fully-qualified name: {target_table_fqn}

{schema}

# Mandatory SQL Filter (REQUIRED — include in EVERY WHERE clause without exception)
{mandatory_filter}

# Previously Rejected Steps (PLEASE FIX)

The following steps were rejected during validation. Each rejection reason explains the problem.
Review each and produce corrected SQL queries that comply with the rules above.

{rejected_steps_with_reasons}

# Output Format — STRICT JSON (no Markdown fences, no commentary)
{{
  "steps": [
    {{
      "source": "semantic_kpi",
      "name": "string",
      "rationale": "string",
      "sql_query": "SELECT site_id, COUNT(*) FROM public.risk_data GROUP BY site_id",
      "expected_columns": ["col1", "col2"],
      "related_kpi": "string or null",
      "source_reference": "string or null"
    }}
  ]
}}
"""

# ---------------------------------------------------------------------------
# NL query builder — constructs the natural-language input for the AI
# Assistant SQL generator API.  The API handles its own semantic search and
# SQL generation; our job is to give it enough project/column/domain context
# so it scopes the query correctly.
# ---------------------------------------------------------------------------

_DOMAIN_TERMS = (
    "NTP = Notice to Proceed; "
    "GC = General Contractor (vendor deploying field crews); "
    "SPO/PO = Special/Purchase Order; "
    "BOM = Bill of Materials; "
    "RFI = Ready for Installation; "
    "NOC = Notice of Commencement; "
    "WIP = Work In Progress; "
    "FTR = First Time Right; "
    "HSE = Health, Safety & Environment; "
    "SLA = Service Level Agreement; "
    "Planned column prefix = pj_p_  (e.g. pj_p_5100_ntp_issued_finish); "
    "Actual column prefix  = pj_a_  (e.g. pj_a_5100_ntp_issued_finish)"
)


def _build_condition_block(condition_text: str) -> str:
    """Embed a pre-processed condition statement into an NL query.

    condition_text is already a clean 'a site is considered at risk if [cond1] AND [cond2]...'
    statement produced by preprocess_condition_with_llm(). Return it as-is so the
    Text-to-SQL API receives plain natural language with no template headers.
    """
    return condition_text.strip()

# Column patterns to extract from business context as hints for the API.
_COL_PATTERN = _re.compile(r'\b(pj_[a-z0-9_]+|ms_[a-z0-9_]+|scop_[a-z0-9_]+|nas_[a-z0-9_]+)\b')

# Always-included base identifier columns.
_BASE_COLS = [
    "s_site_id", "pj_project_id", "s_site_name",
    "rgn_region", "m_area", "m_market", "construction_gc",
]


def _extract_relevant_columns(
    identification_logic: str,
    decision_rules: list[str],
    business_context: str | None,
) -> list[str]:
    """Extract column names relevant to this category from business context.

    Scans the identification_logic and decision_rules for column name patterns,
    then validates them against the business context. Returns a compact list
    of column hints to include in the NL query.
    """
    search_text = identification_logic + " " + " ".join(decision_rules or [])
    mentioned = set(_COL_PATTERN.findall(search_text.lower()))

    # Also pick columns mentioned in business_context that share keywords with
    # the category text (lenient — just extract all pj_/ms_ columns from context).
    context_cols: set[str] = set()
    if business_context:
        context_cols = set(_COL_PATTERN.findall(business_context.lower()))

    # Prefer explicitly mentioned columns; supplement with context columns
    # that share a keyword with the identification logic (avoid flooding).
    combined = list(mentioned) + [c for c in sorted(context_cols) if c not in mentioned]

    # Always prepend base identifier columns.
    result = _BASE_COLS[:]
    for col in combined[:30]:  # cap at 30 additional column hints
        if col not in result:
            result.append(col)
    return result


def _extract_keyword_columns(keywords: "SemanticResponse | None") -> list[str]:
    """Pull mapped_columns from keyword hits — more accurate than pattern matching."""
    if not keywords or not keywords.results:
        return []
    cols: list[str] = []
    for hit in keywords.results:
        c = hit.content
        mapped = getattr(c, "mapped_columns", None) or getattr(c, "columns", None)
        if isinstance(mapped, (list, tuple)):
            cols.extend(str(col) for col in mapped if col)
        elif isinstance(mapped, str):
            cols.extend(col.strip() for col in mapped.split(",") if col.strip())
    return cols


def _extract_kpi_sql_fragments(semantic: "SemanticResponse | None") -> list[str]:
    """Pull steps_to_get_data_sql from top KPI hits."""
    if not semantic or not semantic.results:
        return []
    frags: list[str] = []
    for hit in semantic.results[:3]:
        for frag in (hit.content.steps_to_get_data_sql or []):
            if frag and frag.strip():
                frags.append(frag.strip())
    return frags


def _extract_qb_reference_sql(question_bank: "SemanticResponse | None") -> list[str]:
    """Pull reference SQL from the top question-bank hits."""
    if not question_bank or not question_bank.results:
        return []
    sqls: list[str] = []
    for hit in question_bank.results[:2]:
        c = hit.content
        sql = (
            getattr(c, "sql", None)
            or getattr(c, "sql_query", None)
            or getattr(c, "sql_logic", None)
            or getattr(c, "reference_sql", None)
        )
        if sql and isinstance(sql, str) and sql.strip():
            sqls.append(sql.strip())
        elif not sql and c.steps_to_get_data_sql:
            sqls.extend(s.strip() for s in c.steps_to_get_data_sql if s.strip())
    return sqls


def build_nl_query(
    category: "RiskCategory",
    project: str | None,
    condition_text: str | None = None,
    business_context: str | None = None,
    schema_column_hints: list[str] | None = None,
    semantic: "SemanticResponse | None" = None,
    keywords: "SemanticResponse | None" = None,
    question_bank: "SemanticResponse | None" = None,
    agg_sql: str | None = None,
) -> str:
    """Build the site-level NL query for the Text-to-SQL API.

    Produces a short, plain-language question with the condition inline.
    condition_text is the pre-processed output of preprocess_condition_with_llm().
    """
    project_scope = f"For the {project} project, " if project else ""
    condition = condition_text or category.identification_logic

    if agg_sql:
        return (
            f"{project_scope}give me site-level details for all sites "
            f"where pj_project_status = 'Active' AND {condition}. "
            f"Use the same WHERE clause as this reference SQL but return individual rows "
            f"instead of counts, and include all relevant columns: "
            f"```reference sql\n{agg_sql}\n```"
        )

    geo_cols = "region and market" if project == "NAS" else "region, area, and market"
    smp_cols = ", smp_name, smp_id" if project in ("NTM", "AHLOA") else ""
    return (
        f"{project_scope}give me site-level details for all sites "
        f"where pj_project_status = 'Active' AND {condition}. "
        f"Include site ID, project ID, project status, {geo_cols}, "
        f"GC name{smp_cols}, all milestone planned and actual dates related to the condition, "
        f"and all comment and notes columns."
    )


def build_region_agg_query(
    category: "RiskCategory",
    project: str | None,
    condition_text: str | None = None,
) -> str:
    """Build the at-risk site count NL query for the Text-to-SQL API.

    Produces a short COUNT + GROUP BY question with the condition inline.
    NAS groups by region and market only; other projects include area.
    """
    project_scope = f"For the {project} project, " if project else ""
    condition = condition_text or category.identification_logic

    if project == "NAS":
        group_cols = "region and market"
    else:
        group_cols = "region, area, and market"

    return (
        f"{project_scope}how many sites have pj_project_status = 'Active' AND satisfy the condition "
        f"where {condition}? "
        f"Group the result by {group_cols} and return the count as 'at_risk_count'."
    )


_TOTAL_ACTIVE_SQL: dict[str, str] = {
    "NAS": (
        'SELECT\n'
        '    nas_region AS "Region",\n'
        '    nas_market AS "Market",\n'
        '    COUNT(*) AS "Active_Site_Count"\n'
        'FROM pwc_macro_staging_schema.stg_nas_log_data\n'
        'WHERE nas_site_id IS NOT NULL\n'
        'GROUP BY nas_region, nas_market\n'
        'ORDER BY nas_region, "Active_Site_Count"'
    ),
    "NTM": (
        'SELECT\n'
        '    mbt.rgn_region AS "Region",\n'
        '    mbt.m_area     AS "Area",\n'
        '    mbt.m_market   AS "Market",\n'
        '    COUNT(*) AS "Active_Site_Count"\n'
        'FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined AS mbt\n'
        "WHERE\n"
        "    UPPER(COALESCE(mbt.smp_name, '')) = 'NTM'\n"
        "    AND UPPER(COALESCE(mbt.pj_project_status, '')) = 'ACTIVE'\n"
        "    AND mbt.m_market IS NOT NULL\n"
        'GROUP BY mbt.rgn_region, mbt.m_area, mbt.m_market\n'
        'ORDER BY "Active_Site_Count" DESC, "Market"'
    ),
    "AHLOA": (
        'SELECT\n'
        '    rgn_region     AS "Region",\n'
        '    m_area         AS "Area",\n'
        '    UPPER(m_market) AS "Market",\n'
        '    COUNT(*) AS "Active_Site_Count"\n'
        'FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined\n'
        "WHERE\n"
        "    smp_name = 'AHLOB Modernization'\n"
        "    AND UPPER(COALESCE(pj_project_status, '')) = 'ACTIVE'\n"
        'GROUP BY rgn_region, m_area, UPPER(m_market)\n'
        'ORDER BY rgn_region, m_area, "Market"'
    ),
}


def get_total_active_sql(project: str | None) -> str | None:
    """Return hardcoded SQL for total active site count by geo level.

    NAS: groups by region + market (no area level).
    NTM: groups by region + area + market, filtered by smp_name = 'NTM'.
    AHLOA: groups by region + area + market, filtered by smp_name = 'AHLOB Modernization'.
    Returns None for unknown projects — caller should handle gracefully.
    """
    if not project:
        return None
    return _TOTAL_ACTIVE_SQL.get(project)


def build_site_market_query(
    category: "RiskCategory",
    project: str | None,
    market_name: str,
    market_code: str,
    condition_text: str | None = None,
    agg_sql: str | None = None,
) -> str:
    """Build the per-market site-level NL query for the Text-to-SQL API.

    Produces a short, plain-language question scoped to one market.
    """
    project_scope = f"For the {project} project, " if project else ""
    condition = condition_text or category.identification_logic

    if agg_sql:
        return (
            f"{project_scope}give me site-level details for all sites in {market_name} market "
            f"where pj_project_status = 'Active' AND {condition}. "
            f"Use the same WHERE clause as this reference SQL but return individual rows "
            f"scoped to {market_name} market only, and include all relevant columns: "
            f"```sql\n{agg_sql}\n```"
        )

    return (
        f"{project_scope}give me site-level details for all sites in {market_name} market "
        f"where pj_project_status = 'Active' AND {condition}. "
        f"Include site ID, project ID, project status, region, area, market, "
        f"GC name, all milestone planned and actual dates related to the condition, "
        f"and all comment and notes columns."
    )


def build_kpi_nl_query(
    category: "RiskCategory",
    project: str | None,
    kpi_question: str,
    col_hints: list[str],
) -> str:
    """Build a focused NL query from a KPI hit's RCA question (kept for back-compat)."""
    project_line = f"For the {project} project: " if project else ""
    col_hints_text = ", ".join(col_hints) if col_hints else "(use standard site identifier columns)"
    return (
        f"{project_line}answering the question: {kpi_question}\n\n"
        f"Context: This is part of the '{category.name}' risk analysis.\n"
        f"Related identification logic: {category.identification_logic}\n\n"
        f"Relevant columns: {col_hints_text}\n\n"
        f"Return one row per individual site. Include: site ID, rgn_region, m_area, m_market, "
        f"the specific metric columns, and any comment/remarks columns. Order by severity (worst first)."
    )


def build_qb_nl_query(
    category: "RiskCategory",
    project: str | None,
    qb_question: str,
    col_hints: list[str],
) -> str:
    """Build a focused NL query from a question-bank hit's NL question (kept for back-compat)."""
    project_line = f"For the {project} project: " if project else ""
    col_hints_text = ", ".join(col_hints) if col_hints else "(use standard site identifier columns)"
    return (
        f"{project_line}{qb_question}\n\n"
        f"Context: This is related to the '{category.name}' risk ({category.description}).\n\n"
        f"Relevant columns: {col_hints_text}\n\n"
        f"Return one row per individual site. Include: site ID, rgn_region, m_area, m_market, "
        f"the specific metric columns, and any comment/remarks columns. Order by severity (worst first)."
    )
