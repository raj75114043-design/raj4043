"""Command-line entrypoint for the risk agent.

Usage examples:
    # Run for a single category by id:
    risk-agent run --category-id RISK_NDPD_001

    # List available categories from the catalog:
    risk-agent list

    # Launch the HTTP API:
    risk-agent serve
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import click
import uvicorn
from rich.console import Console
from rich.table import Table

from risk_agent.config import get_settings
from risk_agent.core import RiskCatalog
from risk_agent.db import close_pool, init_pool
from risk_agent.orchestrator import RiskAgentOrchestrator
from risk_agent.utils.exceptions import RiskAgentError, RiskCatalogError
from risk_agent.utils.logging import configure_logging, get_logger

_console = Console()
_logger = get_logger(__name__)


@click.group()
@click.version_option("1.0.0")
def cli() -> None:
    """Risk Identification Agent CLI."""
    configure_logging()


@cli.command("list")
@click.option(
    "--catalog",
    "catalog_path",
    type=click.Path(path_type=Path, exists=True),
    default=None,
    help="Path to the Excel risk catalog (default from settings).",
)
def list_categories(catalog_path: Path | None) -> None:
    """List risk categories available in the Excel catalog."""
    path = catalog_path or get_settings().agent.risk_catalog_path
    try:
        catalog = RiskCatalog.from_excel(path)
    except RiskCatalogError as exc:
        _console.print(f"[red]✘ {exc}[/red]")
        sys.exit(2)

    table = Table(title=f"Risk Catalog ({len(catalog)} categories)")
    table.add_column("category_id", style="cyan")
    table.add_column("name", style="bold")
    table.add_column("owner")
    table.add_column("tags", style="dim")

    for c in catalog:
        table.add_row(c.category_id, c.name, c.owner or "-", ", ".join(c.tags))
    _console.print(table)


@cli.command("run")
@click.option("--category-id", required=True, help="Risk category id to process")
@click.option(
    "--catalog",
    "catalog_path",
    type=click.Path(path_type=Path, exists=True),
    default=None,
    help="Path to the Excel risk catalog (default from settings).",
)
@click.option(
    "--output",
    type=click.Path(path_type=Path),
    default=None,
    help="Write the JSON report to this file (stdout if omitted).",
)
def run_category(
    category_id: str, catalog_path: Path | None, output: Path | None
) -> None:
    """Run the risk agent for a single category."""
    try:
        exit_code = asyncio.run(
            _run_category_async(category_id, catalog_path, output)
        )
    except RiskAgentError as exc:
        _console.print(f"[red]✘ {exc}[/red]")
        exit_code = 1
    sys.exit(exit_code)


async def _run_category_async(
    category_id: str, catalog_path: Path | None, output: Path | None
) -> int:
    path = catalog_path or get_settings().agent.risk_catalog_path
    catalog = RiskCatalog.from_excel(path)
    category = catalog.get(category_id)

    await init_pool()
    try:
        orchestrator = RiskAgentOrchestrator()
        report = await orchestrator.run(category)
    finally:
        await close_pool()

    payload = report.model_dump(mode="json")
    if output is not None:
        output.write_text(json.dumps(payload, indent=2, default=str))
        _console.print(f"[green]✔ wrote report to {output}[/green]")
    else:
        _console.print_json(data=payload)

    return 0 if report.has_risks or report.steps_succeeded > 0 else 1


@cli.command("run-all")
@click.option(
    "--catalog",
    "catalog_path",
    type=click.Path(path_type=Path, exists=True),
    default=None,
    help="Path to the Excel risk catalog (default from settings).",
)
@click.option(
    "--output",
    type=click.Path(path_type=Path),
    default=None,
    help="Write all JSON reports to this file (stdout if omitted).",
)
def run_all_categories(catalog_path: Path | None, output: Path | None) -> None:
    """Run the risk agent for ALL categories in the catalog automatically."""
    try:
        exit_code = asyncio.run(_run_all_async(catalog_path, output))
    except RiskAgentError as exc:
        _console.print(f"[red]✘ {exc}[/red]")
        exit_code = 1
    sys.exit(exit_code)


async def _run_all_async(catalog_path: Path | None, output: Path | None) -> int:
    path = catalog_path or get_settings().agent.risk_catalog_path
    catalog = RiskCatalog.from_excel(path)
    categories = list(catalog)
    _console.print(f"[cyan]Processing {len(categories)} categories…[/cyan]")

    await init_pool()
    reports = []
    try:
        orchestrator = RiskAgentOrchestrator()
        for i, category in enumerate(categories, 1):
            _console.print(f"  [{i}/{len(categories)}] {category.category_id} — {category.name}")
            try:
                report = await orchestrator.run(category)
                reports.append(report.model_dump(mode="json"))
                status = f"[green]✔[/green] {len(report.findings)} finding(s)"
            except Exception as exc:
                _logger.exception("run_all.category_failed", category_id=category.category_id)
                status = f"[red]✘ {exc}[/red]"
            _console.print(f"    {status}")
    finally:
        await close_pool()

    payload = {"total": len(reports), "reports": reports}
    if output is not None:
        output.write_text(json.dumps(payload, indent=2, default=str))
        _console.print(f"[green]✔ wrote {len(reports)} reports to {output}[/green]")
    else:
        _console.print_json(data=payload)

    return 0


@cli.command("kpi-analyze")
@click.option(
    "--output",
    type=click.Path(path_type=Path),
    default=None,
    help="Write the JSON report to this file (stdout if omitted).",
)
def kpi_analyze(output: Path | None) -> None:
    """Run the KPI hierarchical trend analysis pipeline across all KPIs and regions."""
    try:
        exit_code = asyncio.run(_kpi_analyze_async(output))
    except Exception as exc:
        _console.print(f"[red]✘ {exc}[/red]")
        exit_code = 1
    sys.exit(exit_code)


async def _kpi_analyze_async(output: Path | None) -> int:
    from risk_agent.kpi_analysis import KPIAnalysisOrchestrator

    _console.print("[cyan]Starting KPI trend analysis (Region → Area → Market → Site)…[/cyan]")

    await init_pool()
    try:
        orchestrator = KPIAnalysisOrchestrator()
        report = await orchestrator.run()
    finally:
        await close_pool()

    _console.print(
        f"[green]✔ KPI analysis complete — {len(report.findings)} finding(s)[/green]"
    )
    payload = report.model_dump(mode="json")
    if output is not None:
        output.write_text(json.dumps(payload, indent=2, default=str))
        _console.print(f"[green]  wrote report to {output}[/green]")
    else:
        _console.print_json(data=payload)

    return 0


@cli.command("serve")
@click.option("--host", default=None, help="Override API host")
@click.option("--port", default=None, type=int, help="Override API port")
@click.option("--reload/--no-reload", default=False, help="Enable auto-reload")
def serve(host: str | None, port: int | None, reload: bool) -> None:
    """Launch the FastAPI HTTP server."""
    settings = get_settings().api
    uvicorn.run(
        "risk_agent.api:app",
        host=host or settings.host,
        port=port or settings.port,
        reload=reload,
        log_config=None,
    )


if __name__ == "__main__":
    cli()
