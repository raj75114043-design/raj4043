"""Enables `python -m risk_agent ...`."""

from risk_agent.main import cli

if __name__ == "__main__":
    cli()
