"""Persistence layer for global chat sessions and messages.

Tables: pwc_agent_utility_schema.risk_agent_chat_sessions
        pwc_agent_utility_schema.risk_agent_chat_messages
"""

from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

from risk_agent.db.orm_models import ChatMessageORM, ChatSessionORM
from risk_agent.db.pool import get_session_factory
from risk_agent.utils.logging import get_logger

_logger = get_logger(__name__)

_STORE_SCHEMA = "pwc_agent_utility_schema"


# --------------------------------------------------------------------------- #
# Table bootstrap
# --------------------------------------------------------------------------- #


async def ensure_chat_tables_exist() -> None:
    """Create chat tables idempotently using raw DDL (no Alembic required at runtime)."""
    from sqlalchemy import text
    from risk_agent.db.pool import get_pool

    engine = await get_pool()
    statements = [
        f"""CREATE TABLE IF NOT EXISTS {_STORE_SCHEMA}.risk_agent_chat_sessions (
            session_id  VARCHAR PRIMARY KEY,
            user_id     VARCHAR NOT NULL,
            project     VARCHAR,
            title       VARCHAR,
            created_at  TIMESTAMP DEFAULT NOW(),
            updated_at  TIMESTAMP DEFAULT NOW()
        )""",
        f"""CREATE INDEX IF NOT EXISTS ix_ra_chat_sessions_user_id
            ON {_STORE_SCHEMA}.risk_agent_chat_sessions (user_id)""",
        f"""ALTER TABLE {_STORE_SCHEMA}.risk_agent_chat_sessions
            ADD COLUMN IF NOT EXISTS project VARCHAR""",
        f"""CREATE TABLE IF NOT EXISTS {_STORE_SCHEMA}.risk_agent_chat_messages (
            message_id  VARCHAR PRIMARY KEY,
            session_id  VARCHAR NOT NULL
                REFERENCES {_STORE_SCHEMA}.risk_agent_chat_sessions(session_id)
                ON DELETE CASCADE,
            role        VARCHAR NOT NULL,
            content     TEXT    NOT NULL,
            created_at  TIMESTAMP DEFAULT NOW()
        )""",
        f"""CREATE INDEX IF NOT EXISTS ix_ra_chat_messages_session_id
            ON {_STORE_SCHEMA}.risk_agent_chat_messages (session_id)""",
    ]
    async with engine.begin() as conn:
        for stmt in statements:
            await conn.execute(text(stmt))
    _logger.info("chat_store.tables_ready")


# --------------------------------------------------------------------------- #
# Session CRUD
# --------------------------------------------------------------------------- #


def _session_to_dict(s: ChatSessionORM) -> dict:
    return {
        "session_id": s.session_id,
        "user_id": s.user_id,
        "project": s.project,
        "title": s.title,
        "created_at": s.created_at.isoformat() if s.created_at else None,
        "updated_at": s.updated_at.isoformat() if s.updated_at else None,
    }


def _message_to_dict(m: ChatMessageORM) -> dict:
    return {
        "message_id": m.message_id,
        "session_id": m.session_id,
        "role": m.role,
        "content": m.content,
        "created_at": m.created_at.isoformat() if m.created_at else None,
    }


async def create_session(user_id: str, project: str | None = None) -> dict:
    """Create a new chat session and return its metadata."""
    session_factory = get_session_factory()
    async with session_factory() as db:
        async with db.begin():
            orm = ChatSessionORM(
                session_id=str(uuid.uuid4()),
                user_id=user_id,
                project=project,
                title=None,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )
            db.add(orm)
        await db.refresh(orm)
        result = _session_to_dict(orm)
    _logger.info("chat_store.session_created", session_id=result["session_id"], user_id=user_id, project=project)
    return result


async def fetch_session(session_id: str) -> dict | None:
    """Return session metadata or None if not found."""
    session_factory = get_session_factory()
    async with session_factory() as db:
        row = await db.get(ChatSessionORM, session_id)
        return _session_to_dict(row) if row else None


async def list_sessions(user_id: str) -> list[dict]:
    """Return all sessions for a user ordered by most recently updated."""
    session_factory = get_session_factory()
    async with session_factory() as db:
        stmt = (
            select(ChatSessionORM)
            .where(ChatSessionORM.user_id == user_id)
            .order_by(ChatSessionORM.updated_at.desc())
        )
        rows = (await db.execute(stmt)).scalars().all()
        return [_session_to_dict(r) for r in rows]


# --------------------------------------------------------------------------- #
# Message CRUD
# --------------------------------------------------------------------------- #


async def fetch_session_history(session_id: str) -> list[dict]:
    """Return messages for a session as [{role, content}] ordered by created_at."""
    session_factory = get_session_factory()
    async with session_factory() as db:
        stmt = (
            select(ChatMessageORM)
            .where(ChatMessageORM.session_id == session_id)
            .order_by(ChatMessageORM.created_at)
        )
        rows = (await db.execute(stmt)).scalars().all()
        return [{"role": r.role, "content": r.content} for r in rows]


async def fetch_session_messages(session_id: str) -> list[dict]:
    """Return full message dicts (including message_id and created_at) for history view."""
    session_factory = get_session_factory()
    async with session_factory() as db:
        stmt = (
            select(ChatMessageORM)
            .where(ChatMessageORM.session_id == session_id)
            .order_by(ChatMessageORM.created_at)
        )
        rows = (await db.execute(stmt)).scalars().all()
        return [_message_to_dict(r) for r in rows]


async def append_messages(session_id: str, messages: list[dict]) -> None:
    """Bulk-insert new messages and bump session.updated_at."""
    session_factory = get_session_factory()
    now = datetime.utcnow()
    async with session_factory() as db:
        async with db.begin():
            for msg in messages:
                db.add(ChatMessageORM(
                    message_id=str(uuid.uuid4()),
                    session_id=session_id,
                    role=msg["role"],
                    content=msg["content"],
                    created_at=now,
                ))
            await db.execute(
                update(ChatSessionORM)
                .where(ChatSessionORM.session_id == session_id)
                .values(updated_at=now)
            )
    _logger.info("chat_store.messages_appended", session_id=session_id, count=len(messages))


async def set_session_title(session_id: str, title: str) -> None:
    """Set the session title (called once after the first turn)."""
    session_factory = get_session_factory()
    async with session_factory() as db:
        async with db.begin():
            await db.execute(
                update(ChatSessionORM)
                .where(ChatSessionORM.session_id == session_id)
                .values(title=title)
            )


async def delete_session(session_id: str) -> bool:
    """Delete a session and all its messages (cascade). Returns False if not found."""
    from sqlalchemy import delete as sa_delete

    session_factory = get_session_factory()
    async with session_factory() as db:
        async with db.begin():
            result = await db.execute(
                sa_delete(ChatSessionORM).where(ChatSessionORM.session_id == session_id)
            )
    deleted = result.rowcount > 0
    if deleted:
        _logger.info("chat_store.session_deleted", session_id=session_id)
    return deleted
