"""Async persistence layer for RiskReport / RiskFinding objects.

Uses the shared PostgreSQL engine from pool.py and writes to the
pwc_agent_utility_schema schema. No separate database connection needed.

Usage:
    from risk_agent.db.store import save_report, fetch_all_findings, fetch_report
    await save_report(report, pipeline_type="excel")
    findings = await fetch_all_findings(risk_rating="critical")
"""

from __future__ import annotations

import ast
import asyncio
import functools
import json
import os
from datetime import datetime
from typing import Any, Callable, TypeVar
from uuid import UUID

# Set SHUFFLE_WITHIN_DATE=true in env to randomise findings within each date group.
# Dates still descend; only the order within a single calendar day is shuffled.
# Set to false (or remove the var) to restore normal detected_at DESC ordering.
_SHUFFLE_WITHIN_DATE: bool = os.getenv("SHUFFLE_WITHIN_DATE", "false").lower() == "true"
_SHUFFLE_SEED: float = 0.42  # constant seed — ensures stable ordering across paginated calls


def set_shuffle_seed(seed: float) -> float:
    """Update the shuffle seed at runtime. Returns the new seed value."""
    global _SHUFFLE_SEED
    _SHUFFLE_SEED = max(-1.0, min(1.0, seed))  # PostgreSQL setseed range: -1.0 to 1.0
    return _SHUFFLE_SEED


def get_shuffle_config() -> dict:
    return {"shuffle_enabled": _SHUFFLE_WITHIN_DATE, "shuffle_seed": _SHUFFLE_SEED}

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from risk_agent.db.orm_models import Base, FindingORM, ReportORM, RiskInteractionORM, _STORE_SCHEMA
from risk_agent.models.domain import RiskFinding, RiskReport
from risk_agent.utils.logging import get_logger

logger = get_logger(__name__)

_store_session_factory: async_sessionmaker[AsyncSession] | None = None

_T = TypeVar("_T")
_DB_MAX_ATTEMPTS = 3


def _db_retry(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Retry any async DB operation up to _DB_MAX_ATTEMPTS times with exponential backoff.

    Handles transient connection errors (e.g. connection closed mid-operation after
    long-running pipelines). Each attempt is a fresh call so sessions are never reused.
    """
    @functools.wraps(fn)
    async def _wrapper(*args: Any, **kwargs: Any) -> Any:
        last_exc: Exception | None = None
        for attempt in range(_DB_MAX_ATTEMPTS):
            try:
                return await fn(*args, **kwargs)
            except Exception as exc:
                last_exc = exc
                if attempt < _DB_MAX_ATTEMPTS - 1:
                    delay = 2.0 * (attempt + 1)
                    logger.warning(
                        "store.retry",
                        fn=fn.__name__,
                        attempt=attempt + 1,
                        delay_s=delay,
                        error=str(exc),
                    )
                    await asyncio.sleep(delay)
        raise last_exc  # type: ignore[misc]
    return _wrapper


async def _get_factory() -> async_sessionmaker[AsyncSession]:
    global _store_session_factory
    if _store_session_factory is None:
        from risk_agent.db.pool import get_pool
        engine = await get_pool()
        _store_session_factory = async_sessionmaker(engine, expire_on_commit=False)
    return _store_session_factory


async def ensure_tables_exist() -> None:
    """Create tables in pwc_agent_utility_schema if they don't exist yet (idempotent).

    Also applies incremental column migrations (ADD COLUMN IF NOT EXISTS) so that
    new columns added to ORM models are picked up without a full schema recreation.
    """
    from sqlalchemy import text

    from risk_agent.db.pool import get_pool
    engine = await get_pool()
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        # Incremental migrations — safe to re-run (IF NOT EXISTS)
        await conn.execute(text(
            f"ALTER TABLE {_STORE_SCHEMA}.risk_findings "
            "ADD COLUMN IF NOT EXISTS project VARCHAR"
        ))
        await conn.execute(text(
            f"ALTER TABLE {_STORE_SCHEMA}.risk_findings "
            "ADD COLUMN IF NOT EXISTS impacted_sites_count INTEGER"
        ))
        await conn.execute(text(
            f"ALTER TABLE {_STORE_SCHEMA}.risk_findings "
            "ADD COLUMN IF NOT EXISTS area_tags TEXT"
        ))
        await conn.execute(text(
            f"ALTER TABLE {_STORE_SCHEMA}.risk_findings "
            "ADD COLUMN IF NOT EXISTS market_tags TEXT"
        ))
        await conn.execute(text(
            f"ALTER TABLE {_STORE_SCHEMA}.risk_findings "
            "ADD COLUMN IF NOT EXISTS disabled BOOLEAN NOT NULL DEFAULT FALSE"
        ))
    logger.info("store.tables_ready", schema=_STORE_SCHEMA)


def _serialize(value: Any) -> str | None:
    if value is None:
        return None
    try:
        return json.dumps(value, default=str)
    except (TypeError, ValueError):
        logger.warning("store.serialize_failed", value_type=type(value).__name__)
        return None


def _safe_json_loads(raw: str, default: Any = None) -> Any:
    """Parse JSON, falling back to ast.literal_eval for Python-repr strings."""
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        try:
            return ast.literal_eval(raw)
        except (ValueError, SyntaxError):
            logger.warning("store.json_parse_failed", raw_snippet=raw[:120])
            return default


def _report_to_orm(report: RiskReport, pipeline_type: str) -> ReportORM:
    return ReportORM(
        report_id=str(report.report_id),
        category_id=report.category.category_id,
        pipeline_type=pipeline_type,
        steps_planned=report.steps_planned,
        steps_succeeded=report.steps_succeeded,
        steps_failed=report.steps_failed,
        total_rows_examined=report.total_rows_examined,
        started_at=report.started_at.replace(tzinfo=None) if report.started_at else None,
        finished_at=report.finished_at.replace(tzinfo=None) if report.finished_at else None,
        duration_ms=report.duration_ms,
        summary=report.summary,
        created_at=datetime.utcnow(),
    )


def _finding_to_orm(finding: RiskFinding, report_id: str, pipeline_type: str) -> FindingORM:
    return FindingORM(
        finding_id=str(finding.finding_id),
        report_id=report_id,
        category_id=finding.category_id,
        pipeline_type=pipeline_type,
        risk=finding.risk,
        description=finding.description,
        root_cause=finding.root_cause,
        severity=finding.severity.value if finding.severity else None,
        likelihood=finding.likelihood.value if finding.likelihood else None,
        impact=finding.impact.value if finding.impact else None,
        risk_rating=finding.risk_rating.value if finding.risk_rating else None,
        mitigation_actions=_serialize(finding.mitigation_actions),
        recovery_plan=_serialize(finding.recovery_plan),
        drill_down_tables=_serialize(finding.drill_down_tables),
        evidence=_serialize([e.model_dump(mode="json") for e in finding.evidence]),
        region=finding.region,
        project=finding.project,
        impacted_sites_count=finding.impacted_sites_count,
        area_tags=_serialize(finding.area_tags) if finding.area_tags else None,
        market_tags=_serialize(finding.market_tags) if finding.market_tags else None,
        disabled=False,
        detected_at=finding.detected_at.replace(tzinfo=None) if finding.detected_at else None,
        created_at=datetime.utcnow(),
    )


@_db_retry
async def save_report(report: RiskReport, pipeline_type: str) -> None:
    """Persist a complete RiskReport (metadata + all findings) to the store."""
    from sqlalchemy import Integer, cast, func, select

    report_orm = _report_to_orm(report, pipeline_type)
    finding_orms = [
        _finding_to_orm(f, str(report.report_id), pipeline_type) for f in report.findings
    ]
    factory = await _get_factory()
    async with factory() as session:
        async with session.begin():
            session.add(report_orm)
            if finding_orms:
                result = await session.execute(
                    select(
                        func.max(cast(func.substr(FindingORM.finding_id, 3), Integer))
                    ).where(FindingORM.finding_id.like("R-%"))
                )
                last_num = result.scalar_one_or_none() or 0
                for i, orm in enumerate(finding_orms):
                    orm.finding_id = f"R-{last_num + i + 1:04d}"
            session.add_all(finding_orms)
    logger.info(
        "store.saved",
        report_id=str(report.report_id),
        pipeline_type=pipeline_type,
        findings=len(finding_orms),
    )


def _finding_orm_to_dict(row: FindingORM) -> dict[str, Any]:
    return {
        "finding_id": row.finding_id,
        "report_id": row.report_id,
        "category_id": row.category_id,
        "pipeline_type": row.pipeline_type,
        "risk": row.risk,
        "description": row.description,
        "root_cause": row.root_cause,
        "severity": row.severity,
        "likelihood": row.likelihood,
        "impact": row.impact,
        "risk_rating": row.risk_rating,
        "mitigation_actions": _safe_json_loads(row.mitigation_actions, []) if row.mitigation_actions else [],
        "recovery_plan": _safe_json_loads(row.recovery_plan, []) if row.recovery_plan else [],
        "drill_down_tables": _safe_json_loads(row.drill_down_tables, []) if row.drill_down_tables else [],
        "evidence": _safe_json_loads(row.evidence, []) if row.evidence else [],
        "region": row.region,
        "project": row.project,
        "impacted_sites_count": row.impacted_sites_count,
        "area_tags": _safe_json_loads(row.area_tags, []) if row.area_tags else [],
        "market_tags": _safe_json_loads(row.market_tags, []) if row.market_tags else [],
        "action_owner": row.action_owner,
        "status": row.status,
        "disabled": row.disabled,
        "detected_at": row.detected_at.isoformat() if row.detected_at else None,
        "created_at": row.created_at.isoformat() if row.created_at else None,
    }


def _report_orm_to_dict(row: ReportORM, include_findings: bool = False) -> dict[str, Any]:
    d: dict[str, Any] = {
        "report_id": row.report_id,
        "category_id": row.category_id,
        "pipeline_type": row.pipeline_type,
        "steps_planned": row.steps_planned,
        "steps_succeeded": row.steps_succeeded,
        "steps_failed": row.steps_failed,
        "total_rows_examined": row.total_rows_examined,
        "started_at": row.started_at.isoformat() if row.started_at else None,
        "finished_at": row.finished_at.isoformat() if row.finished_at else None,
        "duration_ms": row.duration_ms,
        "summary": row.summary,
        "created_at": row.created_at.isoformat() if row.created_at else None,
    }
    if include_findings:
        d["findings"] = [_finding_orm_to_dict(f) for f in row.findings]
    return d


@_db_retry
async def fetch_all_findings(
    pipeline_type: str | None = None,
    category_id: str | None = None,
    risk_rating: str | None = None,
    limit: int = 100,
    offset: int = 0,
) -> list[dict[str, Any]]:
    """Return paginated, filterable list of stored findings."""
    from sqlalchemy import select

    factory = await _get_factory()
    async with factory() as session:
        stmt = select(FindingORM).where(FindingORM.disabled == False)  # noqa: E712
        if pipeline_type:
            stmt = stmt.where(FindingORM.pipeline_type == pipeline_type)
        if category_id:
            stmt = stmt.where(FindingORM.category_id == category_id)
        if risk_rating:
            stmt = stmt.where(FindingORM.risk_rating == risk_rating)
        stmt = stmt.order_by(FindingORM.detected_at.desc()).limit(limit).offset(offset)
        result = await session.execute(stmt)
        return [_finding_orm_to_dict(row) for row in result.scalars().all()]


@_db_retry
async def fetch_finding(finding_id: str) -> dict[str, Any] | None:
    """Return a single finding by ID, or None if not found."""
    from sqlalchemy import select

    factory = await _get_factory()
    async with factory() as session:
        result = await session.execute(
            select(FindingORM).where(FindingORM.finding_id == finding_id)
        )
        row = result.scalar_one_or_none()
        return _finding_orm_to_dict(row) if row else None


@_db_retry
async def fetch_all_reports(
    pipeline_type: str | None = None,
    limit: int = 50,
    offset: int = 0,
) -> list[dict[str, Any]]:
    """Return paginated report metadata (no findings payload)."""
    from sqlalchemy import select

    factory = await _get_factory()
    async with factory() as session:
        stmt = select(ReportORM)
        if pipeline_type:
            stmt = stmt.where(ReportORM.pipeline_type == pipeline_type)
        stmt = stmt.order_by(ReportORM.created_at.desc()).limit(limit).offset(offset)
        result = await session.execute(stmt)
        return [_report_orm_to_dict(row, include_findings=False) for row in result.scalars().all()]


@_db_retry
async def fetch_report(report_id: str | UUID) -> dict[str, Any] | None:
    """Return a full report with all findings, or None if not found."""
    from sqlalchemy import select
    from sqlalchemy.orm import selectinload

    factory = await _get_factory()
    async with factory() as session:
        result = await session.execute(
            select(ReportORM)
            .options(selectinload(ReportORM.findings))
            .where(ReportORM.report_id == str(report_id))
        )
        row = result.scalar_one_or_none()
        return _report_orm_to_dict(row, include_findings=True) if row else None


def _finding_orm_to_detail(row: FindingORM) -> dict[str, Any]:
    """Convert FindingORM to detail dict for drill-down view."""
    detected_at_str = None
    if row.detected_at:
        # Return full timestamp in ISO format
        detected_at_str = row.detected_at.isoformat()
    
    return {
        "finding_id": row.finding_id,
        "category_id": row.category_id,
        "risk": row.risk,
        "description": row.description,
        "root_cause": row.root_cause,
        "likelihood": row.likelihood,
        "impact": row.impact,
        "severity": row.severity,
        "mitigation_actions": _safe_json_loads(row.mitigation_actions) if row.mitigation_actions else None,
        "recovery_plan": _safe_json_loads(row.recovery_plan) if row.recovery_plan else None,
        "drill_down_tables": _safe_json_loads(row.drill_down_tables) if row.drill_down_tables else None,
        "region": row.region,
        "project": row.project,
        "impacted_sites_count": row.impacted_sites_count,
        "area_tags": _safe_json_loads(row.area_tags, []) if row.area_tags else [],
        "market_tags": _safe_json_loads(row.market_tags, []) if row.market_tags else [],
        "action_owner": row.action_owner,
        "status": row.status,
        "disabled": row.disabled,
        "detected_at": detected_at_str,
    }


@_db_retry
async def fetch_findings_summary(
    project: str | None = None,
    category_id: str | None = None,
    user_id: str | None = None,
    risk_rating: str | None = None,
    likelihood: str | None = None,
    impact: str | None = None,
    region: str | None = None,
    area: str | None = None,
    market: str | None = None,
    limit: int = 10,
    offset: int = 0,
) -> dict[str, Any]:
    """Return paginated list of risk findings with optional filters."""
    from sqlalchemy import and_, func, select

    factory = await _get_factory()
    async with factory() as session:
        join_cond = RiskInteractionORM.finding_id == FindingORM.finding_id
        if user_id:
            join_cond = and_(join_cond, RiskInteractionORM.user_id == user_id)

        def _apply_filters(stmt: Any) -> Any:
            stmt = stmt.where(FindingORM.disabled == False)  # noqa: E712
            if project:
                stmt = stmt.where(FindingORM.project == project)
            if category_id:
                stmt = stmt.where(FindingORM.category_id == category_id)
            if risk_rating:
                stmt = stmt.where(FindingORM.risk_rating == risk_rating)
            if likelihood:
                stmt = stmt.where(FindingORM.likelihood == likelihood)
            if impact:
                stmt = stmt.where(FindingORM.impact == impact)
            if region:
                stmt = stmt.where(FindingORM.region == region)
            if area:
                stmt = stmt.where(FindingORM.area_tags.like(f'%"{area}"%'))
            if market:
                stmt = stmt.where(FindingORM.market_tags.like(f'%"{market}"%'))
            return stmt

        count_stmt = _apply_filters(
            select(func.count(FindingORM.finding_id))
            .outerjoin(RiskInteractionORM, join_cond)
        )
        total: int = (await session.execute(count_stmt)).scalar_one()

        _dt_col = func.coalesce(FindingORM.detected_at, FindingORM.created_at)
        if _SHUFFLE_WITHIN_DATE:
            from sqlalchemy import text
            await session.execute(text("SELECT setseed(:s)"), {"s": _SHUFFLE_SEED})
            _order = (func.date(_dt_col).desc(), func.random())
        else:
            _order = (_dt_col.desc(),)
        data_stmt = _apply_filters(
            select(FindingORM, RiskInteractionORM)
            .outerjoin(RiskInteractionORM, join_cond)
        ).order_by(*_order).limit(limit).offset(offset)
        result = await session.execute(data_stmt)

        findings = []
        for finding, interaction in result.all():
            _dt = finding.detected_at or finding.created_at
            detected_at_str = _dt.date().isoformat() if _dt else None
            findings.append({
                "finding_id": finding.finding_id,
                "category_id": finding.category_id,
                "risk": finding.risk,
                "description": finding.description,
                "likelihood": finding.likelihood,
                "impact": finding.impact,
                "severity": finding.severity,
                "region": finding.region,
                "project": finding.project,
                "detected_at": detected_at_str,
                "action_owner": finding.action_owner,
                "status": finding.status,
                "disabled": finding.disabled,
                "liked": interaction.liked if interaction else False,
                "disliked": interaction.disliked if interaction else False,
                "acknowledged": interaction.acknowledged if interaction else False,
                "muted": interaction.muted if interaction else False,
                "feedback": interaction.feedback if interaction else None,
            })
        return {"total": total, "findings": findings}


@_db_retry
async def fetch_risk_heatmap(
    project: str | None = None,
    region: str | None = None,
    area: str | None = None,
    market: str | None = None,
) -> list[dict[str, Any]]:
    """Return findings aggregated into a 3x3 likelihood × impact heatmap grid."""
    from sqlalchemy import func, select
    from risk_agent.utils.risk_assessment import RISK_RATING_MATRIX
    from risk_agent.models.domain import RiskLikelihood, RiskImpact

    factory = await _get_factory()
    async with factory() as session:
        stmt = (
            select(
                FindingORM.likelihood,
                FindingORM.impact,
                FindingORM.category_id,
                func.count(FindingORM.finding_id).label("count"),
            )
            .where(FindingORM.disabled == False)  # noqa: E712
            .where(FindingORM.likelihood.isnot(None))
            .where(FindingORM.impact.isnot(None))
        )
        if project:
            stmt = stmt.where(FindingORM.project == project)
        if region:
            stmt = stmt.where(FindingORM.region == region)
        if area:
            stmt = stmt.where(FindingORM.area_tags.like(f'%"{area}"%'))
        if market:
            stmt = stmt.where(FindingORM.market_tags.like(f'%"{market}"%'))
        stmt = stmt.group_by(FindingORM.likelihood, FindingORM.impact, FindingORM.category_id)
        result = await session.execute(stmt)
        rows = result.all()

    # aggregate counts into {(likelihood, impact): {category_id: count}}
    cell_data: dict[tuple[str, str], dict[str, int]] = {}
    for row in rows:
        key = (row.likelihood, row.impact)
        if key not in cell_data:
            cell_data[key] = {}
        if row.category_id:
            cell_data[key][row.category_id] = row.count

    # build all 9 cells, including empty ones
    heatmap = []
    for likelihood in RiskLikelihood:
        for impact in RiskImpact:
            risk_rating = RISK_RATING_MATRIX.get((likelihood, impact))
            cats = cell_data.get((likelihood.value, impact.value), {})
            heatmap.append({
                "likelihood": likelihood.value,
                "impact": impact.value,
                "risk_rating": risk_rating.value if risk_rating else None,
                "total": sum(cats.values()),
                "categories": [
                    {"category_id": cat_id, "count": count}
                    for cat_id, count in sorted(cats.items(), key=lambda x: -x[1])
                ],
            })

    return heatmap


def _finding_orm_to_summary(row: FindingORM) -> dict[str, Any]:
    _dt = row.detected_at or row.created_at
    return {
        "finding_id": row.finding_id,
        "category_id": row.category_id,
        "risk": row.risk,
        "description": row.description,
        "likelihood": row.likelihood,
        "impact": row.impact,
        "severity": row.severity,
        "region": row.region,
        "project": row.project,
        "detected_at": _dt.date().isoformat() if _dt else None,
        "action_owner": row.action_owner,
        "status": row.status,
        "disabled": row.disabled,
        "liked": False,
        "disliked": False,
        "acknowledged": False,
        "muted": False,
        "feedback": None,
    }


_UNSET: object = object()


@_db_retry
async def update_finding(
    finding_id: str,
    action_owner: Any = _UNSET,
    status: str | None = None,
) -> dict[str, Any] | None:
    """Update action_owner and/or status on a finding. Returns updated dict or None if not found."""
    from sqlalchemy import select

    factory = await _get_factory()
    async with factory() as session:
        async with session.begin():
            result = await session.execute(
                select(FindingORM).where(FindingORM.finding_id == finding_id)
            )
            row = result.scalar_one_or_none()
            if row is None:
                return None
            if action_owner is not _UNSET:
                row.action_owner = action_owner
            if status is not None:
                row.status = status
        return _finding_orm_to_summary(row)


@_db_retry
async def set_finding_disabled(finding_id: str, disabled: bool) -> dict[str, Any] | None:
    """Set the disabled flag on a finding. Returns updated summary dict or None if not found."""
    from sqlalchemy import select

    factory = await _get_factory()
    async with factory() as session:
        async with session.begin():
            result = await session.execute(
                select(FindingORM).where(FindingORM.finding_id == finding_id)
            )
            row = result.scalar_one_or_none()
            if row is None:
                return None
            row.disabled = disabled
        return _finding_orm_to_summary(row)


@_db_retry
async def fetch_finding_detail(finding_id: str) -> dict[str, Any] | None:
    """Return detailed information for a single finding."""
    from sqlalchemy import select

    factory = await _get_factory()
    async with factory() as session:
        result = await session.execute(
            select(FindingORM).where(FindingORM.finding_id == finding_id)
        )
        row = result.scalar_one_or_none()
        return _finding_orm_to_detail(row) if row else None


@_db_retry
async def fetch_risk_kpis(
    project: str | None = None,
    region: str | None = None,
    area: str | None = None,
    market: str | None = None,
) -> dict[str, Any]:
    """Return risk findings KPIs. Pass project/region/area/market to scope results."""
    from sqlalchemy import func, select

    def _apply_geo(stmt: Any) -> Any:
        stmt = stmt.where(FindingORM.disabled == False)  # noqa: E712
        if project:
            stmt = stmt.where(FindingORM.project == project)
        if region:
            stmt = stmt.where(FindingORM.region == region)
        if area:
            stmt = stmt.where(FindingORM.area_tags.like(f'%"{area}"%'))
        if market:
            stmt = stmt.where(FindingORM.market_tags.like(f'%"{market}"%'))
        return stmt

    factory = await _get_factory()
    async with factory() as session:
        total_risks = (
            await session.execute(_apply_geo(select(func.count(FindingORM.finding_id))))
        ).scalar() or 0

        severity_stmt = _apply_geo(
            select(
                FindingORM.severity,
                func.count(FindingORM.finding_id).label("count"),
            ).group_by(FindingORM.severity)
        )
        severity_counts = {
            row.severity: row.count
            for row in (await session.execute(severity_stmt))
        }

        return {
            "project": project,
            "total_risks": total_risks,
            "critical_severity_count": severity_counts.get("critical", 0),
            "high_severity_count": severity_counts.get("high", 0),
            "medium_severity_count": severity_counts.get("medium", 0),
            "low_severity_count": severity_counts.get("low", 0),
        }


def _interaction_to_dict(row: RiskInteractionORM) -> dict[str, Any]:
    return {
        "interaction_id": row.interaction_id,
        "finding_id": row.finding_id,
        "user_id": row.user_id,
        "liked": row.liked,
        "disliked": row.disliked,
        "acknowledged": row.acknowledged,
        "muted": row.muted,
        "feedback": row.feedback,
        "created_at": row.created_at.isoformat() if row.created_at else None,
        "updated_at": row.updated_at.isoformat() if row.updated_at else None,
    }


async def _get_or_create_interaction(session: Any, finding_id: str, user_id: str) -> RiskInteractionORM:
    from sqlalchemy import select
    import uuid

    result = await session.execute(
        select(RiskInteractionORM).where(
            RiskInteractionORM.finding_id == finding_id,
            RiskInteractionORM.user_id == user_id,
        )
    )
    row = result.scalar_one_or_none()
    if row is None:
        now = datetime.utcnow()
        row = RiskInteractionORM(
            interaction_id=str(uuid.uuid4()),
            finding_id=finding_id,
            user_id=user_id,
            liked=False,
            disliked=False,
            acknowledged=False,
            muted=False,
            created_at=now,
            updated_at=now,
        )
        session.add(row)
    return row


@_db_retry
async def toggle_liked(finding_id: str, user_id: str, feedback: str | None = None) -> dict[str, Any]:
    factory = await _get_factory()
    async with factory() as session:
        async with session.begin():
            row = await _get_or_create_interaction(session, finding_id, user_id)
            if row.liked:
                # Already liked — only update feedback, never unset liked
                if feedback is not None:
                    row.feedback = feedback
            else:
                # Not liked yet — activate, clear disliked
                row.liked = True
                row.disliked = False
                row.feedback = feedback
            row.updated_at = datetime.utcnow()
        return _interaction_to_dict(row)


@_db_retry
async def toggle_disliked(finding_id: str, user_id: str, feedback: str | None = None) -> dict[str, Any]:
    factory = await _get_factory()
    async with factory() as session:
        async with session.begin():
            row = await _get_or_create_interaction(session, finding_id, user_id)
            if row.disliked:
                # Already disliked — only update feedback, never unset disliked
                if feedback is not None:
                    row.feedback = feedback
            else:
                # Not disliked yet — activate, clear liked
                row.disliked = True
                row.liked = False
                row.feedback = feedback
            row.updated_at = datetime.utcnow()
        return _interaction_to_dict(row)


@_db_retry
async def toggle_acknowledged(finding_id: str, user_id: str) -> dict[str, Any]:
    """Toggle acknowledged state for a finding."""
    factory = await _get_factory()
    async with factory() as session:
        async with session.begin():
            row = await _get_or_create_interaction(session, finding_id, user_id)
            row.acknowledged = not row.acknowledged
            row.updated_at = datetime.utcnow()
        return _interaction_to_dict(row)


@_db_retry
async def toggle_muted(finding_id: str, user_id: str) -> dict[str, Any]:
    """Toggle muted state for a finding."""
    factory = await _get_factory()
    async with factory() as session:
        async with session.begin():
            row = await _get_or_create_interaction(session, finding_id, user_id)
            row.muted = not row.muted
            row.updated_at = datetime.utcnow()
        return _interaction_to_dict(row)


@_db_retry
async def fetch_user_interactions(user_id: str) -> list[dict[str, Any]]:
    """Return all interactions for a given user."""
    from sqlalchemy import select

    factory = await _get_factory()
    async with factory() as session:
        result = await session.execute(
            select(RiskInteractionORM).where(RiskInteractionORM.user_id == user_id)
        )
        return [_interaction_to_dict(row) for row in result.scalars().all()]


def _finding_with_interaction_dict(finding: FindingORM, interaction: RiskInteractionORM) -> dict[str, Any]:
    _dt = finding.detected_at or finding.created_at
    return {
        "finding_id": finding.finding_id,
        "category_id": finding.category_id,
        "risk": finding.risk,
        "description": finding.description,
        "likelihood": finding.likelihood,
        "impact": finding.impact,
        "severity": finding.severity,
        "region": finding.region,
        "project": finding.project,
        "detected_at": _dt.date().isoformat() if _dt else None,
        "action_owner": finding.action_owner,
        "status": finding.status,
        "disabled": finding.disabled,
        "liked": interaction.liked,
        "disliked": interaction.disliked,
        "acknowledged": interaction.acknowledged,
        "muted": interaction.muted,
        "feedback": interaction.feedback,
    }


@_db_retry
async def fetch_muted_findings(
    user_id: str,
    project: str | None = None,
    region: str | None = None,
    area: str | None = None,
    market: str | None = None,
) -> list[dict[str, Any]]:
    """Return findings muted by a user in /findings list format."""
    from sqlalchemy import select

    factory = await _get_factory()
    async with factory() as session:
        stmt = (
            select(FindingORM, RiskInteractionORM)
            .join(RiskInteractionORM, RiskInteractionORM.finding_id == FindingORM.finding_id)
            .where(
                RiskInteractionORM.user_id == user_id,
                RiskInteractionORM.muted == True,  # noqa: E712
            )
        )
        if project:
            stmt = stmt.where(FindingORM.project == project)
        if region:
            stmt = stmt.where(FindingORM.region == region)
        if area:
            stmt = stmt.where(FindingORM.area_tags.like(f'%"{area}"%'))
        if market:
            stmt = stmt.where(FindingORM.market_tags.like(f'%"{market}"%'))
        result = await session.execute(stmt)
        return [_finding_with_interaction_dict(f, i) for f, i in result.all()]


@_db_retry
async def fetch_acknowledged_findings(
    user_id: str,
    project: str | None = None,
    region: str | None = None,
    area: str | None = None,
    market: str | None = None,
) -> list[dict[str, Any]]:
    """Return findings acknowledged by a user in /findings list format."""
    from sqlalchemy import select

    factory = await _get_factory()
    async with factory() as session:
        stmt = (
            select(FindingORM, RiskInteractionORM)
            .join(RiskInteractionORM, RiskInteractionORM.finding_id == FindingORM.finding_id)
            .where(
                RiskInteractionORM.user_id == user_id,
                RiskInteractionORM.acknowledged == True,  # noqa: E712
            )
        )
        if project:
            stmt = stmt.where(FindingORM.project == project)
        if region:
            stmt = stmt.where(FindingORM.region == region)
        if area:
            stmt = stmt.where(FindingORM.area_tags.like(f'%"{area}"%'))
        if market:
            stmt = stmt.where(FindingORM.market_tags.like(f'%"{market}"%'))
        result = await session.execute(stmt)
        return [_finding_with_interaction_dict(f, i) for f, i in result.all()]


@_db_retry
async def fetch_risk_distribution_by_category(
    project: str | None = None,
    region: str | None = None,
    area: str | None = None,
    market: str | None = None,
) -> dict[str, Any]:
    """Return risk distribution by category in Highcharts pie chart format."""
    from sqlalchemy import func, select

    factory = await _get_factory()
    async with factory() as session:
        stmt = select(
            FindingORM.category_id,
            func.count(FindingORM.finding_id).label("count"),
        ).where(FindingORM.disabled == False).group_by(FindingORM.category_id).order_by(func.count(FindingORM.finding_id).desc())  # noqa: E712
        if project:
            stmt = stmt.where(FindingORM.project == project)
        if region:
            stmt = stmt.where(FindingORM.region == region)
        if area:
            stmt = stmt.where(FindingORM.area_tags.like(f'%"{area}"%'))
        if market:
            stmt = stmt.where(FindingORM.market_tags.like(f'%"{market}"%'))

        result = await session.execute(stmt)
        category_counts = [{"name": row.category_id, "y": row.count} for row in result]

        # Return Highcharts pie chart configuration
        return {
            "chart": {
                "type": "pie",
                "zooming": {
                    "type": "xy"
                },
                "panning": {
                    "enabled": True,
                    "type": "xy"
                },
                "panKey": "shift"
            },
            "title": {
                "text": "Risk Distribution by Category"
            },
            "tooltip": {
                "valueSuffix": "",
                "pointFormat": "{series.name}: <b>{point.y}</b><br/>"
            },
            "subtitle": {
                "text": "Distribution of risk findings across categories"
            },
            "plotOptions": {
                "pie": {
                    "allowPointSelect": True,
                    "cursor": "pointer",
                    "dataLabels": [
                        {
                            "enabled": True,
                            "distance": 20,
                            "format": "{point.name}"
                        },
                        {
                            "enabled": True,
                            "distance": -40,
                            "format": "{point.y}",
                            "style": {
                                "fontSize": "1.2em",
                                "textOutline": "none",
                                "opacity": 0.7
                            },
                            "filter": {
                                "operator": ">",
                                "property": "y",
                                "value": 100
                            }
                        }
                    ]
                }
            },
            "series": [
                {
                    "name": "Count",
                    "colorByPoint": True,
                    "data": category_counts
                }
            ]
        }


@_db_retry
async def fetch_risk_distribution(
    project: str | None = None,
    region: str | None = None,
    area: str | None = None,
    market: str | None = None,
) -> dict[str, Any]:
    """Return risk distribution by category as raw data plus a unique categories list."""
    from sqlalchemy import func, select

    factory = await _get_factory()
    async with factory() as session:
        stmt = (
            select(
                FindingORM.category_id,
                func.count(FindingORM.finding_id).label("count"),
            )
            .where(FindingORM.disabled == False)  # noqa: E712
            .where(FindingORM.category_id.isnot(None))
            .group_by(FindingORM.category_id)
            .order_by(func.count(FindingORM.finding_id).desc())
        )
        if project:
            stmt = stmt.where(FindingORM.project == project)
        if region:
            stmt = stmt.where(FindingORM.region == region)
        if area:
            stmt = stmt.where(FindingORM.area_tags.like(f'%"{area}"%'))
        if market:
            stmt = stmt.where(FindingORM.market_tags.like(f'%"{market}"%'))
        result = await session.execute(stmt)
        rows = result.all()

    distribution = [{"category_id": row.category_id, "count": row.count} for row in rows]
    categories = [row["category_id"] for row in distribution]
    return {"distribution": distribution, "categories": categories}

