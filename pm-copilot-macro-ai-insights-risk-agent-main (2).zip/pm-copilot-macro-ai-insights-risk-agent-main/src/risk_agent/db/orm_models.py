"""SQLAlchemy ORM models for persisting risk reports and findings.

Tables are created in the pwc_agent_utility_schema Postgres schema.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

_STORE_SCHEMA = "pwc_agent_utility_schema"


class Base(DeclarativeBase):
    pass


class ReportORM(Base):
    __tablename__ = "risk_reports"
    __table_args__ = {"schema": _STORE_SCHEMA}

    report_id: Mapped[str] = mapped_column(String, primary_key=True)
    category_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    pipeline_type: Mapped[str] = mapped_column(String, nullable=False, index=True)
    steps_planned: Mapped[int | None] = mapped_column(Integer)
    steps_succeeded: Mapped[int | None] = mapped_column(Integer)
    steps_failed: Mapped[int | None] = mapped_column(Integer)
    total_rows_examined: Mapped[int | None] = mapped_column(Integer)
    started_at: Mapped[datetime | None] = mapped_column(DateTime)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime)
    duration_ms: Mapped[float | None] = mapped_column(Float)
    summary: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    findings: Mapped[list[FindingORM]] = relationship(
        "FindingORM", back_populates="report", cascade="all, delete-orphan"
    )


class FindingORM(Base):
    __tablename__ = "risk_findings"
    __table_args__ = {"schema": _STORE_SCHEMA}

    finding_id: Mapped[str] = mapped_column(String, primary_key=True)
    report_id: Mapped[str] = mapped_column(
        String,
        ForeignKey(f"{_STORE_SCHEMA}.risk_reports.report_id"),
        nullable=False,
        index=True,
    )
    category_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    pipeline_type: Mapped[str] = mapped_column(String, nullable=False, index=True)
    risk: Mapped[str] = mapped_column(String, nullable=False)
    description: Mapped[str | None] = mapped_column(Text)
    root_cause: Mapped[str | None] = mapped_column(Text)
    severity: Mapped[str | None] = mapped_column(String, index=True)
    likelihood: Mapped[str | None] = mapped_column(String)
    impact: Mapped[str | None] = mapped_column(String)
    risk_rating: Mapped[str | None] = mapped_column(String, index=True)
    mitigation_actions: Mapped[str | None] = mapped_column(Text)  # JSON string
    recovery_plan: Mapped[str | None] = mapped_column(Text)       # JSON string
    drill_down_tables: Mapped[str | None] = mapped_column(Text)   # JSON string
    evidence: Mapped[str | None] = mapped_column(Text)            # JSON string
    region: Mapped[str | None] = mapped_column(String, index=True)
    project: Mapped[str | None] = mapped_column(String, index=True)
    impacted_sites_count: Mapped[int | None] = mapped_column(Integer)
    area_tags: Mapped[str | None] = mapped_column(Text)   # JSON array of area names
    market_tags: Mapped[str | None] = mapped_column(Text) # JSON array of market names
    action_owner: Mapped[str | None] = mapped_column(String)
    status: Mapped[str] = mapped_column(String, default="Open", nullable=False)
    disabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    detected_at: Mapped[datetime | None] = mapped_column(DateTime, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    report: Mapped[ReportORM] = relationship("ReportORM", back_populates="findings")


class ChatSessionORM(Base):
    __tablename__ = "risk_agent_chat_sessions"
    __table_args__ = {"schema": _STORE_SCHEMA}

    session_id: Mapped[str] = mapped_column(String, primary_key=True)
    user_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    project: Mapped[str | None] = mapped_column(String, index=True)
    title: Mapped[str | None] = mapped_column(String)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    messages: Mapped[list[ChatMessageORM]] = relationship(
        "ChatMessageORM", back_populates="session", cascade="all, delete-orphan",
        order_by="ChatMessageORM.created_at",
    )


class ChatMessageORM(Base):
    __tablename__ = "risk_agent_chat_messages"
    __table_args__ = {"schema": _STORE_SCHEMA}

    message_id: Mapped[str] = mapped_column(String, primary_key=True)
    session_id: Mapped[str] = mapped_column(
        String,
        ForeignKey(f"{_STORE_SCHEMA}.risk_agent_chat_sessions.session_id"),
        nullable=False,
        index=True,
    )
    role: Mapped[str] = mapped_column(String, nullable=False)  # 'user' | 'assistant'
    content: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    session: Mapped[ChatSessionORM] = relationship("ChatSessionORM", back_populates="messages")


class RiskInteractionORM(Base):
    __tablename__ = "risk_interactions"
    __table_args__ = (
        UniqueConstraint("finding_id", "user_id", name="uq_risk_interaction_user"),
        {"schema": _STORE_SCHEMA},
    )

    interaction_id: Mapped[str] = mapped_column(String, primary_key=True)
    finding_id: Mapped[str] = mapped_column(
        String,
        ForeignKey(f"{_STORE_SCHEMA}.risk_findings.finding_id"),
        nullable=False,
        index=True,
    )
    user_id: Mapped[str] = mapped_column(String, nullable=False, index=True)
    liked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    disliked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    acknowledged: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    muted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    feedback: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
