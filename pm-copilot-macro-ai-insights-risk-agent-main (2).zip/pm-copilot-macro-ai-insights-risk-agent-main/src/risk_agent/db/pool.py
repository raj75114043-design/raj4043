"""Async SQLAlchemy engine + session factory.

Pattern copied from the working ai_insights_risk reference project.
Uses SQLAlchemy async + asyncpg driver (postgresql+asyncpg://...)
instead of psycopg3 — which is what proved to work against this
Postgres server.

External interface (init_pool, close_pool, get_pool, fetch_all) is
kept stable so the rest of the codebase doesn't need to change.
"""

from __future__ import annotations

import re
from typing import Any

from sqlalchemy import text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from risk_agent.config import get_settings
from risk_agent.utils.exceptions import DatabaseError
from risk_agent.utils.logging import get_logger

_logger = get_logger(__name__)

_engine: AsyncEngine | None = None
_session_factory: async_sessionmaker[AsyncSession] | None = None


# ------------------------------------------------------------------ #
# Parameter-style converter: psycopg %(name)s  ->  SQLAlchemy :name
# Existing call sites use %(name)s + dict params (psycopg style).
# SQLAlchemy text() uses :name style, so we translate.
# ------------------------------------------------------------------ #
_NAMED_PARAM = re.compile(r"%\((\w+)\)s")


def _convert_params(sql: str) -> str:
    """'%(x)s'  ->  ':x'   (dict params pass through unchanged)."""
    return _NAMED_PARAM.sub(lambda m: f":{m.group(1)}", sql)


# ------------------------------------------------------------------ #
# Engine / pool lifecycle
# ------------------------------------------------------------------ #
def _build_engine(url: str) -> AsyncEngine:
    """Build an async engine — same kwargs as the working reference."""
    settings = get_settings()
    return create_async_engine(
        url,
        pool_size=settings.postgres.pool_size,
        max_overflow=settings.postgres.max_overflow,
        pool_timeout=settings.postgres.pool_timeout,
        pool_pre_ping=True,  # detect stale connections
        echo=False,
    )


async def init_pool() -> AsyncEngine:
    """Create the global async engine and verify connectivity."""
    global _engine, _session_factory
    if _engine is not None:
        return _engine

    pg = get_settings().postgres

    if not pg.database_url:
        raise DatabaseError(
            "DATABASE_URL is not set. Expected a value like "
            "postgresql+asyncpg://user:password@host:port/dbname in .env"
        )

    _logger.info(
        "initializing_postgres_engine",
        host=pg.host,
        port=pg.port,
        db=pg.db,
        user=pg.user,
        pool_size=pg.pool_size,
        max_overflow=pg.max_overflow,
    )

    engine = _build_engine(pg.database_url)

    # Pre-flight SELECT 1 — surfaces real errors (auth, network, SSL)
    # instead of a silent timeout later.
    try:
        async with engine.connect() as conn:
            await conn.execute(text("SELECT 1"))
        _logger.info("postgres_preflight_ok")
    except Exception as exc:
        await engine.dispose()
        _logger.error(
            "postgres_preflight_failed",
            error_type=type(exc).__name__,
            error=str(exc) or repr(exc),
            host=pg.host,
            port=pg.port,
        )
        raise DatabaseError(
            f"Cannot connect to Postgres at {pg.host}:{pg.port} as "
            f"user '{pg.user}': {type(exc).__name__}: {exc or repr(exc)}"
        ) from exc

    _engine = engine
    _session_factory = async_sessionmaker(
        bind=engine,
        expire_on_commit=False,
        autoflush=False,
        autocommit=False,
    )
    return _engine


async def close_pool() -> None:
    """Dispose of the global engine on shutdown."""
    global _engine, _session_factory
    if _engine is not None:
        _logger.info("closing_postgres_engine")
        await _engine.dispose()
        _engine = None
        _session_factory = None


async def get_pool() -> AsyncEngine:
    """Return the global engine, initializing it if needed."""
    if _engine is None:
        return await init_pool()
    return _engine


def get_session_factory() -> async_sessionmaker[AsyncSession]:
    if _session_factory is None:
        raise DatabaseError("Session factory not initialized; call init_pool() first.")
    return _session_factory


# ------------------------------------------------------------------ #
# Query helpers
# ------------------------------------------------------------------ #
async def fetch_all(
    sql: str,
    params: dict[str, Any] | None = None,
    timeout: float | None = None,
) -> list[dict[str, Any]]:
    """Execute a read-only query and return all rows as dicts.

    Accepts psycopg-style named parameters (%(name)s) with a dict so
    existing call sites work unchanged.
    """
    engine = await get_pool()
    converted_sql = _convert_params(sql)

    try:
        async with engine.connect() as conn:
            result = await conn.execute(text(converted_sql), params or {})
            return [dict(row._mapping) for row in result]
    except Exception as exc:
        _logger.error(
            "postgres_query_failed",
            error=str(exc),
            sql_preview=sql[:200],
        )
        raise DatabaseError(f"Query failed: {exc}") from exc