"""Postgres schema introspection.

The planner grounds its SQL in a single target table
(``TARGET_TABLE_SCHEMA.TARGET_TABLE_NAME``). This module introspects that
table — column names, data types, nullability, char/numeric precision —
and renders a compact block suitable for inclusion in an LLM prompt.

The introspected schema is cached in memory for the lifetime of the
process; it's read-only metadata that doesn't change during a run.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from risk_agent.config import get_settings
from risk_agent.db.pool import fetch_all
from risk_agent.utils.exceptions import DatabaseError
from risk_agent.utils.logging import get_logger

_logger = get_logger(__name__)


# --------------------------------------------------------------------------- #
# Data classes
# --------------------------------------------------------------------------- #


@dataclass
class Column:
    """Single column metadata from information_schema.columns."""

    name: str
    data_type: str
    is_nullable: bool
    character_maximum_length: int | None = None
    numeric_precision: int | None = None
    numeric_scale: int | None = None
    column_default: str | None = None

    def to_prompt_line(self) -> str:
        """Render one line of schema text for inclusion in an LLM prompt."""
        # Example:  - billing_amount (numeric(18,4) NOT NULL)
        dtype = self.data_type
        if self.data_type in ("character varying", "varchar", "character") and self.character_maximum_length:
            dtype = f"{self.data_type}({self.character_maximum_length})"
        elif self.data_type == "numeric" and self.numeric_precision:
            if self.numeric_scale is not None:
                dtype = f"numeric({self.numeric_precision},{self.numeric_scale})"
            else:
                dtype = f"numeric({self.numeric_precision})"

        null_part = "" if self.is_nullable else " NOT NULL"
        return f"  - {self.name} ({dtype}{null_part})"


@dataclass
class Table:
    """Single table with its column list."""

    schema: str
    name: str
    columns: list[Column] = field(default_factory=list)

    @property
    def qualified_name(self) -> str:
        """Schema-qualified, double-quoted identifier — safe for raw SQL."""
        return f'"{self.schema}"."{self.name}"'

    def to_prompt_block(self) -> str:
        """Render this table as a prompt-ready block."""
        header = f"Table {self.qualified_name}:"
        if not self.columns:
            return header + "\n  (no columns introspected)"
        col_lines = [c.to_prompt_line() for c in self.columns]
        return header + "\n" + "\n".join(col_lines)


@dataclass
class Schema:
    """Collection of tables (here, almost always exactly one — the target)."""

    tables: list[Table] = field(default_factory=list)

    def to_prompt(self, max_tables: int = 50) -> str:
        """Render the schema as text for inclusion in an LLM prompt."""
        subset = self.tables[:max_tables]
        return "\n\n".join(t.to_prompt_block() for t in subset)

    @property
    def is_empty(self) -> bool:
        return not self.tables or all(not t.columns for t in self.tables)


# --------------------------------------------------------------------------- #
# Introspection queries
# --------------------------------------------------------------------------- #

# Full metadata pulled so the LLM sees types, lengths, precisions, and
# NOT-NULL information. We explicitly filter by both schema + table so
# we hit the information_schema index cleanly.
_TARGET_TABLE_QUERY = """
SELECT
    column_name,
    data_type,
    is_nullable,
    character_maximum_length,
    numeric_precision,
    numeric_scale,
    column_default
FROM information_schema.columns
WHERE table_schema = %(schema)s
  AND table_name   = %(table)s
ORDER BY ordinal_position
"""

# Legacy "entire schema" query — kept for back-compat so any callers of the
# old load_schema() still get something reasonable without crashing.
_FULL_SCHEMA_QUERY = """
SELECT
    table_schema,
    table_name,
    column_name,
    data_type,
    is_nullable,
    character_maximum_length,
    numeric_precision,
    numeric_scale,
    column_default
FROM information_schema.columns
WHERE table_schema = %(schema)s
ORDER BY table_name, ordinal_position
"""

# --------------------------------------------------------------------------- #
# Caches (process-lifetime; schema doesn't change during a run)
# --------------------------------------------------------------------------- #
_target_table_cache: Table | None = None
_full_schema_cache: Schema | None = None
_table_cache: dict[str, Table] = {}  # keyed by "schema.table"


def _row_to_column(row: dict) -> Column:
    """Turn one information_schema row into a Column dataclass."""
    return Column(
        name=row["column_name"],
        data_type=row["data_type"],
        is_nullable=str(row["is_nullable"]).upper() == "YES",
        character_maximum_length=row.get("character_maximum_length"),
        numeric_precision=row.get("numeric_precision"),
        numeric_scale=row.get("numeric_scale"),
        column_default=row.get("column_default"),
    )


# --------------------------------------------------------------------------- #
# Public loaders
# --------------------------------------------------------------------------- #


async def load_table_schema(
    schema_name: str,
    table_name: str,
    force_refresh: bool = False,
) -> Table:
    """Introspect any table — not limited to the configured target table.

    Results are cached per (schema, table) for the process lifetime.
    Raises ``DatabaseError`` if the table is not visible to the current role.
    """
    cache_key = f"{schema_name}.{table_name}"
    if cache_key in _table_cache and not force_refresh:
        return _table_cache[cache_key]

    _logger.info("schema.load_table.start", schema=schema_name, table=table_name)

    rows = await fetch_all(
        _TARGET_TABLE_QUERY,
        {"schema": schema_name, "table": table_name},
    )

    if not rows:
        raise DatabaseError(
            f"Table {schema_name}.{table_name} has no columns visible to the "
            "current role, or does not exist."
        )

    table = Table(
        schema=schema_name,
        name=table_name,
        columns=[_row_to_column(r) for r in rows],
    )
    _table_cache[cache_key] = table
    _logger.info(
        "schema.load_table.done",
        schema=schema_name,
        table=table_name,
        column_count=len(table.columns),
    )
    return table


async def load_target_table(force_refresh: bool = False) -> Table:
    """Introspect the single target table configured in settings.

    Returns a ``Table`` with its column list populated. Cached for the
    lifetime of the process — information_schema.columns is cheap but not
    *that* cheap and the planner calls this on every run.

    Raises ``DatabaseError`` if the table isn't visible to the current role.
    """
    global _target_table_cache
    if _target_table_cache is not None and not force_refresh:
        return _target_table_cache

    settings = get_settings().agent
    table = await load_table_schema(
        settings.target_table_schema,
        settings.target_table_name,
        force_refresh=force_refresh,
    )
    _target_table_cache = table
    return table


async def load_target_table_schema(force_refresh: bool = False) -> Schema:
    """Convenience wrapper: returns the target table wrapped in a Schema."""
    table = await load_target_table(force_refresh=force_refresh)
    return Schema(tables=[table])


async def load_schema(force_refresh: bool = False) -> Schema:
    """Legacy full-schema loader (back-compat).

    Kept so that any old call site that still wants the whole DB_SCHEMA
    doesn't crash after this refactor. New code should call
    ``load_target_table_schema()`` instead.
    """
    global _full_schema_cache
    if _full_schema_cache is not None and not force_refresh:
        return _full_schema_cache

    schema_name = get_settings().postgres.schema_name
    _logger.info("schema.load_full.start", schema=schema_name)

    rows = await fetch_all(_FULL_SCHEMA_QUERY, {"schema": schema_name})

    tables: dict[str, Table] = {}
    for row in rows:
        key = f'{row["table_schema"]}.{row["table_name"]}'
        if key not in tables:
            tables[key] = Table(schema=row["table_schema"], name=row["table_name"])
        tables[key].columns.append(_row_to_column(row))

    schema = Schema(tables=list(tables.values()))
    _full_schema_cache = schema
    _logger.info("schema.load_full.done", table_count=len(schema.tables))
    return schema
