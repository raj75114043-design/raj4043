"""Risk Assessment utilities for likelihood × impact → risk_rating calculation.

This module defines the logic for calculating overall risk rating from
likelihood and impact dimensions. The mapping is kept here for easy
modification without changing the core agent code.
"""

from __future__ import annotations

from risk_agent.models.domain import RiskImpact, RiskLikelihood, RiskRating

# ============================================================================ #
# Risk Rating Matrix
# ============================================================================ #
# Maps (likelihood, impact) tuple to risk_rating
#
# Rationale:
#   - Unlikely events with low impact → Low risk (minimal concern)
#   - Likely events with high impact → Critical (must act immediately)
#   - Medium combinations → Medium/High (depends on which dimension dominates)
#
# Matrix visualization:
# ┌──────────┬──────────┬─────────┬─────────┐
# │          │ Low      │ Medium  │ High    │
# ├──────────┼──────────┼─────────┼─────────┤
# │ Unlikely │ Low      │ Low     │ Medium  │
# │ MayHapp. │ Low      │ Medium  │ High    │
# │ Likely   │ Medium   │ High    │ Critical│
# └──────────┴──────────┴─────────┴─────────┘

RISK_RATING_MATRIX: dict[tuple[RiskLikelihood, RiskImpact], RiskRating] = {
    # Unlikely likelihood
    (RiskLikelihood.UNLIKELY, RiskImpact.LOW): RiskRating.LOW,
    (RiskLikelihood.UNLIKELY, RiskImpact.MEDIUM): RiskRating.LOW,
    (RiskLikelihood.UNLIKELY, RiskImpact.HIGH): RiskRating.MEDIUM,
    # May Happen likelihood
    (RiskLikelihood.MAY_HAPPEN, RiskImpact.LOW): RiskRating.LOW,
    (RiskLikelihood.MAY_HAPPEN, RiskImpact.MEDIUM): RiskRating.MEDIUM,
    (RiskLikelihood.MAY_HAPPEN, RiskImpact.HIGH): RiskRating.HIGH,
    # Likely likelihood
    (RiskLikelihood.LIKELY, RiskImpact.LOW): RiskRating.MEDIUM,
    (RiskLikelihood.LIKELY, RiskImpact.MEDIUM): RiskRating.HIGH,
    (RiskLikelihood.LIKELY, RiskImpact.HIGH): RiskRating.CRITICAL,
}


def calculate_risk_rating(
    likelihood: RiskLikelihood | str, impact: RiskImpact | str
) -> RiskRating:
    """Calculate overall risk rating from likelihood and impact.

    Args:
        likelihood: RiskLikelihood enum or string value
        impact: RiskImpact enum or string value

    Returns:
        RiskRating enum value based on the matrix

    Raises:
        ValueError: If likelihood or impact values are invalid
    """
    # Coerce strings to enums if needed
    if isinstance(likelihood, str):
        try:
            likelihood = RiskLikelihood(likelihood.lower())
        except ValueError:
            raise ValueError(
                f"Invalid likelihood: {likelihood}. "
                f"Must be one of: {', '.join(e.value for e in RiskLikelihood)}"
            ) from None

    if isinstance(impact, str):
        try:
            impact = RiskImpact(impact.lower())
        except ValueError:
            raise ValueError(
                f"Invalid impact: {impact}. "
                f"Must be one of: {', '.join(e.value for e in RiskImpact)}"
            ) from None

    # Look up in matrix
    rating = RISK_RATING_MATRIX.get((likelihood, impact))
    if rating is None:
        # Fallback to Medium if somehow missing (shouldn't happen if matrix is complete)
        return RiskRating.MEDIUM

    return rating
