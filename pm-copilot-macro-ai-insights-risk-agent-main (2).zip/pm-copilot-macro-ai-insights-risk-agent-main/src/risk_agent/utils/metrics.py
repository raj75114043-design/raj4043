"""Prometheus metrics for the Risk Agent."""

from __future__ import annotations

from prometheus_client import Counter, Gauge, Histogram

# --------- Counters ---------
categories_processed_total = Counter(
    "risk_agent_categories_processed_total",
    "Total number of risk categories processed.",
    ["status"],  # success | failed
)

steps_executed_total = Counter(
    "risk_agent_steps_executed_total",
    "Total number of traversal steps executed.",
    ["source", "status"],  # source: semantic_kpi|excel_rule, status: success|failed|timeout
)

findings_total = Counter(
    "risk_agent_findings_total",
    "Total number of risk findings produced.",
    ["category_id", "severity"],
)

llm_calls_total = Counter(
    "risk_agent_llm_calls_total",
    "Total LLM calls made.",
    ["agent", "status"],  # agent: planner|generator, status: success|failed
)

# --------- Histograms ---------
category_duration_seconds = Histogram(
    "risk_agent_category_duration_seconds",
    "End-to-end processing time per risk category.",
    buckets=(0.5, 1, 2, 5, 10, 30, 60, 120, 300),
)

step_duration_seconds = Histogram(
    "risk_agent_step_duration_seconds",
    "Execution time of a single traversal step.",
    buckets=(0.1, 0.5, 1, 2, 5, 10, 30, 60),
)

llm_duration_seconds = Histogram(
    "risk_agent_llm_duration_seconds",
    "LLM call latency.",
    ["agent"],
    buckets=(0.5, 1, 2, 5, 10, 20, 30, 60),
)

# --------- Gauges ---------
steps_in_flight = Gauge(
    "risk_agent_steps_in_flight",
    "Number of traversal steps currently executing.",
)
