"""SQL safety utilities.

The planner generates SQL via an LLM, so every query runs through
a safety pass before execution. The rules are intentionally conservative:
- only SELECT/WITH statements are allowed
- DDL / DML keywords are blocked
- multiple statements are rejected
- a statement-level timeout is set per execution
"""

from __future__ import annotations

import re

from risk_agent.utils.exceptions import UnsafeSQLError

# Forbidden top-level statement keywords. Checked against the *stripped*
# SQL (comments + string literals removed) so harmless tokens inside a
# comment like "/* comment */ SELECT 1" don't trigger a false positive.
_FORBIDDEN = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|TRUNCATE|GRANT|REVOKE|"
    r"COPY|MERGE|VACUUM|CLUSTER|REINDEX|SECURITY)\b",
    re.IGNORECASE,
)

# Multiple statements: a semicolon followed by more non-whitespace content
# (again, checked against stripped SQL so ';' inside a string doesn't trigger).
_MULTI_STMT = re.compile(r";\s*\S")

# Must START with SELECT or WITH (after any leading whitespace/comments).
_ALLOWED_START = re.compile(
    r"^\s*(?:/\*.*?\*/\s*|--[^\n]*\n\s*)*(SELECT|WITH)\b",
    re.IGNORECASE | re.DOTALL,
)

_BLOCK_COMMENT = re.compile(r"/\*.*?\*/", re.DOTALL)
_LINE_COMMENT = re.compile(r"--[^\n]*")
_STRING_LITERAL = re.compile(r"'(?:''|[^'])*'")

_MAX_SQL_LEN = 20_000


def _strip_comments_and_strings(sql: str) -> str:
    """Remove block comments, line comments, and string literals for safe scanning."""
    s = _BLOCK_COMMENT.sub(" ", sql)
    s = _LINE_COMMENT.sub(" ", s)
    s = _STRING_LITERAL.sub("''", s)
    return s


def validate_sql(sql: str) -> str:
    """Validate an LLM-generated SQL query is read-only and well-formed.

    Returns the normalized SQL string on success, or raises UnsafeSQLError.
    """
    if not sql or not sql.strip():
        raise UnsafeSQLError("Empty SQL query.")

    normalized = sql.strip().rstrip(";")

    if len(normalized) > _MAX_SQL_LEN:
        raise UnsafeSQLError(f"SQL exceeds maximum length of {_MAX_SQL_LEN} characters.")

    if not _ALLOWED_START.match(normalized):
        raise UnsafeSQLError("Only SELECT / WITH queries are permitted.")

    stripped = _strip_comments_and_strings(normalized)

    if _FORBIDDEN.search(stripped):
        raise UnsafeSQLError("SQL contains forbidden keyword (DDL/DML not allowed).")

    if _MULTI_STMT.search(stripped):
        raise UnsafeSQLError("Multiple statements are not allowed.")

    return normalized


def enforce_row_limit(sql: str, max_rows: int) -> str:
    """Wrap the user SQL so Postgres never returns more than ``max_rows``.

    We wrap instead of patching the original query because the original may
    already contain LIMIT clauses, CTEs, or complex expressions.
    """
    safe = validate_sql(sql)
    return f"SELECT * FROM ({safe}) AS _risk_agent_wrapped LIMIT {int(max_rows)}"
