"""Structured logging setup.

Three output modes:
  - ``json``    — machine-parseable single-line JSON (good for prod/ELK).
  - ``console`` — structlog's built-in dev console renderer (pastel).
  - ``color``   — our own ANSI-colored renderer with per-level badges,
                  optimized for fast visual scanning during local runs.
  - ``text``    — plain key=value, no colors (good for redirected files).

The "color" mode is the default because local runs are the common case
and spotting a red ERROR line in a scrolling log matters a lot more
than having a structured JSON blob that no one reads by eye.
"""

from __future__ import annotations

import logging
import sys
from datetime import datetime, timezone
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Any

import structlog
from structlog.types import EventDict, Processor

from risk_agent.config import get_settings


# --------------------------------------------------------------------------- #
# ANSI colors
# --------------------------------------------------------------------------- #
class _Ansi:
    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"

    # Foregrounds
    GREY = "\033[90m"
    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"

    # Bright foregrounds
    BRIGHT_RED = "\033[91m"
    BRIGHT_GREEN = "\033[92m"
    BRIGHT_YELLOW = "\033[93m"
    BRIGHT_CYAN = "\033[96m"

    # Backgrounds (used only for CRITICAL)
    BG_RED = "\033[41m"


# Per-level color profile. Each tuple is (level_color, padded_label).
# Padding keeps columns aligned across lines.
_LEVEL_STYLE: dict[str, tuple[str, str]] = {
    "debug":    (_Ansi.CYAN,                                 "DEBUG"),
    "info":     (_Ansi.BRIGHT_GREEN,                         "INFO "),
    "warning":  (_Ansi.BRIGHT_YELLOW,                        "WARN "),
    "warn":     (_Ansi.BRIGHT_YELLOW,                        "WARN "),
    "error":    (_Ansi.BRIGHT_RED,                           "ERROR"),
    "critical": (_Ansi.BOLD + _Ansi.BG_RED + _Ansi.WHITE,    "CRIT "),
    "notset":   (_Ansi.GREY,                                 "     "),
}


def _colors_enabled() -> bool:
    """Disable colors when output is not a real TTY (CI, file redirect, etc.)."""
    try:
        return sys.stdout.isatty()
    except Exception:
        return False


class ColoredConsoleRenderer:
    """structlog renderer with per-level colored badges and key=value kv pairs.

    Layout:
        HH:MM:SS.mmm │ [LEVEL] │ logger.name │ event_name key=value ...
    """

    def __init__(self, use_colors: bool | None = None) -> None:
        self._use_colors = _colors_enabled() if use_colors is None else use_colors

    def _c(self, s: str, color: str) -> str:
        if not self._use_colors:
            return s
        return f"{color}{s}{_Ansi.RESET}"

    def _level_badge(self, level: str) -> str:
        color, label = _LEVEL_STYLE.get(level.lower(), _LEVEL_STYLE["notset"])
        badge = f"[{label}]"
        return self._c(badge, color) if self._use_colors else badge

    def _format_value(self, value: Any) -> str:
        if isinstance(value, str):
            if len(value) > 300:
                value = value[:297] + "..."
            if " " in value or "=" in value:
                return f'"{value}"'
            return value
        return repr(value)

    def __call__(
        self, logger: Any, method_name: str, event_dict: EventDict
    ) -> str:
        level = str(event_dict.pop("level", method_name) or method_name)
        timestamp = event_dict.pop("timestamp", "")
        logger_name = (
            event_dict.pop("logger", "") or event_dict.pop("logger_name", "")
        )
        event = event_dict.pop("event", "")

        # Trim ISO timestamp to HH:MM:SS.mmm for readability.
        if isinstance(timestamp, str) and "T" in timestamp:
            try:
                ts_core = timestamp.split("T", 1)[1]
                for suffix in ("Z", "+00:00"):
                    if ts_core.endswith(suffix):
                        ts_core = ts_core[: -len(suffix)]
                        break
                if "." in ts_core:
                    head, frac = ts_core.split(".", 1)
                    ts_core = f"{head}.{frac[:3]}"
                timestamp = ts_core
            except Exception:
                pass

        exc_info = event_dict.pop("exception", None)
        stack_info = event_dict.pop("stack", None)

        kv_parts: list[str] = []
        for key in sorted(event_dict.keys()):
            kv_parts.append(
                f"{self._c(key, _Ansi.DIM)}={self._format_value(event_dict[key])}"
            )

        parts: list[str] = []
        if timestamp:
            parts.append(self._c(str(timestamp), _Ansi.GREY))
        parts.append(self._level_badge(level))
        if logger_name:
            parts.append(self._c(str(logger_name), _Ansi.BLUE))
        if event:
            parts.append(self._c(str(event), _Ansi.BOLD))
        if kv_parts:
            parts.append(" ".join(kv_parts))

        line = " │ ".join(parts) if self._use_colors else " | ".join(parts)

        if stack_info:
            line += "\n" + self._c(str(stack_info), _Ansi.DIM)
        if exc_info:
            line += "\n" + self._c(str(exc_info), _Ansi.RED)

        return line


# --------------------------------------------------------------------------- #
# Public API
# --------------------------------------------------------------------------- #


def _dated_log_path(base: Path) -> Path:
    """Insert today's date (UTC) into the log filename stem.

    ``logs/risk_agent.log`` → ``logs/risk_agent_2026-04-28.log``
    """
    date_str = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d")
    return base.parent / f"{base.stem}_{date_str}{base.suffix}"


def configure_logging() -> None:
    """Configure structlog + stdlib logging based on settings."""
    settings = get_settings().observability

    timestamper = structlog.processors.TimeStamper(fmt="iso", utc=True)

    shared_processors: list[Processor] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        timestamper,
    ]

    renderer: Processor
    if settings.log_format == "json":
        renderer = structlog.processors.JSONRenderer()
    elif settings.log_format == "console":
        renderer = structlog.dev.ConsoleRenderer(colors=True)
    elif settings.log_format == "color":
        renderer = ColoredConsoleRenderer()
    else:  # "text"
        renderer = structlog.dev.ConsoleRenderer(colors=False)

    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    def _make_formatter(proc: Processor) -> structlog.stdlib.ProcessorFormatter:
        return structlog.stdlib.ProcessorFormatter(
            foreign_pre_chain=shared_processors,
            processors=[
                structlog.stdlib.ProcessorFormatter.remove_processors_meta,
                proc,
            ],
        )

    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(_make_formatter(renderer))

    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(console_handler)
    root.setLevel(settings.log_level)

    if settings.log_file:
        log_path = _dated_log_path(settings.log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        file_handler = RotatingFileHandler(
            log_path,
            maxBytes=10 * 1024 * 1024,  # 10 MB per file
            backupCount=5,
            encoding="utf-8",
        )
        file_handler.setFormatter(
            _make_formatter(structlog.dev.ConsoleRenderer(colors=False))
        )
        root.addHandler(file_handler)

    # Tone down noisy 3rd-party loggers.
    for noisy in ("httpx", "httpcore", "openai", "urllib3"):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def get_logger(
    name: str | None = None, **initial_values: Any
) -> structlog.stdlib.BoundLogger:
    """Return a bound structlog logger. Prefer module name for ``name``."""
    logger = structlog.get_logger(name)
    if initial_values:
        logger = logger.bind(**initial_values)
    return logger
