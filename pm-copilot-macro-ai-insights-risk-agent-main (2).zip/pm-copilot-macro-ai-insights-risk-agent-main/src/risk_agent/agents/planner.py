"""Planner Agent.

Responsibilities:
  1. Semantic context retrieval — call the semantic API with the risk
     category description to pull relevant KPIs / RCA patterns / SQL
     fragments.
  2. Target-table schema introspection — load the column metadata for
     the single configured target table so the LLM can ground its SQL.
  3. Step planning — prompt Azure OpenAI to emit a list of independent
     SELECT queries, one per investigation angle.
  4. Concurrent execution — run every planned step against Postgres
     concurrently, bounded by ``MAX_PARALLEL_STEPS``, with per-step
     timeouts and full fault-isolation.

Why asyncio (not ThreadPoolExecutor):
  Each step is an I/O-bound Postgres call over asyncpg. asyncio handles
  high fan-out cheaply (single thread, cooperative scheduling) — a
  ThreadPoolExecutor would add thread overhead without parallelism gain
  because asyncpg is already non-blocking. A Semaphore caps simultaneous
  in-flight queries at MAX_PARALLEL_STEPS so we don't exhaust the pool.
"""

from __future__ import annotations

import asyncio
import time
from datetime import UTC, datetime
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage

from risk_agent.config import get_settings
from risk_agent.core.json_parsing import parse_llm_json
from risk_agent.core.llm import build_llm
from risk_agent.db import fetch_all, load_target_table_schema
from risk_agent.models import (
    AgentState,
    RiskCategory,
    SemanticResponse,
    StepResult,
    StepSource,
    StepStatus,
    TraversalStep,
)
from risk_agent.prompts import (
    PLANNER_SYSTEM_PROMPT,
    PLANNER_USER_PROMPT,
    PLANNER_RETRY_SYSTEM_PROMPT,
    PLANNER_RETRY_USER_PROMPT,
)
from risk_agent.prompts.planner import (
    build_nl_query,
    build_region_agg_query,
    get_total_active_sql,
)
from risk_agent.kpi_analysis.business_context import PROJECT_BUSINESS_CONTEXTS
from risk_agent.agents.nl_sql_client import (
    call_nl_sql_api,
    clean_sql_with_llm,
    build_retry_query,
    preprocess_condition_with_llm,
    NLSQLResult,
)
from risk_agent.semantic import SemanticClient
from risk_agent.utils.exceptions import DatabaseError, LLMError
from risk_agent.utils.logging import get_logger
from risk_agent.utils.metrics import (
    llm_calls_total,
    llm_duration_seconds,
    step_duration_seconds,
    steps_executed_total,
    steps_in_flight,
)
from risk_agent.utils.sql_safety import enforce_row_limit, validate_sql

_logger = get_logger(__name__)


def _detect_project(category_id: str) -> str | None:
    uid = category_id.upper()
    if "AHLOA" in uid:
        return "AHLOA"
    if "TMO" in uid:
        return "NTM"
    if "NAS" in uid:
        return "NAS"
    return None


_SMP_NAME_FOR_PROJECT: dict[str, str] = {
    "NTM": "NTM",
    "AHLOA": "AHLOB Modernization",
}


def _mandatory_filter_hint(project: str | None) -> str:
    smp = _SMP_NAME_FOR_PROJECT.get(project or "")
    if not smp:
        return "(none — no mandatory filter for this project)"
    return (
        f"Every SQL query MUST include AND smp_name = '{smp}' in its WHERE clause "
        f"to scope results to this program only. Never omit this filter."
    )


# --------------------------------------------------------------------------- #
# Node 1: Semantic context retrieval
# --------------------------------------------------------------------------- #



async def _safe_search(
    client: SemanticClient,
    query: str,
    table: str,
    category_id: str,
) -> SemanticResponse:
    """Run one semantic search with per-table failure isolation.

    A failure on one table must NOT kill the others — return an empty
    SemanticResponse so the planner can still consume hits from the
    remaining sources (graceful degradation, per-table).
    """
    try:
        response = await client.search(query, table=table)
        _logger.info(
            "planner.semantic_retrieval.table.done",
            category_id=category_id,
            table=table,
            hits=response.total_results,
        )
        return response
    except Exception as exc:
        _logger.error(
            "planner.semantic_retrieval.table.failed",
            category_id=category_id,
            table=table,
            error=str(exc),
            error_type=type(exc).__name__,
            hint=f"Continuing without {table} context.",
        )
        return SemanticResponse(query=query, total_results=0, results=[])


async def _safe_keywords_search(
    client: SemanticClient,
    query: str,
    category_id: str,
) -> SemanticResponse:
    """Run the dedicated keywords search endpoint with failure isolation."""
    try:
        response = await client.search_keywords(query)
        _logger.info(
            "planner.semantic_retrieval.table.done",
            category_id=category_id,
            table="keywords",
            hits=response.total_results,
        )
        return response
    except Exception as exc:
        _logger.error(
            "planner.semantic_retrieval.table.failed",
            category_id=category_id,
            table="keywords",
            error=str(exc),
            error_type=type(exc).__name__,
            hint="Continuing without keywords context.",
        )
        return SemanticResponse(query=query, total_results=0, results=[])


async def semantic_retrieval_node(state: AgentState) -> dict[str, Any]:
    """LangGraph node: fan out semantic searches across KPI / keywords / question_bank.

    All three sources are queried concurrently with the same NL query. Any
    single table's failure degrades that slot to an empty response without
    blocking the others (per-table fault isolation).
    """
    category: RiskCategory = state["category"]
    query = f"{category.name}. {category.description}"

    _logger.info(
        "planner.semantic_retrieval.start",
        category_id=category.category_id,
        query=query,
        tables=["kpi", "keywords", "question_bank"],
    )

    try:
        async with SemanticClient() as client:
            health = await client.health_check()
            if not health.get("ok"):
                _logger.warning(
                    "planner.semantic_retrieval.health_check_failed",
                    category_id=category.category_id,
                    error=health.get("error"),
                )

            kpi_resp, keywords_resp, question_bank_resp = await asyncio.gather(
                _safe_search(client, query, "kpi", category.category_id),
                _safe_keywords_search(client, query, category.category_id),
                _safe_search(client, query, "question_bank", category.category_id),
            )

        _logger.info(
            "planner.semantic_retrieval.done",
            category_id=category.category_id,
            kpi_hits=kpi_resp.total_results,
            keywords_hits=keywords_resp.total_results,
            question_bank_hits=question_bank_resp.total_results,
        )
        project = _detect_project(category.category_id)
        business_context = PROJECT_BUSINESS_CONTEXTS.get(project) if project else None
        _logger.info(
            "planner.project_detected",
            category_id=category.category_id,
            project=project,
            has_business_context=business_context is not None,
        )
        return {
            "semantic_response": kpi_resp,
            "keywords_response": keywords_resp,
            "question_bank_response": question_bank_resp,
            "project": project,
            "business_context": business_context,
        }

    except Exception as exc:
        # Reaching here means the client itself couldn't even be created
        # (e.g. settings missing) — degrade everything to empty.
        _logger.error(
            "planner.semantic_retrieval.failed",
            category_id=category.category_id,
            error=str(exc),
            error_type=type(exc).__name__,
            hint="Continuing without semantic context. Check endpoint configuration.",
        )
        project = _detect_project(category.category_id)
        business_context = PROJECT_BUSINESS_CONTEXTS.get(project) if project else None
        empty = SemanticResponse(query=query, total_results=0, results=[])
        return {
            "semantic_response": empty,
            "keywords_response": empty,
            "question_bank_response": empty,
            "project": project,
            "business_context": business_context,
        }


# --------------------------------------------------------------------------- #
# Prompt helpers
# --------------------------------------------------------------------------- #


def _format_semantic_context(response: SemanticResponse | None) -> str:
    """Render KPI-table hits: KPI label, RCA question, recommendation area, SQL fragments."""
    if response is None or not response.results:
        return "(no semantic hits above threshold)"

    lines: list[str] = []
    for hit in response.results:
        c = hit.content
        lines.append(
            f"- id={hit.id} score={hit.similarity_score:.3f} "
            f"kpi={c.relevant_kpis or 'n/a'}"
        )
        if c.rca_question:
            lines.append(f"    question: {c.rca_question}")
        if c.recommendation_area:
            lines.append(f"    recommendation_area: {c.recommendation_area}")
        if c.steps_to_get_data_sql:
            lines.append("    steps_to_get_data_sql:")
            for step in c.steps_to_get_data_sql:
                lines.append(f"      * {step.strip()}")
    return "\n".join(lines)


def _content_field(content: Any, *names: str) -> Any:
    """Pull the first present, truthy attribute from a SemanticResultContent.

    The keywords / question_bank tables return fields not declared on
    SemanticResultContent — Pydantic's ``extra="allow"`` makes them
    accessible via attribute lookup. We probe a list of plausible names
    so the formatter is resilient to backend naming variation.
    """
    for n in names:
        v = getattr(content, n, None)
        if v:
            return v
    return None


def _format_keywords_context(response: SemanticResponse | None) -> str:
    """Render keywords-table hits: term + description + mapped tables/columns + synonyms + logic."""
    if response is None or not response.results:
        return "(no keyword matches above threshold)"

    lines: list[str] = []
    for hit in response.results:
        c = hit.content
        term = _content_field(c, "keyword", "term", "name") or "n/a"
        lines.append(
            f"- id={hit.id} score={hit.similarity_score:.3f} term={term}"
        )

        description = _content_field(c, "description", "definition")
        if description:
            lines.append(f"    description: {description}")

        mapped_tables = _content_field(c, "mapped_tables", "tables")
        if mapped_tables:
            if isinstance(mapped_tables, (list, tuple)):
                mapped_tables = ", ".join(str(t) for t in mapped_tables)
            lines.append(f"    mapped_tables: {mapped_tables}")

        mapped_columns = _content_field(c, "mapped_columns", "columns")
        if mapped_columns:
            if isinstance(mapped_columns, (list, tuple)):
                mapped_columns = ", ".join(str(col) for col in mapped_columns)
            lines.append(f"    mapped_columns: {mapped_columns}")

        synonyms = _content_field(c, "synonyms", "domain_synonyms", "aliases")
        if synonyms:
            if isinstance(synonyms, (list, tuple)):
                synonyms = ", ".join(str(s) for s in synonyms)
            lines.append(f"    synonyms: {synonyms}")

        logic = _content_field(c, "logic", "computation_logic", "rule")
        if logic:
            lines.append(f"    logic: {logic}")

    return "\n".join(lines)


def _format_question_bank_context(response: SemanticResponse | None) -> str:
    """Render question_bank-table hits: NL question + reference SQL."""
    if response is None or not response.results:
        return "(no question-bank matches above threshold)"

    lines: list[str] = []
    for hit in response.results:
        c = hit.content
        question = _content_field(
            c, "question", "natural_language_query", "nl_query", "rca_question"
        ) or "n/a"
        lines.append(
            f"- id={hit.id} score={hit.similarity_score:.3f} question={question}"
        )

        sql = _content_field(c, "sql", "sql_query", "sql_logic", "reference_sql")
        if sql:
            sql_text = sql if isinstance(sql, str) else "; ".join(str(s) for s in sql)
            lines.append(f"    sql: {sql_text.strip()}")

        # Fall back to the KPI-style SQL fragments the backend may also
        # emit on this table.
        if not sql and c.steps_to_get_data_sql:
            lines.append("    sql_steps:")
            for step in c.steps_to_get_data_sql:
                lines.append(f"      * {step.strip()}")

    return "\n".join(lines)


def _format_rules(rules: list[str]) -> str:
    if not rules:
        return "(none)"
    return "\n".join(f"- {r}" for r in rules)


# --------------------------------------------------------------------------- #
# Step planning (LLM call) - with retry
# --------------------------------------------------------------------------- #


def _format_rejected_steps_for_retry(
    rejected_steps: list[dict[str, Any]],
    rejection_reasons: list[str],
) -> str:
    """Format rejected steps with their error reasons for the retry prompt."""
    if not rejected_steps or not rejection_reasons:
        return "(no rejected steps)"
    
    lines: list[str] = []
    for idx, (step_data, error) in enumerate(zip(rejected_steps, rejection_reasons)):
        lines.append(f"Step {idx}:")
        lines.append(f"  Name: {step_data.get('name', 'N/A')}")
        lines.append(f"  Original SQL: {step_data.get('sql_query', 'N/A')}")
        lines.append(f"  Error: {error}")
        lines.append(f"  Source: {step_data.get('source', 'unknown')}")
        lines.append(f"  Rationale: {step_data.get('rationale', 'N/A')}")
        lines.append("")
    
    return "\n".join(lines)


async def _retry_rejected_steps(
    rejected_steps: list[dict[str, Any]],
    rejection_reasons: list[str],
    schema_info: tuple[Any, str],
    project: str | None = None,
) -> tuple[list[TraversalStep], list[str]]:
    """Retry planning for rejected steps with feedback about what went wrong.

    Args:
        rejected_steps: List of raw step dicts that failed validation
        rejection_reasons: List of error messages for each rejected step
        schema_info: Tuple of (schema_obj, target_fqn)
        project: Detected project key (e.g. "NTM", "AHLOA")

    Returns:
        (accepted_steps, remaining_errors)
    """
    schema, target_fqn = schema_info

    # Build the retry prompt with feedback
    rejected_text = _format_rejected_steps_for_retry(rejected_steps, rejection_reasons)
    retry_user_prompt = PLANNER_RETRY_USER_PROMPT.format(
        target_table_fqn=target_fqn,
        schema=schema.to_prompt(),
        mandatory_filter=_mandatory_filter_hint(project),
        rejected_steps_with_reasons=rejected_text,
    )
    
    llm = build_llm("planner")
    messages = [
        SystemMessage(content=PLANNER_RETRY_SYSTEM_PROMPT),
        HumanMessage(content=retry_user_prompt),
    ]
    
    _logger.info(
        "planner.retry.start",
        rejected_count=len(rejected_steps),
    )
    
    started = time.perf_counter()
    try:
        response = await llm.ainvoke(messages)
    except Exception as exc:
        _logger.error("planner.retry.llm.failed", error=str(exc))
        return [], [f"Retry LLM call failed: {exc}"]
    
    elapsed = time.perf_counter() - started
    llm_duration_seconds.labels(agent="planner").observe(elapsed)
    
    raw_content = (
        response.content if isinstance(response.content, str) else str(response.content)
    )
    
    try:
        parsed = parse_llm_json(raw_content)
    except Exception as exc:
        _logger.error("planner.retry.json.parse_failed", error=str(exc))
        return [], [f"Retry response JSON parsing failed: {exc}"]
    
    steps: list[TraversalStep] = []
    errors: list[str] = []
    
    for idx, raw_step in enumerate(parsed.get("steps", [])):
        try:
            source_str = str(raw_step.get("source", "excel_rule")).lower()
            source = (
                StepSource.SEMANTIC_KPI
                if source_str == "semantic_kpi"
                else StepSource.EXCEL_RULE
            )
            sql = validate_sql(str(raw_step["sql_query"]))
            steps.append(
                TraversalStep(
                    source=source,
                    name=str(raw_step.get("name", f"step_{idx}")),
                    rationale=str(raw_step.get("rationale", "")),
                    sql_query=sql,
                    expected_columns=list(raw_step.get("expected_columns", []) or []),
                    related_kpi=raw_step.get("related_kpi"),
                    source_reference=raw_step.get("source_reference"),
                )
            )
        except Exception as exc:
            msg = f"planner retry: rejected step {idx}: {exc}"
            _logger.warning("planner.retry.step_rejected", index=idx, error=str(exc))
            errors.append(msg)
    
    _logger.info(
        "planner.retry.done",
        retry_accepted=len(steps),
        retry_rejected=len(errors),
        duration_ms=round(elapsed * 1000, 2),
    )
    
    return steps, errors


async def _plan_steps(
    category: RiskCategory,
    semantic: SemanticResponse | None,
    keywords: SemanticResponse | None = None,
    question_bank: SemanticResponse | None = None,
    business_context: str | None = None,
    project: str | None = None,
    max_retries: int = 2,
) -> tuple[list[TraversalStep], list[str]]:
    """Prompt the LLM to produce a list of independent SQL steps.

    If steps are rejected due to validation errors, retry up to max_retries
    times, passing the rejection feedback to the LLM so it can fix the issues.

    Returns (accepted_steps, rejection_errors). The schema of the single
    target table is introspected fresh (cached) and rendered into the
    prompt so the LLM grounds its SQL correctly.

    The planner consumes three complementary semantic sources:
      - ``semantic`` — KPI-table hits (KPIs, RCA patterns, SQL fragments)
      - ``keywords`` — domain glossary (term → description, mapped columns,
        synonyms, logic)
      - ``question_bank`` — NL questions paired with reference SQL
    """
    # 1. Introspect the one target table — columns + data types.
    schema = await load_target_table_schema()
    if schema.is_empty:
        raise DatabaseError(
            "Target table schema is empty — cannot plan. Check "
            "TARGET_TABLE_SCHEMA / TARGET_TABLE_NAME in .env."
        )
    target_fqn = schema.tables[0].qualified_name
    schema_info = (schema, target_fqn)

    # 2. Build the initial prompt with all three semantic context blocks.
    user_prompt = PLANNER_USER_PROMPT.format(
        category_id=category.category_id,
        name=category.name,
        description=category.description,
        identification_logic=category.identification_logic,
        decision_rules=_format_rules(category.decision_rules),
        mandatory_filter=_mandatory_filter_hint(project),
        business_context=business_context or "(none — unknown project)",
        kpi_context=_format_semantic_context(semantic),
        keywords_context=_format_keywords_context(keywords),
        question_bank_context=_format_question_bank_context(question_bank),
        target_table_fqn=target_fqn,
        schema=schema.to_prompt(),
    )

    llm = build_llm("planner")
    messages = [
        SystemMessage(content=PLANNER_SYSTEM_PROMPT),
        HumanMessage(content=user_prompt),
    ]

    _logger.info(
        "planner.llm.start",
        category_id=category.category_id,
        target_table=target_fqn,
        schema_column_count=len(schema.tables[0].columns),
    )
    started = time.perf_counter()
    try:
        response = await llm.ainvoke(messages)
    except Exception as exc:
        llm_calls_total.labels(agent="planner", status="failed").inc()
        _logger.error("planner.llm.failed", error=str(exc))
        raise LLMError(f"Planner LLM call failed: {exc}") from exc

    elapsed = time.perf_counter() - started
    llm_duration_seconds.labels(agent="planner").observe(elapsed)
    llm_calls_total.labels(agent="planner", status="success").inc()

    raw_content = (
        response.content if isinstance(response.content, str) else str(response.content)
    )
    parsed = parse_llm_json(raw_content)

    steps: list[TraversalStep] = []
    errors: list[str] = []
    rejected_raw_steps: list[dict[str, Any]] = []
    rejection_reasons: list[str] = []

    for idx, raw_step in enumerate(parsed.get("steps", [])):
        try:
            source_str = str(raw_step.get("source", "excel_rule")).lower()
            source = (
                StepSource.SEMANTIC_KPI
                if source_str == "semantic_kpi"
                else StepSource.EXCEL_RULE
            )
            sql = validate_sql(str(raw_step["sql_query"]))
            steps.append(
                TraversalStep(
                    source=source,
                    name=str(raw_step.get("name", f"step_{idx}")),
                    rationale=str(raw_step.get("rationale", "")),
                    sql_query=sql,
                    expected_columns=list(raw_step.get("expected_columns", []) or []),
                    related_kpi=raw_step.get("related_kpi"),
                    source_reference=raw_step.get("source_reference"),
                )
            )
        except Exception as exc:
            error_msg = str(exc)
            _logger.warning("planner.step_rejected", index=idx, error=error_msg)
            errors.append(error_msg)
            rejected_raw_steps.append(raw_step)
            rejection_reasons.append(error_msg)

    _logger.info(
        "planner.llm.done",
        category_id=category.category_id,
        accepted=len(steps),
        rejected=len(errors),
        duration_ms=round(elapsed * 1000, 2),
    )

    # 3. Retry loop: if steps were rejected, ask the LLM to fix them (max 2 retries)
    retry_attempt = 0
    while rejected_raw_steps and retry_attempt < max_retries:
        retry_attempt += 1
        _logger.info(
            "planner.retry_attempt",
            attempt=retry_attempt,
            max_retries=max_retries,
            rejected_count=len(rejected_raw_steps),
        )
        
        # Call LLM again with feedback about rejections
        retry_steps, retry_errors = await _retry_rejected_steps(
            rejected_raw_steps, rejection_reasons, schema_info, project=project
        )
        
        # Merge newly accepted steps
        steps.extend(retry_steps)
        
        # Update rejections: keep only the ones that still failed
        if retry_errors:
            errors.extend(retry_errors)
            # For next iteration: we'd need to track which steps failed again
            # For now, we stop retrying if there are still errors
            _logger.info(
                "planner.retry_still_has_errors",
                attempt=retry_attempt,
                still_rejected=len(retry_errors),
            )
            break  # Exit retry loop if still getting errors
        else:
            # All retried steps passed validation
            rejected_raw_steps = []
            rejection_reasons = []

    _logger.info(
        "planner.planning.complete",
        category_id=category.category_id,
        total_accepted=len(steps),
        total_rejected=len(errors),
        retry_attempts=retry_attempt,
    )

    # Log the full plan so operators can audit what the planner decided.
    for i, step in enumerate(steps):
        _logger.info(
            "planner.plan.step",
            index=i,
            step_id=str(step.step_id),
            name=step.name,
            source=step.source.value,
            rationale=step.rationale,
            sql=step.sql_query,
            expected_columns=step.expected_columns,
            related_kpi=step.related_kpi,
        )

    return steps, errors


# --------------------------------------------------------------------------- #
# Concurrent SQL execution (asyncio.gather + Semaphore)
# --------------------------------------------------------------------------- #


async def _execute_single_step(
    step: TraversalStep,
    max_rows: int,
    timeout: float,
    semaphore: asyncio.Semaphore,
) -> StepResult:
    """Run one step against Postgres with timeout and fault isolation.

    The Semaphore caps how many steps run at the same moment so we never
    exceed the DB pool capacity. Errors inside one step never propagate
    out — they're captured as a StepResult with status FAILED/TIMEOUT.
    """
    started_at = datetime.now(UTC)

    # Outer LIMIT wrap — so a runaway query can never flood the generator.
    wrapped_sql = enforce_row_limit(step.sql_query, max_rows)

    async with semaphore:
        _logger.info(
            "executor.step.start",
            step_id=str(step.step_id),
            source=step.source.value,
            name=step.name,
        )
        steps_in_flight.inc()
        try:
            rows = await asyncio.wait_for(
                fetch_all(wrapped_sql, step.parameters, timeout=timeout),
                timeout=timeout,
            )
            status = StepStatus.SUCCESS
            error: str | None = None
        except TimeoutError:
            rows = []
            status = StepStatus.TIMEOUT
            error = f"Step timed out after {timeout}s"
            _logger.warning(
                "executor.step.timeout",
                step_id=str(step.step_id),
                name=step.name,
            )
        except DatabaseError as exc:
            rows = []
            status = StepStatus.FAILED
            error = str(exc)
            _logger.error(
                "executor.step.db_failed",
                step_id=str(step.step_id),
                error=str(exc),
            )
        except Exception as exc:
            rows = []
            status = StepStatus.FAILED
            error = f"Unexpected error: {exc}"
            _logger.exception(
                "executor.step.unexpected_error",
                step_id=str(step.step_id),
            )
        finally:
            steps_in_flight.dec()

    finished_at = datetime.now(UTC)
    duration_ms = (finished_at - started_at).total_seconds() * 1000

    steps_executed_total.labels(
        source=step.source.value, status=status.value
    ).inc()
    step_duration_seconds.observe(duration_ms / 1000.0)

    result = StepResult(
        step_id=step.step_id,
        step_name=step.name,
        source=step.source,
        status=status,
        rows=rows,
        row_count=len(rows),
        executed_sql=wrapped_sql,
        error=error,
        started_at=started_at,
        finished_at=finished_at,
        duration_ms=duration_ms,
        related_kpi=step.related_kpi,
    )

    _logger.info(
        "executor.step.done",
        step_id=str(step.step_id),
        status=status.value,
        row_count=result.row_count,
        duration_ms=round(duration_ms, 2),
    )
    return result


async def _execute_steps_concurrently(
    steps: list[TraversalStep],
) -> list[StepResult]:
    """Run every step concurrently, bounded by MAX_PARALLEL_STEPS.

    This is the asyncio equivalent of a ThreadPoolExecutor.map — except
    it's single-threaded, cooperative, and much lighter because asyncpg
    is already non-blocking. The Semaphore is the "pool size".
    """
    if not steps:
        return []

    settings = get_settings().agent
    semaphore = asyncio.Semaphore(settings.max_parallel_steps)

    _logger.info(
        "planner.execute.fanout",
        step_count=len(steps),
        max_parallel=settings.max_parallel_steps,
        per_step_timeout=settings.step_execution_timeout,
    )
    started = time.perf_counter()

    # return_exceptions=True shouldn't matter here because
    # _execute_single_step catches everything itself, but it's a belt-
    # and-braces guarantee that gather never raises.
    results = await asyncio.gather(
        *(
            _execute_single_step(
                step,
                max_rows=settings.max_rows_per_step,
                timeout=settings.step_execution_timeout,
                semaphore=semaphore,
            )
            for step in steps
        ),
        return_exceptions=False,
    )

    elapsed = time.perf_counter() - started
    succeeded = sum(1 for r in results if r.status == StepStatus.SUCCESS)
    _logger.info(
        "planner.execute.done",
        step_count=len(steps),
        succeeded=succeeded,
        failed=len(steps) - succeeded,
        total_duration_ms=round(elapsed * 1000, 2),
    )
    return list(results)


# --------------------------------------------------------------------------- #
# Node: plan_and_execute — combines planning + concurrent execution
# --------------------------------------------------------------------------- #




async def _call_api_and_clean(
    step_label: str,
    nl_query: str,
    max_retries: int = 2,
    dry_run: bool = True,
) -> tuple[str, str | None, NLSQLResult | None]:
    """Call NL→SQL API, LLM-clean, validate, optionally dry-run. Returns (label, sql|None, result|None)."""
    current_query = nl_query
    last_sql = ""
    for attempt in range(max_retries + 1):
        _logger.info("nl_sql.attempt", label=step_label, attempt=attempt)
        _logger.info("nl_sql.question", label=step_label, attempt=attempt, question=current_query)
        result = await call_nl_sql_api(current_query)

        if not result.success or not result.generated_sql:
            error = result.error or "API returned no SQL"
            _logger.warning("nl_sql.no_sql", label=step_label, attempt=attempt, error=error)
            current_query = build_retry_query(nl_query, last_sql, error)
            continue

        _logger.info("nl_sql.raw_response", label=step_label, attempt=attempt, raw_sql=result.generated_sql)

        # LLM-clean: remove LIMIT, semicolons, escape artifacts
        try:
            cleaned = await clean_sql_with_llm(result.generated_sql)
            last_sql = cleaned
        except Exception as exc:
            _logger.warning("nl_sql.clean_failed", label=step_label, attempt=attempt, error=str(exc))
            cleaned = result.generated_sql
            last_sql = cleaned

        _logger.info("nl_sql.cleaned_sql", label=step_label, attempt=attempt, cleaned_sql=cleaned)

        if dry_run:
            try:
                await fetch_all(f"SELECT * FROM ({cleaned}) _dryrun LIMIT 1", {})
                _logger.info("nl_sql.dryrun_ok", label=step_label)
            except Exception as exc:
                _logger.warning("nl_sql.dryrun_failed", label=step_label, attempt=attempt, error=str(exc))
                current_query = build_retry_query(nl_query, cleaned, str(exc))
                last_sql = cleaned
                continue

        _logger.info("nl_sql.success", label=step_label, sql_len=len(cleaned), final_sql=cleaned)
        return step_label, cleaned, result

    _logger.error("nl_sql.all_attempts_failed", label=step_label, attempts=max_retries + 1)
    return step_label, None, None


async def plan_steps_node(state: AgentState) -> dict[str, Any]:
    """LangGraph node: generate ONE site-level SQL query for all breaching sites.

    Forms a clear NL question from the category's identification_logic and
    decision_rules → sends to AI Assistant → LLM-cleans → validates → dry-runs.
    The resulting SQL is stored (not executed here) for use by analyze_site_node.
    """
    category: RiskCategory = state["category"]
    business_context: str | None = state.get("business_context")
    project: str | None = state.get("project")

    step_name = f"{category.name} — site level"

    condition_text = await preprocess_condition_with_llm(
        category.identification_logic,
        category.decision_rules or [],
        category.name,
        business_context=business_context,
    )
    nl_query = build_nl_query(category, project, condition_text=condition_text, business_context=business_context)

    _logger.info(
        "plan_steps.plan_ready",
        category_id=category.category_id,
        project=project,
        step_name=step_name,
        condition_text=condition_text,
        nl_question=nl_query,
    )

    _, clean_sql, nl_result = await _call_api_and_clean(step_name, nl_query, max_retries=2, dry_run=True)

    if not clean_sql:
        _logger.error("plan_steps.failed", category_id=category.category_id)
        return {"planned_steps": [], "errors": [f"plan_steps: all attempts failed for '{step_name}'"]}

    planned_steps = [TraversalStep(
        source=StepSource.SEMANTIC_KPI,
        name=step_name,
        rationale=f"Individual sites breaching '{category.name}' identification logic for {project or 'all'} project",
        sql_query=clean_sql,
        expected_columns=[],
        related_kpi=None,
        source_reference="nl_sql_api",
    )]

    _logger.info(
        "plan_steps.done",
        category_id=category.category_id,
        row_count="not executed (stored only)",
        sql=clean_sql,
    )

    return {
        "planned_steps": planned_steps,
        "nl_sql_keyword_names": list(nl_result.keyword_names) if nl_result else [],
        "nl_sql_kpi_names": list(nl_result.kpi_names) if nl_result else [],
        "errors": [],
    }


async def region_sql_plan_node(state: AgentState) -> dict[str, Any]:
    """LangGraph node: generate + execute two aggregation queries.

    Query A — at-risk counts: AI Assistant → COUNT(*) GROUP BY region/area/market → ~50 rows.
    Query B — total active counts: hardcoded SQL per project → ~50 rows.
    Site rows are NOT pre-fetched here; analyze_site_node fetches per flagged market.
    """
    category: RiskCategory = state["category"]
    project: str | None = state.get("project")

    business_context: str | None = state.get("business_context")

    condition_text = await preprocess_condition_with_llm(
        category.identification_logic,
        category.decision_rules or [],
        category.name,
        business_context=business_context,
    )

    agg_query = build_region_agg_query(category, project, condition_text=condition_text)
    total_sql = get_total_active_sql(project)
    agg_label = f"{category.name} — at-risk aggregated"

    _logger.info(
        "region_sql_plan.planning",
        category_id=category.category_id,
        project=project,
        agg_question=agg_query,
        total_sql=total_sql or "(none — unknown project)",
    )

    _, agg_sql, _ = await _call_api_and_clean(agg_label, agg_query, max_retries=2, dry_run=False)

    _logger.info(
        "region_sql_plan.agg_sql_generated",
        category_id=category.category_id,
        agg_sql=agg_sql or "(none)",
    )

    region_agg_results: list[dict] = []
    total_active_results: list[dict] = []
    errors: list[str] = []

    if agg_sql:
        try:
            region_agg_results = await fetch_all(agg_sql, {})
            _logger.info(
                "region_sql_plan.agg_executed",
                category_id=category.category_id,
                row_count=len(region_agg_results),
                sample=region_agg_results[:3] if region_agg_results else [],
            )
        except Exception as exc:
            _logger.warning("region_sql_plan.agg_exec_failed", error=str(exc))
            errors.append(f"region_sql_plan: at-risk aggregation failed: {exc}")
    else:
        errors.append("region_sql_plan: failed to generate at-risk aggregation SQL")

    if total_sql:
        try:
            total_active_results = await fetch_all(total_sql, {})
            _logger.info(
                "region_sql_plan.total_executed",
                category_id=category.category_id,
                row_count=len(total_active_results),
                sample=total_active_results[:3] if total_active_results else [],
            )
        except Exception as exc:
            _logger.warning("region_sql_plan.total_exec_failed", error=str(exc))
            errors.append(f"region_sql_plan: total active query failed: {exc}")
    else:
        _logger.warning(
            "region_sql_plan.no_total_sql",
            project=project,
            hint="no hardcoded total-active SQL for this project",
        )

    _logger.info(
        "region_sql_plan.done",
        category_id=category.category_id,
        agg_rows=len(region_agg_results),
        total_rows=len(total_active_results),
        errors=len(errors),
    )

    return {
        "region_agg_results": region_agg_results,
        "total_active_results": total_active_results,
        "errors": errors,
    }


async def execute_steps_node(state: AgentState) -> dict[str, Any]:
    """LangGraph node: execute validated planned steps concurrently.

    Reads validated_planned_steps (set by validate_plan_node), falls back
    to planned_steps when the validator hasn't run. Writes step_results + errors.
    """
    steps: list[TraversalStep] = list(
        state.get("validated_planned_steps") or state.get("planned_steps") or []
    )
    results = await _execute_steps_concurrently(steps)
    return {"step_results": results, "errors": []}


async def plan_and_execute_node(state: AgentState) -> dict[str, Any]:
    """Back-compat shim: plan SQL steps, then execute them all concurrently.

    Kept so existing callers (old graph wiring, tests) still work unchanged.
    New graphs should wire plan_steps_node → validate_plan_node →
    execute_steps_node instead.
    """
    category: RiskCategory = state["category"]
    semantic: SemanticResponse | None = state.get("semantic_response")
    keywords: SemanticResponse | None = state.get("keywords_response")
    question_bank: SemanticResponse | None = state.get("question_bank_response")
    business_context: str | None = state.get("business_context")
    project: str | None = state.get("project")

    steps, plan_errors = await _plan_steps(
        category,
        semantic,
        keywords=keywords,
        question_bank=question_bank,
        business_context=business_context,
        project=project,
    )

    results = await _execute_steps_concurrently(steps)

    return {
        "planned_steps": steps,
        "step_results": results,
        "errors": plan_errors,
    }


# --------------------------------------------------------------------------- #
# Back-compat: keep planning_node for any external caller that imports it.
# --------------------------------------------------------------------------- #


async def planning_node(state: AgentState) -> dict[str, Any]:
    """Back-compat shim — plans steps only, does not execute.

    The live graph uses ``plan_steps_node`` instead. This shim is
    kept so any existing tests / callers that import ``planning_node``
    still work.
    """
    category: RiskCategory = state["category"]
    semantic: SemanticResponse | None = state.get("semantic_response")
    keywords: SemanticResponse | None = state.get("keywords_response")
    question_bank: SemanticResponse | None = state.get("question_bank_response")
    business_context: str | None = state.get("business_context")
    project: str | None = state.get("project")
    steps, errors = await _plan_steps(
        category,
        semantic,
        keywords=keywords,
        question_bank=question_bank,
        business_context=business_context,
        project=project,
    )
    return {"planned_steps": steps, "errors": errors}
