"""Executor Agent.

A LangGraph node that runs a single TraversalStep against Postgres.
Multiple instances of this node run in parallel (one per planned step)
via the LangGraph ``Send`` API — see ``graph.py``.

Each execution is fault-isolated: an error in one step never blocks
the others, and each returns a StepResult carrying status + error text
so the risk identification agent can reason about partial evidence.
"""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from typing import Any

from risk_agent.config import get_settings
from risk_agent.db import fetch_all
from risk_agent.models import StepResult, StepStatus, TraversalStep
from risk_agent.utils.exceptions import DatabaseError
from risk_agent.utils.logging import get_logger
from risk_agent.utils.metrics import (
    step_duration_seconds,
    steps_executed_total,
    steps_in_flight,
)
from risk_agent.utils.sql_safety import enforce_row_limit

_logger = get_logger(__name__)


async def execute_step_node(payload: dict[str, Any]) -> dict[str, Any]:
    """LangGraph node invoked once per planned step (via ``Send``).

    The ``payload`` is the dict emitted by the fan-out edge; it contains the
    single ``step`` to execute. We return a dict that is merged back into
    ``AgentState`` — its ``step_results`` list is reduced with ``operator.add``.
    """
    step: TraversalStep = payload["step"]
    settings = get_settings().agent

    started_at = datetime.now(UTC)

    _logger.info(
        "executor.step.start",
        step_id=str(step.step_id),
        source=step.source.value,
        name=step.name,
    )

    # Wrap the query in an outer LIMIT so no step can flood the generator
    # with runaway result sets.
    wrapped_sql = enforce_row_limit(step.sql_query, settings.max_rows_per_step)

    steps_in_flight.inc()
    try:
        rows = await asyncio.wait_for(
            fetch_all(
                wrapped_sql,
                step.parameters,
                timeout=settings.step_execution_timeout,
            ),
            timeout=settings.step_execution_timeout,
        )
        status = StepStatus.SUCCESS
        error: str | None = None
    except TimeoutError:
        rows = []
        status = StepStatus.TIMEOUT
        error = f"Step timed out after {settings.step_execution_timeout}s"
        _logger.warning(
            "executor.step.timeout", step_id=str(step.step_id), name=step.name
        )
    except DatabaseError as exc:
        rows = []
        status = StepStatus.FAILED
        error = str(exc)
        _logger.error(
            "executor.step.db_failed",
            step_id=str(step.step_id),
            error=str(exc),
        )
    except Exception as exc:
        rows = []
        status = StepStatus.FAILED
        error = f"Unexpected error: {exc}"
        _logger.exception(
            "executor.step.unexpected_error",
            step_id=str(step.step_id),
        )
    finally:
        steps_in_flight.dec()

    finished_at = datetime.now(UTC)
    duration_ms = (finished_at - started_at).total_seconds() * 1000

    steps_executed_total.labels(
        source=step.source.value, status=status.value
    ).inc()
    step_duration_seconds.observe(duration_ms / 1000.0)

    result = StepResult(
        step_id=step.step_id,
        step_name=step.name,
        source=step.source,
        status=status,
        rows=rows,
        row_count=len(rows),
        executed_sql=wrapped_sql,
        error=error,
        started_at=started_at,
        finished_at=finished_at,
        duration_ms=duration_ms,
        related_kpi=step.related_kpi,
    )

    _logger.info(
        "executor.step.done",
        step_id=str(step.step_id),
        status=status.value,
        row_count=result.row_count,
        duration_ms=round(duration_ms, 2),
    )

    # The reducer in AgentState appends this list into step_results.
    return {"step_results": [result]}
