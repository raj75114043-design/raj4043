"""NL → SQL API client.

Calls the AI Assistant SQL generator endpoint, which accepts a natural-language
query and returns SQL via a Server-Sent Events (SSE) stream.

Static credentials:
    session_id : "42819"   (fixed — reused across all calls)
    username   : "risk agent"

SSE event sequence:
    search_keywords  → (ignored — API does its own semantic search)
    search_kpis      → (ignored)
    search_qb        → (ignored)
    search_complete  → (ignored)
    sql_start        → (ignored)
    keep-alive lines → skipped
    sql_complete     → parsed: generated_sql + parallel_search_output
    chat_end         → stop streaming
"""

from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass, field

import httpx
from langchain_core.messages import HumanMessage, SystemMessage

from risk_agent.config import get_settings
from risk_agent.core.llm import build_llm
from risk_agent.utils.logging import get_logger

_logger = get_logger(__name__)

_SESSION_ID = "42819"
_USERNAME = "risk agent"

# The AI Assistant SSE endpoint rejects concurrent requests from the same session —
# it returns chat_end immediately (no sql_complete) when a second request arrives
# while another is still streaming. Serialize all calls through this semaphore.
_API_SEMAPHORE = asyncio.Semaphore(1)


@dataclass
class NLSQLResult:
    generated_sql: str = ""
    keyword_names: list[str] = field(default_factory=list)
    kpi_names: list[str] = field(default_factory=list)
    success: bool = False
    error: str = ""


def _normalize_nl_sql(sql: str) -> str:
    """Strip trailing semicolon and whitespace so validate_sql() doesn't reject it."""
    sql = sql.strip()
    if sql.endswith(";"):
        sql = sql[:-1].rstrip()
    return sql


def _parse_sse_line(
    current_event: list[str],
    line: str,
    result_holder: list[NLSQLResult],
    received_events: list[str],
) -> bool:
    """Process one SSE line. Returns True when streaming should stop."""
    line = line.rstrip("\r")

    # Keep-alive or comment lines
    if line.startswith(":"):
        return False

    if line.startswith("event:"):
        current_event.clear()
        current_event.append(line[len("event:"):].strip())
        return False

    if line.startswith("data:"):
        event_name = current_event[0] if current_event else ""
        raw_data = line[len("data:"):].strip()
        if event_name:
            received_events.append(event_name)

        if event_name == "search_keywords":
            try:
                payload = json.loads(raw_data)
                _logger.info(
                    "nl_sql_client.sse.search_keywords",
                    found=payload.get("found"),
                    keyword_names=payload.get("keyword_names", []),
                    total=len(payload.get("keyword_names", [])),
                )
            except Exception:
                pass

        elif event_name == "search_kpis":
            try:
                payload = json.loads(raw_data)
                _logger.info(
                    "nl_sql_client.sse.search_kpis",
                    found=payload.get("found"),
                    kpi_names=payload.get("kpi_names", []),
                    total=len(payload.get("kpi_names", [])),
                )
            except Exception:
                pass

        elif event_name == "search_qb":
            try:
                payload = json.loads(raw_data)
                _logger.info(
                    "nl_sql_client.sse.search_qb",
                    found=payload.get("found"),
                    qb_names=payload.get("qb_names", []),
                    total=len(payload.get("qb_names", [])),
                )
            except Exception:
                pass

        elif event_name == "search_complete":
            try:
                payload = json.loads(raw_data)
                _logger.info(
                    "nl_sql_client.sse.search_complete",
                    status=payload.get("status"),
                    total_keywords=payload.get("total_keywords"),
                    total_kpis=payload.get("total_kpis"),
                    total_qb=payload.get("total_qb"),
                )
            except Exception:
                pass

        elif event_name == "sql_start":
            try:
                payload = json.loads(raw_data)
                _logger.info("nl_sql_client.sse.sql_start", message=payload.get("message"))
            except Exception:
                pass

        elif event_name == "sql_complete":
            try:
                payload = json.loads(raw_data)
                sql = payload.get("generated_sql", "")
                table_json = payload.get("table_json") or []
                pso = payload.get("parallel_search_output", {})
                node_timestamps = payload.get("node_timestamps", {})
                result_holder.append(NLSQLResult(
                    generated_sql=_normalize_nl_sql(sql) if sql else "",
                    keyword_names=list(pso.get("keyword_names", [])),
                    kpi_names=list(pso.get("kpi_names", [])),
                    success=bool(payload.get("success", False)) and bool(sql),
                    error=payload.get("error", "") or "",
                ))
                _logger.info(
                    "nl_sql_client.sse.sql_complete",
                    success=result_holder[-1].success,
                    generated_sql=sql,
                    table_row_count=len(table_json),
                    keywords=len(result_holder[-1].keyword_names),
                    kpis=len(result_holder[-1].kpi_names),
                    retries=payload.get("retries"),
                    node_timestamps=node_timestamps,
                    api_error=result_holder[-1].error or None,
                )
            except Exception as exc:
                _logger.warning("nl_sql_client.parse_failed", error=str(exc))

        elif event_name == "chat_end":
            sql_seen = any(e == "sql_complete" for e in received_events)
            _logger.info(
                "nl_sql_client.sse.chat_end",
                sql_complete_received=sql_seen,
                events_received=received_events[:],
            )
            return True  # stop streaming

    return False


async def call_nl_sql_api(user_query: str) -> NLSQLResult:
    """POST to the AI Assistant SSE endpoint and return the generated SQL.

    The session_id and username are static constants for the risk agent.
    Streams SSE events until sql_complete + chat_end are received or timeout.
    """
    settings = get_settings().agent
    url = settings.nl_sql_api_url
    timeout = settings.nl_sql_api_timeout

    payload = {
        "session_id": _SESSION_ID,
        "username": _USERNAME,
        "user_query": user_query,
    }

    _logger.info(
        "nl_sql_client.request",
        url=url,
        session_id=_SESSION_ID,
        user_query=user_query,
    )

    result_holder: list[NLSQLResult] = []
    current_event: list[str] = []
    received_events: list[str] = []

    async with _API_SEMAPHORE:
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(timeout)) as client:
                async with client.stream("POST", url, json=payload) as response:
                    response.raise_for_status()
                    async for line in response.aiter_lines():
                        stop = _parse_sse_line(current_event, line, result_holder, received_events)
                        if stop:
                            break
        except httpx.TimeoutException as exc:
            msg = f"NL SQL API timed out after {timeout}s: {exc}"
            _logger.warning("nl_sql_client.timeout", timeout=timeout, error=str(exc))
            return NLSQLResult(success=False, error=msg)
        except httpx.HTTPStatusError as exc:
            msg = f"NL SQL API HTTP {exc.response.status_code}: {exc}"
            _logger.warning("nl_sql_client.http_error", status=exc.response.status_code, error=str(exc))
            return NLSQLResult(success=False, error=msg)
        except Exception as exc:
            msg = f"NL SQL API unexpected error: {exc}"
            _logger.error("nl_sql_client.error", error=str(exc), error_type=type(exc).__name__)
            return NLSQLResult(success=False, error=msg)

    if not result_holder:
        msg = "NL SQL API stream ended without sql_complete event"
        _logger.warning("nl_sql_client.no_result", events_received=received_events)
        return NLSQLResult(success=False, error=msg)

    return result_holder[-1]


_CLEAN_SQL_SYSTEM = (
    "You are a PostgreSQL SQL cleaner. Given a SQL query, do ALL of the following:\n"
    "1. Remove any trailing LIMIT clause at the very end (e.g. LIMIT 200, LIMIT 100, LIMIT 500).\n"
    "2. Remove any trailing semicolon.\n"
    "3. Fix escape character artifacts in string literals "
    "(e.g. remove extra backslashes like \\' → ', \\\" → \").\n"
    "4. Enforce the active-site filter: find any WHERE condition on pj_project_status that is a "
    "'not completed' check — e.g. 'NOT ILIKE \\'complet%\\'', 'IS NULL OR ... NOT ILIKE', "
    "'NOT IN (\\'Complete\\', \\'Closed\\')', 'IS NULL OR pj_project_status ...' — and replace "
    "that ENTIRE pj_project_status predicate (including any IS NULL OR ... wrapper) with exactly: "
    "pj_project_status = 'Active'. "
    "If pj_project_status is reached via a LEFT JOIN and you change its condition to = 'Active', "
    "also change that LEFT JOIN to INNER JOIN so NULL rows are excluded.\n"
    "5. Do NOT change any other logic, column names, or WHERE conditions.\n"
    "6. Return ONLY the clean SQL. No markdown fences, no explanation, no preamble."
)


async def clean_sql_with_llm(sql: str) -> str:
    """Use a fast LLM call to strip LIMIT clauses, semicolons, and escape artifacts from AI-generated SQL."""
    if not sql or not sql.strip():
        return sql
    llm = build_llm("planner")
    try:
        response = await llm.ainvoke([
            SystemMessage(content=_CLEAN_SQL_SYSTEM),
            HumanMessage(content=sql),
        ])
        cleaned = response.content.strip() if isinstance(response.content, str) else str(response.content).strip()
        # Strip markdown fences if the model wraps output anyway
        if cleaned.startswith("```"):
            cleaned = re.sub(r"^```\w*\n?", "", cleaned)
            cleaned = re.sub(r"\n?```$", "", cleaned).strip()
        _logger.info("nl_sql_client.clean_sql", original_len=len(sql), cleaned_len=len(cleaned))
        return cleaned
    except Exception as exc:
        _logger.warning("nl_sql_client.clean_sql.failed", error=str(exc))
        # Fallback: just strip trailing semicolon
        return _normalize_nl_sql(sql)


def build_retry_query(original_question: str, sql: str, error: str) -> str:
    """Build a retry NL query that includes the original question, failed SQL, and the error."""
    sql_block = f"```sql\n{sql}\n```" if sql else "(no SQL generated)"
    return (
        f"{original_question}\n\n"
        f"I asked the above question and received this SQL:\n{sql_block}\n\n"
        f"When I executed it, I got this error: {error}\n\n"
        f"Please provide corrected SQL that fixes this error."
    )


_CONDITION_SYSTEM = (
    "You are a data analyst. Convert the given risk identification logic and threshold rules "
    "into a single, concise condition statement that a SQL generator can use directly.\n\n"
    "Output format — start with exactly: 'a site is considered at risk if'\n"
    "Then list each condition joined by AND (or OR only when the logic explicitly says OR).\n\n"
    "Rules:\n"
    "- Use the column names and values already mentioned in the identification logic and rules\n"
    "- Convert procedural steps ('fetch X', 'check Y', 'compare Z') into direct data conditions\n"
    "- Express each condition as a data predicate: column = 'value', IS NULL, > N, < date, etc.\n"
    "- Do NOT invent column names — only use names explicitly mentioned in the input\n"
    "- Keep it concise: one to three sentences maximum\n"
    "- Output ONLY the condition statement — no preamble, no explanation"
)


async def preprocess_condition_with_llm(
    identification_logic: str,
    decision_rules: list[str],
    category_name: str,
    business_context: str | None = None,
) -> str:
    """Use LLM to convert identification_logic + decision_rules into a clean condition statement.

    Transforms procedural descriptions ('fetch X, check Y, compare Z') into direct
    data predicates ('column = value AND other_column IS NULL') that a Text-to-SQL
    API can translate directly to a WHERE clause.

    business_context provides project-specific column names and phase definitions so
    the LLM can reference the correct column names in the generated predicates.

    Falls back to the raw identification_logic if the LLM call fails.
    """
    rules_text = "\n".join(f"- {r}" for r in decision_rules) if decision_rules else "(none)"
    ctx_block = f"Project business context (use these column names and values as reference):\n{business_context}\n\n" if business_context else ""
    human = (
        f"{ctx_block}"
        f"Risk category: {category_name}\n\n"
        f"Identification logic:\n{identification_logic}\n\n"
        f"Threshold rules:\n{rules_text}"
    )
    llm = build_llm("planner")
    try:
        response = await llm.ainvoke([
            SystemMessage(content=_CONDITION_SYSTEM),
            HumanMessage(content=human),
        ])
        result = response.content.strip() if isinstance(response.content, str) else str(response.content).strip()
        _logger.info(
            "nl_sql_client.preprocess_condition",
            category=category_name,
            original_len=len(identification_logic),
            rephrased=result,
        )
        return result
    except Exception as exc:
        _logger.warning("nl_sql_client.preprocess_condition.failed", error=str(exc))
        return identification_logic
