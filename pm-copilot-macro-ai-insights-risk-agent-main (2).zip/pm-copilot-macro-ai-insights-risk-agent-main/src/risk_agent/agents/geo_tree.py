"""Geo Tree Agent.

Fetches the geographic hierarchy (Region → Area → Market) from the external
geo tree API and stores it in state. Downstream geo analyzers use the tree
to enumerate units at each level and to extract geo_code values for SQL
filter parameters.
"""

from __future__ import annotations

from typing import Any

import httpx

from risk_agent.config import get_settings
from risk_agent.models import AgentState
from risk_agent.utils.logging import get_logger

_logger = get_logger(__name__)


# --------------------------------------------------------------------------- #
# HTTP client
# --------------------------------------------------------------------------- #


async def _fetch_geo_tree(url: str) -> dict | None:
    """GET the geo hierarchy API. Returns raw JSON dict or None on failure."""
    async with httpx.AsyncClient(timeout=15) as client:
        resp = await client.get(url, headers={"accept": "application/json"})
        resp.raise_for_status()
        return resp.json()


# --------------------------------------------------------------------------- #
# Tree traversal helpers
# --------------------------------------------------------------------------- #


def get_region_codes(tree: Any) -> list[dict[str, Any]]:
    """Extract top-level region entries from the geo tree.

    Returns a list of dicts:  {"geo_code": str, "geo_name": str, "children": [...]}
    Handles both list-of-regions and dict-with-"data"-key shapes.
    """
    regions: list[Any] = []

    if isinstance(tree, list):
        regions = tree
    elif isinstance(tree, dict):
        for key in ("data", "regions", "results", "tree"):
            if key in tree and isinstance(tree[key], list):
                regions = tree[key]
                break
        if not regions:
            regions = list(tree.values()) if tree else []

    result: list[dict[str, Any]] = []
    for item in regions:
        if not isinstance(item, dict):
            continue
        geo_code = str(item.get("geo_code") or item.get("code") or item.get("id") or "")
        geo_name = str(item.get("geo_name") or item.get("name") or geo_code)
        children = item.get("children") or item.get("areas") or []
        result.append({"geo_code": geo_code, "geo_name": geo_name, "children": children})

    return result


def get_area_codes(tree: Any, region_geo_code: str) -> list[dict[str, Any]]:
    """Return area entries whose parent region has the given geo_code."""
    for region in get_region_codes(tree):
        if region["geo_code"] == region_geo_code:
            return _extract_children(region["children"], "markets")
    return []


def get_market_codes(tree: Any, area_geo_code: str) -> list[dict[str, Any]]:
    """Return market entries whose parent area has the given geo_code."""
    for region in get_region_codes(tree):
        for area in _extract_children(region["children"], "markets"):
            if area["geo_code"] == area_geo_code:
                return _extract_children(area["children"], "sites")
    return []


def _extract_children(children: Any, fallback_key: str) -> list[dict[str, Any]]:
    """Normalise a children payload to a list of {geo_code, geo_name, children} dicts."""
    if not children:
        return []
    if isinstance(children, dict):
        children = list(children.values())
    if not isinstance(children, list):
        return []

    result: list[dict[str, Any]] = []
    for item in children:
        if not isinstance(item, dict):
            continue
        geo_code = str(item.get("geo_code") or item.get("code") or item.get("id") or "")
        geo_name = str(item.get("geo_name") or item.get("name") or geo_code)
        sub = item.get("children") or item.get(fallback_key) or []
        result.append({"geo_code": geo_code, "geo_name": geo_name, "children": sub})
    return result


# --------------------------------------------------------------------------- #
# LangGraph node
# --------------------------------------------------------------------------- #


async def fetch_geo_tree_node(state: AgentState) -> dict[str, Any]:
    """LangGraph node: fetch the full geo hierarchy from the API.

    Stores the raw tree in state["geo_tree"]. Downstream nodes call
    get_region_codes / get_area_codes / get_market_codes to navigate it.
    On failure, stores None — downstream nodes skip gracefully.
    """
    url = get_settings().agent.geo_tree_api_url
    try:
        tree = await _fetch_geo_tree(url)
        region_count = len(get_region_codes(tree)) if tree else 0
        _logger.info(
            "geo_tree.fetched",
            url=url,
            type=type(tree).__name__,
            region_count=region_count,
        )
        return {"geo_tree": tree}
    except Exception as exc:
        _logger.warning(
            "geo_tree.failed",
            url=url,
            error=str(exc),
            error_type=type(exc).__name__,
            hint="Geo-hierarchical analysis will be skipped for this run.",
        )
        return {"geo_tree": None}
