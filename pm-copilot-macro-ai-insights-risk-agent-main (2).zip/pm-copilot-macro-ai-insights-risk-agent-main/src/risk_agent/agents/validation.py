"""Validation Agent.

Sits between the planner and the risk-identification agent. Acts as a
relevance gate so risk-identification only sees step results that could
plausibly support a finding for the current ``RiskCategory``.

Pipeline:
    1. Heuristic pre-filter — drop FAILED / TIMEOUT / SKIPPED / empty
       steps deterministically (no LLM cost).
    2. LLM relevance scoring — ask the validator LLM which of the
       surviving steps are on-topic for this risk category.
    3. Write the kept subset to ``validated_step_results`` and
       human-readable rejection reasons to ``validation_notes``. The
       raw ``step_results`` is never mutated, preserving the audit
       trail.

If the LLM call fails or returns unparseable output, we fall through
with the heuristic survivors — better to over-include than to silently
produce zero findings.
"""

from __future__ import annotations

import time
from typing import Any
from uuid import UUID

from langchain_core.messages import HumanMessage, SystemMessage

from risk_agent.agents._formatting import format_rules, format_step_results
from risk_agent.core.json_parsing import parse_llm_json
from risk_agent.core.llm import build_llm
from risk_agent.models import (
    AgentState,
    RiskCategory,
    StepResult,
    StepStatus,
)
from risk_agent.models import TraversalStep
from risk_agent.prompts import (
    VALIDATE_PLAN_SYSTEM_PROMPT,
    VALIDATE_PLAN_USER_PROMPT,
    VALIDATION_SYSTEM_PROMPT,
    VALIDATION_USER_PROMPT,
)
from risk_agent.utils.sql_safety import validate_sql
from risk_agent.utils.logging import get_logger
from risk_agent.utils.metrics import (
    llm_calls_total,
    llm_duration_seconds,
)

_logger = get_logger(__name__)


def _format_planned_steps(steps: list[TraversalStep]) -> str:
    """Render planned steps for the validate_plan_node prompt."""
    lines: list[str] = []
    for step in steps:
        lines.append(f"step_id: {step.step_id}")
        lines.append(f"  name:      {step.name}")
        lines.append(f"  source:    {step.source.value}")
        lines.append(f"  rationale: {step.rationale}")
        lines.append(f"  sql (preview): {step.sql_query[:200]}{'...' if len(step.sql_query) > 200 else ''}")
        lines.append("")
    return "\n".join(lines)


async def validate_plan_node(state: AgentState) -> dict[str, Any]:
    """LangGraph node: validate planned steps before execution.

    Phase 1 — SQL safety (deterministic, no LLM): reject any step whose
    SQL fails `validate_sql()`.
    Phase 2 — LLM relevance check: ask the LLM which safe steps are
    actually relevant to the risk category.

    Writes `validated_planned_steps` + `validation_notes` into state.
    Falls back to all SQL-safe steps if the LLM call fails.
    """
    category: RiskCategory = state["category"]
    planned_steps: list[TraversalStep] = list(state.get("planned_steps", []))

    _logger.info(
        "validate_plan.start",
        category_id=category.category_id,
        step_count=len(planned_steps),
    )

    # ---- Phase 1: SQL safety (no LLM) ------------------------------------
    safe_steps: list[TraversalStep] = []
    notes: list[str] = []
    for step in planned_steps:
        try:
            validate_sql(step.sql_query)
            safe_steps.append(step)
        except Exception as exc:
            msg = f"{step.name} ({step.step_id}): dropped — SQL invalid: {exc}"
            notes.append(msg)
            _logger.warning(
                "validate_plan.sql_invalid",
                step_name=step.name,
                step_id=str(step.step_id),
                error=str(exc),
            )

    if not safe_steps:
        _logger.info(
            "validate_plan.done.no_safe_steps",
            category_id=category.category_id,
            dropped=len(notes),
        )
        return {"validated_planned_steps": [], "validation_notes": notes}

    # ---- Phase 2: LLM relevance check ------------------------------------
    from risk_agent.agents._formatting import format_rules

    user_prompt = VALIDATE_PLAN_USER_PROMPT.format(
        category_id=category.category_id,
        name=category.name,
        description=category.description,
        identification_logic=category.identification_logic,
        decision_rules=format_rules(category.decision_rules),
        planned_steps=_format_planned_steps(safe_steps),
    )

    llm = build_llm("validator")
    messages = [
        SystemMessage(content=VALIDATE_PLAN_SYSTEM_PROMPT),
        HumanMessage(content=user_prompt),
    ]

    started = time.perf_counter()
    try:
        response = await llm.ainvoke(messages)
    except Exception as exc:
        elapsed = time.perf_counter() - started
        llm_duration_seconds.labels(agent="validator").observe(elapsed)
        llm_calls_total.labels(agent="validator", status="failed").inc()
        _logger.warning(
            "validate_plan.llm.failed_falling_through",
            error=str(exc),
            kept=len(safe_steps),
        )
        notes.append(f"validate_plan LLM failed ({exc}); kept all SQL-safe steps")
        return {
            "validated_planned_steps": safe_steps,
            "validation_notes": notes,
        }

    elapsed = time.perf_counter() - started
    llm_duration_seconds.labels(agent="validator").observe(elapsed)
    llm_calls_total.labels(agent="validator", status="success").inc()

    raw_content = (
        response.content if isinstance(response.content, str) else str(response.content)
    )

    try:
        parsed = parse_llm_json(raw_content)
    except Exception as exc:
        _logger.warning(
            "validate_plan.parse.failed_falling_through",
            error=str(exc),
            kept=len(safe_steps),
        )
        notes.append(
            f"validate_plan output unparseable ({exc}); kept all SQL-safe steps"
        )
        return {
            "validated_planned_steps": safe_steps,
            "validation_notes": notes,
        }

    keep_ids: set[UUID] = set()
    for raw_id in parsed.get("kept_step_ids", []) or []:
        try:
            keep_ids.add(UUID(str(raw_id)))
        except (ValueError, TypeError):
            continue

    for rej in parsed.get("rejections", []) or []:
        if not isinstance(rej, dict):
            continue
        sid = str(rej.get("step_id", "")).strip()
        reason = str(rej.get("reason", "")).strip() or "off-topic"
        notes.append(f"{sid}: dropped — {reason}")

    validated = [s for s in safe_steps if s.step_id in keep_ids]

    if not validated:
        _logger.warning(
            "validate_plan.kept_zero_overriding",
            category_id=category.category_id,
            candidate_count=len(safe_steps),
        )
        notes.append(
            f"validate_plan kept zero of {len(safe_steps)} safe steps; overriding to keep all"
        )
        validated = safe_steps

    _logger.info(
        "validate_plan.done",
        category_id=category.category_id,
        in_count=len(planned_steps),
        kept=len(validated),
        dropped_total=len(planned_steps) - len(validated),
        duration_ms=round(elapsed * 1000, 2),
    )

    return {
        "validated_planned_steps": validated,
        "validation_notes": notes,
    }


async def validation_node(state: AgentState) -> dict[str, Any]:
    """LangGraph node: filter step_results down to those relevant to the category."""
    category: RiskCategory = state["category"]
    step_results: list[StepResult] = list(state.get("step_results", []))

    _logger.info(
        "validator.start",
        category_id=category.category_id,
        step_count=len(step_results),
    )

    # ---- Phase 1: heuristic pre-filter ---------------------------------
    candidates: list[StepResult] = []
    notes: list[str] = []
    for r in step_results:
        if r.status != StepStatus.SUCCESS:
            notes.append(
                f"{r.step_name} ({r.step_id}): dropped — status={r.status.value}"
            )
            continue
        if r.row_count == 0:
            notes.append(
                f"{r.step_name} ({r.step_id}): dropped — empty result"
            )
            continue
        candidates.append(r)

    if not candidates:
        _logger.info(
            "validator.done.no_candidates",
            category_id=category.category_id,
            dropped=len(notes),
        )
        return {"validated_step_results": [], "validation_notes": notes}

    # ---- Phase 2: LLM relevance scoring --------------------------------
    user_prompt = VALIDATION_USER_PROMPT.format(
        category_id=category.category_id,
        name=category.name,
        description=category.description,
        identification_logic=category.identification_logic,
        decision_rules=format_rules(category.decision_rules),
        step_results=format_step_results(candidates),
    )

    llm = build_llm("validator")
    messages = [
        SystemMessage(content=VALIDATION_SYSTEM_PROMPT),
        HumanMessage(content=user_prompt),
    ]

    started = time.perf_counter()
    try:
        response = await llm.ainvoke(messages)
    except Exception as exc:
        elapsed = time.perf_counter() - started
        llm_duration_seconds.labels(agent="validator").observe(elapsed)
        llm_calls_total.labels(agent="validator", status="failed").inc()
        _logger.warning(
            "validator.llm.failed_falling_through",
            error=str(exc),
            kept=len(candidates),
        )
        notes.append(f"validator LLM failed ({exc}); kept all heuristic survivors")
        return {
            "validated_step_results": candidates,
            "validation_notes": notes,
        }

    elapsed = time.perf_counter() - started
    llm_duration_seconds.labels(agent="validator").observe(elapsed)
    llm_calls_total.labels(agent="validator", status="success").inc()

    raw_content = (
        response.content if isinstance(response.content, str) else str(response.content)
    )

    try:
        parsed = parse_llm_json(raw_content)
    except Exception as exc:
        _logger.warning(
            "validator.parse.failed_falling_through",
            error=str(exc),
            kept=len(candidates),
        )
        notes.append(
            f"validator output unparseable ({exc}); kept all heuristic survivors"
        )
        return {
            "validated_step_results": candidates,
            "validation_notes": notes,
        }

    keep_ids: set[UUID] = set()
    for raw_id in parsed.get("kept_step_ids", []) or []:
        try:
            keep_ids.add(UUID(str(raw_id)))
        except (ValueError, TypeError):
            continue

    for rej in parsed.get("rejections", []) or []:
        if not isinstance(rej, dict):
            continue
        sid = str(rej.get("step_id", "")).strip()
        reason = str(rej.get("reason", "")).strip() or "off-topic"
        notes.append(f"{sid}: dropped — {reason}")

    validated = [r for r in candidates if r.step_id in keep_ids]

    # Safety net: if the LLM rejected everything but we had candidates,
    # don't trust that — keep the heuristic survivors and log.
    if not validated:
        _logger.warning(
            "validator.kept_zero_overriding",
            category_id=category.category_id,
            candidate_count=len(candidates),
        )
        notes.append(
            "validator kept zero of "
            f"{len(candidates)} candidates; overriding to keep all survivors"
        )
        validated = candidates

    _logger.info(
        "validator.done",
        category_id=category.category_id,
        in_count=len(step_results),
        kept=len(validated),
        dropped_total=len(step_results) - len(validated),
        duration_ms=round(elapsed * 1000, 2),
    )

    return {
        "validated_step_results": validated,
        "validation_notes": notes,
    }
