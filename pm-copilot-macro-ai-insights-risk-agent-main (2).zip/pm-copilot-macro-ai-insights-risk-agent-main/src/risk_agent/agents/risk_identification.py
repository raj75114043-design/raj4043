"""Risk Identification Agent.

Consumes the aggregated step results produced by the planner's concurrent
execution and asks Azure OpenAI to produce a list of structured
``RiskFinding`` objects plus a short summary.

The output schema is FIXED:
    findings[*] = {
        risk, description, root_cause,
        mitigation_actions[], recovery_plan[], drill_down_tables[],
        severity, confidence, impact_summary,
        evidence_step_ids[]
    }

We re-attach the evidence (bounded sample rows) to each finding so the
downstream consumer can audit without needing to re-run the steps.
"""

from __future__ import annotations

import math
import re
import time
from typing import Any
from uuid import UUID

from langchain_core.messages import HumanMessage, SystemMessage

from risk_agent.agents._formatting import format_rules, format_step_results
from risk_agent.agents.milestone_enricher import format_milestones_for_prompt
from risk_agent.core.json_parsing import parse_llm_json
from risk_agent.core.llm import build_llm
from risk_agent.models import (
    AgentState,
    RiskCategory,
    RiskEvidence,
    RiskFinding,
    RiskImpact,
    RiskLikelihood,
    RiskSeverity,
    StepResult,
)
from risk_agent.models.domain import GeoFinding
from risk_agent.prompts import (
    GENERATOR_SYSTEM_PROMPT,
    GENERATOR_USER_PROMPT,
    MARKET_SITE_ANALYSIS_SYSTEM,
    MARKET_SITE_ANALYSIS_USER,
)
from risk_agent.utils.exceptions import LLMError
from risk_agent.utils.logging import get_logger
from risk_agent.utils.metrics import (
    findings_total,
    llm_calls_total,
    llm_duration_seconds,
)
from risk_agent.utils.risk_assessment import calculate_risk_rating

_logger = get_logger(__name__)


_SAMPLE_ROWS_PER_STEP = 5
_MARKET_BATCH_SIZE = 100


# --------------------------------------------------------------------------- #
# Evidence attachment
# --------------------------------------------------------------------------- #


def _attach_evidence(
    evidence_step_ids: list[Any],
    results_by_id: dict[UUID, StepResult],
) -> list[RiskEvidence]:
    """Convert the LLM's list of step_id strings into RiskEvidence objects."""
    evidence: list[RiskEvidence] = []
    for raw_id in evidence_step_ids:
        try:
            sid = UUID(str(raw_id))
        except (ValueError, TypeError):
            continue
        result = results_by_id.get(sid)
        if result is None:
            continue
        evidence.append(
            RiskEvidence(
                step_id=result.step_id,
                step_name=result.step_name,
                source=result.source,
                sample_rows=result.rows[:_SAMPLE_ROWS_PER_STEP],
                row_count=result.row_count,
                related_kpi=result.related_kpi,
            )
        )
    return evidence


def _coerce_str_list(value: Any) -> list[str]:
    """Normalize a possibly-None / possibly-string field into list[str].

    The LLM sometimes hands us a single string where a list is expected
    (e.g. `recovery_plan: "do X, then Y"`). We accept and split.
    """
    if value is None:
        return []
    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]
    text = str(value).strip()
    if not text:
        return []
    # Split on newline, semicolon, or numbered list markers.
    for sep in ("\n", ";"):
        if sep in text:
            return [p.strip() for p in text.split(sep) if p.strip()]
    return [text]


def _coerce_drill_down_tables(value: Any) -> list[dict[str, Any]]:
    """Normalize drill_down_tables to list[dict]. Drop anything that isn't a dict."""
    if not value or not isinstance(value, list):
        return []
    clean: list[dict[str, Any]] = []
    for item in value:
        if isinstance(item, dict):
            clean.append(item)
    return clean


def _build_site_drill_down_tables(
    site_results: list[StepResult],
) -> list[dict[str, Any]]:
    """Build drill_down_tables directly from geo site step results.

    Each flagged market becomes one table entry. Row count matches
    impacted_sites_count exactly — no LLM truncation.
    """
    tables: list[dict[str, Any]] = []
    for result in site_results:
        if not result.rows:
            continue
        columns = list(result.rows[0].keys())
        rows = [[row.get(col) for col in columns] for row in result.rows]
        tables.append({
            "title": result.step_name,
            "columns": columns,
            "rows": rows,
            "source_step_id": str(result.step_id),
        })
    return tables


# --------------------------------------------------------------------------- #
# Geo isolation helpers
# --------------------------------------------------------------------------- #


def _format_rows_as_table(rows: list[dict[str, Any]]) -> str:
    """Format a list of row dicts as a plain-text pipe-delimited table."""
    if not rows:
        return "(no rows)"
    cols = list(rows[0].keys())
    header = " | ".join(str(c) for c in cols)
    separator = "-" * len(header)
    body = "\n".join(" | ".join(str(row.get(c, "")) for c in cols) for row in rows)
    return f"{header}\n{separator}\n{body}"


def _site_results_for_region(
    region_geo_code: str,
    area_findings: list[GeoFinding],
    market_findings: list[GeoFinding],
    site_results_geo: list[StepResult],
) -> list[StepResult]:
    """Return only the site StepResults that belong to the given region.

    Walks the region → area → market chain using parent_geo_code links,
    then matches site StepResult step_names (format: "Site-level: <name> (<geo_code>)").
    """
    area_codes = {a.geo_code for a in area_findings if a.parent_geo_code == region_geo_code}
    # Also include markets parented directly to the region (NAS has no area level)
    market_codes = {
        m.geo_code for m in market_findings
        if m.parent_geo_code in area_codes or m.parent_geo_code == region_geo_code
    }
    result: list[StepResult] = []
    for sr in site_results_geo:
        match = re.search(r"\(([^)]+)\)$", sr.step_name)
        if match and match.group(1) in market_codes:
            result.append(sr)
    return result


async def _summarize_market_sites(
    market_name: str,
    rows: list[dict[str, Any]],
    category: RiskCategory,
    llm: Any,
) -> str:
    """Analyze a market's site rows in batches and return a compact summary."""
    if not rows:
        return f"{market_name}: no breaching sites."

    total_batches = math.ceil(len(rows) / _MARKET_BATCH_SIZE)
    chunk_summaries: list[str] = []

    for i in range(0, len(rows), _MARKET_BATCH_SIZE):
        batch = rows[i : i + _MARKET_BATCH_SIZE]
        batch_n = i // _MARKET_BATCH_SIZE + 1
        usr_p = MARKET_SITE_ANALYSIS_USER.format(
            market_name=market_name,
            category_name=category.name,
            batch_n=batch_n,
            total_batches=total_batches,
            rows_as_table=_format_rows_as_table(batch),
        )
        try:
            response = await llm.ainvoke(
                [SystemMessage(content=MARKET_SITE_ANALYSIS_SYSTEM), HumanMessage(content=usr_p)]
            )
            chunk_summaries.append(
                response.content if isinstance(response.content, str) else str(response.content)
            )
            _logger.info(
                "risk_id.market_batch",
                market=market_name,
                batch_n=batch_n,
                rows=len(batch),
            )
        except Exception as exc:
            _logger.warning(
                "risk_id.market_summary_failed",
                market=market_name,
                batch=batch_n,
                error=str(exc),
            )

    if not chunk_summaries:
        return f"{market_name}: summarization failed."
    return f"=== {market_name} ({len(rows)} sites) ===\n" + "\n".join(chunk_summaries)


# --------------------------------------------------------------------------- #
# Node
# --------------------------------------------------------------------------- #


def _build_geo_section(
    region_findings: list[GeoFinding],
    area_findings: list[GeoFinding],
    market_findings: list[GeoFinding],
    site_results: list[StepResult],
) -> str:
    """Build a geo drill-down block grouped BY REGION.

    Data is structured so the generator can emit one finding per region
    without having to separate the evidence itself.
    """
    if not (region_findings or area_findings or market_findings or site_results):
        return ""

    lines = [
        "=== Geographic Drill-Down (one finding per region required) ===",
        "Each region below is a SEPARATE risk context — emit a separate finding for each.",
        "",
    ]

    # Index area/market/site data by parent geo_code for quick lookup.
    areas_by_region: dict[str, list[GeoFinding]] = {}
    for f in area_findings:
        areas_by_region.setdefault(f.parent_geo_code or "", []).append(f)

    markets_by_area: dict[str, list[GeoFinding]] = {}
    for f in market_findings:
        markets_by_area.setdefault(f.parent_geo_code or "", []).append(f)

    # Map market geo_code → site StepResult (step names contain market name).
    site_by_market: dict[str, StepResult] = {}
    for sr in site_results:
        # step_name format: "Site-level: <market_name> (<geo_code>)"
        m = re.search(r"\(([^)]+)\)$", sr.step_name)
        if m:
            site_by_market[m.group(1)] = sr

    for region in region_findings:
        lines.append(f"── REGION: {region.geo_name} (geo_code={region.geo_code}) ──")
        lines.append(f"   Risk signal: {region.summary} (metric: {region.metric_name})")

        region_areas = areas_by_region.get(region.geo_code, [])
        if region_areas:
            lines.append(f"   Anomalous areas ({len(region_areas)}):")
            for area in region_areas:
                area_markets = markets_by_area.get(area.geo_code, [])
                market_str = ""
                total_sites = 0
                if area_markets:
                    m_names = []
                    for mkt in area_markets:
                        sr = site_by_market.get(mkt.geo_code)
                        n = sr.row_count if sr else 0
                        total_sites += n
                        m_names.append(f"{mkt.geo_name} ({n} sites)")
                    market_str = f" → markets: {', '.join(m_names)}"
                lines.append(
                    f"     • {area.geo_name}: {area.summary}{market_str}"
                )
                if total_sites:
                    lines.append(f"       Total affected sites: {total_sites}")
        else:
            lines.append("   Areas: (no area-level drill-down available)")

        lines.append("")

    # If no region findings but we still have site data (geo pipeline skipped).
    if not region_findings and site_results:
        total = sum(r.row_count for r in site_results)
        lines.append(f"Site-level evidence: {total} sites across {len(site_results)} markets")

    return "\n".join(lines)


def _fmt_region_analysis(region_analysis_json: list[dict]) -> str:
    """Format region analysis JSON as a readable table for the generator prompt."""
    if not region_analysis_json:
        return "(no regional analysis data)"
    lines = ["Region | At-Risk Sites | Total Active | At-Risk % | Status"]
    lines.append("-" * 75)
    for r in region_analysis_json:
        region = r.get("region") or r.get("geo_code") or "?"
        at_risk = r.get("at_risk_count", 0)
        total = r.get("total_active", 0)
        pct = r.get("at_risk_pct", 0)
        status = "FLAGGED ←" if r.get("is_flagged") else "ok"
        lines.append(f"{region} | {at_risk} | {total} | {pct}% | {status}")
        if r.get("summary"):
            lines.append(f"  → {r['summary']}")
    return "\n".join(lines)


def _fmt_area_analysis(area_analysis_json: list[dict]) -> str:
    """Format area analysis JSON for the generator prompt."""
    if not area_analysis_json:
        return "(no area analysis data)"
    lines = ["Area | Parent Region | At-Risk | Total Active | At-Risk % | Status"]
    lines.append("-" * 80)
    for r in area_analysis_json:
        area = r.get("area") or r.get("geo_code") or "?"
        region = r.get("parent_region_code") or "?"
        at_risk = r.get("at_risk_count", 0)
        total = r.get("total_active", 0)
        pct = r.get("at_risk_pct", 0)
        status = "FLAGGED ←" if r.get("is_flagged") else "ok"
        lines.append(f"{area} | {region} | {at_risk} | {total} | {pct}% | {status}")
    return "\n".join(lines)


def _fmt_market_analysis(market_findings: list[GeoFinding]) -> str:
    """Format market geo findings for the generator prompt."""
    if not market_findings:
        return "(no market analysis data)"
    lines = ["Market | Parent Area | Summary"]
    lines.append("-" * 80)
    for f in market_findings:
        lines.append(f"{f.geo_name} | {f.parent_geo_code or '?'} | {f.summary}")
    return "\n".join(lines)


def _evidence_from_site_results(site_results: list[StepResult]) -> list[RiskEvidence]:
    """Build RiskEvidence from scoped site StepResults (no flat steps in new pipeline)."""
    evidence: list[RiskEvidence] = []
    for sr in site_results[:5]:
        evidence.append(RiskEvidence(
            step_id=sr.step_id,
            step_name=sr.step_name,
            source=sr.source,
            sample_rows=sr.rows[:_SAMPLE_ROWS_PER_STEP],
            row_count=sr.row_count,
            related_kpi=None,
        ))
    return evidence


async def risk_identification_node(state: AgentState) -> dict[str, Any]:
    """LangGraph node: synthesize final risk findings from geo analysis results.

    Uses geo analysis JSON (region/area/market percentages), site-level rows,
    and milestone data to produce one RiskFinding per flagged region.
    Flat step_results are used as a fallback if no geo data is present.
    """
    category: RiskCategory = state["category"]
    business_context: str | None = state.get("business_context")
    project: str | None = state.get("project")

    # Geo pipeline outputs.
    region_findings: list[GeoFinding] = list(state.get("region_geo_findings") or [])
    area_findings: list[GeoFinding] = list(state.get("area_geo_findings") or [])
    market_findings: list[GeoFinding] = list(state.get("market_geo_findings") or [])
    site_results_geo: list[StepResult] = list(state.get("excel_site_step_results") or [])
    region_analysis_json: list[dict] = list(state.get("region_analysis_json") or [])
    area_analysis_json: list[dict] = list(state.get("area_analysis_json") or [])
    site_milestones: dict = state.get("site_milestones") or {}
    market_site_summaries: dict = state.get("market_site_summaries") or {}

    # Flat steps (kept as fallback if geo pipeline didn't run).
    raw_step_results: list[StepResult] = list(state.get("step_results", []))
    validated = state.get("validated_step_results")
    step_results: list[StepResult] = list(validated) if validated is not None else raw_step_results

    _logger.info(
        "identifier.start",
        category_id=category.category_id,
        region_findings=len(region_findings),
        area_findings=len(area_findings),
        market_findings=len(market_findings),
        site_geo_results=len(site_results_geo),
        milestone_sites=len(site_milestones),
        market_summaries_cached=len(market_site_summaries),
        flat_steps=len(step_results),
    )

    llm = build_llm("generator")

    # Build region → geo_code lookup for per-finding isolation.
    region_name_to_geo_code: dict[str, str] = {
        f.geo_name.upper(): f.geo_code for f in region_findings
    }

    # Reuse per-market LLM summaries computed in analyze_site_node (no second LLM pass).
    market_summaries_by_region: dict[str, str] = {}
    if site_results_geo:
        if region_findings:
            for region_f in region_findings:
                scoped = _site_results_for_region(
                    region_f.geo_code, area_findings, market_findings, site_results_geo
                )
                summaries = [market_site_summaries.get(sr.step_name, "") for sr in scoped]
                market_summaries_by_region[region_f.geo_code] = "\n\n".join(s for s in summaries if s)
        else:
            summaries = [market_site_summaries.get(sr.step_name, "") for sr in site_results_geo]
            market_summaries_by_region["__all__"] = "\n\n".join(s for s in summaries if s)

    market_summary_block = "\n\n".join(s for s in market_summaries_by_region.values() if s)

    # Total impacted sites.
    _geo_impacted_sites = sum(r.row_count for r in site_results_geo) or None

    milestone_section = format_milestones_for_prompt(site_milestones)

    user_prompt = GENERATOR_USER_PROMPT.format(
        business_context=business_context or "(none)",
        category_id=category.category_id,
        name=category.name,
        description=category.description,
        identification_logic=category.identification_logic,
        decision_rules=format_rules(category.decision_rules),
        region_analysis_section=_fmt_region_analysis(region_analysis_json),
        area_analysis_section=_fmt_area_analysis(area_analysis_json),
        market_analysis_section=_fmt_market_analysis(market_findings),
        market_summary_section=market_summary_block or "(no site-level analysis available)",
        milestone_section=milestone_section or "(no milestone data available)",
        impacted_sites_count=_geo_impacted_sites if _geo_impacted_sites is not None else "unknown",
    )

    messages = [
        SystemMessage(content=GENERATOR_SYSTEM_PROMPT),
        HumanMessage(content=user_prompt),
    ]

    started = time.perf_counter()
    try:
        response = await llm.ainvoke(messages)
    except Exception as exc:
        llm_calls_total.labels(agent="generator", status="failed").inc()
        _logger.error("identifier.llm.failed", error=str(exc))
        raise LLMError(f"Risk identification LLM call failed: {exc}") from exc

    elapsed = time.perf_counter() - started
    llm_duration_seconds.labels(agent="generator").observe(elapsed)
    llm_calls_total.labels(agent="generator", status="success").inc()

    raw_content = (
        response.content if isinstance(response.content, str) else str(response.content)
    )
    parsed = parse_llm_json(raw_content)

    results_by_id: dict[UUID, StepResult] = {r.step_id: r for r in step_results}
    findings: list[RiskFinding] = []

    # Shared fallbacks — used when the LLM-provided region can't be resolved.
    _geo_area_tags_all = [f.geo_name for f in area_findings]
    _geo_market_tags_all = [f.geo_name for f in market_findings]
    # Only fall back to single-region name; with multiple regions the LLM must set it.
    _geo_top_region = region_findings[0].geo_name if len(region_findings) == 1 else None

    for raw in parsed.get("findings", []):
        try:
            # --- Severity + confidence (with safe fallbacks) ---------------
            severity = RiskSeverity(
                str(raw.get("severity", "informational")).lower()
            )
            confidence = float(raw.get("confidence", 0.5))
            confidence = max(0.0, min(1.0, confidence))

            # --- New-schema fields ----------------------------------------
            risk_label = str(
                raw.get("risk") or raw.get("title") or "Unnamed risk"
            ).strip()
            description = str(raw.get("description", "")).strip()
            root_cause = str(raw.get("root_cause", "")).strip()
            mitigation_actions = _coerce_str_list(raw.get("mitigation_actions"))
            recovery_plan = _coerce_str_list(raw.get("recovery_plan"))

            region = raw.get("region") or None
            if region:
                region = str(region).strip() or None

            # --- Per-finding geo isolation --------------------------------
            # Scope site results, area/market tags, and impacted site count
            # to the region this finding belongs to, so West-region findings
            # don't include South-region drill-down tables (and vice-versa).
            region_geo_code = region_name_to_geo_code.get(region.upper()) if region else None
            if region_geo_code and site_results_geo:
                scoped_sites = _site_results_for_region(
                    region_geo_code, area_findings, market_findings, site_results_geo
                )
                area_codes_for_region = {
                    a.geo_code for a in area_findings if a.parent_geo_code == region_geo_code
                }
                _finding_area_tags = [
                    f.geo_name for f in area_findings if f.parent_geo_code == region_geo_code
                ]
                _finding_market_tags = [
                    f.geo_name for f in market_findings if f.parent_geo_code in area_codes_for_region
                ]
                _finding_impacted_sites = sum(sr.row_count for sr in scoped_sites) or None
            else:
                scoped_sites = site_results_geo
                _finding_area_tags = _geo_area_tags_all
                _finding_market_tags = _geo_market_tags_all
                _finding_impacted_sites = _geo_impacted_sites

            # --- Evidence --------------------------------------------------
            # In the geo-first pipeline results_by_id is empty (no flat steps).
            # Fall back to site step results; only skip if truly nothing exists.
            evidence = _attach_evidence(
                raw.get("evidence_step_ids", []) or [], results_by_id
            )
            if not evidence:
                evidence = _evidence_from_site_results(scoped_sites)
            if not evidence and not region_analysis_json:
                _logger.warning(
                    "identifier.finding_skipped_no_evidence",
                    risk=raw.get("risk") or raw.get("title"),
                )
                continue

            drill_down_tables = (
                _build_site_drill_down_tables(scoped_sites)
                if scoped_sites
                else _coerce_drill_down_tables(raw.get("drill_down_tables"))
            )

            # --- Likelihood, Impact, and Risk Rating -----------------------
            try:
                likelihood = RiskLikelihood(
                    str(raw.get("likelihood", "may_happen")).lower()
                )
            except ValueError:
                likelihood = RiskLikelihood.MAY_HAPPEN

            try:
                impact = RiskImpact(str(raw.get("impact", "major")).lower())
            except ValueError:
                impact = RiskImpact.MEDIUM

            risk_rating = calculate_risk_rating(likelihood, impact)

            # --- Legacy fields (kept for back-compat) ---------------------
            recommended_actions = _coerce_str_list(
                raw.get("recommended_actions")
            ) or mitigation_actions
            impact_summary = str(
                raw.get("impact_summary") or description
            ).strip()

            finding = RiskFinding(
                category_id=category.name,
                # New-schema fields
                risk=risk_label,
                description=description,
                root_cause=root_cause,
                mitigation_actions=mitigation_actions,
                recovery_plan=recovery_plan,
                drill_down_tables=drill_down_tables,
                # Legacy fields
                title=risk_label,
                severity=severity,
                confidence=confidence,
                impact_summary=impact_summary,
                recommended_actions=recommended_actions,
                # Risk Assessment Matrix fields
                likelihood=likelihood,
                impact=impact,
                risk_rating=risk_rating,
                evidence=evidence,
                # Geographic context — per-region scoped values
                region=region or _geo_top_region,
                project=project,
                area_tags=_finding_area_tags,
                market_tags=_finding_market_tags,
                impacted_sites_count=_finding_impacted_sites,
            )
            findings.append(finding)
            findings_total.labels(
                category_id=category.category_id, severity=severity.value
            ).inc()
        except Exception as exc:
            _logger.warning("identifier.finding_parse_failed", error=str(exc))

    summary = str(parsed.get("summary", "")) or None

    _logger.info(
        "identifier.done",
        category_id=category.category_id,
        finding_count=len(findings),
        duration_ms=round(elapsed * 1000, 2),
    )

    return {"findings": findings, "summary": summary}
