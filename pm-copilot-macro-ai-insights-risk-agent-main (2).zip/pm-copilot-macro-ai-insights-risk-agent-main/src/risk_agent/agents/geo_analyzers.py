"""Geo Analyzer Nodes — geo-first pipeline (Region → Area → Market → Site).

Region and area/market analyzers work from pre-aggregated data stored in state
by region_sql_plan_node (no extra SQL at analysis time).

Site analyzer generates a fresh NL→SQL query per flagged market, executes it
(paginated), fetches per-site milestone data inline, and produces a StepResult
with LLM site analysis that includes milestone context and business context.

Pipeline order:
  analyze_region_node  → region_geo_findings, region_analysis_json
  analyze_area_node    → area_geo_findings, area_analysis_json
  analyze_market_node  → market_geo_findings
  analyze_site_node    → excel_site_step_results  (+ populates site_milestones)
"""

from __future__ import annotations

import asyncio
import json
import math
import re
import time
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

import httpx
from langchain_core.messages import HumanMessage, SystemMessage

from risk_agent.agents.milestone_enricher import (
    _fetch_milestone,
    _get_site_identifier,
    _phase_summary,
)
from risk_agent.config import get_settings
from risk_agent.core.json_parsing import parse_llm_json
from risk_agent.core.llm import build_llm
from risk_agent.db import fetch_all
from risk_agent.models import AgentState, RiskCategory, StepResult, StepSource, StepStatus
from risk_agent.models.domain import GeoFinding
from risk_agent.prompts.generator import MARKET_SITE_ANALYSIS_SYSTEM
from risk_agent.prompts.geo_prompts import (
    build_area_analysis_prompt,
    build_market_analysis_prompt,
    build_region_analysis_prompt,
)
from risk_agent.utils.logging import get_logger
from risk_agent.utils.metrics import llm_calls_total, llm_duration_seconds
from risk_agent.utils.sql_safety import validate_sql

_logger = get_logger(__name__)

_SITE_BATCH_SIZE = 200
_SITE_MAX_ROWS = 2000
_MARKET_BATCH_SIZE = 200
_LLM_SITE_CAP = 200  # max rows sent to LLM per market; all rows still stored for drill-down
_MILESTONE_CONCURRENT = 20
_MILESTONE_TIMEOUT = 15


# ---------------------------------------------------------------------------
# Row filtering helper
# ---------------------------------------------------------------------------


def _filter_rows_by_value(rows: list[dict], geo_value: str) -> list[dict]:
    """Return rows where any column value exactly matches geo_value (case-insensitive).

    Used to pre-filter aggregation SQL results where the geo-level column name is
    unknown — the AI SQL generator chose it dynamically.  For site-level rows use
    _filter_rows_by_geo_column instead, which targets only the geo column and avoids
    false positives when the geo name appears in a comment or GC field.
    """
    target = geo_value.strip().upper()
    return [r for r in rows if any(str(v or "").strip().upper() == target for v in r.values())]


_GEO_COL_PATTERNS: dict[str, list[str]] = {
    "region": ["region", "rgn"],
    "area": ["area"],
    "market": ["market"],
}


def _find_geo_column(rows: list[dict], geo_level: str) -> str | None:
    """Find the column that represents a geographic level by scanning column name patterns."""
    if not rows:
        return None
    for col in rows[0].keys():
        col_lower = col.lower()
        for pattern in _GEO_COL_PATTERNS.get(geo_level, []):
            if pattern in col_lower:
                return col
    return None


def _filter_rows_by_geo_column(rows: list[dict], geo_value: str, geo_level: str) -> list[dict]:
    """Filter rows by matching only the specific geographic column for geo_level.

    Unlike _filter_rows_by_value (which matches ANY column), this finds the actual
    geo column by name pattern and filters only on that column.  This prevents false
    positives when a geo name (e.g. "BIRMINGHAM") appears in a comment or GC field.
    Falls back to _filter_rows_by_value when no geo column is found.
    """
    if not rows:
        return []
    geo_col = _find_geo_column(rows, geo_level)
    if geo_col:
        target = geo_value.strip().upper()
        filtered = [r for r in rows if str(r.get(geo_col) or "").strip().upper() == target]
        _logger.info(
            "geo_analyzers.filter_by_geo_col",
            geo_level=geo_level,
            geo_value=geo_value,
            geo_col=geo_col,
            before=len(rows),
            after=len(filtered),
        )
        return filtered
    # Column not found — fall back to any-column match
    _logger.info(
        "geo_analyzers.filter_by_value_fallback",
        geo_level=geo_level,
        geo_value=geo_value,
        hint="geo column not found in row keys",
    )
    return _filter_rows_by_value(rows, geo_value)


def _derive_agg_from_site_rows(site_rows: list[dict], geo_level: str) -> list[dict]:
    """Count at-risk sites per geo value from raw individual site rows.

    Used when the aggregation SQL returned no results but the site SQL did.
    Returns [{<geo_col>: value, "at_risk_count": n}, ...] sorted descending by count.
    """
    geo_col = _find_geo_column(site_rows, geo_level)
    if not geo_col:
        return []
    counts: dict[str, int] = {}
    for row in site_rows:
        val = str(row.get(geo_col) or "").strip()
        if val:
            counts[val] = counts.get(val, 0) + 1
    return [
        {geo_col: geo_val, "at_risk_count": count}
        for geo_val, count in sorted(counts.items(), key=lambda x: -x[1])
    ]


def _build_geo_count_from_site_rows(
    rows: list[dict],
    project: str | None = None,
) -> list[dict]:
    """Derive at-risk counts per (region, area, market) combination from individual site rows.

    The AI aggregation SQL often counts ALL active sites instead of only at-risk ones
    because it misapplies the risk WHERE clause. Site rows fetched by the site SQL are
    already correctly filtered, so counting them per geo unit gives accurate at-risk counts.

    NAS has no area level — area column is omitted from the output for NAS.
    Returns [{region_col: v, [area_col: v,] market_col: v, "at_risk_count": n}, ...]
    sorted descending by at_risk_count.
    """
    if not rows:
        return []

    region_col = _find_geo_column(rows, "region")
    market_col = _find_geo_column(rows, "market")

    if not region_col or not market_col:
        _logger.warning(
            "geo_analyzers.build_geo_count.missing_cols",
            region_col=region_col,
            market_col=market_col,
            hint="cannot derive geo counts — region or market column not found in site rows",
        )
        return []

    include_area = project != "NAS"
    area_col = _find_geo_column(rows, "area") if include_area else None

    counts: dict[tuple, int] = {}
    for row in rows:
        region = str(row.get(region_col) or "").strip()
        market = str(row.get(market_col) or "").strip()
        if not region or not market:
            continue
        area = str(row.get(area_col) or "").strip() if area_col else ""
        key = (region, area, market)
        counts[key] = counts.get(key, 0) + 1

    result: list[dict] = []
    for (region, area, market), count in sorted(counts.items(), key=lambda x: -x[1]):
        entry: dict[str, Any] = {region_col: region, market_col: market, "at_risk_count": count}
        if area_col and area:
            entry[area_col] = area
        result.append(entry)

    _logger.info(
        "geo_analyzers.build_geo_count.done",
        project=project,
        site_rows=len(rows),
        geo_combinations=len(result),
        sample=result[:3],
    )
    return result


def _sum_agg_by_geo(
    agg_rows: list[dict],
    geo_level: str,
    count_alias: str = "at_risk_count",
) -> list[dict]:
    """Pre-aggregate raw agg rows into one row per geo unit before the LLM sees them.

    The AI SQL generator may return extra columns alongside the risk count
    (e.g. e911_pending, total_sites_integrated, integration_date).  This function
    finds the right count column and sums it per geo value so the LLM always
    receives a clean, two-column table: {geo_col, count_alias}.

    Count column resolution order:
      1. Exact match on count_alias ('at_risk_count' or 'total_active_count')
      2. Any column whose name contains 'count' (case-insensitive)
      3. First int-valued column that is not the geo column (last resort)

    Returns [{geo_col: value, count_alias: n}, ...] sorted descending by count.
    Returns [] if the geo or count column cannot be found.
    """
    if not agg_rows:
        return []
    geo_col = _find_geo_column(agg_rows, geo_level)
    if not geo_col:
        return []

    sample = agg_rows[0]
    non_geo_cols = [c for c in sample.keys() if c != geo_col]

    # 1. Exact alias match
    count_col: str | None = count_alias if count_alias in sample else None

    # 2. Any column whose name contains "count"
    if not count_col:
        for col in non_geo_cols:
            if "count" in col.lower():
                count_col = col
                break

    # 3. First int-valued column
    if not count_col:
        for col in non_geo_cols:
            v = sample.get(col)
            if isinstance(v, int) and not isinstance(v, bool):
                count_col = col
                break

    if not count_col:
        _logger.warning(
            "geo_analyzers.sum_agg.no_count_col",
            geo_level=geo_level,
            columns=list(sample.keys()),
        )
        return []

    totals: dict[str, int] = {}
    for row in agg_rows:
        geo_val = str(row.get(geo_col) or "").strip()
        if not geo_val:
            continue
        cnt = row.get(count_col)
        if isinstance(cnt, int) and not isinstance(cnt, bool):
            totals[geo_val] = totals.get(geo_val, 0) + cnt

    _logger.info(
        "geo_analyzers.sum_agg",
        geo_level=geo_level,
        geo_col=geo_col,
        count_col=count_col,
        distinct_geo_units=len(totals),
        raw_rows=len(agg_rows),
    )
    return [
        {geo_col: geo_val, count_alias: count}
        for geo_val, count in sorted(totals.items(), key=lambda x: -x[1])
    ]


# ---------------------------------------------------------------------------
# LLM call helper
# ---------------------------------------------------------------------------


async def _call_llm(label: str, system: str, user: str, llm: Any) -> str | None:
    """Invoke LLM with system+user, return content string or None on failure."""
    started = time.perf_counter()
    try:
        response = await llm.ainvoke([SystemMessage(content=system), HumanMessage(content=user)])
        elapsed = time.perf_counter() - started
        llm_duration_seconds.labels(agent="generator").observe(elapsed)
        llm_calls_total.labels(agent="generator", status="success").inc()
        return response.content if isinstance(response.content, str) else str(response.content)
    except Exception as exc:
        elapsed = time.perf_counter() - started
        llm_duration_seconds.labels(agent="generator").observe(elapsed)
        llm_calls_total.labels(agent="generator", status="failed").inc()
        _logger.warning("geo_analyzers.llm_failed", label=label, error=str(exc))
        return None


# ---------------------------------------------------------------------------
# GeoFinding parser helpers
# ---------------------------------------------------------------------------


def _parse_json_list(text: str) -> list[dict]:
    """Parse LLM output as a JSON list, tolerating markdown fences and array format.

    parse_llm_json only handles objects ({...}). Geo prompts return arrays ([...]),
    so we extract the [...] block directly before falling back to parse_llm_json.
    """
    if not text:
        return []

    # Strip markdown fences first
    cleaned = re.sub(r"^```(?:json)?\s*|\s*```\s*$", "", text.strip(), flags=re.IGNORECASE | re.MULTILINE).strip()

    # Try JSON array extraction first (expected format for all geo prompts)
    first_bracket = cleaned.find("[")
    last_bracket = cleaned.rfind("]")
    if first_bracket != -1 and last_bracket > first_bracket:
        try:
            parsed = json.loads(cleaned[first_bracket : last_bracket + 1])
            if isinstance(parsed, list):
                return [item for item in parsed if isinstance(item, dict)]
        except json.JSONDecodeError:
            pass

    # Fall back to parse_llm_json for dict-wrapped responses
    try:
        parsed = parse_llm_json(text)
        if isinstance(parsed, list):
            return [item for item in parsed if isinstance(item, dict)]
        if isinstance(parsed, dict):
            for k in ("regions", "areas", "markets", "results", "data", "findings"):
                if isinstance(parsed.get(k), list):
                    return [item for item in parsed[k] if isinstance(item, dict)]
    except Exception:
        pass
    return []


def _to_geo_finding(item: dict, geo_level: str, parent_geo_code: str | None = None) -> GeoFinding | None:
    """Convert a parsed JSON dict to a GeoFinding, return None if incomplete."""
    geo_code = (
        str(item.get("geo_code") or item.get("region") or item.get("area") or item.get("market") or "").strip()
    )
    geo_name = (
        str(item.get("geo_name") or item.get("region") or item.get("area") or item.get("market") or "").strip()
    )
    if not geo_code:
        return None
    if not geo_name:
        geo_name = geo_code
    return GeoFinding(
        geo_level=geo_level,
        geo_code=geo_code,
        geo_name=geo_name,
        parent_geo_code=parent_geo_code or item.get("parent_region_code") or item.get("parent_area_code"),
        is_anomalous=bool(item.get("is_flagged", True)),
        metric_name="at_risk_pct",
        summary=str(item.get("summary") or ""),
        sample_rows=[],
        category_name=None,
    )


# ---------------------------------------------------------------------------
# Site SQL helpers (pagination)
# ---------------------------------------------------------------------------


def _strip_limit(sql: str) -> str:
    """Remove trailing LIMIT clause and semicolon so pagination can be applied."""
    sql = sql.strip().rstrip(";").rstrip()
    return re.sub(r"\s+LIMIT\s+\d+\s*$", "", sql, flags=re.IGNORECASE).strip()


async def _fetch_all_sites(sql: str, params: dict) -> list[dict]:
    """Paginate through all breaching sites in SITE_BATCH_SIZE batches."""
    base_sql = _strip_limit(sql)
    all_rows: list[dict] = []
    offset = 0
    while True:
        batch_sql = f"{base_sql} LIMIT {_SITE_BATCH_SIZE} OFFSET {offset}"
        try:
            batch = await fetch_all(batch_sql, params)
        except Exception as exc:
            _logger.warning("geo_analyzers.site.batch_failed", offset=offset, error=str(exc))
            break
        all_rows.extend(batch)
        _logger.info(
            "geo_analyzers.site.batch",
            offset=offset,
            rows_in_batch=len(batch),
            total_so_far=len(all_rows),
        )
        if len(batch) < _SITE_BATCH_SIZE:
            break
        offset += _SITE_BATCH_SIZE
        if len(all_rows) >= _SITE_MAX_ROWS:
            _logger.warning("geo_analyzers.site.batch_cap_reached", total=len(all_rows))
            break
    return all_rows




# ---------------------------------------------------------------------------
# Inline milestone enrichment
# ---------------------------------------------------------------------------


async def _enrich_milestones_for_rows(
    rows: list[dict],
    project: str | None,
) -> dict[str, dict]:
    """Fetch milestone data for all site IDs in rows. Returns dict keyed by site ID."""
    ids: list[str] = []
    seen: set[str] = set()
    for row in rows:
        sid = _get_site_identifier(row, project)
        if sid and str(sid) not in seen:
            seen.add(str(sid))
            ids.append(str(sid))

    if not ids:
        return {}

    settings = get_settings().agent
    if project == "AHLOA":
        base_url = settings.ahloa_milestone_api_url
    elif project == "NAS":
        base_url = settings.nas_milestone_api_url
    else:
        base_url = settings.milestone_api_url
    semaphore = asyncio.Semaphore(_MILESTONE_CONCURRENT)

    async def _bounded(sid: str, client: httpx.AsyncClient) -> tuple[str, dict | None]:
        async with semaphore:
            return await _fetch_milestone(sid, base_url, client)

    try:
        async with httpx.AsyncClient(timeout=_MILESTONE_TIMEOUT, follow_redirects=True) as client:
            results = await asyncio.gather(*[_bounded(sid, client) for sid in ids])
        return {sid: data for sid, data in results if data is not None}
    except Exception as exc:
        _logger.warning("geo_analyzers.milestone_enrich_failed", error=str(exc))
        return {}


# ---------------------------------------------------------------------------
# Per-market site LLM analysis
# ---------------------------------------------------------------------------


def _format_rows_as_table(rows: list[dict]) -> str:
    if not rows:
        return "(no rows)"
    cols = list(rows[0].keys())
    header = " | ".join(str(c) for c in cols)
    sep = "-" * len(header)
    body = "\n".join(" | ".join(str(row.get(c, "")) for c in cols) for row in rows)
    return f"{header}\n{sep}\n{body}"


async def _analyze_market_sites(
    market_name: str,
    rows: list[dict],
    category: RiskCategory,
    llm: Any,
    business_context: str | None,
    site_milestones: dict[str, dict],
    project: str | None,
    total_active: int,
    at_risk_total: int = 0,
) -> str:
    """Run batched LLM analysis of site rows for one market. Returns summary text.

    rows may be a capped subset for LLM efficiency; at_risk_total carries the true count.
    """
    if not rows:
        return f"=== {market_name} === No at-risk sites found."

    displayed_at_risk = at_risk_total if at_risk_total else len(rows)
    total_batches = math.ceil(len(rows) / _MARKET_BATCH_SIZE)
    chunk_summaries: list[str] = []

    for i in range(0, len(rows), _MARKET_BATCH_SIZE):
        batch = rows[i: i + _MARKET_BATCH_SIZE]
        batch_n = i // _MARKET_BATCH_SIZE + 1
        rows_text = _format_rows_as_table(batch)

        # Inline milestone data for sites in this batch
        milestone_lines: list[str] = []
        for row in batch:
            sid = _get_site_identifier(row, project)
            if sid and str(sid) in site_milestones:
                milestone_lines.append(_phase_summary(site_milestones[str(sid)]))
        milestone_text = "\n".join(milestone_lines) if milestone_lines else "(no milestone data for this batch)"

        ctx_block = f"Project domain context:\n{business_context}\n\n" if business_context else ""
        at_risk_line = (
            f"Total active sites in market: {total_active} | At-risk sites: {displayed_at_risk}"
            + (f" (showing top {len(rows)} for analysis)" if len(rows) < displayed_at_risk else "")
        )

        user_prompt = (
            f"{ctx_block}"
            f"Market: {market_name}\n"
            f"Risk category: {category.name}\n"
            f"Identification logic: {category.identification_logic}\n"
            f"{at_risk_line}\n\n"
            f"Site data — batch {batch_n} of {total_batches}:\n{rows_text}\n\n"
            f"Milestone phase data for sites in this batch:\n{milestone_text}\n\n"
            f"List the key risk signals, root causes (use milestone gaps to explain WHY), "
            f"and forward-looking concerns as bullet points only. "
            f"Highlight specific sites with the worst delays and explain why."
        )

        _logger.info("geo_analyzers.market_batch", market=market_name, batch_n=batch_n, rows=len(batch))
        content = await _call_llm(f"site-analysis:{market_name}:{batch_n}", MARKET_SITE_ANALYSIS_SYSTEM, user_prompt, llm)
        if content:
            chunk_summaries.append(content)

    header = (
        f"=== {market_name} ({displayed_at_risk} at-risk / {total_active} total active sites) ==="
    )
    return header + "\n" + "\n".join(chunk_summaries)


# ===========================================================================
# Node 1: analyze_region_node
# ===========================================================================


async def analyze_region_node(state: AgentState) -> dict[str, Any]:
    """Flag anomalous regions using pre-aggregated at-risk and total-active counts."""
    category: RiskCategory = state["category"]
    business_context: str | None = state.get("business_context")
    region_agg: list[dict] = list(state.get("region_agg_results") or [])
    total_agg: list[dict] = list(state.get("total_active_results") or [])
    all_site_rows: list[dict] = list(state.get("all_at_risk_site_rows") or [])

    # Fallback: derive region-level at-risk counts from pre-fetched site rows
    # when the aggregation SQL returned no results (AI generated inconsistent SQL).
    if not region_agg and all_site_rows:
        region_agg = _derive_agg_from_site_rows(all_site_rows, "region")
        _logger.info(
            "geo_analyzers.region.derived_agg_from_site_rows",
            derived_rows=len(region_agg),
            site_pool=len(all_site_rows),
        )

    _logger.info(
        "geo_analyzers.region.start",
        category_id=category.category_id,
        agg_rows=len(region_agg),
        total_rows=len(total_agg),
    )

    if not region_agg:
        _logger.warning("geo_analyzers.region.no_data")
        return {"region_geo_findings": [], "region_analysis_json": []}

    # Pre-aggregate in Python: one clean row per region, stable column names.
    # This strips extra AI-generated columns (e911_pending, avg_delay, etc.)
    # so the LLM always receives a predictable two-column table.
    region_agg_clean = _sum_agg_by_geo(region_agg, "region", "at_risk_count")
    total_agg_clean = _sum_agg_by_geo(total_agg, "region", "total_active_count")

    _logger.info(
        "geo_analyzers.region.input_rows",
        raw_agg_rows=len(region_agg),
        clean_agg_rows=len(region_agg_clean),
        raw_total_rows=len(total_agg),
        clean_total_rows=len(total_agg_clean),
        agg_sample=region_agg_clean[:3],
        total_sample=total_agg_clean[:3],
    )

    llm = build_llm("generator")
    system_prompt, user_prompt = build_region_analysis_prompt(
        category, business_context, region_agg_clean, total_agg_clean
    )
    content = await _call_llm("region-analysis", system_prompt, user_prompt, llm)

    _logger.info("geo_analyzers.region.llm_response", content=content)

    analysis_json: list[dict] = []
    region_findings: list[GeoFinding] = []

    if content:
        analysis_json = _parse_json_list(content)
        _logger.info("geo_analyzers.region.parsed", item_count=len(analysis_json), items=analysis_json)
        for item in analysis_json:
            _logger.info(
                "geo_analyzers.region.finding",
                region=item.get("region") or item.get("geo_code"),
                geo_code=item.get("geo_code"),
                at_risk_count=item.get("at_risk_count"),
                total_active=item.get("total_active"),
                at_risk_pct=item.get("at_risk_pct"),
                is_flagged=item.get("is_flagged"),
                summary=item.get("summary"),
            )
            if item.get("is_flagged"):
                gf = _to_geo_finding(item, "region")
                if gf:
                    region_findings.append(gf)

    _logger.info(
        "geo_analyzers.region.done",
        category_id=category.category_id,
        total_regions=len(analysis_json),
        flagged=len(region_findings),
    )
    return {
        "region_geo_findings": region_findings,
        "region_analysis_json": analysis_json,
    }


# ===========================================================================
# Node 2: analyze_area_node
# ===========================================================================


async def _analyze_areas_for_region(
    region_finding: GeoFinding,
    category: RiskCategory,
    business_context: str | None,
    region_agg: list[dict],
    total_agg: list[dict],
    region_analysis_json: list[dict],
    all_site_rows: list[dict],
    llm: Any,
) -> list[GeoFinding]:
    """Analyze areas within one flagged region. Returns flagged GeoFinding list."""
    region_code = region_finding.geo_code

    # Filter raw rows to this region by value-matching (column name is unknown)
    agg_for_region = _filter_rows_by_value(region_agg, region_code)
    total_for_region = _filter_rows_by_value(total_agg, region_code)

    # Fallback: derive area-level counts from pre-fetched site rows when
    # the aggregation SQL is empty or has no area breakdown for this region.
    if not agg_for_region and all_site_rows:
        region_site_rows = _filter_rows_by_geo_column(all_site_rows, region_code, "region")
        agg_for_region = _derive_agg_from_site_rows(region_site_rows, "area")
        _logger.info(
            "geo_analyzers.area.derived_agg_from_site_rows",
            region=region_code,
            derived_rows=len(agg_for_region),
            site_pool=len(region_site_rows),
        )

    if not agg_for_region:
        _logger.warning("geo_analyzers.area.no_data", region=region_code)
        return []

    parent_summary = region_finding.summary or ""

    # Pre-aggregate: one clean row per area, stripping extra AI-generated columns
    agg_for_region_clean = _sum_agg_by_geo(agg_for_region, "area", "at_risk_count")
    total_for_region_clean = _sum_agg_by_geo(total_for_region, "area", "total_active_count")

    _logger.info(
        "geo_analyzers.area.input_rows",
        region=region_code,
        raw_agg_rows=len(agg_for_region),
        clean_agg_rows=len(agg_for_region_clean),
        agg_sample=agg_for_region_clean[:3],
    )

    system_prompt, user_prompt = build_area_analysis_prompt(
        category, business_context,
        agg_for_region_clean, total_for_region_clean,
        region_code, parent_summary,
    )
    content = await _call_llm(f"area-analysis:{region_code}", system_prompt, user_prompt, llm)

    _logger.info("geo_analyzers.area.llm_response", region=region_code, content=content)

    findings: list[GeoFinding] = []
    parsed_items = _parse_json_list(content) if content else []
    _logger.info("geo_analyzers.area.parsed", region=region_code, item_count=len(parsed_items))
    if parsed_items:
        for item in parsed_items:
            _logger.info(
                "geo_analyzers.area.finding",
                region=region_code,
                area=item.get("area") or item.get("geo_code"),
                geo_code=item.get("geo_code"),
                at_risk_count=item.get("at_risk_count"),
                total_active=item.get("total_active"),
                at_risk_pct=item.get("at_risk_pct"),
                is_flagged=item.get("is_flagged"),
                summary=item.get("summary"),
            )
            if item.get("is_flagged"):
                gf = _to_geo_finding(item, "area", parent_geo_code=region_code)
                if gf:
                    findings.append(gf)

    _logger.info(
        "geo_analyzers.area.done",
        region=region_code,
        total_areas=len(parsed_items),
        flagged=len(findings),
    )
    return findings


async def analyze_area_node(state: AgentState) -> dict[str, Any]:
    """Flag anomalous areas for each flagged region — concurrent across regions.

    Skipped entirely for NAS, which has no area geographic level.
    """
    project: str | None = state.get("project")
    if project == "NAS":
        _logger.info("geo_analyzers.area.skipped", reason="NAS has no area level")
        return {"area_geo_findings": [], "area_analysis_json": []}

    category: RiskCategory = state["category"]
    business_context: str | None = state.get("business_context")
    region_findings: list[GeoFinding] = list(state.get("region_geo_findings") or [])
    region_agg: list[dict] = list(state.get("region_agg_results") or [])
    total_agg: list[dict] = list(state.get("total_active_results") or [])
    region_analysis_json: list[dict] = list(state.get("region_analysis_json") or [])
    all_site_rows: list[dict] = list(state.get("all_at_risk_site_rows") or [])

    flagged_regions = [f for f in region_findings if f.is_anomalous]
    _logger.info("geo_analyzers.area.start", flagged_regions=len(flagged_regions))

    if not flagged_regions:
        return {"area_geo_findings": [], "area_analysis_json": []}

    llm = build_llm("generator")
    all_area_findings_nested = await asyncio.gather(*[
        _analyze_areas_for_region(rf, category, business_context, region_agg, total_agg, region_analysis_json, all_site_rows, llm)
        for rf in flagged_regions
    ])

    all_area_findings: list[GeoFinding] = [gf for sublist in all_area_findings_nested for gf in sublist]

    # Build area_analysis_json from findings for downstream use
    area_analysis_json = [
        {
            "area": gf.geo_name,
            "geo_code": gf.geo_code,
            "parent_region_code": gf.parent_geo_code,
            "summary": gf.summary,
            "is_flagged": gf.is_anomalous,
        }
        for gf in all_area_findings
    ]

    _logger.info("geo_analyzers.area.all_done", total_flagged_areas=len(all_area_findings))
    return {"area_geo_findings": all_area_findings, "area_analysis_json": area_analysis_json}


# ===========================================================================
# Node 3: analyze_market_node
# ===========================================================================


async def _analyze_markets_for_area(
    area_finding: GeoFinding,
    category: RiskCategory,
    business_context: str | None,
    region_agg: list[dict],
    total_agg: list[dict],
    area_analysis_json: list[dict],
    all_site_rows: list[dict],
    llm: Any,
) -> list[GeoFinding]:
    """Analyze markets within one flagged area. Returns flagged GeoFinding list."""
    area_code = area_finding.geo_code

    # Filter raw rows to this area by value-matching (column name is unknown)
    agg_for_area = _filter_rows_by_value(region_agg, area_code)
    total_for_area = _filter_rows_by_value(total_agg, area_code)

    # Fallback: derive market-level counts from pre-fetched site rows
    if not agg_for_area and all_site_rows:
        area_site_rows = _filter_rows_by_geo_column(all_site_rows, area_code, "area")
        agg_for_area = _derive_agg_from_site_rows(area_site_rows, "market")
        _logger.info(
            "geo_analyzers.market.derived_agg_from_site_rows",
            area=area_code,
            derived_rows=len(agg_for_area),
            site_pool=len(area_site_rows),
        )

    if not agg_for_area:
        _logger.warning("geo_analyzers.market.no_data", area=area_code)
        return []

    parent_summary = area_finding.summary or ""

    # Pre-aggregate: one clean row per market, stripping extra AI-generated columns
    agg_for_area_clean = _sum_agg_by_geo(agg_for_area, "market", "at_risk_count")
    total_for_area_clean = _sum_agg_by_geo(total_for_area, "market", "total_active_count")

    _logger.info(
        "geo_analyzers.market.input_rows",
        area=area_code,
        raw_agg_rows=len(agg_for_area),
        clean_agg_rows=len(agg_for_area_clean),
        agg_sample=agg_for_area_clean[:3],
    )

    system_prompt, user_prompt = build_market_analysis_prompt(
        category, business_context,
        agg_for_area_clean, total_for_area_clean,
        area_code, parent_summary,
    )
    content = await _call_llm(f"market-analysis:{area_code}", system_prompt, user_prompt, llm)

    _logger.info("geo_analyzers.market.llm_response", area=area_code, content=content)

    findings: list[GeoFinding] = []
    parsed_items = _parse_json_list(content) if content else []
    _logger.info("geo_analyzers.market.parsed", area=area_code, item_count=len(parsed_items))
    if parsed_items:
        for item in parsed_items:
            _logger.info(
                "geo_analyzers.market.finding",
                area=area_code,
                market=item.get("market") or item.get("geo_code"),
                geo_code=item.get("geo_code"),
                at_risk_count=item.get("at_risk_count"),
                total_active=item.get("total_active"),
                at_risk_pct=item.get("at_risk_pct"),
                is_flagged=item.get("is_flagged"),
                summary=item.get("summary"),
            )
            if item.get("is_flagged"):
                gf = _to_geo_finding(item, "market", parent_geo_code=area_code)
                if gf:
                    findings.append(gf)

    _logger.info(
        "geo_analyzers.market.done",
        area=area_code,
        total_markets=len(parsed_items),
        flagged=len(findings),
    )
    return findings


async def analyze_market_node(state: AgentState) -> dict[str, Any]:
    """Flag anomalous markets for each flagged area (or region for NAS) — concurrent."""
    category: RiskCategory = state["category"]
    project: str | None = state.get("project")
    business_context: str | None = state.get("business_context")
    region_agg: list[dict] = list(state.get("region_agg_results") or [])
    total_agg: list[dict] = list(state.get("total_active_results") or [])
    all_site_rows: list[dict] = list(state.get("all_at_risk_site_rows") or [])

    if project == "NAS":
        # NAS has no area level — drive market analysis directly from flagged regions.
        # _analyze_markets_for_area works with any GeoFinding; passing a region finding
        # means the resulting market GeoFindings will have the region as parent_geo_code.
        region_findings: list[GeoFinding] = list(state.get("region_geo_findings") or [])
        flagged_parents = [f for f in region_findings if f.is_anomalous]
        _logger.info("geo_analyzers.market.start_nas", flagged_regions=len(flagged_parents))
    else:
        area_findings: list[GeoFinding] = list(state.get("area_geo_findings") or [])
        area_analysis_json: list[dict] = list(state.get("area_analysis_json") or [])
        flagged_parents = [f for f in area_findings if f.is_anomalous]
        _logger.info("geo_analyzers.market.start", flagged_areas=len(flagged_parents))

    if not flagged_parents:
        return {"market_geo_findings": []}

    area_analysis_json = [] if project == "NAS" else list(state.get("area_analysis_json") or [])

    llm = build_llm("generator")
    all_market_findings_nested = await asyncio.gather(*[
        _analyze_markets_for_area(pf, category, business_context, region_agg, total_agg, area_analysis_json, all_site_rows, llm)
        for pf in flagged_parents
    ])

    all_market_findings: list[GeoFinding] = [gf for sublist in all_market_findings_nested for gf in sublist]
    _logger.info("geo_analyzers.market.all_done", total_flagged_markets=len(all_market_findings))
    return {"market_geo_findings": all_market_findings}


# ===========================================================================
# Node 4: analyze_site_node
# ===========================================================================


async def _analyze_site_for_market(
    market_finding: GeoFinding,
    category: RiskCategory,
    business_context: str | None,
    project: str | None,
    total_agg: list[dict],
    site_sql: str,
    market_col: str | None,
    llm: Any,
) -> tuple[StepResult | None, dict[str, dict], str]:
    """Fetch at-risk site rows for this market from DB, enrich milestones, run LLM analysis.

    Fetches directly from the site SQL validated by plan_steps_node, filtered to this
    market only.  market_col is the detected column name from a sample row — if None,
    all rows are fetched and filtered in Python (fallback).

    Returns (StepResult_or_None, site_milestones_for_this_market).
    """
    market_code = market_finding.geo_code
    market_name = market_finding.geo_name

    started_at = datetime.now(UTC)
    started_ts = time.perf_counter()

    # Build market-filtered base SQL. Double-quote the column name to handle aliases
    # with spaces or mixed case (e.g. "Market", "m_market").
    safe_market_code = market_code.replace("'", "''")
    if market_col:
        base_sql = f'SELECT * FROM ({site_sql}) _mkt WHERE "{market_col}" = \'{safe_market_code}\''
    else:
        base_sql = f"SELECT * FROM ({site_sql}) _mkt"

    site_rows: list[dict] = []
    offset = 0
    while True:
        batch_sql = f"{base_sql} LIMIT {_SITE_BATCH_SIZE} OFFSET {offset}"
        try:
            batch = await fetch_all(batch_sql, {})
        except Exception as exc:
            _logger.warning("geo_analyzers.site.fetch_failed", market=market_code, offset=offset, error=str(exc))
            break
        site_rows.extend(batch)
        if len(batch) < _SITE_BATCH_SIZE:
            break
        offset += _SITE_BATCH_SIZE

    if not market_col:
        site_rows = _filter_rows_by_geo_column(site_rows, market_code, "market")

    _logger.info(
        "geo_analyzers.site.fetched",
        market=market_code,
        row_count=len(site_rows),
        market_col=market_col,
    )

    if not site_rows:
        _logger.warning("geo_analyzers.site.no_rows", market=market_code)
        return None, {}, ""

    # Step C: get total active count for this market from cached total_agg.
    # Use _sum_agg_by_geo to resolve the count column reliably (looks for
    # 'total_active_count' alias first, then any column containing 'count').
    market_total_rows = _filter_rows_by_value(total_agg, market_code)
    market_total_clean = _sum_agg_by_geo(market_total_rows, "market", "total_active_count")
    total_active = sum(r.get("total_active_count", 0) for r in market_total_clean)

    # Step D: inline milestone enrichment
    site_milestones_for_market: dict[str, dict] = {}
    if site_rows:
        site_milestones_for_market = await _enrich_milestones_for_rows(site_rows, project)
        _logger.info(
            "geo_analyzers.site.milestones",
            market=market_code,
            sites=len(site_rows),
            enriched=len(site_milestones_for_market),
        )

    # Step E: LLM site analysis — cap rows sent to LLM; all rows kept for drill-down
    llm_rows = site_rows[:_LLM_SITE_CAP]
    _logger.info(
        "geo_analyzers.site.llm_cap",
        market=market_code,
        total_rows=len(site_rows),
        llm_rows=len(llm_rows),
    )
    market_summary = await _analyze_market_sites(
        market_name=market_name,
        rows=llm_rows,
        category=category,
        llm=llm,
        business_context=business_context,
        site_milestones=site_milestones_for_market,
        project=project,
        total_active=total_active,
        at_risk_total=len(site_rows),
    )
    _logger.info("geo_analyzers.site.analyzed", market=market_code, summary_len=len(market_summary))

    finished_at = datetime.now(UTC)
    duration_ms = (time.perf_counter() - started_ts) * 1000

    step_result = StepResult(
        step_id=uuid4(),
        step_name=f"Site-level: {market_name} ({market_code})",
        source=StepSource.SEMANTIC_KPI,
        status=StepStatus.SUCCESS,
        rows=site_rows,       # all rows → drill-down tables
        row_count=len(site_rows),
        executed_sql=base_sql,
        started_at=started_at,
        finished_at=finished_at,
        duration_ms=round(duration_ms, 2),
    )
    return step_result, site_milestones_for_market, market_summary


async def analyze_site_node(state: AgentState) -> dict[str, Any]:
    """Run LLM site analysis per flagged market — fetches site rows from DB per market."""
    category: RiskCategory = state["category"]
    business_context: str | None = state.get("business_context")
    project: str | None = state.get("project")
    market_findings: list[GeoFinding] = list(state.get("market_geo_findings") or [])
    total_agg: list[dict] = list(state.get("total_active_results") or [])
    planned_steps = list(state.get("planned_steps") or [])
    site_sql: str | None = planned_steps[0].sql_query if planned_steps else None

    flagged_markets = [f for f in market_findings if f.is_anomalous]
    _logger.info(
        "geo_analyzers.site.start",
        flagged_markets=len(flagged_markets),
    )

    if not flagged_markets:
        return {"excel_site_step_results": [], "site_milestones": {}, "market_site_summaries": {}}

    if not site_sql:
        _logger.warning("geo_analyzers.site.no_sql", hint="plan_steps_node may have failed")
        return {"excel_site_step_results": [], "site_milestones": {}, "market_site_summaries": {}}

    # Detect market column name from one sample row so per-market SQL filters correctly.
    market_col: str | None = None
    try:
        sample = await fetch_all(f"SELECT * FROM ({site_sql}) _sample LIMIT 1", {})
        if sample:
            market_col = _find_geo_column(sample, "market")
    except Exception as exc:
        _logger.warning("geo_analyzers.site.sample_failed", error=str(exc))
    _logger.info("geo_analyzers.site.market_col_detected", market_col=market_col)

    llm = build_llm("generator")

    results = await asyncio.gather(*[
        _analyze_site_for_market(mf, category, business_context, project, total_agg, site_sql, market_col, llm)
        for mf in flagged_markets
    ])

    site_results: list[StepResult] = []
    all_milestones: dict[str, dict] = {}
    market_summaries: dict[str, str] = {}

    for step_result, market_milestones, market_summary in results:
        if step_result is not None:
            site_results.append(step_result)
            if market_summary:
                market_summaries[step_result.step_name] = market_summary
        all_milestones.update(market_milestones)

    _logger.info(
        "geo_analyzers.site.all_done",
        markets_processed=len(flagged_markets),
        successful=len(site_results),
        milestones_enriched=len(all_milestones),
        market_summaries_stored=len(market_summaries),
    )
    return {
        "excel_site_step_results": site_results,
        "site_milestones": all_milestones,
        "market_site_summaries": market_summaries,
    }
