"""Geo SQL Generator Agent.

Receives the risk category, table schema, and already-validated flat steps
and asks the LLM to produce 4 parameterised SQL templates:

  region_sql  — no parameters; aggregates all regions in one query
  area_sql    — parameterised: WHERE rgn_region = :region
  market_sql  — parameterised: WHERE m_area = :area
  site_sql    — parameterised: WHERE m_market = :market; individual rows

All 4 templates are validated via validate_sql() before being stored.
If generation or validation fails, geo_sqls is set to None so downstream
geo analyzer nodes skip gracefully.
"""

from __future__ import annotations

import time
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage

from risk_agent.agents._formatting import format_rules, format_step_results
from risk_agent.agents.planner import _mandatory_filter_hint
from risk_agent.config import get_settings
from risk_agent.core.json_parsing import parse_llm_json
from risk_agent.core.llm import build_llm
from risk_agent.db import load_target_table_schema
from risk_agent.models import AgentState, RiskCategory, TraversalStep
from risk_agent.prompts.geo_prompts import build_geo_sql_prompt
from risk_agent.utils.logging import get_logger
from risk_agent.utils.metrics import llm_calls_total, llm_duration_seconds
from risk_agent.utils.sql_safety import validate_sql

_logger = get_logger(__name__)

_GEO_SQL_KEYS = ("region_sql", "area_sql", "market_sql", "site_sql")


def _format_steps_for_geo_prompt(steps: list[TraversalStep]) -> str:
    """Render step names, rationales, and reference SQL for geo SQL generation.

    Including the actual SQL (truncated) lets the geo SQL generator reuse
    the same WHERE conditions for site_sql instead of guessing column names.
    """
    if not steps:
        return "(none)"
    lines: list[str] = []
    for step in steps:
        lines.append(f"- {step.name}: {step.rationale}")
        if step.sql_query:
            sql_preview = step.sql_query[:600].strip()
            if len(step.sql_query) > 600:
                sql_preview += "\n  ... (truncated)"
            lines.append(
                f"  Reference SQL (adapt the WHERE conditions for site_sql):\n"
                + "\n".join(f"  {line}" for line in sql_preview.splitlines())
            )
    return "\n".join(lines)


async def generate_geo_sql_node(state: AgentState) -> dict[str, Any]:
    """LangGraph node: generate 4 parameterised geo SQL templates.

    Reads:  category, business_context, validated_planned_steps (or planned_steps)
    Writes: geo_sqls  — dict with keys region_sql / area_sql / market_sql / site_sql
                        or None if generation / validation failed.
    """
    category: RiskCategory = state["category"]
    business_context: str | None = state.get("business_context")
    project: str | None = state.get("project")
    steps: list[TraversalStep] = list(
        state.get("validated_planned_steps") or state.get("planned_steps") or []
    )

    _logger.info(
        "geo_sql_gen.start",
        category_id=category.category_id,
        step_hint_count=len(steps),
    )

    # Load target table schema (same as planner uses).
    try:
        schema = await load_target_table_schema()
        if schema.is_empty:
            _logger.warning("geo_sql_gen.schema_empty")
            return {"geo_sqls": None}
        table_fqn = schema.tables[0].qualified_name
        schema_text = schema.to_prompt()
    except Exception as exc:
        _logger.warning("geo_sql_gen.schema_load_failed", error=str(exc))
        return {"geo_sqls": None}

    steps_text = _format_steps_for_geo_prompt(steps)
    system_prompt, user_prompt = build_geo_sql_prompt(
        category=category,
        business_context=business_context,
        table_schema=schema_text,
        table_fqn=table_fqn,
        validated_steps_text=steps_text,
        mandatory_filter=_mandatory_filter_hint(project),
    )

    llm = build_llm("planner")
    messages = [
        SystemMessage(content=system_prompt),
        HumanMessage(content=user_prompt),
    ]

    started = time.perf_counter()
    try:
        response = await llm.ainvoke(messages)
    except Exception as exc:
        elapsed = time.perf_counter() - started
        llm_duration_seconds.labels(agent="planner").observe(elapsed)
        llm_calls_total.labels(agent="planner", status="failed").inc()
        _logger.warning("geo_sql_gen.llm.failed", error=str(exc))
        return {"geo_sqls": None}

    elapsed = time.perf_counter() - started
    llm_duration_seconds.labels(agent="planner").observe(elapsed)
    llm_calls_total.labels(agent="planner", status="success").inc()

    raw_content = (
        response.content if isinstance(response.content, str) else str(response.content)
    )

    try:
        parsed = parse_llm_json(raw_content)
    except Exception as exc:
        _logger.warning("geo_sql_gen.parse.failed", error=str(exc))
        return {"geo_sqls": None}

    # Validate all 4 SQL strings.
    geo_sqls: dict[str, str] = {}
    for key in _GEO_SQL_KEYS:
        sql = parsed.get(key, "")
        if not sql:
            _logger.warning("geo_sql_gen.missing_key", key=key)
            return {"geo_sqls": None}
        try:
            geo_sqls[key] = validate_sql(str(sql))
        except Exception as exc:
            _logger.warning(
                "geo_sql_gen.sql_invalid",
                key=key,
                error=str(exc),
                sql_preview=str(sql)[:200],
            )
            return {"geo_sqls": None}

    _logger.info(
        "geo_sql_gen.done",
        category_id=category.category_id,
        duration_ms=round(elapsed * 1000, 2),
        keys=list(geo_sqls.keys()),
    )
    return {"geo_sqls": geo_sqls}
