"""Shared prompt-rendering helpers used by multiple agent nodes."""

from __future__ import annotations

from risk_agent.models import StepResult

_MAX_ROWS_IN_PROMPT = 25


def format_step_results(
    results: list[StepResult],
    max_rows_in_prompt: int = _MAX_ROWS_IN_PROMPT,
) -> str:
    """Render step results as a compact text block for an LLM prompt."""
    if not results:
        return "(no step results)"

    blocks: list[str] = []
    for r in results:
        sample = r.rows[:max_rows_in_prompt]
        blocks.append(
            "\n".join(
                [
                    f"--- Step: {r.step_name}",
                    f"    step_id: {r.step_id}",
                    f"    source: {r.source.value}",
                    f"    status: {r.status.value}",
                    f"    row_count: {r.row_count}",
                    f"    related_kpi: {r.related_kpi or 'n/a'}",
                    f"    error: {r.error or 'none'}",
                    f"    sample_rows: {sample}",
                ]
            )
        )
    return "\n\n".join(blocks)


def format_rules(rules: list[str]) -> str:
    """Render decision rules as a bulleted list."""
    return "\n".join(f"- {r}" for r in rules) if rules else "(none)"
