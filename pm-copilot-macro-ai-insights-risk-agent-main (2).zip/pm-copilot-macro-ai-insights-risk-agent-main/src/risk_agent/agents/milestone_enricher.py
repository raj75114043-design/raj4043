"""Milestone Enrichment Node.

After analyze_site_node identifies flagged sites, this node calls the
project milestone API (Knowledge graph API) for each site concurrently and stores the full
p1–p13 phase timeline in state.

The milestone data is later formatted into the risk identification prompt
so the generator can distinguish live blockages from data entry gaps.

Project-specific identifier:
  NTM   → pj_project_id
  AHLOA → s_site_id
  NAS   → s_site_id
"""

from __future__ import annotations

import asyncio
from typing import Any

import httpx

from risk_agent.config import get_settings
from risk_agent.models import AgentState, StepResult
from risk_agent.utils.logging import get_logger

_logger = get_logger(__name__)

_TIMEOUT = 15
_MAX_CONCURRENT = 20


def _get_site_identifier(row: dict[str, Any], project: str | None) -> str | None:
    """Return the correct API identifier based on project type."""
    if project == "NTM":
        return row.get("pj_project_id") or row.get("project_id")
    return row.get("s_site_id") or row.get("site_id")


def _collect_identifiers(
    site_results: list[StepResult],
    project: str | None,
) -> list[str]:
    """Extract unique non-null site/project identifiers from all site step rows."""
    seen: set[str] = set()
    ids: list[str] = []
    for result in site_results:
        for row in result.rows:
            sid = _get_site_identifier(row, project)
            if sid and str(sid) not in seen:
                seen.add(str(sid))
                ids.append(str(sid))
    return ids


async def _fetch_milestone(
    identifier: str,
    base_url: str,
    client: httpx.AsyncClient,
) -> tuple[str, dict[str, Any] | None]:
    """Fetch milestone data for one site/project. Returns (identifier, data_or_None)."""
    url = f"{base_url.rstrip('/')}/{identifier}"
    try:
        resp = await client.get(url, headers={"accept": "application/json"})
        resp.raise_for_status()
        return identifier, resp.json()
    except httpx.HTTPStatusError as exc:
        _logger.warning(
            "milestone_enricher.http_error",
            identifier=identifier,
            status=exc.response.status_code,
        )
        return identifier, None
    except Exception as exc:
        _logger.warning(
            "milestone_enricher.fetch_failed",
            identifier=identifier,
            error=str(exc),
        )
        return identifier, None


def _phase_summary(milestone: dict[str, Any]) -> str:
    """Format a single site's milestone dict into a compact prompt block."""
    lines: list[str] = []

    site_id = milestone.get("site_id") or milestone.get("s_site_id") or "?"
    project_id = milestone.get("project_id") or milestone.get("pj_project_id") or "?"
    region = milestone.get("region") or "?"
    area = milestone.get("area") or "?"
    market = milestone.get("market") or "?"
    gc = milestone.get("p2_gc") or "?"
    status = milestone.get("project_status") or "?"

    lines.append(
        f"Site: {site_id} | project_id: {project_id} | {region} / {area} / {market}"
        f" | GC: {gc} | status: {status}"
    )

    # Phase key groups — label, pairs of (planned_key, actual_key, display_name)
    phase_milestones = [
        # P2 pre-con
        ("p2_pre_ntp_planned",              "p2_pre_ntp_actual",              "P2 Pre-NTP"),
        ("p2_gc_selected_planned",          "p2_gc_selected_actual",          "P2 GC Selected"),
        # P3 scoping
        ("p3_survey_complete_planned",      "p3_survey_complete_actual",      "P3 Survey Complete"),
        # P4 quoting
        ("p4_bid_walk_planned",             "p4_bid_walk_actual",             "P4 Bid Walk"),
        ("p4_sp_submitted_actual",          None,                             "P4 SP Submitted"),
        # P5 NTP
        ("p5_civil_ntp_submitted_planned",  "p5_civil_ntp_submitted_actual",  "P5 Civil NTP Submitted"),
        ("p5_civil_ntp_accepted_planned",   "p5_civil_ntp_accepted_actual",   "P5 Civil NTP Accepted"),
        ("p5_tower_ntp_submitted_planned",  "p5_tower_ntp_submitted_actual",  "P5 Tower NTP Submitted"),
        ("p5_tower_ntp_accepted_planned",   "p5_tower_ntp_accepted_actual",   "P5 Tower NTP Accepted"),
        ("p5_tower_ntp_validated_actual",   None,                             "P5 Tower NTP Validated"),
        # P6 materials
        ("p6_bom_aims_planned",             "p6_bom_aims_actual",             "P6 BOM AIMS"),
        ("p6_material_arrived_planned",     "p6_material_arrived_actual",     "P6 Material Arrived"),
        ("p6_material_pickup_planned",      "p6_material_pickup_actual",      "P6 Material Pickup"),
        # P8 SPO/PO
        ("p8_construction_po_planned",      "p8_construction_po_actual",      "P8 Construction PO"),
        # P9 civil construction
        ("p9_civil_start_planned",          "p9_civil_start_actual",          "P9 Civil Start"),
        ("p9_civil_complete_planned",       "p9_civil_complete_actual",       "P9 Civil Complete"),
        ("p9_power_installed_planned",      "p9_power_installed_actual",      "P9 Power Installed"),
        # P10 tower construction
        ("p10_tower_start_planned",         "p10_tower_start_actual",         "P10 Tower Start"),
        ("p10_tower_complete_planned",      "p10_tower_complete_actual",      "P10 Tower Complete"),
        # P11 integration
        ("p11_integration_start_planned",   "p11_integration_start_actual",   "P11 Integration Start"),
        ("p11_integration_complete_planned","p11_integration_complete_actual", "P11 Integration Complete"),
        ("p11_scf_validated_actual",        None,                             "P11 SCF Validated"),
        # P12 on-air
        ("p12_gsm_onair_actual",            None,                             "P12 GSM On-Air"),
    ]

    for planned_key, actual_key, label in phase_milestones:
        planned = milestone.get(planned_key) if planned_key else None
        actual = milestone.get(actual_key) if actual_key else None

        # Skip if both are null — milestone not applicable for this site
        if planned is None and actual is None:
            continue

        planned_str = str(planned)[:10] if planned else "—"
        actual_str = str(actual)[:10] if actual else "NULL ←"
        if actual_key is None:
            # Single-value field (no planned counterpart)
            lines.append(f"  {label}: {actual_str}")
        else:
            gap = ""
            if planned and not actual:
                gap = " [MISSING]"
            lines.append(f"  {label}: planned={planned_str}, actual={actual_str}{gap}")

    # P8 SPO details — high value for PM
    spo_fields = [
        ("p8_civil_spo",      "p8_civil_spo_issued_date",  "Civil SPO"),
        ("p8_tower_spo",      "p8_tower_spo_issued_date",  "Tower SPO"),
        ("p8_integration_spo", None,                        "Integration SPO"),
        ("p8_cop_spo",        "p8_cop_spo_issued_date",    "COP SPO"),
    ]
    spo_lines: list[str] = []
    for spo_key, date_key, spo_label in spo_fields:
        spo_val = milestone.get(spo_key)
        if spo_val:
            issued = milestone.get(date_key)[:10] if (date_key and milestone.get(date_key)) else "?"
            spo_lines.append(f"{spo_label}: {spo_val} (issued {issued})")
    if spo_lines:
        lines.append(f"  P8 SPOs: {' | '.join(spo_lines)}")

    # P10 delay codes
    delay_code = milestone.get("p10_start_delay_code")
    delay_comment = milestone.get("p10_complete_delay_comments") or milestone.get("p10_start_delay_comments")
    if delay_code and delay_code not in ("No Delay", "nan", "null"):
        lines.append(f"  P10 Delay code: {delay_code}")
    if delay_comment and str(delay_comment) not in ("nan", "null", "None"):
        lines.append(f"  P10 Delay comment: {delay_comment}")

    # HSE summary
    hse_visits = milestone.get("hse_visits")
    if hse_visits and isinstance(hse_visits, list) and hse_visits:
        latest = hse_visits[-1]
        ppe = latest.get("ppe_validation", "?")
        jsa = latest.get("jsa_completion_status", "?")
        non_comp = latest.get("revisit_non_compliance_category")
        hse_str = f"  HSE: {len(hse_visits)} visits, last PPE={ppe}, JSA={jsa}"
        if non_comp:
            hse_str += f", non-compliance: {non_comp}"
        lines.append(hse_str)

    return "\n".join(lines)


_MAX_MILESTONE_SITES_IN_PROMPT = 100


def _issue_score(milestone: dict[str, Any]) -> int:
    """Score a site by number of actionable problems. Higher = more important to include."""
    score = 0
    summary = _phase_summary(milestone)
    score += summary.count("[MISSING]")
    delay_code = milestone.get("p10_start_delay_code")
    if delay_code and delay_code not in ("No Delay", "nan", "null"):
        score += 2
    hse_visits = milestone.get("hse_visits")
    if isinstance(hse_visits, list):
        for v in hse_visits:
            if v.get("revisit_non_compliance_category"):
                score += 1
                break
    return score


def format_milestones_for_prompt(site_milestones: dict[str, dict[str, Any]]) -> str:
    """Format milestone data into a prompt section, capped to the most problematic sites."""
    if not site_milestones:
        return ""

    total = len(site_milestones)
    # Sort by issue score descending, then cap to avoid token overflow.
    scored = sorted(
        site_milestones.items(),
        key=lambda kv: _issue_score(kv[1]),
        reverse=True,
    )
    selected = scored[:_MAX_MILESTONE_SITES_IN_PROMPT]

    lines = [
        "=== Per-Site Milestone Timelines (from project status API) ===",
        "Use these to distinguish live blockages from data-entry gaps,",
        "and to trace which upstream phase is the root cause.",
        f"Showing {len(selected)} of {total} sites (highest-issue sites prioritised).",
        "",
    ]
    for _, milestone in selected:
        lines.append(_phase_summary(milestone))
        lines.append("")

    return "\n".join(lines)


async def enrich_milestones_node(state: AgentState) -> dict[str, Any]:
    """LangGraph node: fetch per-site milestone timelines for all flagged sites.

    Reads:  excel_site_step_results, project
    Writes: site_milestones — dict[identifier, milestone_dict]
            or empty dict if no sites were flagged or API is unreachable.
    """
    site_results: list[StepResult] = list(state.get("excel_site_step_results") or [])
    project: str | None = state.get("project")

    if not site_results:
        _logger.info("milestone_enricher.skipped", reason="no site results to enrich")
        return {"site_milestones": {}}

    identifiers = _collect_identifiers(site_results, project)
    if not identifiers:
        _logger.warning(
            "milestone_enricher.no_identifiers",
            project=project,
            hint="Rows may be missing s_site_id / pj_project_id columns",
        )
        return {"site_milestones": {}}

    settings = get_settings().agent
    if project == "AHLOA":
        base_url = settings.ahloa_milestone_api_url
    elif project == "NAS":
        base_url = settings.nas_milestone_api_url
    else:
        base_url = settings.milestone_api_url
    _logger.info(
        "milestone_enricher.start",
        project=project,
        site_count=len(identifiers),
        base_url=base_url,
    )

    semaphore = asyncio.Semaphore(_MAX_CONCURRENT)

    async def _bounded_fetch(sid: str, client: httpx.AsyncClient) -> tuple[str, dict | None]:
        async with semaphore:
            return await _fetch_milestone(sid, base_url, client)

    async with httpx.AsyncClient(timeout=_TIMEOUT, follow_redirects=True) as client:
        results = await asyncio.gather(
            *[_bounded_fetch(sid, client) for sid in identifiers],
            return_exceptions=False,
        )

    site_milestones: dict[str, dict[str, Any]] = {
        sid: data
        for sid, data in results
        if data is not None
    }

    _logger.info(
        "milestone_enricher.done",
        requested=len(identifiers),
        fetched=len(site_milestones),
        failed=len(identifiers) - len(site_milestones),
    )

    return {"site_milestones": site_milestones}
