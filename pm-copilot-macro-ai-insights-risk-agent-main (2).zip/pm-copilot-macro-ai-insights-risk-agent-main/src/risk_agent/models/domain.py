"""Domain models for the Risk Identification Agent.

These are the data contracts that flow through the LangGraph state machine
and between the agents. All are Pydantic v2 models for strict validation.
"""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field

# --------------------------------------------------------------------------- #
# Enumerations
# --------------------------------------------------------------------------- #


class StepSource(str, Enum):
    """Origin of a traversal step."""

    SEMANTIC_KPI = "semantic_kpi"
    EXCEL_RULE = "excel_rule"


class StepStatus(str, Enum):
    """Execution status of a single traversal step."""

    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"
    SKIPPED = "skipped"


class RiskSeverity(str, Enum):
    """Severity level attached to a risk finding."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFORMATIONAL = "informational"


class RiskLikelihood(str, Enum):
    """Likelihood of a risk materializing."""

    UNLIKELY = "unlikely"
    MAY_HAPPEN = "may_happen"
    LIKELY = "likely"


class RiskImpact(str, Enum):
    """Impact magnitude if risk materializes."""

    LOW = "minor"
    MEDIUM = "major"
    HIGH = "critical"


class RiskRating(str, Enum):
    """Overall risk rating derived from likelihood × impact.
    
    Matrix:
    ┌──────────┬──────────┬─────────┬─────────┐
    │          │ Low      │ Medium  │ High    │
    ├──────────┼──────────┼─────────┼─────────┤
    │ Unlikely │ Low      │ Low     │ Medium  │
    │ MayHapp. │ Low      │ Medium  │ High    │
    │ Likely   │ Medium   │ High    │ Critical│
    └──────────┴──────────┴─────────┴─────────┘
    """

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


# --------------------------------------------------------------------------- #
# Input: Risk category definition from Excel
# --------------------------------------------------------------------------- #


class RiskCategory(BaseModel):
    """A single risk category definition loaded from the Excel catalog.

    The Excel sheet holds one row per risk category; each row includes:
    - natural-language description of the risk
    - NL-form logic used to flag the risk (translated later into SQL)
    - decision rules (thresholds / severity mappings)
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    category_id: str = Field(..., description="Stable identifier, e.g. 'RISK_NDPD_001'")
    name: str = Field(..., description="Human-readable risk name")
    description: str = Field(..., description="Natural language description of the risk")
    identification_logic: str = Field(
        ..., description="Natural-language logic to identify the risk"
    )
    decision_rules: list[str] = Field(
        default_factory=list,
        description="Rules used to evaluate severity and trigger mitigation",
    )
    owner: str | None = Field(default=None, description="Business owner / team")
    tags: list[str] = Field(default_factory=list)


# --------------------------------------------------------------------------- #
# Semantic API response contract
# --------------------------------------------------------------------------- #


class SemanticResultContent(BaseModel):
    """Content block returned by the semantic API for a single hit."""

    model_config = ConfigDict(extra="allow")

    rca_question: str | None = None
    root_causes: list[str] = Field(default_factory=list)
    problem_id: str | None = None
    root_cause_sudo_sql_schema: str | None = None
    steps_to_get_data_sql: list[str] = Field(default_factory=list)
    output_preferred_template: str | None = None
    created_at: str | None = None
    type_of_rca_question: str | None = None
    relevant_kpis: str | None = None
    recommendation_area: str | None = None
    updated_at: str | None = None


class SemanticResult(BaseModel):
    """A single result item from the semantic context API."""

    model_config = ConfigDict(extra="allow")

    table: str
    id: int
    content: SemanticResultContent
    similarity_score: float = Field(..., ge=0.0, le=1.0)


class SemanticResponse(BaseModel):
    """Full response envelope from the semantic context API."""

    model_config = ConfigDict(extra="allow")

    query: str
    total_results: int
    results: list[SemanticResult] = Field(default_factory=list)


# --------------------------------------------------------------------------- #
# Traversal step
# --------------------------------------------------------------------------- #


class TraversalStep(BaseModel):
    """A single, independently-executable step planned by the Planner Agent.

    Each step carries a SQL query that will be executed in parallel against
    the Postgres risk database. The Risk Identification Agent later combines all results.
    """

    model_config = ConfigDict(extra="forbid")

    step_id: UUID = Field(default_factory=uuid4)
    source: StepSource
    name: str = Field(..., description="Human-readable step title")
    rationale: str = Field(..., description="Why this step is relevant to the risk")
    sql_query: str = Field(..., description="Parameterized SQL to execute on Postgres")
    parameters: dict[str, Any] = Field(default_factory=dict)
    expected_columns: list[str] = Field(
        default_factory=list,
        description="Columns the executor expects in the result set",
    )
    related_kpi: str | None = Field(
        default=None, description="KPI label from semantic API if SEMANTIC_KPI step"
    )
    source_reference: str | None = Field(
        default=None,
        description="Pointer back to the originating rule or semantic hit id",
    )


class StepResult(BaseModel):
    """Outcome of executing a single TraversalStep."""

    model_config = ConfigDict(extra="forbid")

    step_id: UUID
    step_name: str
    source: StepSource
    status: StepStatus
    rows: list[dict[str, Any]] = Field(default_factory=list)
    row_count: int = 0
    total_eligible_count: int | None = None
    executed_sql: str | None = None
    error: str | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    duration_ms: float | None = None
    related_kpi: str | None = None


class GeoFinding(BaseModel):
    """An anomalous geographic unit identified by the Excel pipeline's geo analyzers."""

    model_config = ConfigDict(extra="ignore")

    geo_level: str                   # "region" | "area" | "market"
    geo_code: str                    # value used as SQL filter parameter
    geo_name: str                    # display name
    parent_geo_code: str | None = None
    is_anomalous: bool = True
    metric_name: str                 # specific metric/column driving the finding
    summary: str                     # 1-2 sentence plain-English description
    sample_rows: list[dict[str, Any]] = Field(default_factory=list)
    category_name: str | None = None


# --------------------------------------------------------------------------- #
# Risk finding (output)
# --------------------------------------------------------------------------- #


class RiskEvidence(BaseModel):
    """Evidence attached to a risk finding — which step surfaced which rows."""

    model_config = ConfigDict(extra="forbid")

    step_id: UUID
    step_name: str
    source: StepSource
    sample_rows: list[dict[str, Any]] = Field(default_factory=list, max_length=10)
    row_count: int = 0
    related_kpi: str | None = None


class RiskFinding(BaseModel):
    """A single risk surfaced by the Risk Identification Agent.

    The schema is the stable contract consumed by downstream UIs. It now
    carries both the legacy analytical fields (severity / confidence /
    impact_summary / recommended_actions) AND the newer business-facing
    fields (risk / root_cause / mitigation_actions / recovery_plan /
    drill_down_tables). They coexist so we don't break existing dashboards
    while we roll out the new ones.
    """

    model_config = ConfigDict(extra="forbid")

    finding_id: UUID = Field(default_factory=uuid4)
    category_id: str

    # Core narrative fields — these are the "new schema" fields.
    risk: str = Field(..., description="Short label of the identified risk")
    description: str = Field(..., description="What the risk is, in business language")
    root_cause: str = Field(
        default="",
        description="Why the risk exists, derived from the step evidence",
    )
    mitigation_actions: list[str] = Field(
        default_factory=list,
        description="Concrete steps to reduce or prevent the risk",
    )
    recovery_plan: list[str] = Field(
        default_factory=list,
        description="Ordered steps to recover once the risk materializes",
    )
    drill_down_tables: list[dict[str, Any]] = Field(
        default_factory=list,
        description=(
            "List of tabular JSON blocks that let a dashboard drill into the "
            "underlying evidence. Shape: "
            '{"title": str, "columns": [str], "rows": [[...]], "source_step_id": str}'
        ),
    )

    # Legacy analytical fields — kept for back-compat.
    title: str = Field(
        default="",
        description="Back-compat alias of `risk`; kept so existing consumers don't break",
    )
    severity: RiskSeverity = RiskSeverity.INFORMATIONAL
    confidence: float = Field(default=0.5, ge=0.0, le=1.0)
    impact_summary: str = Field(default="")
    recommended_actions: list[str] = Field(default_factory=list)

    # Risk Assessment Matrix fields — likelihood × impact → risk_rating
    likelihood: RiskLikelihood = Field(
        default=RiskLikelihood.MAY_HAPPEN,
        description="Likelihood of the risk materializing: unlikely | may_happen | likely",
    )
    impact: RiskImpact = Field(
        default=RiskImpact.MEDIUM,
        description="Impact magnitude if the risk materializes: minor | major | critical",
    )
    risk_rating: RiskRating = Field(
        default=RiskRating.MEDIUM,
        description=(
            "Overall risk rating derived from likelihood × impact matrix. "
            "Automatically calculated; set in LLM prompt."
        ),
    )

    evidence: list[RiskEvidence] = Field(default_factory=list)
    detected_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC)
    )

    # Geographic context — populated by the KPI trend pipeline.
    region: str | None = Field(
        default=None,
        description="Region where the risk was identified (KPI trend pipeline only)",
    )
    project: str | None = Field(
        default=None,
        description="Project (AHLOA / NTM / NAS) this finding belongs to (KPI trend pipeline only)",
    )
    impacted_sites_count: int | None = Field(
        default=None,
        description="Total number of impacted sites surfaced by site-level queries for this finding",
    )
    area_tags: list[str] = Field(
        default_factory=list,
        description="All impacted area names for this finding — used for API filtering",
    )
    market_tags: list[str] = Field(
        default_factory=list,
        description="All impacted market names for this finding — used for API filtering",
    )


class RiskReport(BaseModel):
    """Top-level report emitted after one category is fully processed."""

    model_config = ConfigDict(extra="forbid")

    report_id: UUID = Field(default_factory=uuid4)
    category: RiskCategory
    findings: list[RiskFinding] = Field(default_factory=list)
    steps_planned: int = 0
    steps_succeeded: int = 0
    steps_failed: int = 0
    total_rows_examined: int = 0
    started_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC)
    )
    finished_at: datetime | None = None
    duration_ms: float | None = None
    summary: str | None = None

    @property
    def has_risks(self) -> bool:
        return len(self.findings) > 0
