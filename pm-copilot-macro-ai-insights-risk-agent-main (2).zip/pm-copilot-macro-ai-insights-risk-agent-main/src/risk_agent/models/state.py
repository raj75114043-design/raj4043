"""LangGraph shared state schema.

Every node in the graph reads from and writes to this state. Keys that
are lists use `Annotated[..., operator.add]` so that parallel nodes
(via `Send`) can append their results concurrently without conflicts.
"""

from __future__ import annotations

import operator
from typing import Annotated, TypedDict

from risk_agent.models.domain import (
    GeoFinding,
    RiskCategory,
    RiskFinding,
    SemanticResponse,
    StepResult,
    TraversalStep,
)


class AgentState(TypedDict, total=False):
    """Shared state passed between LangGraph nodes.

    Lists that are written from multiple parallel branches use the
    `operator.add` reducer so LangGraph concatenates them automatically.
    """

    # --------- Input ---------
    category: RiskCategory

    # --------- Planner outputs ---------
    # `semantic_response` carries the KPI table hits (kept for back-compat
    # with downstream code that already reads it). `keywords_response` and
    # `question_bank_response` carry the two additional semantic sources
    # the planner consumes for richer grounding.
    semantic_response: SemanticResponse | None
    keywords_response: SemanticResponse | None
    question_bank_response: SemanticResponse | None
    planned_steps: list[TraversalStep]

    # --------- Parallel executor outputs ---------
    # Each executor node returns a single StepResult which is appended.
    step_results: Annotated[list[StepResult], operator.add]

    # --------- Validation outputs ---------
    validated_planned_steps: list[TraversalStep]   # steps that passed validate_plan_node
    validated_step_results: list[StepResult]        # kept for back-compat (old validation path)
    validation_notes: list[str]

    # --------- NL→SQL API outputs (Excel pipeline) ---------
    nl_sql_keyword_names: list[str]                # keyword names from parallel_search_output
    nl_sql_kpi_names: list[str]                    # KPI names from parallel_search_output

    # --------- Project / business context (Excel pipeline) ---------
    project: str | None                            # "AHLOA" | "NTM" | "NAS" | None
    business_context: str | None                   # formatted prompt block

    # --------- Geo tree (Excel pipeline) ---------
    geo_tree: dict | None                          # raw response from geo tree API

    # --------- Geo SQL templates (Excel pipeline — legacy, no longer used) ---------
    geo_sqls: dict | None                          # {"region":..., "area":..., "market":..., "site":...}

    # --------- Aggregated query results (region_sql_plan_node) ---------
    # All three execute once and are cached for all downstream analyzers.
    region_agg_sql: str | None                     # the at-risk aggregation SQL (stored for reference/debug)
    region_agg_results: list[dict]                 # at-risk site counts by region/area/market
    total_active_results: list[dict]               # total active site counts by region/area/market (project-scoped)
    all_at_risk_site_rows: list[dict]              # all individual at-risk site rows (same condition as region_agg); filtered by market in analyze_site_node

    # --------- Geo analysis JSON (with percentages, stored per level) ---------
    region_analysis_json: list[dict]               # {region, geo_code, at_risk_count, total_active, at_risk_pct, is_flagged, summary}
    area_analysis_json: list[dict]                 # same shape per area, includes parent_region_code

    # --------- Geo analyzer outputs (Excel pipeline) ---------
    region_geo_findings: list[GeoFinding]
    area_geo_findings: list[GeoFinding]
    market_geo_findings: list[GeoFinding]
    excel_site_step_results: list[StepResult]

    # --------- Milestone enrichment (Excel pipeline) ---------
    # Keyed by site identifier (pj_project_id for NTM, s_site_id for AHLOA/NAS).
    site_milestones: dict | None

    # --------- Per-market LLM summaries (Excel pipeline) ---------
    # Keyed by StepResult.step_name ("Site-level: <market> (<code>)").
    # Computed once in analyze_site_node; reused in risk_identification_node.
    market_site_summaries: dict | None

    # --------- Risk Identification outputs ---------
    findings: list[RiskFinding]
    summary: str | None

    # --------- Bookkeeping ---------
    errors: Annotated[list[str], operator.add]
    started_at_iso: str
