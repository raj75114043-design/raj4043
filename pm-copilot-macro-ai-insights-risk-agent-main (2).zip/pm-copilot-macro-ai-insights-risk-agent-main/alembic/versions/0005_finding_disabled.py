"""Add disabled column to risk_findings.

Revision ID: 0005
Revises: 0004
Create Date: 2026-05-18
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0005"
down_revision = "0004"
branch_labels = None
depends_on = None

_SCHEMA = "pwc_agent_utility_schema"


def upgrade() -> None:
    op.add_column(
        "risk_findings",
        sa.Column("disabled", sa.Boolean(), nullable=False, server_default="false"),
        schema=_SCHEMA,
    )


def downgrade() -> None:
    op.drop_column("risk_findings", "disabled", schema=_SCHEMA)
