"""Replace risk_interactions and risk_feedback with unified risk_interactions table.

Revision ID: 0002
Revises: 0001
Create Date: 2026-05-09
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

_SCHEMA = "pwc_agent_utility_schema"


def upgrade() -> None:
    op.execute(f'DROP TABLE IF EXISTS "{_SCHEMA}".risk_feedback')
    op.execute(f'DROP TABLE IF EXISTS "{_SCHEMA}".risk_interactions')

    op.create_table(
        "risk_interactions",
        sa.Column("interaction_id", sa.String(), nullable=False),
        sa.Column("finding_id", sa.String(), nullable=False),
        sa.Column("user_id", sa.String(), nullable=False),
        sa.Column("liked", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("disliked", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("acknowledged", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("muted", sa.Boolean(), nullable=False, server_default="false"),
        sa.Column("feedback", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(["finding_id"], [f"{_SCHEMA}.risk_findings.finding_id"]),
        sa.PrimaryKeyConstraint("interaction_id"),
        sa.UniqueConstraint("finding_id", "user_id", name="uq_risk_interaction_user"),
        schema=_SCHEMA,
    )
    op.create_index("ix_risk_interactions_finding_id", "risk_interactions", ["finding_id"], schema=_SCHEMA)
    op.create_index("ix_risk_interactions_user_id", "risk_interactions", ["user_id"], schema=_SCHEMA)


def downgrade() -> None:
    op.drop_table("risk_interactions", schema=_SCHEMA)
