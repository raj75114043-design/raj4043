"""Add action_owner and status columns to risk_findings.

Revision ID: 0003
Revises: 0002
Create Date: 2026-05-14
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None

_SCHEMA = "pwc_agent_utility_schema"


def upgrade() -> None:
    op.add_column(
        "risk_findings",
        sa.Column("action_owner", sa.String(), nullable=True),
        schema=_SCHEMA,
    )
    op.add_column(
        "risk_findings",
        sa.Column("status", sa.String(), nullable=False, server_default="Open"),
        schema=_SCHEMA,
    )


def downgrade() -> None:
    op.drop_column("risk_findings", "status", schema=_SCHEMA)
    op.drop_column("risk_findings", "action_owner", schema=_SCHEMA)
