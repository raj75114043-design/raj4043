"""Create risk_agent_chat_sessions and risk_agent_chat_messages tables.

Revision ID: 0004
Revises: 0003
Create Date: 2026-05-14
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0004"
down_revision = "0003"
branch_labels = None
depends_on = None

_SCHEMA = "pwc_agent_utility_schema"


def upgrade() -> None:
    op.create_table(
        "risk_agent_chat_sessions",
        sa.Column("session_id", sa.String(), primary_key=True),
        sa.Column("user_id", sa.String(), nullable=False),
        sa.Column("title", sa.String(), nullable=True),
        sa.Column("created_at", sa.DateTime(), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(), server_default=sa.func.now()),
        schema=_SCHEMA,
    )
    op.create_index(
        "ix_ra_chat_sessions_user_id",
        "risk_agent_chat_sessions",
        ["user_id"],
        schema=_SCHEMA,
    )

    op.create_table(
        "risk_agent_chat_messages",
        sa.Column("message_id", sa.String(), primary_key=True),
        sa.Column(
            "session_id",
            sa.String(),
            sa.ForeignKey(f"{_SCHEMA}.risk_agent_chat_sessions.session_id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("role", sa.String(), nullable=False),
        sa.Column("content", sa.Text(), nullable=False),
        sa.Column("created_at", sa.DateTime(), server_default=sa.func.now()),
        schema=_SCHEMA,
    )
    op.create_index(
        "ix_ra_chat_messages_session_id",
        "risk_agent_chat_messages",
        ["session_id"],
        schema=_SCHEMA,
    )


def downgrade() -> None:
    op.drop_index("ix_ra_chat_messages_session_id", table_name="risk_agent_chat_messages", schema=_SCHEMA)
    op.drop_table("risk_agent_chat_messages", schema=_SCHEMA)
    op.drop_index("ix_ra_chat_sessions_user_id", table_name="risk_agent_chat_sessions", schema=_SCHEMA)
    op.drop_table("risk_agent_chat_sessions", schema=_SCHEMA)
