"""Initial risk_reports and risk_findings tables in pwc_agent_utility_schema.

Revision ID: 0001
Revises:
Create Date: 2026-05-05
"""

from __future__ import annotations

import sqlalchemy as sa
from alembic import op

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

_SCHEMA = "pwc_agent_utility_schema"


def upgrade() -> None:
    op.execute(f'CREATE SCHEMA IF NOT EXISTS "{_SCHEMA}"')

    op.create_table(
        "risk_reports",
        sa.Column("report_id", sa.String(), nullable=False),
        sa.Column("category_id", sa.String(), nullable=False),
        sa.Column("pipeline_type", sa.String(), nullable=False),
        sa.Column("steps_planned", sa.Integer(), nullable=True),
        sa.Column("steps_succeeded", sa.Integer(), nullable=True),
        sa.Column("steps_failed", sa.Integer(), nullable=True),
        sa.Column("total_rows_examined", sa.Integer(), nullable=True),
        sa.Column("started_at", sa.DateTime(), nullable=True),
        sa.Column("finished_at", sa.DateTime(), nullable=True),
        sa.Column("duration_ms", sa.Float(), nullable=True),
        sa.Column("summary", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.PrimaryKeyConstraint("report_id"),
        schema=_SCHEMA,
    )
    op.create_index("ix_risk_reports_category_id", "risk_reports", ["category_id"], schema=_SCHEMA)
    op.create_index("ix_risk_reports_pipeline_type", "risk_reports", ["pipeline_type"], schema=_SCHEMA)

    op.create_table(
        "risk_findings",
        sa.Column("finding_id", sa.String(), nullable=False),
        sa.Column("report_id", sa.String(), nullable=False),
        sa.Column("category_id", sa.String(), nullable=False),
        sa.Column("pipeline_type", sa.String(), nullable=False),
        sa.Column("risk", sa.String(), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("root_cause", sa.Text(), nullable=True),
        sa.Column("severity", sa.String(), nullable=True),
        sa.Column("likelihood", sa.String(), nullable=True),
        sa.Column("impact", sa.String(), nullable=True),
        sa.Column("risk_rating", sa.String(), nullable=True),
        sa.Column("mitigation_actions", sa.Text(), nullable=True),
        sa.Column("recovery_plan", sa.Text(), nullable=True),
        sa.Column("drill_down_tables", sa.Text(), nullable=True),
        sa.Column("evidence", sa.Text(), nullable=True),
        sa.Column("detected_at", sa.DateTime(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.ForeignKeyConstraint(
            ["report_id"],
            [f"{_SCHEMA}.risk_reports.report_id"],
        ),
        sa.PrimaryKeyConstraint("finding_id"),
        schema=_SCHEMA,
    )
    op.create_index("ix_risk_findings_report_id", "risk_findings", ["report_id"], schema=_SCHEMA)
    op.create_index("ix_risk_findings_category_id", "risk_findings", ["category_id"], schema=_SCHEMA)
    op.create_index("ix_risk_findings_pipeline_type", "risk_findings", ["pipeline_type"], schema=_SCHEMA)
    op.create_index("ix_risk_findings_severity", "risk_findings", ["severity"], schema=_SCHEMA)
    op.create_index("ix_risk_findings_risk_rating", "risk_findings", ["risk_rating"], schema=_SCHEMA)
    op.create_index("ix_risk_findings_detected_at", "risk_findings", ["detected_at"], schema=_SCHEMA)


def downgrade() -> None:
    op.drop_table("risk_findings", schema=_SCHEMA)
    op.drop_table("risk_reports", schema=_SCHEMA)
