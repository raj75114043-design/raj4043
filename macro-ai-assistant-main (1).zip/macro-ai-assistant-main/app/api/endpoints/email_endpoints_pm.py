"""
PM Playground Email Endpoint
Sends a formatted PM Playground chat turn as an HTML email via Nokia mail gateway.

Fetches from two tables:
  - pm_playground_chat_history       → main turn (project, filters, HITL, CSV synthesis)
  - pm_playground_sub_question_results → per-sub-question SQL + data table + charts

Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import json
import logging
from typing import Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.services.email_send_pm import (
    PM_CHAT_TABLE,
    PM_SUB_TABLE,
    build_playground_email,
    build_csv_attachment,
    get_gateway_session,
    send_via_gateway,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/email-pm", tags=["PM Playground Email"])


# ── Request Models ─────────────────────────────────────────────────────────────

class ImageAttachment(BaseModel):
    filename: str = Field(..., description="Filename including extension, e.g. 'chart.png'")
    data: str = Field(
        ...,
        description=(
            "Base64-encoded image bytes. Accepts raw base64 or a data URI "
            "(e.g. 'data:image/png;base64,...'). The data-URI prefix is stripped automatically."
        ),
    )


class SendPlaygroundEmailRequest(BaseModel):
    session_id: str = Field(..., description="Session ID for the playground session")
    unique_chat_id: str = Field(..., description="Unique chat ID of the specific turn to email")
    to_list: List[str] = Field(..., min_length=1, description="Recipient email addresses")
    cc_list: List[str] = Field(default=[], description="CC email addresses")
    bcc_list: List[str] = Field(default=[], description="BCC email addresses")
    custom_message: Optional[str] = Field(default=None, description="Optional note from sender")
    images: List[ImageAttachment] = Field(
        default=[],
        description="Optional chart screenshots to embed inline. Max 5.",
        max_length=5,
    )


# ── Endpoint ───────────────────────────────────────────────────────────────────

@router.post(
    "/send-chat",
    summary="Send PM Playground chat turn as formatted email",
    description=(
        "Fetches a PM Playground turn by session_id + unique_chat_id "
        "(main record + sub-question results) and sends a Nokia-blue HTML email "
        "with filters, AI analysis, per-sub-question SQL/data, and CSV synthesis."
    ),
)
async def send_playground_chat_email(
    request: SendPlaygroundEmailRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Flow:
    1. Fetch main turn from pm_playground_chat_history
    2. Fetch sub-question rows from pm_playground_sub_question_results
    3. Build Nokia-blue HTML email
    4. Build CSV attachments (one per sub-question + CSV synthesis final table)
    5. Authenticate with Nokia gateway and send
    """
    try:
        # Step 1: Fetch main turn
        main_result = await db.execute(
            text(f"""
                SELECT
                    unique_chat_id, session_id, hitl_id, username,
                    user_query, enriched_query,
                    project, market, region, area, vendors, kpis,
                    date_start, date_end,
                    keyword_names, kpi_names_found, qb_names,
                    query_type, ready_for_sql,
                    hitl_response, hitl_assisted_response, hitl_generic_response,
                    sub_questions,
                    csv_final_table_json, csv_text_explanation, csv_agent_steps,
                    final_charts_json, status, created_at
                FROM {PM_CHAT_TABLE}
                WHERE session_id = :session_id AND unique_chat_id = :unique_chat_id
            """),
            {"session_id": request.session_id, "unique_chat_id": request.unique_chat_id},
        )
        main_row = main_result.mappings().first()

        if not main_row:
            raise HTTPException(status_code=404, detail="PM Playground chat record not found")

        # Step 2: Fetch sub-question results ordered by question_index
        sub_result = await db.execute(
            text(f"""
                SELECT
                    question_index, sub_question,
                    generated_sql, table_json,
                    sql_success, sql_error, charts_json
                FROM {PM_SUB_TABLE}
                WHERE session_id = :session_id AND unique_chat_id = :unique_chat_id
                ORDER BY question_index ASC
            """),
            {"session_id": request.session_id, "unique_chat_id": request.unique_chat_id},
        )
        sub_rows = [dict(r) for r in sub_result.mappings().all()]

        # Step 3: Build HTML email body
        html_body = build_playground_email(
            row=dict(main_row),
            sub_rows=sub_rows,
            custom_message=request.custom_message,
            images=request.images,
        )

        # Step 4: Build CSV attachments
        attachments: List[Dict[str, str]] = []

        for sr in sub_rows:
            if sr.get("table_json"):
                idx = sr.get("question_index", "")
                att = build_csv_attachment(sr["table_json"], f"sub_question_{idx}_results.csv")
                if att:
                    attachments.append(att)

        csv_final = dict(main_row).get("csv_final_table_json")
        if csv_final:
            att = build_csv_attachment(csv_final, "csv_synthesis_results.csv")
            if att:
                attachments.append(att)

        # Append image files (already embedded inline in the HTML body as well)
        for img in request.images:
            raw = img.data
            if "," in raw and raw.startswith("data:"):
                raw = raw.split(",", 1)[1]
            attachments.append({"filename": img.filename, "filedata": raw})

        # Step 5: Send via Nokia gateway
        gateway_sid = get_gateway_session()
        project_label = dict(main_row).get("project") or "PM Playground"
        query_short = (dict(main_row).get("user_query") or "Analytics")[:60]
        subject = f"PM Playground [{project_label}]: {query_short}"

        send_via_gateway(
            gateway_sid=gateway_sid,
            to_list=request.to_list,
            cc_list=request.cc_list,
            bcc_list=request.bcc_list,
            subject=subject,
            body=html_body,
            attachments=attachments,
        )

        logger.info(
            f"PM Playground email sent | chat_id={request.unique_chat_id} "
            f"sub_rows={len(sub_rows)} attachments={len(attachments)} "
            f"recipients={request.to_list}"
        )

        return {
            "status": "sent",
            "unique_chat_id": str(request.unique_chat_id),
            "recipients": request.to_list,
            "sub_question_count": len(sub_rows),
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"PM Playground email send failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Email send failed: {str(e)}")
