"""
AI Assistant endpoint – HITL gateway for user queries
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import asyncio
import json
import logging
import re
import time
from datetime import datetime, timezone
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import text

import asyncpg
import pandas as pd

from app.services.parallel_kpi_key_qb_search import parallel_search
from app.services.table_utils import df_to_table_json
from app.agents.hitl_agent import run_hitl_agent
from app.agents.sql_agent.graph import run_sql_agent
from app.agents.sql_agent.config import DB_CONFIG
from app.chains.chat_header_gen.chat_header_gen import generate_chat_header
from app.chains.table_analysis.analysis import generate_table_analysis
from app.chains.sql_explanation.analysis import generate_sql_explanation
from app.chains.high_chart_graph_gen.hi_chart_graph import generate_hichart_graphs
from app.db.database import AsyncSessionLocal
from app.core.config import settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/assistant", tags=["AI Assistant"])

SCHEMA = settings.db_schema
CHAT_TABLE = f"{SCHEMA}.ai_assistant_chat_history"
HITL_TABLE = f"{SCHEMA}.human_in_the_loop"


# ── Job Store (in-memory) ────────────────────────────────────────────
# In production, consider using Redis or a database for persistence across pod restarts


JOB_STORE: dict = {}  # job_id -> job_state


# ── Request / Response schemas ───────────────────────────────────────

class QueryRequest(BaseModel):
    session_id: str = Field(description="Mandatory Session ID")
    username: str = Field(default="anonymous", description="Username of the requester")
    query: str = Field(..., min_length=1, description="User's natural language query")
    is_follow_up: bool = Field(default=False, description="True if this is a follow-up to a clarification")
    follow_up_chat_id: Optional[str] = Field(
        default=None,
        description="Needed when is_follow_up=True"
    )
    project: str = Field(
        default="ALL",
        description="Project scope filter. One of: ALL, NTM, NAS, AHLOA. Defaults to ALL (no restriction).",
    )




class JobStatusResponse(BaseModel):
    job_id: str = Field(description="Unique job identifier")
    status: str = Field(description="pending | processing | completed | failed")
    created_at: str = Field(description="ISO timestamp when job was created")
    started_at: Optional[str] = Field(default=None, description="ISO timestamp when processing started")
    completed_at: Optional[str] = Field(default=None, description="ISO timestamp when processing completed")
    progress: str = Field(default="Initializing...", description="Current progress message")
    error: Optional[str] = Field(default=None, description="Error message if failed")


class JobResultResponse(BaseModel):
    job_id: str = Field(description="Unique job identifier")
    status: str = Field(description="completed | failed")
    unique_chat_id: str = Field(description="Chat ID for this query")
    hitl_id: str = Field(description="HITL ID for this query")
    success: bool = Field(description="Whether SQL execution was successful")
    generated_sql: str = Field(default="", description="Generated SQL query")
    table_json: str = Field(default="", description="Result data as JSON")
    error: str = Field(default="", description="Error message if applicable")
    node_timestamps: dict = Field(default_factory=dict, description="Execution timestamps")


# ── SSE helper ───────────────────────────────────────────────────────

def _sse_event(event: str, data: dict) -> str:
    """Format a Server-Sent Event string."""
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"

# ── Follow-up context helpers ─────────────────────────────────────

def _construct_combined_query(current_query: str, prev_query: str, prev_sql: str) -> str:
    """
    Construct an explicit combined query that clearly shows follow-up context.
    This eliminates ambiguity by structuring the relationship plainly for the LLM.

    Returns: "Previous: {query} | Previous SQL: {sql} | Follow-up: {current_query}"
    """
    if not prev_query:
        return current_query

    parts = []
    parts.append(f"Previous Query: {prev_query}")

    if prev_sql:
        parts.append(f"Previous SQL: {prev_sql}")

    parts.append(f"Follow-up Query: {current_query}")

    return " | ".join(parts)


async def _fetch_previous_context(follow_up_chat_id: str | None) -> tuple[str, str, str]:
    """
    Fetch previous chat context for follow-up questions.
    Returns (previous_user_query, previous_clarifying_message, previous_generated_sql) or ("", "", "") if not found.
    """
    if not follow_up_chat_id:
        return "", "", ""

    try:
        async with AsyncSessionLocal() as db:
            # Fetch chat_history row
            chat_result = await db.execute(
                text(f"""
                    SELECT unique_chat_id, hitl_id, user_query, sql_generated
                    FROM {CHAT_TABLE}
                    WHERE unique_chat_id = :chat_id
                    LIMIT 1
                """),
                {"chat_id": follow_up_chat_id},
            )
            chat_row = chat_result.fetchone()
            if not chat_row:
                return "", "", ""

            prev_query = chat_row[2] if len(chat_row) > 2 else ""
            prev_sql = chat_row[3] if len(chat_row) > 3 else ""
            hitl_id = chat_row[1] if len(chat_row) > 1 else None

            # Fetch HITL response
            if hitl_id:
                hitl_result = await db.execute(
                    text(f"""
                        SELECT hitl_assisted_response
                        FROM {HITL_TABLE}
                        WHERE hitl_id = :hitl_id
                        LIMIT 1
                    """),
                    {"hitl_id": hitl_id},
                )
                hitl_row = hitl_result.fetchone()
                prev_msg = hitl_row[0] if hitl_row else ""
            else:
                prev_msg = ""

            logger.info(
            "\n"
            "============================================================\n"
            "                     FOLLOW-UP QUERY INITIATED\n"
            "============================================================\n"
            f"Previous Chat ID   : {follow_up_chat_id}\n"
            f"Previous User Query: {prev_query}\n"
            f"AI HITL Message    : {prev_msg}\n"
            "Previous SQL Code  :\n"
            f"{prev_sql}\n"
            "============================================================\n"
            )

            return prev_query, prev_msg, prev_sql
    except Exception as e:
        logger.warning(f"Failed to fetch previous context for follow-up: {e}")
        return "", "", ""


async def _fetch_previous_search_context(follow_up_chat_id: str | None) -> tuple[list[str], list[str], list[str]]:
    """
    Fetch previous search results (keywords, KPIs, QBs) for follow-up questions.
    Returns (keyword_names, kpi_names, qb_names) from the previous chat record.
    This preserves the context from the first query when handling follow-ups.
    """
    if not follow_up_chat_id:
        return [], [], []

    try:
        async with AsyncSessionLocal() as db:
            chat_result = await db.execute(
                text(f"""
                    SELECT keywords_indentifed, kpi_identified, qb_indentifed
                    FROM {CHAT_TABLE}
                    WHERE unique_chat_id = :chat_id
                    LIMIT 1
                """),
                {"chat_id": follow_up_chat_id},
            )
            chat_row = chat_result.fetchone()
            if not chat_row:
                return [], [], []

            # Parse comma-separated strings back into lists
            keywords_str = chat_row[0] if chat_row[0] else ""
            kpis_str = chat_row[1] if chat_row[1] else ""
            qbs_str = chat_row[2] if chat_row[2] else ""

            keyword_names = [k.strip() for k in keywords_str.split(",") if k.strip()] if keywords_str else []
            kpi_names = [k.strip() for k in kpis_str.split(",") if k.strip()] if kpis_str else []
            qb_names = [q.strip() for q in qbs_str.split(",") if q.strip()] if qbs_str else []

            logger.info(
                f"Reusing previous search context for follow-up:\n"
                f"  Keywords: {keyword_names}\n"
                f"  KPIs: {kpi_names}\n"
                f"  QBs: {qb_names}"
            )

            return keyword_names, kpi_names, qb_names
    except Exception as e:
        logger.warning(f"Failed to fetch previous search context: {e}")
        return [], [], []

# ── DB persistence helper ─────────────────────────────────────────────

async def _save_chat_and_hitl(
    *,
    unique_chat_id: str,
    hitl_id: str,
    session_id: str,
    username: str,
    user_query: str,
    keyword_names: list[str],
    kpi_names: list[str],
    qb_names: list[str],
    is_follow_up: bool,
    hitl_generic_response: str,
    hitl_assisted_response: str,
    hitl_status: str,
    sql_generated: str = " ",
    table_json: str = " ",
    distill_toon_output: str = " ",
    ai_assistant_output: str = " ",
) -> None:
    """
    Persist a chat_history row and a human_in_the_loop row in a single
    transaction. Used for all scenarios (including Scenario 3 with SQL results).
    """
    # now = datetime.now(timezone.utc)
    now = datetime.now().replace(tzinfo=None)
    
    async with AsyncSessionLocal() as db:
        try:
            # ── Insert chat_history ──
            await db.execute(
                text(f"""
                    INSERT INTO {CHAT_TABLE}
                        (unique_chat_id, session_id, hitl_id, username,
                         status, session_status_ui, user_query, hitl_assisted_response,
                         hitl_generic_response, kpi_identified, keywords_indentifed,
                         qb_indentifed, is_follow_up, sql_generated, table_json, distlled_toon_context_output, ai_assistant_output, created_at)
                    VALUES
                        (:unique_chat_id, :session_id, :hitl_id, :username,
                         :status, :session_status_ui, :user_query, :hitl_assisted_response,
                         :hitl_generic_response, :kpi_identified, :keywords_indentifed,
                         :qb_indentifed, :is_follow_up, :sql_generated, :table_json, :distlled_toon_context_output,:ai_assistant_output, :created_at)
                """),
                {
                    "unique_chat_id": unique_chat_id,
                    "session_id": session_id,
                    "hitl_id": hitl_id,
                    "username": username,
                    "status": hitl_status,
                    "session_status_ui": True,
                    "user_query": user_query,
                    "hitl_assisted_response": hitl_assisted_response,
                    "hitl_generic_response": hitl_generic_response,
                    "kpi_identified": (", ".join(kpi_names)[:255]) if kpi_names else None,
                    "keywords_indentifed": (", ".join(keyword_names)[:255]) if keyword_names else None,
                    "qb_indentifed": (", ".join(qb_names)[:255]) if qb_names else None,
                    "is_follow_up": is_follow_up,
                    "sql_generated": sql_generated if sql_generated else None,
                    "table_json": table_json if table_json else None,
                    "distlled_toon_context_output": distill_toon_output,
                    "ai_assistant_output": ai_assistant_output,
                    "created_at": now,
                },
            )

            # ── Insert human_in_the_loop ──
            await db.execute(
                text(f"""
                    INSERT INTO {HITL_TABLE}
                        (hitl_id, session_id, unique_chat_id, username,
                         user_query, hitl_assisted_response,
                         hitl_generic_response, status, created_at)
                    VALUES
                        (:hitl_id, :session_id, :unique_chat_id, :username,
                         :user_query, :hitl_assisted_response,
                         :hitl_generic_response, :status, :created_at)
                """),
                {
                    "hitl_id": hitl_id,
                    "session_id": session_id,
                    "unique_chat_id": unique_chat_id,
                    "username": username,
                    "user_query": user_query,
                    "hitl_assisted_response": hitl_assisted_response,
                    "hitl_generic_response": hitl_generic_response,
                    "status": hitl_status,
                    "created_at": now,
                },
            )

            await db.commit()
            logger.info(
                f"Saved chat_history ({unique_chat_id}) and "
                f"hitl ({hitl_id}) — status={hitl_status}"
            )
        except Exception as e:
            await db.rollback()
            logger.error(f"Failed to save chat/hitl records: {e}")
            raise


# ── Endpoints ────────────────────────────────────────────────────────

@router.post(
    "/session",
    summary="Create a new chat session",
    description="Returns a unique session_id for the frontend to use when "
                "the user logs in or clicks 'New Chat'.",
)
async def create_session():
    """Generate and return a new unique session ID."""
    return {"session_id": str(uuid4())}


@router.post(
    "/query",
    summary="Submit a query to the AI Assistant (SSE stream)",
    description="Runs parallel search and streams each result chunk via SSE. "
                "Events: search_keywords, search_kpis, search_qb, search_complete, error.",
)
async def submit_query(request: QueryRequest):
    """
    
    Step 1 – Parallel search with SSE streaming.

    Fires keyword, KPI, and question-bank searches in parallel.
    As each completes, the result is streamed to the frontend as an SSE event.
    If all three return empty, a graceful message is sent instead.
    
    """

    # ── Project-scope suffix map ──────────────────────────────────────────
    _PROJECT_SUFFIXES: dict[str, str] = {
        "NTM":   " for NTM",
        "NAS":   " for NAS",
        "AHLOA": " for AHLOA",
    }

    # Build enriched query — append project suffix when a specific project is selected
    _project = (request.project or "ALL").upper().strip()
    _enriched_query = (
        request.query + _PROJECT_SUFFIXES[_project]
        if _project in _PROJECT_SUFFIXES
        else request.query
    )

    async def _event_generator():
        pipeline_start_ts = datetime.now(timezone.utc).isoformat()
        pipeline_start_time = time.time()

        # Step 1 – Run parallel search on the current query (new or follow-up)
        # For follow-ups, also fetch and merge with previous search context
        keyword_names = []
        keyword_ids = []
        keyword_results = []
        kpi_names = []
        kpi_ids = []
        kpi_results = []
        qb_names = []
        qb_ids = []
        qb_results = []

        # Fetch previous context for follow-ups (to preserve prior search results)
        prev_keyword_names = []
        prev_kpi_names = []
        prev_qb_names = []
        if request.is_follow_up and request.follow_up_chat_id:
            logger.info(f"Follow-up detected: fetching previous search context from {request.follow_up_chat_id}")
            prev_keyword_names, prev_kpi_names, prev_qb_names = await _fetch_previous_search_context(request.follow_up_chat_id)

        # Run parallel search on the enriched query (includes project suffix when scoped)
        try:
            search = await parallel_search(_enriched_query)
        except Exception as e:
            logger.error(f"Parallel search failed: {e}")
            yield _sse_event("error", {"message": f"Search failed: {e}"})
            return

        keyword_names = search.get("keyword_names", [])
        keyword_ids = search.get("keyword_ids", [])
        keyword_results = search.get("keyword_results", [])
        kpi_names = search.get("kpi_names", [])
        kpi_ids = search.get("kpi_ids", [])
        kpi_results = search.get("kpi_results", [])
        qb_names = search.get("qb_names", [])
        qb_ids = search.get("qb_ids", [])
        qb_results = search.get("qb_results", [])

        # For follow-ups, merge previous context with new search results
        if request.is_follow_up and request.follow_up_chat_id and (prev_keyword_names or prev_kpi_names or prev_qb_names):
            # Merge keywords (avoid duplicates, preserve scores)
            # Create dict keyed by keyword_name to dedupe while preserving scores
            keyword_dict = {}
            for result in (keyword_results or []):
                key = result.get("keyword_name") or ""
                if key and key not in keyword_dict:
                    keyword_dict[key] = result
            merged_keyword_names = list(keyword_dict.keys())
            merged_keyword_results = list(keyword_dict.values())

            # Merge KPIs (avoid duplicates, preserve scores)
            kpi_dict = {}
            for result in (kpi_results or []):
                kpi_name = result.get("content", {}).get("kpi_name") or ""
                if kpi_name and kpi_name not in kpi_dict:
                    kpi_dict[kpi_name] = result
            merged_kpi_names = list(kpi_dict.keys())
            merged_kpi_results = list(kpi_dict.values())

            # Merge question bank (avoid duplicates, preserve scores)
            qb_dict = {}
            for result in (qb_results or []):
                question = result.get("content", {}).get("question") or ""
                if question and question not in qb_dict:
                    qb_dict[question] = result
            merged_qb_names = list(qb_dict.keys())
            merged_qb_results = list(qb_dict.values())

            logger.info(
                f"Merged search context for follow-up:\n"
                f"  Previous keywords: {prev_keyword_names}\n"
                f"  New keywords: {keyword_names}\n"
                f"  Merged keywords: {merged_keyword_names}\n"
                f"  Previous KPIs: {prev_kpi_names}\n"
                f"  New KPIs: {kpi_names}\n"
                f"  Merged KPIs: {merged_kpi_names}\n"
                f"  Previous QBs: {prev_qb_names}\n"
                f"  New QBs: {qb_names}\n"
                f"  Merged QBs: {merged_qb_names}"
            )

            keyword_names = merged_keyword_names
            keyword_results = merged_keyword_results
            kpi_names = merged_kpi_names
            kpi_results = merged_kpi_results
            qb_names = merged_qb_names
            qb_results = merged_qb_results

        yield _sse_event("pipeline_start", {"timestamp": pipeline_start_ts})

        # Stream each category — indicate which ones found results
        yield _sse_event("search_keywords", {
            "keyword_names": keyword_names,
            "keyword_ids": keyword_ids,
            "keyword_results": keyword_results,  # Include full results with scores
            "found": len(keyword_names) > 0,
            "message": "" if keyword_names else "No matching keywords found.",
        })

        yield _sse_event("search_kpis", {
            "kpi_names": kpi_names,
            "kpi_ids": kpi_ids,
            "kpi_results": kpi_results,  # Include full results with scores
            "found": len(kpi_names) > 0,
            "message": "" if kpi_names else "No matching KPIs found.",
        })

        yield _sse_event("search_qb", {
            "qb_names": qb_names,
            "qb_ids": qb_ids,
            "qb_results": qb_results,  # Include full results with scores
            "found": len(qb_names) > 0,
            "message": "" if qb_names else "No matching reference questions found.",
        })

        # Determine overall status
        has_keywords = len(keyword_names) > 0
        has_kpis = len(kpi_names) > 0
        has_qb = len(qb_names) > 0
        all_empty = not has_keywords and not has_kpis and not has_qb
        partial = not all_empty and not (has_keywords and has_kpis and has_qb)

        # Search timing is always captured since we run parallel_search on every query
        search_duration = search.get("node_timestamps", 0)

        if all_empty:
            yield _sse_event("search_complete", {
                "status": "no_results",
                "message": (
                    "I couldn't find any matching keywords, KPIs, or reference "
                    "questions for your query. Could you rephrase your question? "
                    "For example, you could ask about specific telecom KPIs like "
                    "On-Air Completion Rate, site counts by region, or milestone progress."
                ),
            })
        elif partial:
            missing = []
            if not has_keywords:
                missing.append("keywords")
            if not has_kpis:
                missing.append("KPIs")
            if not has_qb:
                missing.append("reference questions")

            yield _sse_event("search_complete", {
                "status": "partial",
                "message": f"No matching {', '.join(missing)} found — proceeding with available context.",
                "keyword_names": keyword_names,
                "keyword_ids": keyword_ids,
                "keyword_results": keyword_results,  # Include full results with scores
                "kpi_names": kpi_names,
                "kpi_ids": kpi_ids,
                "kpi_results": kpi_results,  # Include full results with scores
                "qb_names": qb_names,
                "qb_ids": qb_ids,
                "qb_results": qb_results,  # Include full results with scores
                "search_duration_s": search_duration,
            })
        else:
            yield _sse_event("search_complete", {
                "status": "ok",
                "keyword_names": keyword_names,
                "keyword_ids": keyword_ids,
                "keyword_results": keyword_results,  # Include full results with scores
                "kpi_names": kpi_names,
                "kpi_ids": kpi_ids,
                "kpi_results": kpi_results,  # Include full results with scores
                "qb_names": qb_names,
                "qb_ids": qb_ids,
                "qb_results": qb_results,  # Include full results with scores
                "search_duration_s": search_duration,
            })

        # ── QB Exact-Match Fast Path ─────────────────────────────────
        # If the top question-bank result is a perfect match and carries a stored
        # SQL, skip the HITL LLM call and SQL generation entirely.
        # Two ways to match:
        #   1. Vector score ≥ 0.99 — near-perfect semantic similarity
        #   2. Normalised text equality (score ≥ 0.85) — catches trivial
        #      variations like extra spaces, case differences, trailing punctuation
        #      that lower the vector score without changing meaning.
        _QB_EXACT_THRESHOLD = 0.99
        _QB_NORM_THRESHOLD = 0.85  # minimum score for text-normalised match

        def _norm(s: str) -> str:
            """Lowercase, collapse whitespace, strip trailing punctuation."""
            import re as _re
            s = s.lower().strip()
            s = _re.sub(r"\s+", " ", s)          # collapse inner whitespace
            s = _re.sub(r"[?!.,;:\s]+$", "", s)  # strip trailing punctuation/spaces
            return s

        _norm_user = _norm(_enriched_query)

        _qb_exact: dict | None = None
        for _r in qb_results:
            _score = _r.get("score", 0)
            _stored_sql = _r.get("content", {}).get("sql", "").strip()
            if not _stored_sql:
                continue
            # Primary: high vector similarity
            if _score >= _QB_EXACT_THRESHOLD:
                _qb_exact = _r
                break
            # Secondary: normalised text match with softer score gate
            if _score >= _QB_NORM_THRESHOLD:
                _stored_q = _r.get("content", {}).get("question", "")
                if _norm(_stored_q) == _norm_user:
                    _qb_exact = _r
                    break

        if _qb_exact is not None:
            unique_chat_id = str(uuid4())
            hitl_id = str(uuid4())
            _stored_sql = _qb_exact["content"]["sql"].strip()

            # Mirror the normal hitl_start / hitl_complete events
            yield _sse_event("hitl_start", {
                "unique_chat_id": unique_chat_id,
                "hitl_id": hitl_id,
                "message": "Analysing your query…",
            })
            yield _sse_event("hitl_complete", {
                "unique_chat_id": unique_chat_id,
                "hitl_id": hitl_id,
                "query_type": "data",
                "ready_for_sql": True,
                "keyword_names": keyword_names,
                "kpi_names": kpi_names,
                "qb_names": qb_names,
                "hitl_duration_s": {},
                "message": "Query validated — proceeding to SQL generation.",
            })

            # Mirror sql_start then execute stored SQL directly
            yield _sse_event("sql_start", {
                "unique_chat_id": unique_chat_id,
                "message": "Generating SQL query…",
            })

            _qb_result_df = None
            _qb_sql_error = ""
            try:
                _conn = await asyncpg.connect(**DB_CONFIG)
                try:
                    _rows = await _conn.fetch(_stored_sql)
                    _qb_result_df = (
                        pd.DataFrame([dict(r) for r in _rows], columns=list(_rows[0].keys()))
                        if _rows else pd.DataFrame()
                    )
                finally:
                    await _conn.close()
            except Exception as _exc:
                _qb_sql_error = str(_exc)
                logger.error(f"QB fast-path SQL execution failed: {_exc}", exc_info=True)

            _qb_success = _qb_sql_error == "" and _qb_result_df is not None
            _qb_table_json = ""
            _qb_has_data = False
            if _qb_success and not _qb_result_df.empty:
                _qb_table_json = df_to_table_json(_qb_result_df)
                _qb_has_data = True

            yield _sse_event("sql_complete", {
                "unique_chat_id": unique_chat_id,
                "success": _qb_success,
                "generated_sql": _stored_sql,
                "table_json": _qb_table_json,
                "error": _qb_sql_error,
                "node_timestamps": {},
                "message": "SQL executed successfully." if _qb_success else "SQL execution failed.",
            })
            yield _sse_event("pipeline_end", {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "duration_s": round(time.time() - pipeline_start_time, 2),
            })

            # Post-SQL chains — same as normal path
            _qb_chat_header = None
            _qb_table_analysis = None
            _qb_sql_explanation = None

            if _qb_success:
                try:
                    _analysis_task = asyncio.create_task(
                        asyncio.wait_for(
                            asyncio.gather(
                                generate_chat_header(
                                    user_query=request.query,
                                    generated_sql=_stored_sql,
                                    table_json=_qb_table_json,
                                    has_data=_qb_has_data,
                                ),
                                generate_table_analysis(
                                    user_query=request.query,
                                    generated_sql=_stored_sql,
                                    table_json=_qb_table_json,
                                    distill_toon_output="",
                                    has_data=_qb_has_data,
                                ),
                                generate_sql_explanation(
                                    user_query=request.query,
                                    generated_sql=_stored_sql,
                                    distill_toon_context="",
                                ),
                                return_exceptions=True,
                            ),
                            timeout=120.0,
                        )
                    )
                    _last_ping = time.time()
                    while not _analysis_task.done():
                        if time.time() - _last_ping > 30:
                            yield ": keep-alive\n\n"
                            _last_ping = time.time()
                        await asyncio.sleep(1)

                    _res = _analysis_task.result()
                    _qb_chat_header = _res[0] if not isinstance(_res[0], Exception) else None
                    _qb_table_analysis = _res[1] if not isinstance(_res[1], Exception) else None
                    _qb_sql_explanation = _res[2] if not isinstance(_res[2], Exception) else None
                except (asyncio.TimeoutError, Exception) as _e:
                    logger.error(f"QB fast-path post-SQL chains failed: {_e}", exc_info=True)

            if _qb_chat_header:
                yield _sse_event("chat_header", {
                    "unique_chat_id": unique_chat_id,
                    "header": _qb_chat_header.header,
                    "sub_header": _qb_chat_header.sub_header,
                })
            if _qb_table_analysis:
                yield _sse_event("table_analysis", {
                    "unique_chat_id": unique_chat_id,
                    "analysis": _qb_table_analysis.analysis,
                    "key_insights": _qb_table_analysis.key_insights,
                })
            if _qb_sql_explanation:
                yield _sse_event("sql_explanation", {
                    "unique_chat_id": unique_chat_id,
                    "explanation": _qb_sql_explanation.explanation,
                    "key_steps": _qb_sql_explanation.key_steps,
                })

            await _save_chat_and_hitl(
                unique_chat_id=unique_chat_id,
                hitl_id=hitl_id,
                session_id=request.session_id,
                username=request.username,
                user_query=request.query,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_names=qb_names,
                is_follow_up=request.is_follow_up,
                hitl_generic_response="",
                hitl_assisted_response="",
                hitl_status="qb_fast_path",
                sql_generated=_stored_sql,
                table_json=_qb_table_json,
                distill_toon_output="",
                ai_assistant_output=_qb_table_analysis.analysis if _qb_table_analysis else "",
            )

            yield _sse_event("db_saved", {
                "unique_chat_id": unique_chat_id,
                "message": "Chat history saved.",
            })
            yield "event:chat_end\n\n"
            return  # ← fast path complete, skip normal HITL + SQL agent

        # ── Step 2 – HITL agent invocation ──────────────────────────────
        unique_chat_id = str(uuid4())
        hitl_id = str(uuid4())

        yield _sse_event("hitl_start", {
            "unique_chat_id": unique_chat_id,
            "hitl_id": hitl_id,
            "message": "Analysing your query…",
        })

        # Fetch previous context if this is a follow-up
        prev_query = ""
        prev_msg = ""
        prev_sql = ""
        combined_query = _enriched_query  # Use enriched query (with project suffix if scoped)
        if request.is_follow_up and request.follow_up_chat_id:
            prev_query, prev_msg, prev_sql = await _fetch_previous_context(request.follow_up_chat_id)
            # Construct explicit combined query that shows follow-up relationship
            combined_query = _construct_combined_query(request.query, prev_query, prev_sql)
            logger.info(f"Follow-up combined query:\n{combined_query}")

        try:
            hitl = await run_hitl_agent(
                user_query=combined_query,  # Use combined query instead of just current query
                keyword_results=keyword_results,
                kpi_results=kpi_results,
                qb_results=qb_results,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_questions=qb_names,
                is_follow_up=request.is_follow_up,
                previous_user_query=prev_query,
                previous_clarifying_message=prev_msg,
                project=_project,
            )
        except Exception as e:
            logger.error(f"HITL agent failed: {e}")
            yield _sse_event("error", {"message": f"HITL processing failed: {e}"})
            return

        query_type = hitl.get("query_type", "")
        ready_for_sql = hitl.get("ready_for_sql", False)

        # ── Scenario 1: General / chitchat query ──────────────────────
        if query_type == "general":
            general_response = hitl.get("general_response", "")

            yield _sse_event("hitl_complete", {
                "unique_chat_id": unique_chat_id,
                "hitl_id": hitl_id,
                "query_type": "general",
                "ready_for_sql": False,
                "general_response": general_response,
                "hitl_duration_s": hitl.get("node_timestamps", {}),
            })

            # Persist chat_history + hitl in background (no SQL output)
            await _save_chat_and_hitl(
                unique_chat_id=unique_chat_id,
                hitl_id=hitl_id,
                session_id=request.session_id,
                username=request.username,
                user_query=request.query,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_names=qb_names,
                is_follow_up=request.is_follow_up,
                hitl_generic_response=general_response,
                hitl_assisted_response="",
                hitl_status="completed_general",
            )

            yield _sse_event("db_saved", {
                "unique_chat_id": unique_chat_id,
                "message": "Chat history saved.",
            })
            yield "event:chat_end\n\n"  # SSE comment signaling end of chat stream
            return  # Flow ends — no SQL agent needed

        # ── Scenario 2: Data question but needs clarification ─────────
        if query_type == "data" and not ready_for_sql:
            clarifying_message = hitl.get("clarifying_message", "")
            

            yield _sse_event("hitl_complete", {
                "unique_chat_id": unique_chat_id,
                "hitl_id": hitl_id,
                "query_type": "data",
                "ready_for_sql": False,
                "clarifying_message": clarifying_message,
                "keyword_names": keyword_names,
                "kpi_names": kpi_names,
                "qb_names": qb_names,
                "hitl_duration_s": hitl.get("node_timestamps", {}),
            })

            # Persist so the follow-up can reference this chat turn
            await _save_chat_and_hitl(
                unique_chat_id=unique_chat_id,
                hitl_id=hitl_id,
                session_id=request.session_id,
                username=request.username,
                user_query=request.query,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_names=qb_names,
                is_follow_up=request.is_follow_up,
                hitl_generic_response="",
                hitl_assisted_response=clarifying_message,
                hitl_status="needs_clarification",
            )

            yield _sse_event("db_saved", {
                "unique_chat_id": unique_chat_id,
                "message": "Chat history saved. Awaiting follow-up from user.",
            })
            yield "event:chat_end\n\n"  # SSE comment signaling end of chat stream
            return  # Flow pauses — frontend sends follow-up

        # ── Scenario 3: Data question ready for SQL agent ─────────────
        yield _sse_event("hitl_complete", {
            "unique_chat_id": unique_chat_id,
            "hitl_id": hitl_id,
            "query_type": "data",
            "ready_for_sql": True,
            "keyword_names": keyword_names,
            "kpi_names": kpi_names,
            "qb_names": qb_names,
            "hitl_duration_s": hitl.get("node_timestamps", {}),
            "message": "Query validated — proceeding to SQL generation.",
        })

        # ── Step 3: SQL Agent invocation ─────────────────────────────
        yield _sse_event("sql_start", {
            "unique_chat_id": unique_chat_id,
            "message": "Generating SQL query…",
        })

        try:
            # ── Keep-alive pinging mechanism for long-running SQL generation ──
            # Create task for SQL agent with 360s timeout
            sql_task = asyncio.create_task(
                asyncio.wait_for(
                    run_sql_agent(
                        user_query=combined_query,  # Use combined query with full context
                        keyword_names=keyword_names,
                        kpi_names=kpi_names,
                        qb_names=qb_names,
                        is_follow_up=request.is_follow_up,
                        previous_user_query=prev_query,
                        previous_clarifying_message=prev_msg,
                        previous_generated_sql=prev_sql,
                        llm_name="o4-mini",
                    ),
                    timeout=360.0
                )
            )

            # Monitor task and send keep-alive pings every 30 seconds
            last_ping = time.time()
            while not sql_task.done():
                # Check if 30 seconds have passed since last ping
                if time.time() - last_ping > 30:
                    yield ": keep-alive\n\n"  # SSE comment (client ignores, connection stays alive)
                    last_ping = time.time()
                    logger.debug("Keep-alive ping sent during SQL generation")

                # Small sleep to avoid busy-waiting
                await asyncio.sleep(1)

            # Task is done, get result (may raise TimeoutError or other exceptions)
            sql_result = sql_task.result()

        except asyncio.TimeoutError:
            logger.error("SQL agent timed out after 360 seconds")
            yield _sse_event("sql_complete", {
                "unique_chat_id": unique_chat_id,
                "success": False,
                "generated_sql": "",
                "table_json": "",
                "error": "SQL generation timed out after 360 seconds",
                "node_timestamps": {},
                "message": "SQL generation timed out.",
            })
            yield _sse_event("pipeline_end", {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "duration_s": round(time.time() - pipeline_start_time, 2),
            })
            return
        except Exception as e:
            logger.error(f"SQL agent failed: {e}", exc_info=True)
            yield _sse_event("sql_complete", {
                "unique_chat_id": unique_chat_id,
                "success": False,
                "generated_sql": "",
                "table_json": "",
                "error": str(e),
                "node_timestamps": {},
                "message": f"SQL generation failed: {e}",
            })
            yield _sse_event("pipeline_end", {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "duration_s": round(time.time() - pipeline_start_time, 2),
            })
            return

        sql_success = sql_result.get("success", False)
        generated_sql = sql_result.get("generated_sql", "")
        result_df = sql_result.get("result_df")
        sql_error = sql_result.get("error", "")
        distill_toon_output = sql_result.get("context", "")

        # Trim context for post-processing chains (analysis / explanation).
        # The full context is large and only needed for accurate SQL generation;
        # downstream chains only need a compact summary to stay grounded.
        _MAX_CTX_CHARS = 1500
        if len(distill_toon_output) > _MAX_CTX_CHARS:
            distill_toon_trimmed = (
                distill_toon_output[:_MAX_CTX_CHARS].rsplit("\n", 1)[0]
                + "\n... [context truncated]"
            )
        else:
            distill_toon_trimmed = distill_toon_output

        # Serialize DataFrame to JSON for storage / SSE
        table_json = ""
        has_data = False
        if result_df is not None and not result_df.empty:
            table_json = df_to_table_json(result_df)
            has_data = bool(table_json)

        

        sql_complete_event = {
            "unique_chat_id": unique_chat_id,
            "success": sql_success,
            "generated_sql": generated_sql,
            "table_json": table_json,
            "error": sql_error,
            "node_timestamps": sql_result.get("node_timestamps", {}),
            "message": "SQL executed successfully." if sql_success else "SQL execution failed.",
        }

        yield _sse_event("sql_complete", sql_complete_event)
        yield _sse_event("pipeline_end", {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "duration_s": round(time.time() - pipeline_start_time, 2),
        })

        # Generate chat header, table analysis, and SQL explanation in parallel (all independent operations)
        # This optimizes performance by running three LLM calls concurrently instead of sequentially
        chat_header = None
        table_analysis = None
        sql_explanation = None

        if sql_success:
            try:
                # Run all three operations concurrently with keep-alive pinging
                analysis_task = asyncio.create_task(
                    asyncio.wait_for(
                        asyncio.gather(
                            generate_chat_header(
                                user_query=request.query,
                                generated_sql=generated_sql,
                                table_json=table_json,
                                has_data=has_data,
                            ),
                            generate_table_analysis(
                                user_query=request.query,
                                generated_sql=generated_sql,
                                table_json=table_json,
                                distill_toon_output=distill_toon_trimmed,
                                has_data=has_data,
                            ),
                            generate_sql_explanation(
                                user_query=request.query,
                                generated_sql=generated_sql,
                                distill_toon_context=distill_toon_trimmed,
                            ),
                            return_exceptions=True,
                        ),
                        timeout=120.0,
                    )
                )

                # Send keep-alive pings while waiting for parallel generation
                last_ping = time.time()
                while not analysis_task.done():
                    if time.time() - last_ping > 30:
                        yield ": keep-alive\n\n"
                        last_ping = time.time()
                        logger.debug("Keep-alive ping sent during parallel analysis generation")
                    await asyncio.sleep(1)

                results = analysis_task.result()

                # Unpack results with individual error handling
                chat_header = results[0] if not isinstance(results[0], Exception) else None
                table_analysis = results[1] if not isinstance(results[1], Exception) else None
                sql_explanation = results[2] if not isinstance(results[2], Exception) else None

                # Log individual results
                if isinstance(results[0], Exception):
                    logger.warning(f"Failed to generate chat header: {results[0]}")
                elif chat_header:
                    logger.info(f"Chat header generated: {chat_header.header}")

                if isinstance(results[1], Exception):
                    logger.warning(f"Failed to generate table analysis: {results[1]}")
                else:
                    logger.info("Table analysis generated successfully")

                if isinstance(results[2], Exception):
                    logger.warning(f"Failed to generate SQL explanation: {results[2]}")
                else:
                    logger.info("SQL explanation generated successfully")

            except asyncio.TimeoutError:
                logger.error("Parallel analysis generation timed out after 120 seconds")
            except Exception as e:
                logger.error(f"Unexpected error in parallel generation: {e}", exc_info=True)

        # Send header event
        if chat_header:
            header_event = {
                "unique_chat_id": unique_chat_id,
                "header": chat_header.header,
                "sub_header": chat_header.sub_header,
            }
            yield _sse_event("chat_header", header_event)

        # Send table analysis event
        if table_analysis:
            analysis_event = {
                "unique_chat_id": unique_chat_id,
                "analysis": table_analysis.analysis,
                "key_insights": table_analysis.key_insights,
            }
            yield _sse_event("table_analysis", analysis_event)

        # Send SQL explanation event
        if sql_explanation:
            explanation_event = {
                "unique_chat_id": unique_chat_id,
                "explanation": sql_explanation.explanation,
                "key_steps": sql_explanation.key_steps,
            }
            yield _sse_event("sql_explanation", explanation_event)

        # Save chat history with full SQL output (happens immediately while LLM chains are being prepared)
        # Note: Save original request.query (not combined_query) to database for UI/audit purposes

        await _save_chat_and_hitl(
            unique_chat_id=unique_chat_id,
            hitl_id=hitl_id,
            session_id=request.session_id,
            username=request.username,
            user_query=request.query,  # Original query from user (not combined form)
            keyword_names=keyword_names,
            kpi_names=kpi_names,
            qb_names=qb_names,
            is_follow_up=request.is_follow_up,
            hitl_generic_response="",
            hitl_assisted_response="",
            hitl_status="Data Question",
            sql_generated=generated_sql,
            table_json=table_json,
            distill_toon_output = distill_toon_output,
            ai_assistant_output = table_analysis.analysis,
        )

        # Signal end of chat stream
        yield "event:chat_end\n\n"  # SSE comment signaling end of chat stream

    return StreamingResponse(
        _event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


class GraphRequest(BaseModel):
    session_id: str = Field(description="Mandatory Session ID")
    unique_chat_id: str
    

@router.post(
    "/graph_generation",
    summary="Submit a autograph request for AI to give a Hi_chart compatabile json",
    description="This post fucntion generates on compheresneive hi_chart graph"
)
async def submit_query(request: GraphRequest):
    """
    Stream Hi-Chart graph generation with keep-alive pinging for Kubernetes timeout prevention.

    SSE Events emitted:
    - graph_start: Generation started
    - graph_complete: Generation succeeded with charts
    - graph_error: Generation failed with error message
    """
    async def stream_graph_generation():
        try:
            # ── Emit graph_start event ──────────────────────────────────
            yield _sse_event("graph_start", {
                "unique_chat_id": request.unique_chat_id,
                "message": "Graph generation started"
            })

            # ── Fetch chat data from database ────────────────────────────────
            async with AsyncSessionLocal() as db:
                result = await db.execute(
                    text(f"SELECT user_query, table_json, sql_generated FROM {CHAT_TABLE} WHERE unique_chat_id = :id"),
                    {"id": request.unique_chat_id}
                )
                row = result.fetchone()

            if not row:
                yield _sse_event("graph_error", {
                    "unique_chat_id": request.unique_chat_id,
                    "error": "Chat record not found"
                })
                return

            user_query, table_json, generated_sql = row

            if not table_json:
                yield _sse_event("graph_error", {
                    "unique_chat_id": request.unique_chat_id,
                    "error": "No table data available for this chat"
                })
                return

            # ── Create task for graph generation with timeout ──────────────────
            graph_task = asyncio.create_task(
                asyncio.wait_for(
                    generate_hichart_graphs(
                        user_query=user_query or "",
                        table_json=table_json,
                        generated_sql=generated_sql or "",
                    ),
                    timeout=300.0  # 5 minutes timeout
                )
            )

            # ── Monitor task and send keep-alive pings every 30 seconds ────────
            last_ping = time.time()
            while not graph_task.done():
                # Check if 30 seconds have passed since last ping
                if time.time() - last_ping > 30:
                    yield ": keep-alive\n\n"  # SSE comment (client ignores, connection stays alive)
                    last_ping = time.time()
                    logger.debug("Keep-alive ping sent during graph generation")

                # Small sleep to avoid busy-waiting
                await asyncio.sleep(1)

            # ── Get result or handle exception ──────────────────────────────
            try:
                output = graph_task.result()
                logger.info(f"Hi-Chart graphs generated for chat_id={request.unique_chat_id}")

                # ── Emit graph_complete event ──────────────────────────────────
                yield _sse_event("graph_complete", {
                    "unique_chat_id": request.unique_chat_id,
                    "charts": output.charts,
                    "status": "success"
                })

            except asyncio.TimeoutError:
                logger.error(f"Graph generation timeout for chat_id={request.unique_chat_id}")
                yield _sse_event("graph_error", {
                    "unique_chat_id": request.unique_chat_id,
                    "error": "Graph generation timed out after 5 minutes",
                    "status": "timeout"
                })

            except Exception as e:
                logger.error(f"Graph generation failed for chat_id={request.unique_chat_id}: {e}", exc_info=True)
                yield _sse_event("graph_error", {
                    "unique_chat_id": request.unique_chat_id,
                    "error": f"Failed to generate chart recommendations: {str(e)}",
                    "status": "error"
                })

        except Exception as e:
            logger.error(f"Stream error during graph generation: {e}", exc_info=True)
            yield _sse_event("graph_error", {
                "unique_chat_id": request.unique_chat_id,
                "error": f"Stream error: {str(e)}",
                "status": "error"
            })

    return StreamingResponse(
        stream_graph_generation(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# ── Full-data export ──────────────────────────────────────────────────

FULL_DATA_SAFE_LIMIT = 5_000

def _apply_safe_limit(sql: str, limit: int = FULL_DATA_SAFE_LIMIT) -> str:
    """
    Replace the outermost trailing LIMIT clause with a safe ceiling.
    Anchoring to $ ensures inner CTE/subquery LIMITs are untouched.
    """
    cleaned = sql.rstrip().rstrip(";").rstrip()
    modified = re.sub(r"(?i)\bLIMIT\s+\d+\s*$", f"LIMIT {limit}", cleaned)
    if modified == cleaned:
        modified = f"{cleaned}\nLIMIT {limit}"
    return modified


@router.get(
    "/full-data",
    summary="Re-execute stored SQL without the 200-row cap",
    description=(
        "Looks up the SQL stored for a given chat turn, removes the LIMIT 200 "
        f"injected by the agent, and re-runs it with a safe ceiling of {FULL_DATA_SAFE_LIMIT} rows. "
        "Returns the same table_json format used by the chat stream so the frontend "
        "can render the full dataset without any extra parsing."
    ),
)
async def get_full_data(session_id: str, unique_chat_id: str):
    """
    1. Fetch sql_generated from ai_assistant_chat_history.
    2. Validate the row belongs to the given session_id.
    3. Strip LIMIT 200, apply LIMIT 5000.
    4. Execute via asyncpg.
    5. Return { unique_chat_id, session_id, row_count, table_json }.
    """
    # ── 1. Fetch stored SQL ───────────────────────────────────────────
    try:
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                text(f"""
                    SELECT sql_generated, session_id
                    FROM {CHAT_TABLE}
                    WHERE unique_chat_id = :chat_id
                    LIMIT 1
                """),
                {"chat_id": unique_chat_id},
            )
            row = result.fetchone()
    except Exception as e:
        logger.error(f"DB lookup failed for full-data request chat_id={unique_chat_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Database error while fetching stored SQL.")

    if not row:
        raise HTTPException(status_code=404, detail=f"Chat turn '{unique_chat_id}' not found.")

    stored_sql: str | None = row[0]
    stored_session: str = row[1]

    # ── 2. Validate ownership ─────────────────────────────────────────
    if stored_session != session_id:
        raise HTTPException(status_code=403, detail="session_id does not match this chat turn.")

    if not stored_sql or not stored_sql.strip():
        raise HTTPException(
            status_code=422,
            detail="This chat turn has no stored SQL (it was a general or clarification response).",
        )

    # ── 3. Apply safe limit ───────────────────────────────────────────
    safe_sql = _apply_safe_limit(stored_sql, FULL_DATA_SAFE_LIMIT)
    logger.info(
        f"Full-data request: chat_id={unique_chat_id} session_id={session_id}\n"
        f"Original SQL:\n{stored_sql}\n"
        f"Safe SQL (limit={FULL_DATA_SAFE_LIMIT}):\n{safe_sql}"
    )

    # ── 4. Execute ────────────────────────────────────────────────────
    try:
        conn = await asyncpg.connect(**DB_CONFIG)
        try:
            rows = await conn.fetch(safe_sql)
            if rows:
                columns = list(rows[0].keys())
                df = pd.DataFrame([dict(r) for r in rows], columns=columns)
            else:
                df = pd.DataFrame()
        finally:
            await conn.close()
    except Exception as e:
        logger.error(f"SQL execution failed for full-data chat_id={unique_chat_id}: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"SQL execution failed: {str(e)}")

    # ── 5. Return ─────────────────────────────────────────────────────
    table_json = df_to_table_json(df)
    return {
        "unique_chat_id": unique_chat_id,
        "session_id": session_id,
        "row_count": len(df),
        "table_json": table_json,
    }