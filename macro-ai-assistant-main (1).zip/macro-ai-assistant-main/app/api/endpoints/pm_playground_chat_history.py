"""
PM Playground Chat History endpoints
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import logging
from datetime import datetime
from typing import Optional, Any, List
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.database import get_db

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/playground/chat", tags=["PM Playground Chat History"])

SCHEMA = settings.db_schema
CHAT_TABLE = f"{SCHEMA}.pm_playground_chat_history"
SUB_TABLE = f"{SCHEMA}.pm_playground_sub_question_results"
FEEDBACK_TABLE = f"{SCHEMA}.pm_playground_feedback"


# ── Pydantic Schemas ──────────────────────────────────────────────────────────

class SubQuestionOut(BaseModel):
    sub_result_id: str
    question_index: int
    sub_question: str
    generated_sql: Optional[str] = None
    table_json: Optional[str] = None
    sql_success: Optional[bool] = None
    sql_error: Optional[str] = None
    charts_json: Optional[Any] = None
    created_at: datetime


class PlaygroundTurnOut(BaseModel):
    unique_chat_id: str
    session_id: str
    hitl_id: str
    username: str
    user_query: str
    enriched_query: Optional[str] = None
    project: str
    market: Optional[Any] = None
    region: Optional[Any] = None
    area: Optional[Any] = None
    vendors: Optional[Any] = None
    kpis: Optional[Any] = None
    date_start: Optional[str] = None
    date_end: Optional[str] = None
    keyword_names: Optional[Any] = None
    kpi_names_found: Optional[Any] = None
    qb_names: Optional[Any] = None
    query_type: Optional[str] = None
    ready_for_sql: Optional[bool] = None
    hitl_response: Optional[str] = None
    hitl_assisted_response: Optional[str] = None
    hitl_generic_response: Optional[str] = None
    sub_questions: Optional[Any] = None
    csv_final_table_json: Optional[str] = None
    csv_text_explanation: Optional[str] = None
    csv_agent_steps: Optional[str] = None
    final_charts_json: Optional[Any] = None
    status: str
    session_status_ui: Optional[bool] = None
    created_at: datetime
    sub_question_results: List[SubQuestionOut] = []


class PlaygroundHistoryResponse(BaseModel):
    session_id: str
    turns: List[PlaygroundTurnOut]


class FeedbackRequest(BaseModel):
    session_id: str
    unique_chat_id: str
    username: str
    rating: Optional[int] = Field(None, ge=1, le=5, description="1–5 numeric score")
    is_positive: Optional[bool] = Field(None, description="Thumbs up (True) / thumbs down (False)")
    comment: Optional[str] = None


# ── Helpers ───────────────────────────────────────────────────────────────────

def _parse_turn_row(r: dict) -> dict:
    """Normalise DB row: stringify UUID columns."""
    d = dict(r)
    for key in ("unique_chat_id", "hitl_id"):
        if d.get(key) is not None:
            d[key] = str(d[key])
    return d


def _parse_sub_row(r: dict) -> dict:
    d = dict(r)
    for key in ("sub_result_id", "unique_chat_id"):
        if d.get(key) is not None:
            d[key] = str(d[key])
    return d


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get(
    "/history/{session_id}",
    response_model=PlaygroundHistoryResponse,
    summary="Get PM Playground chat history for a session",
)
async def get_playground_history(
    session_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Return all turns for a session, each enriched with its sub-question results."""
    turn_rows = (
        await db.execute(
            text(f"""
                SELECT unique_chat_id, session_id, hitl_id, username,
                       user_query, enriched_query,
                       project, market, region, area, vendors, kpis,
                       date_start, date_end,
                       keyword_names, kpi_names_found, qb_names,
                       query_type, ready_for_sql,
                       hitl_response, hitl_assisted_response, hitl_generic_response,
                       sub_questions,
                       csv_final_table_json, csv_text_explanation, csv_agent_steps,
                       final_charts_json,
                       status, session_status_ui, created_at
                FROM {CHAT_TABLE}
                WHERE session_id = :session_id
                ORDER BY created_at ASC
            """),
            {"session_id": session_id},
        )
    ).mappings().all()

    if not turn_rows:
        return PlaygroundHistoryResponse(session_id=session_id, turns=[])

    chat_ids = [str(r["unique_chat_id"]) for r in turn_rows]

    sub_rows = (
        await db.execute(
            text(f"""
                SELECT sub_result_id, unique_chat_id,
                       question_index, sub_question,
                       generated_sql, table_json,
                       sql_success, sql_error, charts_json, created_at
                FROM {SUB_TABLE}
                WHERE unique_chat_id = ANY(:ids)
                ORDER BY unique_chat_id, question_index ASC
            """),
            {"ids": chat_ids},
        )
    ).mappings().all()

    # Group sub-rows by unique_chat_id
    subs_by_chat: dict[str, list] = {}
    for sr in sub_rows:
        cid = str(sr["unique_chat_id"])
        subs_by_chat.setdefault(cid, []).append(SubQuestionOut(**_parse_sub_row(sr)))

    turns = []
    for r in turn_rows:
        try:
            d = _parse_turn_row(r)
            d["sub_question_results"] = subs_by_chat.get(d["unique_chat_id"], [])
            turns.append(PlaygroundTurnOut(**d))
        except Exception as e:
            logger.error(f"Failed to parse playground turn: {e}", exc_info=True)
            raise HTTPException(status_code=500, detail=f"Data parsing error: {e}")

    return PlaygroundHistoryResponse(session_id=session_id, turns=turns)


@router.get(
    "/turn/{unique_chat_id}",
    response_model=PlaygroundTurnOut,
    summary="Get a single PM Playground turn by unique_chat_id",
)
async def get_playground_turn(
    unique_chat_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Return one turn with all its sub-question results."""
    row = (
        await db.execute(
            text(f"""
                SELECT unique_chat_id, session_id, hitl_id, username,
                       user_query, enriched_query,
                       project, market, region, area, vendors, kpis,
                       date_start, date_end,
                       keyword_names, kpi_names_found, qb_names,
                       query_type, ready_for_sql,
                       hitl_response, hitl_assisted_response, hitl_generic_response,
                       sub_questions,
                       csv_final_table_json, csv_text_explanation, csv_agent_steps,
                       final_charts_json,
                       status, session_status_ui, created_at
                FROM {CHAT_TABLE}
                WHERE unique_chat_id = :cid
            """),
            {"cid": unique_chat_id},
        )
    ).mappings().first()

    if not row:
        raise HTTPException(status_code=404, detail=f"Turn '{unique_chat_id}' not found")

    sub_rows = (
        await db.execute(
            text(f"""
                SELECT sub_result_id, unique_chat_id,
                       question_index, sub_question,
                       generated_sql, table_json,
                       sql_success, sql_error, charts_json, created_at
                FROM {SUB_TABLE}
                WHERE unique_chat_id = :cid
                ORDER BY question_index ASC
            """),
            {"cid": unique_chat_id},
        )
    ).mappings().all()

    d = _parse_turn_row(row)
    d["sub_question_results"] = [SubQuestionOut(**_parse_sub_row(sr)) for sr in sub_rows]
    return PlaygroundTurnOut(**d)


@router.get(
    "/sessions",
    summary="List PM Playground sessions",
)
async def list_playground_sessions(
    username: Optional[str] = Query(None, description="Filter by username"),
    limit: int = Query(20, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
):
    """Return the most recent playground sessions with first query and last activity."""
    where_clauses = ["session_status_ui = TRUE"]
    params: dict = {"lim": limit}
    if username:
        where_clauses.append("username = :username")
        params["username"] = username

    where = "WHERE " + " AND ".join(where_clauses)

    result = await db.execute(
        text(f"""
            SELECT s.session_id, s.username, s.project,
                   s.started_at, s.last_message_at, s.turn_count,
                   f.user_query AS first_user_query
            FROM (
                SELECT session_id, username, project,
                       MIN(created_at) AS started_at,
                       MAX(created_at) AS last_message_at,
                       COUNT(*) AS turn_count
                FROM {CHAT_TABLE}
                {where}
                GROUP BY session_id, username, project
            ) s
            INNER JOIN (
                SELECT DISTINCT ON (session_id)
                       session_id, user_query
                FROM {CHAT_TABLE}
                WHERE session_status_ui = TRUE
                ORDER BY session_id, created_at ASC
            ) f ON s.session_id = f.session_id
            ORDER BY s.last_message_at DESC
            LIMIT :lim
        """),
        params,
    )
    return [dict(r) for r in result.mappings().all()]


@router.patch(
    "/sessions/{session_id}/hide",
    summary="Hide a PM Playground session from the sessions list",
)
async def hide_playground_session(
    session_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Set session_status_ui = FALSE for all turns in this session."""
    result = await db.execute(
        text(f"""
            UPDATE {CHAT_TABLE}
            SET session_status_ui = FALSE
            WHERE session_id = :session_id
        """),
        {"session_id":session_id},
    )
    await db.commit()
    return {
        "status": "success",
        "session_id":session_id,
        "rows_updated":result.rowcount,
    }


@router.post(
    "/feedback",
    summary="Submit feedback for a PM Playground turn",
    status_code=201,
)
async def submit_playground_feedback(
    feedback: FeedbackRequest,
    db: AsyncSession = Depends(get_db),
):
    """Save thumbs-up/down, optional 1–5 rating, and free-text comment for a playground turn."""
    check = (
        await db.execute(
            text(f"SELECT 1 FROM {CHAT_TABLE} WHERE unique_chat_id = :cid"),
            {"cid": feedback.unique_chat_id},
        )
    ).fetchone()
    if not check:
        raise HTTPException(
            status_code=404,
            detail=f"Turn '{feedback.unique_chat_id}' not found",
        )
    feedback_id = str(uuid4())
    await db.execute(
        text(f"""
            INSERT INTO {FEEDBACK_TABLE}
                (feedback_id, session_id, unique_chat_id, username,
                 rating, is_positive, comment, created_at)
            VALUES
                (:feedback_id, :session_id, :unique_chat_id, :username,
                 :rating, :is_positive, :comment, :created_at)
        """),
        {
            "feedback_id": feedback_id,
            "session_id": feedback.session_id,
            "unique_chat_id": feedback.unique_chat_id,
            "username": feedback.username,
            "rating": feedback.rating,
            "is_positive": feedback.is_positive,
            "comment": feedback.comment,
            "created_at": datetime.utcnow(),
        },
    )
    await db.commit()
    return {"status": "saved", "feedback_id": feedback_id}
