import uuid
from datetime import datetime
from typing import Optional
from sqlalchemy import (
    ForeignKey,
    Integer,
    String,
    Text,
    DateTime,
    Boolean,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.db.database import Base
from app.core.config import settings


class PMPlaygroundUserUploadData(Base):
    """
    PM Playground User Upload Data Table: Stores user-uploaded data with session tracking.
    """
    __tablename__ = "pm_playground_user_upload_data"
    __table_args__ = {"schema": settings.db_schema}

    data_upload_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=lambda: str(uuid.uuid4())
    )

    session_id: Mapped[str] = mapped_column(
        String(255), nullable=False, index=True
    )

    table_json: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True, comment="JSON representation of the uploaded table data"
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )

    def __repr__(self) -> str:
        return (
            f"<PMPlaygroundUserUploadData(data_upload_id={self.data_upload_id}, "
            f"session_id='{self.session_id}')>"
        )


class PMPlaygroundChatHistory(Base):
    """
    PM Playground Chat History: One row per user query/turn.
    Captures the full pipeline: filters → search → HITL → splits → SQL → charts → CSV → final chart.
    """
    __tablename__ = "pm_playground_chat_history"
    __table_args__ = {"schema": settings.db_schema}

    unique_chat_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    session_id: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    hitl_id: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    username: Mapped[str] = mapped_column(String(255), nullable=False, index=True)

    user_query: Mapped[str] = mapped_column(Text, nullable=False)
    enriched_query: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    project: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    market: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    region: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    area: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    vendors: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    kpis: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    date_start: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    date_end: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)

    keyword_names: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    kpi_names_found: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    qb_names: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)

    query_type: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    ready_for_sql: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    hitl_response: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    hitl_assisted_response: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    hitl_generic_response: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    sub_questions: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)

    csv_final_table_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    csv_text_explanation: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    csv_agent_steps: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    final_charts_json: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)

    status: Mapped[str] = mapped_column(
        String(50), nullable=False, default="pending",
        comment="general_response | clarification | completed | completed_no_data | error"
    )
    session_status_ui: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )

    sub_question_results: Mapped[list["PMPlaygroundSubQuestionResult"]] = relationship(
        back_populates="chat_history", cascade="all, delete-orphan"
    )
    feedbacks: Mapped[list["PMPlaygroundFeedback"]] = relationship(
        back_populates="chat_history", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return (
            f"<PMPlaygroundChatHistory(unique_chat_id={self.unique_chat_id}, "
            f"session_id='{self.session_id}', status='{self.status}')>"
        )


class PMPlaygroundSubQuestionResult(Base):
    """
    PM Playground Sub-Question Results: One row per sub-question per turn (up to 3).
    Stores the SQL generated, the data returned, and the per-question Highchart.
    """
    __tablename__ = "pm_playground_sub_question_results"
    __table_args__ = {"schema": settings.db_schema}

    sub_result_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    unique_chat_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey(f"{settings.db_schema}.pm_playground_chat_history.unique_chat_id"),
        nullable=False,
        index=True,
    )
    session_id: Mapped[str] = mapped_column(String(255), nullable=False, index=True)

    question_index: Mapped[int] = mapped_column(Integer, nullable=False)
    sub_question: Mapped[str] = mapped_column(Text, nullable=False)

    generated_sql: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    table_json: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    sql_success: Mapped[Optional[bool]] = mapped_column(Boolean, nullable=True)
    sql_error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    charts_json: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )

    chat_history: Mapped["PMPlaygroundChatHistory"] = relationship(
        back_populates="sub_question_results"
    )

    def __repr__(self) -> str:
        return (
            f"<PMPlaygroundSubQuestionResult(sub_result_id={self.sub_result_id}, "
            f"question_index={self.question_index})>"
        )


class PMPlaygroundFeedback(Base):
    """
    PM Playground Feedback: Thumbs up/down + optional rating and comment per turn.
    """
    __tablename__ = "pm_playground_feedback"
    __table_args__ = {"schema": settings.db_schema}

    feedback_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    session_id: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    unique_chat_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey(f"{settings.db_schema}.pm_playground_chat_history.unique_chat_id"),
        nullable=False,
        index=True,
    )
    username: Mapped[str] = mapped_column(String(255), nullable=False, index=True)

    rating: Mapped[Optional[int]] = mapped_column(
        Integer, nullable=True, comment="1–5 numeric score"
    )
    is_positive: Mapped[Optional[bool]] = mapped_column(
        Boolean, nullable=True, comment="Thumbs up (TRUE) / thumbs down (FALSE)"
    )
    comment: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )

    chat_history: Mapped["PMPlaygroundChatHistory"] = relationship(
        back_populates="feedbacks"
    )

    def __repr__(self) -> str:
        return (
            f"<PMPlaygroundFeedback(feedback_id={self.feedback_id}, "
            f"unique_chat_id='{self.unique_chat_id}')>"
        )
