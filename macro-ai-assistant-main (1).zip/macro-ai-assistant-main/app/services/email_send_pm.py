"""
PM Playground Email Service — pure helper layer.
Provides HTML building, CSV attachment, and Nokia gateway send functions.
Consumed by app/api/endpoints/email_endpoints_pm.py.

Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import base64
import csv
import io
import json
import logging
import re
import requests
from datetime import datetime
from typing import Any, Dict, List, Optional

from app.core.config import settings

logger = logging.getLogger(__name__)

# ── Nokia Email Gateway ────────────────────────────────────────────────────────
AUTH_URL = "https://nokiaosdp-gsd-staging.aibi-americas-002.dyn.nesc.nokia.net/web/session/authenticate"
SEND_MAIL_URL = "https://nokiaosdp-gsd-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/send_mail"

_AUTH_PAYLOAD = {
    "jsonrpc": "2.0",
    "method": "call",
    "params": {
        "db": "postgres",
        "login": "pwc_osdp_user",
        "password": "pwc_osdp_user",
    },
}

SCHEMA = settings.db_schema
PM_CHAT_TABLE = f"{SCHEMA}.pm_playground_chat_history"
PM_SUB_TABLE = f"{SCHEMA}.pm_playground_sub_question_results"

NOKIA_COLORS = {
    "primary": "#005AFF",
    "light": "#E8F0FF",
    "alt_row": "#F5F8FF",
    "page_bg": "#F4F6F9",
    "footer": "#666666",
}


# ── Nokia Gateway ──────────────────────────────────────────────────────────────

def get_gateway_session() -> str:
    """Authenticate with Nokia mail gateway and return session cookie."""
    try:
        session = requests.Session()
        resp = session.post(AUTH_URL, json=_AUTH_PAYLOAD, timeout=15)
        resp.raise_for_status()
        sid = session.cookies.get("session_id")
        if not sid:
            raise RuntimeError("Nokia gateway did not return session_id cookie")
        return sid
    except Exception as e:
        logger.error(f"Nokia gateway auth failed: {e}")
        raise


def send_via_gateway(
    gateway_sid: str,
    to_list: List[str],
    cc_list: List[str],
    bcc_list: List[str],
    subject: str,
    body: str,
    attachments: List[Dict[str, str]],
) -> Dict[str, Any]:
    """Send email via Nokia mail gateway."""
    payload = {
        "params": {
            "tolist": to_list,
            "cclist": cc_list,
            "bcclist": bcc_list,
            "subject": subject,
            "body": body,
            "file": attachments,
        }
    }
    resp = requests.post(
        SEND_MAIL_URL,
        json=payload,
        headers={
            "Content-Type": "application/json",
            "Cookie": f"session_id={gateway_sid}",
        },
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


# ── HTML Helpers ───────────────────────────────────────────────────────────────

def escape_html(text: Any) -> str:
    if not text:
        return ""
    return (
        str(text)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


def markdown_to_html(text: str) -> str:
    if not text:
        return ""
    text = str(text)
    lines = text.split("\n")
    processed, in_list = [], False
    for line in lines:
        if re.match(r"^\s*[-*]\s+", line):
            if not in_list:
                processed.append("__LIST_START__")
                in_list = True
            item = re.sub(r"^\s*[-*]\s+", "", line)
            processed.append(f"__LIST_ITEM__{escape_html(item)}__END_LIST_ITEM__")
        else:
            if in_list:
                processed.append("__LIST_END__")
                in_list = False
            if line.strip():
                processed.append(f"__PARA__{escape_html(line)}__END_PARA__")
            else:
                processed.append("__BLANK__")
    if in_list:
        processed.append("__LIST_END__")
    text = "\n".join(processed)
    text = re.sub(r"\*\*([^\*]+)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"(?<!\*)\*([^\*]+)\*(?!\*)", r"<em>\1</em>", text)
    text = re.sub(
        r"`([^`]+)`",
        r'<code style="background:#f0f0f0;padding:2px 4px;border-radius:3px;'
        r'font-family:monospace;font-size:12px;">\1</code>',
        text,
    )
    text = text.replace("__LIST_START__", '<ul style="margin:10px 0;padding-left:20px;">')
    text = text.replace("__LIST_END__", "</ul>")
    text = text.replace("__LIST_ITEM__", "<li>")
    text = text.replace("__END_LIST_ITEM__", "</li>")
    text = text.replace("__PARA__", '<p style="margin:8px 0;line-height:1.6;">')
    text = text.replace("__END_PARA__", "</p>")
    text = text.replace("__BLANK__", "")
    return text


def json_table_html(table_json_str: Optional[str], limit: int = 50) -> str:
    """Render a table_json records string as an HTML table (capped at *limit* rows)."""
    if not table_json_str:
        return ""
    try:
        records = json.loads(table_json_str)
        if not records or not isinstance(records, list):
            return ""
        records = records[:limit]
        fields = list(records[0].keys())
        header = "".join(
            f'<th style="padding:8px;border:1px solid #ddd;'
            f'background:{NOKIA_COLORS["primary"]};color:white;text-align:left;">'
            f"{escape_html(f)}</th>"
            for f in fields
        )
        rows_html = ""
        for idx, rec in enumerate(records):
            bg = NOKIA_COLORS["alt_row"] if idx % 2 else "white"
            cells = "".join(
                f'<td style="padding:8px;border:1px solid #ddd;">'
                f"{escape_html(rec.get(f, ''))}</td>"
                for f in fields
            )
            rows_html += f'<tr style="background:{bg};">{cells}</tr>'
        return (
            f'<table style="width:100%;border-collapse:collapse;margin:12px 0;">'
            f"<thead><tr>{header}</tr></thead><tbody>{rows_html}</tbody></table>"
        )
    except Exception as e:
        logger.warning(f"Failed to render table_json: {e}")
        return '<p style="color:#d32f2f;">Unable to render table data.</p>'


def build_csv_attachment(table_json_str: str, filename: str) -> Optional[Dict[str, str]]:
    """Build a base64-encoded CSV attachment dict from a table_json records string."""
    try:
        records = json.loads(table_json_str)
        if not records or not isinstance(records, list):
            return None
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=list(records[0].keys()))
        writer.writeheader()
        writer.writerows(records)
        encoded = base64.b64encode(buf.getvalue().encode("utf-8")).decode("utf-8")
        return {"filename": filename, "filedata": encoded}
    except Exception as e:
        logger.warning(f"Failed to build CSV attachment '{filename}': {e}")
        return None


def badges_html(items: list, label: str) -> str:
    """Render a list of values as Nokia-blue pill badges with a label prefix."""
    if not items:
        return ""
    pills = "".join(
        f'<span style="background:{NOKIA_COLORS["light"]};color:{NOKIA_COLORS["primary"]};'
        f'padding:3px 8px;border-radius:12px;margin:2px;font-size:12px;display:inline-block;">'
        f"{escape_html(str(v))}</span>"
        for v in items
    )
    return (
        f'<div style="margin:6px 0;">'
        f'<strong style="color:{NOKIA_COLORS["primary"]};font-size:12px;">{label}:</strong> {pills}'
        f"</div>"
    )


def sub_questions_section_html(sub_rows: List[Dict[str, Any]]) -> str:
    """Build the Sub-Questions HTML block (SQL code + data table per sub-question)."""
    if not sub_rows:
        return ""
    blocks = []
    for row in sub_rows:
        idx = row.get("question_index", "")
        question = escape_html(row.get("sub_question", ""))
        sql = escape_html(row.get("generated_sql") or "")
        table = json_table_html(row.get("table_json"))
        success = row.get("sql_success", False)
        error = escape_html(row.get("sql_error") or "")

        sql_block = (
            f'<div style="background:#f5f5f5;padding:12px;'
            f'border-left:4px solid {NOKIA_COLORS["primary"]};border-radius:4px;margin:10px 0;">'
            f'<strong style="color:{NOKIA_COLORS["primary"]};">Generated SQL</strong>'
            f'<pre style="margin:8px 0;overflow-x:auto;font-family:monospace;font-size:11px;color:#333;">'
            f"{sql}</pre></div>"
        ) if sql else ""

        error_block = (
            f'<p style="color:#d32f2f;font-size:12px;">SQL Error: {error}</p>'
            if not success and error
            else ""
        )

        table_block = f'<div style="overflow-x:auto;">{table}</div>' if table else ""

        blocks.append(
            f'<div style="border:1px solid #e0e0e0;border-radius:6px;padding:15px;margin:12px 0;">'
            f'<div style="color:{NOKIA_COLORS["primary"]};font-weight:600;font-size:14px;margin-bottom:8px;">'
            f"Sub-Question {idx}</div>"
            f'<p style="margin:0 0 10px 0;line-height:1.6;">{question}</p>'
            f"{sql_block}{error_block}{table_block}"
            f"</div>"
        )
    return (
        '<div class="section"><div class="section-title">Sub-Question Results</div>'
        + "".join(blocks)
        + "</div>"
    )


def inline_charts_html(images: list) -> str:
    """Embed image attachments as base64 <img> tags in a Charts section."""
    if not images:
        return ""
    items = []
    for img in images:
        raw = img.data
        if "," in raw and raw.startswith("data:"):
            mime = raw.split(";")[0].split(":")[1]
            raw_b64 = raw.split(",", 1)[1]
        else:
            mime = "image/png"
            raw_b64 = raw
        label = escape_html(img.filename)
        items.append(
            f'<div style="margin-bottom:20px;text-align:center;">'
            f'<img src="data:{mime};base64,{raw_b64}" alt="{label}" '
            f'style="max-width:100%;height:auto;border:1px solid #e0e0e0;'
            f'border-radius:4px;display:block;margin:0 auto;" />'
            f'<p style="font-size:11px;color:#666;margin:4px 0 0 0;">{label}</p>'
            f"</div>"
        )
    return (
        '<div class="section"><div class="section-title">Charts</div>'
        + "".join(items)
        + "</div>"
    )


# ── Main HTML Builder ──────────────────────────────────────────────────────────

def build_playground_email(
    row: Dict[str, Any],
    sub_rows: List[Dict[str, Any]],
    custom_message: Optional[str] = None,
    images: Optional[list] = None,
) -> str:
    """
    Build a Nokia-blue HTML email from pm_playground_chat_history + sub-question rows.

    Args:
        row: Main turn dict from pm_playground_chat_history
        sub_rows: Ordered list of dicts from pm_playground_sub_question_results
        custom_message: Optional sender note (markdown supported)
        images: Optional list of ImageAttachment objects for inline charts

    Returns:
        HTML string suitable for the Nokia mail gateway body field
    """
    unique_chat_id = str(row.get("unique_chat_id", ""))
    session_id = str(row.get("session_id", ""))
    username = escape_html(row.get("username") or "Unknown")
    project = escape_html(row.get("project") or "")
    user_query = escape_html(row.get("user_query") or "")
    enriched_query = escape_html(row.get("enriched_query") or "")
    query_type = escape_html(row.get("query_type") or "")

    hitl_text = row.get("hitl_assisted_response") or row.get("hitl_generic_response") or ""
    hitl_html = markdown_to_html(hitl_text)

    csv_explanation = markdown_to_html(row.get("csv_text_explanation") or "")
    csv_table = json_table_html(row.get("csv_final_table_json"))

    def _parse_list(val: Any) -> list:
        if not val:
            return []
        if isinstance(val, list):
            return val
        try:
            return json.loads(val)
        except Exception:
            return [str(val)]

    market = _parse_list(row.get("market"))
    region = _parse_list(row.get("region"))
    area = _parse_list(row.get("area"))
    vendors = _parse_list(row.get("vendors"))
    kpis = _parse_list(row.get("kpis"))
    keyword_names = _parse_list(row.get("keyword_names"))

    created_at = row.get("created_at", datetime.utcnow())
    created_at_str = (
        created_at.strftime("%Y-%m-%d %H:%M:%S UTC")
        if isinstance(created_at, datetime)
        else str(created_at)
    )

    custom_section = (
        f'<div class="section" style="background:{NOKIA_COLORS["light"]};padding:15px;'
        f'border-left:4px solid {NOKIA_COLORS["primary"]};border-radius:4px;">'
        f'<div class="section-title">Sender Note</div>'
        f"<div>{markdown_to_html(custom_message)}</div></div>"
    ) if custom_message else ""

    filters_inner = (
        badges_html(market, "Market")
        + badges_html(region, "Region")
        + badges_html(area, "Area")
        + badges_html(vendors, "Vendors")
        + badges_html(kpis, "KPIs")
        + badges_html(keyword_names, "Keywords")
    )
    filters_section = (
        f'<div class="section"><div class="section-title">Selected Filters</div>'
        f"{filters_inner}</div>"
    ) if filters_inner else ""

    enriched_block = (
        f'<div style="font-size:12px;color:#666;margin-top:8px;padding:8px;'
        f'background:#fafafa;border-radius:4px;">'
        f"<strong>Enriched query:</strong> {enriched_query}</div>"
    ) if enriched_query and enriched_query != user_query else ""

    ai_section = (
        f'<div class="section"><div class="section-title">AI Analysis</div>'
        f'<div class="response-box">{hitl_html}</div></div>'
    ) if hitl_html else ""

    sub_section = sub_questions_section_html(sub_rows)

    csv_section = (
        f'<div class="section"><div class="section-title">CSV Synthesis Results</div>'
        + (f"<div>{csv_explanation}</div>" if csv_explanation else "")
        + (f'<div style="overflow-x:auto;">{csv_table}</div>' if csv_table else "")
        + "</div>"
    ) if (csv_explanation or csv_table) else ""

    charts_section = inline_charts_html(images or [])

    c = NOKIA_COLORS
    return f"""
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body {{ font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif; background:{c["page_bg"]}; margin:0; padding:0; color:#333; }}
            .container {{ max-width:850px; margin:0 auto; background:white; box-shadow:0 2px 4px rgba(0,0,0,.1); }}
            .header {{ background:{c["primary"]}; color:white; padding:28px 20px; text-align:center; }}
            .header h1 {{ margin:0; font-size:26px; font-weight:600; }}
            .header p {{ margin:4px 0 0 0; font-size:12px; opacity:.9; }}
            .meta-section {{ background:{c["page_bg"]}; padding:12px 20px; border-bottom:1px solid #e0e0e0; display:flex; gap:10px; flex-wrap:wrap; font-size:12px; }}
            .meta-badge {{ background:white; border:1px solid {c["primary"]}; color:{c["primary"]}; padding:5px 10px; border-radius:4px; font-weight:500; }}
            .content {{ padding:20px; }}
            .section {{ margin:20px 0; }}
            .section-title {{ color:{c["primary"]}; font-size:15px; font-weight:600; margin-bottom:10px; border-bottom:2px solid {c["primary"]}; padding-bottom:6px; }}
            .query-box {{ background:{c["light"]}; padding:14px; border-left:4px solid {c["primary"]}; border-radius:4px; line-height:1.6; }}
            .response-box {{ background:#f9f9f9; padding:14px; border-left:4px solid {c["primary"]}; border-radius:4px; line-height:1.6; }}
            .footer {{ background:{c["page_bg"]}; border-top:1px solid #e0e0e0; padding:18px 20px; text-align:center; font-size:12px; color:{c["footer"]}; }}
            table {{ width:100%; border-collapse:collapse; margin:12px 0; }}
            th {{ background:{c["primary"]}; color:white; padding:9px; border:1px solid #ddd; text-align:left; font-weight:bold; }}
            td {{ padding:9px; border:1px solid #ddd; }}
            tr:nth-child(even) {{ background:{c["alt_row"]}; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>PM Playground Analytics</h1>
                <p>Chat Summary | Nokia</p>
            </div>
            <div class="meta-section">
                <div class="meta-badge">Chat ID: <span style="color:#333;">{escape_html(unique_chat_id[:12])}...</span></div>
                <div class="meta-badge">Session: <span style="color:#333;">{escape_html(session_id[:8])}...</span></div>
                <div class="meta-badge">User: <span style="color:#333;">{username}</span></div>
                <div class="meta-badge">Project: <span style="color:#333;">{project}</span></div>
                <div class="meta-badge">Type: <span style="color:#333;">{query_type}</span></div>
                <div class="meta-badge">Date: <span style="color:#333;">{escape_html(created_at_str)}</span></div>
            </div>
            <div class="content">
                {custom_section}
                <div class="section">
                    <div class="section-title">Your Question</div>
                    <div class="query-box">{user_query}</div>
                    {enriched_block}
                </div>
                {filters_section}
                {ai_section}
                {sub_section}
                {csv_section}
                {charts_section}
            </div>
            <div class="footer">
                <p>Powered by <strong>PM Playground</strong> | Nokia</p>
                <p style="margin:4px 0 0 0;font-size:11px;">This email was automatically generated. Please do not reply.</p>
            </div>
        </div>
    </body>
    </html>
    """
