"""
Utilities for post-processing SQL result DataFrames before serialisation.
"""
from __future__ import annotations

import datetime
import logging
import re
from typing import Optional

import pandas as pd

logger = logging.getLogger(__name__)

# Column-name patterns that look numeric but are IDs / codes, not additive.
_SKIP_PATTERNS: tuple[str, ...] = (
    r"\bid\b",
    r"\bids\b",
    r"\bcode\b",
    r"\bcodes\b",
    r"\bkey\b",
    r"\bkeys\b",
    r"_id$",
    r"^id_",
    r"\bname\b",
    r"\bnames\b",
    r"\bdate\b",
    r"\byear\b",
    r"\bmonth\b",
    r"\bhour\b",
    r"\bday\b",
    r"\brank\b",
    r"\bindex\b",
    r"\bserial\b",
    r"\bnumber\b",
    r"\bno\b",
    r"\bcount_id\b",
    r"\bsite\b",
    r"\bcell\b",
    r"\bnci\b",
    r"\bci\b",
    r"\blac\b",
    r"\btac\b",
    r"\bearfcn\b",
    r"\bpci\b",
    r"\bgnb\b",
    r"\benb\b",
    r"\brnc\b",
    r"\bbsc\b",
    r"week"
)

_SKIP_RE = re.compile(
    "|".join(_SKIP_PATTERNS),
    flags=re.IGNORECASE,
)

# Columns where average is more meaningful than sum (SLA, rates, percentages).
_AVERAGE_PATTERNS: tuple[str, ...] = (
    r"\bsla\b",
    r"\brate\b",
    r"\bavg\b",
    r"\baverage\b",
    r"\bpct\b",
    r"\bpercent\b",
    r"%",
    r"\bscore\b",
    r"\bratio\b",
)

_AVERAGE_RE = re.compile(
    "|".join(_AVERAGE_PATTERNS),
    flags=re.IGNORECASE,
)

_LABEL_COL = "Total"  # value inserted into the first non-aggregated column


def _aggregation_type(col: str, series: pd.Series) -> str:
    """Return 'sum', 'avg', or 'skip' for a numeric column.

    Decision order:
      1. Name pattern → skip  (identifiers, dates, codes)
      2. Data: empty or constant column → skip
      3. Data: strictly sequential integers → skip  (row index / rank)
      4. Name pattern → avg  (rates, ratios, percentages)
      5. Data: float bounded in [0, 1] → avg  (ratio/proportion)
      6. Data: float bounded in (0, 100] with fractional values → avg  (percentage)
      7. Default → sum
    """
    # 1. Name-based skip
    if _SKIP_RE.search(col):
        return "skip"

    non_null = series.dropna()
    if non_null.empty:
        return "skip"

    # 2. Constant column — no meaningful aggregation
    if non_null.nunique() == 1:
        return "skip"

    # 3. Strictly sequential integers — row index or rank
    if pd.api.types.is_integer_dtype(series) and len(non_null) > 2:
        if (non_null.sort_values().diff().dropna() == 1).all():
            return "skip"

    # 4. Name-based avg
    if _AVERAGE_RE.search(col):
        return "avg"

    col_min = float(non_null.min())
    col_max = float(non_null.max())

    # 5. Float bounded in [0, 1] — ratio / proportion
    if pd.api.types.is_float_dtype(series) and col_min >= 0.0 and col_max <= 1.0:
        return "avg"

    # 6. Float bounded in (0, 100] with actual decimal places — percentage-like
    if (
        pd.api.types.is_float_dtype(series)
        and col_min >= 0.0
        and col_max <= 100.0
        and (non_null % 1 != 0).any()
    ):
        return "avg"

    return "sum"


def _round_to_col_precision(value: float, series: pd.Series) -> float:
    """Round value to the same decimal precision as the column (max 4 dp)."""
    max_dp = min(
        4,
        max(
            (len(str(v).rstrip("0").split(".")[-1]) for v in series.dropna() if "." in str(v)),
            default=2,
        ),
    )
    return round(value, max_dp)


def add_totals_row(df: pd.DataFrame) -> pd.DataFrame:
    """
    Append a summary row to *df*. Falls back to the original df on any error.

    Rules
    -----
    - Skipped when the frame has fewer than 2 data rows.
    - ID/code/date/week/month-like columns are excluded from the summary row.
    - Integer columns where every value is unique are treated as identifiers (skipped).
    - SLA, rate, percentage, ratio columns → show average.
    - All other numeric columns → show sum.
    - Non-aggregated columns get an empty string; the first one gets "Total".
    """
    try:
        if df is None or df.empty or len(df) < 2:
            return df

        # Don't double-total if the last row already has "Total" / "Grand Total"
        first_col = df.columns[0]
        last_val = str(df[first_col].iloc[-1]).strip().lower()
        if last_val in ("total", "grand total"):
            return df

        numeric_cols = df.select_dtypes(include="number").columns.tolist()
        if not numeric_cols:
            return df

        agg_map = {c: _aggregation_type(c, df[c]) for c in numeric_cols}
        if all(v == "skip" for v in agg_map.values()):
            return df

        totals: dict[str, object] = {}
        first_non_agg_set = False

        for col in df.columns:
            agg = agg_map.get(col, "skip")
            if agg == "sum":
                val = df[col].sum(skipna=True)
                if pd.api.types.is_float_dtype(df[col]):
                    val = _round_to_col_precision(float(val), df[col])
                totals[col] = val
            elif agg == "avg":
                val = df[col].mean(skipna=True)
                totals[col] = _round_to_col_precision(float(val), df[col])
            else:
                if not first_non_agg_set:
                    totals[col] = _LABEL_COL
                    first_non_agg_set = True
                else:
                    totals[col] = ""

        totals_row = pd.DataFrame([totals], columns=df.columns)
        result = pd.concat([df, totals_row], ignore_index=True)

        summed = [c for c, t in agg_map.items() if t == "sum"]
        averaged = [c for c, t in agg_map.items() if t == "avg"]
        logger.debug(
            "add_totals_row: summed=%s averaged=%s",
            summed,
            averaged,
        )
        return result

    except Exception:
        logger.warning("add_totals_row failed — returning original df", exc_info=True)
        return df


_ISO_TS_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}")


def _coerce_datetimes_to_date(df: pd.DataFrame) -> pd.DataFrame:
    """Convert datetime/timestamp columns to date-only string columns.

    Handles three cases:
    - datetime64 columns (TIMESTAMP/TIMESTAMPTZ DB columns via asyncpg)
    - object dtype with Python datetime.date/datetime objects (DATE DB columns via asyncpg after ::date cast)
    - object dtype with ISO timestamp strings (VARCHAR DB columns)

    Prevents to_json from emitting "2026-05-20T00:00:00.000" when only
    "2026-05-20" is needed. NaT becomes NaN → null in JSON.
    """
    dt64_cols = [c for c in df.columns if pd.api.types.is_datetime64_any_dtype(df[c])]

    date_obj_cols = []   # object dtype with Python date/datetime objects
    str_ts_cols = []     # object dtype with ISO timestamp strings

    for col in df.columns:
        if col in dt64_cols or df[col].dtype != object:
            continue
        sample = df[col].dropna().head(5)
        if len(sample) == 0:
            continue
        first = sample.iloc[0]
        if isinstance(first, datetime.date):  # covers datetime.datetime too (subclass)
            date_obj_cols.append(col)
        elif isinstance(first, str) and _ISO_TS_RE.match(first):
            str_ts_cols.append(col)

    if not dt64_cols and not date_obj_cols and not str_ts_cols:
        return df

    df = df.copy()
    for col in dt64_cols:
        df[col] = df[col].dt.strftime("%Y-%m-%d")
    for col in date_obj_cols:
        df[col] = df[col].apply(
            lambda v: v.strftime("%Y-%m-%d") if isinstance(v, datetime.date) else v
        )
    for col in str_ts_cols:
        df[col] = df[col].apply(lambda v: str(v)[:10] if pd.notna(v) and v else v)
    return df


def df_to_table_json(df: Optional[pd.DataFrame], *, with_totals: bool = True) -> str:
    """
    Serialize *df* to a JSON string (records orientation) ready for SSE /
    database storage.  Optionally appends a totals row.

    Returns an empty string when *df* is None or empty.
    """
    try:
        if df is None or df.empty:
            return ""
        df = _coerce_datetimes_to_date(df)
        out_df = add_totals_row(df) if with_totals else df
        return out_df.to_json(orient="records", date_format="iso")
    except Exception:
        logger.warning("df_to_table_json failed — falling back to plain serialisation", exc_info=True)
        try:
            return df.to_json(orient="records", date_format="iso")
        except Exception:
            logger.error("df_to_table_json plain fallback also failed", exc_info=True)
            return ""
