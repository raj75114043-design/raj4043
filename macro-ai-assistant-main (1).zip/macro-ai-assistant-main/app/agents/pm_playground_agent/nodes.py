"""
PM Playground Agent – Node implementations.
"""

import logging
import time
from datetime import datetime
from langchain_core.output_parsers import JsonOutputParser, StrOutputParser
from langchain_core.prompts import PromptTemplate

from .state import PlaygroundAgentState
from .config import llm
from .prompts import QuerySplit, QUERY_SPLIT_PROMPT

logger = logging.getLogger(__name__)


# ── Helper functions ──────────────────────────────────────────────

def _now_iso() -> str:
    """Return current UTC time as ISO string."""
    return datetime.utcnow().isoformat()


def _merge_ts(existing: dict, node: str, start: float, end: float, dur: float) -> dict:
    """Merge timing data immutably into node_timestamps dict."""
    new_ts = existing.copy()
    new_ts[node] = {
        "start": start,
        "end": end,
        "duration_s": dur,
    }
    return new_ts


# ── Node functions ────────────────────────────────────────────────

async def split_query(state: PlaygroundAgentState) -> PlaygroundAgentState:
    """
    Split user query into 1-3 sub-questions.

    Each sub-question includes project context and is independent.
    """
    node_start = time.time()

    try:
        # Prepare prompt variables
        parser = JsonOutputParser(pydantic_object=QuerySplit)
        format_instructions = parser.get_format_instructions()

        prompt = PromptTemplate(
            template=QUERY_SPLIT_PROMPT,
            input_variables=["project", "dropdown_context", "search_context", "user_query"],
            partial_variables={"format": format_instructions},
        )

        # Build chain
        chain = prompt | llm | StrOutputParser() | parser

        # Invoke
        result = await chain.ainvoke(
            {
                "project": state["project"],
                "dropdown_context": state["dropdown_context"],
                "search_context": state.get("search_context") or "No context retrieved.",
                "user_query": state["user_query"],
            },
            config={"run_name": "split_query"},
        )

        # Extract sub_questions
        sub_questions = result.get("sub_questions", [])

        # Validate: 1-3 items
        if not sub_questions:
            logger.warning("Query splitting returned no sub-questions; using original query")
            sub_questions = [state["user_query"]]
        elif len(sub_questions) > 3:
            logger.warning(f"Query splitting returned {len(sub_questions)} questions; truncating to 3")
            sub_questions = sub_questions[:3]

        # Ensure each sub-question includes all filter context
        for i, q in enumerate(sub_questions):
            # Build filter suffix to append to each sub-question
            filter_parts = [f"Project: {state['project']}"]

            # Add geographic filters
            if state.get("region"):
                filter_parts.append(f"Regions: {', '.join(state['region'])}")
            if state.get("area"):
                filter_parts.append(f"Areas: {', '.join(state['area'])}")
            if state.get("market"):
                filter_parts.append(f"Markets: {', '.join(state['market'])}")

            # Add vendor filters
            if state.get("vendors"):
                filter_parts.append(f"Vendors: {', '.join(state['vendors'])}")

            # Add KPI filters
            if state.get("kpis"):
                filter_parts.append(f"KPIs: {', '.join(state['kpis'])}")

            filter_context = " | ".join(filter_parts)
            sub_questions[i] = f"{q} [{filter_context}]"

        node_end = time.time()
        duration = node_end - node_start

        logger.info(
            f"Query split into {len(sub_questions)} sub-questions in {duration:.2f}s: "
            f"{sub_questions}"
        )

        return {
            **state,
            "sub_questions": sub_questions,
            "node_timestamps": _merge_ts(
                state.get("node_timestamps", {}),
                "split_query",
                node_start,
                node_end,
                duration,
            ),
        }

    except Exception as e:
        logger.error(f"Query splitting failed: {e}", exc_info=True)
        # Fallback: return original query as single sub-question with all filter context
        filter_parts = [f"Project: {state['project']}"]
        if state.get("region"):
            filter_parts.append(f"Regions: {', '.join(state['region'])}")
        if state.get("area"):
            filter_parts.append(f"Areas: {', '.join(state['area'])}")
        if state.get("market"):
            filter_parts.append(f"Markets: {', '.join(state['market'])}")
        if state.get("vendors"):
            filter_parts.append(f"Vendors: {', '.join(state['vendors'])}")
        if state.get("kpis"):
            filter_parts.append(f"KPIs: {', '.join(state['kpis'])}")

        filter_context = " | ".join(filter_parts)
        sub_questions = [f"{state['user_query']} [{filter_context}]"]
        node_end = time.time()
        duration = node_end - node_start

        return {
            **state,
            "sub_questions": sub_questions,
            "node_timestamps": _merge_ts(
                state.get("node_timestamps", {}),
                "split_query",
                node_start,
                node_end,
                duration,
            ),
        }
