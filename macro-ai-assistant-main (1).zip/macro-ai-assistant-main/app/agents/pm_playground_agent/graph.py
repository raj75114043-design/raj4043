"""
PM Playground Agent – LangGraph graph assembly and public entry point.

Splits a user query into 1-3 sub-questions for independent analysis.
"""

import logging
from langgraph.graph import END, StateGraph

from .state import PlaygroundAgentState
from .nodes import split_query

logger = logging.getLogger(__name__)


# ── Graph assembly ────────────────────────────────────────────────

def build_graph():
    """Assemble the PM Playground query splitting graph."""
    g = StateGraph(PlaygroundAgentState)

    # Single node: split_query
    g.add_node("split_query", split_query)

    # Entry and edge
    g.set_entry_point("split_query")
    g.add_edge("split_query", END)

    return g.compile()


graph = build_graph()


# ── Public entry point ────────────────────────────────────────────

async def run_playground_agent(
    user_query: str,
    project: str,
    market: list[str] | None = None,
    region: list[str] | None = None,
    area: list[str] | None = None,
    vendors: list[str] | None = None,
    kpis: list[str] | None = None,
    keyword_names: list[str] | None = None,
    kpi_names: list[str] | None = None,
    qb_names: list[str] | None = None,
) -> dict:
    """
    Run the PM Playground query splitting agent.

    Splits a user query into 1-3 sub-questions grounded in retrieved search context.
    Sub-Q1 is always anchored to the user's original question.

    Args:
        user_query: Original user question
        project: Project code (NTM, NAS, AHLO-A)
        market: Selected markets (max 3)
        region: Selected regions (max 3)
        area: Selected areas (max 3)
        vendors: Selected vendors/construction status (max 3)
        kpis: Selected KPIs (max 3)
        keyword_names: Retrieved keyword names from semantic search
        kpi_names: Retrieved KPI names from semantic search
        qb_names: Retrieved question bank questions from semantic search

    Returns:
        dict with keys:
          - sub_questions: list[str] — 1-3 sub-questions, each with full filter context
          - node_timestamps: dict — per-node timing
    """

    # Build dropdown context string
    dropdown_context = f"Project: {project}"
    if region:
        dropdown_context += f"\nRegions: {', '.join(region)}"
    if area:
        dropdown_context += f"\nAreas: {', '.join(area)}"
    if market:
        dropdown_context += f"\nMarkets: {', '.join(market)}"
    if vendors:
        dropdown_context += f"\nVendors: {', '.join(vendors)}"
    if kpis:
        dropdown_context += f"\nKPIs: {', '.join(kpis)}"

    # Build search context string from retrieved results
    search_parts = []
    if keyword_names:
        search_parts.append(f"Retrieved Keywords: {', '.join(keyword_names)}")
    if kpi_names:
        search_parts.append(f"Retrieved KPIs: {', '.join(kpi_names)}")
    if qb_names:
        search_parts.append(f"Related Questions from Knowledge Base:\n" + "\n".join(f"  - {q}" for q in qb_names))
    search_context = "\n".join(search_parts) if search_parts else "No context retrieved."

    # Build initial state
    initial_state: PlaygroundAgentState = {
        "user_query": user_query,
        "project": project,
        "market": market or [],
        "region": region or [],
        "area": area or [],
        "vendors": vendors or [],
        "kpis": kpis or [],
        "dropdown_context": dropdown_context,
        "search_context": search_context,
        "sub_questions": [],
        "node_timestamps": {},
    }

    # Run graph
    final = await graph.ainvoke(initial_state)

    return {
        "sub_questions": final.get("sub_questions", []),
        "node_timestamps": final.get("node_timestamps", {}),
    }
