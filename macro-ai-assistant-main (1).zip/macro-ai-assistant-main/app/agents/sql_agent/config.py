"""
SQL Agent – Configuration
All values sourced from app.core.config.settings (loaded from .env).
"""

from langchain_openai import ChatOpenAI
from app.core.config import settings

# ── Database (asyncpg direct connection for SQL execution) ────────

DB_CONFIG = {
    "host": settings.db_host,
    "port": settings.db_port,
    "user": settings.db_user,
    "password": settings.db_password,
    "database": settings.db_name,
    "server_settings": {"search_path": f"{settings.db_schema_staging},public"},
}

# ── External API endpoints (Global Context Layer) ─────────────────

SCHEMA_WORLD_VIEW_API = settings.schema_world_view_api
WORLD_VIEW_AUTH = ("Any_string", settings.world_view_auth_password)

# ── Retry budget ──────────────────────────────────────────────────

MAX_SQL_RETRIES = 3

# ── LLM instances ─────────────────────────────────────────────────

_common_headers = {
    "api-key": settings.llm_api_key,
    "workspacename": settings.workspace_name,
}

llm_gpt = ChatOpenAI(
    api_key="NONE",
    model="gpt-5-mini",
    base_url=settings.llm_gateway_link,
    default_headers=_common_headers,
    temperature=0,
    verbose=True,
    reasoning_effort="medium",
    timeout=360,
)

llm_o3m = ChatOpenAI(
    api_key="NONE",
    model="o3-mini",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
    timeout=120,
)



llm_o4m = ChatOpenAI(
    api_key="NONE",
    model="o4-mini",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
    timeout=360,
)

llm_52 = ChatOpenAI(
    api_key="NONE",
    model="gpt-5.2",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
    reasoning_effort="medium",
    timeout=360,
)

llm_claude = ChatOpenAI(
    api_key="NONE",
    model="claude-haiku-4-5",
    base_url=settings.llm_gateway_link,
    default_headers=_common_headers,
    temperature=0,
    verbose=True,
    timeout=360,
)

llm_claude_sonnet = ChatOpenAI(
    api_key="NONE",
    model="claude-sonnet-4-6",
    base_url=settings.llm_gateway_link,
    default_headers=_common_headers,
    temperature=0,
    verbose=True,
    timeout=360,
)



# Default (backwards-compatible alias)
llm = llm_gpt

# ── LLM registry ──────────────────────────────────────────────────

LLM_REGISTRY: dict[str, ChatOpenAI] = {
    "gpt-5-mini": llm_gpt,
    "gpt-5.2": llm_52,
    "claude-haiku-4-5": llm_claude,
    "claude-sonnet-4-6":llm_claude_sonnet,
    "o3-mini":llm_o3m,
    "o4-mini": llm_o4m,
}

DEFAULT_LLM_NAME = "gpt-5-mini"


def get_llm(name: str | None = None) -> ChatOpenAI:
    """Return the LLM instance for the given name. Falls back to default."""
    return LLM_REGISTRY.get((name or DEFAULT_LLM_NAME).strip(), llm_gpt)