"""
CSV Agent – Configuration
All values sourced from app.core.config.settings (loaded from .env).
"""

from typing import Optional
from langchain_openai import ChatOpenAI
from pydantic import BaseModel, Field
from app.core.config import settings

# ── Database (asyncpg direct connection for data operations) ─────────

DB_CONFIG = {
    "host": settings.db_host,
    "port": settings.db_port,
    "user": settings.db_user,
    "password": settings.db_password,
    "database": settings.db_name,
    "server_settings": {"search_path": f"{settings.db_schema_staging},public"},
}

# ── Retry budget ──────────────────────────────────────────────────

MAX_RETRIES = 3

# ── LLM ───────────────────────────────────────────────────────────

llm = ChatOpenAI(
    api_key="NONE",
    model="gpt-5-mini",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
    reasoning_effort="medium",
    timeout=360,
)

llm_52 = ChatOpenAI(
    api_key="NONE",
    model="gpt-5.2",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
    reasoning_effort="medium",
    timeout=360,
)

_common_headers = {
    "api-key": settings.llm_api_key,
    "workspacename": settings.workspace_name,
}

llm_claude_sonnet = ChatOpenAI(
    api_key="NONE",
    model="claude-sonnet-4-6",
    base_url=settings.llm_gateway_link,
    default_headers=_common_headers,
    temperature=0,
    verbose=True,
    timeout=360,
)

llm_4o = ChatOpenAI(
    api_key="NONE",
    model="gpt-4o-mini",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
    timeout=120,
)

llm_o3m = ChatOpenAI(
    api_key="NONE",
    model="o3-mini",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
    timeout=120,
)


llm_claude = ChatOpenAI(
    api_key="NONE",
    model="claude-haiku-4-5",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
    timeout=360,
)

# ── LLM registry ──────────────────────────────────────────────────

LLM_REGISTRY: dict[str, ChatOpenAI] = {
    "gpt-5-mini": llm,
    "gpt-5.2": llm_52,
    "gpt-4o-mini": llm_4o,
    "claude-haiku-4-5": llm_claude,
    "claude-sonnet-4-6": llm_claude_sonnet,
    "o3-mini":llm_o3m,
}

DEFAULT_LLM_NAME = "gpt-5-mini"


def get_llm(name: str | None = None) -> ChatOpenAI:
    """Return the LLM instance for the given name. Falls back to default."""
    return LLM_REGISTRY.get((name or DEFAULT_LLM_NAME).strip(), llm)



# ── CSV Agent Specific Settings ──────────────────────────────────────


class CSVAgentConfig(BaseModel):
    """Configuration for CSV Agent"""

    # Execution Settings
    max_retries: int = Field(default=MAX_RETRIES, description="Maximum code generation retries on error")
    execution_timeout: int = Field(default=30, description="Code execution timeout in seconds")

    # DataFrame Settings
    max_dataframes: int = Field(default=10, description="Maximum number of dataframes to process")
    max_output_rows: int = Field(default=200, description="Maximum rows in output dataframe")

    # EDA Settings
    eda_sample_size: int = Field(default=5, description="Number of rows for head/tail in EDA")
    eda_categorical_threshold: int = Field(default=10, description="Threshold for categorical columns")
    eda_include_correlation: bool = Field(default=True, description="Include correlation matrix in EDA")

    # Output Settings
    generate_text_explanation: bool = Field(default=True, description="Generate text explanation of results")
    include_code_in_response: bool = Field(default=True, description="Include generated code in response")

    # Safety Settings
    allow_imports: bool = Field(default=True, description="Allow import statements in generated code")
    sandbox_execution: bool = Field(default=True, description="Execute code in sandboxed environment")

    class Config:
        frozen = False


# Default configuration instance
DEFAULT_CSV_AGENT_CONFIG = CSVAgentConfig()


def get_csv_agent_config() -> CSVAgentConfig:
    """Get default CSV agent configuration"""
    return DEFAULT_CSV_AGENT_CONFIG
