"""

CSV Agent – Nodes
LangGraph nodes for CSV/DataFrame analysis.

"""

import asyncio
import logging
from typing import Dict, Any

from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser, StrOutputParser
from langchain_core.runnables import RunnableLambda
from pydantic import BaseModel, Field

from app.agents.csv_agent.state import CSVAgentState
from app.agents.csv_agent.config import llm_4o, MAX_RETRIES, get_llm, llm_52 , llm_claude_sonnet
from app.agents.csv_agent.prompts import (
    get_python_generation_prompt,
    get_error_correction_prompt,
    get_text_output_prompt
)
from app.agents.csv_agent.tools import (
    python_repl_tool,
    safe_parse_json,
    strip_think_and_nonjson,
    eda_summary
)

logger = logging.getLogger(__name__)


# Pydantic model for Python code output
class PythonGeneration(BaseModel):
    """Python Code"""
    python_code: str = Field(description="Only include the code and nothing else in output")


class TextAnalysis(BaseModel):
    """Text analysis output"""
    text_analysis: str = Field(description="Markdown analytical report")


def python_generate(state: CSVAgentState) -> Dict[str, Any]:
    """
    Generate Python code based on user query and data schema.
    Uses centralized LLM from config.
    """
    logger.info("Generating Python code")

    try:
        # Extract state variables
        user_query = state["user_query"][-1].content if hasattr(state["user_query"][-1], 'content') else state["user_query"][-1].get("content", "")
        user_context = state["user_provided_context"][-1].content if hasattr(state["user_provided_context"][-1], 'content') else state["user_provided_context"][-1].get("content", "")
        chat_history = state["chat_history"][-1].content if hasattr(state["chat_history"][-1], 'content') else state["chat_history"][-1].get("content", "")
        final_schema = state["full_schema"][-1].content if hasattr(state["full_schema"][-1], 'content') else state["full_schema"][-1].get("content", "")
        error_message = state["tool_error"][-1] if state["tool_error"] else ""

        # Setup chain components
        stripper = RunnableLambda(strip_think_and_nonjson)
        parser = JsonOutputParser(pydantic_object=PythonGeneration)
        format_instructions = parser.get_format_instructions()

        # Choose prompt based on error state
        if not error_message:
            # Default prompt - first attempt
            prompt_template = get_python_generation_prompt()
            prompt = PromptTemplate(
                template=prompt_template,
                input_variables=["query", "final_schema", "user_context", "chat_history"],
                partial_variables={"format": format_instructions}
            )

            chain = prompt | get_llm(state.get("llm_name")) | stripper | parser
            python_code_output = chain.invoke({
                "query": user_query,
                "chat_history": chat_history,
                "final_schema": final_schema,
                "user_context": user_context
            })
        else:
            # Error correction prompt - retry with error info
            python_code = state["python_output"][-1]
            prompt_template = get_error_correction_prompt()
            prompt = PromptTemplate(
                template=prompt_template,
                input_variables=["final_schema", "query", "user_context", "python_code", "error"],
                partial_variables={"format": format_instructions}
            )

            chain = prompt | get_llm(state.get("llm_name")) | stripper | parser
            python_code_output = chain.invoke({
                "query": user_query,
                "final_schema": final_schema,
                "python_code": python_code,
                "error": error_message,
                "user_context": user_context
            })

        # Parse output
        parsed_output = safe_parse_json(python_code_output)
        python_code = parsed_output.get("python_code", "")
        logger.info("Python code generation successful")

    except Exception as e:
        logger.exception("Error generating Python code")
        python_code = f"# Error: {str(e)}"

    return {"python_output": [python_code]}


def final_output(state: CSVAgentState) -> Dict[str, Any]:
    """
    Execute generated Python code and capture results.
    """
    logger.info("Executing generated Python code")

    try:
        df_list = state['df']
        python_code = state["python_output"][-1]

        logger.debug(f"Generated code: {python_code[:100]}...")

        # Execute code using Python REPL
        result, result_df, df_error_msg = python_repl_tool(df_list, python_code)

        if df_error_msg:
            logger.warning(f"Code execution error: {df_error_msg}")
        else:
            logger.info("Code execution successful")

        return {
            "tool_error": [df_error_msg],
            "output_data": [result],
            "output_df": [result_df]
        }
    except Exception:
        logger.exception("Error executing Python code")
        return {
            "tool_error": ["Failed to execute code"],
            "output_data": [None],
            "output_df": [None]
        }


def feedback_decider(state: CSVAgentState) -> bool:
    """
    Decide whether to retry code generation based on errors.
    Returns True if should retry, False if should end.
    Max retries: MAX_RETRIES (from config).
    """
    # Retrieve the most recent error message
    error_message = state["tool_error"][-1] if state["tool_error"] else ""

    # Check if error_message is empty
    if not error_message:
        logger.info("No error detected, proceeding to end")
        return False  # No error, proceed to END

    # Check if max retries exceeded
    retry_count = len(state["tool_error"]) - 1  # -1 because first error is attempt 1
    if retry_count >= MAX_RETRIES:
        logger.warning(f"Max retries ({MAX_RETRIES}) exceeded")
        return False  # Max retries reached, proceed to END

    # If there is an error and retries remain, retry
    logger.info(f"Error detected, retrying (attempt {retry_count + 1}/{MAX_RETRIES})")
    return True


def text_final_output(user_query: str, python_code: str, data_df, chat_history: str) -> str:
    """
    Generate final text explanation of the analysis results.
    Uses centralized LLM from config.
    """
    try:
        logger.info("Generating text explanation")

        # Generate EDA summary
        eda_analysis = eda_summary(data_df)

        # Create prompt
        prompt_template = get_text_output_prompt()
        prompt = PromptTemplate(
            template=prompt_template,
            input_variables=["query", "python_code", "eda_analysis", "chat_history"]
        )

        parser = StrOutputParser()
        chain = prompt | llm_claude_sonnet | parser

        final_text_output = chain.invoke({
            "query": user_query,
            "chat_history": chat_history,
            "eda_analysis": eda_analysis,
            "python_code": python_code
        })

        logger.info("Text explanation generation successful")
        return final_text_output
    except Exception:
        logger.exception("Error generating text explanation")
        return "Analysis complete. Results shown above."


# ==================== NEW: PARALLEL EXPLANATION NODES ====================

def generate_text_explanation_node(state: CSVAgentState) -> Dict[str, Any]:
    """
    Generate natural language explanation of analysis results.
    Runs in parallel with agent_steps_explanation_node.
    Uses centralized LLM from config.
    """
    logger.info("Generating text explanation node")

    try:
        # Extract state
        user_query_content = state["user_query"][-1].content if hasattr(state["user_query"][-1], 'content') else state["user_query"][-1].get("content", "")
        chat_history_content = state["chat_history"][-1].content if hasattr(state["chat_history"][-1], 'content') else state["chat_history"][-1].get("content", "")
        python_code = state["python_output"][-1]
        data_df = state["output_df"][-1] if state["output_df"] else None

        if data_df is None or data_df.empty:
            logger.warning("No data available to explain")
            return {"text_explanation": ["No data available to explain."]}

        # Generate EDA summary
        eda_analysis = eda_summary(data_df)

        # Create prompt
        prompt_template = get_text_output_prompt()
        prompt = PromptTemplate(
            template=prompt_template,
            input_variables=["query", "python_code", "eda_analysis", "chat_history"]
        )

        stripper = RunnableLambda(strip_think_and_nonjson)
        parser = JsonOutputParser(pydantic_object=TextAnalysis)
        chain = prompt | llm_52 | stripper | parser

        result = chain.invoke({
            "query": user_query_content,
            "chat_history": chat_history_content,
            "eda_analysis": eda_analysis,
            "python_code": python_code
        })

        explanation = result.get("text_analysis", "") if isinstance(result, dict) else str(result)
        logger.info("Text explanation node completed")
        return {"text_explanation": [explanation]}
    except Exception as e:
        import traceback
        tb = traceback.format_exc()
        logger.error("=" * 60)
        logger.error("TEXT EXPLANATION NODE FAILED")
        logger.error(f"Exception type : {type(e).__name__}")
        logger.error(f"Exception msg  : {e}")
        logger.error(f"Traceback:\n{tb}")
        logger.error("=" * 60)
        print("=" * 60)
        print("TEXT EXPLANATION NODE FAILED")
        print(f"Exception type : {type(e).__name__}")
        print(f"Exception msg  : {e}")
        print(tb)
        print("=" * 60)
        return {"text_explanation": [f"Analysis complete. Results shown above. Exception msg :{e}"]}


def generate_agent_steps_explanation_node(state: CSVAgentState) -> Dict[str, Any]:
    """
    Generate business-friendly explanation of agent workflow steps.
    Runs in parallel with text_explanation_node.
    Uses centralized LLM from config.
    """
    logger.info("Generating agent steps explanation node")

    try:
        # Extract python code (the agent's output/steps)
        python_code = state["python_output"][-1]

        # Agent steps explanation prompt
        template = """
You are a business analyst translator. Your role is to explain technical data analysis operations to business users in clear, professional language.

Context:
An AI agent has executed data analysis operations (Python code or SQL queries) to answer a business question. The business user needs to understand what was done and why, without technical jargon.

Agent's Output:
{AgentOutput}

Your Task:
Analyze the agent's actions and provide a clear, professional explanation following this structure:

1. **What was requested**: Briefly state what question or task the user asked for
2. **What was done**: Explain the key operations performed (e.g., "filtered the data", "calculated totals", "joined datasets", "aggregated by category")
3. **How it was done**: Describe the logical steps taken, using business terms instead of technical terms:
   - Instead of "GROUP BY": say "grouped the records by..."
   - Instead of "JOIN": say "combined data from multiple tables..."
   - Instead of "WHERE clause": say "filtered to include only..."
   - Instead of "SUM/AVG": say "calculated the total/average..."
   - Instead of "pandas merge": say "matched and combined records..."
4. **Result**: Explain what output was produced and what it means for the user

Guidelines:
- Use professional, conversational business language
- Avoid technical terms like "dataframe", "function", "variable", "iteration"
- Do NOT use emojis or casual language
- Keep explanations concise but complete (3-5 sentences per step)
- Focus on the business logic, not the technical implementation
- If SQL was used, explain the data retrieval strategy
- If Python was used, explain the data manipulation approach
- Use bullet points for multi-step processes

Example tone: "The analysis filtered your sales data to show only transactions from Q1 2024, then calculated the total revenue for each product category. This helps identify which product lines generated the most income during that period."

Provide your explanation:
"""

        prompt = PromptTemplate(
            template=template,
            input_variables=["AgentOutput"]
        )

        parser = StrOutputParser()
        chain = prompt | llm_4o | parser

        explanation = chain.invoke({"AgentOutput": python_code})

        logger.info("Agent steps explanation node completed")
        return {"agent_steps_explanation": [explanation]}
    except Exception:
        logger.exception("Error generating agent steps explanation node")
        return {"agent_steps_explanation": ["Analysis steps completed successfully."]}


async def parallel_explanations_node(state: CSVAgentState) -> Dict[str, Any]:
    """
    Execute both text explanation and agent steps explanation in parallel.
    This is the main parallel node that combines both outputs.
    
    Uses asyncio to run both LLM calls concurrently for better performance.
    """
    import asyncio

    # Create tasks for parallel execution
    text_task = asyncio.create_task(
        asyncio.to_thread(generate_text_explanation_node, state)
    )
    steps_task = asyncio.create_task(
        asyncio.to_thread(generate_agent_steps_explanation_node, state)
    )

    # Wait for both to complete
    text_result, steps_result = await asyncio.gather(text_task, steps_task)

    # Combine results
    return {
        "text_explanation": text_result["text_explanation"],
        "agent_steps_explanation": steps_result["agent_steps_explanation"]
    }


# For synchronous execution (fallback)
def parallel_explanations_node_sync(state: CSVAgentState) -> Dict[str, Any]:
    """
    Synchronous version of parallel explanations.
    Executes sequentially if async is not available.
    """
    text_result = generate_text_explanation_node(state)
    steps_result = generate_agent_steps_explanation_node(state)

    return {
        "text_explanation": text_result["text_explanation"],
        "agent_steps_explanation": steps_result["agent_steps_explanation"]
    }
