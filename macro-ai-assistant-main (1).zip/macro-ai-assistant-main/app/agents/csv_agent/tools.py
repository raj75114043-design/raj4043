"""
CSV Agent Tools

Contains tools for code execution and DataFrame processing.
Based on: tools/new_df_agent.py
"""

import re
import json
import warnings
import pandas as pd
import numpy as np
from typing import List, Tuple, Dict, Any
from ast import literal_eval
import datetime
import math
import collections
import itertools
import functools
import operator

try:
    from langchain_experimental.utilities import PythonREPL
except ImportError:
    PythonREPL = None


def strip_think_and_nonjson(text: str) -> str:
    """Remove <think>...</think> and text before first '{'"""
    if hasattr(text, "content"):
        text = text.content
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)
    text = text.strip()
    first_brace = text.find('{')
    if first_brace != -1:
        return text[first_brace:]
    return text


def parse_partial_json(json_str: str) -> Dict[str, Any]:
    """Parse JSON string with error recovery"""
    json_str = re.sub(r"<think>.*?</think>", "", json_str, flags=re.DOTALL)
    json_str = json_str.strip()
    first_brace = json_str.find('{')
    last_brace = json_str.rfind('}')
    if first_brace != -1 and last_brace != -1:
        json_str = json_str[first_brace:last_brace+1]
    json_str = re.sub(r',\s*([}\]])', r'\1', json_str)
    try:
        return json.loads(json_str)
    except json.JSONDecodeError:
        if not json_str.endswith('}'):
            json_str += '}'
        try:
            return json.loads(json_str)
        except Exception as e:
            try:
                return literal_eval(json_str)
            except Exception:
                raise e


def safe_parse_json(possible_json: Any) -> Dict[str, Any]:
    """Safely parse JSON from various input types"""
    if isinstance(possible_json, dict):
        return possible_json
    elif isinstance(possible_json, str):
        return parse_partial_json(possible_json)
    else:
        raise ValueError("Input must be a dict or str")


def process_dataframes(df_list: List[pd.DataFrame]) -> Tuple:
    """Process list of dataframes into df_1 to df_10"""
    if len(df_list) > 10:
        warnings.warn(f"Only first 10 of {len(df_list)} dataframes will be used")
        df_list = df_list[:10]

    # Initialize empty dataframes
    df_1 = df_2 = df_3 = df_4 = df_5 = pd.DataFrame()
    df_6 = df_7 = df_8 = df_9 = df_10 = pd.DataFrame()
    result_df = pd.DataFrame()

    # Assign available dataframes
    if len(df_list) >= 1: df_1 = df_list[0]
    if len(df_list) >= 2: df_2 = df_list[1]
    if len(df_list) >= 3: df_3 = df_list[2]
    if len(df_list) >= 4: df_4 = df_list[3]
    if len(df_list) >= 5: df_5 = df_list[4]
    if len(df_list) >= 6: df_6 = df_list[5]
    if len(df_list) >= 7: df_7 = df_list[6]
    if len(df_list) >= 8: df_8 = df_list[7]
    if len(df_list) >= 9: df_9 = df_list[8]
    if len(df_list) >= 10: df_10 = df_list[9]

    my_globals = {
        # Libraries
        "pd": pd,
        "np": np,
        "json": json,
        "re": re,
        "datetime": datetime,
        "math": math,
        "collections": collections,
        "itertools": itertools,
        "functools": functools,
        "operator": operator,
        # DataFrames
        "df_1": df_1, "df_2": df_2, "df_3": df_3, "df_4": df_4, "df_5": df_5,
        "df_6": df_6, "df_7": df_7, "df_8": df_8, "df_9": df_9, "df_10": df_10,
        "result_df": result_df
    }

    return df_1, df_2, df_3, df_4, df_5, df_6, df_7, df_8, df_9, df_10, result_df, my_globals


def python_repl_tool(df_list: List[pd.DataFrame], code: str) -> Tuple[str, pd.DataFrame, str]:
    """Execute Python code using Python REPL"""
    print('\nREPL tool is called\n')

    df_error_msg = ""
    result_df = pd.DataFrame()
    output_text = ""

    try:
        df_1, df_2, df_3, df_4, df_5, df_6, df_7, df_8, df_9, df_10, result_df, my_globals = process_dataframes(df_list)

        if PythonREPL is None:
            raise ImportError("PythonREPL not available")

        python_repl = PythonREPL(_globals=my_globals)

        try:
            output_text = python_repl.run(code)
            if 'result_df' in python_repl.locals:
                result_df = python_repl.locals['result_df']
                print(f"\nResult DataFrame:\n{result_df}\n")
        except Exception as e:
            df_error_msg = f"Error executing code: {str(e)}"

        # Check for error indicators
        error_keywords = ["error", "exception", "traceback", "failed", "invalid"]
        if any(kw.lower() in output_text.lower() for kw in error_keywords):
            error_lines = [
                line.strip() for line in output_text.split('\n')
                if any(kw.lower() in line.lower() for kw in error_keywords)
            ]
            if error_lines:
                df_error_msg = " | ".join(error_lines)
            else:
                df_error_msg = "Unknown error detected"

        # Check result quality
        if isinstance(result_df, pd.DataFrame):
            if result_df.empty:
                df_error_msg = "Resulting dataframe is empty"
            else:
                numeric_cols = result_df.select_dtypes(include=["number"]).columns
                if len(numeric_cols) > 0 and all(result_df[col].isna().all() for col in numeric_cols):
                    df_error_msg = "All numeric columns are NA"

    except Exception as e:
        df_error_msg = str(e)

    return output_text, result_df, df_error_msg


_TEMPORAL_PARSE_THRESHOLD = 0.7


def eda_summary(df: pd.DataFrame, categorical_threshold: int = 15, sample_size: int = 10) -> str:
    """
    Business-intelligence focused summary of a DataFrame.
    Surfaces what the data means: rankings, distributions, trends, KPI breakdowns.
    """
    if df is None or df.empty:
        return "[Empty DataFrame — no data to summarize]"

    out = []
    n_rows, n_cols = df.shape

    # ── Data snapshot ────────────────────────────────────────────────
    out.append("## DATA SNAPSHOT")
    out.append(f"Records: {n_rows}  |  Columns: {n_cols}")
    out.append(f"Columns: {', '.join(df.columns.tolist())}")

    out.append(f"\n## SAMPLE RECORDS (first {min(sample_size, n_rows)})")
    out.append(df.head(sample_size).to_string(index=False, max_colwidth=60))

    # ── Detect temporal columns ──────────────────────────────────────
    temporal_cols: list = []
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            temporal_cols.append((col, df[col]))
        elif df[col].dtype == object:
            parsed = pd.to_datetime(df[col], errors="coerce")
            if parsed.notna().sum() / max(len(df[col].dropna()), 1) >= _TEMPORAL_PARSE_THRESHOLD:
                temporal_cols.append((col, parsed))

    temporal_col_names = {c for c, _ in temporal_cols}
    numeric_cols = df.select_dtypes(include=np.number).columns.tolist()

    # ── Temporal trends ──────────────────────────────────────────────
    if temporal_cols:
        out.append("\n## TIME RANGE & TRENDS")
        for col_name, series in temporal_cols:
            valid = series.dropna().sort_values()
            if valid.empty:
                continue
            span_days = (valid.max() - valid.min()).days
            out.append(
                f"  {col_name}: {valid.min().date()} → {valid.max().date()}"
                f"  ({span_days} days, {len(valid)} records)"
            )
            if span_days > 31 and len(valid) >= 5:
                monthly = valid.dt.to_period("M").value_counts().sort_index()
                out.append("  Monthly record counts:")
                for period, cnt in monthly.items():
                    out.append(f"    {period}: {cnt}")

        # Numeric KPI trend over time
        if numeric_cols and len(temporal_cols) == 1:
            _, t_series = temporal_cols[0]
            try:
                temp_df = df.copy()
                temp_df["_period"] = t_series.dt.to_period("M")
                for num_col in numeric_cols[:3]:
                    trend = temp_df.groupby("_period")[num_col].mean().dropna()
                    if len(trend) >= 2:
                        first_val, last_val = trend.iloc[0], trend.iloc[-1]
                        direction = "UP" if last_val > first_val else "DOWN"
                        out.append(
                            f"\n  {num_col} over time [{direction}]: "
                            f"{first_val:.2f} → {last_val:.2f}"
                        )
                        out.append("  Monthly avg:")
                        for period, val in trend.items():
                            out.append(f"    {period}: {val:.2f}")
            except Exception:
                pass

    # ── Numeric KPI summary ──────────────────────────────────────────
    if numeric_cols:
        out.append("\n## NUMERIC KPIs & METRICS")
        for col in numeric_cols:
            series = df[col].dropna()
            if series.empty:
                continue
            total = series.sum()
            mean = series.mean()
            median = series.median()
            mn, mx = series.min(), series.max()
            p25, p75 = series.quantile(0.25), series.quantile(0.75)
            out.append(
                f"\n  {col}:"
                f"\n    Total={total:,.2f}  Mean={mean:,.2f}  Median={median:,.2f}"
                f"\n    Min={mn:,.2f}  Max={mx:,.2f}  Range={mx - mn:,.2f}"
                f"\n    Bottom 25%: ≤{p25:,.2f}  |  Top 25%: ≥{p75:,.2f}"
            )

        # Relationships between metrics
        if len(numeric_cols) >= 2:
            try:
                corr = df[numeric_cols].corr()
                strong = []
                for i, c1 in enumerate(numeric_cols):
                    for c2 in numeric_cols[i + 1:]:
                        val = corr.loc[c1, c2]
                        if abs(val) >= 0.65:
                            rel = "positive" if val > 0 else "negative"
                            strong.append(f"  {c1} ↔ {c2}: {val:.2f} ({rel})")
                if strong:
                    out.append("\n## METRIC RELATIONSHIPS (|r| ≥ 0.65)")
                    out.extend(strong)
            except Exception:
                pass

    # ── Category breakdowns with KPI roll-ups ───────────────────────
    cat_cols = [
        col for col in df.columns
        if col not in temporal_col_names
        and col not in numeric_cols
        and df[col].dtype == object
        and df[col].nunique() <= categorical_threshold
    ]
    if cat_cols:
        out.append("\n## CATEGORY BREAKDOWNS")
        for col in cat_cols:
            vc = df[col].value_counts(dropna=True)
            n_unique = len(vc)
            out.append(f"\n  {col} ({n_unique} categories):")
            for val, cnt in vc.head(10).items():
                bar = "█" * min(int(cnt / n_rows * 20), 20)
                out.append(f"    {str(val):<30} {cnt:>5} ({cnt / n_rows * 100:5.1f}%)  {bar}")
            if n_unique > 10:
                out.append(f"    ... and {n_unique - 10} more")

            if numeric_cols:
                out.append(f"\n  {col} × KPI breakdown (mean | total | count):")
                for num_col in numeric_cols[:3]:
                    try:
                        grouped = (
                            df.groupby(col)[num_col]
                            .agg(["mean", "sum", "count"])
                            .sort_values("mean", ascending=False)
                        )
                        out.append(f"    {num_col}:")
                        for cat_val, row in grouped.head(10).iterrows():
                            out.append(
                                f"      {str(cat_val):<28} "
                                f"avg={row['mean']:,.2f}  "
                                f"total={row['sum']:,.2f}  "
                                f"n={int(row['count'])}"
                            )
                    except Exception:
                        pass

    # ── Top / bottom entity rankings (high-cardinality ID cols) ─────
    high_card = [
        col for col in df.columns
        if col not in temporal_col_names
        and col not in numeric_cols
        and df[col].dtype == object
        and df[col].nunique() > categorical_threshold
    ]
    if high_card and numeric_cols:
        out.append("\n## TOP / BOTTOM ENTITY RANKINGS")
        for id_col in high_card[:3]:
            for num_col in numeric_cols[:2]:
                try:
                    grouped = df.groupby(id_col)[num_col].mean().dropna().sort_values(ascending=False)
                    if grouped.empty:
                        continue
                    out.append(f"\n  Top 10 {id_col} by avg {num_col}:")
                    for entity, val in grouped.head(10).items():
                        out.append(f"    {str(entity):<35} {val:,.2f}")
                    out.append(f"  Bottom 5 {id_col} by avg {num_col}:")
                    for entity, val in grouped.tail(5).items():
                        out.append(f"    {str(entity):<35} {val:,.2f}")
                except Exception:
                    pass

    return "\n".join(out)
