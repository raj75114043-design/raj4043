"""
Table Analysis – Deterministic EDA + LLM Analysis Chain
Extracts statistical insights and generates compelling analysis of query results.
Author: AI Assistant Development
Client: Nokia
"""

import json
import logging
from typing import Optional
import pandas as pd

from langchain_core.output_parsers import JsonOutputParser, StrOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI

from app.core.config import settings
from .prompt import (
    TableAnalysis,
    EDAContext,
    TABLE_ANALYSIS_PROMPT,
    TABLE_ANALYSIS_NO_RESULTS_PROMPT,
)

logger = logging.getLogger(__name__)

# ── LLM Configuration ─────────────────────────────────────────────

llm = ChatOpenAI(
    api_key="NONE",
    model="gpt-4o-mini",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
    timeout=200,
)


# ── Deterministic EDA Script ───────────────────────────────────────

def extract_eda(table_json: str) -> Optional[EDAContext]:
    """
    Extract deterministic statistical insights from table data.

    Args:
        table_json: JSON string of table data (records format)

    Returns:
        EDAContext with statistical insights or None if parsing fails
    """
    try:
        if not table_json:
            return None

        result_data = json.loads(table_json)

        if not isinstance(result_data, list) or not result_data:
            return None

        # Convert to DataFrame for analysis
        df = pd.DataFrame(result_data)

        row_count = len(df)
        column_count = len(df.columns)

        # Column info extraction
        column_info = {}
        numeric_stats = {}
        categorical_summary = {}
        null_counts = {}

        for col in df.columns:
            # Null/missing count
            null_counts[col] = int(df[col].isnull().sum())

            # Determine data type
            if df[col].dtype in ['int64', 'float64']:
                col_type = "numeric"
                # Calculate statistics for numeric columns
                numeric_stats[col] = {
                    "min": float(df[col].min()) if not df[col].isnull().all() else None,
                    "max": float(df[col].max()) if not df[col].isnull().all() else None,
                    "mean": float(df[col].mean()) if not df[col].isnull().all() else None,
                    "median": float(df[col].median()) if not df[col].isnull().all() else None,
                    "std": float(df[col].std()) if not df[col].isnull().all() else None,
                    "count": int(df[col].notna().sum()),
                }
                column_info[col] = {
                    "type": col_type,
                    "null_count": null_counts[col],
                    "stats": numeric_stats[col],
                }
            else:
                col_type = "categorical"
                # Unique value counts
                unique_counts = df[col].nunique()
                value_counts = df[col].value_counts().to_dict()
                categorical_summary[col] = {
                    "unique_count": unique_counts,
                    "top_values": {str(k): int(v) for k, v in list(value_counts.items())[:10]},
                }
                column_info[col] = {
                    "type": col_type,
                    "null_count": null_counts[col],
                    "unique_count": unique_counts,
                }

        # Pattern detection
        patterns = []

        # Check for highly skewed distributions
        for col in numeric_stats:
            if numeric_stats[col]["std"] is not None and numeric_stats[col]["mean"] is not None:
                mean = numeric_stats[col]["mean"]
                std = numeric_stats[col]["std"]
                if std > 0 and abs(mean) > 0:
                    cv = abs(std / mean)  # Coefficient of variation
                    if cv > 1:
                        patterns.append(f"Column '{col}' has high variability (CV={cv:.2f})")

        # Check for columns with many nulls
        for col, null_count in null_counts.items():
            if null_count > 0:
                null_pct = (null_count / row_count) * 100
                if null_pct > 20:
                    patterns.append(f"Column '{col}' has {null_pct:.1f}% missing values")

        # Check for categorical imbalance
        for col, summary in categorical_summary.items():
            if summary["unique_count"] > 1:
                top_values = list(summary["top_values"].values())
                if top_values:
                    top_freq = max(top_values)
                    total = sum(top_values)
                    if total > 0:
                        top_pct = (top_freq / total) * 100
                        if top_pct > 80:
                            patterns.append(f"Column '{col}' is dominated by one category ({top_pct:.1f}% concentration)")

        # Data distribution summary
        summary = f"Table contains {row_count} rows and {column_count} columns. "
        numeric_cols = len(numeric_stats)
        categorical_cols = len(categorical_summary)
        if numeric_cols > 0:
            summary += f"{numeric_cols} numeric columns with statistics extracted. "
        if categorical_cols > 0:
            summary += f"{categorical_cols} categorical columns with value distributions analyzed."

        return EDAContext(
            row_count=row_count,
            column_count=column_count,
            column_info=column_info,
            null_counts=null_counts,
            numeric_stats=numeric_stats,
            categorical_summary=categorical_summary,
            patterns=patterns if patterns else ["No major anomalies detected"],
            summary=summary,
        )

    except Exception as e:
        logger.warning(f"Failed to extract EDA context: {e}")
        return None


# ── Main Async Analysis Function ───────────────────────────────────

async def generate_table_analysis(
    user_query: str,
    generated_sql: str,
    table_json: str = "",
    distill_toon_output: str = "",
    has_data: bool = False,
) -> TableAnalysis:
    """
    Generate compelling analysis of table data using EDA context.

    Args:
        user_query: The original user query
        generated_sql: The SQL query that was executed
        table_json: The result data as JSON (empty string if no results)
        distill_toon_output: Context from distillation/clarification
        has_data: Whether the result contains data (True) or is empty (False)

    Returns:
        TableAnalysis with analysis and key_insights fields

    Raises:
        Exception: If LLM call fails or output parsing fails
    """
    try:
        # Extract EDA context from table data
        eda_context = None
        table_preview = ""

        if has_data and table_json:
            eda_context = extract_eda(table_json)

            # Generate table preview (first 5 rows)
            try:
                result_data = json.loads(table_json)
                if isinstance(result_data, list):
                    preview_data = result_data[:5]
                    table_preview = json.dumps(preview_data, indent=2)
            except Exception as e:
                logger.warning(f"Failed to generate table preview: {e}")
                table_preview = "[Preview unavailable]"

        # Choose prompt based on data availability
        if has_data and eda_context:
            prompt_template = TABLE_ANALYSIS_PROMPT
            logger.info(f"Generating analysis for table with {eda_context.row_count} rows")

            # Format EDA context for prompt
            eda_str = (
                f"Row Count: {eda_context.row_count}\n"
                f"Column Count: {eda_context.column_count}\n"
                f"Columns: {', '.join(eda_context.column_info.keys())}\n"
                f"Null Counts: {eda_context.null_counts}\n"
                f"Numeric Stats: {json.dumps(eda_context.numeric_stats, indent=2)}\n"
                f"Patterns: {', '.join(eda_context.patterns)}\n"
                f"Summary: {eda_context.summary}"
            )
        else:
            prompt_template = TABLE_ANALYSIS_NO_RESULTS_PROMPT
            logger.info("Generating analysis for query with no results")
            eda_str = ""

        # Set up the LLM chain
        parser = JsonOutputParser(pydantic_object=TableAnalysis)
        format_instructions = parser.get_format_instructions()

        prompt = PromptTemplate(
            template=prompt_template,
            input_variables=["user_query", "generated_sql", "distill_toon_output"],
            partial_variables={
                "format": format_instructions,
                "eda_context": eda_str,
                "table_preview": table_preview,
            } if has_data and eda_context else {
                "format": format_instructions,
            },
        )

        chain = prompt | llm | StrOutputParser() | parser

        # Call LLM asynchronously
        result = await chain.ainvoke({
            "user_query": user_query,
            "generated_sql": generated_sql,
            "distill_toon_output": distill_toon_output or "[No distillation context]",
        })

        # Ensure result is a TableAnalysis object (not a dict)
        if isinstance(result, dict):
            result = TableAnalysis(**result)

        logger.info(f"Table analysis generated successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to generate table analysis: {e}", exc_info=True)
        # Return default analysis on failure
        return TableAnalysis(
            analysis="Unable to generate detailed analysis at this time. Please review the table data and SQL query above.",
            key_insights=["Data retrieved successfully. Review the table for specific insights."],
        )
