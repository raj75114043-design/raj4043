"""
Power BI Recommender — given a user query and project, returns the single
most relevant Power BI dashboard link + a 2-3 sentence justification.
"""

import json
import logging
from pathlib import Path

from langchain_core.output_parsers import JsonOutputParser, StrOutputParser
from langchain_core.prompts import PromptTemplate
from pydantic import BaseModel, Field

from app.agents.sql_agent.config import get_llm
from .prompt import POWER_BI_RECOMMENDATION_PROMPT

logger = logging.getLogger(__name__)

# Load catalog once at import time
_CATALOG: list[dict] = json.loads(
    (Path(__file__).parent / "power_bi_link.json").read_text(encoding="utf-8")
)


class _PowerBIRecommendation(BaseModel):
    link: str = Field(description="URL of the most relevant Power BI report Note: give the whole URL so the front end can render it")
    justification: str = Field(
        description="2-3 sentences explaining why this dashboard is relevant to the user's query"
    )


def _build_catalog_text(project: str) -> tuple[list[dict], str]:
    """Filter catalog by project and format as numbered list for the LLM."""
    normalized = project.replace("-", "").upper()
    candidates = [
        e for e in _CATALOG
        if e.get("Project", "").replace("-", "").upper() == normalized
    ]
    lines = []
    for i, e in enumerate(candidates, 1):
        lines.append(
            f"{i}. [{e['Category']} — {e['Subcategory']}]\n"
            f"   Link: {e['Link']}\n"
            f"   Description: {e['Description']}"
        )
    return candidates, "\n".join(lines)


async def recommend_power_bi(user_query: str, project: str) -> dict:
    """
    Return {"link": str, "justification": str} for the best matching Power BI
    report, or {"link": "", "justification": str} if none exist for the project.
    """
    candidates, catalog_text = _build_catalog_text(project)

    if not candidates:
        logger.info(f"No Power BI entries found for project '{project}'")
        return {
            "link": "",
            "justification": f"No Power BI dashboards are catalogued for project {project}.",
        }

    parser = JsonOutputParser(pydantic_object=_PowerBIRecommendation)
    prompt = PromptTemplate(
        template=POWER_BI_RECOMMENDATION_PROMPT,
        input_variables=["user_query", "project", "catalog"],
        partial_variables={"format": parser.get_format_instructions()},
    )
    chain = prompt | get_llm("o4-mini") | StrOutputParser() | parser

    result = await chain.ainvoke({
        "user_query": user_query,
        "project": project,
        "catalog": catalog_text,
    })

    logger.info(
        f"Power BI recommendation for project={project}: "
        f"link={result.get('link', '')[:60]}…"
    )
    return {"link": result["link"], "justification": result["justification"]}
