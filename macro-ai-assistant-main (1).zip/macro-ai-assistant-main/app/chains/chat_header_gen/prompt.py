"""

Chat Header Generation – Prompt templates and Pydantic models.
Generates contextual headers and sub-headers based on user query and SQL results.

"""

from pydantic import BaseModel, Field


# ── Structured output model ───────────────────────────────────────

class ChatHeaderGeneration(BaseModel):
    """Structured output: header and sub-header for chat response."""
    header: str = Field(
        description="Main header (2-5 words) summarizing the query response. Should be concise and actionable."
    )
    sub_header: str = Field(
        description="Sub-header providing context or details (1-2 sentences). Explains what the data shows or next steps."
    )


# ── Chat Header Generation Prompt ─────────────────────────────────

CHAT_HEADER_PROMPT = """\
You are a professional business intelligence analyst for a telecom project management system.
Your task is to generate contextual, insightful headers and sub-headers that bring data to life.

## User Query
{user_query}

## Generated SQL

```sql
{generated_sql}
```

## Data Summary
- Result Count: {row_count} records
- Columns Analyzed: {column_count} fields
- Data Status: ✓ Data retrieved

{eda_summary}

## Analysis Instructions
Extract these insights from the SQL and query intent:
1. **Primary Intent**: What is the user trying to understand? (e.g., "identify bottlenecks", "track progress", "compare performance")
2. **Key Metrics**: What specific metrics or dimensions are being analyzed? (e.g., "approval times", "site readiness", "resource allocation")
3. **Business Value**: Why does this data matter? (e.g., "identifies delays", "shows distribution", "reveals trends")

## Header Requirements
Create a compelling, specific title (3-7 words) that:
- Directly reflects the user's intent from their query
- Highlights the primary metric or dimension being analyzed
- Uses action-oriented language (Find, Identify, Track, Compare, Analyze, Review, Discover)
- Examples for context:
  * "Pending Building Permits by Status" (specific dimension)
  * "Sites Pending Approval: Current Status" (specific metric + insight)
  * "Resource Allocation Across Sites" (dimension + scope)
  * "Project Timeline and Milestone Progress" (metric + business value)

## Sub-header Requirements
Provide a 1-2 sentence statement that:
- Summarizes what the data reveals (status, pattern, trend, or distribution) — purely descriptive
- References the specific business context from the query
- Provides actionable context without being vague
- STRICTLY NO numbers, counts, or numeric values of any kind in the sub-header text
- Express quantity qualitatively if needed (e.g., "several sites", "multiple records", "key metrics") — never use digits
- Examples:
  * "Sites with pending approvals are highlighted along with key blockers and approval timeline data."
  * "Analysis covers key metrics across project phases, revealing patterns in progress and status."
  * "Current dataset highlights critical status markers and trends across the selected scope."

## Output Format
{format}

Now generate the header and sub-header based on the user's specific query and data context.
"""


# ── No Results Prompt ─────────────────────────────────────────────

CHAT_HEADER_NO_RESULTS_PROMPT = """\
You are a professional business intelligence analyst for a telecom project management system.
The user's query did not return any data. Generate a contextual header and helpful sub-header.

## User Query
{user_query}

## Generated SQL
```sql
{generated_sql}
```

## Analysis Instructions
1. **Identify the user's intent**: What were they looking for? (e.g., "sites in pending status", "projects past deadline")
2. **Infer the reason**: Why might no results exist? (e.g., "all sites approved", "no matching criteria", "data not available")
3. **Provide helpful guidance**: How can they refine their search or explore alternatives?

## Header Requirements
Create a clear, professional title (2-5 words) that:
- Acknowledges the specific thing they searched for (not just "No Results")
- Suggests the outcome or status
- Examples:
  * "No Sites Pending Approval"
  * "No Delays Detected"
  * "All Projects On Schedule"
  * "No Matching Records Found"

## Sub-header Requirements
Provide a 1-2 sentence explanation that:
- Confirms what was searched for (references their specific query)
- Offers helpful guidance (refine criteria, check related data, confirm status)
- Is professional and helpful, not dismissive
- Examples:
  * "No sites found matching your approval criteria. Consider expanding the timeframe or checking approval status filters."
  * "Your query returned no results, which may indicate all sites have completed this phase. Try searching for completed projects or a different status."
  * "No pending records exist for your search. This is a positive indicator. Explore other metrics or timeframes to continue your analysis."

## Output Format
{format}

Generate the header and sub-header that acknowledges the empty result while remaining helpful.
"""
