"""
Chat Header Generation – Async LLM chain for generating contextual response headers.
Author: AI Assistant Development
Client: Nokia
"""

import json
import logging
from typing import Optional

import pandas as pd
from langchain_core.output_parsers import JsonOutputParser, StrOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI

from app.core.config import settings
from app.agents.csv_agent.tools import eda_summary
from .prompt import (
    ChatHeaderGeneration,
    CHAT_HEADER_PROMPT,
    CHAT_HEADER_NO_RESULTS_PROMPT,
)

logger = logging.getLogger(__name__)

# ── LLM Configuration ─────────────────────────────────────────────

llm = ChatOpenAI(
    api_key="NONE",
    model="gpt-4o-mini",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
    timeout=120,
)


# ── Main async function ───────────────────────────────────────────

async def generate_chat_header(
    user_query: str,
    generated_sql: str,
    table_json: str = "",
    has_data: bool = False,
) -> ChatHeaderGeneration:
    """
    Generate a contextual header and sub-header for the chat response.

    Args:
        user_query: The original user query
        generated_sql: The SQL query that was executed
        table_json: The result data as JSON (empty string if no results)
        has_data: Whether the result contains data (True) or is empty (False)

    Returns:
        ChatHeaderGeneration with header and sub_header fields

    Raises:
        Exception: If LLM call fails or output parsing fails
    """
    try:
        row_count = 0
        column_count = 0
        eda_text = ""

        if has_data and table_json:
            try:
                result_data = json.loads(table_json)
                if isinstance(result_data, list) and result_data:
                    df = pd.DataFrame(result_data)
                    row_count = len(df)
                    column_count = len(df.columns)
                    eda_text = eda_summary(df)
            except (json.JSONDecodeError, TypeError, ValueError) as e:
                logger.warning(f"Failed to parse table_json for EDA: {e}")
                has_data = False
                row_count = 0
                column_count = 0

        # Choose prompt based on whether data exists
        if has_data and row_count > 0:
            prompt_template = CHAT_HEADER_PROMPT
            logger.info(f"Generating header for query with {row_count} rows, {column_count} columns")
        else:
            prompt_template = CHAT_HEADER_NO_RESULTS_PROMPT
            logger.info("Generating header for query with no results")

        # Set up the LLM chain
        parser = JsonOutputParser(pydantic_object=ChatHeaderGeneration)
        format_instructions = parser.get_format_instructions()

        partial_vars = {
            "format": format_instructions,
            "has_data": str(has_data and row_count > 0),
            "row_count": row_count,
            "column_count": column_count,
            "eda_summary": eda_text,
        }

        prompt = PromptTemplate(
            template=prompt_template,
            input_variables=["user_query", "generated_sql"],
            partial_variables=partial_vars,
        )

        chain = prompt | llm | StrOutputParser() | parser

        # Call LLM asynchronously
        result = await chain.ainvoke({
            "user_query": user_query,
            "generated_sql": generated_sql,
        })

        if isinstance(result, dict):
            result = ChatHeaderGeneration(**result)

        logger.info(f"Chat header generated successfully: {result.header}")
        return result

    except Exception as e:
        logger.error(f"Failed to generate chat header: {e}", exc_info=True)
        # Return contextual fallback header on failure
        fallback_header = "Query Analysis Complete"
        fallback_subheader = f"Retrieved {row_count} records with {column_count} metrics. Review the data table above for full details." if row_count > 0 else "No data matched your query criteria. Try adjusting your search parameters."

        return ChatHeaderGeneration(
            header=fallback_header,
            sub_header=fallback_subheader,
        )
