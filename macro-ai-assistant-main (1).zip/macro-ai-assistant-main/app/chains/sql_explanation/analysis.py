"""
SQL Explanation – Generate professional explanation of SQL generation steps.
Author: AI Assistant Development
Client: Nokia
"""

import logging
from langchain_core.output_parsers import JsonOutputParser, StrOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI

from app.core.config import settings
from .prompt import SQLExplanation, SQL_EXPLANATION_PROMPT

logger = logging.getLogger(__name__)

# ── LLM Configuration ─────────────────────────────────────────────

llm = ChatOpenAI(
    api_key="NONE",
    model="gpt-4o-mini",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
    timeout=120,
)


# ── Main Async Explanation Function ────────────────────────────────

async def generate_sql_explanation(
    user_query: str,
    generated_sql: str,
    distill_toon_context: str = "",
) -> SQLExplanation:
    """
    Generate professional explanation of SQL generation steps.

    Args:
        user_query: The original user query
        generated_sql: The SQL query that was generated
        distill_toon_context: Context from distillation/clarification (understanding of user intent)

    Returns:
        SQLExplanation with explanation and key_steps fields

    Raises:
        Exception: If LLM call fails or output parsing fails
    """
    try:
        # Set up the LLM chain
        parser = JsonOutputParser(pydantic_object=SQLExplanation)
        format_instructions = parser.get_format_instructions()

        prompt = PromptTemplate(
            template=SQL_EXPLANATION_PROMPT,
            input_variables=["user_query", "generated_sql", "distill_toon_context"],
            partial_variables={
                "format": format_instructions,
            },
        )

        chain = prompt | llm | StrOutputParser() | parser

        # Call LLM asynchronously
        result = await chain.ainvoke({
            "user_query": user_query,
            "generated_sql": generated_sql,
            "distill_toon_context": distill_toon_context or "[No clarification context]",
        })

        # Ensure result is a SQLExplanation object (not a dict)
        if isinstance(result, dict):
            result = SQLExplanation(**result)

        logger.info("SQL explanation generated successfully")
        return result

    except Exception as e:
        logger.error(f"Failed to generate SQL explanation: {e}", exc_info=True)
        # Return default explanation on failure
        return SQLExplanation(
            explanation="The SQL query was generated based on your request to retrieve data. Please review the SQL statement above to understand the exact data retrieval logic.",
            key_steps=[
                "User intent was analyzed from your original query",
                "Relevant data sources and columns were identified",
                "SQL filters and aggregations were constructed to answer your question",
            ],
        )
