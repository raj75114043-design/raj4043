"""
Hi-Chart Graph Generation – Prompt templates and Pydantic models.
Generates Highcharts-compatible graph configurations based on table data and user query.
"""

from typing import Any
from pydantic import BaseModel, Field


# ── Structured output model ───────────────────────────────────────

class HiChartOutput(BaseModel):
    """Structured output: exactly one Highcharts-compatible chart configuration."""
    charts: list[Any] = Field(
        description="List containing exactly ONE complete Highcharts-compatible chart configuration object with type, title, series, and axes."
    )


# ── Hi-Chart Graph Generation Prompt ──────────────────────────────

HICHART_GRAPH_PROMPT = """\
You are a Highcharts expert. Generate exactly ONE complete, production-ready Highcharts configuration that best visualizes the data and answers the user's question.
Always include Tile and Axis information in the chart configuration.
## User Query
{user_query}

## SQL Used
{generated_sql}

## Data
```
{table_preview}
```

## Chart Selection Rules
- **Line** → time-series trends, continuous data over dates
- **Column** → category comparisons (≤20 categories); use **bar** if labels are long
- **Bar** → horizontal comparisons, ranked lists
- **Pie/Donut** → part-to-whole, 2–7 slices only; set `innerSize: "50%"` for donut
- **Area / Stacked Area** → cumulative or composition over time
- **Scatter** → correlation between two numeric variables
- **Gauge / SolidGauge** → single KPI value with a target range
- **Heatmap** → two-axis matrix with numeric intensity
- **Treemap** → hierarchical proportions
- **Boxplot** → statistical distribution per category
- **Stacked Column/Bar** → composition breakdown per category

## Configuration Requirements
1. Output a single JSON object inside `charts` array — NEVER more than one chart.
2. Always include: `type`, `title`, `xAxis`, `yAxis` (omit for pie/gauge), `series`, `tooltip`, `legend`, `plotOptions`, `credits: {{enabled: false}}`.
3. `title.text` must be descriptive (what the chart shows), not generic.
4. Every series `data` array must contain the actual values from the table — do NOT use placeholder values.
5. `xAxis.categories` must list actual category/date values from the data.
6. For numeric axes: set `yAxis.title.text` to the metric name; format with `labels.format: "{{value:,.0f}}"` for large integers.
7. For date/time x-axes: use `xAxis.type: "datetime"` and timestamps in milliseconds.
8. `tooltip.pointFormat` should show the series name and formatted value.
9. `plotOptions` must enable `dataLabels` for pie charts (show percentage + name).
10. Use a professional color palette — avoid neon or default grey.
11. All JSON must be syntactically valid — no trailing commas, no comments.
12. Never create Bubble chart type stick to char selection rules 



## Output Format
{format}
"""
