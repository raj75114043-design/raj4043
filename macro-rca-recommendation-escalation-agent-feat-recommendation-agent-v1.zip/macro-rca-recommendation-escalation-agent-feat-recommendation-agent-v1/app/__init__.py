"""Nokia Macro Agent Application"""
