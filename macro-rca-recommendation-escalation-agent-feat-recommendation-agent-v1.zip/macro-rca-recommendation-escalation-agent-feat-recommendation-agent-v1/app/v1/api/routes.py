"""
API Routes
===========
File: app/v1/api/routes.py

FastAPI endpoints for the RCA + Recommender Agent system.
"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from fastapi.responses import StreamingResponse
from typing import Optional
import json
import asyncio
from datetime import datetime
import logging

from ..models import AgentRequest, AgentResponse
from ..orchestration import run_rca_recommender
from ..foundation_layer import feedback_loop, FeedbackType

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/rca", tags=["RCA & Recommender"])


@router.post("/analyze", response_model=AgentResponse)
async def analyze_and_recommend(request: AgentRequest) -> AgentResponse:
    """
    Run RCA + Recommender analysis on a query.
    
    This endpoint executes the full Multi-Agent System:
    1. Planner decomposes the query
    2. Data Agent gathers evidence
    3. Analyst performs statistical analysis
    4. RCA Agent identifies root causes
    5. Recommender generates actionable recommendations
    
    Example queries:
    - "Why is FTR declining for vendor X in Northeast?"
    - "Which regions have the highest H&S non-compliance?"
    - "What should we do about the civil SLA breaches in Chicago?"
    """
    try:
        logger.info(f"[API] Received request: {request.query[:100]}...")
        
        response = await run_rca_recommender(request)
        
        logger.info(f"[API] Completed with success={response.success}")
        
        return response
        
    except Exception as e:
        logger.error(f"[API] Error processing request: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/analyze/stream")
async def analyze_and_recommend_stream(request: AgentRequest):
    """
    Run RCA + Recommender analysis with streaming updates.
    
    Returns Server-Sent Events (SSE) with progress updates.
    """
    async def generate():
        try:
            # Send start event
            yield f"data: {json.dumps({'type': 'start', 'query': request.query})}\n\n"
            
            # Run the analysis
            response = await run_rca_recommender(request)
            
            # Send progress updates based on response
            if response.root_causes:
                yield f"data: {json.dumps({'type': 'root_causes', 'count': len(response.root_causes)})}\n\n"
            
            if response.recommendations:
                yield f"data: {json.dumps({'type': 'recommendations', 'count': len(response.recommendations)})}\n\n"
            
            # Send complete event with full response
            yield f"data: {json.dumps({'type': 'complete', 'response': response.model_dump()})}\n\n"
            
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'message': str(e)})}\n\n"
    
    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive"
        }
    )


@router.post("/feedback")
async def submit_feedback(
    insight_id: str,
    feedback: str,  # "positive", "negative", "correction"
    user_id: str,
    correction: Optional[str] = None
):
    """
    Submit feedback on an insight/recommendation.
    
    This feeds into the Learning Loop for continuous improvement.
    - Positive feedback: May promote patterns from Tier 3 → Tier 2 → Tier 1
    - Negative feedback: Logged for review
    - Correction: Stored for future training
    """
    try:
        feedback_type = FeedbackType(feedback)
        
        result = await feedback_loop.record_feedback(
            insight_id=insight_id,
            feedback_type=feedback_type,
            user_id=user_id,
            correction=correction
        )
        
        if result.success:
            return {"status": "recorded", "insight_id": insight_id}
        else:
            raise HTTPException(status_code=500, detail=result.error)
            
    except ValueError:
        raise HTTPException(
            status_code=400, 
            detail=f"Invalid feedback type. Must be: positive, negative, or correction"
        )
    except Exception as e:
        logger.error(f"[API] Feedback error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "service": "rca-recommender-agent"
    }


# Quick analysis endpoints for common scenarios

@router.get("/quick/vendor-performance")
async def quick_vendor_performance(
    market: Optional[str] = None,
    days: int = 30
):
    """Quick analysis: Vendor performance issues"""
    request = AgentRequest(
        query="Which vendors have the worst FTR performance and what actions should we take?",
        filters={"market": market} if market else {},
        time_range={"start": f"2025-01-{max(1, 21-days):02d}", "end": "2025-02-21"}
    )
    return await analyze_and_recommend(request)


@router.get("/quick/hse-compliance")
async def quick_hse_compliance(
    market: Optional[str] = None,
    days: int = 60
):
    """Quick analysis: HSE compliance issues"""
    request = AgentRequest(
        query="Which regions and vendors have the highest H&S non-compliance failures? Provide GC-wise breakdown and action plan.",
        filters={"market": market} if market else {},
        time_range={"start": f"2025-01-01", "end": "2025-02-21"}
    )
    return await analyze_and_recommend(request)


@router.get("/quick/sla-breaches")
async def quick_sla_breaches(
    market: Optional[str] = None,
    sla_type: str = "civil"  # "civil" or "ran"
):
    """Quick analysis: SLA breaches"""
    request = AgentRequest(
        query=f"Which regions and vendors have the highest {sla_type.upper()} SLA breaches and which milestones are causing delays?",
        filters={"market": market} if market else {},
        time_range={"start": "2024-12-01", "end": "2025-02-21"}
    )
    return await analyze_and_recommend(request)
