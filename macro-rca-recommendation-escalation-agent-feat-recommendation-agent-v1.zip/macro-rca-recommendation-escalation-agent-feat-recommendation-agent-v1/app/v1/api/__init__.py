"""
API Module
===========
File: app/v1/api/__init__.py
"""

from .routes import router

__all__ = ["router"]
