"""
Nokia Macro Agent Data Models
==============================
File: app/v1/models/schemas.py

Pydantic models for state management, domain objects, and agent communication.
Based on the Multi-Agent System architecture from the detailed architecture doc.
"""

from datetime import datetime
from typing import Dict, List, Optional, Any, Literal, Union, Annotated
from pydantic import BaseModel, Field
from enum import Enum
import operator


# =============================================================================
# Enums
# =============================================================================

class IntentType(str, Enum):
    """Query intent classification"""
    DIAGNOSTIC = "diagnostic"        # Why is X happening?
    PRESCRIPTIVE = "prescriptive"    # What should we do?
    PREDICTIVE = "predictive"        # What will happen if?
    INFORMATIONAL = "informational"  # Show me / Tell me


class AgentStatus(str, Enum):
    """Agent execution status"""
    PLANNING = "planning"
    GATHERING = "gathering"
    ANALYZING = "analyzing"
    RECOMMENDING = "recommending"
    COMPLETE = "complete"
    ERROR = "error"


class InsightPriority(str, Enum):
    """Priority levels for insights"""
    CRITICAL = "critical"    # Immediate action required
    HIGH = "high"           # This week
    MEDIUM = "medium"       # This month
    LOW = "low"             # Awareness


class InsightType(str, Enum):
    """Types of insights"""
    ACTIONABLE = "actionable"
    INFORMATIVE = "informative"
    WARNING = "warning"


class ValidationStatus(str, Enum):
    """Validation status for root causes"""
    VALIDATED = "validated"
    HYPOTHESIZED = "hypothesized"
    REJECTED = "rejected"


class Feasibility(str, Enum):
    """Feasibility levels"""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


# =============================================================================
# Foundation Layer Models
# =============================================================================

class ColumnMetadata(BaseModel):
    """Column-level metadata for Enriched DB Metadata"""
    column_name: str
    nl_description: str
    synonyms: List[str] = Field(default_factory=list)
    data_type: str
    sample_values: List[Any] = Field(default_factory=list)
    common_filters: List[str] = Field(default_factory=list)
    aggregation_patterns: List[str] = Field(default_factory=list)
    thresholds: Optional[Dict[str, Any]] = None
    null_meaning: Optional[str] = None


class TableMetadata(BaseModel):
    """Table-level metadata for Enriched DB Metadata"""
    table_name: str
    description: str
    business_context: str
    update_frequency: str
    primary_key: List[str]
    common_joins: List[str] = Field(default_factory=list)
    tags: List[str] = Field(default_factory=list)
    columns: Dict[str, ColumnMetadata] = Field(default_factory=dict)


class KPIDefinition(BaseModel):
    """KPI definition from KPI Catalog"""
    kpi_id: str
    kpi_name: str
    formula: str
    thresholds: Dict[str, float]  # e.g., {"red": 85, "amber": 95, "green": 100}
    owner: str
    category: str
    unit: str
    is_critical: bool = False


class RCAPlan(BaseModel):
    """Curated RCA plan for Tier 1"""
    plan_id: str
    problem_pattern: str
    trigger_conditions: str
    root_causes: List[Dict[str, Any]]  # [{cause: str, weight: float}]
    validation_queries: List[str]
    recommendations: List[str]
    category: str


class HistoricalCase(BaseModel):
    """Historical case for Tier 2 RAG"""
    case_id: str
    problem_signature: Dict[str, Any]
    investigation_summary: str
    root_cause_identified: str
    resolution: str
    outcome: str
    embedding: Optional[List[float]] = None
    created_at: datetime = Field(default_factory=datetime.now)


# =============================================================================
# Agent Communication Models
# =============================================================================

class SubQuestion(BaseModel):
    """Decomposed sub-question from Planner"""
    question_id: str
    question: str
    data_requirements: List[str]
    dependencies: List[str] = Field(default_factory=list)
    priority: int = 1


class DataRequirement(BaseModel):
    """Data requirement identified by Planner"""
    requirement_id: str
    description: str
    source: Literal["SQL", "API", "Cache", "Derived"]
    sql_template: Optional[str] = None
    parameters: Dict[str, Any] = Field(default_factory=dict)


class Evidence(BaseModel):
    """Evidence gathered by Data Agent"""
    evidence_id: str
    source: str
    description: str
    data: Any
    timestamp: datetime = Field(default_factory=datetime.now)
    query_used: Optional[str] = None
    confidence: float = 1.0


class Finding(BaseModel):
    """Statistical finding from Analyst"""
    finding_id: str
    description: str
    metric_a: str
    metric_b: Optional[str] = None
    value_a: float
    value_b: Optional[float] = None
    difference: Optional[float] = None
    p_value: Optional[float] = None
    sample_size: int
    is_significant: bool
    method: str  # e.g., "t-test", "correlation", "trend"


class RootCause(BaseModel):
    """Identified root cause from RCA Agent"""
    cause_id: str
    description: str
    confidence: float
    tier: int  # 1, 2, or 3
    evidence_ids: List[str] = Field(default_factory=list)
    validation_status: ValidationStatus = ValidationStatus.HYPOTHESIZED
    category: str
    affected_entities: Dict[str, List[str]] = Field(default_factory=dict)


class Recommendation(BaseModel):
    """Recommendation from Recommender Agent"""
    recommendation_id: str
    action: str
    description: str
    root_cause_id: str
    priority: InsightPriority
    impact: Dict[str, Any] = Field(default_factory=dict)
    feasibility: Feasibility = Feasibility.MEDIUM
    owner: Optional[str] = None
    timeline: Optional[str] = None
    metrics_improvement: Optional[Dict[str, float]] = None


# =============================================================================
# Agent State Models (for LangGraph)
# =============================================================================

class PlanState(BaseModel):
    """State for Planner Agent output"""
    sub_questions: List[SubQuestion] = Field(default_factory=list)
    data_requirements: List[DataRequirement] = Field(default_factory=list)
    rca_coverage: Optional[Dict[str, Any]] = None  # Tier 1 plan if found
    simulation_models_needed: List[str] = Field(default_factory=list)


class EvidenceState(BaseModel):
    """State for collected evidence"""
    data_tables: List[Evidence] = Field(default_factory=list)
    metrics: Dict[str, Any] = Field(default_factory=dict)
    events: List[Evidence] = Field(default_factory=list)
    kpis: Dict[str, Any] = Field(default_factory=dict)


class AnalysisState(BaseModel):
    """State for analysis results"""
    findings: List[Finding] = Field(default_factory=list)
    root_causes: List[RootCause] = Field(default_factory=list)
    confidence: Dict[str, float] = Field(default_factory=dict)
    statistical_tests: List[Dict[str, Any]] = Field(default_factory=list)


class AgentMessage(BaseModel):
    """Message between agents"""
    from_agent: str
    to_agent: str
    action: str
    parameters: Dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=datetime.now)


class ToolCall(BaseModel):
    """Record of a tool call"""
    tool_name: str
    parameters: Dict[str, Any]
    result: Optional[Any] = None
    success: bool = True
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    timestamp: datetime = Field(default_factory=datetime.now)


class AgentState(BaseModel):
    """
    Main agent state for LangGraph orchestration.
    This is the shared state (blackboard pattern) that all agents read from and write to.
    """
    # Input
    query: str
    intent: List[IntentType] = Field(default_factory=list)
    context: Dict[str, Any] = Field(default_factory=dict)
    filters: Dict[str, Any] = Field(default_factory=dict)
    
    # Status tracking
    status: AgentStatus = AgentStatus.PLANNING
    current_agent: str = "orchestrator"
    iteration_count: int = 0
    max_iterations: int = 3
    
    # Agent outputs (blackboard)
    plan: PlanState = Field(default_factory=PlanState)
    evidence: EvidenceState = Field(default_factory=EvidenceState)
    analysis: AnalysisState = Field(default_factory=AnalysisState)
    recommendations: List[Recommendation] = Field(default_factory=list)
    
    # Execution trace
    messages: Annotated[List[AgentMessage], operator.add] = Field(default_factory=list)
    tool_calls: Annotated[List[ToolCall], operator.add] = Field(default_factory=list)
    errors: Annotated[List[str], operator.add] = Field(default_factory=list)
    
    # Quality gate tracking
    has_evidence: bool = False
    has_root_cause: bool = False
    has_quantified_impact: bool = False
    
    # Timestamps
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None

    class Config:
        arbitrary_types_allowed = True


# =============================================================================
# Output Models
# =============================================================================

class InsightOutput(BaseModel):
    """Final insight output format (as per architecture doc)"""
    insight_id: str
    tier: int
    category: str
    title: str
    description: str
    priority: InsightPriority
    type: InsightType
    recommendation: Optional[str] = None
    affected_entities: Dict[str, List[str]] = Field(default_factory=dict)
    metrics: Dict[str, Any] = Field(default_factory=dict)
    source: Dict[str, Any] = Field(default_factory=dict)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class AgentResponse(BaseModel):
    """Final response from the multi-agent system"""
    success: bool
    query: str
    evidence_summary: str
    root_causes: List[RootCause] = Field(default_factory=list)
    recommendations: List[Recommendation] = Field(default_factory=list)
    insights: List[InsightOutput] = Field(default_factory=list)
    execution_trace: List[Dict[str, Any]] = Field(default_factory=list)
    total_time_seconds: float = 0.0
    iterations_used: int = 0
    error_message: Optional[str] = None


# =============================================================================
# Request Models
# =============================================================================

class AgentRequest(BaseModel):
    """Input request to the agent system"""
    query: str
    context: Optional[Dict[str, Any]] = None
    filters: Optional[Dict[str, Any]] = None  # e.g., {"market": "Chicago", "vendor": "Nettxio"}
    time_range: Optional[Dict[str, str]] = None  # e.g., {"start": "2025-01-01", "end": "2025-02-21"}
    max_iterations: int = 3
    require_deep_investigation: bool = False  # Force Tier 3
    project_track: str = "TMO_RPM"  # TMO_RPM, NAS, or DEC


class ToolCallRequest(BaseModel):
    """Tool call request from agent to tool"""
    tool_name: str
    parameters: Dict[str, Any]
    requesting_agent: str
    purpose: str


class ToolCallResponse(BaseModel):
    """Response from tool execution"""
    success: bool
    tool_name: str
    result: Any = None
    error: Optional[str] = None
    execution_time_ms: float = 0.0
