"""
Database Module
================
File: app/v1/db/__init__.py

Database connections, ORM models, and initialization.
"""

from .connection import (
    DatabaseConfig,
    db_config,
    DatabaseManager,
    db_manager,
    get_db_session,
    get_redis,
    Base
)

from .models import (
    Site,
    Vendor,
    Crew,
    SiteMilestone,
    SitePrerequisite,
    QualityRecord,
    HSERecord,
    RCAPlan,
    HistoricalCase,
    Insight,
    OperationalEvent,
    KPISnapshot
)

from .init_db import (
    create_tables,
    drop_tables,
    init_database,
    reset_database
)

__all__ = [
    # Connection
    "DatabaseConfig",
    "db_config",
    "DatabaseManager",
    "db_manager",
    "get_db_session",
    "get_redis",
    "Base",
    
    # Models
    "Site",
    "Vendor",
    "Crew",
    "SiteMilestone",
    "SitePrerequisite",
    "QualityRecord",
    "HSERecord",
    "RCAPlan",
    "HistoricalCase",
    "Insight",
    "OperationalEvent",
    "KPISnapshot",
    
    # Initialization
    "create_tables",
    "drop_tables",
    "init_database",
    "reset_database"
]