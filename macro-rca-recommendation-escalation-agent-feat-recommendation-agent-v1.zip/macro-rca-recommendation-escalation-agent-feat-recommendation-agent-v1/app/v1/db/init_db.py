"""
Database Initialization
========================
File: app/v1/db/init_db.py

Initialize database tables and seed data.
"""

import logging
from sqlalchemy import text
from datetime import datetime, date, timedelta
import random

from .connection import db_manager, Base
from .models import (
    Site, Vendor, Crew, SiteMilestone, SitePrerequisite,
    QualityRecord, HSERecord, RCAPlan, HistoricalCase,
    OperationalEvent, KPISnapshot
)

logger = logging.getLogger(__name__)


async def create_tables():
    """Create all database tables"""
    logger.info("Creating database tables...")
    
    async with db_manager.engine.begin() as conn:
        # Enable pgvector extension
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        
        # Create all tables
        await conn.run_sync(Base.metadata.create_all)
    
    logger.info("Database tables created successfully")


async def drop_tables():
    """Drop all database tables"""
    logger.info("Dropping database tables...")
    
    async with db_manager.engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
    
    logger.info("Database tables dropped")


async def seed_vendors():
    """Seed vendor data"""
    vendors_data = [
        {"vendor_code": "NETTXIO", "vendor_name": "Nettxio Communications", "tier": 1, "markets": ["Chicago", "Detroit", "Milwaukee"]},
        {"vendor_code": "TECHBLD", "vendor_name": "TechBuild Solutions", "tier": 1, "markets": ["New York", "Boston", "Philadelphia"]},
        {"vendor_code": "TOWERCO", "vendor_name": "TowerCo Construction", "tier": 1, "markets": ["Los Angeles", "San Francisco", "Seattle"]},
        {"vendor_code": "CELLNET", "vendor_name": "CellNet Builders", "tier": 2, "markets": ["Dallas", "Houston", "Austin"]},
        {"vendor_code": "INFRAX", "vendor_name": "InfraX Networks", "tier": 2, "markets": ["Miami", "Atlanta", "Charlotte"]},
    ]
    
    async with db_manager.session() as session:
        for v_data in vendors_data:
            vendor = Vendor(
                vendor_code=v_data["vendor_code"],
                vendor_name=v_data["vendor_name"],
                vendor_type="GC",
                tier=v_data["tier"],
                markets=v_data["markets"],
                regions=v_data["markets"],
                active_crews=random.randint(5, 15),
                daily_capacity=random.uniform(1.5, 3.0),
                ftr_rate=random.uniform(82, 98),
                on_time_rate=random.uniform(85, 98),
                compliance_rate=random.uniform(90, 99),
                is_active=True
            )
            session.add(vendor)
        
        await session.commit()
    
    logger.info(f"Seeded {len(vendors_data)} vendors")


async def seed_rca_plans():
    """Seed Tier 1 curated RCA plans"""
    plans_data = [
        {
            "plan_id": "PLAN_CREW_INEXPERIENCE",
            "problem_pattern": "FTR declining for specific vendor with new crews",
            "trigger_conditions": "FTR < 90% AND crew_tenure < 30 days",
            "category": "crew_inexperience",
            "root_causes": [
                {"cause": "New crews with insufficient training", "weight": 0.4},
                {"cause": "Lack of mentorship for new crews", "weight": 0.3}
            ],
            "recommendations": [
                "Schedule refresher training for affected crews",
                "Pair new crews with experienced mentors",
                "Mandatory retraining for crews with <90% FTR"
            ]
        },
        {
            "plan_id": "PLAN_MATERIAL_BATCH",
            "problem_pattern": "Quality failures correlated with material batch",
            "trigger_conditions": "Failure rate > 15% for specific material batch",
            "category": "material_batch_issue",
            "root_causes": [
                {"cause": "Defective material batch from supplier", "weight": 0.5},
                {"cause": "Improper material storage", "weight": 0.2}
            ],
            "recommendations": [
                "Quarantine remaining inventory from affected batch",
                "Initiate supplier quality review",
                "Request replacement from alternate supplier"
            ]
        },
        {
            "plan_id": "PLAN_VENDOR_UNDERPERFORM",
            "problem_pattern": "Vendor delivery consistently below plan",
            "trigger_conditions": "Plan achievement < 80% for 2+ consecutive weeks",
            "category": "vendor_underperformance",
            "root_causes": [
                {"cause": "Insufficient crew capacity", "weight": 0.35},
                {"cause": "Poor project management", "weight": 0.25},
                {"cause": "Resource allocation issues", "weight": 0.2}
            ],
            "recommendations": [
                "Shift volume to better performing vendors",
                "Apply penalty clauses",
                "Freeze new site awards for bottom quartile"
            ]
        },
        {
            "plan_id": "PLAN_HSE_NONCOMPLIANCE",
            "problem_pattern": "Repeated HSE violations causing work stoppage",
            "trigger_conditions": "HSE compliance < 90% OR repeated violations",
            "category": "hse_non_compliance",
            "root_causes": [
                {"cause": "Inadequate safety training", "weight": 0.3},
                {"cause": "Lack of enforcement", "weight": 0.3},
                {"cause": "Poor safety culture", "weight": 0.2}
            ],
            "recommendations": [
                "Enforce compliance process adherence",
                "Issue notice against repeat violators",
                "Mandatory safety retraining"
            ]
        },
        {
            "plan_id": "PLAN_PREREQ_DELAY",
            "problem_pattern": "Sites blocked by missing prerequisites",
            "trigger_conditions": "Blocked sites > 20% of portfolio",
            "category": "prerequisite_delay",
            "root_causes": [
                {"cause": "Delayed power (EB/DG) provisioning", "weight": 0.3},
                {"cause": "Fiber backhaul not ready", "weight": 0.25},
                {"cause": "NTP approval delays", "weight": 0.25}
            ],
            "recommendations": [
                "Fast-track critical prerequisites",
                "Launch readiness acceleration task force",
                "Parallel processing where possible"
            ]
        }
    ]
    
    async with db_manager.session() as session:
        for p_data in plans_data:
            plan = RCAPlan(
                plan_id=p_data["plan_id"],
                problem_pattern=p_data["problem_pattern"],
                trigger_conditions=p_data["trigger_conditions"],
                category=p_data["category"],
                root_causes=p_data["root_causes"],
                recommendations=p_data["recommendations"],
                validation_queries=[],
                times_used=random.randint(0, 50),
                success_rate=random.uniform(0.75, 0.95),
                is_active=True
            )
            session.add(plan)
        
        await session.commit()
    
    logger.info(f"Seeded {len(plans_data)} RCA plans")


async def init_database(seed_data: bool = True):
    """Initialize the complete database"""
    await db_manager.initialize()
    await create_tables()
    
    if seed_data:
        logger.info("Seeding initial data...")
        await seed_vendors()
        await seed_rca_plans()
        logger.info("Database seeding complete")


async def reset_database(seed_data: bool = True):
    """Reset the database (drop and recreate)"""
    await db_manager.initialize()
    await drop_tables()
    await create_tables()
    
    if seed_data:
        await seed_vendors()
        await seed_rca_plans()