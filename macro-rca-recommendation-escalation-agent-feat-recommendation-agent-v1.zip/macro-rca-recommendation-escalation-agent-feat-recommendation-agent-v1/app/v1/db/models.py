"""
Database ORM Models
====================
File: app/v1/db/models.py

SQLAlchemy ORM models for the Nokia Macro project database.
Includes pgvector support for embeddings.
"""

from datetime import datetime, date
from typing import Optional, List
from sqlalchemy import (
    Column, String, Integer, Float, Boolean, DateTime, Date,
    ForeignKey, Text, JSON, Enum, Index, UniqueConstraint
)
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import ARRAY
from pgvector.sqlalchemy import Vector

from .connection import Base


# =============================================================================
# Core Project Entities
# =============================================================================

class Site(Base):
    """Site/Tower entity - core entity for Nokia Macro project"""
    __tablename__ = "sites"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    site_code = Column(String(50), unique=True, nullable=False, index=True)
    smp_id = Column(String(50), index=True)
    project_id = Column(String(50), index=True)
    
    # Location
    market = Column(String(100), index=True)
    region = Column(String(100), index=True)
    address = Column(Text)
    latitude = Column(Float)
    longitude = Column(Float)
    
    # Assignment
    general_contractor_id = Column(Integer, ForeignKey("vendors.id"))
    project_track = Column(String(20))  # TMO_RPM, NAS, DEC
    
    # Status
    project_status = Column(String(50), default="Pending")  # Pending, In Progress, Completed
    current_milestone = Column(String(20))
    
    # Prerequisites
    entitlement_status = Column(String(50))
    ntp_status = Column(String(50))
    bom_status = Column(String(50))
    material_status = Column(String(50))
    power_status = Column(String(50))
    fiber_status = Column(String(50))
    
    # Quality
    quality_status = Column(String(50))  # Pass, Fail, Pending
    ftr_status = Column(Boolean)  # First Time Right
    
    # HSE Compliance
    check_in_status = Column(String(20))
    ppe_status = Column(String(20))
    jsa_status = Column(String(20))
    ptid_status = Column(String(20))
    
    # Dates
    assignment_date = Column(Date)
    ntp_date = Column(Date)
    civil_start_date = Column(Date)
    civil_complete_date = Column(Date)
    ran_start_date = Column(Date)
    ran_complete_date = Column(Date)
    integration_start_date = Column(Date)
    integration_complete_date = Column(Date)
    on_air_date = Column(Date)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    general_contractor = relationship("Vendor", back_populates="sites")
    milestones = relationship("SiteMilestone", back_populates="site")
    prerequisites = relationship("SitePrerequisite", back_populates="site")
    quality_records = relationship("QualityRecord", back_populates="site")
    
    __table_args__ = (
        Index("ix_sites_market_status", "market", "project_status"),
        Index("ix_sites_gc_status", "general_contractor_id", "project_status"),
    )


class Vendor(Base):
    """Vendor/General Contractor entity"""
    __tablename__ = "vendors"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    vendor_code = Column(String(50), unique=True, nullable=False)
    vendor_name = Column(String(200), nullable=False)
    
    # Classification
    vendor_type = Column(String(50))  # GC, Subcontractor, Supplier
    tier = Column(Integer)  # 1, 2, 3
    
    # Coverage
    markets = Column(ARRAY(String))  # List of markets covered
    regions = Column(ARRAY(String))  # List of regions covered
    
    # Capacity
    active_crews = Column(Integer, default=0)
    daily_capacity = Column(Float, default=0)
    
    # Performance Metrics (cached)
    ftr_rate = Column(Float)
    on_time_rate = Column(Float)
    compliance_rate = Column(Float)
    
    # Status
    is_active = Column(Boolean, default=True)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    sites = relationship("Site", back_populates="general_contractor")
    crews = relationship("Crew", back_populates="vendor")


class Crew(Base):
    """Crew entity - work crews assigned to vendors"""
    __tablename__ = "crews"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    crew_id = Column(String(50), unique=True, nullable=False)
    crew_name = Column(String(200))
    
    # Assignment
    vendor_id = Column(Integer, ForeignKey("vendors.id"))
    market = Column(String(100))
    
    # Capacity
    crew_size = Column(Integer)
    sites_per_day_capacity = Column(Float, default=1.0)
    
    # Training
    onboarding_date = Column(Date)
    last_training_date = Column(Date)
    certifications = Column(ARRAY(String))
    
    # Performance
    ftr_rate = Column(Float)
    sites_completed = Column(Integer, default=0)
    
    # Status
    status = Column(String(20), default="Active")  # Active, Inactive, Training
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    vendor = relationship("Vendor", back_populates="crews")


# =============================================================================
# Milestone and Workflow Entities
# =============================================================================

class SiteMilestone(Base):
    """Site milestone tracking"""
    __tablename__ = "site_milestones"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    site_id = Column(Integer, ForeignKey("sites.id"), nullable=False)
    
    milestone_code = Column(String(20), nullable=False)  # MS_1310, MS_1313, etc.
    milestone_name = Column(String(200))
    
    # Dates
    planned_date = Column(Date)
    actual_date = Column(Date)
    
    # Status
    status = Column(String(50))  # Pending, Completed, Delayed, Skipped
    delay_days = Column(Integer, default=0)
    delay_reason = Column(Text)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    site = relationship("Site", back_populates="milestones")
    
    __table_args__ = (
        UniqueConstraint("site_id", "milestone_code", name="uq_site_milestone"),
        Index("ix_milestones_site_code", "site_id", "milestone_code"),
    )


class SitePrerequisite(Base):
    """Site prerequisite tracking"""
    __tablename__ = "site_prerequisites"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    site_id = Column(Integer, ForeignKey("sites.id"), nullable=False)
    
    prerequisite_type = Column(String(50), nullable=False)  # power, fiber, ntp, etc.
    prerequisite_name = Column(String(200))
    
    # Status
    status = Column(String(50))  # Pending, Complete, Blocked
    blocker_reason = Column(Text)
    
    # Dates
    request_date = Column(Date)
    expected_date = Column(Date)
    complete_date = Column(Date)
    
    # Lead time tracking
    lead_time_days = Column(Integer)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    site = relationship("Site", back_populates="prerequisites")


# =============================================================================
# Quality and Compliance Entities
# =============================================================================

class QualityRecord(Base):
    """Quality inspection records"""
    __tablename__ = "quality_records"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    site_id = Column(Integer, ForeignKey("sites.id"), nullable=False)
    
    # Inspection details
    inspection_type = Column(String(50))  # Civil, RAN, Integration
    inspection_date = Column(Date)
    inspector_id = Column(String(50))
    
    # Results
    status = Column(String(20))  # Pass, Fail
    score = Column(Float)
    
    # Metrics
    vswr_pass = Column(Boolean)
    pim_pass = Column(Boolean)
    
    # NCR
    ncr_raised = Column(Boolean, default=False)
    ncr_id = Column(String(50))
    ncr_category = Column(String(100))
    
    # Rework
    requires_rework = Column(Boolean, default=False)
    rework_complete = Column(Boolean)
    
    # Material tracking
    material_batch = Column(String(100))
    supplier = Column(String(200))
    
    # Notes
    findings = Column(Text)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    site = relationship("Site", back_populates="quality_records")


class HSERecord(Base):
    """HSE (Health, Safety, Environment) compliance records"""
    __tablename__ = "hse_records"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    site_id = Column(Integer, ForeignKey("sites.id"), nullable=False)
    vendor_id = Column(Integer, ForeignKey("vendors.id"))
    crew_id = Column(String(50))
    
    # Inspection date
    inspection_date = Column(Date)
    
    # Compliance checks
    check_in_status = Column(String(20))  # Pass, Fail
    ppe_status = Column(String(20))
    jsa_status = Column(String(20))
    ptid_status = Column(String(20))
    
    # Overall
    overall_status = Column(String(20))  # Compliant, Non-Compliant
    compliance_score = Column(Float)
    
    # Violations
    violation_count = Column(Integer, default=0)
    violation_details = Column(JSON)
    
    # Action taken
    action_taken = Column(Text)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)


# =============================================================================
# RCA and Analytics Entities
# =============================================================================

class RCAPlan(Base):
    """Tier 1 curated RCA plans"""
    __tablename__ = "rca_plans"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    plan_id = Column(String(50), unique=True, nullable=False)
    
    # Pattern
    problem_pattern = Column(Text, nullable=False)
    trigger_conditions = Column(Text)
    category = Column(String(100))
    
    # Root causes (JSON array)
    root_causes = Column(JSON)  # [{cause: str, weight: float}]
    
    # Validation
    validation_queries = Column(JSON)  # List of SQL queries
    
    # Recommendations
    recommendations = Column(JSON)  # List of recommendations
    
    # Embedding for semantic search
    embedding = Column(Vector(1536))
    
    # Usage stats
    times_used = Column(Integer, default=0)
    success_rate = Column(Float)
    
    # Status
    is_active = Column(Boolean, default=True)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class HistoricalCase(Base):
    """Tier 2 historical RCA cases"""
    __tablename__ = "historical_cases"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    case_id = Column(String(50), unique=True, nullable=False)
    
    # Problem signature
    problem_signature = Column(JSON)
    symptom = Column(Text)
    
    # Investigation
    investigation_summary = Column(Text)
    tool_calls = Column(JSON)  # Record of tools used
    
    # Results
    root_cause_identified = Column(Text)
    resolution = Column(Text)
    outcome = Column(String(50))  # Success, Partial, Failed
    
    # Impact
    sites_affected = Column(Integer)
    improvement_achieved = Column(Float)
    
    # Embedding
    embedding = Column(Vector(1536))
    
    # Promotion tracking
    tier = Column(Integer, default=2)
    promoted_from_tier = Column(Integer)
    promotion_date = Column(DateTime)
    
    # Feedback
    feedback_positive = Column(Integer, default=0)
    feedback_negative = Column(Integer, default=0)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)


class Insight(Base):
    """Generated insights from the RCA system"""
    __tablename__ = "insights"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    insight_id = Column(String(50), unique=True, nullable=False)
    
    # Classification
    tier = Column(Integer)  # 1, 2, 3
    category = Column(String(100))
    insight_type = Column(String(50))  # actionable, informative, warning
    
    # Content
    title = Column(String(500))
    description = Column(Text)
    recommendation = Column(Text)
    
    # Priority
    priority = Column(String(20))  # critical, high, medium, low
    
    # Scope
    affected_entities = Column(JSON)  # {vendors: [], markets: [], sites: []}
    
    # Metrics
    metrics = Column(JSON)
    estimated_impact = Column(JSON)
    
    # Source
    source_query = Column(Text)
    source_root_cause_id = Column(String(50))
    execution_trace = Column(JSON)
    
    # Feedback
    feedback_status = Column(String(20))  # pending, positive, negative
    feedback_user = Column(String(100))
    feedback_timestamp = Column(DateTime)
    feedback_correction = Column(Text)
    
    # Status
    status = Column(String(20), default="active")  # active, acted_upon, dismissed
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# =============================================================================
# Operational Events
# =============================================================================

class OperationalEvent(Base):
    """Operational events and changes for correlation analysis"""
    __tablename__ = "operational_events"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(String(50), unique=True, nullable=False)
    
    # Event details
    event_type = Column(String(100))  # crew_change, policy_change, weather, etc.
    event_date = Column(Date, nullable=False)
    description = Column(Text)
    
    # Scope
    market = Column(String(100))
    region = Column(String(100))
    vendor_id = Column(Integer, ForeignKey("vendors.id"))
    
    # Affected entities
    affected_entity_type = Column(String(50))  # site, vendor, crew, market
    affected_entity_id = Column(String(100))
    affected_count = Column(Integer)
    
    # Impact
    impact_type = Column(String(50))  # positive, negative, neutral
    impact_magnitude = Column(Float)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        Index("ix_events_date_market", "event_date", "market"),
    )


# =============================================================================
# KPI Snapshots
# =============================================================================

class KPISnapshot(Base):
    """Daily KPI snapshots for trend analysis"""
    __tablename__ = "kpi_snapshots"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    
    # Dimensions
    snapshot_date = Column(Date, nullable=False)
    market = Column(String(100))
    region = Column(String(100))
    vendor_id = Column(Integer, ForeignKey("vendors.id"))
    
    # Schedule KPIs
    plan_achievement = Column(Float)
    productivity_daily = Column(Float)
    civil_delay_avg = Column(Float)
    ran_delay_avg = Column(Float)
    
    # Quality KPIs
    ftr_rate = Column(Float)
    rework_rate = Column(Float)
    qc_pass_rate = Column(Float)
    ncr_count = Column(Integer)
    
    # Compliance KPIs
    hse_compliance_rate = Column(Float)
    check_in_compliance = Column(Float)
    
    # Material KPIs
    material_availability = Column(Float)
    site_readiness_rate = Column(Float)
    
    # Counts
    total_sites = Column(Integer)
    completed_sites = Column(Integer)
    wip_sites = Column(Integer)
    blocked_sites = Column(Integer)
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    
    __table_args__ = (
        UniqueConstraint("snapshot_date", "market", "vendor_id", name="uq_kpi_snapshot"),
        Index("ix_kpi_date_market", "snapshot_date", "market"),
    )