"""
Database Connection Management
===============================
File: app/v1/db/connection.py

Manages database connections for:
- PostgreSQL (main project data)
- pgvector (vector embeddings for semantic search)
- Redis (caching layer)
"""

import os
from typing import Optional, AsyncGenerator
from contextlib import asynccontextmanager
import logging

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base
from sqlalchemy import text
import redis.asyncio as redis

logger = logging.getLogger(__name__)

# Base for ORM models
Base = declarative_base()


class DatabaseConfig:
    """Database configuration from environment"""
    
    # PostgreSQL
    POSTGRES_HOST: str = os.getenv("POSTGRES_HOST", "localhost")
    POSTGRES_PORT: int = int(os.getenv("POSTGRES_PORT", "5432"))
    POSTGRES_USER: str = os.getenv("POSTGRES_USER", "nokia_macro")
    POSTGRES_PASSWORD: str = os.getenv("POSTGRES_PASSWORD", "nokia_macro_pwd")
    POSTGRES_DB: str = os.getenv("POSTGRES_DB", "nokia_macro_db")
    
    # Redis
    REDIS_HOST: str = os.getenv("REDIS_HOST", "localhost")
    REDIS_PORT: int = int(os.getenv("REDIS_PORT", "6379"))
    REDIS_DB: int = int(os.getenv("REDIS_DB", "0"))
    REDIS_PASSWORD: Optional[str] = os.getenv("REDIS_PASSWORD")
    
    @property
    def postgres_url(self) -> str:
        return f"postgresql+asyncpg://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}@{self.POSTGRES_HOST}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
    
    @property
    def redis_url(self) -> str:
        if self.REDIS_PASSWORD:
            return f"redis://:{self.REDIS_PASSWORD}@{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"
        return f"redis://{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"


db_config = DatabaseConfig()


class DatabaseManager:
    """
    Manages all database connections.
    
    Connections:
    - PostgreSQL: Main relational data (sites, vendors, milestones)
    - pgvector: Vector embeddings for semantic search
    - Redis: Caching and session management
    """
    
    def __init__(self):
        self._engine = None
        self._session_factory = None
        self._redis_client = None
        self._initialized = False
    
    async def initialize(self):
        """Initialize all database connections"""
        if self._initialized:
            return
        
        logger.info("Initializing database connections...")
        
        # PostgreSQL with pgvector
        self._engine = create_async_engine(
            db_config.postgres_url,
            echo=False,
            pool_size=10,
            max_overflow=20,
            pool_pre_ping=True
        )
        
        self._session_factory = async_sessionmaker(
            bind=self._engine,
            class_=AsyncSession,
            expire_on_commit=False,
            autoflush=False
        )
        
        # Redis
        self._redis_client = redis.from_url(
            db_config.redis_url,
            encoding="utf-8",
            decode_responses=True
        )
        
        # Verify connections
        await self._verify_connections()
        
        self._initialized = True
        logger.info("Database connections initialized successfully")
    
    async def _verify_connections(self):
        """Verify all connections are working"""
        # Test PostgreSQL
        try:
            async with self._engine.begin() as conn:
                await conn.execute(text("SELECT 1"))
            logger.info("PostgreSQL connection verified")
        except Exception as e:
            logger.error(f"PostgreSQL connection failed: {e}")
            raise
        
        # Test pgvector extension
        try:
            async with self._engine.begin() as conn:
                await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
            logger.info("pgvector extension verified")
        except Exception as e:
            logger.warning(f"pgvector extension check failed (may not be critical): {e}")
        
        # Test Redis
        try:
            await self._redis_client.ping()
            logger.info("Redis connection verified")
        except Exception as e:
            logger.warning(f"Redis connection failed (caching disabled): {e}")
            self._redis_client = None
    
    @asynccontextmanager
    async def session(self) -> AsyncGenerator[AsyncSession, None]:
        """Get a database session"""
        if not self._initialized:
            await self.initialize()
        
        async with self._session_factory() as session:
            try:
                yield session
                await session.commit()
            except Exception:
                await session.rollback()
                raise
    
    @property
    def redis(self) -> Optional[redis.Redis]:
        """Get Redis client"""
        return self._redis_client
    
    @property
    def engine(self):
        """Get SQLAlchemy engine"""
        return self._engine
    
    async def close(self):
        """Close all connections"""
        if self._engine:
            await self._engine.dispose()
        if self._redis_client:
            await self._redis_client.close()
        self._initialized = False
        logger.info("Database connections closed")


# Global database manager instance
db_manager = DatabaseManager()


async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """Dependency for FastAPI to get database session"""
    async with db_manager.session() as session:
        yield session


async def get_redis() -> Optional[redis.Redis]:
    """Dependency for FastAPI to get Redis client"""
    if not db_manager._initialized:
        await db_manager.initialize()
    return db_manager.redis