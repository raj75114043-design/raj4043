"""
Cache Utilities
================
File: app/v1/utils/cache.py

Redis-based caching for performance optimization.
"""

import json
from typing import Any, Optional, Callable
from functools import wraps
from datetime import timedelta
import hashlib
import logging

from ..db import get_redis

logger = logging.getLogger(__name__)


class CacheService:
    """
    Redis-based caching service.
    """
    
    DEFAULT_TTL = 3600  # 1 hour
    
    def __init__(self):
        self._redis = None
    
    async def _get_redis(self):
        """Get Redis connection"""
        if self._redis is None:
            self._redis = await get_redis()
        return self._redis
    
    async def get(self, key: str) -> Optional[Any]:
        """
        Get value from cache.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None
        """
        redis = await self._get_redis()
        if not redis:
            return None
        
        try:
            value = await redis.get(key)
            if value:
                return json.loads(value)
            return None
        except Exception as e:
            logger.warning(f"Cache get failed for {key}: {e}")
            return None
    
    async def set(
        self,
        key: str,
        value: Any,
        ttl: Optional[int] = None
    ) -> bool:
        """
        Set value in cache.
        
        Args:
            key: Cache key
            value: Value to cache
            ttl: Time to live in seconds
            
        Returns:
            Success status
        """
        redis = await self._get_redis()
        if not redis:
            return False
        
        try:
            serialized = json.dumps(value, default=str)
            await redis.set(
                key,
                serialized,
                ex=ttl or self.DEFAULT_TTL
            )
            return True
        except Exception as e:
            logger.warning(f"Cache set failed for {key}: {e}")
            return False
    
    async def delete(self, key: str) -> bool:
        """Delete value from cache"""
        redis = await self._get_redis()
        if not redis:
            return False
        
        try:
            await redis.delete(key)
            return True
        except Exception as e:
            logger.warning(f"Cache delete failed for {key}: {e}")
            return False
    
    async def exists(self, key: str) -> bool:
        """Check if key exists in cache"""
        redis = await self._get_redis()
        if not redis:
            return False
        
        try:
            return await redis.exists(key) > 0
        except Exception as e:
            logger.warning(f"Cache exists check failed for {key}: {e}")
            return False
    
    async def clear_pattern(self, pattern: str) -> int:
        """
        Clear all keys matching pattern.
        
        Args:
            pattern: Key pattern (e.g., "rca:*")
            
        Returns:
            Number of keys deleted
        """
        redis = await self._get_redis()
        if not redis:
            return 0
        
        try:
            keys = await redis.keys(pattern)
            if keys:
                return await redis.delete(*keys)
            return 0
        except Exception as e:
            logger.warning(f"Cache clear pattern failed for {pattern}: {e}")
            return 0


# Singleton instance
cache_service = CacheService()


def generate_cache_key(*args, **kwargs) -> str:
    """
    Generate a cache key from arguments.
    """
    key_data = json.dumps({"args": args, "kwargs": kwargs}, sort_keys=True, default=str)
    return hashlib.md5(key_data.encode()).hexdigest()


def cached(
    prefix: str,
    ttl: int = 3600,
    key_builder: Optional[Callable] = None
):
    """
    Decorator for caching async function results.
    
    Args:
        prefix: Cache key prefix
        ttl: Time to live in seconds
        key_builder: Optional custom key builder function
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            # Build cache key
            if key_builder:
                key_suffix = key_builder(*args, **kwargs)
            else:
                key_suffix = generate_cache_key(*args, **kwargs)
            cache_key = f"{prefix}:{key_suffix}"
            # Try to get from cache
            cached_value = await cache_service.get(cache_key)
            if cached_value is not None:
                logger.info(f"Cache hit for {cache_key}")
                return cached_value
            
            logger.info(f"Cache miss for {cache_key}")
            # Call the original function
            result = await func(*args, **kwargs)
            # Store in cache            await cache_service.set(cache_key, result, ttl=ttl)
            return result
        return wrapper
    return decorator