"""
RCA Service
============
File: app/v1/services/rca_service.py

Business logic layer for Root Cause Analysis operations.
Integrates with the Tiered RCA system.
"""

from typing import List, Optional, Dict, Any
from datetime import datetime
import uuid
import logging
from sqlalchemy.ext.asyncio import AsyncSession

from ..repositories import (
    RCAPlanRepository,
    HistoricalCaseRepository,
    InsightRepository
)
from ..db import RCAPlan, HistoricalCase, Insight
from ..config import RCATier

logger = logging.getLogger(__name__)


class RCAService:
    """
    Service layer for RCA operations.
    
    Manages the three-tier RCA system:
    - Tier 1: Curated plans (instant lookup)
    - Tier 2: Historical cases (RAG search)
    - Tier 3: Agentic investigation
    """
    
    def __init__(self, session: AsyncSession):
        self.session = session
        self.plan_repo = RCAPlanRepository(session)
        self.case_repo = HistoricalCaseRepository(session)
        self.insight_repo = InsightRepository(session)
    
    # =========================================================================
    # Tier 1: Curated Plans
    # =========================================================================
    
    async def search_tier1_plans(
        self,
        symptom: str,
        embedding: List[float],
        threshold: float = 0.92
    ) -> List[Dict[str, Any]]:
        """Search Tier 1 curated plans by similarity"""
        matches = await self.plan_repo.search_by_similarity(
            embedding=embedding,
            threshold=threshold,
            top_k=5
        )
        
        # Increment usage for matches
        for match in matches:
            await self.plan_repo.increment_usage(match["plan_id"])
        
        return matches
    
    async def get_plan_by_category(self, category: str) -> List[RCAPlan]:
        """Get plans by category"""
        return await self.plan_repo.get_by_category(category)
    
    async def create_tier1_plan(self, data: Dict[str, Any]) -> RCAPlan:
        """Create a new Tier 1 curated plan"""
        plan_id = f"PLAN_{data.get('category', 'CUSTOM').upper()}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        data["plan_id"] = plan_id
        return await self.plan_repo.create(data)
    
    # =========================================================================
    # Tier 2: Historical Cases
    # =========================================================================
    
    async def search_tier2_cases(
        self,
        problem_signature: Dict[str, Any],
        embedding: List[float],
        threshold: float = 0.75
    ) -> List[Dict[str, Any]]:
        """Search Tier 2 historical cases by similarity"""
        return await self.case_repo.search_by_similarity(
            embedding=embedding,
            threshold=threshold,
            top_k=5
        )
    
    async def add_historical_case(
        self,
        problem_signature: Dict[str, Any],
        symptom: str,
        investigation_summary: str,
        root_cause: str,
        resolution: str,
        outcome: str,
        embedding: Optional[List[float]] = None
    ) -> HistoricalCase:
        """Add a new historical case (from Tier 3 validation)"""
        case_id = f"CASE_{datetime.now().strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex[:6]}"
        
        return await self.case_repo.add_case(
            case_id=case_id,
            problem_signature=problem_signature,
            symptom=symptom,
            investigation_summary=investigation_summary,
            root_cause=root_cause,
            resolution=resolution,
            outcome=outcome,
            embedding=embedding
        )
    
    async def get_promotion_candidates(self) -> List[HistoricalCase]:
        """Get cases ready for promotion to Tier 1"""
        return await self.case_repo.get_promotion_candidates()
    
    async def promote_case_to_tier1(self, case_id: str) -> Dict[str, Any]:
        """Promote a Tier 2 case to Tier 1"""
        case = await self.case_repo.get_by_case_id(case_id)
        if not case:
            return {"success": False, "error": "Case not found"}
        
        # Mark case as promoted
        await self.case_repo.promote_to_tier1(case_id)
        
        # Create new Tier 1 plan from case
        new_plan = await self.create_tier1_plan({
            "problem_pattern": case.symptom,
            "trigger_conditions": str(case.problem_signature),
            "category": "promoted",
            "root_causes": [{"cause": case.root_cause_identified, "weight": 0.8}],
            "recommendations": [case.resolution],
            "embedding": case.embedding
        })
        
        return {
            "success": True,
            "case_id": case_id,
            "new_plan_id": new_plan.plan_id
        }
    
    # =========================================================================
    # Insights Management
    # =========================================================================
    
    async def create_insight(
        self,
        tier: int,
        category: str,
        title: str,
        description: str,
        recommendation: str,
        priority: str,
        insight_type: str,
        affected_entities: Dict[str, Any],
        metrics: Dict[str, Any],
        source_query: str,
        source_root_cause_id: Optional[str] = None,
        execution_trace: Optional[List[Dict]] = None
    ) -> Insight:
        """Create a new insight"""
        insight_id = f"INS_{datetime.now().strftime('%Y%m%d')}_{uuid.uuid4().hex[:8]}"
        
        return await self.insight_repo.create({
            "insight_id": insight_id,
            "tier": tier,
            "category": category,
            "title": title,
            "description": description,
            "recommendation": recommendation,
            "priority": priority,
            "insight_type": insight_type,
            "affected_entities": affected_entities,
            "metrics": metrics,
            "source_query": source_query,
            "source_root_cause_id": source_root_cause_id,
            "execution_trace": execution_trace
        })
    
    async def get_recent_insights(
        self,
        limit: int = 20,
        category: Optional[str] = None,
        priority: Optional[str] = None
    ) -> List[Insight]:
        """Get recent insights"""
        return await self.insight_repo.get_recent_insights(
            limit=limit,
            category=category,
            priority=priority
        )
    
    async def record_insight_feedback(
        self,
        insight_id: str,
        feedback_type: str,
        user_id: str,
        correction: Optional[str] = None
    ) -> Dict[str, Any]:
        """Record feedback on an insight"""
        success = await self.insight_repo.record_feedback(
            insight_id=insight_id,
            feedback_type=feedback_type,
            user_id=user_id,
            correction=correction
        )
        
        if success and feedback_type == "positive":
            # Check if this should trigger learning loop
            insight = await self.insight_repo.get_by_insight_id(insight_id)
            if insight and insight.tier == 3:
                # Consider adding to Tier 2
                await self._process_tier3_feedback(insight)
        
        return {"success": success, "insight_id": insight_id}
    
    async def _process_tier3_feedback(self, insight: Insight) -> None:
        """Process positive feedback on Tier 3 insight"""
        logger.info(f"Processing Tier 3 feedback for insight {insight.insight_id}")
        
        # Extract information for historical case
        if insight.source_root_cause_id:
            # Create historical case from this investigation
            await self.add_historical_case(
                problem_signature=insight.affected_entities,
                symptom=insight.title,
                investigation_summary=insight.description,
                root_cause=insight.recommendation,
                resolution=insight.recommendation,
                outcome="Success"
            )
            logger.info(f"Created historical case from insight {insight.insight_id}")
    
    async def get_feedback_stats(self, days: int = 30) -> Dict[str, Any]:
        """Get feedback statistics"""
        return await self.insight_repo.get_feedback_stats(days)
    
    # =========================================================================
    # Pattern Analysis
    # =========================================================================
    
    async def analyze_pattern_frequency(self) -> Dict[str, Any]:
        """Analyze which patterns are most common"""
        plans = await self.plan_repo.get_active_plans()
        
        # Sort by usage
        sorted_plans = sorted(plans, key=lambda p: p.times_used or 0, reverse=True)
        
        return {
            "most_used": [
                {
                    "plan_id": p.plan_id,
                    "category": p.category,
                    "problem_pattern": p.problem_pattern,
                    "times_used": p.times_used,
                    "success_rate": p.success_rate
                }
                for p in sorted_plans[:10]
            ],
            "total_plans": len(plans),
            "total_usage": sum(p.times_used or 0 for p in plans)
        }
    
    async def get_rca_coverage_report(self) -> Dict[str, Any]:
        """Generate RCA coverage report"""
        plans = await self.plan_repo.get_active_plans()
        cases = await self.case_repo.get_all(limit=1000)
        
        # Categories covered
        tier1_categories = set(p.category for p in plans)
        tier2_categories = set()
        for case in cases:
            if case.problem_signature:
                category = case.problem_signature.get("category")
                if category:
                    tier2_categories.add(category)
        
        return {
            "tier1": {
                "plan_count": len(plans),
                "categories": list(tier1_categories),
                "avg_success_rate": sum(p.success_rate or 0 for p in plans) / len(plans) if plans else 0
            },
            "tier2": {
                "case_count": len(cases),
                "categories": list(tier2_categories)
            },
            "coverage_gaps": list(tier2_categories - tier1_categories)
        }