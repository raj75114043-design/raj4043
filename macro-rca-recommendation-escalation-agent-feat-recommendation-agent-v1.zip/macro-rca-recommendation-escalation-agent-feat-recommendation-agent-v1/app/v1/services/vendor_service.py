"""
Vendor Service
===============
File: app/v1/services/vendor_service.py

Business logic layer for vendor operations.
"""

from typing import List, Optional, Dict, Any
from datetime import date
from sqlalchemy.ext.asyncio import AsyncSession
import logging

from ..repositories import VendorRepository
from ..db import Vendor

logger = logging.getLogger(__name__)


class VendorService:
    """
    Service layer for Vendor operations.
    
    Encapsulates business logic for vendor management and performance tracking.
    """
    
    def __init__(self, session: AsyncSession):
        self.repository = VendorRepository(session)
        self.session = session
    
    async def get_vendor(self, vendor_code: str) -> Optional[Vendor]:
        """Get a vendor by vendor code"""
        return await self.repository.get_by_vendor_code(vendor_code)
    
    async def get_active_vendors(
        self,
        market: Optional[str] = None
    ) -> List[Vendor]:
        """Get all active vendors"""
        return await self.repository.get_active_vendors(market)
    
    async def get_vendor_performance_report(
        self,
        market: Optional[str] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None
    ) -> Dict[str, Any]:
        """Generate vendor performance report"""
        performance = await self.repository.get_vendor_performance(
            market=market,
            start_date=start_date,
            end_date=end_date
        )
        
        if not performance:
            return {"vendors": [], "summary": {}}
        
        # Calculate summary stats
        total_sites = sum(v["total_sites"] for v in performance)
        avg_ftr = sum(v["ftr_rate"] * v["total_sites"] for v in performance) / total_sites if total_sites > 0 else 0
        avg_cycle_time = sum(v["avg_cycle_time"] * v["total_sites"] for v in performance) / total_sites if total_sites > 0 else 0
        
        # Identify underperformers
        underperformers = [v for v in performance if v["ftr_rate"] < 85]
        
        return {
            "vendors": performance,
            "summary": {
                "total_vendors": len(performance),
                "total_sites": total_sites,
                "avg_ftr_rate": round(avg_ftr, 2),
                "avg_cycle_time": round(avg_cycle_time, 2),
                "underperformer_count": len(underperformers)
            },
            "underperformers": underperformers
        }
    
    async def get_vendor_productivity_report(
        self,
        vendor_code: Optional[str] = None,
        start_date: Optional[date] = None
    ) -> Dict[str, Any]:
        """Generate vendor productivity report"""
        vendor_id = None
        if vendor_code:
            vendor = await self.repository.get_by_vendor_code(vendor_code)
            vendor_id = vendor.id if vendor else None
        
        productivity = await self.repository.get_vendor_productivity(
            vendor_id=vendor_id,
            start_date=start_date
        )
        
        if not productivity:
            return {"data": [], "summary": {}}
        
        # Group by vendor
        by_vendor = {}
        for p in productivity:
            vendor = p["vendor"]
            if vendor not in by_vendor:
                by_vendor[vendor] = []
            by_vendor[vendor].append(p)
        
        # Calculate averages
        vendor_averages = {}
        for vendor, weeks in by_vendor.items():
            avg = sum(w["sites_completed"] for w in weeks) / len(weeks)
            vendor_averages[vendor] = round(avg, 2)
        
        return {
            "data": productivity,
            "by_vendor": by_vendor,
            "averages": vendor_averages
        }
    
    async def get_hse_compliance_report(
        self,
        market: Optional[str] = None,
        start_date: Optional[date] = None
    ) -> Dict[str, Any]:
        """Generate HSE compliance report"""
        compliance = await self.repository.get_vendor_hse_compliance(
            market=market,
            start_date=start_date
        )
        
        if not compliance:
            return {"vendors": [], "summary": {}}
        
        # Calculate summary
        total_inspections = sum(v["total_inspections"] for v in compliance)
        weighted_compliance = sum(
            v["compliance_rate"] * v["total_inspections"] 
            for v in compliance
        ) / total_inspections if total_inspections > 0 else 0
        
        # Identify non-compliant vendors
        non_compliant = [v for v in compliance if v["compliance_rate"] < 95]
        
        return {
            "vendors": compliance,
            "summary": {
                "total_vendors": len(compliance),
                "total_inspections": total_inspections,
                "overall_compliance_rate": round(weighted_compliance, 2),
                "non_compliant_count": len(non_compliant)
            },
            "non_compliant": non_compliant
        }
    
    async def get_bottom_performers(
        self,
        n: int = 5,
        metric: str = "ftr_rate"
    ) -> List[Dict[str, Any]]:
        """Get bottom N performing vendors"""
        return await self.repository.get_bottom_performers(n, metric)
    
    async def analyze_vendor_issues(
        self,
        vendor_code: str
    ) -> Dict[str, Any]:
        """Deep analysis of a specific vendor's issues"""
        vendor = await self.repository.get_by_vendor_code(vendor_code)
        if not vendor:
            return {"error": f"Vendor {vendor_code} not found"}
        
        # Get performance
        performance = await self.repository.get_vendor_performance(vendor_id=vendor.id)
        
        # Get compliance
        compliance = await self.repository.get_vendor_hse_compliance()
        vendor_compliance = next(
            (c for c in compliance if c["vendor"] == vendor_code),
            None
        )
        
        # Identify issues
        issues = []
        
        if performance and performance[0]["ftr_rate"] < 85:
            issues.append({
                "type": "quality",
                "severity": "high",
                "description": f"FTR rate ({performance[0]['ftr_rate']:.1f}%) below threshold (85%)",
                "metric": "ftr_rate",
                "value": performance[0]["ftr_rate"],
                "threshold": 85
            })
        
        if vendor_compliance and vendor_compliance["compliance_rate"] < 95:
            issues.append({
                "type": "compliance",
                "severity": "high",
                "description": f"HSE compliance ({vendor_compliance['compliance_rate']:.1f}%) below threshold (95%)",
                "metric": "compliance_rate",
                "value": vendor_compliance["compliance_rate"],
                "threshold": 95
            })
        
        return {
            "vendor": vendor_code,
            "vendor_name": vendor.vendor_name,
            "performance": performance[0] if performance else None,
            "compliance": vendor_compliance,
            "issues": issues,
            "issue_count": len(issues)
        }
    
    async def update_vendor_status(
        self,
        vendor_code: str,
        is_active: bool
    ) -> Optional[Vendor]:
        """Activate or deactivate a vendor"""
        vendor = await self.repository.get_by_vendor_code(vendor_code)
        if vendor:
            return await self.repository.update(vendor.id, {"is_active": is_active})
        return None