"""
Site Service
=============
File: app/v1/services/site_service.py

Business logic layer for site operations.
"""

from typing import List, Optional, Dict, Any
from datetime import date, datetime
from sqlalchemy.ext.asyncio import AsyncSession
import logging

from ..repositories import SiteRepository
from ..db import Site

logger = logging.getLogger(__name__)


class SiteService:
    """
    Service layer for Site operations.
    
    Encapsulates business logic and orchestrates repository calls.
    """
    
    def __init__(self, session: AsyncSession):
        self.repository = SiteRepository(session)
        self.session = session
    
    async def get_site(self, site_code: str) -> Optional[Site]:
        """Get a site by site code"""
        return await self.repository.get_by_site_code(site_code)
    
    async def get_sites_by_market(
        self,
        market: str,
        status: Optional[str] = None,
        include_details: bool = False
    ) -> List[Site]:
        """Get sites for a market"""
        if include_details:
            return await self.repository.get_sites_with_details(market=market)
        return await self.repository.get_by_market(market, status)
    
    async def get_market_summary(
        self,
        market: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Get site status summary by market"""
        return await self.repository.get_status_summary_by_market(market)
    
    async def get_blocked_sites_analysis(
        self,
        market: Optional[str] = None
    ) -> Dict[str, Any]:
        """Analyze blocked sites and their blockers"""
        blocked = await self.repository.get_blocked_sites(market)
        
        # Categorize blockers
        blockers = {
            "ntp": 0,
            "power": 0,
            "fiber": 0,
            "material": 0
        }
        
        for site in blocked:
            if site.ntp_status != "Approved":
                blockers["ntp"] += 1
            if site.power_status != "Ready":
                blockers["power"] += 1
            if site.fiber_status != "Ready":
                blockers["fiber"] += 1
            if site.material_status != "Ready":
                blockers["material"] += 1
        
        return {
            "total_blocked": len(blocked),
            "blockers": blockers,
            "sites": [
                {
                    "site_code": s.site_code,
                    "market": s.market,
                    "ntp_status": s.ntp_status,
                    "power_status": s.power_status,
                    "fiber_status": s.fiber_status,
                    "material_status": s.material_status
                }
                for s in blocked[:20]  # Top 20
            ]
        }
    
    async def get_readiness_analysis(
        self,
        market: Optional[str] = None
    ) -> Dict[str, Any]:
        """Get site readiness analysis"""
        readiness = await self.repository.get_readiness_rate(market)
        
        # Determine status
        rate = readiness["readiness_rate"]
        if rate >= 95:
            status = "green"
        elif rate >= 80:
            status = "amber"
        else:
            status = "red"
        
        return {
            **readiness,
            "status": status,
            "gap_to_target": max(0, 95 - rate)
        }
    
    async def get_ftr_analysis(
        self,
        market: Optional[str] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None
    ) -> Dict[str, Any]:
        """Get FTR analysis by vendor"""
        ftr_data = await self.repository.get_ftr_by_vendor(
            start_date=start_date,
            end_date=end_date,
            market=market
        )
        
        if not ftr_data:
            return {"vendors": [], "summary": {}}
        
        # Calculate summary
        total_sites = sum(v["total_sites"] for v in ftr_data)
        total_ftr_pass = sum(v["ftr_pass"] for v in ftr_data)
        overall_ftr = (total_ftr_pass / total_sites * 100) if total_sites > 0 else 0
        
        # Identify worst performers
        worst_performers = [v for v in ftr_data if v["ftr_rate"] < 85]
        
        return {
            "vendors": ftr_data,
            "summary": {
                "total_sites": total_sites,
                "overall_ftr_rate": round(overall_ftr, 2),
                "worst_performer_count": len(worst_performers),
                "worst_performers": worst_performers
            }
        }
    
    async def get_sla_analysis(
        self,
        market: Optional[str] = None,
        sla_type: str = "civil",
        start_date: Optional[date] = None
    ) -> Dict[str, Any]:
        """Get SLA breach analysis"""
        sla_days = 21 if sla_type == "civil" else 14
        breaches = await self.repository.get_sla_breaches(
            sla_type=sla_type,
            sla_days=sla_days,
            start_date=start_date,
            market=market
        )
        
        if not breaches:
            return {
                "breaches": [],
                "summary": {"total_breaches": 0, "sla_type": sla_type, "sla_days": sla_days}
            }
        
        # Group by vendor
        vendor_breaches = {}
        for b in breaches:
            vendor = b["vendor"]
            if vendor not in vendor_breaches:
                vendor_breaches[vendor] = []
            vendor_breaches[vendor].append(b)
        
        return {
            "breaches": breaches,
            "summary": {
                "total_breaches": len(breaches),
                "sla_type": sla_type,
                "sla_days": sla_days,
                "avg_delay_days": sum(b["duration_days"] for b in breaches) / len(breaches),
                "max_delay_days": max(b["duration_days"] for b in breaches),
                "by_vendor": {v: len(sites) for v, sites in vendor_breaches.items()}
            }
        }
    
    async def create_site(self, data: Dict[str, Any]) -> Site:
        """Create a new site"""
        return await self.repository.create(data)
    
    async def update_site_status(
        self,
        site_code: str,
        status: str,
        milestone: Optional[str] = None
    ) -> Optional[Site]:
        """Update site status"""
        site = await self.repository.get_by_site_code(site_code)
        if site:
            update_data = {"project_status": status}
            if milestone:
                update_data["current_milestone"] = milestone
            return await self.repository.update(site.id, update_data)
        return None