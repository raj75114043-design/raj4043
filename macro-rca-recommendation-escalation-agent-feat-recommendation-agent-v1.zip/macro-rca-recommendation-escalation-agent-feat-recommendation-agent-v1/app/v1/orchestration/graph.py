"""
LangGraph Orchestrator
=======================
File: app/v1/orchestration/graph.py

Central coordinator that manages the conversation between agents and ensures quality.
Implements the Multi-Agent System using LangGraph StateGraph.

Responsibilities:
- Intent classification: Determine query type (diagnostic, prescriptive, predictive)
- Agent invocation: Decide which agents to activate and in what configuration
- State management: Maintain shared context (evidence gathered, causes identified)
- Quality gate: Check if recommendation meets quality criteria before returning
- Loop control: Decide when to iterate (need more data) vs finalize
"""

from typing import Dict, Any, List, Literal, Optional
from datetime import datetime
import logging
from langgraph.graph import StateGraph, END
from langgraph.checkpoint.memory import MemorySaver

from ..config import settings, AgentType
from ..models import (
    AgentState, AgentStatus, IntentType,
    AgentResponse, AgentRequest, InsightOutput
)
from ..agents import (
    planner_agent, data_agent, analyst_agent, 
    rca_agent, recommender_agent
)

logger = logging.getLogger(__name__)


class RCARecommenderOrchestrator:
    """
    Orchestrator for the RCA + Recommender Multi-Agent System.
    
    Uses LangGraph to coordinate:
    - 📋 Planner Agent: Decompose query, identify data needs
    - 🔍 Data Agent: Fetch evidence from all sources
    - 🔬 Analyst Agent: Statistical analysis, pattern detection
    - 🎯 RCA Agent: Root cause identification
    - 💡 Recommender Agent: Generate actions + quantify impact
    """
    
    def __init__(self):
        self.max_iterations = settings.guardrails.max_iterations
        self.checkpointer = MemorySaver()
        self.graph = self._build_graph()
    
    def _build_graph(self) -> StateGraph:
        """Build the LangGraph state machine"""
        
        # Create the graph with AgentState
        workflow = StateGraph(AgentState)
        
        # Add nodes for each agent
        workflow.add_node("planner", self._run_planner)
        workflow.add_node("data_agent", self._run_data_agent)
        workflow.add_node("analyst", self._run_analyst)
        workflow.add_node("rca_agent", self._run_rca_agent)
        workflow.add_node("recommender", self._run_recommender)
        workflow.add_node("quality_gate", self._quality_gate)
        
        # Set entry point
        workflow.set_entry_point("planner")
        
        # Add edges
        # Planner -> Data Agent (always)
        workflow.add_edge("planner", "data_agent")
        
        # Data Agent -> Analyst (always)
        workflow.add_edge("data_agent", "analyst")
        
        # Analyst -> RCA Agent (for diagnostic/prescriptive queries)
        workflow.add_conditional_edges(
            "analyst",
            self._should_run_rca,
            {
                "rca": "rca_agent",
                "quality_gate": "quality_gate"
            }
        )
        
        # RCA Agent -> Recommender (for prescriptive queries)
        workflow.add_conditional_edges(
            "rca_agent",
            self._should_run_recommender,
            {
                "recommender": "recommender",
                "quality_gate": "quality_gate"
            }
        )
        
        # Recommender -> Quality Gate
        workflow.add_edge("recommender", "quality_gate")
        
        # Quality Gate -> END or iterate
        workflow.add_conditional_edges(
            "quality_gate",
            self._check_quality,
            {
                "complete": END,
                "iterate_data": "data_agent",
                "iterate_rca": "rca_agent"
            }
        )
        
        return workflow.compile(checkpointer=self.checkpointer)
    
    # =========================================================================
    # Node Functions (Agent Runners)
    # =========================================================================
    
    async def _run_planner(self, state: AgentState) -> AgentState:
        """Run the Planner Agent"""
        logger.info("[Orchestrator] Running Planner Agent")
        try:
            state = await planner_agent.process(state)
            state.status = AgentStatus.PLANNING
        except Exception as e:
            logger.error(f"[Orchestrator] Planner error: {e}")
            state.errors.append(f"Planner error: {str(e)}")
        return state
    
    async def _run_data_agent(self, state: AgentState) -> AgentState:
        """Run the Data Agent"""
        logger.info("[Orchestrator] Running Data Agent")
        try:
            state = await data_agent.process(state)
            state.status = AgentStatus.GATHERING
        except Exception as e:
            logger.error(f"[Orchestrator] Data Agent error: {e}")
            state.errors.append(f"Data Agent error: {str(e)}")
        return state
    
    async def _run_analyst(self, state: AgentState) -> AgentState:
        """Run the Analyst Agent"""
        logger.info("[Orchestrator] Running Analyst Agent")
        try:
            state = await analyst_agent.process(state)
            state.status = AgentStatus.ANALYZING
        except Exception as e:
            logger.error(f"[Orchestrator] Analyst error: {e}")
            state.errors.append(f"Analyst error: {str(e)}")
        return state
    
    async def _run_rca_agent(self, state: AgentState) -> AgentState:
        """Run the RCA Agent"""
        logger.info("[Orchestrator] Running RCA Agent")
        try:
            state = await rca_agent.process(state)
        except Exception as e:
            logger.error(f"[Orchestrator] RCA Agent error: {e}")
            state.errors.append(f"RCA Agent error: {str(e)}")
        return state
    
    async def _run_recommender(self, state: AgentState) -> AgentState:
        """Run the Recommender Agent"""
        logger.info("[Orchestrator] Running Recommender Agent")
        try:
            state = await recommender_agent.process(state)
            state.status = AgentStatus.RECOMMENDING
        except Exception as e:
            logger.error(f"[Orchestrator] Recommender error: {e}")
            state.errors.append(f"Recommender error: {str(e)}")
        return state
    
    async def _quality_gate(self, state: AgentState) -> AgentState:
        """
        Quality Gate - Check if response meets quality criteria.
        
        Quality Requirements:
        - Specific: Must include exact numbers, site names, vendor names
        - Validated: All numbers computed by tools, not LLM arithmetic
        - Significant: Statistical significance or threshold breach
        - Prioritized: Ranked by business impact
        - Traceable: Full audit trail
        """
        logger.info("[Orchestrator] Running Quality Gate")
        
        # Check evidence
        state.has_evidence = len(state.evidence.data_tables) > 0
        
        # Check root causes
        state.has_root_cause = len(state.analysis.root_causes) > 0
        
        # Check impact quantification
        state.has_quantified_impact = any(
            rec.impact.get("estimated_improvement", 0) > 0 
            for rec in state.recommendations
        )
        
        # Increment iteration
        state.iteration_count += 1
        
        logger.info(f"[Orchestrator] Quality Gate - Evidence: {state.has_evidence}, "
                   f"Root Cause: {state.has_root_cause}, "
                   f"Impact: {state.has_quantified_impact}, "
                   f"Iteration: {state.iteration_count}")
        
        return state
    
    # =========================================================================
    # Conditional Edge Functions (Routing)
    # =========================================================================
    
    def _should_run_rca(self, state: AgentState) -> Literal["rca", "quality_gate"]:
        """Determine if RCA Agent should run"""
        # Run RCA for diagnostic or prescriptive intents
        if IntentType.DIAGNOSTIC in state.intent or IntentType.PRESCRIPTIVE in state.intent:
            return "rca"
        return "quality_gate"
    
    def _should_run_recommender(self, state: AgentState) -> Literal["recommender", "quality_gate"]:
        """Determine if Recommender should run"""
        # Run Recommender for prescriptive intent and if we have root causes
        if IntentType.PRESCRIPTIVE in state.intent and state.has_root_cause:
            return "recommender"
        return "quality_gate"
    
    def _check_quality(self, state: AgentState) -> Literal["complete", "iterate_data", "iterate_rca"]:
        """Check quality and determine next action"""
        
        # Max iterations reached
        if state.iteration_count >= self.max_iterations:
            logger.info("[Orchestrator] Max iterations reached, completing")
            return "complete"
        
        # Check if we need more data
        if IntentType.DIAGNOSTIC in state.intent and not state.has_evidence:
            logger.info("[Orchestrator] Need more evidence, iterating data")
            return "iterate_data"
        
        # Check if we need RCA
        if IntentType.DIAGNOSTIC in state.intent and not state.has_root_cause:
            if state.has_evidence:
                logger.info("[Orchestrator] Need root cause, iterating RCA")
                return "iterate_rca"
        
        # Check prescriptive requirements
        if IntentType.PRESCRIPTIVE in state.intent:
            if settings.guardrails.require_evidence and not state.has_evidence:
                return "iterate_data"
            if settings.guardrails.require_root_cause and not state.has_root_cause:
                return "iterate_rca"
            if settings.guardrails.require_quantified_impact and not state.has_quantified_impact:
                # Try recommender again
                return "complete"  # Don't loop infinitely
        
        return "complete"
    
    # =========================================================================
    # Public API
    # =========================================================================
    
    async def run(self, request: AgentRequest) -> AgentResponse:
        """
        Run the RCA + Recommender agent system.
        
        Args:
            request: The agent request with query and context
            
        Returns:
            AgentResponse with evidence, root causes, and recommendations
        """
        start_time = datetime.now()
        
        # Initialize state
        initial_state = AgentState(
            query=request.query,
            context=request.context or {},
            filters=request.filters or {},
            max_iterations=request.max_iterations,
            start_time=start_time
        )
        
        # Set deep investigation flag if requested
        if request.require_deep_investigation:
            initial_state.context["require_deep_investigation"] = True
        
        logger.info(f"[Orchestrator] Starting execution for query: {request.query[:100]}...")
        
        try:
            # Run the graph
            config = {"configurable": {"thread_id": f"thread_{start_time.timestamp()}"}}
            final_state = await self.graph.ainvoke(initial_state, config)
            
            # Mark completion
            final_state.status = AgentStatus.COMPLETE
            final_state.end_time = datetime.now()
            
            # Generate response
            response = self._build_response(final_state)
            
            logger.info(f"[Orchestrator] Completed in {response.total_time_seconds:.2f}s "
                       f"with {len(response.root_causes)} root causes and "
                       f"{len(response.recommendations)} recommendations")
            
            return response
            
        except Exception as e:
            logger.error(f"[Orchestrator] Execution error: {e}")
            return AgentResponse(
                success=False,
                query=request.query,
                evidence_summary="Execution failed",
                error_message=str(e),
                total_time_seconds=(datetime.now() - start_time).total_seconds(),
                iterations_used=0
            )
    
    def _build_response(self, state: AgentState) -> AgentResponse:
        """Build the final response from state"""
        
        # Build evidence summary
        evidence_summary = self._summarize_evidence(state)
        
        # Generate insights from recommendations
        insights = []
        if state.recommendations:
            insights = recommender_agent.generate_insights(state)
        
        # Build execution trace
        trace = self._build_trace(state)
        
        return AgentResponse(
            success=len(state.errors) == 0,
            query=state.query,
            evidence_summary=evidence_summary,
            root_causes=state.analysis.root_causes,
            recommendations=state.recommendations,
            insights=insights,
            execution_trace=trace,
            total_time_seconds=(state.end_time - state.start_time).total_seconds() if state.end_time and state.start_time else 0,
            iterations_used=state.iteration_count,
            error_message="; ".join(state.errors) if state.errors else None
        )
    
    def _summarize_evidence(self, state: AgentState) -> str:
        """Generate a summary of gathered evidence"""
        parts = []
        
        # Count evidence items
        data_count = len(state.evidence.data_tables)
        if data_count > 0:
            parts.append(f"Gathered {data_count} data sources")
        
        # Summarize key metrics
        metrics = state.evidence.metrics
        if metrics:
            if any("ftr" in k.lower() for k in metrics.keys()):
                ftr_keys = [k for k in metrics.keys() if "avg_ftr" in k.lower()]
                if ftr_keys:
                    avg_ftr = metrics[ftr_keys[0]]
                    parts.append(f"Average FTR: {avg_ftr:.1f}%")
            
            if any("total_sites" in k for k in metrics.keys()):
                total_keys = [k for k in metrics.keys() if "total_sites" in k]
                if total_keys:
                    total = metrics[total_keys[0]]
                    parts.append(f"Total sites: {total}")
        
        # Summarize findings
        findings_count = len(state.analysis.findings)
        significant_count = len([f for f in state.analysis.findings if f.is_significant])
        if findings_count > 0:
            parts.append(f"Found {significant_count} significant patterns out of {findings_count} analyzed")
        
        return ". ".join(parts) if parts else "No evidence gathered"
    
    def _build_trace(self, state: AgentState) -> List[Dict[str, Any]]:
        """Build execution trace from tool calls and messages"""
        trace = []
        
        # Add tool calls
        for tc in state.tool_calls:
            trace.append({
                "type": "tool_call",
                "tool": tc.tool_name,
                "success": tc.success,
                "execution_time_ms": tc.execution_time_ms,
                "timestamp": tc.timestamp.isoformat() if tc.timestamp else None
            })
        
        # Add messages
        for msg in state.messages:
            trace.append({
                "type": "message",
                "from": msg.from_agent,
                "to": msg.to_agent,
                "action": msg.action,
                "timestamp": msg.timestamp.isoformat() if msg.timestamp else None
            })
        
        # Sort by timestamp
        trace.sort(key=lambda x: x.get("timestamp", ""))
        
        return trace


# Create singleton orchestrator
orchestrator = RCARecommenderOrchestrator()


async def run_rca_recommender(request: AgentRequest) -> AgentResponse:
    """
    Main entry point for running the RCA + Recommender system.
    
    Args:
        request: AgentRequest with query and context
        
    Returns:
        AgentResponse with complete analysis results
    """
    return await orchestrator.run(request)
