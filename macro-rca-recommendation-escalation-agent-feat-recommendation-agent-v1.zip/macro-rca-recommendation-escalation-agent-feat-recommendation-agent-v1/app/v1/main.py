"""
Nokia Macro RCA + Recommender Agent
====================================
File: app/v1/main.py

Main FastAPI application entry point.

This is a Multi-Agent System (MAS) for Root Cause Analysis and Recommendations
based on the Nokia Detailed Architecture document.

Architecture:
- Foundation Layer: Shared tools and knowledge registries
- Execution Layer: Specialized agents (Planner, Data, Analyst, RCA, Recommender)
- Orchestration Layer: LangGraph-based coordination

Usage:
    uvicorn app.v1.main:app --reload --port 8001
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import logging

from .config import settings
from .api import router as rca_router

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Nokia Macro RCA + Recommender Agent",
    description="""
    Multi-Agent System for Root Cause Analysis and Recommendations.
    
    ## Features
    
    - **Tiered RCA System**: 3-tier analysis (curated plans → historical cases → agentic investigation)
    - **Multi-Agent Architecture**: 5 specialized agents coordinated via LangGraph
    - **Foundation Layer**: Shared tools (SQL, Python Sandbox, Vector Store, Feedback Loop)
    - **Continuous Learning**: Feedback loop for pattern promotion
    
    ## Agents
    
    1. **Planner**: Decomposes queries, identifies data requirements
    2. **Data Agent**: Fetches evidence from all sources
    3. **Analyst**: Statistical analysis, pattern detection
    4. **RCA Agent**: Root cause identification using Tiered RCA
    5. **Recommender**: Generates actionable recommendations with quantified impact
    
    ## Project Tracks Supported
    
    - TMO RPM (Telecom Rollout Project Management)
    - NAS (Network Activation Services)
    - DEC (Delivery Excellence & Compliance)
    """,
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(rca_router, prefix="/api/v1")


@app.on_event("startup")
async def startup_event():
    """Initialize services on startup"""
    logger.info("Starting Nokia Macro RCA + Recommender Agent...")
    logger.info(f"Unified Layer URL: {settings.unified_layer.base_url}")
    logger.info(f"Max iterations: {settings.guardrails.max_iterations}")
    logger.info(f"RCA Tier 1 threshold: {settings.rca.tier1_similarity_threshold}")


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    logger.info("Shutting down Nokia Macro RCA + Recommender Agent...")


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Nokia Macro RCA + Recommender Agent",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs",
        "api": "/api/v1/rca"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)
