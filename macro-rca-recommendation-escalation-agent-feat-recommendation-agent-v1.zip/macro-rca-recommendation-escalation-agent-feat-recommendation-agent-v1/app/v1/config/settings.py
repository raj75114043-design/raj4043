"""
Nokia Macro Agent Configuration Settings
=========================================
File: app/v1/config/settings.py

Central configuration for the RCA + Recommender Agent system.
Based on the Nokia Detailed Architecture for MACRO project.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional
from enum import Enum
import os


class ProjectTrack(Enum):
    """Three project tracks in Nokia Macro business"""
    TMO_RPM = "TMO_RPM"  # Telecom Rollout Project Management
    NAS = "NAS"          # Network Activation Services  
    DEC = "DEC"          # Delivery Excellence & Compliance


class AgentType(Enum):
    """Types of specialized agents in the system"""
    ORCHESTRATOR = "orchestrator"
    PLANNER = "planner"
    DATA_AGENT = "data_agent"
    ANALYST = "analyst"
    RCA_AGENT = "rca_agent"
    RECOMMENDER = "recommender"


class RCATier(Enum):
    """Three-tier RCA system"""
    TIER_1 = 1  # Instant Lookup - Curated Plans (<2 seconds)
    TIER_2 = 2  # Fast Synthesis - RAG + Historical Cases (5-10 seconds)
    TIER_3 = 3  # Deep Investigation - Agentic RCA (30-60 seconds)


@dataclass
class LLMConfig:
    """LLM configuration for agents"""
    model_name: str = os.getenv("LLM_MODEL_NAME", "gpt-4o")
    temperature: float = 0.1
    api_key: Optional[str] = os.getenv("LLM_API_KEY")
    max_tokens: int = 4096
    timeout: int = 60


@dataclass
class UnifiedLayerConfig:
    """Unified Layer microservice configuration"""
    base_url: str = os.getenv("UNIFIED_LAYER_URL", "http://localhost:8000/api/v1")
    timeout: int = 30
    retry_count: int = 3


@dataclass
class VectorStoreConfig:
    """Vector store configuration for semantic search"""
    embedding_model: str = "text-embedding-3-small"
    embedding_dimension: int = 1536
    similarity_threshold: float = 0.85
    top_k: int = 5


@dataclass
class RCAConfig:
    """RCA system configuration"""
    tier1_similarity_threshold: float = 0.92
    tier2_similarity_threshold: float = 0.75
    tier3_max_tool_calls: int = 8
    confidence_threshold: float = 0.85
    min_sample_size: int = 10
    p_value_threshold: float = 0.05


@dataclass
class AgentGuardrails:
    """Guardrails for agent execution"""
    max_iterations: int = 3
    max_tool_calls: int = 15
    timeout_seconds: int = 60
    require_evidence: bool = True
    require_root_cause: bool = True
    require_quantified_impact: bool = True


@dataclass
class KPIThresholds:
    """KPI thresholds for the Nokia Macro project"""
    # Quality
    ftr_red: float = 85.0
    ftr_amber: float = 95.0
    ftr_green: float = 100.0
    
    # Schedule
    civil_sla_days: int = 21
    ran_sla_days: int = 14
    
    # Compliance
    hse_compliance_threshold: float = 95.0
    on_time_delivery_threshold: float = 90.0
    
    # Resource
    crew_utilization_target: float = 85.0


@dataclass
class Settings:
    """Main configuration class"""
    llm: LLMConfig = field(default_factory=LLMConfig)
    unified_layer: UnifiedLayerConfig = field(default_factory=UnifiedLayerConfig)
    vector_store: VectorStoreConfig = field(default_factory=VectorStoreConfig)
    rca: RCAConfig = field(default_factory=RCAConfig)
    guardrails: AgentGuardrails = field(default_factory=AgentGuardrails)
    kpi_thresholds: KPIThresholds = field(default_factory=KPIThresholds)
    
    # Logging
    log_level: str = os.getenv("LOG_LEVEL", "INFO")
    enable_trace_logging: bool = True


# Global settings instance
settings = Settings()


# =============================================================================
# MACRO Project Domain Constants
# =============================================================================

# Workflow phases for Nokia Macro (7 phases)
WORKFLOW_PHASES = {
    1: {
        "name": "Site Assignment & GC Assignment",
        "milestones": ["MS_1310"],
        "description": "T-Mobile assigns sites to Nokia, GC assignment via email"
    },
    2: {
        "name": "Pre-NTP Validation & Survey", 
        "milestones": ["MS_1313", "MS_1314", "MS_1315", "MS_1316", "MS_1321", "MS_1323"],
        "description": "Document validation and site survey (manual/drone)"
    },
    3: {
        "name": "Scoping, NTP & Material",
        "milestones": ["MS_1327", "MS_1331", "MS_1333", "MS_1406", "MS_1407", "MS_1408", "MS_1507"],
        "description": "Scoping package, NTP approval, BOM creation"
    },
    4: {
        "name": "Pre-Construction & Construction",
        "milestones": ["MS_1549", "MS_1550", "MS_1551", "MS_1553", "MS_1555"],
        "description": "Civil and tower construction execution"
    },
    5: {
        "name": "Quality & Compliance",
        "milestones": ["MS_1556"],
        "description": "NDPc sessions, HSE compliance, punch checklist"
    },
    6: {
        "name": "Integration",
        "milestones": ["MS_1564", "MS_1899", "MS_1970", "MS_1971", "MS_2123"],
        "description": "Site integration, alarm monitoring, E911 testing"
    },
    7: {
        "name": "Acceptance & Payment",
        "milestones": ["MS_1557", "MS_1558", "MS_1559"],
        "description": "Closeout package, customer acceptance, GR"
    }
}

# Key milestones mapping
MILESTONES = {
    "MS_1310": "Pre-NTP document received",
    "MS_1313": "Pre-NTP validated",
    "MS_1315": "Pre-NTP rejected",
    "MS_1314": "Manual survey assigned (CM)",
    "MS_1316": "Manual survey complete",
    "MS_1321": "Drone survey complete",
    "MS_1323": "Survey not required (urgent)",
    "MS_1327": "Scoping package validated",
    "MS_1331": "Scoping submitted to T-Mobile",
    "MS_1333": "Scoping approved",
    "MS_1406": "NTP received",
    "MS_1407": "NTP approved",
    "MS_1408": "NTP rejected",
    "MS_1507": "NTP approved (alternate)",
    "MS_1549": "Civil construction start",
    "MS_1550": "Tower construction start",
    "MS_1551": "Civil construction complete",
    "MS_1553": "Civil quality review",
    "MS_1555": "Tower construction complete",
    "MS_1556": "Punch checklist audit",
    "MS_1557": "Punch checklist to T-Mobile",
    "MS_1558": "Admin checklist submitted",
    "MS_1559": "COP approved",
    "MS_1564": "SCF validated",
    "MS_1899": "Technologies integrated",
    "MS_1970": "Integration complete (48hr monitoring)",
    "MS_1971": "AirVIEW complete",
    "MS_2123": "E911 complete"
}

# Prerequisite categories
PREREQUISITES = {
    "power": {
        "items": ["EB", "DG"],
        "description": "Electricity Board connection, Diesel Generator backup"
    },
    "backhaul": {
        "items": ["Fiber", "MW", "AAV"],
        "description": "Fiber readiness, Microwave links, Alternate backhaul"
    },
    "site_access": {
        "items": ["Landlord", "Authority", "Timing"],
        "description": "Building permissions, authority approvals, access windows"
    },
    "permits": {
        "items": ["NTP", "SPO", "FCC"],
        "description": "Notice to Proceed, Supplier PO, FCC filings"
    },
    "material": {
        "items": ["BOM", "Hardware"],
        "description": "Bill of Materials, hardware availability"
    },
    "technical": {
        "items": ["iNTP", "CIQ", "ICOP", "RIOT", "CR", "SCAF", "OTDR"],
        "description": "Integration readiness artifacts"
    }
}

# Standard calculation formulas (from business understanding doc)
CALCULATION_FORMULAS = {
    "resource_requirement": "Total Work Volume / (Individual Capacity × Available Time)",
    "capacity_gap": "Required Capacity – Available Capacity",
    "weekly_delivery": "Crews × Sites/Crew/Day × Working Days/Week",
    "delay_impact": "Original Date + Delay Days + Ripple Effect Days",
    "engineer_requirement": "Sessions/Shift ÷ Sessions/Engineer/Shift"
}

# Common root causes for RCA (Tier 1 curated)
COMMON_ROOT_CAUSES = {
    "crew_inexperience": {
        "problem_pattern": "FTR declining for specific vendor",
        "description": "New crews with less than 30 days experience",
        "weight": 0.4,
        "indicators": ["training_date", "crew_onboarding_date", "crew_tenure"],
        "recommendations": [
            "Schedule refresher training",
            "Pair with experienced mentors",
            "Mandatory retraining for crews with <90% FTR"
        ]
    },
    "material_batch_issue": {
        "problem_pattern": "Quality failures correlated with material batch",
        "description": "Quality issues with specific material batch",
        "weight": 0.3,
        "indicators": ["material_batch", "supplier", "batch_date"],
        "recommendations": [
            "Quarantine affected batch inventory",
            "Initiate supplier quality review",
            "Request replacement from alternate supplier"
        ]
    },
    "vendor_underperformance": {
        "problem_pattern": "Vendor delivery below plan",
        "description": "GC not meeting planned productivity",
        "weight": 0.3,
        "indicators": ["planned_vs_actual", "productivity_rate", "sla_breaches"],
        "recommendations": [
            "Shift volume to better performing vendors",
            "Apply penalty clauses",
            "Freeze new site awards for bottom quartile"
        ]
    },
    "site_access_delay": {
        "problem_pattern": "Execution blocked by access issues",
        "description": "Delays due to site access permissions",
        "weight": 0.25,
        "indicators": ["access_status", "landlord_response", "permission_expiry"],
        "recommendations": [
            "Improve stakeholder management",
            "Pre-survey verification",
            "Joint re-verification with landlord"
        ]
    },
    "prerequisite_delay": {
        "problem_pattern": "Sites blocked by missing prerequisites",
        "description": "Missing prerequisites blocking execution",
        "weight": 0.35,
        "indicators": ["prereq_status", "lead_time", "dependency_chain"],
        "recommendations": [
            "Fast-track critical prerequisites",
            "Launch readiness acceleration task force",
            "Parallel processing where possible"
        ]
    },
    "hse_non_compliance": {
        "problem_pattern": "H&S failures causing work stoppage",
        "description": "Safety compliance violations",
        "weight": 0.4,
        "indicators": ["check_in_status", "ppe_status", "jsa_status", "ptid_status"],
        "recommendations": [
            "Enforce compliance process adherence",
            "Issue notice against repeat violators",
            "Mandatory safety retraining"
        ]
    },
    "integration_backlog": {
        "problem_pattern": "Construction complete but On-Air delayed",
        "description": "Integration capacity limiting throughput",
        "weight": 0.3,
        "indicators": ["ix_start_date", "cmg_status", "engineer_availability"],
        "recommendations": [
            "Add integration shifts",
            "Expand CMG windows",
            "Align construction with integration capacity"
        ]
    }
}

# KPI Categories (from business understanding doc)
KPI_CATEGORIES = {
    "schedule_delivery": [
        "Plan Achievement %",
        "Productivity (Sites/Day, Sites/Week)",
        "Civil Delay",
        "RAN Delay", 
        "IX-to-OA Delay",
        "Milestone Slippage",
        "Survey Completion Rate"
    ],
    "quality_compliance": [
        "H&S Compliance Rate",
        "FTR %",
        "Rework Rate",
        "QC Pass Rate",
        "NCR Count",
        "VSWR Pass Rate",
        "Safety Compliance %"
    ],
    "material_readiness": [
        "Material Availability Rate",
        "Site Readiness Rate",
        "BOM Availability %",
        "On-Time Delivery %"
    ],
    "resource_capacity": [
        "Crew Utilization %",
        "Vacancy Rate",
        "Training Completion %",
        "Resource Utilization %"
    ],
    "vendor_performance": [
        "Vendor On-Time %",
        "SLA Breach %",
        "Avg Response Time",
        "Productivity",
        "Repeat NCR %"
    ],
    "cost_financial": [
        "Cost Variance (CV)",
        "EAC vs Baseline",
        "Forecast Accuracy %",
        "Rework Cost"
    ]
}
