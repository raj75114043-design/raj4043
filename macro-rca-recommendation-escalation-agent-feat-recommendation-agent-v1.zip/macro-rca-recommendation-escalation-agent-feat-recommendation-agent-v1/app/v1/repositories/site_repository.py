"""
Site Repository
================
File: app/v1/repositories/site_repository.py

Repository for Site entity operations.
"""

from typing import List, Optional, Dict, Any
from datetime import date
from sqlalchemy import select, func, and_, or_, case
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..db import Site, Vendor, SiteMilestone, SitePrerequisite
from .base_repository import BaseRepository


class SiteRepository(BaseRepository[Site]):
    """
    Repository for Site operations.
    
    Provides domain-specific queries for site management,
    status tracking, and analytics.
    """
    
    def __init__(self, session: AsyncSession):
        super().__init__(Site, session)
    
    async def get_by_site_code(self, site_code: str) -> Optional[Site]:
        """Get site by site code"""
        return await self.get_by_field("site_code", site_code)
    
    async def get_by_market(
        self,
        market: str,
        status: Optional[str] = None,
        skip: int = 0,
        limit: int = 100
    ) -> List[Site]:
        """Get sites by market with optional status filter"""
        query = select(Site).where(Site.market == market)
        
        if status:
            query = query.where(Site.project_status == status)
        
        query = query.offset(skip).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def get_by_vendor(
        self,
        vendor_id: int,
        status: Optional[str] = None
    ) -> List[Site]:
        """Get sites assigned to a vendor"""
        query = select(Site).where(Site.general_contractor_id == vendor_id)
        
        if status:
            query = query.where(Site.project_status == status)
        
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def get_sites_with_details(
        self,
        market: Optional[str] = None,
        vendor_id: Optional[int] = None,
        skip: int = 0,
        limit: int = 100
    ) -> List[Site]:
        """Get sites with related milestones and prerequisites loaded"""
        query = (
            select(Site)
            .options(
                selectinload(Site.milestones),
                selectinload(Site.prerequisites),
                selectinload(Site.general_contractor)
            )
        )
        
        if market:
            query = query.where(Site.market == market)
        if vendor_id:
            query = query.where(Site.general_contractor_id == vendor_id)
        
        query = query.offset(skip).limit(limit)
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def get_status_summary_by_market(
        self,
        market: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Get site status summary grouped by market"""
        query = (
            select(
                Site.market,
                func.count(Site.id).label("total_sites"),
                func.count(case((Site.project_status == "Completed", 1))).label("completed"),
                func.count(case((Site.project_status == "In Progress", 1))).label("wip"),
                func.count(case((Site.project_status == "Pending", 1))).label("pending")
            )
            .group_by(Site.market)
        )
        
        if market:
            query = query.where(Site.market == market)
        
        result = await self.session.execute(query)
        return [
            {
                "market": row.market,
                "total_sites": row.total_sites,
                "completed": row.completed,
                "wip": row.wip,
                "pending": row.pending
            }
            for row in result
        ]
    
    async def get_blocked_sites(
        self,
        market: Optional[str] = None
    ) -> List[Site]:
        """Get sites blocked by missing prerequisites"""
        query = (
            select(Site)
            .where(
                or_(
                    Site.ntp_status != "Approved",
                    Site.power_status != "Ready",
                    Site.fiber_status != "Ready",
                    Site.material_status != "Ready"
                )
            )
            .where(Site.project_status != "Completed")
        )
        
        if market:
            query = query.where(Site.market == market)
        
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def get_readiness_rate(
        self,
        market: Optional[str] = None
    ) -> Dict[str, Any]:
        """Calculate site readiness rate"""
        # Count total non-completed sites
        total_query = (
            select(func.count(Site.id))
            .where(Site.project_status != "Completed")
        )
        
        # Count ready sites (all prerequisites complete)
        ready_query = (
            select(func.count(Site.id))
            .where(Site.project_status != "Completed")
            .where(Site.ntp_status == "Approved")
            .where(Site.power_status == "Ready")
            .where(Site.material_status == "Ready")
        )
        
        if market:
            total_query = total_query.where(Site.market == market)
            ready_query = ready_query.where(Site.market == market)
        
        total_result = await self.session.execute(total_query)
        ready_result = await self.session.execute(ready_query)
        
        total = total_result.scalar_one()
        ready = ready_result.scalar_one()
        
        return {
            "total_sites": total,
            "ready_sites": ready,
            "readiness_rate": (ready / total * 100) if total > 0 else 0
        }
    
    async def get_ftr_by_vendor(
        self,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
        market: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Get FTR rate grouped by vendor"""
        query = (
            select(
                Vendor.vendor_code.label("vendor"),
                Vendor.vendor_name,
                func.count(Site.id).label("total_sites"),
                func.count(case((Site.ftr_status == True, 1))).label("ftr_pass"),
                (func.count(case((Site.ftr_status == True, 1))) * 100.0 / 
                 func.count(Site.id)).label("ftr_rate")
            )
            .join(Vendor, Site.general_contractor_id == Vendor.id)
            .group_by(Vendor.vendor_code, Vendor.vendor_name)
        )
        
        if start_date:
            query = query.where(Site.civil_complete_date >= start_date)
        if end_date:
            query = query.where(Site.civil_complete_date <= end_date)
        if market:
            query = query.where(Site.market == market)
        
        query = query.order_by(func.count(case((Site.ftr_status == True, 1))) * 100.0 / func.count(Site.id))
        
        result = await self.session.execute(query)
        return [
            {
                "vendor": row.vendor,
                "vendor_name": row.vendor_name,
                "total_sites": row.total_sites,
                "ftr_pass": row.ftr_pass,
                "ftr_rate": float(row.ftr_rate) if row.ftr_rate else 0
            }
            for row in result
        ]
    
    async def get_sla_breaches(
        self,
        sla_type: str = "civil",  # "civil" or "ran"
        sla_days: int = 21,
        start_date: Optional[date] = None,
        market: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Get sites with SLA breaches"""
        if sla_type == "civil":
            start_col = Site.civil_start_date
            complete_col = Site.civil_complete_date
        else:
            start_col = Site.ran_start_date
            complete_col = Site.ran_complete_date
            sla_days = 14  # RAN SLA is 14 days
        
        query = (
            select(
                Site.site_code,
                Site.market,
                Site.region,
                Vendor.vendor_code.label("vendor"),
                start_col.label("start_date"),
                complete_col.label("complete_date"),
                (func.extract('day', complete_col - start_col)).label("duration_days")
            )
            .join(Vendor, Site.general_contractor_id == Vendor.id)
            .where(complete_col.isnot(None))
            .where(func.extract('day', complete_col - start_col) > sla_days)
        )
        
        if start_date:
            query = query.where(start_col >= start_date)
        if market:
            query = query.where(Site.market == market)
        
        query = query.order_by((func.extract('day', complete_col - start_col)).desc())
        
        result = await self.session.execute(query)
        return [
            {
                "site_code": row.site_code,
                "market": row.market,
                "region": row.region,
                "vendor": row.vendor,
                "start_date": row.start_date,
                "complete_date": row.complete_date,
                "duration_days": int(row.duration_days) if row.duration_days else 0
            }
            for row in result
        ]