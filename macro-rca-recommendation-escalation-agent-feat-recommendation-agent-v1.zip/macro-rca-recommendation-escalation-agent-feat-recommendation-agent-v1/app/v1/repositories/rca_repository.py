"""
RCA Repository
===============
File: app/v1/repositories/rca_repository.py

Repository for RCA Plans, Historical Cases, and Insights.
Includes vector similarity search using pgvector.
"""

from typing import List, Optional, Dict, Any
from datetime import datetime
from sqlalchemy import select, func, and_, update
from sqlalchemy.ext.asyncio import AsyncSession
from pgvector.sqlalchemy import Vector

from ..db import RCAPlan, HistoricalCase, Insight
from .base_repository import BaseRepository


class RCAPlanRepository(BaseRepository[RCAPlan]):
    """
    Repository for Tier 1 curated RCA Plans.
    
    Supports vector similarity search for pattern matching.
    """
    
    def __init__(self, session: AsyncSession):
        super().__init__(RCAPlan, session)
    
    async def get_by_plan_id(self, plan_id: str) -> Optional[RCAPlan]:
        """Get plan by plan ID"""
        return await self.get_by_field("plan_id", plan_id)
    
    async def get_by_category(self, category: str) -> List[RCAPlan]:
        """Get plans by category"""
        query = (
            select(RCAPlan)
            .where(RCAPlan.category == category)
            .where(RCAPlan.is_active == True)
        )
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def get_active_plans(self) -> List[RCAPlan]:
        """Get all active plans"""
        return await self.get_many_by_field("is_active", True)
    
    async def search_by_similarity(
        self,
        embedding: List[float],
        threshold: float = 0.92,
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Search plans by vector similarity.
        
        Args:
            embedding: Query embedding vector
            threshold: Minimum similarity score (0-1)
            top_k: Maximum results to return
            
        Returns:
            List of matching plans with similarity scores
        """
        # Use pgvector cosine distance (<=>)
        query = (
            select(
                RCAPlan,
                (1 - RCAPlan.embedding.cosine_distance(embedding)).label("similarity")
            )
            .where(RCAPlan.is_active == True)
            .where(RCAPlan.embedding.isnot(None))
            .order_by(RCAPlan.embedding.cosine_distance(embedding))
            .limit(top_k)
        )
        
        result = await self.session.execute(query)
        matches = []
        
        for row in result:
            plan = row[0]
            similarity = row[1]
            
            if similarity >= threshold:
                matches.append({
                    "plan_id": plan.plan_id,
                    "problem_pattern": plan.problem_pattern,
                    "category": plan.category,
                    "root_causes": plan.root_causes,
                    "recommendations": plan.recommendations,
                    "score": float(similarity)
                })
        
        return matches
    
    async def increment_usage(self, plan_id: str) -> None:
        """Increment usage count for a plan"""
        await self.session.execute(
            update(RCAPlan)
            .where(RCAPlan.plan_id == plan_id)
            .values(times_used=RCAPlan.times_used + 1)
        )
    
    async def update_success_rate(
        self,
        plan_id: str,
        success: bool
    ) -> None:
        """Update success rate based on feedback"""
        plan = await self.get_by_plan_id(plan_id)
        if plan:
            # Calculate new success rate
            total = plan.times_used or 1
            current_successes = (plan.success_rate or 0.5) * total
            new_successes = current_successes + (1 if success else 0)
            new_rate = new_successes / (total + 1)
            
            await self.update(plan.id, {"success_rate": new_rate})


class HistoricalCaseRepository(BaseRepository[HistoricalCase]):
    """
    Repository for Tier 2 historical RCA cases.
    
    Supports vector similarity search and case promotion.
    """
    
    def __init__(self, session: AsyncSession):
        super().__init__(HistoricalCase, session)
    
    async def get_by_case_id(self, case_id: str) -> Optional[HistoricalCase]:
        """Get case by case ID"""
        return await self.get_by_field("case_id", case_id)
    
    async def search_by_similarity(
        self,
        embedding: List[float],
        threshold: float = 0.75,
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Search historical cases by vector similarity.
        
        Args:
            embedding: Query embedding vector (from problem signature)
            threshold: Minimum similarity score
            top_k: Maximum results to return
            
        Returns:
            List of similar cases with scores
        """
        query = (
            select(
                HistoricalCase,
                (1 - HistoricalCase.embedding.cosine_distance(embedding)).label("similarity")
            )
            .where(HistoricalCase.embedding.isnot(None))
            .order_by(HistoricalCase.embedding.cosine_distance(embedding))
            .limit(top_k)
        )
        
        result = await self.session.execute(query)
        matches = []
        
        for row in result:
            case = row[0]
            similarity = row[1]
            
            if similarity >= threshold:
                matches.append({
                    "case_id": case.case_id,
                    "problem_signature": case.problem_signature,
                    "symptom": case.symptom,
                    "investigation_summary": case.investigation_summary,
                    "root_cause_identified": case.root_cause_identified,
                    "resolution": case.resolution,
                    "outcome": case.outcome,
                    "similarity_score": float(similarity)
                })
        
        return matches
    
    async def add_case(
        self,
        case_id: str,
        problem_signature: Dict[str, Any],
        symptom: str,
        investigation_summary: str,
        root_cause: str,
        resolution: str,
        outcome: str,
        embedding: Optional[List[float]] = None
    ) -> HistoricalCase:
        """Add a new historical case"""
        return await self.create({
            "case_id": case_id,
            "problem_signature": problem_signature,
            "symptom": symptom,
            "investigation_summary": investigation_summary,
            "root_cause_identified": root_cause,
            "resolution": resolution,
            "outcome": outcome,
            "embedding": embedding,
            "tier": 2
        })
    
    async def promote_to_tier1(self, case_id: str) -> bool:
        """Promote a case to Tier 1 (mark for curation)"""
        case = await self.get_by_case_id(case_id)
        if case:
            await self.update(case.id, {
                "tier": 1,
                "promoted_from_tier": 2,
                "promotion_date": datetime.utcnow()
            })
            return True
        return False
    
    async def record_feedback(
        self,
        case_id: str,
        positive: bool
    ) -> None:
        """Record feedback for a case"""
        case = await self.get_by_case_id(case_id)
        if case:
            if positive:
                await self.update(case.id, {
                    "feedback_positive": (case.feedback_positive or 0) + 1
                })
            else:
                await self.update(case.id, {
                    "feedback_negative": (case.feedback_negative or 0) + 1
                })
    
    async def get_promotion_candidates(self, min_positive_feedback: int = 3) -> List[HistoricalCase]:
        """Get cases ready for promotion to Tier 1"""
        query = (
            select(HistoricalCase)
            .where(HistoricalCase.tier == 2)
            .where(HistoricalCase.feedback_positive >= min_positive_feedback)
            .where(HistoricalCase.outcome == "Success")
        )
        result = await self.session.execute(query)
        return list(result.scalars().all())


class InsightRepository(BaseRepository[Insight]):
    """
    Repository for generated insights.
    
    Tracks insights, feedback, and actions taken.
    """
    
    def __init__(self, session: AsyncSession):
        super().__init__(Insight, session)
    
    async def get_by_insight_id(self, insight_id: str) -> Optional[Insight]:
        """Get insight by insight ID"""
        return await self.get_by_field("insight_id", insight_id)
    
    async def get_recent_insights(
        self,
        limit: int = 20,
        category: Optional[str] = None,
        priority: Optional[str] = None
    ) -> List[Insight]:
        """Get recent insights with optional filters"""
        query = (
            select(Insight)
            .where(Insight.status == "active")
            .order_by(Insight.created_at.desc())
            .limit(limit)
        )
        
        if category:
            query = query.where(Insight.category == category)
        if priority:
            query = query.where(Insight.priority == priority)
        
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def record_feedback(
        self,
        insight_id: str,
        feedback_type: str,  # "positive", "negative", "correction"
        user_id: str,
        correction: Optional[str] = None
    ) -> bool:
        """Record feedback on an insight"""
        insight = await self.get_by_insight_id(insight_id)
        if insight:
            await self.update(insight.id, {
                "feedback_status": feedback_type,
                "feedback_user": user_id,
                "feedback_timestamp": datetime.utcnow(),
                "feedback_correction": correction
            })
            return True
        return False
    
    async def mark_acted_upon(self, insight_id: str) -> bool:
        """Mark insight as acted upon"""
        insight = await self.get_by_insight_id(insight_id)
        if insight:
            await self.update(insight.id, {"status": "acted_upon"})
            return True
        return False
    
    async def get_feedback_stats(
        self,
        days: int = 30
    ) -> Dict[str, Any]:
        """Get feedback statistics"""
        from datetime import timedelta
        
        since_date = datetime.utcnow() - timedelta(days=days)
        
        query = (
            select(
                func.count(Insight.id).label("total"),
                func.count(case((Insight.feedback_status == "positive", 1))).label("positive"),
                func.count(case((Insight.feedback_status == "negative", 1))).label("negative"),
                func.count(case((Insight.status == "acted_upon", 1))).label("acted_upon")
            )
            .where(Insight.created_at >= since_date)
        )
        
        result = await self.session.execute(query)
        row = result.one()
        
        return {
            "total_insights": row.total,
            "positive_feedback": row.positive,
            "negative_feedback": row.negative,
            "acted_upon": row.acted_upon,
            "positive_rate": (row.positive / row.total * 100) if row.total > 0 else 0
        }