"""
Vendor Repository
==================
File: app/v1/repositories/vendor_repository.py

Repository for Vendor entity operations.
"""

from typing import List, Optional, Dict, Any
from datetime import date
from sqlalchemy import select, func, and_, case
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from ..db import Vendor, Site, Crew, HSERecord
from .base_repository import BaseRepository


class VendorRepository(BaseRepository[Vendor]):
    """
    Repository for Vendor operations.
    
    Provides domain-specific queries for vendor management
    and performance tracking.
    """
    
    def __init__(self, session: AsyncSession):
        super().__init__(Vendor, session)
    
    async def get_by_vendor_code(self, vendor_code: str) -> Optional[Vendor]:
        """Get vendor by vendor code"""
        return await self.get_by_field("vendor_code", vendor_code)
    
    async def get_active_vendors(self, market: Optional[str] = None) -> List[Vendor]:
        """Get all active vendors, optionally filtered by market"""
        query = select(Vendor).where(Vendor.is_active == True)
        
        if market:
            query = query.where(Vendor.markets.contains([market]))
        
        result = await self.session.execute(query)
        return list(result.scalars().all())
    
    async def get_vendors_by_tier(self, tier: int) -> List[Vendor]:
        """Get vendors by tier level"""
        return await self.get_many_by_field("tier", tier)
    
    async def get_vendor_with_crews(self, vendor_id: int) -> Optional[Vendor]:
        """Get vendor with crews loaded"""
        query = (
            select(Vendor)
            .options(selectinload(Vendor.crews))
            .where(Vendor.id == vendor_id)
        )
        result = await self.session.execute(query)
        return result.scalar_one_or_none()
    
    async def get_vendor_performance(
        self,
        vendor_id: Optional[int] = None,
        market: Optional[str] = None,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None
    ) -> List[Dict[str, Any]]:
        """Get vendor performance metrics"""
        query = (
            select(
                Vendor.id,
                Vendor.vendor_code,
                Vendor.vendor_name,
                func.count(Site.id).label("total_sites"),
                func.count(case((Site.project_status == "Completed", 1))).label("completed"),
                func.count(case((Site.ftr_status == True, 1))).label("ftr_pass"),
                (func.count(case((Site.ftr_status == True, 1))) * 100.0 / 
                 func.nullif(func.count(Site.id), 0)).label("ftr_rate"),
                func.avg(
                    func.extract('day', Site.civil_complete_date - Site.civil_start_date)
                ).label("avg_cycle_time")
            )
            .join(Site, Site.general_contractor_id == Vendor.id)
            .where(Vendor.is_active == True)
            .group_by(Vendor.id, Vendor.vendor_code, Vendor.vendor_name)
        )
        
        if vendor_id:
            query = query.where(Vendor.id == vendor_id)
        if market:
            query = query.where(Site.market == market)
        if start_date:
            query = query.where(Site.civil_complete_date >= start_date)
        if end_date:
            query = query.where(Site.civil_complete_date <= end_date)
        
        query = query.order_by(
            (func.count(case((Site.ftr_status == True, 1))) * 100.0 / 
             func.nullif(func.count(Site.id), 0)).asc()
        )
        
        result = await self.session.execute(query)
        return [
            {
                "vendor_id": row.id,
                "vendor_code": row.vendor_code,
                "vendor_name": row.vendor_name,
                "total_sites": row.total_sites,
                "completed": row.completed,
                "ftr_pass": row.ftr_pass,
                "ftr_rate": float(row.ftr_rate) if row.ftr_rate else 0,
                "avg_cycle_time": float(row.avg_cycle_time) if row.avg_cycle_time else 0
            }
            for row in result
        ]
    
    async def get_vendor_productivity(
        self,
        vendor_id: Optional[int] = None,
        start_date: Optional[date] = None
    ) -> List[Dict[str, Any]]:
        """Get vendor productivity (sites per week)"""
        query = (
            select(
                Vendor.vendor_code,
                func.date_trunc('week', Site.civil_complete_date).label("week"),
                func.count(Site.id).label("sites_completed")
            )
            .join(Site, Site.general_contractor_id == Vendor.id)
            .where(Site.civil_complete_date.isnot(None))
            .group_by(Vendor.vendor_code, func.date_trunc('week', Site.civil_complete_date))
            .order_by(func.date_trunc('week', Site.civil_complete_date).desc())
        )
        
        if vendor_id:
            query = query.where(Vendor.id == vendor_id)
        if start_date:
            query = query.where(Site.civil_complete_date >= start_date)
        
        result = await self.session.execute(query)
        return [
            {
                "vendor": row.vendor_code,
                "week": row.week,
                "sites_completed": row.sites_completed
            }
            for row in result
        ]
    
    async def get_vendor_hse_compliance(
        self,
        market: Optional[str] = None,
        start_date: Optional[date] = None
    ) -> List[Dict[str, Any]]:
        """Get HSE compliance by vendor"""
        query = (
            select(
                Vendor.vendor_code,
                Vendor.vendor_name,
                func.count(HSERecord.id).label("total_inspections"),
                func.count(case((HSERecord.check_in_status == "Pass", 1))).label("check_in_pass"),
                func.count(case((HSERecord.ppe_status == "Pass", 1))).label("ppe_pass"),
                func.count(case((HSERecord.jsa_status == "Pass", 1))).label("jsa_pass"),
                func.count(case((HSERecord.ptid_status == "Pass", 1))).label("ptid_pass"),
                (
                    (func.count(case((HSERecord.check_in_status == "Pass", 1))) +
                     func.count(case((HSERecord.ppe_status == "Pass", 1))) +
                     func.count(case((HSERecord.jsa_status == "Pass", 1))) +
                     func.count(case((HSERecord.ptid_status == "Pass", 1)))) * 100.0 /
                    func.nullif(func.count(HSERecord.id) * 4, 0)
                ).label("compliance_rate")
            )
            .join(HSERecord, HSERecord.vendor_id == Vendor.id)
            .group_by(Vendor.vendor_code, Vendor.vendor_name)
        )
        
        if start_date:
            query = query.where(HSERecord.inspection_date >= start_date)
        
        query = query.order_by(
            (
                (func.count(case((HSERecord.check_in_status == "Pass", 1))) +
                 func.count(case((HSERecord.ppe_status == "Pass", 1))) +
                 func.count(case((HSERecord.jsa_status == "Pass", 1))) +
                 func.count(case((HSERecord.ptid_status == "Pass", 1)))) * 100.0 /
                func.nullif(func.count(HSERecord.id) * 4, 0)
            ).asc()
        )
        
        result = await self.session.execute(query)
        return [
            {
                "vendor": row.vendor_code,
                "vendor_name": row.vendor_name,
                "total_inspections": row.total_inspections,
                "check_in_pass": row.check_in_pass,
                "ppe_pass": row.ppe_pass,
                "jsa_pass": row.jsa_pass,
                "ptid_pass": row.ptid_pass,
                "compliance_rate": float(row.compliance_rate) if row.compliance_rate else 0
            }
            for row in result
        ]
    
    async def get_bottom_performers(
        self,
        n: int = 5,
        metric: str = "ftr_rate"
    ) -> List[Dict[str, Any]]:
        """Get bottom N vendors by specified metric"""
        performance = await self.get_vendor_performance()
        
        # Sort by metric
        sorted_vendors = sorted(performance, key=lambda x: x.get(metric, 0))
        
        return sorted_vendors[:n]
    
    async def update_cached_metrics(self, vendor_id: int) -> Optional[Vendor]:
        """Update cached performance metrics for a vendor"""
        performance = await self.get_vendor_performance(vendor_id=vendor_id)
        
        if performance:
            perf = performance[0]
            return await self.update(vendor_id, {
                "ftr_rate": perf["ftr_rate"],
                "on_time_rate": 100 - (perf["avg_cycle_time"] > 21) * 100 if perf["avg_cycle_time"] else None
            })
        
        return None