"""
Vector Store Tool for Foundation Layer
=======================================
File: app/v1/foundation_layer/shared_tools/vector_store.py

Provides semantic search capabilities across:
- Enriched DB Metadata (column embeddings)
- Historical RCA Cases (Tier 2)
- Question Bank (Q&A pairs)

Used by: AI Assistant, RCA Agent (Tier 1-2), Planner Agent
"""

import httpx
from typing import Dict, Any, List, Optional
from datetime import datetime
import logging

from ...config import settings
from ...models import ToolCallResponse, HistoricalCase, RCAPlan

logger = logging.getLogger(__name__)


class VectorStore:
    """
    Vector Store for semantic search operations.
    Interfaces with the Unified Layer's vector search capabilities.
    """
    
    def __init__(self, base_url: Optional[str] = None):
        self.base_url = base_url or settings.unified_layer.base_url
        self.timeout = settings.unified_layer.timeout
        self.top_k = settings.vector_store.top_k
        self.similarity_threshold = settings.vector_store.similarity_threshold
    
    async def search_rca_plans(
        self,
        problem_description: str,
        top_k: Optional[int] = None,
        threshold: Optional[float] = None
    ) -> ToolCallResponse:
        """
        Search Tier 1 curated RCA plans by problem description.
        
        Args:
            problem_description: Description of the problem/symptom
            top_k: Number of results to return
            threshold: Similarity threshold (default: 0.92 for Tier 1)
            
        Returns:
            ToolCallResponse with matching RCA plans
        """
        start_time = datetime.now()
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/vector/search/rca_plans",
                    json={
                        "query": problem_description,
                        "top_k": top_k or self.top_k,
                        "threshold": threshold or settings.rca.tier1_similarity_threshold
                    }
                )
                response.raise_for_status()
                result = response.json()
                
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="vector_store",
                result=result.get("matches", []),
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"search_rca_plans error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="vector_store",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
    
    async def search_historical_cases(
        self,
        problem_signature: Dict[str, Any],
        top_k: Optional[int] = None,
        threshold: Optional[float] = None
    ) -> ToolCallResponse:
        """
        Search Tier 2 historical cases by problem signature.
        
        Args:
            problem_signature: Problem characteristics (metrics, vendor, pattern)
            top_k: Number of results to return
            threshold: Similarity threshold (default: 0.75 for Tier 2)
            
        Returns:
            ToolCallResponse with similar historical cases
        """
        start_time = datetime.now()
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/vector/search/historical_cases",
                    json={
                        "problem_signature": problem_signature,
                        "top_k": top_k or self.top_k,
                        "threshold": threshold or settings.rca.tier2_similarity_threshold
                    }
                )
                response.raise_for_status()
                result = response.json()
                
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            # Parse results into HistoricalCase objects
            cases = []
            for match in result.get("matches", []):
                cases.append({
                    "case_id": match.get("case_id"),
                    "problem_signature": match.get("problem_signature"),
                    "investigation_summary": match.get("investigation_summary"),
                    "root_cause_identified": match.get("root_cause_identified"),
                    "resolution": match.get("resolution"),
                    "outcome": match.get("outcome"),
                    "similarity_score": match.get("score", 0)
                })
            
            return ToolCallResponse(
                success=True,
                tool_name="vector_store",
                result=cases,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"search_historical_cases error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="vector_store",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
    
    async def search_question_bank(
        self,
        question: str,
        top_k: Optional[int] = None
    ) -> ToolCallResponse:
        """
        Search Question Bank for similar Q&A pairs.
        
        Args:
            question: User's question
            top_k: Number of results to return
            
        Returns:
            ToolCallResponse with matching Q&A pairs
        """
        start_time = datetime.now()
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/vector/search/questions",
                    json={
                        "query": question,
                        "top_k": top_k or self.top_k
                    }
                )
                response.raise_for_status()
                result = response.json()
                
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="vector_store",
                result=result.get("matches", []),
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"search_question_bank error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="vector_store",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
    
    async def search_metadata(
        self,
        query: str,
        search_type: str = "columns",  # "columns" or "tables"
        top_k: Optional[int] = None
    ) -> ToolCallResponse:
        """
        Search enriched metadata for relevant tables/columns.
        
        Args:
            query: Search query (natural language)
            search_type: "columns" or "tables"
            top_k: Number of results to return
            
        Returns:
            ToolCallResponse with matching metadata
        """
        start_time = datetime.now()
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/vector/search/metadata",
                    json={
                        "query": query,
                        "search_type": search_type,
                        "top_k": top_k or self.top_k
                    }
                )
                response.raise_for_status()
                result = response.json()
                
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="vector_store",
                result=result.get("matches", []),
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"search_metadata error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="vector_store",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
    
    async def add_historical_case(
        self,
        case: HistoricalCase
    ) -> ToolCallResponse:
        """
        Add a new historical case to the vector store (Learning Loop).
        
        Args:
            case: Historical case to add
            
        Returns:
            ToolCallResponse with addition status
        """
        start_time = datetime.now()
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/vector/add/historical_case",
                    json=case.model_dump()
                )
                response.raise_for_status()
                result = response.json()
                
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="vector_store",
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"add_historical_case error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="vector_store",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )


# Singleton instance
vector_store = VectorStore()
