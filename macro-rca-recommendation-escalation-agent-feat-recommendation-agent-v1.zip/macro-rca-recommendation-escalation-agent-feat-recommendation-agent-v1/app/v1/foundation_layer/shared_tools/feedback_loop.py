"""
Feedback Loop Tool for Foundation Layer
=========================================
File: app/v1/foundation_layer/shared_tools/feedback_loop.py

Provides continuous improvement capabilities:
- Track PM feedback (thumbs up/down)
- Pattern promotion (Tier 3 → Tier 2 → Tier 1)
- Success rate tracking
- Historical impact baselines

Used by: All agents, Learning Loop process
"""

import httpx
from typing import Dict, Any, List, Optional
from datetime import datetime
from enum import Enum
import logging

from ...config import settings
from ...models import ToolCallResponse

logger = logging.getLogger(__name__)


class FeedbackType(str, Enum):
    """Types of PM feedback"""
    POSITIVE = "positive"       # 👍 - Action taken, helpful
    NEGATIVE = "negative"       # 👎 - Unhelpful
    CORRECTION = "correction"   # PM provides correct answer


class FeedbackLoop:
    """
    Feedback Loop for continuous improvement.
    
    Learning Loop Actions:
    - PM 👍 on Tier 3 insight → Extract pattern → Add to Historical Cases (Tier 2)
    - Pattern fires 3+ times → Consider promotion to Tier 1
    - PM 👎 on insight → Log for review, adjust thresholds
    - New KPI added → Auto-generate monitors
    """
    
    def __init__(self, base_url: Optional[str] = None):
        self.base_url = base_url or settings.unified_layer.base_url
        self.timeout = settings.unified_layer.timeout
    
    async def record_feedback(
        self,
        insight_id: str,
        feedback_type: FeedbackType,
        user_id: str,
        correction: Optional[str] = None,
        additional_context: Optional[Dict[str, Any]] = None
    ) -> ToolCallResponse:
        """
        Record PM feedback on an insight/recommendation.
        
        Args:
            insight_id: ID of the insight receiving feedback
            feedback_type: Type of feedback (positive/negative/correction)
            user_id: ID of the user providing feedback
            correction: If correction, the correct answer
            additional_context: Any additional context
            
        Returns:
            ToolCallResponse with recording status
        """
        start_time = datetime.now()
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/feedback/record",
                    json={
                        "insight_id": insight_id,
                        "feedback_type": feedback_type.value,
                        "user_id": user_id,
                        "correction": correction,
                        "additional_context": additional_context or {},
                        "timestamp": datetime.now().isoformat()
                    }
                )
                response.raise_for_status()
                result = response.json()
                
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            # Trigger pattern promotion if positive feedback
            if feedback_type == FeedbackType.POSITIVE:
                await self._check_pattern_promotion(insight_id)
            
            return ToolCallResponse(
                success=True,
                tool_name="feedback_loop",
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"record_feedback error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="feedback_loop",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
    
    async def get_success_rate(
        self,
        pattern_id: Optional[str] = None,
        agent_type: Optional[str] = None,
        time_range_days: int = 30
    ) -> ToolCallResponse:
        """
        Get success rate for patterns or agent types.
        
        Args:
            pattern_id: Specific pattern to check
            agent_type: Specific agent type to check
            time_range_days: Number of days to look back
            
        Returns:
            ToolCallResponse with success rate metrics
        """
        start_time = datetime.now()
        
        try:
            params = {"time_range_days": time_range_days}
            if pattern_id:
                params["pattern_id"] = pattern_id
            if agent_type:
                params["agent_type"] = agent_type
                
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(
                    f"{self.base_url}/feedback/success_rate",
                    params=params
                )
                response.raise_for_status()
                result = response.json()
                
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="feedback_loop",
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"get_success_rate error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="feedback_loop",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
    
    async def get_historical_impact(
        self,
        action_type: str,
        time_range_days: int = 90
    ) -> ToolCallResponse:
        """
        Lookup past impact of similar recommendations.
        
        Args:
            action_type: Type of action (e.g., "crew_retraining", "vendor_shift")
            time_range_days: Number of days to look back
            
        Returns:
            ToolCallResponse with historical impact data
        """
        start_time = datetime.now()
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(
                    f"{self.base_url}/feedback/historical_impact",
                    params={
                        "action_type": action_type,
                        "time_range_days": time_range_days
                    }
                )
                response.raise_for_status()
                result = response.json()
                
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="feedback_loop",
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"get_historical_impact error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="feedback_loop",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
    
    async def _check_pattern_promotion(self, insight_id: str) -> None:
        """
        Check if a pattern should be promoted (Tier 3 → Tier 2 → Tier 1).
        
        Promotion rules:
        - Tier 3 → Tier 2: Validated by PM (👍 + action taken)
        - Tier 2 → Tier 1: Pattern fires 3+ times successfully
        """
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                # Get insight details
                response = await client.get(
                    f"{self.base_url}/insights/{insight_id}"
                )
                if response.status_code != 200:
                    return
                    
                insight = response.json()
                current_tier = insight.get("tier", 3)
                pattern_id = insight.get("source", {}).get("pattern_id")
                
                # Check promotion eligibility
                if current_tier == 3:
                    # Promote to Tier 2 (add to historical cases)
                    await client.post(
                        f"{self.base_url}/feedback/promote",
                        json={
                            "insight_id": insight_id,
                            "from_tier": 3,
                            "to_tier": 2,
                            "reason": "PM validated (positive feedback)"
                        }
                    )
                    logger.info(f"Promoted insight {insight_id} from Tier 3 to Tier 2")
                    
                elif current_tier == 2 and pattern_id:
                    # Check if pattern has fired 3+ times
                    count_response = await client.get(
                        f"{self.base_url}/feedback/pattern_count",
                        params={"pattern_id": pattern_id}
                    )
                    if count_response.status_code == 200:
                        count = count_response.json().get("count", 0)
                        if count >= 3:
                            await client.post(
                                f"{self.base_url}/feedback/promote",
                                json={
                                    "insight_id": insight_id,
                                    "from_tier": 2,
                                    "to_tier": 1,
                                    "reason": f"Pattern fired {count} times successfully"
                                }
                            )
                            logger.info(f"Promoted pattern {pattern_id} from Tier 2 to Tier 1")
                            
        except Exception as e:
            logger.error(f"Pattern promotion check failed: {e}")
    
    async def log_investigation_trace(
        self,
        insight_id: str,
        trace: List[Dict[str, Any]]
    ) -> ToolCallResponse:
        """
        Log the full investigation trace for a Tier 3 exploration.
        
        Args:
            insight_id: ID of the insight
            trace: Full exploration trace (tool calls, hypotheses, results)
            
        Returns:
            ToolCallResponse with logging status
        """
        start_time = datetime.now()
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/feedback/trace",
                    json={
                        "insight_id": insight_id,
                        "trace": trace,
                        "timestamp": datetime.now().isoformat()
                    }
                )
                response.raise_for_status()
                result = response.json()
                
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="feedback_loop",
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"log_investigation_trace error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="feedback_loop",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )


# Singleton instance
feedback_loop = FeedbackLoop()
