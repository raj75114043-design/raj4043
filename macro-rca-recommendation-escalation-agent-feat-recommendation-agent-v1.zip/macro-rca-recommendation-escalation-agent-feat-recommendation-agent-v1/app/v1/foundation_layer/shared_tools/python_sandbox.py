"""
Python Sandbox Tool for Foundation Layer
==========================================
File: app/v1/foundation_layer/shared_tools/python_sandbox.py

Provides statistical analysis capabilities for agents.
Used by: Analyst Agent, Recommender Agent, RCA Agent (Tier 3)

Key capabilities:
- Statistical tests (t-test, chi-square)
- Correlation analysis
- Trend detection
- Outlier detection
- Impact estimation
- Monte Carlo simulation
"""

import numpy as np
from scipy import stats
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import logging

from ...config import settings
from ...models import ToolCallResponse

logger = logging.getLogger(__name__)


class PythonSandbox:
    """
    Python Sandbox for statistical analysis and calculations.
    All mathematical computations happen here - LLM never does math.
    
    Design Principle: Separate exploration from computation.
    LLM hypothesizes (what patterns to look for) → Tools compute (how).
    """
    
    def __init__(self):
        self.p_value_threshold = settings.rca.p_value_threshold
        self.min_sample_size = settings.rca.min_sample_size
    
    async def compare_groups(
        self,
        group_a_values: List[float],
        group_b_values: List[float],
        group_a_label: str = "Group A",
        group_b_label: str = "Group B",
        metric_name: str = "metric"
    ) -> ToolCallResponse:
        """
        Statistical comparison between two groups (t-test).
        
        Args:
            group_a_values: Values for group A
            group_b_values: Values for group B
            group_a_label: Label for group A
            group_b_label: Label for group B
            metric_name: Name of the metric being compared
            
        Returns:
            ToolCallResponse with comparison results
        """
        start_time = datetime.now()
        
        try:
            # Validate sample sizes
            n_a = len(group_a_values)
            n_b = len(group_b_values)
            
            if n_a < self.min_sample_size or n_b < self.min_sample_size:
                return ToolCallResponse(
                    success=False,
                    tool_name="python_sandbox",
                    result=None,
                    error=f"Insufficient sample size. Need at least {self.min_sample_size} samples per group. Got: {n_a}, {n_b}",
                    execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
                )
            
            # Calculate statistics
            mean_a = np.mean(group_a_values)
            mean_b = np.mean(group_b_values)
            std_a = np.std(group_a_values, ddof=1)
            std_b = np.std(group_b_values, ddof=1)
            
            # Perform t-test
            t_stat, p_value = stats.ttest_ind(group_a_values, group_b_values)
            
            # Calculate effect size (Cohen's d)
            pooled_std = np.sqrt(((n_a - 1) * std_a**2 + (n_b - 1) * std_b**2) / (n_a + n_b - 2))
            cohens_d = (mean_a - mean_b) / pooled_std if pooled_std > 0 else 0
            
            is_significant = p_value < self.p_value_threshold
            
            result = {
                group_a_label: {
                    "mean": round(mean_a, 2),
                    "std": round(std_a, 2),
                    "n": n_a
                },
                group_b_label: {
                    "mean": round(mean_b, 2),
                    "std": round(std_b, 2),
                    "n": n_b
                },
                "difference": round(mean_a - mean_b, 2),
                "difference_percent": round((mean_a - mean_b) / mean_b * 100, 2) if mean_b != 0 else None,
                "t_statistic": round(t_stat, 4),
                "p_value": round(p_value, 6),
                "cohens_d": round(cohens_d, 3),
                "is_significant": is_significant,
                "metric_name": metric_name
            }
            
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="python_sandbox",
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"compare_groups error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="python_sandbox",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
    
    async def detect_trend(
        self,
        values: List[float],
        timestamps: Optional[List[str]] = None,
        metric_name: str = "metric"
    ) -> ToolCallResponse:
        """
        Time series trend detection.
        
        Args:
            values: Time-ordered values
            timestamps: Optional timestamps
            metric_name: Name of the metric
            
        Returns:
            ToolCallResponse with trend analysis
        """
        start_time = datetime.now()
        
        try:
            if len(values) < 3:
                return ToolCallResponse(
                    success=False,
                    tool_name="python_sandbox",
                    result=None,
                    error="Need at least 3 data points for trend detection",
                    execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
                )
            
            # Create x values (time indices)
            x = np.arange(len(values))
            y = np.array(values)
            
            # Linear regression
            slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
            
            # Determine trend direction
            if p_value < self.p_value_threshold:
                if slope > 0:
                    trend = "increasing"
                elif slope < 0:
                    trend = "decreasing"
                else:
                    trend = "flat"
            else:
                trend = "no_significant_trend"
            
            # Calculate percent change
            first_val = values[0] if values[0] != 0 else 1
            percent_change = ((values[-1] - values[0]) / first_val) * 100
            
            result = {
                "trend": trend,
                "slope": round(slope, 4),
                "intercept": round(intercept, 2),
                "r_squared": round(r_value**2, 4),
                "p_value": round(p_value, 6),
                "is_significant": p_value < self.p_value_threshold,
                "percent_change": round(percent_change, 2),
                "start_value": values[0],
                "end_value": values[-1],
                "data_points": len(values),
                "metric_name": metric_name
            }
            
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="python_sandbox",
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"detect_trend error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="python_sandbox",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
    
    async def find_outliers(
        self,
        values: List[float],
        labels: Optional[List[str]] = None,
        method: str = "iqr",
        metric_name: str = "metric"
    ) -> ToolCallResponse:
        """
        Identify statistical outliers.
        
        Args:
            values: Values to analyze
            labels: Optional labels for each value
            method: Detection method ("iqr" or "zscore")
            metric_name: Name of the metric
            
        Returns:
            ToolCallResponse with outlier analysis
        """
        start_time = datetime.now()
        
        try:
            arr = np.array(values)
            
            if method == "iqr":
                q1 = np.percentile(arr, 25)
                q3 = np.percentile(arr, 75)
                iqr = q3 - q1
                lower_bound = q1 - 1.5 * iqr
                upper_bound = q3 + 1.5 * iqr
                outlier_mask = (arr < lower_bound) | (arr > upper_bound)
            else:  # zscore
                z_scores = np.abs(stats.zscore(arr))
                outlier_mask = z_scores > 2
                lower_bound = np.mean(arr) - 2 * np.std(arr)
                upper_bound = np.mean(arr) + 2 * np.std(arr)
            
            outlier_indices = np.where(outlier_mask)[0].tolist()
            outlier_values = arr[outlier_mask].tolist()
            
            # Get labels for outliers if provided
            outlier_labels = None
            if labels and len(labels) == len(values):
                outlier_labels = [labels[i] for i in outlier_indices]
            
            result = {
                "method": method,
                "total_count": len(values),
                "outlier_count": len(outlier_values),
                "outlier_percent": round(len(outlier_values) / len(values) * 100, 2),
                "outlier_indices": outlier_indices,
                "outlier_values": [round(v, 2) for v in outlier_values],
                "outlier_labels": outlier_labels,
                "lower_bound": round(lower_bound, 2),
                "upper_bound": round(upper_bound, 2),
                "mean": round(np.mean(arr), 2),
                "std": round(np.std(arr), 2),
                "metric_name": metric_name
            }
            
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="python_sandbox",
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"find_outliers error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="python_sandbox",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
    
    async def correlate(
        self,
        metric_a_values: List[float],
        metric_b_values: List[float],
        metric_a_name: str = "Metric A",
        metric_b_name: str = "Metric B"
    ) -> ToolCallResponse:
        """
        Check correlation between two metrics.
        
        Args:
            metric_a_values: Values for metric A
            metric_b_values: Values for metric B
            metric_a_name: Name of metric A
            metric_b_name: Name of metric B
            
        Returns:
            ToolCallResponse with correlation analysis
        """
        start_time = datetime.now()
        
        try:
            if len(metric_a_values) != len(metric_b_values):
                return ToolCallResponse(
                    success=False,
                    tool_name="python_sandbox",
                    result=None,
                    error="Metrics must have the same number of values",
                    execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
                )
            
            if len(metric_a_values) < self.min_sample_size:
                return ToolCallResponse(
                    success=False,
                    tool_name="python_sandbox",
                    result=None,
                    error=f"Need at least {self.min_sample_size} data points",
                    execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
                )
            
            # Pearson correlation
            r, p_value = stats.pearsonr(metric_a_values, metric_b_values)
            
            # Interpret correlation strength
            abs_r = abs(r)
            if abs_r < 0.3:
                strength = "weak"
            elif abs_r < 0.7:
                strength = "moderate"
            else:
                strength = "strong"
            
            direction = "positive" if r > 0 else "negative"
            
            result = {
                "correlation_coefficient": round(r, 4),
                "r_squared": round(r**2, 4),
                "p_value": round(p_value, 6),
                "is_significant": p_value < self.p_value_threshold,
                "strength": strength,
                "direction": direction,
                "interpretation": f"{strength} {direction} correlation",
                "sample_size": len(metric_a_values),
                "metric_a": metric_a_name,
                "metric_b": metric_b_name
            }
            
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="python_sandbox",
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"correlate error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="python_sandbox",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
    
    async def estimate_impact(
        self,
        current_value: float,
        improvement_percent: float,
        affected_count: int,
        metric_name: str = "metric",
        additional_context: Optional[Dict[str, Any]] = None
    ) -> ToolCallResponse:
        """
        Calculate projected impact of proposed action.
        
        Args:
            current_value: Current metric value
            improvement_percent: Expected improvement percentage
            affected_count: Number of affected entities
            metric_name: Name of the metric
            additional_context: Additional context for calculation
            
        Returns:
            ToolCallResponse with impact estimation
        """
        start_time = datetime.now()
        
        try:
            projected_value = current_value * (1 + improvement_percent / 100)
            absolute_improvement = projected_value - current_value
            
            result = {
                "current_value": round(current_value, 2),
                "projected_value": round(projected_value, 2),
                "improvement_percent": round(improvement_percent, 2),
                "absolute_improvement": round(absolute_improvement, 2),
                "affected_count": affected_count,
                "total_impact": round(absolute_improvement * affected_count, 2),
                "metric_name": metric_name
            }
            
            # Add additional calculations if context provided
            if additional_context:
                if "cost_per_unit" in additional_context:
                    cost_savings = absolute_improvement * affected_count * additional_context["cost_per_unit"]
                    result["cost_savings"] = round(cost_savings, 2)
                    
                if "time_per_unit_hours" in additional_context:
                    time_savings = absolute_improvement * affected_count * additional_context["time_per_unit_hours"]
                    result["time_savings_hours"] = round(time_savings, 2)
            
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="python_sandbox",
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"estimate_impact error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="python_sandbox",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
    
    async def get_top_n(
        self,
        values: List[float],
        labels: List[str],
        n: int = 5,
        ascending: bool = True,
        metric_name: str = "metric"
    ) -> ToolCallResponse:
        """
        Retrieve top/bottom N items by metric.
        
        Args:
            values: Values to rank
            labels: Labels for each value
            n: Number of items to return
            ascending: If True, return lowest values (bottom); if False, return highest (top)
            metric_name: Name of the metric
            
        Returns:
            ToolCallResponse with top/bottom N items
        """
        start_time = datetime.now()
        
        try:
            if len(values) != len(labels):
                return ToolCallResponse(
                    success=False,
                    tool_name="python_sandbox",
                    result=None,
                    error="Values and labels must have the same length",
                    execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
                )
            
            # Create list of tuples and sort
            paired = list(zip(labels, values))
            paired.sort(key=lambda x: x[1], reverse=not ascending)
            
            # Get top N
            top_n = paired[:n]
            
            result = {
                "items": [{"label": label, "value": round(value, 2)} for label, value in top_n],
                "order": "ascending" if ascending else "descending",
                "n": n,
                "total_count": len(values),
                "metric_name": metric_name,
                "description": f"{'Bottom' if ascending else 'Top'} {n} by {metric_name}"
            }
            
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="python_sandbox",
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"get_top_n error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="python_sandbox",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )


# Singleton instance
python_sandbox = PythonSandbox()
