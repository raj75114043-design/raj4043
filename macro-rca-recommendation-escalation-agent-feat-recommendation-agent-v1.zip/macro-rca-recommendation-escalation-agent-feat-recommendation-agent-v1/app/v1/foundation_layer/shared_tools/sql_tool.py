"""
SQL Tool for Foundation Layer
==============================
File: app/v1/foundation_layer/shared_tools/sql_tool.py

Provides SQL query execution capabilities with enriched metadata context.
This tool interfaces with the Unified Layer microservice.
Used by: All agents
"""

import httpx
import json
from typing import Dict, Any, List, Optional
from datetime import datetime
import logging

from ...config import settings
from ...models import ToolCallResponse

logger = logging.getLogger(__name__)


class SQLTool:
    """
    SQL Tool for executing queries against the Nokia Macro database.
    Uses enriched metadata for NL to SQL generation.
    
    Foundation Layer Integration:
    - Enriched DB Metadata: Schema context for SQL generation
    - Executes queries via Unified Layer microservice
    """
    
    def __init__(self, base_url: Optional[str] = None):
        self.base_url = base_url or settings.unified_layer.base_url
        self.timeout = settings.unified_layer.timeout
        
    async def execute_query(
        self,
        sql: str,
        parameters: Optional[Dict[str, Any]] = None
    ) -> ToolCallResponse:
        """
        Execute a SQL query against the database.
        
        Args:
            sql: The SQL query to execute
            parameters: Optional parameters for parameterized queries
            
        Returns:
            ToolCallResponse with query results
        """
        start_time = datetime.now()
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.post(
                    f"{self.base_url}/sql/execute",
                    json={
                        "query": sql,
                        "parameters": parameters or {}
                    }
                )
                response.raise_for_status()
                result = response.json()
                
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            logger.info(f"SQL query executed successfully in {execution_time:.2f}ms")
            
            return ToolCallResponse(
                success=True,
                tool_name="sql_tool",
                result=result.get("data", []),
                execution_time_ms=execution_time
            )
            
        except httpx.HTTPStatusError as e:
            logger.error(f"SQL execution failed: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="sql_tool",
                result=None,
                error=f"HTTP Error: {e.response.status_code} - {str(e)}",
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
        except Exception as e:
            logger.error(f"SQL Tool error: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="sql_tool",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )
    
    async def get_schema_context(
        self,
        tables: Optional[List[str]] = None,
        domain: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get enriched schema metadata for SQL generation context.
        
        Args:
            tables: Specific tables to get metadata for
            domain: Domain category (e.g., "quality", "schedule")
            
        Returns:
            Dictionary with table and column metadata
        """
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                params = {}
                if tables:
                    params["tables"] = ",".join(tables)
                if domain:
                    params["domain"] = domain
                    
                response = await client.get(
                    f"{self.base_url}/metadata/schema",
                    params=params
                )
                response.raise_for_status()
                return response.json()
                
        except Exception as e:
            logger.error(f"Failed to get schema context: {e}")
            return {}
    
    async def get_derived_table(
        self,
        table_name: str,
        filters: Optional[Dict[str, Any]] = None
    ) -> ToolCallResponse:
        """
        Get pre-aggregated derived table data.
        
        Args:
            table_name: Name of the derived table
            filters: Optional filters to apply
            
        Returns:
            ToolCallResponse with table data
        """
        start_time = datetime.now()
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(
                    f"{self.base_url}/derived/{table_name}",
                    params=filters or {}
                )
                response.raise_for_status()
                result = response.json()
                
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="sql_tool",
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"Derived table fetch failed: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="sql_tool",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )

    async def get_kpi(
        self,
        kpi_name: str,
        market: Optional[str] = None,
        vendor: Optional[str] = None,
        time_range: Optional[Dict[str, str]] = None
    ) -> ToolCallResponse:
        """
        Retrieve KPI value from the KPI Catalog.
        
        Args:
            kpi_name: Name of the KPI
            market: Optional market filter
            vendor: Optional vendor filter
            time_range: Optional time range
            
        Returns:
            ToolCallResponse with KPI value
        """
        start_time = datetime.now()
        
        try:
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                params = {"kpi_name": kpi_name}
                if market:
                    params["market"] = market
                if vendor:
                    params["vendor"] = vendor
                if time_range:
                    params.update(time_range)
                    
                response = await client.get(
                    f"{self.base_url}/kpi/value",
                    params=params
                )
                response.raise_for_status()
                result = response.json()
                
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            return ToolCallResponse(
                success=True,
                tool_name="sql_tool",
                result=result,
                execution_time_ms=execution_time
            )
            
        except Exception as e:
            logger.error(f"KPI fetch failed: {e}")
            return ToolCallResponse(
                success=False,
                tool_name="sql_tool",
                result=None,
                error=str(e),
                execution_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )


# =============================================================================
# Query Templates for Common Patterns (MACRO Project)
# =============================================================================

QUERY_TEMPLATES = {
    # Site Status Queries
    "site_status_by_market": """
        SELECT 
            m_market as market,
            COUNT(*) as total_sites,
            COUNT(CASE WHEN pj_project_status = 'Completed' THEN 1 END) as completed,
            COUNT(CASE WHEN pj_project_status = 'In Progress' THEN 1 END) as wip,
            COUNT(CASE WHEN pj_project_status = 'Pending' THEN 1 END) as pending
        FROM macro_combined
        WHERE m_market = :market
        GROUP BY m_market
    """,
    
    "site_readiness_status": """
        SELECT 
            site_code,
            entitlement_status,
            ntp_status,
            bom_status,
            material_status,
            power_status,
            fiber_status,
            CASE 
                WHEN entitlement_status = 'Complete' 
                AND ntp_status = 'Approved'
                AND material_status = 'Ready'
                AND power_status = 'Ready'
                THEN 'Ready'
                ELSE 'Blocked'
            END as readiness_status
        FROM macro_combined
        WHERE m_market = :market
    """,
    
    # Vendor Performance Queries
    "vendor_performance": """
        SELECT 
            pj_general_contractor as vendor,
            COUNT(*) as total_sites,
            AVG(CASE WHEN quality_status = 'Pass' THEN 100.0 ELSE 0.0 END) as ftr_rate,
            COUNT(CASE WHEN quality_status = 'Fail' THEN 1 END) as failures,
            AVG(DATEDIFF(day, cx_start_date, cx_complete_date)) as avg_cycle_time
        FROM macro_combined
        WHERE cx_complete_date >= :start_date 
        AND cx_complete_date <= :end_date
        GROUP BY pj_general_contractor
        ORDER BY ftr_rate ASC
    """,
    
    "vendor_productivity": """
        SELECT 
            pj_general_contractor as vendor,
            DATE_TRUNC('week', cx_complete_date) as week,
            COUNT(*) as sites_completed,
            COUNT(DISTINCT crew_id) as crews_active
        FROM macro_combined
        WHERE cx_complete_date >= :start_date
        GROUP BY pj_general_contractor, DATE_TRUNC('week', cx_complete_date)
        ORDER BY week DESC
    """,
    
    # Prerequisites Queries
    "prerequisite_status": """
        SELECT 
            prerequisite_type,
            COUNT(CASE WHEN status = 'Complete' THEN 1 END) as complete_count,
            COUNT(CASE WHEN status = 'Pending' THEN 1 END) as pending_count,
            COUNT(CASE WHEN status = 'Blocked' THEN 1 END) as blocked_count,
            COUNT(*) as total
        FROM site_prerequisites
        WHERE m_market = :market
        GROUP BY prerequisite_type
    """,
    
    "prerequisite_lead_times": """
        SELECT 
            prerequisite_type,
            AVG(DATEDIFF(day, request_date, complete_date)) as mean_lead_time,
            PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY DATEDIFF(day, request_date, complete_date)) as median_lead_time
        FROM site_prerequisites
        WHERE m_market = :market
        AND complete_date IS NOT NULL
        GROUP BY prerequisite_type
    """,
    
    # HSE Compliance Queries
    "hse_compliance_summary": """
        SELECT 
            m_region as region,
            pj_general_contractor as vendor,
            COUNT(*) as total_sites,
            COUNT(CASE WHEN check_in_status = 'Pass' THEN 1 END) as check_in_pass,
            COUNT(CASE WHEN ppe_status = 'Pass' THEN 1 END) as ppe_pass,
            COUNT(CASE WHEN jsa_status = 'Pass' THEN 1 END) as jsa_pass,
            COUNT(CASE WHEN ptid_status = 'Pass' THEN 1 END) as ptid_pass,
            (COUNT(CASE WHEN check_in_status = 'Pass' AND ppe_status = 'Pass' 
                AND jsa_status = 'Pass' AND ptid_status = 'Pass' THEN 1 END) * 100.0 / COUNT(*)) as compliance_rate
        FROM macro_combined
        WHERE cx_start_date >= :start_date
        GROUP BY m_region, pj_general_contractor
        HAVING compliance_rate < :threshold
        ORDER BY compliance_rate ASC
    """,
    
    # Civil/RAN SLA Queries
    "civil_sla_breaches": """
        SELECT 
            m_region as region,
            pj_general_contractor as vendor,
            site_code,
            civil_start_date,
            civil_complete_date,
            DATEDIFF(day, civil_start_date, civil_complete_date) as duration_days
        FROM macro_combined
        WHERE civil_complete_date IS NOT NULL
        AND DATEDIFF(day, civil_start_date, civil_complete_date) > :sla_days
        AND civil_start_date >= :start_date
        ORDER BY duration_days DESC
    """,
    
    "ran_sla_breaches": """
        SELECT 
            m_region as region,
            pj_general_contractor as vendor,
            site_code,
            ran_start_date,
            ran_complete_date,
            DATEDIFF(day, ran_start_date, ran_complete_date) as duration_days
        FROM macro_combined
        WHERE ran_complete_date IS NOT NULL
        AND DATEDIFF(day, ran_start_date, ran_complete_date) > :sla_days
        AND ran_start_date >= :start_date
        ORDER BY duration_days DESC
    """,
    
    # Integration Queries
    "integration_backlog": """
        SELECT 
            m_region as region,
            COUNT(*) as construction_complete,
            COUNT(CASE WHEN integration_status = 'Complete' THEN 1 END) as integration_complete,
            COUNT(CASE WHEN integration_status = 'Pending' THEN 1 END) as integration_pending,
            COUNT(CASE WHEN on_air_status = 'Complete' THEN 1 END) as on_air_complete
        FROM macro_combined
        WHERE construction_complete_date IS NOT NULL
        GROUP BY m_region
        HAVING integration_pending > 0
        ORDER BY integration_pending DESC
    """,
    
    # Crew Capacity Queries
    "crew_capacity": """
        SELECT 
            m_market as market,
            pj_general_contractor as vendor,
            COUNT(DISTINCT crew_id) as active_crews,
            SUM(sites_per_day_capacity) as daily_capacity
        FROM vendor_crews
        WHERE m_market = :market
        AND status = 'Active'
        GROUP BY m_market, pj_general_contractor
    """,
    
    # Events/Changes Queries
    "recent_events": """
        SELECT 
            event_type,
            event_date,
            description,
            affected_entity,
            affected_value
        FROM operational_events
        WHERE event_date >= :start_date
        AND event_date <= :end_date
        AND (:market IS NULL OR m_market = :market)
        ORDER BY event_date DESC
        LIMIT :limit
    """,
    
    # Material Batch Queries
    "material_batch_performance": """
        SELECT 
            material_batch,
            supplier,
            COUNT(*) as sites_using,
            AVG(CASE WHEN quality_status = 'Pass' THEN 100.0 ELSE 0.0 END) as ftr_rate,
            COUNT(CASE WHEN quality_status = 'Fail' THEN 1 END) as failures
        FROM macro_combined
        WHERE cx_complete_date >= :start_date
        GROUP BY material_batch, supplier
        ORDER BY ftr_rate ASC
    """
}


# Singleton instance
sql_tool = SQLTool()
