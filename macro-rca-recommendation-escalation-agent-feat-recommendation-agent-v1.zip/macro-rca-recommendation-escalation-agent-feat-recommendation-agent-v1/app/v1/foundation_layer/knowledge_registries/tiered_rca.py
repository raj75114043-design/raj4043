"""
Tiered RCA System (Knowledge Registry)
=======================================
File: app/v1/foundation_layer/knowledge_registries/tiered_rca.py

Three-tier Root Cause Analysis system:
- Tier 1: Instant Lookup - Curated Plans (<2 seconds)
- Tier 2: Fast Synthesis - RAG + Historical Cases (5-10 seconds)  
- Tier 3: Deep Investigation - Agentic RCA (30-60 seconds)

Replaces manual curated plans with a hybrid approach that enables
continuous learning through the feedback loop.
"""

from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import logging

from ...config import settings, COMMON_ROOT_CAUSES, RCATier
from ...models import RCAPlan, HistoricalCase, RootCause, ValidationStatus
from ..shared_tools import sql_tool, vector_store, python_sandbox

logger = logging.getLogger(__name__)


class TieredRCASystem:
    """
    Tiered Root Cause Analysis System.
    
    Flow:
    1. Tier 1: Check curated plans (embedding similarity > 0.92)
    2. Tier 2: If no match, retrieve similar historical cases via RAG
    3. Tier 3: If low confidence, invoke agentic investigation
    """
    
    def __init__(self):
        self.tier1_threshold = settings.rca.tier1_similarity_threshold
        self.tier2_threshold = settings.rca.tier2_similarity_threshold
        self.tier3_max_tool_calls = settings.rca.tier3_max_tool_calls
        self.confidence_threshold = settings.rca.confidence_threshold
        
        # Load curated plans from config
        self.curated_plans = self._load_curated_plans()
    
    def _load_curated_plans(self) -> List[RCAPlan]:
        """Load Tier 1 curated plans from configuration."""
        plans = []
        for cause_id, cause_data in COMMON_ROOT_CAUSES.items():
            plan = RCAPlan(
                plan_id=f"PLAN_{cause_id.upper()}",
                problem_pattern=cause_data["problem_pattern"],
                trigger_conditions=f"indicators: {cause_data['indicators']}",
                root_causes=[{
                    "cause": cause_data["description"],
                    "weight": cause_data["weight"]
                }],
                validation_queries=[],  # Would be populated from DB
                recommendations=cause_data["recommendations"],
                category=cause_id
            )
            plans.append(plan)
        return plans
    
    async def analyze(
        self,
        symptom: str,
        context: Dict[str, Any],
        force_tier: Optional[int] = None
    ) -> Tuple[List[RootCause], int]:
        """
        Perform tiered RCA analysis.
        
        Args:
            symptom: Problem description (e.g., "FTR declining for vendor X")
            context: Additional context (market, vendor, time_range, etc.)
            force_tier: Force specific tier (for deep investigation)
            
        Returns:
            Tuple of (list of root causes, tier used)
        """
        logger.info(f"Starting RCA analysis for: {symptom}")
        
        # Tier 1: Check curated plans
        if force_tier is None or force_tier == 1:
            tier1_result = await self._tier1_lookup(symptom)
            if tier1_result:
                logger.info(f"Tier 1 match found: {tier1_result.plan_id}")
                return self._convert_plan_to_root_causes(tier1_result, 1), 1
        
        # Tier 2: RAG search historical cases
        if force_tier is None or force_tier == 2:
            tier2_results = await self._tier2_search(symptom, context)
            if tier2_results:
                logger.info(f"Tier 2: Found {len(tier2_results)} similar cases")
                return await self._synthesize_from_cases(tier2_results, context), 2
        
        # Tier 3: Agentic investigation
        if force_tier is None or force_tier == 3:
            logger.info("Tier 3: Starting agentic investigation")
            return await self._tier3_investigate(symptom, context), 3
        
        # No results
        return [], 0
    
    async def _tier1_lookup(self, symptom: str) -> Optional[RCAPlan]:
        """
        Tier 1: Instant lookup against curated plans.
        Response time: < 2 seconds
        Threshold: 0.92 similarity
        """
        # Use vector store to find matching plans
        result = await vector_store.search_rca_plans(
            problem_description=symptom,
            threshold=self.tier1_threshold
        )
        
        if result.success and result.result:
            matches = result.result
            if len(matches) > 0:
                # Get the best match
                best_match = matches[0]
                if best_match.get("score", 0) >= self.tier1_threshold:
                    # Find the corresponding curated plan
                    for plan in self.curated_plans:
                        if plan.plan_id == best_match.get("plan_id"):
                            return plan
        
        return None
    
    async def _tier2_search(
        self,
        symptom: str,
        context: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """
        Tier 2: RAG search over historical cases.
        Response time: 5-10 seconds
        Returns top 5 similar incidents
        """
        # Build problem signature
        problem_signature = {
            "symptom": symptom,
            "metrics": context.get("metrics", []),
            "vendor": context.get("vendor"),
            "market": context.get("market"),
            "time_range": context.get("time_range")
        }
        
        result = await vector_store.search_historical_cases(
            problem_signature=problem_signature,
            top_k=5,
            threshold=self.tier2_threshold
        )
        
        if result.success and result.result:
            return result.result
        
        return []
    
    async def _synthesize_from_cases(
        self,
        cases: List[Dict[str, Any]],
        context: Dict[str, Any]
    ) -> List[RootCause]:
        """
        Synthesize root causes from historical cases.
        Adapts past resolutions to current context.
        """
        root_causes = []
        seen_causes = set()
        
        for case in cases:
            cause_desc = case.get("root_cause_identified", "")
            
            # Avoid duplicates
            if cause_desc in seen_causes:
                continue
            seen_causes.add(cause_desc)
            
            # Calculate confidence based on similarity and case outcome
            similarity = case.get("similarity_score", 0.5)
            outcome_success = case.get("outcome", "").lower().find("success") >= 0
            confidence = similarity * (1.2 if outcome_success else 0.8)
            confidence = min(confidence, 1.0)
            
            root_cause = RootCause(
                cause_id=f"RC_T2_{case.get('case_id', 'UNKNOWN')}",
                description=cause_desc,
                confidence=confidence,
                tier=2,
                evidence_ids=[],
                validation_status=ValidationStatus.HYPOTHESIZED,
                category=self._categorize_cause(cause_desc),
                affected_entities={}
            )
            root_causes.append(root_cause)
        
        return root_causes
    
    async def _tier3_investigate(
        self,
        symptom: str,
        context: Dict[str, Any]
    ) -> List[RootCause]:
        """
        Tier 3: Agentic investigation.
        Response time: 30-60 seconds
        Uses tools: query_data, compare_groups, correlate, get_events
        
        Guardrails:
        - Max 8 tool calls
        - Statistical significance required (p < 0.05)
        - Minimum sample size: n >= 10
        - Must cite specific data
        """
        root_causes = []
        tool_calls_remaining = self.tier3_max_tool_calls
        
        # Extract context
        market = context.get("market")
        vendor = context.get("vendor")
        time_range = context.get("time_range", {})
        
        # Investigation strategies based on symptom type
        if "ftr" in symptom.lower() or "quality" in symptom.lower():
            # Quality investigation
            causes = await self._investigate_quality_issue(
                market, vendor, time_range, tool_calls_remaining
            )
            root_causes.extend(causes)
            
        elif "delay" in symptom.lower() or "sla" in symptom.lower():
            # Schedule investigation
            causes = await self._investigate_schedule_issue(
                market, vendor, time_range, tool_calls_remaining
            )
            root_causes.extend(causes)
            
        elif "compliance" in symptom.lower() or "hse" in symptom.lower():
            # Compliance investigation
            causes = await self._investigate_compliance_issue(
                market, vendor, time_range, tool_calls_remaining
            )
            root_causes.extend(causes)
        
        else:
            # Generic investigation
            causes = await self._investigate_generic(
                symptom, context, tool_calls_remaining
            )
            root_causes.extend(causes)
        
        return root_causes
    
    async def _investigate_quality_issue(
        self,
        market: Optional[str],
        vendor: Optional[str],
        time_range: Dict[str, str],
        max_calls: int
    ) -> List[RootCause]:
        """Investigate quality-related issues (FTR, rework, etc.)"""
        root_causes = []
        
        # Check 1: Crew experience correlation
        crew_result = await sql_tool.execute_query(
            """
            SELECT 
                crew_id,
                crew_onboarding_date,
                DATEDIFF(day, crew_onboarding_date, CURRENT_DATE) as tenure_days,
                AVG(CASE WHEN quality_status = 'Pass' THEN 100.0 ELSE 0.0 END) as ftr_rate,
                COUNT(*) as site_count
            FROM macro_combined
            WHERE (:market IS NULL OR m_market = :market)
            AND (:vendor IS NULL OR pj_general_contractor = :vendor)
            AND cx_complete_date >= :start_date
            GROUP BY crew_id, crew_onboarding_date
            HAVING COUNT(*) >= 5
            """,
            {
                "market": market,
                "vendor": vendor,
                "start_date": time_range.get("start", "2025-01-01")
            }
        )
        
        if crew_result.success and crew_result.result:
            crew_data = crew_result.result
            
            # Compare new vs experienced crews
            new_crew_ftr = [r["ftr_rate"] for r in crew_data if r["tenure_days"] < 30]
            exp_crew_ftr = [r["ftr_rate"] for r in crew_data if r["tenure_days"] >= 30]
            
            if len(new_crew_ftr) >= 5 and len(exp_crew_ftr) >= 5:
                comparison = await python_sandbox.compare_groups(
                    new_crew_ftr, exp_crew_ftr,
                    "New Crews (<30 days)", "Experienced Crews (≥30 days)",
                    "FTR Rate"
                )
                
                if comparison.success and comparison.result.get("is_significant"):
                    diff = comparison.result.get("difference", 0)
                    if diff < -5:  # New crews performing worse
                        root_causes.append(RootCause(
                            cause_id="RC_T3_CREW_INEXPERIENCE",
                            description=f"New crews (<30 days) have {abs(diff):.1f}% lower FTR than experienced crews",
                            confidence=0.85,
                            tier=3,
                            evidence_ids=[],
                            validation_status=ValidationStatus.VALIDATED,
                            category="crew_inexperience",
                            affected_entities={
                                "new_crew_count": len(new_crew_ftr)
                            }
                        ))
        
        # Check 2: Material batch issues
        batch_result = await sql_tool.execute_query(
            """
            SELECT 
                material_batch,
                supplier,
                COUNT(*) as sites_using,
                AVG(CASE WHEN quality_status = 'Pass' THEN 100.0 ELSE 0.0 END) as ftr_rate
            FROM macro_combined
            WHERE (:market IS NULL OR m_market = :market)
            AND cx_complete_date >= :start_date
            GROUP BY material_batch, supplier
            HAVING COUNT(*) >= 10
            """,
            {
                "market": market,
                "start_date": time_range.get("start", "2025-01-01")
            }
        )
        
        if batch_result.success and batch_result.result:
            batch_data = batch_result.result
            
            # Find outlier batches
            ftr_rates = [b["ftr_rate"] for b in batch_data]
            labels = [b["material_batch"] for b in batch_data]
            
            if len(ftr_rates) >= 3:
                outliers = await python_sandbox.find_outliers(
                    ftr_rates, labels, method="iqr", metric_name="FTR Rate"
                )
                
                if outliers.success and outliers.result.get("outlier_count", 0) > 0:
                    # Check if outliers are low performers
                    for i, (label, value) in enumerate(zip(
                        outliers.result.get("outlier_labels", []),
                        outliers.result.get("outlier_values", [])
                    )):
                        if value < outliers.result.get("lower_bound", 80):
                            # Find batch details
                            batch_info = next((b for b in batch_data if b["material_batch"] == label), None)
                            if batch_info:
                                root_causes.append(RootCause(
                                    cause_id=f"RC_T3_MATERIAL_BATCH_{label}",
                                    description=f"Material batch {label} has significantly lower FTR ({value:.1f}%) vs average",
                                    confidence=0.80,
                                    tier=3,
                                    evidence_ids=[],
                                    validation_status=ValidationStatus.VALIDATED,
                                    category="material_batch_issue",
                                    affected_entities={
                                        "batch": label,
                                        "supplier": batch_info.get("supplier"),
                                        "sites_affected": batch_info.get("sites_using")
                                    }
                                ))
        
        return root_causes
    
    async def _investigate_schedule_issue(
        self,
        market: Optional[str],
        vendor: Optional[str],
        time_range: Dict[str, str],
        max_calls: int
    ) -> List[RootCause]:
        """Investigate schedule-related issues (delays, SLA breaches)"""
        root_causes = []
        
        # Check: Prerequisite delays
        prereq_result = await sql_tool.execute_query(
            """
            SELECT 
                prerequisite_type,
                COUNT(*) as total,
                COUNT(CASE WHEN status = 'Blocked' THEN 1 END) as blocked,
                AVG(DATEDIFF(day, request_date, complete_date)) as avg_lead_time
            FROM site_prerequisites
            WHERE (:market IS NULL OR m_market = :market)
            AND request_date >= :start_date
            GROUP BY prerequisite_type
            ORDER BY blocked DESC
            """,
            {
                "market": market,
                "start_date": time_range.get("start", "2025-01-01")
            }
        )
        
        if prereq_result.success and prereq_result.result:
            for prereq in prereq_result.result:
                if prereq["blocked"] > 0:
                    block_rate = (prereq["blocked"] / prereq["total"]) * 100
                    if block_rate > 20:  # More than 20% blocked
                        root_causes.append(RootCause(
                            cause_id=f"RC_T3_PREREQ_{prereq['prerequisite_type'].upper()}",
                            description=f"{prereq['prerequisite_type']} has {block_rate:.1f}% blocked sites ({prereq['blocked']} of {prereq['total']})",
                            confidence=0.75,
                            tier=3,
                            evidence_ids=[],
                            validation_status=ValidationStatus.VALIDATED,
                            category="prerequisite_delay",
                            affected_entities={
                                "prerequisite_type": prereq["prerequisite_type"],
                                "blocked_count": prereq["blocked"],
                                "avg_lead_time_days": prereq.get("avg_lead_time")
                            }
                        ))
        
        return root_causes
    
    async def _investigate_compliance_issue(
        self,
        market: Optional[str],
        vendor: Optional[str],
        time_range: Dict[str, str],
        max_calls: int
    ) -> List[RootCause]:
        """Investigate compliance-related issues (HSE, quality)"""
        root_causes = []
        
        # Check: HSE violations by vendor
        hse_result = await sql_tool.execute_query(
            """
            SELECT 
                pj_general_contractor as vendor,
                COUNT(*) as total_sites,
                COUNT(CASE WHEN check_in_status = 'Fail' THEN 1 END) as check_in_fails,
                COUNT(CASE WHEN ppe_status = 'Fail' THEN 1 END) as ppe_fails,
                COUNT(CASE WHEN jsa_status = 'Fail' THEN 1 END) as jsa_fails
            FROM macro_combined
            WHERE (:market IS NULL OR m_market = :market)
            AND cx_start_date >= :start_date
            GROUP BY pj_general_contractor
            HAVING total_sites >= 10
            ORDER BY (check_in_fails + ppe_fails + jsa_fails) DESC
            LIMIT 5
            """,
            {
                "market": market,
                "start_date": time_range.get("start", "2025-01-01")
            }
        )
        
        if hse_result.success and hse_result.result:
            for v in hse_result.result:
                total_violations = v["check_in_fails"] + v["ppe_fails"] + v["jsa_fails"]
                if total_violations > 0:
                    violation_rate = (total_violations / (v["total_sites"] * 3)) * 100
                    if violation_rate > 10:
                        # Determine primary issue
                        issues = []
                        if v["check_in_fails"] > 0:
                            issues.append(f"Check-in ({v['check_in_fails']})")
                        if v["ppe_fails"] > 0:
                            issues.append(f"PPE ({v['ppe_fails']})")
                        if v["jsa_fails"] > 0:
                            issues.append(f"JSA ({v['jsa_fails']})")
                        
                        root_causes.append(RootCause(
                            cause_id=f"RC_T3_HSE_{v['vendor'][:10].upper()}",
                            description=f"Vendor {v['vendor']} has HSE violations: {', '.join(issues)}",
                            confidence=0.85,
                            tier=3,
                            evidence_ids=[],
                            validation_status=ValidationStatus.VALIDATED,
                            category="hse_non_compliance",
                            affected_entities={
                                "vendor": v["vendor"],
                                "total_violations": total_violations,
                                "sites_affected": v["total_sites"]
                            }
                        ))
        
        return root_causes
    
    async def _investigate_generic(
        self,
        symptom: str,
        context: Dict[str, Any],
        max_calls: int
    ) -> List[RootCause]:
        """Generic investigation when symptom type is unclear"""
        # Use vector store to find similar past investigations
        cases = await self._tier2_search(symptom, context)
        if cases:
            return await self._synthesize_from_cases(cases, context)
        return []
    
    def _convert_plan_to_root_causes(
        self,
        plan: RCAPlan,
        tier: int
    ) -> List[RootCause]:
        """Convert a curated plan to root cause objects"""
        root_causes = []
        for i, cause_data in enumerate(plan.root_causes):
            root_cause = RootCause(
                cause_id=f"RC_T{tier}_{plan.plan_id}_{i}",
                description=cause_data.get("cause", ""),
                confidence=cause_data.get("weight", 0.5),
                tier=tier,
                evidence_ids=[],
                validation_status=ValidationStatus.VALIDATED,
                category=plan.category,
                affected_entities={}
            )
            root_causes.append(root_cause)
        return root_causes
    
    def _categorize_cause(self, description: str) -> str:
        """Categorize a root cause description"""
        desc_lower = description.lower()
        
        if "crew" in desc_lower or "training" in desc_lower or "experience" in desc_lower:
            return "crew_inexperience"
        elif "material" in desc_lower or "batch" in desc_lower or "supplier" in desc_lower:
            return "material_batch_issue"
        elif "vendor" in desc_lower or "gc" in desc_lower or "contractor" in desc_lower:
            return "vendor_underperformance"
        elif "access" in desc_lower or "permission" in desc_lower or "landlord" in desc_lower:
            return "site_access_delay"
        elif "prereq" in desc_lower or "power" in desc_lower or "fiber" in desc_lower:
            return "prerequisite_delay"
        elif "safety" in desc_lower or "hse" in desc_lower or "compliance" in desc_lower:
            return "hse_non_compliance"
        else:
            return "other"


# Singleton instance
tiered_rca = TieredRCASystem()
