"""
KPI Catalog (Knowledge Registry)
=================================
File: app/v1/foundation_layer/knowledge_registries/kpi_catalog.py

Centralized KPI definitions with formulas, thresholds, and ownership.
Used by: Dashboard, Insights Agent, Simulator, all analysis agents
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import logging

from ...config import settings, KPI_CATEGORIES
from ...models import KPIDefinition, ToolCallResponse
from ..shared_tools import sql_tool

logger = logging.getLogger(__name__)


class KPICatalog:
    """
    KPI Catalog providing centralized metric definitions.
    """
    
    def __init__(self):
        self.kpis = self._initialize_kpis()
    
    def _initialize_kpis(self) -> Dict[str, KPIDefinition]:
        """Initialize KPI definitions for MACRO project"""
        kpis = {}
        
        # Schedule & Delivery KPIs
        kpis["plan_achievement"] = KPIDefinition(
            kpi_id="KPI_PLAN_ACH",
            kpi_name="Plan Achievement",
            formula="(Actual Completed / Planned) * 100",
            thresholds={"red": 80, "amber": 95, "green": 100},
            owner="Project Manager",
            category="schedule_delivery",
            unit="%",
            is_critical=True
        )
        
        kpis["ftr_rate"] = KPIDefinition(
            kpi_id="KPI_FTR",
            kpi_name="First Time Right Rate",
            formula="COUNT(Pass) / COUNT(*) * 100",
            thresholds={"red": 85, "amber": 95, "green": 100},
            owner="Quality Manager",
            category="quality_compliance",
            unit="%",
            is_critical=True
        )
        
        kpis["hse_compliance"] = KPIDefinition(
            kpi_id="KPI_HSE_COMP",
            kpi_name="HSE Compliance Rate",
            formula="(Check-in Pass + PPE Pass + JSA Pass + PTID Pass) / (4 * Total) * 100",
            thresholds={"red": 90, "amber": 95, "green": 100},
            owner="Safety Manager",
            category="quality_compliance",
            unit="%",
            is_critical=True
        )
        
        kpis["site_readiness"] = KPIDefinition(
            kpi_id="KPI_SITE_READY",
            kpi_name="Site Readiness Rate",
            formula="COUNT(All Prerequisites Complete) / COUNT(Total Sites) * 100",
            thresholds={"red": 60, "amber": 80, "green": 95},
            owner="Operations Manager",
            category="material_readiness",
            unit="%",
            is_critical=True
        )
        
        kpis["vendor_on_time"] = KPIDefinition(
            kpi_id="KPI_VENDOR_OT",
            kpi_name="Vendor On-Time Performance",
            formula="COUNT(Completed On Time) / COUNT(Total Assigned) * 100",
            thresholds={"red": 80, "amber": 90, "green": 98},
            owner="Vendor Manager",
            category="vendor_performance",
            unit="%"
        )
        
        kpis["crew_utilization"] = KPIDefinition(
            kpi_id="KPI_CREW_UTIL",
            kpi_name="Crew Utilization",
            formula="Actual Sites / (Crews * Days * Capacity) * 100",
            thresholds={"red": 60, "amber": 75, "green": 90},
            owner="Resource Manager",
            category="resource_capacity",
            unit="%"
        )
        
        return kpis
    
    def get_kpi(self, kpi_name: str) -> Optional[KPIDefinition]:
        """Get KPI definition by name"""
        return self.kpis.get(kpi_name)
    
    def get_critical_kpis(self) -> List[KPIDefinition]:
        """Get all critical KPIs"""
        return [kpi for kpi in self.kpis.values() if kpi.is_critical]
    
    def get_kpis_by_category(self, category: str) -> List[KPIDefinition]:
        """Get KPIs by category"""
        return [kpi for kpi in self.kpis.values() if kpi.category == category]
    
    def check_threshold(self, kpi_name: str, value: float) -> str:
        """Check which threshold band a value falls into"""
        kpi = self.get_kpi(kpi_name)
        if not kpi:
            return "unknown"
        
        if value < kpi.thresholds.get("red", 0):
            return "red"
        elif value < kpi.thresholds.get("amber", 0):
            return "amber"
        else:
            return "green"


# Singleton instance
kpi_catalog = KPICatalog()
