"""
Foundation Layer Module
========================
File: app/v1/foundation_layer/__init__.py

The Foundation Layer serves as the unified knowledge and tooling backbone.
All specialized agents consume from this layer.

Components:
1. Knowledge Registries - Encode domain semantics and business logic
2. Shared Tools - Provide common execution capabilities
"""

from .knowledge_registries import (
    TieredRCASystem,
    tiered_rca,
    KPICatalog,
    kpi_catalog
)

from .shared_tools import (
    SQLTool,
    sql_tool,
    QUERY_TEMPLATES,
    PythonSandbox,
    python_sandbox,
    VectorStore,
    vector_store,
    FeedbackLoop,
    feedback_loop,
    FeedbackType
)

__all__ = [
    # Knowledge Registries
    "TieredRCASystem",
    "tiered_rca",
    "KPICatalog",
    "kpi_catalog",
    
    # Shared Tools
    "SQLTool",
    "sql_tool",
    "QUERY_TEMPLATES",
    "PythonSandbox",
    "python_sandbox",
    "VectorStore",
    "vector_store",
    "FeedbackLoop",
    "feedback_loop",
    "FeedbackType"
]
