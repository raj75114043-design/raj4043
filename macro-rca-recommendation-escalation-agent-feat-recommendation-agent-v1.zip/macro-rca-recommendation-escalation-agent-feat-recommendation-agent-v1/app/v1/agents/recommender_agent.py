"""
Recommender Agent
==================
File: app/v1/agents/recommender_agent.py

Role: Generate actionable recommendations with quantified impact based on findings from other agents.

Foundation Layer Access:
- Python Sandbox: Impact calculations
- KPI Catalog: SLAs, thresholds for impact framing
- Feedback Loop: Historical impact baselines from past recommendations

Can Request: Analyst for impact calculations
Can Request: RCA Agent to confirm cause-action mapping
Outputs To: Orchestrator (final recommendation)
"""

from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import logging
import uuid

from ..config import AgentType, COMMON_ROOT_CAUSES, settings
from ..models import (
    AgentState, AgentStatus, RootCause, Recommendation,
    InsightPriority, Feasibility, InsightOutput, InsightType
)
from .base_agent import BaseAgent

logger = logging.getLogger(__name__)


class RecommenderAgent(BaseAgent):
    """
    Recommender Agent - Generates actionable recommendations with quantified impact.
    
    Tools:
    - generate_action(root_cause): Map root cause to recommended action
    - quantify_impact(action, evidence): Calculate sites recovered, days saved, KPI improvement
    - rank_recommendations(recos): Priority ranking by impact × feasibility
    - get_historical_impact(action_type): Lookup past impact of similar recommendations
    """
    
    def __init__(self):
        super().__init__(AgentType.RECOMMENDER)
        
        # Action mappings for each root cause category
        self.action_mappings = {
            "crew_inexperience": [
                {
                    "action": "Schedule refresher training for affected crews",
                    "owner": "GC Manager",
                    "timeline": "1-2 weeks",
                    "feasibility": Feasibility.HIGH
                },
                {
                    "action": "Pair new crews with experienced mentors",
                    "owner": "Operations Manager",
                    "timeline": "Immediate",
                    "feasibility": Feasibility.HIGH
                }
            ],
            "material_batch_issue": [
                {
                    "action": "Quarantine remaining inventory from affected batch",
                    "owner": "Supply Chain Manager",
                    "timeline": "Immediate",
                    "feasibility": Feasibility.HIGH
                },
                {
                    "action": "Initiate supplier quality review and request replacement",
                    "owner": "Procurement Manager",
                    "timeline": "1 week",
                    "feasibility": Feasibility.MEDIUM
                }
            ],
            "vendor_underperformance": [
                {
                    "action": "Shift volume to better performing vendors",
                    "owner": "Vendor Manager",
                    "timeline": "2-4 weeks",
                    "feasibility": Feasibility.MEDIUM
                },
                {
                    "action": "Apply penalty clauses and initiate performance improvement plan",
                    "owner": "Contract Manager",
                    "timeline": "1 week",
                    "feasibility": Feasibility.HIGH
                },
                {
                    "action": "Freeze new site awards for bottom-quartile vendors",
                    "owner": "Project Manager",
                    "timeline": "Immediate",
                    "feasibility": Feasibility.HIGH
                }
            ],
            "hse_non_compliance": [
                {
                    "action": "Enforce compliance process adherence with daily audits",
                    "owner": "Safety Manager",
                    "timeline": "Immediate",
                    "feasibility": Feasibility.HIGH
                },
                {
                    "action": "Issue formal notice to repeat violators",
                    "owner": "Safety Manager / CM",
                    "timeline": "1-2 days",
                    "feasibility": Feasibility.HIGH
                },
                {
                    "action": "Mandatory safety retraining for non-compliant crews",
                    "owner": "GC Manager",
                    "timeline": "1 week",
                    "feasibility": Feasibility.MEDIUM
                }
            ],
            "prerequisite_delay": [
                {
                    "action": "Fast-track critical prerequisites (power, fiber, NTP)",
                    "owner": "Operations Manager",
                    "timeline": "1-2 weeks",
                    "feasibility": Feasibility.MEDIUM
                },
                {
                    "action": "Launch readiness acceleration task force",
                    "owner": "Project Manager",
                    "timeline": "Immediate",
                    "feasibility": Feasibility.HIGH
                }
            ],
            "site_access_delay": [
                {
                    "action": "Improve stakeholder management and pre-survey verification",
                    "owner": "Site Acquisition Manager",
                    "timeline": "Ongoing",
                    "feasibility": Feasibility.MEDIUM
                },
                {
                    "action": "Conduct joint re-verification with landlord",
                    "owner": "Field Operations",
                    "timeline": "1-2 days per site",
                    "feasibility": Feasibility.HIGH
                }
            ],
            "integration_backlog": [
                {
                    "action": "Add integration shifts (night/weekend)",
                    "owner": "Integration Manager",
                    "timeline": "1 week",
                    "feasibility": Feasibility.MEDIUM
                },
                {
                    "action": "Expand CMG maintenance windows",
                    "owner": "NAS Team",
                    "timeline": "2-4 weeks",
                    "feasibility": Feasibility.LOW
                },
                {
                    "action": "Align construction completion with integration capacity",
                    "owner": "Project Manager",
                    "timeline": "Ongoing",
                    "feasibility": Feasibility.MEDIUM
                }
            ]
        }
    
    async def process(self, state: AgentState) -> AgentState:
        """
        Generate recommendations based on root causes and evidence.
        
        Steps:
        1. Read root causes from analysis state
        2. Map each cause to recommended actions
        3. Quantify impact for each action
        4. Rank recommendations by impact × feasibility
        5. Generate final recommendation list
        """
        logger.info(f"[Recommender] Generating recommendations for {len(state.analysis.root_causes)} root causes")
        state.current_agent = self.name
        state.status = AgentStatus.RECOMMENDING
        
        recommendations = []
        
        # Process each root cause
        for root_cause in state.analysis.root_causes:
            cause_recommendations = await self._generate_recommendations_for_cause(
                state, root_cause
            )
            recommendations.extend(cause_recommendations)
        
        # Rank recommendations
        ranked_recommendations = self._rank_recommendations(recommendations)
        
        # Store recommendations
        state.recommendations = ranked_recommendations[:10]  # Top 10
        state.has_quantified_impact = any(r.impact for r in state.recommendations)
        
        logger.info(f"[Recommender] Generated {len(state.recommendations)} recommendations")
        
        return state
    
    async def _generate_recommendations_for_cause(
        self,
        state: AgentState,
        root_cause: RootCause
    ) -> List[Recommendation]:
        """Generate recommendations for a single root cause"""
        recommendations = []
        
        # Get action mappings for this cause category
        actions = self.action_mappings.get(root_cause.category, [])
        
        if not actions:
            # Generate generic recommendation
            actions = [{
                "action": f"Investigate and address: {root_cause.description}",
                "owner": "Project Manager",
                "timeline": "TBD",
                "feasibility": Feasibility.MEDIUM
            }]
        
        for action_config in actions:
            # Calculate impact
            impact = await self._calculate_impact(state, root_cause, action_config["action"])
            
            # Determine priority based on root cause confidence and impact
            priority = self._determine_priority(root_cause.confidence, impact)
            
            recommendation = Recommendation(
                recommendation_id=f"REC_{uuid.uuid4().hex[:8].upper()}",
                action=action_config["action"],
                description=f"To address: {root_cause.description}",
                root_cause_id=root_cause.cause_id,
                priority=priority,
                impact=impact,
                feasibility=action_config["feasibility"],
                owner=action_config["owner"],
                timeline=action_config["timeline"],
                metrics_improvement=impact.get("metrics_improvement")
            )
            recommendations.append(recommendation)
        
        return recommendations
    
    async def _calculate_impact(
        self,
        state: AgentState,
        root_cause: RootCause,
        action: str
    ) -> Dict[str, Any]:
        """Calculate the expected impact of an action"""
        impact = {
            "sites_affected": 0,
            "estimated_improvement": 0,
            "confidence": 0.5
        }
        
        # Get affected count from root cause
        affected_count = root_cause.affected_entities.get("count", 0)
        if not affected_count:
            # Estimate from evidence
            affected_count = self._estimate_affected_count(state, root_cause)
        
        impact["sites_affected"] = affected_count
        
        # Get historical impact for this action type
        action_type = self._get_action_type(action)
        state, hist_result = await self.execute_tool(
            state, "feedback_loop.get_historical_impact",
            self.feedback_loop.get_historical_impact,
            action_type=action_type
        )
        
        if hist_result.success and hist_result.result:
            historical_data = hist_result.result
            impact["estimated_improvement"] = historical_data.get("avg_improvement_percent", 15)
            impact["confidence"] = 0.8
            impact["based_on_historical"] = True
        else:
            # Use default estimates
            default_improvements = {
                "training": 22,
                "mentoring": 18,
                "quarantine": 20,
                "volume_shift": 15,
                "penalty": 10,
                "fast_track": 25,
                "audit": 12
            }
            
            for key, value in default_improvements.items():
                if key in action.lower():
                    impact["estimated_improvement"] = value
                    break
            else:
                impact["estimated_improvement"] = 15  # Default
            
            impact["confidence"] = 0.5
            impact["based_on_historical"] = False
        
        # Calculate projected metrics improvement
        if state.evidence.metrics:
            baseline_ftr = state.evidence.metrics.get("D2_avg_ftr") or state.evidence.metrics.get("D1_avg_ftr", 85)
            projected_ftr = baseline_ftr + impact["estimated_improvement"]
            impact["metrics_improvement"] = {
                "ftr_current": baseline_ftr,
                "ftr_projected": min(projected_ftr, 100),
                "improvement_percent": impact["estimated_improvement"]
            }
        
        # Calculate business value if possible
        if affected_count > 0:
            # Assuming $1500 rework cost per failed site
            avoided_failures = affected_count * (impact["estimated_improvement"] / 100)
            impact["estimated_cost_savings"] = avoided_failures * 1500
        
        return impact
    
    def _estimate_affected_count(self, state: AgentState, root_cause: RootCause) -> int:
        """Estimate the number of affected entities"""
        # Try to get from evidence
        for evidence in state.evidence.data_tables:
            if isinstance(evidence.data, list):
                # Check if this evidence relates to the root cause
                if root_cause.category in evidence.description.lower():
                    return len(evidence.data)
        
        # Try to get from metrics
        total_sites = state.evidence.metrics.get("D1_total_sites", 0)
        if total_sites:
            # Estimate 20% affected
            return int(total_sites * 0.2)
        
        return 10  # Default estimate
    
    def _get_action_type(self, action: str) -> str:
        """Extract action type from action description"""
        action_lower = action.lower()
        
        if "training" in action_lower or "retrain" in action_lower:
            return "crew_retraining"
        elif "mentor" in action_lower or "pair" in action_lower:
            return "mentoring"
        elif "quarantine" in action_lower:
            return "material_quarantine"
        elif "shift volume" in action_lower:
            return "vendor_shift"
        elif "penalty" in action_lower or "notice" in action_lower:
            return "penalty_enforcement"
        elif "fast-track" in action_lower or "accelerate" in action_lower:
            return "prerequisite_acceleration"
        elif "audit" in action_lower:
            return "compliance_audit"
        else:
            return "general_improvement"
    
    def _determine_priority(self, confidence: float, impact: Dict[str, Any]) -> InsightPriority:
        """Determine recommendation priority"""
        improvement = impact.get("estimated_improvement", 0)
        affected = impact.get("sites_affected", 0)
        
        # High confidence + high impact = CRITICAL
        if confidence >= 0.8 and improvement >= 20 and affected >= 10:
            return InsightPriority.CRITICAL
        
        # Medium-high confidence + good impact = HIGH
        if confidence >= 0.7 and improvement >= 15:
            return InsightPriority.HIGH
        
        # Moderate impact = MEDIUM
        if improvement >= 10:
            return InsightPriority.MEDIUM
        
        return InsightPriority.LOW
    
    def _rank_recommendations(self, recommendations: List[Recommendation]) -> List[Recommendation]:
        """Rank recommendations by impact × feasibility"""
        def score(rec: Recommendation) -> float:
            # Impact score (0-100)
            impact_score = rec.impact.get("estimated_improvement", 0) * rec.impact.get("sites_affected", 1) / 10
            
            # Feasibility multiplier
            feasibility_mult = {
                Feasibility.HIGH: 1.0,
                Feasibility.MEDIUM: 0.7,
                Feasibility.LOW: 0.4
            }.get(rec.feasibility, 0.5)
            
            # Priority multiplier
            priority_mult = {
                InsightPriority.CRITICAL: 1.5,
                InsightPriority.HIGH: 1.2,
                InsightPriority.MEDIUM: 1.0,
                InsightPriority.LOW: 0.8
            }.get(rec.priority, 1.0)
            
            return impact_score * feasibility_mult * priority_mult
        
        return sorted(recommendations, key=score, reverse=True)
    
    def generate_insights(self, state: AgentState) -> List[InsightOutput]:
        """Generate insight outputs from recommendations"""
        insights = []
        
        for i, rec in enumerate(state.recommendations[:5]):  # Top 5 as insights
            # Find the root cause
            root_cause = next(
                (rc for rc in state.analysis.root_causes if rc.cause_id == rec.root_cause_id),
                None
            )
            
            insight = InsightOutput(
                insight_id=f"INS_{datetime.now().strftime('%Y%m%d')}_{i+1:03d}",
                tier=root_cause.tier if root_cause else 3,
                category=root_cause.category if root_cause else "general",
                title=f"Action Required: {rec.action[:50]}...",
                description=f"{root_cause.description if root_cause else 'Issue identified'}. {rec.description}",
                priority=rec.priority,
                type=InsightType.ACTIONABLE,
                recommendation=rec.action,
                affected_entities=root_cause.affected_entities if root_cause else {},
                metrics={
                    "estimated_improvement": rec.impact.get("estimated_improvement"),
                    "sites_affected": rec.impact.get("sites_affected"),
                    "cost_savings": rec.impact.get("estimated_cost_savings")
                },
                source={
                    "root_cause_id": rec.root_cause_id,
                    "confidence": root_cause.confidence if root_cause else 0.5
                },
                metadata={
                    "owner": rec.owner,
                    "timeline": rec.timeline,
                    "feasibility": rec.feasibility.value
                }
            )
            insights.append(insight)
        
        return insights


# Singleton instance
recommender_agent = RecommenderAgent()
