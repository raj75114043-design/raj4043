"""
Data Agent
===========
File: app/v1/agents/data_agent.py

Role: Fetch data from all available sources based on requirements from any agent.

Foundation Layer Access:
- SQL Tool: Execute queries against project database
- Enriched DB Metadata: Context for SQL generation (synonyms, patterns)
- Derived Tables: Pre-aggregated views for common patterns
- KPI Catalog: Formulas for computed metrics

Receives Requests From: Planner, Analyst, RCA Agent, Recommender
Outputs To: Shared state (evidence) for all agents
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import logging

from ..config import AgentType
from ..models import (
    AgentState, AgentStatus, Evidence, EvidenceState
)
from ..foundation_layer import sql_tool, QUERY_TEMPLATES
from .base_agent import BaseAgent

logger = logging.getLogger(__name__)


class DataAgent(BaseAgent):
    """
    Data Agent - Fetches data from all sources.
    
    Tools:
    - query_data(sql): Execute SQL via SQL Tool
    - get_derived_table(name): Fetch pre-aggregated view
    - get_historical(metric, window): Retrieve historical baseline
    - get_events(filter, window): Fetch operational events/changes
    - get_kpi(name, market): Get KPI value from catalog
    """
    
    def __init__(self):
        super().__init__(AgentType.DATA_AGENT)
    
    async def process(self, state: AgentState) -> AgentState:
        """
        Fetch all required data based on the plan.
        
        Steps:
        1. Read data requirements from plan
        2. Execute queries for each requirement
        3. Store results in evidence state
        """
        logger.info(f"[DataAgent] Fetching data for {len(state.plan.data_requirements)} requirements")
        state.current_agent = self.name
        state.status = AgentStatus.GATHERING
        
        # Process each data requirement
        for req in state.plan.data_requirements:
            state = await self._fetch_data_requirement(state, req)
        
        # Mark evidence as gathered
        state.has_evidence = len(state.evidence.data_tables) > 0
        
        logger.info(f"[DataAgent] Gathered {len(state.evidence.data_tables)} evidence items")
        
        return state
    
    async def _fetch_data_requirement(self, state: AgentState, req) -> AgentState:
        """Fetch data for a single requirement"""
        logger.info(f"[DataAgent] Fetching: {req.description}")
        
        try:
            if req.source == "SQL":
                state = await self._execute_sql_query(state, req)
            elif req.source == "Derived":
                state = await self._fetch_derived_table(state, req)
            elif req.source == "Cache":
                state = await self._fetch_from_cache(state, req)
            else:
                state = await self._execute_sql_query(state, req)
                
        except Exception as e:
            state = self.log_error(state, f"Failed to fetch {req.requirement_id}: {str(e)}")
        
        return state
    
    async def _execute_sql_query(self, state: AgentState, req) -> AgentState:
        """Execute a SQL query"""
        # Get SQL template if specified
        sql_template = req.sql_template
        if sql_template and sql_template in QUERY_TEMPLATES:
            sql = QUERY_TEMPLATES[sql_template]
        else:
            # Build dynamic query based on requirement description
            sql = self._build_query_from_description(req.description, req.parameters)
        
        # Execute query
        state, result = await self.execute_tool(
            state,
            f"sql_tool.execute_query",
            self.sql_tool.execute_query,
            sql=sql,
            parameters=req.parameters
        )
        
        if result.success and result.result:
            # Store as evidence
            evidence = Evidence(
                evidence_id=f"EV_{req.requirement_id}",
                source="SQL",
                description=req.description,
                data=result.result,
                query_used=sql,
                confidence=1.0
            )
            state.evidence.data_tables.append(evidence)
            
            # Extract key metrics
            state = self._extract_metrics(state, req, result.result)
        
        return state
    
    async def _fetch_derived_table(self, state: AgentState, req) -> AgentState:
        """Fetch pre-aggregated derived table"""
        table_name = req.parameters.get("table_name", req.sql_template)
        filters = {k: v for k, v in req.parameters.items() if k != "table_name"}
        
        state, result = await self.execute_tool(
            state,
            f"sql_tool.get_derived_table",
            self.sql_tool.get_derived_table,
            table_name=table_name,
            filters=filters
        )
        
        if result.success and result.result:
            evidence = Evidence(
                evidence_id=f"EV_{req.requirement_id}",
                source="Derived",
                description=req.description,
                data=result.result,
                confidence=1.0
            )
            state.evidence.data_tables.append(evidence)
        
        return state
    
    async def _fetch_from_cache(self, state: AgentState, req) -> AgentState:
        """Fetch from pre-processed cache"""
        # For now, fall back to SQL
        return await self._execute_sql_query(state, req)
    
    def _build_query_from_description(self, description: str, parameters: Dict[str, Any]) -> str:
        """Build a SQL query from natural language description"""
        desc_lower = description.lower()
        
        # Site status query
        if "site status" in desc_lower or "completed" in desc_lower:
            return QUERY_TEMPLATES.get("site_status_by_market", "SELECT 1")
        
        # Vendor performance
        if "vendor" in desc_lower and ("performance" in desc_lower or "ftr" in desc_lower):
            return QUERY_TEMPLATES.get("vendor_performance", "SELECT 1")
        
        # HSE compliance
        if "hse" in desc_lower or "compliance" in desc_lower:
            return QUERY_TEMPLATES.get("hse_compliance_summary", "SELECT 1")
        
        # Prerequisites
        if "prerequisite" in desc_lower or "readiness" in desc_lower:
            return QUERY_TEMPLATES.get("prerequisite_status", "SELECT 1")
        
        # Events
        if "event" in desc_lower or "change" in desc_lower:
            return QUERY_TEMPLATES.get("recent_events", "SELECT 1")
        
        # Default - return a placeholder
        logger.warning(f"[DataAgent] Could not build query for: {description}")
        return "SELECT 1 as placeholder"
    
    def _extract_metrics(self, state: AgentState, req, data: List[Dict]) -> AgentState:
        """Extract key metrics from query results"""
        if not data:
            return state
        
        req_id = req.requirement_id
        
        # Extract based on data content
        if isinstance(data, list) and len(data) > 0:
            first_row = data[0]
            
            # Check for common metric columns
            if "ftr_rate" in first_row:
                # Calculate average FTR
                ftr_values = [r.get("ftr_rate", 0) for r in data if r.get("ftr_rate") is not None]
                if ftr_values:
                    state.evidence.metrics[f"{req_id}_avg_ftr"] = sum(ftr_values) / len(ftr_values)
                    state.evidence.metrics[f"{req_id}_min_ftr"] = min(ftr_values)
                    state.evidence.metrics[f"{req_id}_max_ftr"] = max(ftr_values)
            
            if "total_sites" in first_row:
                total = sum(r.get("total_sites", 0) for r in data)
                state.evidence.metrics[f"{req_id}_total_sites"] = total
            
            if "completed" in first_row:
                completed = sum(r.get("completed", 0) for r in data)
                state.evidence.metrics[f"{req_id}_completed"] = completed
            
            if "compliance_rate" in first_row:
                compliance_values = [r.get("compliance_rate", 0) for r in data if r.get("compliance_rate") is not None]
                if compliance_values:
                    state.evidence.metrics[f"{req_id}_avg_compliance"] = sum(compliance_values) / len(compliance_values)
        
        return state
    
    async def fetch_additional_data(
        self,
        state: AgentState,
        request_from: str,
        query_type: str,
        parameters: Dict[str, Any]
    ) -> AgentState:
        """
        Handle direct requests from other agents for additional data.
        
        This method supports the inter-agent communication pattern where
        agents can request specific data from the Data Agent.
        """
        logger.info(f"[DataAgent] Received request from {request_from}: {query_type}")
        
        state = self.log_message(
            state,
            to_agent=request_from,
            action=f"fulfilling_{query_type}",
            parameters=parameters
        )
        
        if query_type == "vendor_detail":
            sql = """
                SELECT * FROM macro_combined 
                WHERE pj_general_contractor = :vendor
                AND (:market IS NULL OR m_market = :market)
                LIMIT 100
            """
            state, result = await self.execute_tool(
                state, "sql_tool.execute_query",
                self.sql_tool.execute_query,
                sql=sql, parameters=parameters
            )
            
        elif query_type == "crew_data":
            sql = """
                SELECT crew_id, crew_onboarding_date, 
                       COUNT(*) as sites,
                       AVG(CASE WHEN quality_status = 'Pass' THEN 100.0 ELSE 0.0 END) as ftr
                FROM macro_combined
                WHERE (:vendor IS NULL OR pj_general_contractor = :vendor)
                GROUP BY crew_id, crew_onboarding_date
            """
            state, result = await self.execute_tool(
                state, "sql_tool.execute_query",
                self.sql_tool.execute_query,
                sql=sql, parameters=parameters
            )
        
        elif query_type == "material_batch":
            sql = QUERY_TEMPLATES.get("material_batch_performance", "SELECT 1")
            state, result = await self.execute_tool(
                state, "sql_tool.execute_query",
                self.sql_tool.execute_query,
                sql=sql, parameters=parameters
            )
        
        elif query_type == "timeline_events":
            sql = QUERY_TEMPLATES.get("recent_events", "SELECT 1")
            state, result = await self.execute_tool(
                state, "sql_tool.execute_query",
                self.sql_tool.execute_query,
                sql=sql, parameters=parameters
            )
        
        return state


# Singleton instance
data_agent = DataAgent()
