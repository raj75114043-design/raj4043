"""
RCA Agent
==========
File: app/v1/agents/rca_agent.py

Role: Identify root causes using Tiered RCA and correlate with evidence from other agents.

Foundation Layer Access:
- Tiered RCA (Tier 1): Curated root cause plans for common symptoms
- Tiered RCA (Tier 2): RAG search over historical cases
- Tiered RCA (Tier 3): Agentic investigation for novel causes

Can Request: Data Agent for evidence to validate hypothesized cause
Can Request: Analyst to check correlation between cause and symptom
Outputs To: Shared state (root_causes) + Recommender
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import logging

from ..config import AgentType, COMMON_ROOT_CAUSES
from ..models import (
    AgentState, AgentStatus, RootCause, ValidationStatus
)
from ..foundation_layer import tiered_rca
from .base_agent import BaseAgent

logger = logging.getLogger(__name__)


class RCAAgent(BaseAgent):
    """
    RCA Agent - Identifies root causes using the Tiered RCA system.
    
    Tools:
    - lookup_curated(symptom): Search Tier 1 curated plans
    - search_historical(symptom): RAG search over historical cases (Tier 2)
    - investigate(symptom, evidence): Agentic investigation for novel causes (Tier 3)
    - validate_cause(cause, evidence): Check if evidence supports the proposed cause
    """
    
    def __init__(self):
        super().__init__(AgentType.RCA_AGENT)
        self.tiered_rca = tiered_rca
    
    async def process(self, state: AgentState) -> AgentState:
        """
        Identify root causes for the problem.
        
        Steps:
        1. Extract symptom from query and findings
        2. Check Tier 1 curated plans
        3. If no match, search Tier 2 historical cases
        4. If low confidence, perform Tier 3 agentic investigation
        5. Validate causes against evidence
        6. Store validated root causes
        """
        logger.info(f"[RCAAgent] Starting root cause analysis")
        state.current_agent = self.name
        
        # Extract symptom
        symptom = self._extract_symptom_from_state(state)
        logger.info(f"[RCAAgent] Extracted symptom: {symptom}")
        
        # Build context from evidence
        context = self._build_context(state)
        
        # Determine if deep investigation is needed
        force_tier = 3 if state.context.get("require_deep_investigation") else None
        
        # Run tiered analysis
        root_causes, tier_used = await self.tiered_rca.analyze(
            symptom=symptom,
            context=context,
            force_tier=force_tier
        )
        
        logger.info(f"[RCAAgent] Found {len(root_causes)} root causes using Tier {tier_used}")
        
        # Validate causes against evidence
        validated_causes = await self._validate_causes(state, root_causes)
        
        # Store results
        state.analysis.root_causes = validated_causes
        state.has_root_cause = len(validated_causes) > 0
        
        # Log the tier used
        state = self.log_message(
            state,
            to_agent="orchestrator",
            action="rca_complete",
            parameters={
                "tier_used": tier_used,
                "causes_found": len(validated_causes)
            }
        )
        
        return state
    
    def _extract_symptom_from_state(self, state: AgentState) -> str:
        """Extract the problem symptom from state"""
        # First check if RCA coverage already extracted it
        if state.plan.rca_coverage and state.plan.rca_coverage.get("symptom_extracted"):
            return state.plan.rca_coverage["symptom_extracted"]
        
        # Extract from findings
        findings = state.analysis.findings
        if findings:
            # Look for significant findings
            significant = [f for f in findings if f.is_significant]
            if significant:
                # Build symptom from top finding
                top_finding = significant[0]
                return top_finding.description
        
        # Fall back to query
        return state.query
    
    def _build_context(self, state: AgentState) -> Dict[str, Any]:
        """Build context from evidence and filters"""
        context = {
            "metrics": [],
            "market": state.filters.get("market"),
            "vendor": state.filters.get("vendor"),
            "time_range": state.filters.get("time_range", {})
        }
        
        # Add metrics from evidence
        if state.evidence.metrics:
            for key, value in state.evidence.metrics.items():
                if "ftr" in key.lower():
                    context["metrics"].append("ftr")
                if "compliance" in key.lower():
                    context["metrics"].append("compliance")
        
        # Add findings context
        for finding in state.analysis.findings:
            if finding.metric_a and finding.metric_a not in context["metrics"]:
                context["metrics"].append(finding.metric_a)
        
        return context
    
    async def _validate_causes(
        self,
        state: AgentState,
        causes: List[RootCause]
    ) -> List[RootCause]:
        """Validate root causes against gathered evidence"""
        validated = []
        
        for cause in causes:
            # Check if evidence supports this cause
            evidence_support = self._check_evidence_support(state, cause)
            
            if evidence_support["supported"]:
                cause.validation_status = ValidationStatus.VALIDATED
                cause.evidence_ids = evidence_support["evidence_ids"]
                cause.confidence = min(cause.confidence * 1.2, 1.0)  # Boost confidence
            else:
                cause.validation_status = ValidationStatus.HYPOTHESIZED
                cause.confidence = cause.confidence * 0.8  # Reduce confidence
            
            # Keep causes with confidence above threshold
            if cause.confidence >= 0.5:
                validated.append(cause)
        
        # Sort by confidence
        validated.sort(key=lambda x: x.confidence, reverse=True)
        
        return validated
    
    def _check_evidence_support(
        self,
        state: AgentState,
        cause: RootCause
    ) -> Dict[str, Any]:
        """Check if evidence supports a root cause"""
        supported = False
        evidence_ids = []
        
        cause_category = cause.category.lower()
        cause_desc = cause.description.lower()
        
        # Check findings for supporting evidence
        for finding in state.analysis.findings:
            finding_desc = finding.description.lower()
            
            # Check for crew/training issues
            if cause_category == "crew_inexperience":
                if "crew" in finding_desc or "training" in finding_desc or "new" in finding_desc:
                    if finding.is_significant:
                        supported = True
                        evidence_ids.append(finding.finding_id)
            
            # Check for material issues
            elif cause_category == "material_batch_issue":
                if "material" in finding_desc or "batch" in finding_desc:
                    if finding.is_significant:
                        supported = True
                        evidence_ids.append(finding.finding_id)
            
            # Check for vendor issues
            elif cause_category == "vendor_underperformance":
                if "vendor" in finding_desc:
                    if finding.is_significant:
                        supported = True
                        evidence_ids.append(finding.finding_id)
            
            # Check for compliance issues
            elif cause_category == "hse_non_compliance":
                if "compliance" in finding_desc or "hse" in finding_desc or "safety" in finding_desc:
                    if finding.is_significant:
                        supported = True
                        evidence_ids.append(finding.finding_id)
            
            # Check for prerequisite issues
            elif cause_category == "prerequisite_delay":
                if "prerequisite" in finding_desc or "blocked" in finding_desc or "ready" in finding_desc:
                    supported = True
                    evidence_ids.append(finding.finding_id)
        
        # Also check raw evidence data
        for evidence in state.evidence.data_tables:
            if cause_category in evidence.description.lower():
                evidence_ids.append(evidence.evidence_id)
                supported = True
        
        return {
            "supported": supported,
            "evidence_ids": evidence_ids
        }
    
    async def request_additional_evidence(
        self,
        state: AgentState,
        cause: RootCause
    ) -> AgentState:
        """Request additional evidence from Data Agent to validate a cause"""
        logger.info(f"[RCAAgent] Requesting additional evidence for: {cause.description}")
        
        # Log request to Data Agent
        state = self.log_message(
            state,
            to_agent="data_agent",
            action="request_evidence",
            parameters={
                "cause_id": cause.cause_id,
                "cause_category": cause.category,
                "required_data": self._get_required_data_for_cause(cause.category)
            }
        )
        
        return state
    
    def _get_required_data_for_cause(self, cause_category: str) -> List[str]:
        """Get required data to validate a cause category"""
        requirements = {
            "crew_inexperience": ["crew_data", "training_dates", "crew_tenure"],
            "material_batch_issue": ["material_batch", "supplier_data", "batch_quality"],
            "vendor_underperformance": ["vendor_detail", "productivity_data", "sla_data"],
            "hse_non_compliance": ["hse_detail", "violation_history", "training_status"],
            "prerequisite_delay": ["prereq_status", "lead_times", "blocker_detail"],
            "site_access_delay": ["access_history", "permission_status", "landlord_data"],
            "integration_backlog": ["ix_queue", "engineer_capacity", "cmg_windows"]
        }
        return requirements.get(cause_category, ["general_data"])


# Singleton instance
rca_agent = RCAAgent()
