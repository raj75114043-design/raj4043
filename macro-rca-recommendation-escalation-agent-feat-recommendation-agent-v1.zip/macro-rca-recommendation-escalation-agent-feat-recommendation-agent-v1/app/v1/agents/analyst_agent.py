"""
Analyst Agent
==============
File: app/v1/agents/analyst_agent.py

Role: Perform statistical analysis on gathered data to identify patterns and validate findings.

Foundation Layer Access:
- Python Sandbox: Execute statistical computations
- KPI Catalog: Thresholds for significance determination

Can Request: Data Agent for more data if analysis inconclusive
Can Request: RCA Agent to validate if finding matches known patterns
Outputs To: Shared state (findings) + Recommender
"""

from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import logging

from ..config import AgentType, settings
from ..models import (
    AgentState, AgentStatus, Finding, Evidence
)
from ..foundation_layer import python_sandbox, kpi_catalog
from .base_agent import BaseAgent

logger = logging.getLogger(__name__)


class AnalystAgent(BaseAgent):
    """
    Analyst Agent - Performs statistical analysis on evidence.
    
    Tools:
    - detect_trend(data, metric): Time series trend analysis
    - compare_groups(a, b, metric): Statistical comparison (t-test, chi-square)
    - correlate(metric_a, metric_b): Correlation analysis
    - find_outliers(data, metric): Outlier detection (IQR, z-score)
    - estimate_impact(action, data): Project impact of proposed action
    """
    
    def __init__(self):
        super().__init__(AgentType.ANALYST)
        self.p_value_threshold = settings.rca.p_value_threshold
        self.min_sample_size = settings.rca.min_sample_size
    
    async def process(self, state: AgentState) -> AgentState:
        """
        Analyze the gathered evidence.
        
        Steps:
        1. Identify analyzable data in evidence
        2. Detect trends in time-series data
        3. Compare groups (vendors, regions, etc.)
        4. Find outliers
        5. Check correlations
        6. Compile findings
        """
        logger.info(f"[Analyst] Analyzing {len(state.evidence.data_tables)} evidence items")
        state.current_agent = self.name
        state.status = AgentStatus.ANALYZING
        
        findings = []
        
        # Analyze each evidence item
        for evidence in state.evidence.data_tables:
            evidence_findings = await self._analyze_evidence(state, evidence)
            findings.extend(evidence_findings)
        
        # Add findings to state
        state.analysis.findings = findings
        
        # Calculate overall confidence
        if findings:
            significant_findings = [f for f in findings if f.is_significant]
            state.analysis.confidence["overall"] = len(significant_findings) / len(findings)
        
        logger.info(f"[Analyst] Generated {len(findings)} findings, {len([f for f in findings if f.is_significant])} significant")
        
        return state
    
    async def _analyze_evidence(self, state: AgentState, evidence: Evidence) -> List[Finding]:
        """Analyze a single evidence item"""
        findings = []
        data = evidence.data
        
        if not data or not isinstance(data, list) or len(data) < 2:
            return findings
        
        # Determine what analysis to perform based on data structure
        first_row = data[0]
        
        # Check for vendor comparison data
        if "vendor" in first_row and "ftr_rate" in first_row:
            vendor_findings = await self._analyze_vendor_performance(state, data)
            findings.extend(vendor_findings)
        
        # Check for time-series data
        if any(k for k in first_row.keys() if "date" in k.lower() or "week" in k.lower()):
            trend_findings = await self._analyze_trends(state, data)
            findings.extend(trend_findings)
        
        # Check for compliance data
        if any(k for k in first_row.keys() if "compliance" in k.lower() or "pass" in k.lower()):
            compliance_findings = await self._analyze_compliance(state, data)
            findings.extend(compliance_findings)
        
        # Check for outliers in numeric columns
        outlier_findings = await self._find_outliers_in_data(state, data)
        findings.extend(outlier_findings)
        
        return findings
    
    async def _analyze_vendor_performance(self, state: AgentState, data: List[Dict]) -> List[Finding]:
        """Analyze vendor performance differences"""
        findings = []
        
        # Get FTR values by vendor
        vendor_ftr = {}
        for row in data:
            vendor = row.get("vendor")
            ftr = row.get("ftr_rate")
            if vendor and ftr is not None:
                if vendor not in vendor_ftr:
                    vendor_ftr[vendor] = []
                vendor_ftr[vendor].append(ftr)
        
        if len(vendor_ftr) < 2:
            return findings
        
        # Calculate averages
        vendor_avgs = {v: sum(rates)/len(rates) for v, rates in vendor_ftr.items() if rates}
        
        # Find best and worst
        if vendor_avgs:
            worst_vendor = min(vendor_avgs.items(), key=lambda x: x[1])
            best_vendor = max(vendor_avgs.items(), key=lambda x: x[1])
            
            if worst_vendor[1] < best_vendor[1] - 5:  # More than 5% difference
                # Perform statistical comparison
                worst_values = vendor_ftr[worst_vendor[0]]
                best_values = vendor_ftr[best_vendor[0]]
                
                if len(worst_values) >= self.min_sample_size and len(best_values) >= self.min_sample_size:
                    state, result = await self.execute_tool(
                        state, "python_sandbox.compare_groups",
                        self.python_sandbox.compare_groups,
                        group_a_values=worst_values,
                        group_b_values=best_values,
                        group_a_label=worst_vendor[0],
                        group_b_label=best_vendor[0],
                        metric_name="FTR Rate"
                    )
                    
                    if result.success and result.result:
                        finding = Finding(
                            finding_id=f"FIND_VENDOR_COMP_{datetime.now().strftime('%H%M%S')}",
                            description=f"Vendor {worst_vendor[0]} has significantly lower FTR ({worst_vendor[1]:.1f}%) vs {best_vendor[0]} ({best_vendor[1]:.1f}%)",
                            metric_a=f"{worst_vendor[0]} FTR",
                            metric_b=f"{best_vendor[0]} FTR",
                            value_a=worst_vendor[1],
                            value_b=best_vendor[1],
                            difference=result.result.get("difference"),
                            p_value=result.result.get("p_value"),
                            sample_size=len(worst_values) + len(best_values),
                            is_significant=result.result.get("is_significant", False),
                            method="t-test"
                        )
                        findings.append(finding)
        
        return findings
    
    async def _analyze_trends(self, state: AgentState, data: List[Dict]) -> List[Finding]:
        """Analyze time-series trends"""
        findings = []
        
        # Find date column
        date_col = None
        for col in data[0].keys():
            if "date" in col.lower() or "week" in col.lower():
                date_col = col
                break
        
        if not date_col:
            return findings
        
        # Find numeric columns to analyze
        numeric_cols = [k for k, v in data[0].items() 
                       if isinstance(v, (int, float)) and k != date_col]
        
        for col in numeric_cols[:3]:  # Analyze top 3 numeric columns
            # Sort by date and extract values
            sorted_data = sorted(data, key=lambda x: str(x.get(date_col, "")))
            values = [row.get(col) for row in sorted_data if row.get(col) is not None]
            
            if len(values) >= 3:
                state, result = await self.execute_tool(
                    state, "python_sandbox.detect_trend",
                    self.python_sandbox.detect_trend,
                    values=values,
                    metric_name=col
                )
                
                if result.success and result.result:
                    trend = result.result.get("trend", "no_trend")
                    if trend in ["increasing", "decreasing"] and result.result.get("is_significant"):
                        finding = Finding(
                            finding_id=f"FIND_TREND_{col}_{datetime.now().strftime('%H%M%S')}",
                            description=f"{col} is {trend} (slope: {result.result.get('slope', 0):.4f})",
                            metric_a=col,
                            value_a=result.result.get("start_value", 0),
                            value_b=result.result.get("end_value", 0),
                            difference=result.result.get("percent_change"),
                            p_value=result.result.get("p_value"),
                            sample_size=len(values),
                            is_significant=result.result.get("is_significant", False),
                            method="linear_regression"
                        )
                        findings.append(finding)
        
        return findings
    
    async def _analyze_compliance(self, state: AgentState, data: List[Dict]) -> List[Finding]:
        """Analyze compliance patterns"""
        findings = []
        
        # Look for compliance rate column
        compliance_col = None
        for col in data[0].keys():
            if "compliance" in col.lower():
                compliance_col = col
                break
        
        if not compliance_col:
            return findings
        
        # Get compliance values
        compliance_values = [row.get(compliance_col) for row in data if row.get(compliance_col) is not None]
        labels = [row.get("vendor") or row.get("region") or f"Item_{i}" for i, row in enumerate(data)]
        
        if len(compliance_values) >= 3:
            # Find outliers (low compliance)
            state, result = await self.execute_tool(
                state, "python_sandbox.find_outliers",
                self.python_sandbox.find_outliers,
                values=compliance_values,
                labels=labels,
                method="iqr",
                metric_name="Compliance Rate"
            )
            
            if result.success and result.result:
                outlier_count = result.result.get("outlier_count", 0)
                if outlier_count > 0:
                    outlier_labels = result.result.get("outlier_labels", [])
                    outlier_values = result.result.get("outlier_values", [])
                    
                    finding = Finding(
                        finding_id=f"FIND_COMPLIANCE_{datetime.now().strftime('%H%M%S')}",
                        description=f"Found {outlier_count} entities with abnormally low compliance: {', '.join(str(l) for l in outlier_labels[:3])}",
                        metric_a="Compliance Rate",
                        value_a=min(outlier_values) if outlier_values else 0,
                        value_b=result.result.get("mean", 0),
                        difference=result.result.get("lower_bound", 0) - min(outlier_values) if outlier_values else 0,
                        sample_size=len(compliance_values),
                        is_significant=True,
                        method="iqr_outlier"
                    )
                    findings.append(finding)
        
        return findings
    
    async def _find_outliers_in_data(self, state: AgentState, data: List[Dict]) -> List[Finding]:
        """Find outliers in numeric columns"""
        findings = []
        
        # Get numeric columns
        numeric_cols = [k for k, v in data[0].items() 
                       if isinstance(v, (int, float))]
        
        for col in numeric_cols[:2]:  # Check top 2 numeric columns
            values = [row.get(col) for row in data if row.get(col) is not None]
            
            # Try to get labels
            label_col = next((c for c in ["vendor", "region", "site_code", "site"] if c in data[0]), None)
            labels = [row.get(label_col, f"Item_{i}") for i, row in enumerate(data)] if label_col else None
            
            if len(values) >= 5:
                state, result = await self.execute_tool(
                    state, "python_sandbox.find_outliers",
                    self.python_sandbox.find_outliers,
                    values=values,
                    labels=labels,
                    method="zscore",
                    metric_name=col
                )
                
                if result.success and result.result:
                    outlier_count = result.result.get("outlier_count", 0)
                    if outlier_count > 0 and outlier_count <= len(values) * 0.2:  # Less than 20% outliers
                        finding = Finding(
                            finding_id=f"FIND_OUTLIER_{col}_{datetime.now().strftime('%H%M%S')}",
                            description=f"Found {outlier_count} outliers in {col}",
                            metric_a=col,
                            value_a=result.result.get("mean", 0),
                            sample_size=len(values),
                            is_significant=True,
                            method="zscore_outlier"
                        )
                        findings.append(finding)
        
        return findings
    
    async def estimate_impact(
        self,
        state: AgentState,
        action: str,
        affected_entities: Dict[str, Any],
        baseline_metric: float
    ) -> Tuple[AgentState, Dict[str, Any]]:
        """
        Estimate the impact of a proposed action.
        Called by Recommender Agent.
        """
        logger.info(f"[Analyst] Estimating impact for action: {action}")
        
        # Get historical impact if available
        state, hist_result = await self.execute_tool(
            state, "feedback_loop.get_historical_impact",
            self.feedback_loop.get_historical_impact,
            action_type=action
        )
        
        historical_improvement = 0
        if hist_result.success and hist_result.result:
            historical_improvement = hist_result.result.get("avg_improvement", 15)
        else:
            # Default estimates by action type
            default_improvements = {
                "crew_retraining": 22,
                "vendor_shift": 15,
                "material_quarantine": 18,
                "process_enforcement": 12,
                "capacity_increase": 20
            }
            historical_improvement = default_improvements.get(action, 15)
        
        affected_count = affected_entities.get("count", 1)
        
        state, result = await self.execute_tool(
            state, "python_sandbox.estimate_impact",
            self.python_sandbox.estimate_impact,
            current_value=baseline_metric,
            improvement_percent=historical_improvement,
            affected_count=affected_count,
            metric_name="FTR Rate"
        )
        
        impact = {}
        if result.success and result.result:
            impact = {
                "projected_improvement": result.result.get("improvement_percent"),
                "affected_count": affected_count,
                "baseline_value": baseline_metric,
                "projected_value": result.result.get("projected_value"),
                "confidence": 0.75 if hist_result.success else 0.5
            }
        
        return state, impact


# Singleton instance
analyst_agent = AnalystAgent()
