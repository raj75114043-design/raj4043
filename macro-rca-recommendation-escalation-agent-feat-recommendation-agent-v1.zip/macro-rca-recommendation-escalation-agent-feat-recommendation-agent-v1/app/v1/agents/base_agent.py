"""
Base Agent Class
=================
File: app/v1/agents/base_agent.py

Base class for all specialized agents in the Multi-Agent System.
Provides common functionality and Foundation Layer access.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
from datetime import datetime
import logging

from ..config import settings, AgentType
from ..models import AgentState, AgentMessage, ToolCall, ToolCallResponse
from ..foundation_layer import sql_tool, python_sandbox, vector_store, feedback_loop, kpi_catalog

logger = logging.getLogger(__name__)


class BaseAgent(ABC):
    """
    Base class for all specialized agents.
    
    All agents have direct access to Foundation Layer tools.
    Agents communicate via shared state (blackboard pattern) and direct requests.
    """
    
    def __init__(self, agent_type: AgentType):
        self.agent_type = agent_type
        self.name = agent_type.value
        
        # Foundation Layer access - all agents have direct access
        self.sql_tool = sql_tool
        self.python_sandbox = python_sandbox
        self.vector_store = vector_store
        self.feedback_loop = feedback_loop
        self.kpi_catalog = kpi_catalog
    
    @abstractmethod
    async def process(self, state: AgentState) -> AgentState:
        """
        Process the current state and return updated state.
        
        Args:
            state: Current agent state (blackboard)
            
        Returns:
            Updated agent state
        """
        pass
    
    def log_message(
        self,
        state: AgentState,
        to_agent: str,
        action: str,
        parameters: Dict[str, Any] = None
    ) -> AgentState:
        """Log a message to another agent"""
        message = AgentMessage(
            from_agent=self.name,
            to_agent=to_agent,
            action=action,
            parameters=parameters or {},
            timestamp=datetime.now()
        )
        state.messages.append(message)
        return state
    
    def log_tool_call(
        self,
        state: AgentState,
        tool_name: str,
        parameters: Dict[str, Any],
        result: Any,
        success: bool,
        error: Optional[str] = None,
        execution_time_ms: float = 0.0
    ) -> AgentState:
        """Log a tool call"""
        tool_call = ToolCall(
            tool_name=tool_name,
            parameters=parameters,
            result=result,
            success=success,
            error=error,
            execution_time_ms=execution_time_ms,
            timestamp=datetime.now()
        )
        state.tool_calls.append(tool_call)
        return state
    
    def log_error(self, state: AgentState, error: str) -> AgentState:
        """Log an error"""
        state.errors.append(f"[{self.name}] {error}")
        logger.error(f"[{self.name}] {error}")
        return state
    
    async def execute_tool(
        self,
        state: AgentState,
        tool_name: str,
        tool_func,
        **kwargs
    ) -> tuple[AgentState, ToolCallResponse]:
        """
        Execute a tool and log the call.
        
        Args:
            state: Current state
            tool_name: Name of the tool
            tool_func: Async function to call
            **kwargs: Arguments for the tool function
            
        Returns:
            Tuple of (updated state, tool response)
        """
        start_time = datetime.now()
        
        try:
            result = await tool_func(**kwargs)
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            
            state = self.log_tool_call(
                state=state,
                tool_name=tool_name,
                parameters=kwargs,
                result=result.result if isinstance(result, ToolCallResponse) else result,
                success=result.success if isinstance(result, ToolCallResponse) else True,
                error=result.error if isinstance(result, ToolCallResponse) else None,
                execution_time_ms=execution_time
            )
            
            return state, result
            
        except Exception as e:
            execution_time = (datetime.now() - start_time).total_seconds() * 1000
            error_msg = str(e)
            
            state = self.log_tool_call(
                state=state,
                tool_name=tool_name,
                parameters=kwargs,
                result=None,
                success=False,
                error=error_msg,
                execution_time_ms=execution_time
            )
            
            state = self.log_error(state, f"Tool {tool_name} failed: {error_msg}")
            
            return state, ToolCallResponse(
                success=False,
                tool_name=tool_name,
                result=None,
                error=error_msg,
                execution_time_ms=execution_time
            )
