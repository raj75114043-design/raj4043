"""
Planner Agent
==============
File: app/v1/agents/planner_agent.py

Role: Decompose complex queries into actionable sub-questions and identify data requirements.

Foundation Layer Access:
- Enriched DB Metadata: Discover available tables, columns, relationships
- KPI Catalog: Understand what metrics exist and their definitions
- Tiered RCA: Check if known root cause patterns exist for the symptom

Can Request Help From: Data Agent (schema discovery)
Outputs To: Shared state (plan) for other agents to execute
"""

from typing import Dict, Any, List, Optional
import logging
import re

from ..config import AgentType, COMMON_ROOT_CAUSES, PREREQUISITES, KPI_CATEGORIES
from ..models import (
    AgentState, AgentStatus, IntentType, 
    SubQuestion, DataRequirement, PlanState
)
from ..foundation_layer import tiered_rca, kpi_catalog
from .base_agent import BaseAgent

logger = logging.getLogger(__name__)


class PlannerAgent(BaseAgent):
    """
    Planner Agent - Decomposes queries and identifies data requirements.
    
    Tools:
    - get_schema(domain): Retrieve relevant table/column metadata
    - get_kpis(category): List available KPIs and their thresholds
    - check_rca_coverage(symptom): Check if Tiered RCA has known causes
    - decompose(query): Break query into sub-questions with dependencies
    """
    
    def __init__(self):
        super().__init__(AgentType.PLANNER)
    
    async def process(self, state: AgentState) -> AgentState:
        """
        Process the query and create an execution plan.
        
        Steps:
        1. Classify intent
        2. Check RCA coverage (Tier 1)
        3. Identify relevant domains/tables
        4. Decompose into sub-questions
        5. Identify data requirements
        """
        logger.info(f"[Planner] Processing query: {state.query}")
        state.current_agent = self.name
        state.status = AgentStatus.PLANNING
        
        # Step 1: Classify intent
        state = self._classify_intent(state)
        logger.info(f"[Planner] Classified intent: {state.intent}")
        
        # Step 2: Check RCA coverage for diagnostic queries
        if IntentType.DIAGNOSTIC in state.intent or IntentType.PRESCRIPTIVE in state.intent:
            state = await self._check_rca_coverage(state)
        
        # Step 3: Identify relevant domains
        domains = self._identify_domains(state.query)
        logger.info(f"[Planner] Identified domains: {domains}")
        
        # Step 4: Decompose query into sub-questions
        state = self._decompose_query(state, domains)
        
        # Step 5: Identify data requirements
        state = self._identify_data_requirements(state, domains)
        
        logger.info(f"[Planner] Created plan with {len(state.plan.sub_questions)} sub-questions and {len(state.plan.data_requirements)} data requirements")
        
        return state
    
    def _classify_intent(self, state: AgentState) -> AgentState:
        """Classify the query intent"""
        query_lower = state.query.lower()
        intents = []
        
        # Diagnostic patterns (Why is X happening?)
        diagnostic_patterns = [
            r"why\s+(is|are|did|does)",
            r"what\s+(is\s+)?caus",
            r"root\s+cause",
            r"reason\s+for",
            r"explain\s+the",
            r"what('s|\s+is)\s+driving",
            r"which\s+.*(highest|lowest|most|worst|best)"
        ]
        
        # Prescriptive patterns (What should we do?)
        prescriptive_patterns = [
            r"what\s+should",
            r"how\s+(can|do|should)\s+we",
            r"recommend",
            r"action\s+plan",
            r"how\s+to\s+(fix|solve|improve|reduce)",
            r"what\s+action"
        ]
        
        # Predictive patterns (What will happen if?)
        predictive_patterns = [
            r"what\s+(will|would)\s+happen",
            r"if\s+we\s+(add|remove|change|reduce|increase)",
            r"impact\s+(of|if)",
            r"simulate",
            r"forecast",
            r"predict"
        ]
        
        # Informational patterns (Show me / Tell me)
        informational_patterns = [
            r"^(show|tell|list|give|get|what\s+is\s+the|how\s+many)",
            r"status\s+of",
            r"current\s+state",
            r"summary\s+of"
        ]
        
        for pattern in diagnostic_patterns:
            if re.search(pattern, query_lower):
                intents.append(IntentType.DIAGNOSTIC)
                break
        
        for pattern in prescriptive_patterns:
            if re.search(pattern, query_lower):
                intents.append(IntentType.PRESCRIPTIVE)
                break
        
        for pattern in predictive_patterns:
            if re.search(pattern, query_lower):
                intents.append(IntentType.PREDICTIVE)
                break
        
        for pattern in informational_patterns:
            if re.search(pattern, query_lower):
                intents.append(IntentType.INFORMATIONAL)
                break
        
        # Default to informational if no match
        if not intents:
            intents.append(IntentType.INFORMATIONAL)
        
        state.intent = list(set(intents))
        return state
    
    async def _check_rca_coverage(self, state: AgentState) -> AgentState:
        """Check if Tier 1 curated plans cover this symptom"""
        # Extract symptom from query
        symptom = self._extract_symptom(state.query)
        
        # Search for matching plans
        result = await self.vector_store.search_rca_plans(
            problem_description=symptom,
            threshold=0.85  # Lower threshold for planning phase
        )
        
        if result.success and result.result:
            state.plan.rca_coverage = {
                "has_coverage": True,
                "matching_plans": result.result[:3],  # Top 3 matches
                "symptom_extracted": symptom
            }
            logger.info(f"[Planner] Found RCA coverage for symptom: {symptom}")
        else:
            state.plan.rca_coverage = {
                "has_coverage": False,
                "symptom_extracted": symptom
            }
        
        state = self.log_tool_call(
            state, "vector_store.search_rca_plans",
            {"symptom": symptom},
            result.result, result.success, result.error,
            result.execution_time_ms
        )
        
        return state
    
    def _extract_symptom(self, query: str) -> str:
        """Extract the problem/symptom from the query"""
        query_lower = query.lower()
        
        # Pattern: "Why is X declining/dropping/failing"
        match = re.search(r"why\s+(?:is|are)\s+(.+?)(?:\s+in\s+|\s+for\s+|\?|$)", query_lower)
        if match:
            return match.group(1).strip()
        
        # Pattern: "What is causing X"
        match = re.search(r"what\s+(?:is\s+)?caus(?:ing|e)\s+(.+?)(?:\?|$)", query_lower)
        if match:
            return match.group(1).strip()
        
        # Pattern: "Which regions/vendors have highest X"
        match = re.search(r"which\s+\w+\s+(?:have|has|show)\s+(?:the\s+)?(?:highest|most|worst)\s+(.+?)(?:\?|$)", query_lower)
        if match:
            return match.group(1).strip()
        
        # Default: return first 100 chars
        return query[:100]
    
    def _identify_domains(self, query: str) -> List[str]:
        """Identify relevant business domains from the query"""
        query_lower = query.lower()
        domains = []
        
        # Domain keywords mapping
        domain_keywords = {
            "quality": ["ftr", "first time right", "quality", "rework", "defect", "ncr", "qc", "pass rate"],
            "schedule": ["delay", "sla", "completion", "timeline", "schedule", "milestone", "lead time"],
            "compliance": ["hse", "safety", "compliance", "check-in", "ppe", "jsa", "violation"],
            "vendor": ["vendor", "gc", "contractor", "crew", "performance"],
            "material": ["material", "bom", "delivery", "inventory", "shortage"],
            "prerequisite": ["prerequisite", "power", "fiber", "ntp", "readiness", "blocked"],
            "integration": ["integration", "on-air", "ix", "cmg", "backlog"]
        }
        
        for domain, keywords in domain_keywords.items():
            for keyword in keywords:
                if keyword in query_lower:
                    domains.append(domain)
                    break
        
        # Default domains if none found
        if not domains:
            domains = ["general"]
        
        return list(set(domains))
    
    def _decompose_query(self, state: AgentState, domains: List[str]) -> AgentState:
        """Decompose the query into sub-questions"""
        sub_questions = []
        query_lower = state.query.lower()
        
        # Generate sub-questions based on intent and domain
        if IntentType.DIAGNOSTIC in state.intent:
            # Diagnostic sub-questions
            sub_questions.append(SubQuestion(
                question_id="Q1",
                question="What is the current state/trend of the metric?",
                data_requirements=["metric_current_value", "metric_trend"],
                priority=1
            ))
            sub_questions.append(SubQuestion(
                question_id="Q2",
                question="Which entities (vendors/regions/sites) are most affected?",
                data_requirements=["entity_breakdown"],
                dependencies=["Q1"],
                priority=2
            ))
            sub_questions.append(SubQuestion(
                question_id="Q3",
                question="What changed recently that correlates with the issue?",
                data_requirements=["recent_events", "correlation_analysis"],
                dependencies=["Q1", "Q2"],
                priority=3
            ))
        
        if IntentType.PRESCRIPTIVE in state.intent:
            # Prescriptive sub-questions
            sub_questions.append(SubQuestion(
                question_id="Q4",
                question="What are the validated root causes?",
                data_requirements=["root_causes"],
                dependencies=["Q1", "Q2", "Q3"] if IntentType.DIAGNOSTIC in state.intent else [],
                priority=4
            ))
            sub_questions.append(SubQuestion(
                question_id="Q5",
                question="What actions can address each root cause?",
                data_requirements=["action_mapping"],
                dependencies=["Q4"],
                priority=5
            ))
            sub_questions.append(SubQuestion(
                question_id="Q6",
                question="What is the expected impact of each action?",
                data_requirements=["impact_estimation", "historical_impact"],
                dependencies=["Q5"],
                priority=6
            ))
        
        # Domain-specific sub-questions
        if "quality" in domains:
            sub_questions.append(SubQuestion(
                question_id="Q_QUAL",
                question="What is the FTR breakdown by vendor and region?",
                data_requirements=["ftr_by_vendor", "ftr_by_region"],
                priority=2
            ))
        
        if "compliance" in domains:
            sub_questions.append(SubQuestion(
                question_id="Q_HSE",
                question="What is the HSE compliance breakdown (check-in, PPE, JSA)?",
                data_requirements=["hse_compliance_detail"],
                priority=2
            ))
        
        if "schedule" in domains:
            sub_questions.append(SubQuestion(
                question_id="Q_SCHED",
                question="Which milestones have the highest slippage?",
                data_requirements=["milestone_slippage"],
                priority=2
            ))
        
        state.plan.sub_questions = sub_questions
        return state
    
    def _identify_data_requirements(self, state: AgentState, domains: List[str]) -> AgentState:
        """Identify specific data requirements"""
        data_requirements = []
        context = state.context or {}
        filters = state.filters or {}
        
        # Market filter
        market = filters.get("market")
        vendor = filters.get("vendor")
        time_range = filters.get("time_range", {})
        
        # Core data requirements
        data_requirements.append(DataRequirement(
            requirement_id="D1",
            description="Site status summary (completed, WIP, pending)",
            source="SQL",
            sql_template="site_status_by_market",
            parameters={"market": market}
        ))
        
        if "quality" in domains or "vendor" in domains:
            data_requirements.append(DataRequirement(
                requirement_id="D2",
                description="Vendor performance metrics (FTR, productivity)",
                source="SQL",
                sql_template="vendor_performance",
                parameters={
                    "market": market,
                    "vendor": vendor,
                    "start_date": time_range.get("start"),
                    "end_date": time_range.get("end")
                }
            ))
        
        if "compliance" in domains:
            data_requirements.append(DataRequirement(
                requirement_id="D3",
                description="HSE compliance breakdown",
                source="SQL",
                sql_template="hse_compliance_summary",
                parameters={"market": market, "start_date": time_range.get("start")}
            ))
        
        if "prerequisite" in domains:
            data_requirements.append(DataRequirement(
                requirement_id="D4",
                description="Prerequisite status and lead times",
                source="SQL",
                sql_template="prerequisite_status",
                parameters={"market": market}
            ))
        
        if "schedule" in domains:
            data_requirements.append(DataRequirement(
                requirement_id="D5",
                description="SLA breaches (Civil and RAN)",
                source="SQL",
                sql_template="civil_sla_breaches",
                parameters={"market": market, "start_date": time_range.get("start")}
            ))
        
        # Always include recent events for diagnostic queries
        if IntentType.DIAGNOSTIC in state.intent:
            data_requirements.append(DataRequirement(
                requirement_id="D_EVENTS",
                description="Recent operational events and changes",
                source="SQL",
                sql_template="recent_events",
                parameters={"market": market, "limit": 20}
            ))
        
        state.plan.data_requirements = data_requirements
        return state


# Singleton instance
planner_agent = PlannerAgent()
