# Nokia Macro RCA + Recommender Agent

A FastAPI service that runs a **multi-agent Root Cause Analysis (RCA) + Recommender** workflow for the Nokia Macro (MACRO) program. The orchestration is implemented with **LangGraph** and the agents use a shared “foundation layer” (SQL / vector search / Python sandbox / domain catalogs).

This repository is the **agent service**. It expects a separate “Unified Layer” service for data, metadata, and vector search.

## Table of Contents

- [Architecture Overview](#architecture-overview)
- [Project Structure](#project-structure)
- [Agents](#agents)
- [Foundation Layer](#foundation-layer)
- [Getting Started](#getting-started)
- [Development](#development)
- [API Endpoints](#api-endpoints)
- [Example Queries](#example-queries)
- [Configuration](#configuration)
- [Unified Layer Contract](#unified-layer-contract)
- [Troubleshooting](#troubleshooting)

---

## Architecture Overview

This system implements a **Multi-Agent System (MAS)** architecture with:

1. **Foundation Layer** - Shared knowledge and tools
2. **Execution Layer** - 5 specialized agents
3. **Orchestration Layer** - LangGraph-based coordination

```
┌─────────────────────────────────────────────────────────────────┐
│                      ORCHESTRATION LAYER                         │
│                    (LangGraph StateGraph)                        │
│                                                                  │
│   ┌─────────┐    ┌─────────┐    ┌─────────┐    ┌───────────┐   │
│   │ Planner │ →  │  Data   │ →  │ Analyst │ →  │ RCA Agent │   │
│   │  Agent  │    │  Agent  │    │  Agent  │    │           │   │
│   └─────────┘    └─────────┘    └─────────┘    └─────┬─────┘   │
│                                                       ↓         │
│                                               ┌─────────────┐   │
│                                               │ Recommender │   │
│                                               │    Agent    │   │
│                                               └─────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                                ↓
┌─────────────────────────────────────────────────────────────────┐
│                      FOUNDATION LAYER                            │
│                                                                  │
│   ┌─────────────────────┐    ┌───────────────────────────────┐  │
│   │  Knowledge Registries│    │       Shared Tools            │  │
│   │  ├─ Tiered RCA      │    │  ├─ SQL Tool                  │  │
│   │  ├─ KPI Catalog     │    │  ├─ Python Sandbox            │  │
│   │  └─ Enriched Metadata│    │  ├─ Vector Store             │  │
│   └─────────────────────┘    │  └─ Feedback Loop             │  │
│                              └───────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

### Tiered RCA System

| Tier | Name | Response Time | Method |
|------|------|---------------|--------|
| 1 | Instant Lookup | < 2 seconds | Curated plans (similarity > 0.92) |
| 2 | Fast Synthesis | 5-10 seconds | RAG over historical cases |
| 3 | Deep Investigation | 30-60 seconds | Agentic investigation |

---

## Project Structure

```
rca_recommendor_agent/
├── app/
│   └── v1/
│       ├── agents/                    # Specialized Agents
│       │   ├── __init__.py
│       │   ├── base_agent.py          # Base class with Foundation Layer access
│       │   ├── planner_agent.py       # Query decomposition
│       │   ├── data_agent.py          # Data fetching
│       │   ├── analyst_agent.py       # Statistical analysis
│       │   ├── rca_agent.py           # Root cause identification
│       │   └── recommender_agent.py   # Action recommendations
│       │
│       ├── foundation_layer/          # Foundation Layer
│       │   ├── __init__.py
│       │   ├── knowledge_registries/  # Domain knowledge
│       │   │   ├── __init__.py
│       │   │   ├── tiered_rca.py      # 3-tier RCA system
│       │   │   └── kpi_catalog.py     # KPI definitions
│       │   │
│       │   └── shared_tools/          # Shared execution tools
│       │       ├── __init__.py
│       │       ├── sql_tool.py        # SQL execution
│       │       ├── python_sandbox.py  # Statistical computations
│       │       ├── vector_store.py    # Semantic search
│       │       └── feedback_loop.py   # Learning loop
│       │
│       ├── orchestration/             # LangGraph Orchestration
│       │   ├── __init__.py
│       │   └── graph.py               # StateGraph definition
│       │
│       ├── models/                    # Pydantic Models
│       │   ├── __init__.py
│       │   └── schemas.py             # All data models
│       │
│       ├── config/                    # Configuration
│       │   ├── __init__.py
│       │   └── settings.py            # Settings & constants
│       │
│       ├── api/                       # API Layer
│       │   ├── __init__.py
│       │   └── routes.py              # FastAPI routes
│       │
│       ├── __init__.py
│       └── main.py                    # FastAPI application
│
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
└── README.md
```

---

## Agents

### 1. Planner Agent (`app/v1/agents/planner_agent.py`)

**Role**: Decompose complex queries into actionable sub-questions.

**Capabilities**:
- Intent classification (diagnostic, prescriptive, predictive, informational)
- Domain identification (quality, schedule, compliance, vendor, etc.)
- Query decomposition into sub-questions
- Data requirement identification
- Check RCA coverage (Tier 1 plans)

### 2. Data Agent (`app/v1/agents/data_agent.py`)

**Role**: Fetch data from all available sources.

**Capabilities**:
- Execute SQL queries via Unified Layer
- Fetch pre-aggregated derived tables
- Retrieve KPI values
- Extract key metrics from results

### 3. Analyst Agent (`app/v1/agents/analyst_agent.py`)

**Role**: Perform statistical analysis on gathered data.

**Capabilities**:
- Trend detection (linear regression)
- Group comparison (t-test)
- Outlier detection (IQR, z-score)
- Correlation analysis
- Impact estimation

### 4. RCA Agent (`app/v1/agents/rca_agent.py`)

**Role**: Identify root causes using the Tiered RCA system.

**Capabilities**:
- Tier 1: Curated plan lookup
- Tier 2: Historical case RAG search
- Tier 3: Agentic investigation
- Evidence-based validation

### 5. Recommender Agent (`app/v1/agents/recommender_agent.py`)

**Role**: Generate actionable recommendations with quantified impact.

**Capabilities**:
- Root cause to action mapping
- Impact quantification (sites recovered, cost savings)
- Priority ranking (impact × feasibility)
- Historical impact lookup
- Insight generation

---

## Foundation Layer

### Knowledge Registries

| Registry | Purpose |
|----------|---------|
| **Tiered RCA** | 3-tier root cause analysis system |
| **KPI Catalog** | Metric definitions, formulas, thresholds |
| **Enriched Metadata** | Schema context for SQL generation |

### Shared Tools

| Tool | Purpose |
|------|---------|
| **SQL Tool** | Query execution via Unified Layer |
| **Python Sandbox** | Statistical computations (LLM never does math) |
| **Vector Store** | Semantic search (plans, cases, questions) |
| **Feedback Loop** | Continuous improvement, pattern promotion |

---

## Getting Started

### What Works Today

- The service starts and exposes the API endpoints.
- Agent logic is currently **heuristic / rule-based** (no direct LLM calls are wired in this repo yet).
- Most “real” behavior depends on having a working Unified Layer backing the tool calls (SQL, metadata, vector search, KPI endpoints).

### Prerequisites

- Python 3.11+
- Docker (optional)
- A Unified Layer service running (or the docker-compose placeholder for smoke tests)

### Installation

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# or
.\venv\Scripts\activate  # Windows

# Install dependencies
pip install -r requirements.txt
```

### Running Locally

```bash
# Set environment variables
export UNIFIED_LAYER_URL=http://localhost:8000/api/v1
export LOG_LEVEL=INFO

# Run the application
uvicorn app.v1.main:app --reload --port 8001
```

### Running with Docker

```bash
# Build and run
docker-compose up --build

# Or just the agent container (expects Unified Layer to be reachable)
docker build -t nokia-macro-rca-agent .
docker run -p 8001:8001 nokia-macro-rca-agent
```

### Access the API

- **Swagger UI**: http://localhost:8001/docs
- **ReDoc**: http://localhost:8001/redoc
- **Health Check**: http://localhost:8001/api/v1/rca/health

---

## Development

### Run Tests

```bash
pytest -q
```

### Notes on the Database Layer

The repo contains `app/v1/db/`, `app/v1/repositories/`, and `app/v1/services/` modules intended for persistence. They are not currently part of the FastAPI request path and may require additional dependencies/configuration (for example SQLAlchemy and a database URL) before they can be used.

---

## API Endpoints

### Main Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/rca/analyze` | Run full RCA + Recommender analysis |
| POST | `/api/v1/rca/analyze/stream` | Streaming analysis with SSE updates |
| POST | `/api/v1/rca/feedback` | Submit feedback on insights |
| GET | `/api/v1/rca/health` | Health check |

### Quick Analysis Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/rca/quick/vendor-performance` | Quick vendor FTR analysis |
| GET | `/api/v1/rca/quick/hse-compliance` | Quick HSE compliance analysis |
| GET | `/api/v1/rca/quick/sla-breaches` | Quick SLA breach analysis |

---

## Example Queries

Note: `time_range` values are examples. Use the date range relevant to your investigation.

### Diagnostic Query
```json
{
  "query": "Why is FTR declining for vendor Nettxio in Chicago market?",
  "filters": {
    "market": "Chicago",
    "vendor": "Nettxio"
  },
  "time_range": {
    "start": "2025-01-01",
    "end": "2025-02-21"
  }
}
```

### Prescriptive Query
```json
{
  "query": "Which vendors have the worst performance and what actions should we take?",
  "filters": {
    "market": "Northeast"
  },
  "max_iterations": 3
}
```

### Deep Investigation
```json
{
  "query": "What is causing the integration backlog in Pacific region?",
  "require_deep_investigation": true,
  "filters": {
    "market": "Pacific"
  }
}
```

### Example Response

```json
{
  "success": true,
  "query": "Why is FTR declining for vendor Nettxio?",
  "evidence_summary": "Gathered 5 data sources. Average FTR: 82.3%. Found 3 significant patterns.",
  "root_causes": [
    {
      "cause_id": "RC_T3_CREW_INEXPERIENCE",
      "description": "New crews (<30 days) have 12.5% lower FTR than experienced crews",
      "confidence": 0.85,
      "tier": 3,
      "validation_status": "validated",
      "category": "crew_inexperience"
    }
  ],
  "recommendations": [
    {
      "recommendation_id": "REC_A1B2C3D4",
      "action": "Schedule refresher training for affected crews",
      "priority": "high",
      "impact": {
        "sites_affected": 45,
        "estimated_improvement": 22,
        "estimated_cost_savings": 14850
      },
      "feasibility": "high",
      "owner": "GC Manager",
      "timeline": "1-2 weeks"
    }
  ],
  "total_time_seconds": 8.45,
  "iterations_used": 1
}
```

---

## Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `UNIFIED_LAYER_URL` | `http://localhost:8000/api/v1` | Unified Layer base URL |
| `LOG_LEVEL` | `INFO` | Logging level |

### Key Settings (`app/v1/config/settings.py`)

- The settings module defines defaults for RCA thresholds, guardrails, KPI thresholds, and integration points (Unified Layer base URL).
- `LLMConfig` exists in `app/v1/config/settings.py`, but this repo does not currently wire an LLM client into the agent execution.

---

## Unified Layer Contract

This service calls the Unified Layer over HTTP. The docker-compose file includes a minimal placeholder Unified Layer for smoke testing, but a real deployment should implement (at minimum):

- `POST /api/v1/sql/execute` (used by `app/v1/foundation_layer/shared_tools/sql_tool.py`)
- `GET /api/v1/metadata/schema` (used by `app/v1/foundation_layer/shared_tools/sql_tool.py`)
- `POST /api/v1/vector/search/rca_plans` (used by `app/v1/foundation_layer/shared_tools/vector_store.py`)
- `POST /api/v1/vector/search/historical_cases` (used by `app/v1/foundation_layer/shared_tools/vector_store.py`)

Additional endpoints referenced by the tools may also be required depending on which agents/features you enable (KPI value, derived tables, metadata search, question bank, adding cases/plans).

---

## Troubleshooting

### `httpx` connection errors to Unified Layer

- Confirm `UNIFIED_LAYER_URL` points to the Unified Layer base path (example: `http://localhost:8000/api/v1`).
- If using `docker-compose`, the agent container is configured to reach Unified Layer at `http://unified-layer:8000/api/v1`.

### “Successful” responses but empty evidence/root causes

- The `docker-compose.yml` Unified Layer is a placeholder that returns empty results.
- To get meaningful RCA output, run the agent against a real Unified Layer implementation backed by your data sources and vector store.

---

## MACRO Project Domain

### Project Tracks

| Track | Description |
|-------|-------------|
| **TMO RPM** | Telecom Rollout Project Management |
| **NAS** | Network Activation Services |
| **DEC** | Delivery Excellence & Compliance |

### Workflow Phases

1. Site Assignment & GC Assignment
2. Pre-NTP Validation & Survey
3. Scoping, NTP & Material
4. Pre-Construction & Construction
5. Quality & Compliance
6. Integration
7. Acceptance & Payment

### Common Root Causes

- Crew inexperience (new crews < 30 days)
- Material batch issues
- Vendor underperformance
- Site access delays
- Prerequisite delays (power, fiber, NTP)
- HSE non-compliance
- Integration backlog

---

## Learning Loop

The system continuously improves through the Feedback Loop:

1. **PM Positive Feedback (👍)** → Extract pattern → Add to Historical Cases (Tier 2)
2. **Pattern fires 3+ times** → Promote to Curated Plans (Tier 1)
3. **PM Negative Feedback (👎)** → Log for review, adjust thresholds
4. **PM Correction** → Store for future training

---

## License

Proprietary - Nokia/T-Mobile Project

---

## Authors

Built for Nokia Macro Project - RCA + Recommender Agent System
