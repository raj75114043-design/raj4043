"""
Pydantic schemas for semantic tables with vector embeddings
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

from datetime import datetime
from typing import List, Optional
from pydantic import BaseModel, Field, ConfigDict
from app.models.semantic_models import SemanticRCATypeEnum


# ==================== Semantic KPI Schemas ====================

class SemanticKPIBase(BaseModel):
    """Base Semantic KPI schema"""
    kpi_name: str = Field(..., min_length=1, max_length=255, description="KPI name")
    description: Optional[str] = Field(None, description="KPI description")
    formula: Optional[str] = Field(None, description="KPI calculation formula")
    mapped_tables_columns: Optional[str] = Field(None, description="Mapped database tables and columns")
    logic: Optional[str] = Field(None, description="Business logic description")
    root_cause_positive: Optional[str] = Field(None, description="Root causes for positive trend")
    root_cause_negative: Optional[str] = Field(None, description="Root causes for negative trend")


class SemanticKPICreate(SemanticKPIBase):
    """Schema for creating a semantic KPI (embedding generated automatically)"""
    pass


class SemanticKPIUpdate(BaseModel):
    """Schema for updating a semantic KPI"""
    kpi_name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    formula: Optional[str] = None
    mapped_tables_columns: Optional[str] = None
    logic: Optional[str] = None
    root_cause_positive: Optional[str] = None
    root_cause_negative: Optional[str] = None


class SemanticKPIResponse(SemanticKPIBase):
    """Schema for Semantic KPI response"""
    model_config = ConfigDict(from_attributes=True)

    kpi_id: int
    created_at: datetime
    updated_at: datetime


# ==================== Semantic Question Bank Schemas ====================

class SemanticQuestionBankBase(BaseModel):
    """Base Semantic Question Bank schema"""
    question: str = Field(..., min_length=1, description="Question text")
    sql: str = Field(..., min_length=1, description="Corresponding SQL query")


class SemanticQuestionBankCreate(SemanticQuestionBankBase):
    """Schema for creating a semantic question"""
    pass


class SemanticQuestionBankUpdate(BaseModel):
    """Schema for updating a semantic question"""
    question: Optional[str] = Field(None, min_length=1)
    sql: Optional[str] = Field(None, min_length=1)


class SemanticQuestionBankResponse(SemanticQuestionBankBase):
    """Schema for Semantic Question Bank response"""
    model_config = ConfigDict(from_attributes=True)

    question_id: int
    created_at: datetime
    updated_at: datetime


# ==================== Semantic RCA Schemas ====================

class SemanticRCABase(BaseModel):
    """Base Semantic RCA schema"""
    rca_question: str = Field(..., min_length=1, description="RCA question")
    type_of_rca_question: SemanticRCATypeEnum = Field(..., description="Type of RCA question")
    root_causes: Optional[List[str]] = Field(None, description="List of root causes")
    root_cause_sudo_sql_schema: Optional[str] = Field(None, description="Pseudo SQL schema")
    relevant_kpis: Optional[str] = Field(None, description="Relevant KPIs")
    steps_to_get_data_sql: Optional[List[str]] = Field(None, description="Steps to retrieve data in SQL")
    recommendation_area: Optional[str] = Field(None, description="Area for recommendations")
    output_preferred_template: Optional[str] = Field(None, description="Preferred output template")


class SemanticRCACreate(SemanticRCABase):
    """Schema for creating a semantic RCA"""
    pass


class SemanticRCAUpdate(BaseModel):
    """Schema for updating a semantic RCA"""
    rca_question: Optional[str] = Field(None, min_length=1)
    type_of_rca_question: Optional[SemanticRCATypeEnum] = None
    root_causes: Optional[List[str]] = None
    root_cause_sudo_sql_schema: Optional[str] = None
    relevant_kpis: Optional[str] = None
    steps_to_get_data_sql: Optional[List[str]] = None
    recommendation_area: Optional[str] = None
    output_preferred_template: Optional[str] = None


class SemanticRCAResponse(SemanticRCABase):
    """Schema for Semantic RCA response"""
    model_config = ConfigDict(from_attributes=True)

    problem_id: int
    created_at: datetime
    updated_at: datetime


# ==================== Semantic Simulation Schemas ====================

class SemanticSimulationBase(BaseModel):
    """Base Semantic Simulation schema"""
    scenario: str = Field(..., min_length=1, max_length=500, description="Simulation scenario")
    data_phase_steps: Optional[List[str]] = Field(None, description="Data phase steps")
    data_phase_questions: Optional[List[str]] = Field(None, description="Data phase questions")
    calculation_phase_steps: Optional[List[str]] = Field(None, description="Calculation phase steps")
    simulator_phase_steps: Optional[List[str]] = Field(None, description="Simulator phase steps")
    simulation_methodology: Optional[str] = Field(None, description="Simulation methodology")


class SemanticSimulationCreate(SemanticSimulationBase):
    """Schema for creating a semantic simulation"""
    pass


class SemanticSimulationUpdate(BaseModel):
    """Schema for updating a semantic simulation"""
    scenario: Optional[str] = Field(None, min_length=1, max_length=500)
    data_phase_steps: Optional[List[str]] = None
    data_phase_questions: Optional[List[str]] = None
    calculation_phase_steps: Optional[List[str]] = None
    simulator_phase_steps: Optional[List[str]] = None
    simulation_methodology: Optional[str] = None


class SemanticSimulationResponse(SemanticSimulationBase):
    """Schema for Semantic Simulation response"""
    model_config = ConfigDict(from_attributes=True)

    scenario_id: int
    created_at: datetime
    updated_at: datetime

# ==================== Semantic Escalation Schemas ====================
class SemanticEscalationBase(BaseModel):
    """Base schema for Semantic Escalation definitions"""

    escalation_type: str = Field(..., min_length=1, max_length=500, 
        description="Type or category of escalation scenario (e.g., KPI degradation, site delay, integration failure)."
    )
    escalation_description: Optional[List[str]] = Field(None, 
        description="Detailed explanation of the escalation scenario and the context in which it occurs."
    )
    probable_reasons: Optional[List[str]] = Field(None, 
        description="List of potential causes or factors that may lead to this escalation."
    )
    recommended_resolution: Optional[List[str]] = Field(None, 
        description="Suggested steps or actions recommended to resolve or mitigate the escalation."
    )
    expected_agent_output: Optional[List[str]] = Field(None, 
        description="Expected response or output that the AI agent should generate when this escalation is triggered."
    )
    draft_escalation_message_template: Optional[str] = Field(None, 
        description="Template message that can be used to communicate the escalation to stakeholders."
    )
    relevent_kpi_s: Optional[List[str]] = Field(None,
        description="List of KPIs related to or impacted by this escalation scenario."
    )
    vertical: Optional[str] = Field(None,
        description="Business or operational vertical to which this escalation scenario belongs (e.g., Deployment, Operations, Finance)."
    )


class SemanticEscalationCreate(SemanticEscalationBase):
    """Schema used when creating a new semantic escalation"""
    pass


class SemanticEscalationUpdate(BaseModel):
    """Schema used for updating an existing semantic escalation"""

    escalation_type: Optional[str] = Field(None, min_length=1, max_length=500)
    escalation_description: Optional[List[str]] = None
    probable_reasons: Optional[List[str]] = None
    recommended_resolution: Optional[List[str]] = None
    expected_agent_output: Optional[List[str]] = None
    draft_escalation_message_template: Optional[str] = None
    relevent_kpi_s: Optional[List[str]] = None
    vertical: Optional[str] = None


class SemanticEscalationResponse(SemanticEscalationBase):
    """Schema returned in API responses for semantic escalations"""

    model_config = ConfigDict(from_attributes=True)

    scenario_id: int
    created_at: datetime
    updated_at: datetime


# ==================== Semantic Keyword Schemas (Non-Semantic) ====================

class SemanticKeywordBase(BaseModel):
    """Base Keyword schema"""
    keyword_name: str = Field(..., min_length=1, max_length=255, description="Keyword name")
    keyword_description: Optional[str] = Field(None, description="Keyword description")
    mapped_tables_columns: Optional[str] = Field(None, description="Mapped database tables and columns")
    logic: Optional[str] = Field(None, description="Keyword logic")
    synonyms: Optional[str] = Field(None, description="Comma-separated synonyms")


class SemanticKeywordCreate(SemanticKeywordBase):
    """Schema for creating a keyword"""
    pass


class SemanticKeywordUpdate(BaseModel):
    """Schema for updating a keyword"""
    keyword_name: Optional[str] = Field(None, min_length=1, max_length=255)
    keyword_description: Optional[str] = None
    mapped_tables_columns: Optional[str] = None
    logic: Optional[str] = None
    synonyms: Optional[str] = None


class SemanticKeywordResponse(SemanticKeywordBase):
    """Schema for Keyword response"""
    model_config = ConfigDict(from_attributes=True)

    keyword_id: int
    created_at: datetime
    updated_at: datetime


# ==================== Keyword Detection Schemas ====================

class DetectedKeywordDetail(BaseModel):
    """A single detected keyword with full details"""
    keyword_id: int
    keyword_name: str
    keyword_description: Optional[str] = None
    mapped_tables_columns: Optional[str] = None
    logic: Optional[str] = None
    synonyms: Optional[str] = None
    matched_terms: List[str] = Field(..., description="Which keyword name or synonyms were detected in the input")
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class KeywordDetectionResponse(BaseModel):
    """Response schema for keyword detection endpoint"""
    input_sentence: str = Field(..., description="The original input sentence")
    detected_count: int = Field(..., description="Number of keywords detected")
    detected_keywords: List[DetectedKeywordDetail] = Field(..., description="Full details of detected keywords")


# ==================== KPI Detection Schemas ====================

class DetectedKPIDetail(BaseModel):
    """A single detected KPI with full details"""
    kpi_id: int
    kpi_name: str
    description: Optional[str] = None
    formula: Optional[str] = None
    mapped_tables_columns: Optional[str] = None
    logic: Optional[str] = None
    root_cause_positive: Optional[str] = None
    root_cause_negative: Optional[str] = None
    matched_terms: List[str] = Field(..., description="Which KPI name or variations were detected in the input")
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)


class KPIDetectionResponse(BaseModel):
    """Response schema for KPI detection endpoint"""
    input_sentence: str = Field(..., description="The original input sentence")
    detected_count: int = Field(..., description="Number of KPIs detected")
    detected_kpis: List[DetectedKPIDetail] = Field(..., description="Full details of detected KPIs")


# ==================== Semantic Search Schemas ====================

class SemanticSearchRequest(BaseModel):
    """Schema for semantic search request"""
    query: str = Field(..., min_length=1, description="Search query text")
    table: Optional[str] = Field(
        None,
        description="Specific table to search (kpi, question_bank, rca, simulation)"
    )
    top_k: int = Field(default=10, ge=1, le=100, description="Number of results to return")


class SemanticKeywordSearchRequest(BaseModel):
    """Schema for semantic keyword search request (keywords only)"""
    query: str = Field(..., min_length=1, description="Search query text")
    top_k: int = Field(default=10, ge=1, le=100, description="Number of results to return")


class SemanticSearchResult(BaseModel):
    """Schema for a single semantic search result"""
    table: str = Field(..., description="Source table name")
    id: int = Field(..., description="Record ID")
    content: dict = Field(..., description="Record content")
    similarity_score: float = Field(..., description="Cosine similarity score")


class SemanticSearchResponse(BaseModel):
    """Schema for semantic search response"""
    query: str
    total_results: int
    results: List[SemanticSearchResult]


# ==================== Table Initialization Schemas ====================

class TableInitResponse(BaseModel):
    """Schema for table initialization response"""
    success: bool
    message: str
    tables_created: List[str]
    schema_name: str


class ResetTablesResponse(BaseModel):
    """Schema for reset all tables response"""
    success: bool
    message: str
    tables_cleared: List[str] = Field(..., description="Tables that were cleared")
    rows_deleted: dict = Field(..., description="Number of rows deleted per table")


# ==================== Common Response Schemas ====================

class MessageResponse(BaseModel):
    """Generic message response"""
    message: str
    detail: Optional[str] = None


class PaginatedResponse(BaseModel):
    """Paginated response wrapper"""
    total: int
    page: int
    page_size: int
    items: List[dict]


# ==================== Bulk Operation Schemas ====================

class BulkDeleteRequest(BaseModel):
    """Request schema for bulk delete operations"""
    ids: List[int] = Field(..., min_length=1, max_length=100, description="List of IDs to delete (max 100)")


class BulkOperationResponse(BaseModel):
    """Response schema for bulk operations"""
    success_count: int = Field(..., description="Number of successful operations")
    failed_count: int = Field(..., description="Number of failed operations")
    created_ids: Optional[List[int]] = Field(None, description="List of created IDs (for bulk create)")
    deleted_ids: Optional[List[int]] = Field(None, description="List of deleted IDs (for bulk delete)")
    updated_ids: Optional[List[int]] = Field(None, description="List of updated IDs (for bulk update/reembed)")
    errors: Optional[List[dict]] = Field(None, description="List of errors with index/id and error message")


# ==================== Dev Utility Schemas ====================

class SchemaCompareResponse(BaseModel):
    """Response for schema comparison report endpoint"""
    success: bool
    global_report: str = Field(..., description="Global summary markdown report")
    detailed_report: str = Field(..., description="Detailed per-entry markdown report")
    csv_reports: dict = Field(..., description="CSV reports (questions, kpis, keywords, combined)")
    statistics: dict = Field(..., description="Summary statistics of the comparison")


class TableSchemaBuilderResponse(BaseModel):
    """Response for table schema builder endpoint"""
    success: bool
    message: str
    table_schema_map: dict = Field(..., description="The full table-centric schema JSON")
    stored_id: int = Field(..., description="ID of the record stored in PostgreSQL")


class SchemaWorldViewRequest(BaseModel):
    """Request for schema world view endpoint"""
    kpi_names: Optional[List[str]] = Field(None, description="List of KPI names to include")
    question_texts: Optional[List[str]] = Field(None, description="List of question texts to include")
    keyword_names: Optional[List[str]] = Field(None, description="List of keyword names to include")


class SchemaWorldViewResponse(BaseModel):
    """Response for schema world view endpoint"""
    success: bool
    world_view: dict = Field(..., description="Focused SQL schema world view for text-to-SQL")


# ==================== Copilot User Schemas ====================

class CopilotUserBase(BaseModel):
    """Base schema for Copilot User"""
    email: str = Field(..., min_length=1, max_length=255, description="User email address")
    company: Optional[str] = Field(None, max_length=255, description="User's company")
    project_ahloa: bool = Field(False, description="Access to AHLOA project")
    project_nas: bool = Field(False, description="Access to NAS project")
    project_ntm: bool = Field(False, description="Access to NTM project")
    project_rpm: bool = Field(False, description="Access to RPM project")
    substream_dec: bool = Field(False, description="Access to DEC substream")
    substream_rse: bool = Field(False, description="Access to rSE substream")
    substream_hse: bool = Field(False, description="Access to HSE substream")
    workflow_admin: bool = Field(False, description="Workflow admin privilege")


class CopilotUserCreate(CopilotUserBase):
    """Schema for creating a Copilot User"""
    pass


class CopilotUserUpdate(BaseModel):
    """Schema for updating a Copilot User (all fields optional)"""
    email: Optional[str] = Field(None, min_length=1, max_length=255)
    company: Optional[str] = Field(None, max_length=255)
    project_ahloa: Optional[bool] = None
    project_nas: Optional[bool] = None
    project_ntm: Optional[bool] = None
    project_rpm: Optional[bool] = None
    substream_dec: Optional[bool] = None
    substream_rse: Optional[bool] = None
    substream_hse: Optional[bool] = None
    workflow_admin: Optional[bool] = None


class CopilotUserResponse(CopilotUserBase):
    """Schema for Copilot User response"""
    model_config = ConfigDict(from_attributes=True)

    user_id: int
    created_at: datetime
    updated_at: datetime


class CopilotUserAccessResponse(BaseModel):
    """Schema for user access lookup by email"""
    email: str
    company: Optional[str]
    projects: dict = Field(..., description="Project access map")
    substreams: dict = Field(..., description="Substream access map")
    workflow_admin: bool


class UserBulkDeleteRequest(BaseModel):
    """Request schema for bulk delete of users"""
    ids: List[int] = Field(..., min_length=1, max_length=500, description="List of user IDs to delete (max 500)")
