"""
Table Schema Builder Service
=============================
Builds comprehensive table-centric JSON mapping KPIs, Questions, and Keywords
to staging tables/columns with 4-tier column matching. Stores result in PostgreSQL.
"""

import re
import logging
from collections import defaultdict
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.core.config import settings
from app.db.database import async_engine, Base
from app.models.semantic_models import TableSchemaMap
from app.services.dev_shared import (
    SQL_KEYWORDS, NOISE_TOKENS, SYSTEM_COLUMNS,
    STRUCTURED_PATTERN, COL_LIKE, BRACKET_COL, MBT_PREFIX,
    FROM_JOIN_PATTERN, QUALIFIED_COL,
    fetch_staging_schema_async, fetch_column_types_async, load_json_from_semantic_tables,
    map_client_to_staging,
)

logger = logging.getLogger(__name__)

# ── Fuzzy matching config ──

try:
    from rapidfuzz import fuzz
    _USE_RAPIDFUZZ = True
except ImportError:
    import difflib
    _USE_RAPIDFUZZ = False

_FUZZY_THRESHOLD = 80
_DIFFLIB_THRESHOLD = 0.75

NUMERIC_BASE_TYPES = {"integer", "bigint", "smallint", "numeric", "real", "double precision", "money"}
DATE_BASE_TYPES = {"date", "timestamp without time zone", "timestamp with time zone", "time without time zone"}


def _normalize(col):
    return col.lower().replace("_", "").replace(" ", "")


def _fuzzy_score(a, b):
    if _USE_RAPIDFUZZ:
        return fuzz.ratio(a, b)
    else:
        import difflib
        return difflib.SequenceMatcher(None, a, b).ratio()


def _match_column(input_col, column_tables_map, all_columns, normalized_map):
    if input_col in column_tables_map:
        return "exact", input_col, column_tables_map[input_col], 1.0
    for col in all_columns:
        if col.lower() == input_col.lower():
            return "case_insensitive", col, column_tables_map[col], 0.95
    norm = _normalize(input_col)
    if norm in normalized_map:
        matched = normalized_map[norm]
        return "normalized", matched, column_tables_map[matched], 0.90
    best_match, best_score = None, 0
    for col in all_columns:
        score = _fuzzy_score(input_col.lower(), col.lower())
        if score > best_score:
            best_score = score
            best_match = col
    if _USE_RAPIDFUZZ and best_score >= _FUZZY_THRESHOLD:
        return "fuzzy", best_match, column_tables_map[best_match], round(best_score / 100, 3)
    if not _USE_RAPIDFUZZ and best_score >= _DIFFLIB_THRESHOLD:
        return "fuzzy", best_match, column_tables_map[best_match], round(best_score, 3)
    return "unmatched", None, [], 0


# ── Column extraction helpers ──

def _extract_kpi_columns_for_builder(kpi_obj):
    raw = kpi_obj.get("mapped_tables_columns", "").strip()
    table_hints = defaultdict(set)
    columns = set()
    explicit_mappings = {}

    if not raw:
        for field in ["formula", "logic"]:
            text_val = kpi_obj.get(field, "").strip()
            if text_val:
                for regex in [COL_LIKE, BRACKET_COL]:
                    for m in regex.finditer(text_val):
                        token = m.group(1).lower().strip()
                        if '_' in token:
                            columns.add(token)
        columns -= NOISE_TOKENS
        return {"columns": columns, "table_hints": dict(table_hints), "explicit_mappings": {}}

    # Try to parse explicit table-column mappings
    explicit_mappings = _parse_explicit_table_column_mappings(raw)

    if STRUCTURED_PATTERN.search(raw):
        for m in STRUCTURED_PATTERN.finditer(raw):
            tbl = m.group(1).lower().strip()
            cols_raw = m.group(2)
            cols = [c.strip().lower() for c in cols_raw.split(",") if c.strip()]
            cols = [c for c in cols if re.match(r'^[a-z_][a-z0-9_]*$', c)]
            if tbl and cols:
                table_hints[tbl].update(cols)
                columns.update(cols)
        matched_spans = [(m.start(), m.end()) for m in STRUCTURED_PATTERN.finditer(raw)]
        for regex in [COL_LIKE, BRACKET_COL]:
            for m in regex.finditer(raw):
                token = m.group(1).lower().strip()
                in_matched = any(s <= m.start() < e for s, e in matched_spans)
                if not in_matched and '_' in token:
                    columns.add(token)
    else:
        if MBT_PREFIX.search(raw):
            for m in MBT_PREFIX.finditer(raw):
                token = m.group(1).lower().strip()
                if token and token not in {'dump'}:
                    columns.add(token)
        for regex in [COL_LIKE, BRACKET_COL]:
            for m in regex.finditer(raw):
                token = m.group(1).lower().strip()
                if '_' in token:
                    columns.add(token)

    for field in ["formula", "logic"]:
        text_val = kpi_obj.get(field, "").strip()
        if not text_val:
            continue
        for regex in [COL_LIKE, BRACKET_COL]:
            for m in regex.finditer(text_val):
                token = m.group(1).lower().strip()
                if '_' in token:
                    columns.add(token)

    columns -= NOISE_TOKENS
    return {
        "columns": columns,
        "table_hints": dict(table_hints),
        "explicit_mappings": explicit_mappings
    }


def _extract_question_columns_for_builder(question_obj):
    sql = question_obj.get("sql", "")
    if not sql:
        return {"table_refs": {}, "columns": set()}
    tables_in_query = {}
    for m in FROM_JOIN_PATTERN.finditer(sql):
        tbl = m.group(1).lower().strip()
        alias = m.group(2).lower().strip() if m.group(2) else None
        if tbl in SQL_KEYWORDS:
            continue
        tables_in_query[tbl] = alias

    table_columns = {tbl: set() for tbl in tables_in_query}
    for m in QUALIFIED_COL.finditer(sql):
        prefix = m.group(1).lower()
        col = m.group(2).lower()
        for tbl, alias in tables_in_query.items():
            if prefix == tbl or prefix == alias:
                table_columns[tbl].add(col)
                break
    if tables_in_query:
        main_table = list(tables_in_query.keys())[0]
        all_table_refs = set(tables_in_query.keys()) | {a for a in tables_in_query.values() if a}
        for m in re.finditer(r'\b([a-z_][a-z0-9_]*)\b', sql, re.IGNORECASE):
            candidate = m.group(1).lower()
            if candidate in SQL_KEYWORDS or '_' not in candidate or candidate in all_table_refs:
                continue
            table_columns[main_table].add(candidate)

    all_cols = set()
    for cols in table_columns.values():
        all_cols.update(cols)
    return {"table_refs": tables_in_query, "columns": all_cols}


def _parse_explicit_table_column_mappings(mapped_str):
    """
    Parse explicit table(column) mappings from mapped_tables_columns.
    Returns dict with tables as keys and sets of columns as values.
    Format: "table1(col1,col2), table2(col3), ..."
    """
    if not mapped_str:
        return {}

    mappings = {}
    for m in STRUCTURED_PATTERN.finditer(mapped_str):
        tbl = m.group(1).lower().strip()
        cols_raw = m.group(2)
        cols = [c.strip().lower() for c in cols_raw.split(",") if c.strip()]
        cols = [c for c in cols if re.match(r'^[a-z_][a-z0-9_]*$', c)]
        if tbl and cols:
            if tbl not in mappings:
                mappings[tbl] = set()
            mappings[tbl].update(cols)
    return mappings


def _extract_keyword_columns_for_builder(kw_obj):
    raw = kw_obj.get("mapped_tables_columns", "").strip()
    logic = kw_obj.get("logic", "").strip()
    table_hints = defaultdict(set)
    columns = set()
    explicit_mappings = {}

    # Try to parse explicit table-column mappings
    explicit_mappings = _parse_explicit_table_column_mappings(raw)

    # Always extract columns and table hints (for fallback/complementary matching)
    for text_val in [raw, logic]:
        if not text_val:
            continue
        for m in STRUCTURED_PATTERN.finditer(text_val):
            tbl = m.group(1).lower().strip()
            cols_raw = m.group(2)
            cols = [c.strip().lower() for c in cols_raw.split(",") if c.strip()]
            cols = [c for c in cols if re.match(r'^[a-z_][a-z0-9_]*$', c)]
            if tbl and cols:
                table_hints[tbl].update(cols)
                columns.update(cols)
        for regex in [COL_LIKE, BRACKET_COL]:
            for m in regex.finditer(text_val):
                token = m.group(1).lower().strip()
                if '_' in token:
                    columns.add(token)

    columns -= NOISE_TOKENS
    return {
        "columns": columns,
        "table_hints": dict(table_hints),
        "explicit_mappings": explicit_mappings
    }


# ── Resolution helpers ──

def _resolve_target_tables(col, matched_col, matched_tables, table_hints, resolved_hints):
    if not matched_tables:
        return []
    if len(matched_tables) == 1:
        return matched_tables
    for client_tbl, hint_cols in table_hints.items():
        if col in hint_cols or col.lower() in {c.lower() for c in hint_cols}:
            stg_tbl = resolved_hints.get(client_tbl)
            if stg_tbl and stg_tbl in matched_tables:
                return [stg_tbl]
    hinted_stg = set(resolved_hints.values())
    overlap = [t for t in matched_tables if t in hinted_stg]
    if overlap:
        return overlap
    return matched_tables


# ── Column profiling ──

async def _build_column_profiles_async(
    schema: str,
    staging_schema: dict,
    column_types: dict,
) -> dict:
    """
    Profile each column in the staging schema using a dedicated engine connection.
    Uses ONE query per table (aggregating count, distinct, null, min, max, avg for all
    columns in a single SELECT) — avoids per-column round-trips that cause timeouts.
    Returns {table: {col: {data_type, nullable, distinct_count, null_pct, range}}}
    """
    from sqlalchemy import text as _text

    profiles = {}
    async with async_engine.connect() as conn:
        for table_name, columns in staging_schema.items():
            if not columns:
                continue

            tbl_types = column_types.get(table_name, {})
            quoted_table = f'"{schema}"."{table_name}"'

            # Classify columns by type so we know which aggregates to include
            numeric_idx = []   # (index, col)
            date_idx = []      # (index, col)
            for i, col in enumerate(columns):
                col_meta = tbl_types.get(col, {})
                base_type = col_meta.get("data_type", "unknown").split("(")[0].lower()
                if base_type in NUMERIC_BASE_TYPES:
                    numeric_idx.append((i, col))
                elif base_type in DATE_BASE_TYPES:
                    date_idx.append((i, col))

            # Build a single aggregation SELECT for the whole table.
            # Use index-based aliases (_d0, _n0, _min0, etc.) to avoid issues with
            # special characters or long column names in SQL identifiers.
            agg_parts = ["COUNT(*) AS _total_rows"]
            for i, col in enumerate(columns):
                qc = f'"{col}"'
                agg_parts.append(f"COUNT(DISTINCT {qc}) AS _d{i}")
                agg_parts.append(f"SUM(CASE WHEN {qc} IS NULL THEN 1 ELSE 0 END) AS _n{i}")

            for i, col in numeric_idx:
                qc = f'"{col}"'
                agg_parts.append(f"MIN({qc})::numeric AS _min{i}")
                agg_parts.append(f"MAX({qc})::numeric AS _max{i}")
                agg_parts.append(f"ROUND(AVG({qc})::numeric, 4) AS _avg{i}")

            for i, col in date_idx:
                qc = f'"{col}"'
                agg_parts.append(f"MIN({qc})::text AS _min{i}")
                agg_parts.append(f"MAX({qc})::text AS _max{i}")

            try:
                agg_sql = f"SELECT {', '.join(agg_parts)} FROM {quoted_table}"
                agg_result = await conn.execute(_text(agg_sql))
                agg_row = agg_result.mappings().fetchone()
            except Exception as e:
                logger.warning(f"Column profiling failed for {table_name}: {e}")
                continue

            total_rows = agg_row["_total_rows"] or 0
            tbl_profiles = {}

            numeric_set = {i for i, _ in numeric_idx}
            date_set = {i for i, _ in date_idx}

            for i, col in enumerate(columns):
                col_meta = tbl_types.get(col, {})
                data_type = col_meta.get("data_type", "unknown")
                nullable = col_meta.get("nullable", True)

                distinct_count = agg_row.get(f"_d{i}") or 0
                null_count = agg_row.get(f"_n{i}") or 0
                null_pct = round(null_count / total_rows * 100, 1) if total_rows > 0 else 0.0

                profile: dict = {
                    "data_type": data_type,
                    "nullable": nullable,
                    "distinct_count": int(distinct_count),
                    "null_pct": null_pct,
                }

                if i in numeric_set:
                    mn = agg_row.get(f"_min{i}")
                    mx = agg_row.get(f"_max{i}")
                    av = agg_row.get(f"_avg{i}")
                    profile["range"] = {
                        "min": float(mn) if mn is not None else None,
                        "max": float(mx) if mx is not None else None,
                        "avg": float(av) if av is not None else None,
                    }
                elif i in date_set:
                    profile["range"] = {
                        "min": agg_row.get(f"_min{i}"),
                        "max": agg_row.get(f"_max{i}"),
                    }

                tbl_profiles[col] = profile

            profiles[table_name] = tbl_profiles
            logger.debug(f"Profiled {len(columns)} columns in {table_name} ({total_rows} rows)")

    return profiles


# ── Core builder logic ──

def _build_table_schema_map(staging_schema: dict, kpis: list, questions: list, keywords: list, column_profiles: dict | None = None) -> dict:
    """Build the full table-centric schema map JSON."""
    tables = staging_schema
    column_tables_map = defaultdict(list)
    all_columns_set = set()
    for table, cols in tables.items():
        for col in cols:
            if table not in column_tables_map[col]:
                column_tables_map[col].append(table)
            all_columns_set.add(col)
    all_columns = sorted(all_columns_set)
    normalized_map = {_normalize(col): col for col in all_columns}
    column_tables_map = dict(column_tables_map)

    # Process KPIs
    kpi_results = []
    for kpi in kpis:
        kpi_name = kpi.get("kpi_name", "unknown").strip()
        extraction = _extract_kpi_columns_for_builder(kpi)
        extracted_cols = extraction["columns"]
        table_hints = extraction["table_hints"]
        explicit_mappings = extraction.get("explicit_mappings", {})
        resolved_hints = {}
        for client_tbl in table_hints:
            stg_tbl = map_client_to_staging(client_tbl, tables)
            if stg_tbl:
                resolved_hints[client_tbl] = stg_tbl

        tables_matched = defaultdict(list)
        unmatched_cols = []

        # If explicit mappings exist, use them directly
        if explicit_mappings:
            for tbl, cols in explicit_mappings.items():
                for col in cols:
                    # Try to match the column to verify it exists
                    match_type, matched_col, matched_tables_list, confidence = _match_column(
                        col, column_tables_map, all_columns, normalized_map
                    )
                    if match_type == "unmatched":
                        unmatched_cols.append(col)
                    else:
                        detail = {"input": col, "matched_to": matched_col, "match_type": match_type, "confidence": confidence}
                        tables_matched[tbl].append(detail)
        else:
            # Fallback to original matching logic
            for col in extracted_cols:
                match_type, matched_col, matched_tables_list, confidence = _match_column(
                    col, column_tables_map, all_columns, normalized_map
                )
                if match_type == "unmatched":
                    unmatched_cols.append(col)
                    continue
                target_tables = _resolve_target_tables(col, matched_col, matched_tables_list, table_hints, resolved_hints)
                detail = {"input": col, "matched_to": matched_col, "match_type": match_type, "confidence": confidence}
                for t in target_tables:
                    tables_matched[t].append(detail)

        kpi_results.append({
            "kpi_name": kpi_name, "description": kpi.get("description", ""),
            "formula": kpi.get("formula", ""), "logic": kpi.get("logic", ""),
            "tables_matched": dict(tables_matched), "unmatched_columns": unmatched_cols,
        })

    # Process Questions
    question_results = []
    for q in questions:
        question_text = q.get("question", "").strip()
        sql = q.get("sql", "")
        extraction = _extract_question_columns_for_builder(q)
        table_refs = extraction["table_refs"]
        extracted_cols = extraction["columns"]
        resolved_refs = {}
        for client_tbl in table_refs:
            stg_tbl = map_client_to_staging(client_tbl, tables)
            if stg_tbl:
                resolved_refs[client_tbl] = stg_tbl

        tables_matched = defaultdict(list)
        unmatched_cols = []
        for col in extracted_cols:
            match_type, matched_col, matched_tables_list, confidence = _match_column(
                col, column_tables_map, all_columns, normalized_map
            )
            if match_type == "unmatched":
                unmatched_cols.append(col)
                continue
            ref_stg = set(resolved_refs.values())
            if len(matched_tables_list) > 1:
                overlap = [t for t in matched_tables_list if t in ref_stg]
                target = overlap if overlap else matched_tables_list
            else:
                target = matched_tables_list
            detail = {"input": col, "matched_to": matched_col, "match_type": match_type, "confidence": confidence}
            for t in target:
                tables_matched[t].append(detail)

        question_results.append({
            "question": question_text, "sql": sql,
            "tables_matched": dict(tables_matched), "unmatched_columns": unmatched_cols,
        })

    # Process Keywords
    keyword_results = []
    for kw in keywords:
        kw_name = kw.get("keyword_name", "unknown").strip()
        kw_desc = (kw.get("keyword_description ", "") or kw.get("keyword_description", "") or "").strip()
        synonyms = kw.get("synonyms", "").strip()
        kw_logic = kw.get("logic", "").strip()
        extraction = _extract_keyword_columns_for_builder(kw)
        extracted_cols = extraction["columns"]
        table_hints = extraction["table_hints"]
        explicit_mappings = extraction.get("explicit_mappings", {})
        resolved_hints = {}
        for client_tbl in table_hints:
            stg_tbl = map_client_to_staging(client_tbl, tables)
            if stg_tbl:
                resolved_hints[client_tbl] = stg_tbl

        tables_matched = defaultdict(list)
        unmatched_cols = []

        # If explicit mappings exist, use them directly
        if explicit_mappings:
            for tbl, cols in explicit_mappings.items():
                for col in cols:
                    # Try to match the column to verify it exists
                    match_type, matched_col, matched_tables_list, confidence = _match_column(
                        col, column_tables_map, all_columns, normalized_map
                    )
                    if match_type == "unmatched":
                        unmatched_cols.append(col)
                    else:
                        detail = {"input": col, "matched_to": matched_col, "match_type": match_type, "confidence": confidence}
                        tables_matched[tbl].append(detail)
        else:
            # Fallback to original matching logic
            for col in extracted_cols:
                match_type, matched_col, matched_tables_list, confidence = _match_column(
                    col, column_tables_map, all_columns, normalized_map
                )
                if match_type == "unmatched":
                    unmatched_cols.append(col)
                    continue
                target = _resolve_target_tables(col, matched_col, matched_tables_list, table_hints, resolved_hints)
                detail = {"input": col, "matched_to": matched_col, "match_type": match_type, "confidence": confidence}
                for t in target:
                    tables_matched[t].append(detail)

        keyword_results.append({
            "keyword_name": kw_name, "description": kw_desc, "synonyms": synonyms,
            "logic": kw_logic,
            "tables_matched": dict(tables_matched), "unmatched_columns": unmatched_cols,
        })

    # Build table entries
    table_entries = {}
    for table_name, columns in tables.items():
        table_entries[table_name] = {
            "column_count": len(columns), "columns": columns,
            "column_profiles": column_profiles.get(table_name, {}) if column_profiles else {},
            "kpis": [], "questions": [], "keywords": [], "related_tables": [],
        }

    for kpi_res in kpi_results:
        for table_name, match_details in kpi_res["tables_matched"].items():
            if table_name in table_entries:
                table_entries[table_name]["kpis"].append({
                    "kpi_name": kpi_res["kpi_name"], "matched_columns": match_details,
                    "description": kpi_res["description"], "formula": kpi_res["formula"], "logic": kpi_res["logic"],
                })
    for q_res in question_results:
        for table_name, match_details in q_res["tables_matched"].items():
            if table_name in table_entries:
                table_entries[table_name]["questions"].append({
                    "question": q_res["question"], "matched_columns": match_details,
                    "reference_sql": q_res["sql"],
                })
    for kw_res in keyword_results:
        for table_name, match_details in kw_res["tables_matched"].items():
            if table_name in table_entries:
                table_entries[table_name]["keywords"].append({
                    "keyword_name": kw_res["keyword_name"], "matched_columns": match_details,
                    "description": kw_res["description"], "synonyms": kw_res["synonyms"],
                    "logic": kw_res["logic"],
                })

    # Table affinity / relationships
    table_names = list(tables.keys())
    table_col_sets = {t: set(cols) - SYSTEM_COLUMNS for t, cols in tables.items()}
    table_kpis = defaultdict(set)
    table_questions = defaultdict(set)
    table_keywords = defaultdict(set)
    for kpi_res in kpi_results:
        for t in kpi_res["tables_matched"]:
            table_kpis[t].add(kpi_res["kpi_name"])
    for q_res in question_results:
        for t in q_res["tables_matched"]:
            table_questions[t].add(q_res["question"])
    for kw_res in keyword_results:
        for t in kw_res["tables_matched"]:
            table_keywords[t].add(kw_res["keyword_name"])

    relationships = defaultdict(list)
    for i, t1 in enumerate(table_names):
        for t2 in table_names[i + 1:]:
            shared = table_col_sets[t1] & table_col_sets[t2]
            co_kpis = table_kpis[t1] & table_kpis[t2]
            co_questions = table_questions[t1] & table_questions[t2]
            co_keywords = table_keywords[t1] & table_keywords[t2]
            if not shared and not co_kpis and not co_questions and not co_keywords:
                continue
            min_cols = min(len(table_col_sets[t1]), len(table_col_sets[t2]))
            col_score = len(shared) / max(min_cols, 1)
            total_kpis_count = len(table_kpis[t1] | table_kpis[t2])
            kpi_score = len(co_kpis) / max(total_kpis_count, 1)
            total_qs = len(table_questions[t1] | table_questions[t2])
            q_score = len(co_questions) / max(total_qs, 1)
            total_kws = len(table_keywords[t1] | table_keywords[t2])
            kw_score = len(co_keywords) / max(total_kws, 1)
            affinity = round(0.4 * col_score + 0.2 * kpi_score + 0.2 * q_score + 0.2 * kw_score, 3)
            shared_sorted = sorted(shared)

            relationships[t1].append({"table_name": t2, "shared_columns": shared_sorted, "shared_column_count": len(shared), "affinity_score": affinity})
            relationships[t2].append({"table_name": t1, "shared_columns": shared_sorted, "shared_column_count": len(shared), "affinity_score": affinity})

    for t in relationships:
        relationships[t].sort(key=lambda x: x["affinity_score"], reverse=True)
    for table_name, related in relationships.items():
        if table_name in table_entries:
            table_entries[table_name]["related_tables"] = related

    # Build indexes
    def _build_index(results_list, name_key, extra_keys=None):
        index = {}
        for res in results_list:
            tables_involved = sorted(res["tables_matched"].keys())
            matched_by_table = {
                t: sorted(set(d["matched_to"] for d in details))
                for t, details in res["tables_matched"].items()
            }
            total_extracted = len(set(
                d["input"] for details in res["tables_matched"].values() for d in details
            )) + len(res["unmatched_columns"])
            matched_count = total_extracted - len(res["unmatched_columns"])
            coverage = round(matched_count / max(total_extracted, 1) * 100, 1)
            entry = {
                "tables_involved": tables_involved,
                "matched_columns_by_table": matched_by_table,
                "unmatched_columns": sorted(res["unmatched_columns"]),
                "validation": {
                    "total_columns_extracted": total_extracted,
                    "matched_count": matched_count,
                    "coverage_pct": coverage,
                    "can_execute": coverage >= 50.0,
                },
            }
            if extra_keys:
                for k in extra_keys:
                    entry[k] = res.get(k, "")
            index[res[name_key]] = entry
        return index

    kpi_index = _build_index(kpi_results, "kpi_name", ["description", "formula", "logic"])
    question_index = _build_index(question_results, "question", ["sql"])
    keyword_index = _build_index(keyword_results, "keyword_name", ["description", "synonyms", "logic"])

    # Statistics
    kpis_with_matches = sum(1 for r in kpi_results if r["tables_matched"])
    qs_with_matches = sum(1 for r in question_results if r["tables_matched"])
    kws_with_matches = sum(1 for r in keyword_results if r["tables_matched"])
    kpis_executable = sum(1 for v in kpi_index.values() if v["validation"]["can_execute"])
    qs_executable = sum(1 for v in question_index.values() if v["validation"]["can_execute"])
    kws_executable = sum(1 for v in keyword_index.values() if v["validation"]["can_execute"])

    schema_name = settings.db_schema_compare

    result = {
        "_metadata": {
            "generated_at": datetime.now().isoformat(timespec="seconds"),
            "schema_name": schema_name,
            "matching_config": {
                "fuzzy_threshold": _FUZZY_THRESHOLD,
                "difflib_threshold": _DIFFLIB_THRESHOLD,
                "engine": "rapidfuzz" if _USE_RAPIDFUZZ else "difflib",
            },
            "statistics": {
                "total_tables": len(tables),
                "total_columns": len(all_columns),
                "total_kpis": len(kpis),
                "total_questions": len(questions),
                "total_keywords": len(keywords),
                "kpis_with_table_matches": kpis_with_matches,
                "questions_with_table_matches": qs_with_matches,
                "keywords_with_table_matches": kws_with_matches,
                "kpis_executable": kpis_executable,
                "questions_executable": qs_executable,
                "keywords_executable": kws_executable,
            },
        },
        "tables": table_entries,
        "kpi_index": kpi_index,
        "question_index": question_index,
        "keyword_index": keyword_index,
    }

    return result


# ── Public entry point ──

async def run_table_schema_builder(db: AsyncSession, include_profiles: bool = True) -> dict:
    """
    Build schema map, store in PostgreSQL, return dict with schema_map and stored_id.
    Raises HTTPException on error.

    Args:
        include_profiles: When True (default), runs column profiling (data_type, distinct count,
            null %, min/max/avg). Uses one query per table so it is fast regardless of schema size.
    """
    from fastapi import HTTPException

    staging_schema = await fetch_staging_schema_async(db, settings.db_schema_compare)
    if not staging_schema:
        raise HTTPException(status_code=404, detail=f"No tables found in schema '{settings.db_schema_compare}'")

    kpi_data, qb_data, kw_data = await load_json_from_semantic_tables(db)

    column_profiles = None
    if include_profiles:
        column_types = await fetch_column_types_async(db, settings.db_schema_compare)
        column_profiles = await _build_column_profiles_async(settings.db_schema_compare, staging_schema, column_types)

    schema_map = _build_table_schema_map(staging_schema, kpi_data, qb_data, kw_data, column_profiles=column_profiles)

    # Ensure table exists
    async with async_engine.begin() as conn:
        await conn.run_sync(
            Base.metadata.create_all,
            tables=[TableSchemaMap.__table__],
        )

    # Store in PostgreSQL
    new_record = TableSchemaMap(schema_data=schema_map)
    db.add(new_record)
    await db.flush()
    stored_id = new_record.id

    logger.info(f"Table schema map stored with id={stored_id}")

    return {
        "schema_map": schema_map,
        "stored_id": stored_id,
    }
