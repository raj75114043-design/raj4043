"""
KPI CRUD endpoints for PM Copilot Global Context Layer
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import logging
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text, func
from sqlalchemy.orm import selectinload
import numpy as np

from fastapi import Security, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import secrets

from app.db.database import get_db, async_engine, Base
from app.core.config import settings
from app.models.semantic_models import (
    SemanticKPI
)
from app.schemas.semantic_schemas import (
    SemanticKPICreate,
    SemanticKPIUpdate,
    SemanticKPIResponse,
    MessageResponse,
    BulkDeleteRequest,
    BulkOperationResponse,
)
from app.services.embedding_service import embedding_service


logger = logging.getLogger(__name__)


security = HTTPBasic()
logger = logging.getLogger(__name__)
router = APIRouter(prefix="/kpi", tags=["KPI Creations [Dev Only]"])


DEV_PASSOWRD = "pwc_macro_team"

def verify_dev_password(credentials: HTTPBasicCredentials = Depends(security)):
    correct = secrets.compare_digest(credentials.password, "pwc_macro_team")
    if not correct:
        raise HTTPException(status_code=401, headers={"WWW-Authenticate": "Basic"})




@router.post("/kpi", response_model=SemanticKPIResponse, status_code=201)
async def create_semantic_kpi(
    kpi: SemanticKPICreate,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> SemanticKPIResponse:
    """
    Create a new semantic KPI with auto-generated embedding

    Args:
        kpi: KPI data

    Returns:
        Created KPI with embedding
    """
    # Generate embedding from combined text fields
    combined_text = embedding_service.combine_text_for_embedding(
        name=kpi.kpi_name,
        description=kpi.description,
    )

    embedding = None
    try:
        embedding = await embedding_service.generate_embedding(combined_text)
    except Exception as e:
        # Log but don't fail - embedding is optional
        logger.warning(f"Failed to generate embedding: {e}")

    db_kpi = SemanticKPI(**kpi.model_dump(), embedding=embedding)
    db.add(db_kpi)
    await db.commit()
    await db.refresh(db_kpi)
    return SemanticKPIResponse.model_validate(db_kpi)


@router.get("/kpi", response_model=List[SemanticKPIResponse])
async def list_semantic_kpis(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: AsyncSession = Depends(get_db)
) -> List[SemanticKPIResponse]:
    """
    A get requests which returns N number of KPIs

    Args:
        skip: Number of records to skip
        limit: Maximum number of records to return
        db: Database session

    Returns:
        List[SemanticKPIResponse]
    """
    result = await db.execute(
        select(SemanticKPI).offset(skip).limit(limit).order_by(SemanticKPI.kpi_id)
    )
    kpis = result.scalars().all()
    return [SemanticKPIResponse.model_validate(kpi) for kpi in kpis]


# --- Fixed: bulk routes MUST be defined before /{kpi_id} routes ---

@router.post("/kpi/bulk", response_model=BulkOperationResponse, status_code=201)
async def bulk_create_kpis(
    kpis: List[SemanticKPICreate],
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Bulk create semantic KPIs with auto-generated embeddings (max 100 items per request)

    Returns success/failure counts and details for each operation.
    """
    if len(kpis) > 100:
        raise HTTPException(status_code=400, detail="Maximum 100 items per request")

    created_ids = []
    errors = []

    for index, kpi in enumerate(kpis):
        try:
            # Generate embedding
            combined_text = embedding_service.combine_text_for_embedding(
                name=kpi.kpi_name,
                description=kpi.description,
            )

            embedding = None
            try:
                embedding = await embedding_service.generate_embedding(combined_text)
            except Exception as e:
                logger.warning(f"Failed to generate embedding for KPI at index {index}: {e}")

            db_kpi = SemanticKPI(**kpi.model_dump(), embedding=embedding)
            db.add(db_kpi)
            await db.flush()
            created_ids.append(db_kpi.kpi_id)
        except Exception as e:
            errors.append({"index": index, "error": str(e)})

    await db.commit()

    return BulkOperationResponse(
        success_count=len(created_ids),
        failed_count=len(errors),
        created_ids=created_ids,
        errors=errors if errors else None
    )


@router.delete("/kpi/bulk", response_model=BulkOperationResponse)
async def bulk_delete_kpis(
    request: BulkDeleteRequest,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Bulk delete semantic KPIs by IDs (max 100 IDs per request)

    Returns success/failure counts and details for each operation.
    """
    deleted_ids = []
    errors = []

    for kpi_id in request.ids:
        result = await db.execute(
            select(SemanticKPI).where(SemanticKPI.kpi_id == kpi_id)
        )
        kpi = result.scalar_one_or_none()

        if not kpi:
            errors.append({"id": kpi_id, "error": "KPI not found"})
            continue

        await db.delete(kpi)
        deleted_ids.append(kpi_id)

    await db.commit()

    return BulkOperationResponse(
        success_count=len(deleted_ids),
        failed_count=len(errors),
        deleted_ids=deleted_ids,
        errors=errors if errors else None
    )


@router.post("/kpi/bulk-reembed", response_model=BulkOperationResponse)
async def bulk_reembed_kpis(
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
) -> BulkOperationResponse:
    """
    Regenerate embeddings for ALL existing KPIs using only kpi_name + description.
    Processes records in batches of 100.
    """
    updated_ids = []
    errors = []
    batch_size = 100
    offset = 0

    while True:
        result = await db.execute(
            select(SemanticKPI).order_by(SemanticKPI.kpi_id).offset(offset).limit(batch_size)
        )
        batch = result.scalars().all()
        if not batch:
            break

        for kpi in batch:
            try:
                combined_text = embedding_service.combine_text_for_embedding(
                    name=kpi.kpi_name,
                    description=kpi.description,
                )
                kpi.embedding = await embedding_service.generate_embedding(combined_text)
                updated_ids.append(kpi.kpi_id)
            except Exception as e:
                logger.warning(f"Failed to reembed KPI {kpi.kpi_id}: {e}")
                errors.append({"id": kpi.kpi_id, "error": str(e)})

        await db.commit()
        offset += batch_size

    return BulkOperationResponse(
        success_count=len(updated_ids),
        failed_count=len(errors),
        updated_ids=updated_ids,
        errors=errors if errors else None,
    )


# --- Parameterized /{kpi_id} routes below (must come after /bulk) ---

@router.get("/kpi/{kpi_id}", response_model=SemanticKPIResponse)
async def get_semantic_kpi(
    kpi_id: int,
    db: AsyncSession = Depends(get_db)
) -> SemanticKPIResponse:
    """
    Create a new semantic KPI with auto-generated embedding

    Args:
        kpi_id: int
        db: Database session

    Returns:
        SemanticKPIResponse
    """
    result = await db.execute(select(SemanticKPI).where(SemanticKPI.kpi_id == kpi_id))
    kpi = result.scalar_one_or_none()
    if not kpi:
        raise HTTPException(status_code=404, detail=f"Semantic KPI with ID {kpi_id} not found")
    return SemanticKPIResponse.model_validate(kpi)


@router.put("/kpi/{kpi_id}", response_model=SemanticKPIResponse)
async def update_semantic_kpi(
    kpi_id: int,
    kpi_update: SemanticKPIUpdate,
    regenerate_embedding: bool = Query(True, description="Regenerate embedding after update"),
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> SemanticKPIResponse:
    """
    Create a new semantic KPI with auto-generated embedding

    Args:
        kpi_id: int
        kpi_update: SemanticKPIUpdate
        db: Database session

    Returns:
        SemanticKPIResponse
    """
    result = await db.execute(select(SemanticKPI).where(SemanticKPI.kpi_id == kpi_id))
    kpi = result.scalar_one_or_none()
    if not kpi:
        raise HTTPException(status_code=404, detail=f"Semantic KPI with ID {kpi_id} not found")

    update_data = kpi_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(kpi, field, value)

    if regenerate_embedding:
        combined_text = embedding_service.combine_text_for_embedding(
            name=kpi.kpi_name,
            description=kpi.description,
        )
        try:
            kpi.embedding = await embedding_service.generate_embedding(combined_text)
        except Exception as e:
            logger.warning(f"Failed to regenerate embedding: {e}")

    await db.commit()
    await db.refresh(kpi)
    return SemanticKPIResponse.model_validate(kpi)


@router.delete("/kpi/{kpi_id}", response_model=MessageResponse)
async def delete_semantic_kpi(
    kpi_id: int,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> MessageResponse:
    """
    Create a new semantic KPI with auto-generated embedding

    Args:
        kpi_id: Int

    Returns:
        MessageResponse
    """
    result = await db.execute(select(SemanticKPI).where(SemanticKPI.kpi_id == kpi_id))
    kpi = result.scalar_one_or_none()
    if not kpi:
        raise HTTPException(status_code=404, detail=f"Semantic KPI with ID {kpi_id} not found")
    await db.delete(kpi)
    await db.commit()
    return MessageResponse(message=f"Semantic KPI with ID {kpi_id} deleted successfully")
