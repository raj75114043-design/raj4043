"""
Semantic Search endpoints with vector embeddings for PM Copilot Global Context Layer
Schema: pwc_semantic_information_schema
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import logging
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query

logger = logging.getLogger(__name__)
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text, func
from sqlalchemy.orm import selectinload
import numpy as np


from fastapi import Security, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import secrets

from app.db.database import get_db, async_engine, Base
from app.core.config import settings
from app.models.semantic_models import (
    SemanticKPI,
    SemanticQuestionBank,
    SemanticRCA,
    SemanticSimulation,
    SemanticKeyword,
    SemanticEscalation,
)
from app.schemas.semantic_schemas import (
    SemanticSearchRequest,
    SemanticKeywordSearchRequest,
    SemanticSearchResult,
    SemanticSearchResponse,
)
from app.schemas.semantic_schemas import MessageResponse
from app.services.embedding_service import embedding_service

router = APIRouter(prefix="/semantic", tags=["Semantic Search & Vector Operations"])

security = HTTPBasic()

DEV_PASSOWRD = "pwc_macro_team"

def verify_dev_password(credentials: HTTPBasicCredentials = Depends(security)):
    correct = secrets.compare_digest(credentials.password, "pwc_macro_team")
    if not correct:
        raise HTTPException(status_code=401, headers={"WWW-Authenticate": "Basic"})



def cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
    """Calculate cosine similarity between two vectors"""
    if not vec1 or not vec2:
        return 0.0
    a = np.array(vec1)
    b = np.array(vec2)
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b)
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return float(np.dot(a, b) / (norm_a * norm_b))


def _normalize_text(text: str) -> str:
    """Lowercase and collapse whitespace for comparison."""
    return " ".join(text.lower().split())


def _token_overlap_score(query: str, text: str) -> float:
    """Jaccard similarity on word tokens."""
    q_tokens = set(query.lower().split())
    t_tokens = set(text.lower().split())
    if not q_tokens or not t_tokens:
        return 0.0
    intersection = len(q_tokens & t_tokens)
    union = len(q_tokens | t_tokens)
    return intersection / union if union > 0 else 0.0


def hybrid_score(vector_sim: float, query: str, text: str, alpha: float = 0.7) -> float:
    """
    Blend vector cosine similarity with Jaccard token overlap.
    Returns 1.0 for exact (normalised) matches, otherwise 70% vector + 30% Jaccard.
    """
    if _normalize_text(query) == _normalize_text(text):
        return 1.0
    text_sim = _token_overlap_score(query, text)
    return round(alpha * vector_sim + (1.0 - alpha) * text_sim, 4)


@router.post("/search", response_model=SemanticSearchResponse)
async def semantic_search(
    request: SemanticSearchRequest,
    db: AsyncSession = Depends(get_db)
) -> SemanticSearchResponse:
    """
    Perform semantic search across all or specific tables

    Uses cosine similarity to find the most relevant records based on
    vector embeddings.

    Args:
        request: Search request with query, optional table filter, and top_k

    Returns:
        Ranked search results with similarity scores
    """
    # Generate embedding for the query
    try:
        query_embedding = await embedding_service.generate_embedding(request.query)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate query embedding: {str(e)}"
        )

    if not query_embedding:
        raise HTTPException(
            status_code=400,
            detail="Could not generate embedding for the query"
        )

    results: List[SemanticSearchResult] = []
    tables_to_search = []

    # Determine which tables to search
    if request.table:
        table_mapping = {
            "kpi": SemanticKPI,
            "question_bank": SemanticQuestionBank,
            "rca": SemanticRCA,
            "simulation": SemanticSimulation,
            "escalation": SemanticEscalation
        }
        if request.table not in table_mapping:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid table name. Must be one of: {list(table_mapping.keys())}"
            )
        tables_to_search = [(request.table, table_mapping[request.table])]
    else:
        tables_to_search = [
            ("kpi", SemanticKPI),
            ("question_bank", SemanticQuestionBank),
            ("rca", SemanticRCA),
            ("simulation", SemanticSimulation),
            ("escalation", SemanticEscalation)
        ]

    # Search each table
    for table_name, model_class in tables_to_search:
        query_result = await db.execute(select(model_class))
        records = query_result.scalars().all()

        for record in records:
            if record.embedding:
                vec_sim = cosine_similarity(query_embedding, record.embedding)

                # Apply hybrid scoring for tables where a direct text field is available
                if table_name == "question_bank" and record.question:
                    similarity = hybrid_score(vec_sim, request.query, record.question)
                elif table_name == "kpi" and record.kpi_name:
                    similarity = hybrid_score(vec_sim, request.query, record.kpi_name)
                else:
                    similarity = round(vec_sim, 4)

                # Build content dict excluding embedding
                content = {}
                for key, value in record.__dict__.items():
                    if not key.startswith("_") and key != "embedding":
                        if hasattr(value, "value"):  # Handle enums
                            content[key] = value.value
                        elif isinstance(value, list):
                            content[key] = value
                        else:
                            content[key] = str(value) if value is not None else None

                # Get primary key value
                if hasattr(record, "kpi_id"):
                    record_id = record.kpi_id
                elif hasattr(record, "question_id"):
                    record_id = record.question_id
                elif hasattr(record, "problem_id"):
                    record_id = record.problem_id
                elif hasattr(record, "scenario_id"):
                    record_id = record.scenario_id
                else:
                    record_id = 0

                results.append(SemanticSearchResult(
                    table=table_name,
                    id=record_id,
                    content=content,
                    similarity_score=round(similarity, 4)
                ))

    # Sort by similarity and limit to top_k
    results.sort(key=lambda x: x.similarity_score, reverse=True)
    results = results[:request.top_k]

    return SemanticSearchResponse(
        query=request.query,
        total_results=len(results),
        results=results
    )


@router.post("/keywords/search", response_model=SemanticSearchResponse)
async def semantic_search_keywords(
    request: SemanticKeywordSearchRequest,
    db: AsyncSession = Depends(get_db)
) -> SemanticSearchResponse:
    """
    Perform semantic search specifically for keywords.

    Uses cosine similarity to find the most relevant keywords based on
    vector embeddings of their descriptions.

    Args:
        request: Search request with query and top_k (keywords only)

    Returns:
        Ranked keyword search results with similarity scores
    """
    # Generate embedding for the query
    try:
        query_embedding = await embedding_service.generate_embedding(request.query)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate query embedding: {str(e)}"
        )

    if not query_embedding:
        raise HTTPException(
            status_code=400,
            detail="Could not generate embedding for the query"
        )

    results: List[SemanticSearchResult] = []

    # Search keywords table
    query_result = await db.execute(select(SemanticKeyword))
    records = query_result.scalars().all()

    for record in records:
        if record.embedding:
            vec_sim = cosine_similarity(query_embedding, record.embedding)
            similarity = hybrid_score(vec_sim, request.query, record.keyword_name or "")

            # Build content dict excluding embedding
            content = {}
            for key, value in record.__dict__.items():
                if not key.startswith("_") and key != "embedding":
                    if hasattr(value, "value"):  # Handle enums
                        content[key] = value.value
                    elif isinstance(value, list):
                        content[key] = value
                    else:
                        content[key] = str(value) if value is not None else None

            results.append(SemanticSearchResult(
                table="keywords",
                id=record.keyword_id,
                content=content,
                similarity_score=round(similarity, 4)
            ))

    # Sort by similarity and limit to top_k
    results.sort(key=lambda x: x.similarity_score, reverse=True)
    results = results[:request.top_k]

    return SemanticSearchResponse(
        query=request.query,
        total_results=len(results),
        results=results
    )


@router.post("/regenerate-embeddings/{table_name}")
async def regenerate_embeddings(
    table_name: str,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> dict:
    """
    Regenerate embeddings for all records in a specific table

    Args:
        table_name: Table name (kpi, question_bank, rca, simulation, escalation)

    Returns:
        Status with count of updated records
    """
    table_mapping = {
        "kpi": SemanticKPI,
        "question_bank": SemanticQuestionBank,
        "rca": SemanticRCA,
        "simulation": SemanticSimulation,
        "escalation": SemanticEscalation
    }

    if table_name not in table_mapping:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid table name. Must be one of: kpi, question_bank, rca, simulation, escalation"
        )

    model_class = table_mapping[table_name]
    result = await db.execute(select(model_class))
    records = result.scalars().all()

    updated_count = 0
    failed_count = 0

    for record in records:
        try:
            if table_name == "kpi":
                combined_text = embedding_service.combine_text_for_embedding(
                    name=record.kpi_name,
                    description=record.description,
                    formula=record.formula,
                    logic=record.logic
                )
            elif table_name == "question_bank":
                combined_text = embedding_service.combine_text_for_embedding(
                    question=record.question,
                    sql=record.sql
                )
            elif table_name == "rca":
                combined_text = embedding_service.combine_text_for_embedding(
                    question=record.rca_question,
                    type=record.type_of_rca_question.value,
                    root_causes=record.root_causes,
                    relevant_kpis=record.relevant_kpis
                )
            elif table_name == "simulation":
                combined_text = embedding_service.combine_text_for_embedding(
                    scenario=record.scenario,
                    simulation_methodology=record.simulation_methodology
                )
            elif table_name == "escalation":
                combined_text = embedding_service.combine_text_for_embedding(
                    escalation_type=record.escalation_type,
                    escalation_description=record.escalation_description,
                    probable_reasons=record.probable_reasons,
                    draft_escalation_message_template=record.draft_escalation_message_template,
                    vertical=record.vertical
                )

            record.embedding = await embedding_service.generate_embedding(combined_text)
            updated_count += 1
        except Exception as e:
            logger.warning(f"Failed to regenerate embedding for record: {e}")
            failed_count += 1

    await db.commit()

    return {
        "table": table_name,
        "total_records": len(records),
        "updated": updated_count,
        "failed": failed_count,
        "message": f"Embeddings regenerated for {updated_count} records"
    }
