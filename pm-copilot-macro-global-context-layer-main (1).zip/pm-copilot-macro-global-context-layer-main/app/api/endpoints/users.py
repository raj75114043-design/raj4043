"""
Copilot User Management CRUD endpoints for PM Copilot Global Context Layer
Manages Nokia PM Copilot user access configuration loaded from Excel.
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import logging
import os
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Security, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import secrets

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func

from app.db.database import get_db
from app.models.semantic_models import CopilotUser
from app.schemas.semantic_schemas import (
    CopilotUserCreate,
    CopilotUserUpdate,
    CopilotUserResponse,
    CopilotUserAccessResponse,
    UserBulkDeleteRequest,
    BulkOperationResponse,
    MessageResponse,
)

security = HTTPBasic()
logger = logging.getLogger(__name__)
router = APIRouter(prefix="/users", tags=["User Management"])

DEV_PASSWORD = "pwc_macro_team"


def verify_dev_password(credentials: HTTPBasicCredentials = Depends(security)):
    correct = secrets.compare_digest(credentials.password, DEV_PASSWORD)
    if not correct:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            headers={"WWW-Authenticate": "Basic"},
        )


def _parse_bool(value) -> bool:
    """Parse Excel cell value to bool — 'Yes' (any case) → True, else False."""
    if value is None:
        return False
    return str(value).strip().lower() == "yes"


# ==================== CREATE ====================

@router.post("/", response_model=CopilotUserResponse, status_code=201)
async def create_user(
    user: CopilotUserCreate,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
) -> CopilotUserResponse:
    """Create a new Copilot user."""
    existing = await db.execute(
        select(CopilotUser).where(CopilotUser.email == user.email)
    )
    if existing.scalar_one_or_none():
        raise HTTPException(status_code=409, detail=f"User with email '{user.email}' already exists")

    db_user = CopilotUser(**user.model_dump())
    db.add(db_user)
    await db.commit()
    await db.refresh(db_user)
    return CopilotUserResponse.model_validate(db_user)


# ==================== READ ====================

@router.get("/", response_model=List[CopilotUserResponse])
async def list_users(
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(100, ge=1, le=1000, description="Max records to return"),
    company: Optional[str] = Query(None, description="Filter by company name"),
    workflow_admin: Optional[bool] = Query(None, description="Filter by workflow admin flag"),
    db: AsyncSession = Depends(get_db),
) -> List[CopilotUserResponse]:
    """List all Copilot users with optional filters and pagination."""
    query = select(CopilotUser)

    if company is not None:
        query = query.where(CopilotUser.company.ilike(f"%{company}%"))
    if workflow_admin is not None:
        query = query.where(CopilotUser.workflow_admin == workflow_admin)

    query = query.order_by(CopilotUser.email).offset(skip).limit(limit)
    result = await db.execute(query)
    users = result.scalars().all()
    return [CopilotUserResponse.model_validate(u) for u in users]


@router.get("/access/{email}", response_model=CopilotUserAccessResponse)
async def get_user_access(
    email: str,
    db: AsyncSession = Depends(get_db),
) -> CopilotUserAccessResponse:
    """
    Get access configuration for a user by email address.
    Returns which projects and substreams the user has access to.
    """
    result = await db.execute(
        select(CopilotUser).where(CopilotUser.email == email.lower().strip())
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail=f"User '{email}' not found")

    return CopilotUserAccessResponse(
        email=user.email,
        company=user.company,
        projects={
            "AHLOA": user.project_ahloa,
            "NAS": user.project_nas,
            "NTM": user.project_ntm,
            "RPM": user.project_rpm,
        },
        substreams={
            "DEC": user.substream_dec,
            "rSE": user.substream_rse,
            "HSE": user.substream_hse,
        },
        workflow_admin=user.workflow_admin,
    )


@router.get("/{user_id}", response_model=CopilotUserResponse)
async def get_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
) -> CopilotUserResponse:
    """Get a specific Copilot user by ID."""
    result = await db.execute(
        select(CopilotUser).where(CopilotUser.user_id == user_id)
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail=f"User with ID {user_id} not found")
    return CopilotUserResponse.model_validate(user)


# ==================== UPDATE ====================

@router.put("/{user_id}", response_model=CopilotUserResponse)
async def update_user(
    user_id: int,
    user_update: CopilotUserUpdate,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
) -> CopilotUserResponse:
    """Update a Copilot user's details or access flags."""
    result = await db.execute(
        select(CopilotUser).where(CopilotUser.user_id == user_id)
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail=f"User with ID {user_id} not found")

    # Check for email conflict if email is being changed
    update_data = user_update.model_dump(exclude_unset=True)
    if "email" in update_data and update_data["email"] != user.email:
        conflict = await db.execute(
            select(CopilotUser).where(CopilotUser.email == update_data["email"])
        )
        if conflict.scalar_one_or_none():
            raise HTTPException(status_code=409, detail=f"Email '{update_data['email']}' is already in use")

    for field, value in update_data.items():
        setattr(user, field, value)

    await db.commit()
    await db.refresh(user)
    return CopilotUserResponse.model_validate(user)


# ==================== DELETE ====================

@router.delete("/bulk", response_model=BulkOperationResponse)
async def bulk_delete_users(
    request: UserBulkDeleteRequest,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
) -> BulkOperationResponse:
    """Bulk delete users by IDs (max 500 per request)."""
    deleted_ids = []
    errors = []

    for user_id in request.ids:
        result = await db.execute(
            select(CopilotUser).where(CopilotUser.user_id == user_id)
        )
        user = result.scalar_one_or_none()
        if not user:
            errors.append({"id": user_id, "error": "User not found"})
            continue
        await db.delete(user)
        deleted_ids.append(user_id)

    await db.commit()
    return BulkOperationResponse(
        success_count=len(deleted_ids),
        failed_count=len(errors),
        deleted_ids=deleted_ids,
        errors=errors if errors else None,
    )


@router.delete("/{user_id}", response_model=MessageResponse)
async def delete_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
) -> MessageResponse:
    """Delete a Copilot user by ID."""
    result = await db.execute(
        select(CopilotUser).where(CopilotUser.user_id == user_id)
    )
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail=f"User with ID {user_id} not found")
    await db.delete(user)
    await db.commit()
    return MessageResponse(message=f"User with ID {user_id} ({user.email}) deleted successfully")


# ==================== EXCEL IMPORT ====================

# @router.post("/import/excel", response_model=BulkOperationResponse, status_code=201)
# async def import_users_from_excel(
#     db: AsyncSession = Depends(get_db),
#     credentials: HTTPBasicCredentials = Depends(verify_dev_password),
# ) -> BulkOperationResponse:
#     """
#     Import users from the Excel file located in the data/ folder.

#     Reads `data/Co-Pilot User Config_*.xlsx` (picks the latest file alphabetically).
#     Skips rows with no email. Updates existing users, creates new ones.

#     Excel column layout (row 1 = merged headers, row 2 = sub-headers, row 3+ = data):
#     - Col A: Employee Mail ID
#     - Col B: AHLOA (project)
#     - Col C: NAS (project)
#     - Col D: NTM (project)
#     - Col E: RPM (project)
#     - Col F: DEC (substream)
#     - Col G: rSE (substream)
#     - Col H: HSE (substream)
#     - Col I: Company
#     - Col J: Workflow Admin
#     """
#     try:
#         import openpyxl
#     except ImportError:
#         raise HTTPException(
#             status_code=500,
#             detail="openpyxl is not installed. Run: pip install openpyxl"
#         )

#     # Discover Excel file in data/ folder
#     data_dir = os.path.join(os.path.dirname(__file__), "..", "..", "..", "data")
#     data_dir = os.path.normpath(data_dir)

#     if not os.path.isdir(data_dir):
#         raise HTTPException(status_code=500, detail=f"Data directory not found: {data_dir}")

#     excel_files = sorted([
#         f for f in os.listdir(data_dir)
#         if f.lower().endswith(".xlsx") and "user" in f.lower()
#     ])

#     if not excel_files:
#         raise HTTPException(status_code=404, detail="No user Excel file found in data/ folder")

#     excel_path = os.path.join(data_dir, excel_files[-1])  # latest file
#     logger.info(f"Importing users from: {excel_path}")

#     try:
#         wb = openpyxl.load_workbook(excel_path, read_only=True, data_only=True)
#         ws = wb.active
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"Failed to open Excel file: {str(e)}")

#     created_ids = []
#     updated_ids = []
#     errors = []
#     row_num = 0

#     # Row 1 = merged group headers, Row 2 = sub-column headers, Row 3+ = data
#     for row in ws.iter_rows(min_row=3, values_only=True):
#         row_num += 1
#         try:
#             email_raw = row[0] if len(row) > 0 else None
#             if not email_raw or str(email_raw).strip() == "":
#                 continue  # skip empty rows

#             email = str(email_raw).strip().lower()
#             company = str(row[8]).strip() if len(row) > 8 and row[8] else None
#             company = company if company and company.lower() != "none" else None

#             project_ahloa = _parse_bool(row[1] if len(row) > 1 else None)
#             project_nas   = _parse_bool(row[2] if len(row) > 2 else None)
#             project_ntm   = _parse_bool(row[3] if len(row) > 3 else None)
#             project_rpm   = _parse_bool(row[4] if len(row) > 4 else None)
#             substream_dec  = _parse_bool(row[5] if len(row) > 5 else None)
#             substream_rse  = _parse_bool(row[6] if len(row) > 6 else None)
#             substream_hse  = _parse_bool(row[7] if len(row) > 7 else None)
#             workflow_admin = _parse_bool(row[9] if len(row) > 9 else None)

#             # Upsert: update if exists, create if not
#             existing_result = await db.execute(
#                 select(CopilotUser).where(CopilotUser.email == email)
#             )
#             existing = existing_result.scalar_one_or_none()

#             if existing:
#                 existing.company = company
#                 existing.project_ahloa = project_ahloa
#                 existing.project_nas = project_nas
#                 existing.project_ntm = project_ntm
#                 existing.project_rpm = project_rpm
#                 existing.substream_dec = substream_dec
#                 existing.substream_rse = substream_rse
#                 existing.substream_hse = substream_hse
#                 existing.workflow_admin = workflow_admin
#                 await db.flush()
#                 updated_ids.append(existing.user_id)
#             else:
#                 new_user = CopilotUser(
#                     email=email,
#                     company=company,
#                     project_ahloa=project_ahloa,
#                     project_nas=project_nas,
#                     project_ntm=project_ntm,
#                     project_rpm=project_rpm,
#                     substream_dec=substream_dec,
#                     substream_rse=substream_rse,
#                     substream_hse=substream_hse,
#                     workflow_admin=workflow_admin,
#                 )
#                 db.add(new_user)
#                 await db.flush()
#                 created_ids.append(new_user.user_id)

#         except Exception as e:
#             errors.append({"row": row_num + 2, "error": str(e)})

#     await db.commit()
#     wb.close()

#     total_success = len(created_ids) + len(updated_ids)
#     logger.info(f"Excel import complete: {len(created_ids)} created, {len(updated_ids)} updated, {len(errors)} errors")

#     return BulkOperationResponse(
#         success_count=total_success,
#         failed_count=len(errors),
#         created_ids=created_ids,
#         errors=errors if errors else None,
#     )
