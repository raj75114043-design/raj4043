"""
Keywords CRUD endpoints for PM Copilot Global Context Layer
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""
import logging
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, Body
from fastapi import Security, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import secrets

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text, func
from sqlalchemy.orm import selectinload
import numpy as np

from app.db.database import get_db, async_engine, Base
from app.core.config import settings
from app.models.semantic_models import (
    SemanticKeyword,
)
from app.schemas.semantic_schemas import (
    SemanticKeywordCreate,
    SemanticKeywordUpdate,
    SemanticKeywordResponse,
    MessageResponse,
    BulkDeleteRequest,
    BulkOperationResponse,
)
from app.services.embedding_service import embedding_service

logger = logging.getLogger(__name__)
security = HTTPBasic()
router = APIRouter(prefix="/keywords", tags=["Keywords Management [Dev Only]"])

DEV_PASSOWRD = "pwc_macro_team"

def verify_dev_password(credentials: HTTPBasicCredentials = Depends(security)):
    correct = secrets.compare_digest(credentials.password, "pwc_macro_team")
    if not correct:
        raise HTTPException(status_code=401, headers={"WWW-Authenticate": "Basic"})



@router.post("/keywords", response_model=SemanticKeywordResponse, status_code=201)
async def create_keyword(
    keyword: SemanticKeywordCreate,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> SemanticKeywordResponse:
    """Create a new keyword with automatic embedding generation from description"""
    db_keyword = SemanticKeyword(**keyword.model_dump())

    # Generate embedding from keyword description
    if db_keyword.keyword_description and db_keyword.keyword_description.strip():
        try:
            embedding = await embedding_service.generate_embedding(db_keyword.keyword_description)
            db_keyword.embedding = embedding
            logger.info(f"Generated embedding for keyword '{db_keyword.keyword_name}'")
        except Exception as e:
            logger.warning(f"Failed to generate embedding for keyword '{db_keyword.keyword_name}': {str(e)}")

    db.add(db_keyword)
    await db.commit()
    await db.refresh(db_keyword)
    return SemanticKeywordResponse.model_validate(db_keyword)


@router.get("/keywords", response_model=List[SemanticKeywordResponse])
async def list_keywords(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: AsyncSession = Depends(get_db)
) -> List[SemanticKeywordResponse]:
    """List all keywords with pagination"""
    result = await db.execute(
        select(SemanticKeyword).offset(skip).limit(limit).order_by(SemanticKeyword.keyword_id)
    )
    keywords = result.scalars().all()
    return [SemanticKeywordResponse.model_validate(k) for k in keywords]


# --- Fixed: search & bulk routes MUST be defined before /{keyword_id} routes ---

@router.get("/keywords/search/by-name", response_model=List[SemanticKeywordResponse])
async def search_keyword_by_name(
    name: str = Query(..., min_length=1, description="Keyword name to search"),
    db: AsyncSession = Depends(get_db)
) -> List[SemanticKeywordResponse]:
    """Search keywords by name (partial match)"""
    result = await db.execute(
        select(SemanticKeyword).where(
            SemanticKeyword.keyword_name.ilike(f"%{name}%")
        ).order_by(SemanticKeyword.keyword_id)
    )
    keywords = result.scalars().all()
    return [SemanticKeywordResponse.model_validate(k) for k in keywords]


@router.get("/keywords/search/by-synonym", response_model=List[SemanticKeywordResponse])
async def search_keyword_by_synonym(
    synonym: str = Query(..., min_length=1, description="Synonym to search"),
    db: AsyncSession = Depends(get_db)
) -> List[SemanticKeywordResponse]:
    """Search keywords by synonym (partial match)"""
    result = await db.execute(
        select(SemanticKeyword).where(
            SemanticKeyword.synonyms.ilike(f"%{synonym}%")
        ).order_by(SemanticKeyword.keyword_id)
    )
    keywords = result.scalars().all()
    return [SemanticKeywordResponse.model_validate(k) for k in keywords]


@router.post("/keywords/bulk", response_model=BulkOperationResponse, status_code=201)
async def bulk_create_keywords(
    keywords: List[SemanticKeywordCreate] = Body(..., description="List of keywords to create (max 100)"),
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Bulk create keywords with automatic embedding generation (max 100 items per request)

    Returns success/failure counts and details for each operation.
    """
    if len(keywords) > 100:
        raise HTTPException(status_code=400, detail="Maximum 100 items per request")

    created_ids = []
    errors = []
    db_keywords = []
    descriptions = []
    desc_to_keyword_idx = {}

    # Create keyword objects and collect descriptions for batch embedding
    for index, keyword in enumerate(keywords):
        try:
            db_keyword = SemanticKeyword(**keyword.model_dump())
            db_keywords.append(db_keyword)
            db.add(db_keyword)
            await db.flush()
            created_ids.append(db_keyword.keyword_id)

            # Collect descriptions for embedding generation
            if db_keyword.keyword_description and db_keyword.keyword_description.strip():
                descriptions.append(db_keyword.keyword_description)
                desc_to_keyword_idx[len(descriptions) - 1] = len(db_keywords) - 1

        except Exception as e:
            errors.append({"index": index, "error": str(e)})

    # Generate embeddings in batch for all keywords with descriptions
    if descriptions:
        try:
            embeddings = await embedding_service.generate_embeddings_batch(descriptions)

            for desc_idx, embedding in enumerate(embeddings):
                if desc_idx in desc_to_keyword_idx and embedding:
                    keyword_idx = desc_to_keyword_idx[desc_idx]
                    db_keywords[keyword_idx].embedding = embedding
                    logger.info(f"Generated embedding for keyword '{db_keywords[keyword_idx].keyword_name}'")

        except Exception as e:
            logger.warning(f"Failed to generate batch embeddings: {str(e)}")
            errors.append({"message": f"Batch embedding generation failed: {str(e)}"})

    await db.commit()

    return BulkOperationResponse(
        success_count=len(created_ids),
        failed_count=len(errors),
        created_ids=created_ids,
        errors=errors if errors else None
    )


@router.delete("/keywords/bulk", response_model=BulkOperationResponse)
async def bulk_delete_keywords(
    request: BulkDeleteRequest,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Bulk delete keywords by IDs (max 100 IDs per request)

    Returns success/failure counts and details for each operation.
    """
    deleted_ids = []
    errors = []

    for keyword_id in request.ids:
        result = await db.execute(
            select(SemanticKeyword).where(SemanticKeyword.keyword_id == keyword_id)
        )
        keyword = result.scalar_one_or_none()

        if not keyword:
            errors.append({"id": keyword_id, "error": "Keyword not found"})
            continue

        await db.delete(keyword)
        deleted_ids.append(keyword_id)

    await db.commit()

    return BulkOperationResponse(
        success_count=len(deleted_ids),
        failed_count=len(errors),
        deleted_ids=deleted_ids,
        errors=errors if errors else None
    )


@router.post("/keywords/embeddings/generate", response_model=BulkOperationResponse)
async def generate_keyword_embeddings(
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Generate embeddings for all existing keywords from their descriptions.

    This endpoint fetches all keywords and generates vector embeddings
    for the keyword_description field using the embedding service.

    Returns success/failure counts and details for each operation.
    """
    # Fetch all keywords
    result = await db.execute(select(SemanticKeyword))
    keywords = result.scalars().all()

    if not keywords:
        return BulkOperationResponse(
            success_count=0,
            failed_count=0,
            created_ids=[],
            errors=[{"message": "No keywords found in database"}]
        )

    updated_ids = []
    errors = []

    # Collect descriptions to generate embeddings in batch
    descriptions = []
    keyword_map = {}

    for keyword in keywords:
        if keyword.keyword_description and keyword.keyword_description.strip():
            descriptions.append(keyword.keyword_description)
            keyword_map[len(descriptions) - 1] = keyword
        else:
            errors.append({
                "id": keyword.keyword_id,
                "error": "Keyword has no description or empty description"
            })

    if not descriptions:
        return BulkOperationResponse(
            success_count=0,
            failed_count=len(errors),
            created_ids=[],
            errors=errors if errors else None
        )

    # Generate embeddings for all descriptions
    try:
        embeddings = await embedding_service.generate_embeddings_batch(descriptions)

        # Update keywords with embeddings
        for idx, embedding in enumerate(embeddings):
            if idx in keyword_map and embedding:
                keyword = keyword_map[idx]
                keyword.embedding = embedding
                db.add(keyword)
                updated_ids.append(keyword.keyword_id)
            elif idx in keyword_map:
                errors.append({
                    "id": keyword_map[idx].keyword_id,
                    "error": "Failed to generate embedding"
                })

        await db.commit()

    except Exception as e:
        logger.error(f"Error generating embeddings: {str(e)}")
        errors.append({"message": f"Batch embedding generation failed: {str(e)}"})

    return BulkOperationResponse(
        success_count=len(updated_ids),
        failed_count=len(errors),
        created_ids=updated_ids,
        errors=errors if errors else None
    )


# --- Parameterized /{keyword_id} routes below (must come after /search and /bulk) ---

@router.get("/keywords/{keyword_id}", response_model=SemanticKeywordResponse)
async def get_keyword(
    keyword_id: int,
    db: AsyncSession = Depends(get_db)
) -> SemanticKeywordResponse:
    """Get a specific keyword by ID"""
    result = await db.execute(
        select(SemanticKeyword).where(SemanticKeyword.keyword_id == keyword_id)
    )
    keyword = result.scalar_one_or_none()
    if not keyword:
        raise HTTPException(status_code=404, detail=f"Keyword with ID {keyword_id} not found")
    return SemanticKeywordResponse.model_validate(keyword)


@router.put("/keywords/{keyword_id}", response_model=SemanticKeywordResponse)
async def update_keyword(
    keyword_id: int,
    keyword_update: SemanticKeywordUpdate,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> SemanticKeywordResponse:
    """Update a keyword and regenerate embedding if description changes"""
    result = await db.execute(
        select(SemanticKeyword).where(SemanticKeyword.keyword_id == keyword_id)
    )
    keyword = result.scalar_one_or_none()
    if not keyword:
        raise HTTPException(status_code=404, detail=f"Keyword with ID {keyword_id} not found")

    update_data = keyword_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(keyword, field, value)

    # Regenerate embedding if description was updated
    if "keyword_description" in update_data and keyword.keyword_description and keyword.keyword_description.strip():
        try:
            embedding = await embedding_service.generate_embedding(keyword.keyword_description)
            keyword.embedding = embedding
            logger.info(f"Regenerated embedding for keyword '{keyword.keyword_name}'")
        except Exception as e:
            logger.warning(f"Failed to regenerate embedding for keyword '{keyword.keyword_name}': {str(e)}")

    await db.commit()
    await db.refresh(keyword)
    return SemanticKeywordResponse.model_validate(keyword)


@router.delete("/keywords/{keyword_id}", response_model=MessageResponse)
async def delete_keyword(
    keyword_id: int,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> MessageResponse:
    """Delete a keyword"""
    result = await db.execute(
        select(SemanticKeyword).where(SemanticKeyword.keyword_id == keyword_id)
    )
    keyword = result.scalar_one_or_none()
    if not keyword:
        raise HTTPException(status_code=404, detail=f"Keyword with ID {keyword_id} not found")
    await db.delete(keyword)
    await db.commit()
    return MessageResponse(message=f"Keyword with ID {keyword_id} deleted successfully")
