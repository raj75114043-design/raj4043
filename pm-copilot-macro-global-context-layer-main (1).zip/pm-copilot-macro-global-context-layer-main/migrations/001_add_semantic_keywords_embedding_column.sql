-- Migration: Add embedding column to semantic_keywords table

BEGIN;

-- Add embedding column to semantic_keywords table
ALTER TABLE pwc_semantic_information_schema.semantic_keywords
ADD COLUMN embedding FLOAT8[] NULL;

-- Add comment to embedding column
COMMENT ON COLUMN pwc_semantic_information_schema.semantic_keywords.embedding
IS 'Vector embedding for semantic search';

-- Commit transaction
COMMIT;
