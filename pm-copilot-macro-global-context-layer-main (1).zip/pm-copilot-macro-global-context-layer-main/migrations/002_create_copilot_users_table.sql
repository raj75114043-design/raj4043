-- Migration: Create copilot_users table for Nokia PM Copilot user access management

BEGIN;

CREATE TABLE IF NOT EXISTS pwc_agent_utility_schema.copilot_users (
    user_id       SERIAL PRIMARY KEY,
    email         VARCHAR(255) NOT NULL UNIQUE,
    company       VARCHAR(255),

    -- Project access flags
    project_ahloa BOOLEAN NOT NULL DEFAULT FALSE,
    project_nas   BOOLEAN NOT NULL DEFAULT FALSE,
    project_ntm   BOOLEAN NOT NULL DEFAULT FALSE,
    project_rpm   BOOLEAN NOT NULL DEFAULT FALSE,

    -- Substream access flags
    substream_dec BOOLEAN NOT NULL DEFAULT FALSE,
    substream_rse BOOLEAN NOT NULL DEFAULT FALSE,
    substream_hse BOOLEAN NOT NULL DEFAULT FALSE,

    -- Admin flag
    workflow_admin BOOLEAN NOT NULL DEFAULT FALSE,

    created_at    TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS ix_copilot_users_email
    ON pwc_agent_utility_schema.copilot_users (email);

COMMENT ON TABLE pwc_agent_utility_schema.copilot_users
    IS 'Nokia PM Copilot user access configuration — imported from Co-Pilot User Config Excel';

COMMIT;
