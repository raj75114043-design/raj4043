# Nokia PM Copilot AI Assistant

**An intelligent conversational AI system for telecom project management data queries using natural language processing and SQL generation**

**Developed by:** PwC India
**Lead Developer:** Venkatesh Manikantan, Senior Associate
**Client:** Nokia
**Version:** 2.0
**Last Updated:** February 2026

---

## Project Overview

Nokia PM Copilot AI Assistant is a sophisticated backend system that transforms natural language questions into SQL queries for a telecom project management database. Built with FastAPI, LangGraph, and Azure Cognitive Services, it provides intelligent query processing with multi-turn conversation support, voice-to-text capabilities, and comprehensive feedback collection.

### Key Capabilities

- **Natural Language Processing:** Converts user questions into optimized PostgreSQL queries
- **Multi-Turn Conversations:** Maintains session context for follow-up questions and clarifications
- **Voice-to-Text Integration:** Real-time voice transcription via WebSocket using Azure Cognitive Services
- **Intelligent Validation:** HITL (Human-In-The-Loop) agent validates queries before SQL generation
- **Query Classification:** Automatically determines if a question needs general response, clarification, or SQL execution
- **Retry Logic:** Handles SQL errors gracefully with automatic generation and execution attempts
- **Chat History:** Stores and retrieves conversation turns with full context
- **Feedback Collection:** Captures user ratings and comments for continuous improvement
- **Server-Sent Events:** Progressive streaming of query processing stages to frontend
- **Async Performance:** Fully async backend for handling concurrent requests

---

##  System Architecture

### High-Level Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                     Frontend Applications                       │
│  (Browser/React, Mobile Apps, Desktop Clients)                  │
└──────────────┬────────────────────────────────────────────────┬─┘
               │                                                  │
         HTTP/SSE Streaming                              WebSocket
         (REST Endpoints)                            (Voice Input)
               │                                                  │
┌──────────────▼────────────────────────────────────────────────▼─┐
│                     API Gateway (FastAPI)                       │
│                    Port 8000 (Default)                          │
│                                                                 │
│  ├─ Session Management       (/api/v1/assistant/session)      │
│  ├─ Query Processing         (/api/v1/assistant/query)        │
│  ├─ Voice Transcription      (/api/v1/voice/*)               │
│  ├─ Chat History             (/api/v1/chat/*)                │
│  └─ Feedback Endpoints       (/api/v1/feedback/*)            │
└─┬────────────────────────────────────────────────────────────┬──┘
  │                                                              │
  ├─────────────────────────────────────────────────────────────┤
  │              Backend Processing Pipeline                     │
  │                                                              │
  ├─ Parallel Search Service                                   │
  │  ├─ Keyword Detection API                                  │
  │  ├─ KPI (Key Performance Indicator) Search                 │
  │  └─ Question Bank Similarity Matching                      │
  │                                                              │
  ├─ HITL Validation Agent (LangGraph)                         │
  │  ├─ Query Classification Module                            │
  │  │  ├─ Identifies query type (general/data/clarification) │
  │  │  └─ Routes to appropriate handler                       │
  │  ├─ General Response Generator                            │
  │  │  └─ Provides direct answers without SQL               │
  │  └─ Data Validation Module                                │
  │     ├─ Checks data availability                           │
  │     ├─ Validates KPI/keyword mappings                     │
  │     ├─ Requests clarification if needed                   │
  │     └─ Approves for SQL generation                        │
  │                                                              │
  ├─ SQL Generation Agent (LangGraph)                          │
  │  ├─ World View Fetching                                   │
  │  │  └─ Retrieves database schema and metadata            │
  │  ├─ Context Distillation                                  │
  │  │  └─ Compresses schema into optimized context          │
  │  ├─ SQL Generation Module                                │
  │  │  ├─ Normal Query Generation                           │
  │  │  └─ Follow-up Context-Aware Generation                │
  │  ├─ SQL Execution Engine                                 │
  │  │  └─ Executes queries with timeout protection          │
  │  ├─ Retry Handler                                        │
  │  │  └─ Regenerates on SQL errors (up to 3 retries)      │
  │  └─ Output Formatter                                      │
  │     └─ Converts results to JSON for transport             │
  │                                                              │
  ├─ Voice Service (Azure Cognitive Services)                 │
  │  ├─ Real-time WebSocket Transcription                    │
  │  └─ REST API Audio File Processing                       │
  │                                                              │
  └─ Database Layer (PostgreSQL)                              │
     ├─ Project Management Data Tables                        │
     ├─ Chat History Storage                                 │
     ├─ HITL Response Tracking                              │
     ├─ Feedback Records                                     │
     └─ Session Management Tables                           │
```

### Query Processing Flow

```
User Submits Question
       ↓
[Session Validation]
       ↓
[Parallel Search] ─→ Keywords + KPIs + Questions
       ↓
[HITL Agent]
       ├─→ General Query? → Return Response + END
       ├─→ Need Clarification? → Request Follow-up + END
       └─→ Ready for SQL? → Continue
              ↓
        [SQL Agent]
              ├─ Fetch World View (Database Schema)
              ├─ Distill Context
              ├─ Generate SQL (with conversation context if follow-up)
              ├─ Execute Query
              ├─ Handle Errors (retry if needed)
              └─ Format Output → JSON Table
              ↓
        [Save to History]
              ↓
        [Return Results + SSE Stream Complete]
              ↓
        [Optional: Collect Feedback]
```

---

##  Quick Start

### Prerequisites

- **Python:** 3.10+
- **PostgreSQL:** 13+
- **Azure Account:** For Speech-to-Text services
- **Git:** For version control

### Environment Setup

1. **Clone and Navigate:**
```bash
cd "c:\Nokia PM Copilot\MACRO\AI Assistant 2.0"
```

2. **Create Virtual Environment:**
```bash
python -m venv venv
source venv/Scripts/activate  # Windows
# or
source venv/bin/activate  # Linux/Mac
```

3. **Install Dependencies:**
```bash
pip install -r requirements.txt
```

4. **Configure Environment Variables:**

Create a `.env` file in the project root:

```env
# Database Configuration
DATABASE_URL=postgresql+asyncpg://user:password@localhost:5432/pm_copilot_db
DB_SCHEMA=your_schema_name

# API Configuration
API_HOST=0.0.0.0
API_PORT=8000
API_LOG_LEVEL=INFO

# Azure Speech Services
SPEECH_KEY_1=your_azure_speech_key
SPEECH_REGION=your_azure_region

# External APIs
KEYWORD_API_URL=http://keyword-api-host:port
KPI_API_URL=http://kpi-api-host:port
QUESTION_BANK_API_URL=http://qb-api-host:port
WORLD_VIEW_API_URL=http://world-view-api-host:port

# LLM Configuration
OPENAI_API_KEY=your_openai_key  # If using OpenAI
MODEL_NAME=gpt-4

# Logging
LOG_FILE_PATH=./logs/app.log
```


5. **Start the Server:**
```bash
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

The API will be available at `http://localhost:8000`
Swagger UI documentation: `http://localhost:8000/docs`

---

## Project Structure

```
AI Assistant 2.0/
├── app/
│   ├── main.py                          # FastAPI application entry point
│   ├── core/
│   │   ├── config.py                    # Configuration and environment variables
│   │   └── security.py                  # Authentication/authorization logic
│   │
│   ├── api/
│   │   ├── __init__.py
│   │   └── endpoints/
│   │       ├── ai_assistant.py          # Main query endpoint (SSE streaming)
│   │       ├── voice_2_text.py          # Voice transcription endpoints
│   │       ├── chat_history.py          # Chat history retrieval
│   │       └── feedback.py              # Feedback submission and retrieval
│   │
│   ├── agents/
│   │   ├── hitl_agent/
│   │   │   ├── graph.py                 # LangGraph for HITL validation
│   │   │   ├── nodes.py                 # Individual processing nodes
│   │   │   ├── prompts.py               # LLM prompts for HITL
│   │   │   └── state.py                 # State TypedDict for HITL flow
│   │   │
│   │   └── sql_agent/
│   │       ├── graph.py                 # LangGraph for SQL generation
│   │       ├── nodes.py                 # SQL processing nodes
│   │       ├── prompts.py               # SQL generation prompts
│   │       ├── state.py                 # State TypedDict for SQL flow
│   │       └── config.py                # SQL agent configuration
│   │
│   ├── services/
│   │   ├── parallel_kpi_key_qb_search.py # Parallel keyword/KPI/QB search
│   │   ├── voice_transcriber.py         # Azure voice transcription service
│   │   ├── world_view_utils.py          # Database schema context building
│   │   └── db_connection.py             # Database query execution
│   │
│   └── db/
│       ├── database.py                  # Async database session management
│       └── models.py                    # SQLAlchemy ORM models
│
├── docs/
│   ├── README.md                        # Documentation index
│   ├── FRONTEND_INTEGRATION_GUIDE.md    # Frontend integration manual
│   └── QUICK_START_EXAMPLES.md          # Code examples and walkthroughs
│
├── tests/
│   ├── test_hitl_agent.py               # HITL agent tests
│   ├── test_sql_agent.py                # SQL agent tests
│   └── test_endpoints.py                # API endpoint tests
│
├── requirements.txt                     # Python dependencies
├── .env.example                         # Environment template
├── docker-compose.yml                   # Docker services (optional)
└── README.md                            # This file
```

---

## Core Components

### 1. API Gateway (`app/main.py` + `app/api/endpoints/`)

**Responsibility:** HTTP interface for client applications

**Endpoints:**

| Endpoint | Method | Purpose | Response |
|----------|--------|---------|----------|
| `/api/v1/assistant/session` | POST | Create new conversation session | `{session_id, created_at}` |
| `/api/v1/assistant/query` | POST | Submit question and stream processing | SSE Events |
| `/api/v1/voice/ws/transcribe` | WebSocket | Real-time voice-to-text | Transcription events |
| `/api/v1/voice/transcribe` | POST | Upload audio file for transcription | SSE Stream |
| `/api/v1/chat/history/{session_id}` | GET | Retrieve conversation history | `{session_id, messages[]}` |
| `/api/v1/chat/turn/{unique_chat_id}` | GET | Get single Q&A turn | Chat turn details |
| `/api/v1/chat/sessions` | GET | List user's recent sessions | `[{session_id, turn_count}]` |
| `/api/v1/feedback/submit` | POST | Submit feedback for a turn | `{feedback_id, status}` |
| `/api/v1/feedback/chat/{unique_chat_id}` | GET | Get feedback for a turn | Feedback list |
| `/api/v1/feedback/stats` | GET | Get aggregate feedback statistics | `{total, avg_rating, thumbs_up, thumbs_down}` |

### 2. HITL Validation Agent (`app/agents/hitl_agent/`)

**Responsibility:** Intelligent query classification and validation before SQL generation

**Process:**

1. **Query Classification** → Determines query type
2. **General Response Path** → Direct answers (no database query)
3. **Data Validation Path** → Checks data availability and KPI/keyword mappings
4. **Clarification Path** → Requests user to refine question

**Key Features:**
- Uses LangGraph for stateful processing
- Iterates over KPI/keyword search results
- Validates mapping to database columns
- Returns structured response with status and guidance

### 3. SQL Generation Agent (`app/agents/sql_agent/`)

**Responsibility:** Transform validated queries into optimized PostgreSQL SQL

**Process:**

1. **World View Fetching** → Retrieve database schema and metadata
2. **Context Distillation** → Compress schema into LLM-optimized format
3. **SQL Generation** → Create SQL from natural language (normal or follow-up context)
4. **SQL Execution** → Run query against database
5. **Retry Handler** → Regenerate on errors (up to 3 retries)
6. **Output Formatting** → Convert results to JSON

**Smart Features:**
- **Follow-up Awareness:** Uses conversation history for context-aware generation
- **Schema Encoding:** Uses "toon" compression for context fit within token limits
- **Retry Intelligence:** Detects and fixes common SQL errors
- **Performance Optimization:** Adds LIMIT clauses, uses appropriate indexes
- **KPI Formula Application:** Applies predefined formulas from world view

### 4. Voice Service (`app/services/voice_transcriber.py`)

**Responsibility:** Audio processing and transcription

**Methods:**

- **WebSocket Real-Time:** Streams audio chunks to Azure, gets partial + final transcriptions
- **REST File Upload:** Process entire audio files with progress events
- **Format Support:** WebM/Opus, WAV, MP3

---

## Key Workflows

### Workflow 1: Normal Query Processing

```
1. User submits question via /assistant/query endpoint
2. Session validated and unique_chat_id generated
3. Parallel search fetches keywords, KPIs, questions
4. HITL agent classifies query
   a. If general → return response + END
   b. If needs clarification → return guidance + END
   c. If ready for SQL → continue
5. SQL agent generates query
6. SQL executed and results returned
7. All data saved to chat history
8. SSE stream completes
9. User can submit feedback
```

### Workflow 2: Follow-Up Question

```
1. User submits follow-up with is_follow_up=true and follow_up_chat_id
2. System fetches previous context:
   - Original user question
   - HITL clarification provided
   - Previously generated SQL
3. HITL agent re-validates with new question + previous context
4. SQL agent generates SQL using:
   - Current refined question
   - Conversation history context
   - Previous SQL as reference
5. Results returned and history saved
```

### Workflow 3: Voice-to-Text Query

```
1. User grants microphone permission
2. Browser records audio chunks
3. WebSocket connected to /voice/ws/transcribe
4. Audio chunks streamed in real-time
5. Server returns partial transcriptions (recognizing event)
6. Final transcription returned (recognized event)
7. Transcribed text automatically submitted to /assistant/query
8. Results streamed back to frontend
9. User can provide feedback on results
```

---

## Technology Stack

### Backend Framework
- **FastAPI** - Modern async web framework
- **Uvicorn** - ASGI server
- **Pydantic** - Data validation
- **SQLAlchemy** - Async ORM

### AI/ML Components
- **LangGraph** - Graph-based agent orchestration
- **LangChain** - LLM framework
- **OpenAI** - Language models for query classification and SQL generation

### Data & Database
- **PostgreSQL** - Primary database
- **asyncpg** - Async PostgreSQL driver
- **Pandas** - Data manipulation and serialization

### External Services
- **Azure Cognitive Services** - Speech-to-text transcription
- **Keyword API** - Custom keyword detection
- **KPI Search API** - Performance indicator search
- **Question Bank API** - Similar question retrieval

### Infrastructure & Utilities
- **Python-dotenv** - Environment configuration
- **Logging** - Comprehensive logging system
- **Toon** - Context compression
- **httpx** - Async HTTP client

---

## Data Models

### Session Model
```python
session_id: str              # Unique identifier
username: str                # User identifier
created_at: datetime         # Session start time
last_activity: datetime      # Last request time
```

### Chat Turn Model
```python
unique_chat_id: str          # Turn identifier
session_id: str              # Parent session
user_query: str              # User's question
ai_assistant_output: str     # HITL or SQL response
sql_generated: str           # Generated SQL (if applicable)
table_json: str              # Query results as JSON
kpi_identified: str[]        # KPIs found
keywords_identified: str[]   # Keywords found
is_follow_up: bool           # Whether this is a follow-up
created_at: datetime         # Timestamp
```

### Feedback Model
```python
feedback_id: str             # Feedback identifier
unique_chat_id: str          # Associated turn
session_id: str              # Associated session
username: str                # User who provided feedback
rating: int (1-5)            # Numeric rating
is_positive: bool            # Thumbs up/down
comment: str                 # Free-text comment
created_at: datetime         # Timestamp
```

---

## Processing Events (SSE Stream)

When a query is submitted, the frontend receives Server-Sent Events in this sequence:

1. **search_keywords** → Keywords extracted from question
2. **search_kpis** → KPIs matched in database
3. **search_qb** → Similar questions found
4. **search_complete** → Parallel search finished
5. **hitl_start** → HITL validation begins
6. **hitl_complete** → Classification result + next steps
   - `status: "general"` → Question answered
   - `status: "clarification_needed"` → User feedback required
   - `status: "ready_for_sql"` → Proceeding to SQL generation
7. **sql_start** → SQL generation begins (if status=ready_for_sql)
8. **sql_complete** → SQL executed, results available
9. **db_saved** → Data persisted to history

Each event includes relevant data for progressive UI updates.

---

## Security Considerations

### Current Implementation
- Session-based user identification
- No current authentication layer (assumed backend validates requests)

### Recommendations for Production
- Implement JWT authentication
- Add rate limiting per session
- Validate input lengths and types
- Implement CORS properly
- Use HTTPS/TLS for all communications
- Mask sensitive data in logs
- Implement request signing for external API calls

---

## Testing

### Run Tests
```bash
pytest tests/ -v
```

### Test Coverage
```bash
pytest tests/ --cov=app --cov-report=html
```

### Individual Test Files
```bash
pytest tests/test_endpoints.py -v          # API tests
pytest tests/test_hitl_agent.py -v        # HITL agent tests
pytest tests/test_sql_agent.py -v         # SQL agent tests
```

---

## Logging

The application uses Python's `logging` module with:

- **Console Output:** Real-time logs to stderr
- **File Logs:** Persistent logs in `./logs/app.log`
- **Log Levels:** DEBUG, INFO, WARNING, ERROR, CRITICAL
- **Structured Logs:** Include timestamps, function names, line numbers

Configure via environment variable:
```bash
API_LOG_LEVEL=DEBUG  # More detailed logs
```

---

## Docker Deployment (Optional)

### Build Image
```bash
docker build -t nokia-pm-copilot:2.0 .
```

### Run Container
```bash
docker run -p 8000:8000 \
  --env-file .env \
  --name pm-copilot \
  nokia-pm-copilot:2.0
```

### Docker Compose
```bash
docker-compose up -d
```

---

## Performance Optimization

### Current Optimizations
- **Parallel Search:** Keyword, KPI, and QB searches run concurrently
- **Async Processing:** All I/O operations are non-blocking
- **Context Compression:** Uses toon encoding to fit schema in token limits
- **Connection Pooling:** Reuses database connections
- **Streaming Responses:** SSE provides progressive updates

### Scaling Considerations
- Load balance multiple instances behind Nginx
- Use connection pooling for database
- Cache world view updates
- Implement Redis for session storage
- Monitor and optimize SQL query execution time

---

## Contributing

### Development Workflow
1. Create feature branch: `git checkout -b feature/your-feature`
2. Make changes following code style
3. Add tests for new functionality
4. Run tests and linting
5. Commit with descriptive message
6. Push and create pull request

### Code Style
- Follow PEP 8 guidelines
- Use type hints for all functions
- Document complex logic with comments
- Keep functions focused and modular

### Commit Message Format
```
[TYPE] Brief description

Detailed explanation if needed.
- Bullet points for multiple changes
- Reference any related issues

Type: feature, fix, refactor, test, docs
```

---

## Deployment Workflow

### Development
```bash
python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

### Staging
```bash
gunicorn app.main:app --workers 4 --worker-class uvicorn.workers.UvicornWorker
```

### Production
```bash
gunicorn app.main:app \
  --workers 8 \
  --worker-class uvicorn.workers.UvicornWorker \
  --bind 0.0.0.0:8000 \
  --access-logfile - \
  --error-logfile -
```

---

## Support & Contact

**Project Lead:**
- **Venkatesh Manikantan** | Senior Associate, PwC India
- Email: venkatesh.manikantan@pwc.com

**For Issues & Support:**
1. Check logs: `./logs/app.log`
2. Review Swagger documentation: `http://localhost:8000/docs`
3. Verify environment configuration: `.env` file
4. Check database connectivity
5. Review external service credentials

---

## License

**Proprietary**
© 2026 PwC India. All rights reserved.
Developed for Nokia Project Management Copilot
Unauthorized use or distribution is prohibited.

---

##  Changelog

### Version 2.0 (February 2026)
- ✅ Implemented SQL Agent follow-up branching with context-aware generation
- ✅ Fixed HITL validator data loss issue (keywords/KPIs now passed through pipeline)
- ✅ Added parallel search result object preservation
- ✅ Enhanced follow-up query handling with conversation history
- ✅ Comprehensive API documentation and examples

### Version 1.0 (January 2026)
- ✅ Initial release
- ✅ Core query processing pipeline
- ✅ Voice-to-text integration
- ✅ Chat history and feedback

---

**Version:** 2.0
**Last Updated:** February 24, 2026
**Status:** Active Development
**For:** Nokia PM Copilot Project Team
