"""
Simple Voice WebSocket Test for Frontend Team
With automatic resampling to 16kHz
"""

import asyncio
import json
import websockets
import wave
import struct

WS_URL = "wss://pm-copilot-macro-aiassistant3-osdp-gsd-gsd-delivery-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/voice/ws/transcribe"


async def test_simple():
    """Test with pre-recorded audio file (simplest method)"""

    language = "en-US"
    audio_file = r"C:\Nokia PM Copilot\MACRO\AI Assistant 2.0\notebooks\sample_16khz.wav"

    url = f"{WS_URL}?language={language}&audio_format=pcm"

    print(f"Connecting to: {url}\n")

    async with websockets.connect(url) as ws:
        print("✅ Connected!")
        print("=" * 60)

        # Read WAV file and resample to 16kHz
        with wave.open(audio_file, 'rb') as wav_file:
            n_channels, sample_width, framerate, n_frames, compression, params = wav_file.getparams()
            print(f"Original: {framerate}Hz, {n_channels} channel(s), {sample_width} bytes/sample")

            # Read all audio
            audio_data = wav_file.readframes(n_frames)
            samples = struct.unpack(f'<{n_frames * n_channels}h', audio_data)

            # Resample from original rate to 16kHz if needed
            target_rate = 16000
            if framerate != target_rate:
                print(f"Resampling {framerate}Hz → {target_rate}Hz...")
                ratio = target_rate / framerate
                resampled = []
                for i in range(int(len(samples) * ratio)):
                    idx = i / ratio
                    # Simple linear interpolation
                    idx_low = int(idx)
                    idx_high = min(idx_low + 1, len(samples) - 1)
                    frac = idx - idx_low
                    sample = int(samples[idx_low] * (1 - frac) + samples[idx_high] * frac)
                    resampled.append(struct.pack('<h', max(-32768, min(32767, sample))))
                audio_data = b''.join(resampled)
                print(f"Resampled to {len(resampled)} samples @ {target_rate}Hz")
            else:
                print(f"Audio already at {target_rate}Hz, no resampling needed")

        # Send audio in chunks
        chunk_size = 4096
        for i in range(0, len(audio_data), chunk_size):
            chunk = audio_data[i:i + chunk_size]
            await ws.send(chunk)
            print(f"📤 Sent {len(chunk)} bytes")

        # Send stop signal
        await ws.send("STOP")
        print("\n📤 Sent STOP\n")

        # Receive results
        print("Results:")
        print("=" * 60)
        try:
            async for message in ws:
                data = json.loads(message)
                event = data.get("event", "unknown")

                if event == "recognizing":
                    text = data.get("text", "")
                    print(f"🔄 Recognizing: {text}")
                elif event == "recognized":
                    text = data.get("text", "")
                    print(f"✅ Recognized: {text}")
                elif event == "done":
                    print(f"🏁 Done!")
                    break
                elif event == "error":
                    print(f"❌ Error: {data}")
                    break
        except Exception as e:
            print(f"❌ Error: {e}")

        print("=" * 60)


if __name__ == "__main__":
    import sys
    import io
    # Fix encoding for emojis on Windows
    if sys.platform == 'win32':
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

    print("[VOICE TEST] Voice WebSocket Simple Test\n")
    print("Usage: Replace 'sample.wav' with any audio file\n")

    asyncio.run(test_simple())
