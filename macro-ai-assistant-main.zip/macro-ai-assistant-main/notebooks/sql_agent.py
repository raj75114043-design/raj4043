"""

Text-to-SQL LangGraph Agent
============================
Flow:
  1. Parallel API calls → keyword detection, KPI search, question bank search
  2. Schema world-view API  → full context from backend
  3. Distill world-view     → drop noise via build_text2sql_context
  4. Generate SQL            → GPT-5-mini with high reasoning
  5. Execute SQL             → run against PostgreSQL
  6. On error → retry with error context (max 3 attempts)
  7. Return DataFrame

"""

import asyncio
import json
import operator
from typing import Annotated, Any, TypedDict

import httpx
import pandas as pd
import psycopg2
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from langgraph.graph import END, StateGraph

from world_view_utils import build_text2sql_context

# ──────────────────────────────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────────────────────────────

DB_CONFIG = {
    "host": "10.208.241.129",
    "port": "30924",
    "user": "osdp_pwc_read_role",
    "password": "Nokia@osdp@pwc@2025",
    "dbname": "postgres",
    "options": "-c search_path=pwc_macro_staging_schema,public",
}

BASE_URL = (
    "https://pm-copilot-macro-gcl-osdp-gsd-gsd-delivery-staging"
    ".aibi-americas-002.dyn.nesc.nokia.net"
)

KEYWORD_SEARCH_API = f"{BASE_URL}/api/v1/search/keywords/detect"
KPI_SEARCH_API = f"{BASE_URL}/api/v1/semantic/search"
QB_SEARCH_API = f"{BASE_URL}/api/v1/semantic/search"
SCHEMA_WORLD_VIEW_API = f"{BASE_URL}/api/v1/dev/schema-world-view"

WORLD_VIEW_AUTH = ("Any_string", "pwc_macro_team")

MAX_SQL_RETRIES = 3

# LLM
llm = ChatOpenAI(
    api_key="NONE",
    model="gpt-5-mini",
    base_url="https://llmgateway-qa-api.nokia.com/v1.2/",
    default_headers={
        "api-key": (
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
            "eyJ1c2VyTmFtZSI6IlJvbGxvdXRBZ2VudERldlRvb2wiLCJPYmplY3RJRCI6IjNGRUY4NzI0LUE5RTItNDMyQy1COTk4LTU0NDMwMEZBQjcxMyIsIndvcmtTcGFjZU5hbWUiOiJWUjE4NTdSb2xsb3V0QWdlbnREZXZTcGFjZSIsIm5iZiI6MTc3MDg4NTYyNCwiZXhwIjoxODAyNDIxNjI0LCJpYXQiOjE3NzA4ODU2MjR9."
            "HvO_kB6UNwcNSV4B_MXuh9OK54rYtRRDMPH5Y1EuOhc"
        ),
        "workspacename": "VR1857RolloutAgentDevSpace",
    },
    temperature=0,
    verbose=True,
    reasoning_effort="high",
)


# ──────────────────────────────────────────────────────────────────────
# State
# ──────────────────────────────────────────────────────────────────────

class AgentState(TypedDict):
    user_query: str
    # parallel search results
    keyword_names: list[str]
    kpi_names: list[str]
    qb_names: list[str]
    # world view
    raw_world_view: dict
    context: dict            # distilled
    # sql generation / execution
    generated_sql: str
    sql_error: str
    retry_count: int
    # final output
    result_df: Any           # pandas DataFrame or None
    final_status: str


# ──────────────────────────────────────────────────────────────────────
# Node helpers – async API calls
# ──────────────────────────────────────────────────────────────────────

async def _fetch_keywords(client: httpx.AsyncClient, query: str) -> list[str]:
    resp = await client.get(
        KEYWORD_SEARCH_API,
        params={"sentence": query},
        headers={"Accept": "application/json"},
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    return [
        kw["keyword_name"]
        for kw in data.get("detected_keywords", [])
        if kw.get("keyword_name")
    ]


async def _fetch_kpis(client: httpx.AsyncClient, query: str) -> list[str]:
    resp = await client.post(
        KPI_SEARCH_API,
        json={"query": query, "table": "kpi", "top_k": 8},
        headers={"Accept": "application/json", "Content-Type": "application/json"},
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    return [
        r["content"]["kpi_name"]
        for r in data.get("results", [])
        if r.get("content", {}).get("kpi_name")
    ]


async def _fetch_question_bank(client: httpx.AsyncClient, query: str) -> list[str]:
    resp = await client.post(
        QB_SEARCH_API,
        json={"query": query, "table": "question_bank", "top_k": 3},
        headers={"Accept": "application/json", "Content-Type": "application/json"},
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    return [
        r["content"]["question"]
        for r in data.get("results", [])
        if r.get("content", {}).get("question")
    ]


# ──────────────────────────────────────────────────────────────────────
# Graph Nodes
# ──────────────────────────────────────────────────────────────────────

async def parallel_search(state: AgentState) -> dict:
    """Fire keyword, KPI, and question-bank searches in parallel."""
    query = state["user_query"]
    async with httpx.AsyncClient() as client:
        keyword_names, kpi_names, qb_names = await asyncio.gather(
            _fetch_keywords(client, query),
            _fetch_kpis(client, query),
            _fetch_question_bank(client, query),
        )
    return {
        "keyword_names": keyword_names,
        "kpi_names": kpi_names,
        "qb_names": qb_names,
    }


async def fetch_world_view(state: AgentState) -> dict:
    """Call schema-world-view endpoint with collected search results."""
    payload = {
        "kpi_names": state["kpi_names"],
        "question_texts": state["qb_names"],
        "keyword_names": state["keyword_names"],
    }
    async with httpx.AsyncClient() as client:
        resp = await client.post(
            SCHEMA_WORLD_VIEW_API,
            json=payload,
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
            auth=WORLD_VIEW_AUTH,
            timeout=30,
        )
        resp.raise_for_status()
        data = resp.json()
    return {"raw_world_view": data}


def distill_context(state: AgentState) -> dict:
    """Apply build_text2sql_context to strip noise from the world view."""
    context = build_text2sql_context(state["raw_world_view"])
    return {"context": context}


# ───────── SQL Generation Prompt ─────────

SQL_SYSTEM_PROMPT = """\
You are an expert PostgreSQL query generator for a telecom project management database.

## Rules
- Output ONLY a single valid PostgreSQL SELECT statement. No markdown, no explanation.
- Use the schema: {schema_name}
- Prefix all table names with the schema, e.g. {schema_name}.table_name
- Use only the tables and columns listed in the context below.
- Cast date columns explicitly with ::date when comparing dates.
- Use CURRENT_DATE for "today".
- Use double-quoted aliases for readability, e.g. AS "Region".
- NEVER use SELECT *; always list specific columns.
- For KPI calculations, follow the formula and logic provided exactly.
- Reference SQL examples are provided as few-shot guides — adapt them, don't copy blindly.

## Context
{context_json}
"""

SQL_RETRY_PROMPT = """\
The previous SQL query failed with this database error:

```
{error}
```

Previous failing query:
```sql
{sql}
```

Fix the query based on the error. Output ONLY the corrected PostgreSQL SELECT statement.
Use the same context and rules as before.
"""


def generate_sql(state: AgentState) -> dict:
    """Generate SQL from the distilled context (or fix a previous error)."""
    ctx = state["context"]
    schema = ctx.get("schema_name", "pwc_macro_staging_schema")
    context_json = json.dumps(ctx, indent=2, default=str)

    messages = [
        SystemMessage(content=SQL_SYSTEM_PROMPT.format(
            schema_name=schema,
            context_json=context_json,
        )),
    ]

    if state.get("sql_error") and state.get("generated_sql"):
        # Retry path — include the error
        messages.append(HumanMessage(content=SQL_RETRY_PROMPT.format(
            error=state["sql_error"],
            sql=state["generated_sql"],
        )))
    else:
        # First attempt
        messages.append(HumanMessage(content=(
            f"Write a PostgreSQL query to answer this question:\n\n"
            f"{state['user_query']}"
        )))

    response = llm.invoke(messages)
    sql = response.content.strip()

    # Strip markdown fences if the LLM wraps them
    if sql.startswith("```"):
        sql = "\n".join(sql.split("\n")[1:])
    if sql.endswith("```"):
        sql = "\n".join(sql.split("\n")[:-1])
    sql = sql.strip()

    return {"generated_sql": sql, "sql_error": ""}


def execute_sql(state: AgentState) -> dict:
    """Run the generated SQL against PostgreSQL, return a DataFrame."""
    sql = state["generated_sql"]
    try:
        conn = psycopg2.connect(**DB_CONFIG)
        df = pd.read_sql_query(sql, conn)
        conn.close()
        return {
            "result_df": df,
            "sql_error": "",
            "final_status": "success",
        }
    except Exception as exc:
        return {
            "result_df": None,
            "sql_error": str(exc),
            "retry_count": state.get("retry_count", 0) + 1,
            "final_status": "error",
        }


def format_output(state: AgentState) -> dict:
    """Terminal node — nothing to transform, df is already on state."""
    return {}


# ──────────────────────────────────────────────────────────────────────
# Conditional edges
# ──────────────────────────────────────────────────────────────────────

def should_retry(state: AgentState) -> str:
    if not state.get("sql_error"):
        return "success"
    if state.get("retry_count", 0) >= MAX_SQL_RETRIES:
        return "max_retries"
    return "retry"


# ──────────────────────────────────────────────────────────────────────
# Graph assembly
# ──────────────────────────────────────────────────────────────────────

def build_graph() -> StateGraph:
    g = StateGraph(AgentState)

    # Nodes
    g.add_node("parallel_search", parallel_search)
    g.add_node("fetch_world_view", fetch_world_view)
    g.add_node("distill_context", distill_context)
    g.add_node("generate_sql", generate_sql)
    g.add_node("execute_sql", execute_sql)
    g.add_node("format_output", format_output)

    # Edges
    g.set_entry_point("parallel_search")
    g.add_edge("parallel_search", "fetch_world_view")
    g.add_edge("fetch_world_view", "distill_context")
    g.add_edge("distill_context", "generate_sql")
    g.add_edge("generate_sql", "execute_sql")

    g.add_conditional_edges(
        "execute_sql",
        should_retry,
        {
            "success": "format_output",
            "retry": "generate_sql",
            "max_retries": "format_output",
        },
    )

    g.add_edge("format_output", END)

    return g.compile()


# ──────────────────────────────────────────────────────────────────────
# Public entry point
# ──────────────────────────────────────────────────────────────────────

graph = build_graph()


async def run_sql_agent(user_query: str) -> dict:
    """
    Run the full text-to-SQL pipeline for a natural language question.

    Returns dict with keys:
      - success: bool
      - query: the user question
      - generated_sql: final SQL
      - result_df: pandas DataFrame (or None)
      - retries: number of SQL retries used
      - error: last error message if failed
    """
    initial_state: AgentState = {
        "user_query": user_query,
        "keyword_names": [],
        "kpi_names": [],
        "qb_names": [],
        "raw_world_view": {},
        "context": {},
        "generated_sql": "",
        "sql_error": "",
        "retry_count": 0,
        "result_df": None,
        "final_status": "",
    }

    final_state = await graph.ainvoke(initial_state)

    return {
        "success": final_state["final_status"] == "success",
        "query": user_query,
        "generated_sql": final_state["generated_sql"],
        "result_df": final_state["result_df"],
        "retries": final_state.get("retry_count", 0),
        "error": final_state.get("sql_error", ""),
    }


# ──────────────────────────────────────────────────────────────────────
# Quick CLI test
# ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys

    query = (
        sys.argv[1]
        if len(sys.argv) > 1
        else "List all sites where construction is complete but On-Air is pending"
    )

    result = asyncio.run(run_sql_agent(query))

    print(f"\n{'='*60}")
    print(f"Query:   {result['query']}")
    print(f"Success: {result['success']}")
    print(f"Retries: {result['retries']}")
    if result["error"]:
        print(f"Error:   {result['error']}")
    print(f"\nSQL:\n{result['generated_sql']}")
    if result["result_df"] is not None:
        print(f"\nResults ({len(result['result_df'])} rows):")
        print(result["result_df"].to_string(max_rows=20))
