"""
Human-in-the-Loop (HITL) LangGraph Agent (Fully Async)
======================================================
Flow:
  1. Classify query        → data question vs general/chitchat
  2a. If general           → respond directly (who are you, help, greetings, etc.)
  2b. If data question     → parallel API calls (keyword, KPI, question bank search)
  3. Validate question     → check if enough context was found to answer
  4a. If valid             → pass through to text-to-SQL pipeline
  4b. If insufficient      → generate clarifying questions using retrieved context
  5. Return result with per-node timestamps
"""

import asyncio
import time
from datetime import datetime, timezone
from typing import Any, TypedDict

import httpx
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_core.output_parsers import JsonOutputParser, StrOutputParser
from langgraph.graph import END, StateGraph
from pydantic import BaseModel, Field


# ──────────────────────────────────────────────────────────────────────
# Configuration (same endpoints as the sql_agent)
# ──────────────────────────────────────────────────────────────────────

BASE_URL = (
    "https://pm-copilot-macro-gcl-osdp-gsd-gsd-delivery-staging"
    ".aibi-americas-002.dyn.nesc.nokia.net"
)
KEYWORD_SEARCH_API = f"{BASE_URL}/api/v1/search/keywords/detect"
KPI_SEARCH_API = f"{BASE_URL}/api/v1/semantic/search"
QB_SEARCH_API = f"{BASE_URL}/api/v1/semantic/search"

# Minimum thresholds to consider a question "valid" for text-to-SQL
MIN_KPI_MATCHES = 1
MIN_TOTAL_MATCHES = 1  # at least 1 hit across KPI + keyword + QB combined

# LLM
llm = ChatOpenAI(
    api_key="NONE",
    model="gpt-5-mini",
    base_url="https://llmgateway-qa-api.nokia.com/v1.2/",
    default_headers={
        "api-key": (
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
            "eyJ1c2VyTmFtZSI6IlJvbGxvdXRBZ2VudERldlRvb2wiLCJPYmplY3RJRCI6IjNGRUY4NzI0LUE5RTItNDMyQy1COTk4LTU0NDMwMEZBQjcxMyIsIndvcmtTcGFjZU5hbWUiOiJWUjE4NTdSb2xsb3V0QWdlbnREZXZTcGFjZSIsIm5iZiI6MTc3MDg4NTYyNCwiZXhwIjoxODAyNDIxNjI0LCJpYXQiOjE3NzA4ODU2MjR9."
            "HvO_kB6UNwcNSV4B_MXuh9OK54rYtRRDMPH5Y1EuOhc"
        ),
        "workspacename": "VR1857RolloutAgentDevSpace",
    },
    temperature=0,
    verbose=True,
)


# ──────────────────────────────────────────────────────────────────────
# State
# ──────────────────────────────────────────────────────────────────────

class HITLState(TypedDict):
    user_query: str
    # classification
    query_type: str                # "data" | "general"
    # general-query response
    general_response: str
    # parallel search results
    keyword_results: list[dict]    # full objects from API (name + score)
    kpi_results: list[dict]
    qb_results: list[dict]
    keyword_names: list[str]
    kpi_names: list[str]
    qb_questions: list[str]
    # validation
    is_valid: bool
    clarifying_message: str
    # passthrough flag
    ready_for_sql: bool
    # per-node timing
    node_timestamps: dict


# ──────────────────────────────────────────────────────────────────────
# Timestamp helpers
# ──────────────────────────────────────────────────────────────────────

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def _merge_ts(existing: dict, node: str, start: str, end: str, dur: float) -> dict:
    updated = {**existing}
    updated[node] = {"start": start, "end": end, "duration_s": round(dur, 3)}
    return updated


# ──────────────────────────────────────────────────────────────────────
# Pydantic models for structured LLM outputs
# ──────────────────────────────────────────────────────────────────────

class QueryClassification(BaseModel):
    """Classification of a user query."""
    query_type: str = Field(
        description=(
            "Either 'data' for database / analytics / KPI / telecom questions, "
            "or 'general' for greetings, identity questions, help requests, chitchat."
        )
    )
    reasoning: str = Field(description="Brief explanation of why this classification was chosen.")


class ValidationResult(BaseModel):
    """Result of validating whether a data question is answerable."""
    is_valid: bool = Field(
        description="True if the question can be answered by the text-to-SQL system."
    )
    clarifying_message: str = Field(
        description=(
            "If is_valid is False, a helpful message that guides the user toward "
            "a better question. Include specific KPI names, keywords, or example "
            "questions from the retrieved context. If is_valid is True, leave empty."
        )
    )


# ──────────────────────────────────────────────────────────────────────
# Node helpers – async API calls (reused from sql_agent pattern)
# ──────────────────────────────────────────────────────────────────────

async def _fetch_keywords(client: httpx.AsyncClient, query: str) -> list[dict]:
    resp = await client.get(
        KEYWORD_SEARCH_API,
        params={"sentence": query},
        headers={"Accept": "application/json"},
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    return [kw for kw in data.get("detected_keywords", []) if kw.get("keyword_name")]


async def _fetch_kpis(client: httpx.AsyncClient, query: str) -> list[dict]:
    resp = await client.post(
        KPI_SEARCH_API,
        json={"query": query, "table": "kpi", "top_k": 8},
        headers={"Accept": "application/json", "Content-Type": "application/json"},
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    return [r for r in data.get("results", []) if r.get("content", {}).get("kpi_name")]


async def _fetch_question_bank(client: httpx.AsyncClient, query: str) -> list[dict]:
    resp = await client.post(
        QB_SEARCH_API,
        json={"query": query, "table": "question_bank", "top_k": 5},
        headers={"Accept": "application/json", "Content-Type": "application/json"},
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    return [r for r in data.get("results", []) if r.get("content", {}).get("question")]


# ──────────────────────────────────────────────────────────────────────
# Graph Nodes
# ──────────────────────────────────────────────────────────────────────

CLASSIFY_SYSTEM_PROMPT = """\
You are a query classifier for a telecom project management AI assistant.

The assistant helps users query a PostgreSQL database containing telecom KPIs,
project rollout data, site information, regions, milestones, and related metrics.

Classify the user's query into one of two categories:
- "data": The user is asking about data, KPIs, metrics, counts, status, projects,
  sites, regions, dates, schedules, rollout progress, or anything that would
  require querying a database.
- "general": The user is asking a general question like "who are you?",
  "what can you do?", "hello", "thanks", "help", or any non-data chitchat.

Be generous toward "data" — if there is any chance the user wants database info,
classify it as "data".
"""


async def classify_query(state: HITLState) -> dict:
    """Use the LLM to decide if this is a data question or general chitchat."""
    t_start, iso_start = time.perf_counter(), _now_iso()

    parser = JsonOutputParser(pydantic_object=QueryClassification)

    messages = [
        SystemMessage(content=CLASSIFY_SYSTEM_PROMPT),
        HumanMessage(content=(
            f"Classify this query:\n\n\"{state['user_query']}\"\n\n"
            f"{parser.get_format_instructions()}"
        )),
    ]
    raw = await llm.ainvoke(messages)
    result = parser.parse(raw.content)

    query_type = result["query_type"].lower().strip()
    if query_type not in ("data", "general"):
        query_type = "data"  # default to data if unclear

    duration = time.perf_counter() - t_start
    return {
        "query_type": query_type,
        "node_timestamps": _merge_ts(
            state.get("node_timestamps", {}), "classify_query", iso_start, _now_iso(), duration
        ),
    }


GENERAL_RESPONSE_SYSTEM_PROMPT = """\
You are the Nokia PM Copilot AI Assistant for telecom project management.
You help users explore KPIs, project rollout data, site information, and more
by converting natural language questions into SQL queries.

Respond to the user's general (non-data) query in a friendly, concise way.
If the user is asking what you can do, mention that you can:
- Answer questions about telecom KPIs (e.g. RAN Integration, Site Acceptance)
- Show project rollout progress by region, site, or milestone
- Provide counts, trends, and status breakdowns from the database
- Guide users toward the right questions to ask

Keep your response under 4 sentences.
"""


async def handle_general(state: HITLState) -> dict:
    """Respond to general / chitchat queries directly."""
    t_start, iso_start = time.perf_counter(), _now_iso()

    messages = [
        SystemMessage(content=GENERAL_RESPONSE_SYSTEM_PROMPT),
        HumanMessage(content=state["user_query"]),
    ]
    raw = await llm.ainvoke(messages)
    response = raw.content.strip()

    duration = time.perf_counter() - t_start
    return {
        "general_response": response,
        "ready_for_sql": False,
        "is_valid": False,
        "node_timestamps": _merge_ts(
            state.get("node_timestamps", {}), "handle_general", iso_start, _now_iso(), duration
        ),
    }


async def parallel_search(state: HITLState) -> dict:
    """Fire keyword, KPI, and question-bank searches in parallel."""
    t_start, iso_start = time.perf_counter(), _now_iso()

    query = state["user_query"]
    async with httpx.AsyncClient() as client:
        keyword_results, kpi_results, qb_results = await asyncio.gather(
            _fetch_keywords(client, query),
            _fetch_kpis(client, query),
            _fetch_question_bank(client, query),
        )

    keyword_names = [kw["keyword_name"] for kw in keyword_results]
    kpi_names = [r["content"]["kpi_name"] for r in kpi_results]
    qb_questions = [r["content"]["question"] for r in qb_results]

    duration = time.perf_counter() - t_start
    return {
        "keyword_results": keyword_results,
        "kpi_results": kpi_results,
        "qb_results": qb_results,
        "keyword_names": keyword_names,
        "kpi_names": kpi_names,
        "qb_questions": qb_questions,
        "node_timestamps": _merge_ts(
            state.get("node_timestamps", {}), "parallel_search", iso_start, _now_iso(), duration
        ),
    }


VALIDATE_SYSTEM_PROMPT = """\
You are a validation agent for a telecom project management AI assistant.

The assistant converts natural language questions into SQL queries against a
PostgreSQL database with telecom KPIs, project rollout data, sites, regions, etc.

You are given:
1. The user's question.
2. Matched KPIs from semantic search (names + descriptions).
3. Matched keywords from keyword detection (domain terms found in the query).
4. Similar questions from the question bank (previously answered reference questions).

Your job is to decide if the user's question is **answerable** by the text-to-SQL
system given the retrieved context.

A question is VALID if:
- At least one KPI, keyword, or reference question is relevant to what the user asked.
- The question is specific enough to translate into a SQL query (mentions data
  concepts like counts, lists, status, dates, regions, sites, KPIs, etc.).

A question is INVALID if:
- No retrieved KPIs, keywords, or reference questions relate to what the user asked.
- The question is too vague or ambiguous to produce a meaningful SQL query.
- The user seems to be asking about something outside the database scope.

When the question is INVALID, write a helpful clarifying_message that:
- Explains what the system can help with.
- Lists specific relevant KPI names or keywords from the context (if any partially match).
- Suggests 2-3 example questions the user could ask instead, drawn from or inspired
  by the reference questions in the context.
- Is friendly and encouraging, not dismissive.
"""


async def validate_question(state: HITLState) -> dict:
    """Check if the data question is answerable given the search context."""
    t_start, iso_start = time.perf_counter(), _now_iso()

    # Build context summary for the LLM
    kpi_summary = []
    for r in state.get("kpi_results", []):
        content = r.get("content", {})
        name = content.get("kpi_name", "")
        desc = content.get("description", "")
        score = r.get("score", "")
        kpi_summary.append(f"- {name} (score: {score}): {desc}")

    keyword_summary = []
    for kw in state.get("keyword_results", []):
        name = kw.get("keyword_name", "")
        desc = kw.get("description", "")
        keyword_summary.append(f"- {name}: {desc}")

    qb_summary = []
    for r in state.get("qb_results", []):
        content = r.get("content", {})
        question = content.get("question", "")
        score = r.get("score", "")
        qb_summary.append(f"- \"{question}\" (score: {score})")

    context_text = (
        f"## User Question\n{state['user_query']}\n\n"
        f"## Matched KPIs ({len(kpi_summary)} results)\n"
        + ("\n".join(kpi_summary) if kpi_summary else "None found.")
        + f"\n\n## Matched Keywords ({len(keyword_summary)} results)\n"
        + ("\n".join(keyword_summary) if keyword_summary else "None found.")
        + f"\n\n## Similar Questions from Question Bank ({len(qb_summary)} results)\n"
        + ("\n".join(qb_summary) if qb_summary else "None found.")
    )

    parser = JsonOutputParser(pydantic_object=ValidationResult)

    messages = [
        SystemMessage(content=VALIDATE_SYSTEM_PROMPT),
        HumanMessage(content=f"{context_text}\n\n{parser.get_format_instructions()}"),
    ]
    raw = await llm.ainvoke(messages)
    result = parser.parse(raw.content)

    is_valid = result.get("is_valid", False)
    clarifying_message = result.get("clarifying_message", "")

    # Also enforce a hard minimum: if zero results came back, it's invalid
    total_matches = len(state.get("kpi_names", [])) + len(state.get("keyword_names", [])) + len(state.get("qb_questions", []))
    if total_matches < MIN_TOTAL_MATCHES:
        is_valid = False
        if not clarifying_message:
            clarifying_message = (
                "I couldn't find any matching KPIs, keywords, or reference questions "
                "for your query. Could you rephrase your question? For example, you "
                "could ask about specific telecom KPIs, project rollout status, "
                "site counts by region, or milestone progress."
            )

    duration = time.perf_counter() - t_start
    return {
        "is_valid": is_valid,
        "clarifying_message": clarifying_message,
        "ready_for_sql": is_valid,
        "node_timestamps": _merge_ts(
            state.get("node_timestamps", {}), "validate_question", iso_start, _now_iso(), duration
        ),
    }


# ──────────────────────────────────────────────────────────────────────
# Conditional edge functions
# ──────────────────────────────────────────────────────────────────────

def route_query_type(state: HITLState) -> str:
    """After classification, route to general handler or data pipeline."""
    if state.get("query_type") == "general":
        return "general"
    return "data"


def route_validation(state: HITLState) -> str:
    """After validation, either pass through or return clarification."""
    if state.get("is_valid"):
        return "valid"
    return "clarify"


# ──────────────────────────────────────────────────────────────────────
# Terminal nodes
# ──────────────────────────────────────────────────────────────────────

async def passthrough(state: HITLState) -> dict:
    """Terminal node for valid data questions — ready for text-to-SQL."""
    iso_now = _now_iso()
    return {
        "ready_for_sql": True,
        "node_timestamps": _merge_ts(
            state.get("node_timestamps", {}), "passthrough", iso_now, iso_now, 0.0
        ),
    }


async def return_clarification(state: HITLState) -> dict:
    """Terminal node for invalid data questions — return clarifying message."""
    iso_now = _now_iso()
    return {
        "ready_for_sql": False,
        "node_timestamps": _merge_ts(
            state.get("node_timestamps", {}), "return_clarification", iso_now, iso_now, 0.0
        ),
    }


# ──────────────────────────────────────────────────────────────────────
# Graph assembly
# ──────────────────────────────────────────────────────────────────────

def build_hitl_graph() -> StateGraph:
    g = StateGraph(HITLState)

    # Nodes
    g.add_node("classify_query", classify_query)
    g.add_node("handle_general", handle_general)
    g.add_node("parallel_search", parallel_search)
    g.add_node("validate_question", validate_question)
    g.add_node("passthrough", passthrough)
    g.add_node("return_clarification", return_clarification)

    # Entry
    g.set_entry_point("classify_query")

    # Route: general vs data
    g.add_conditional_edges(
        "classify_query",
        route_query_type,
        {
            "general": "handle_general",
            "data": "parallel_search",
        },
    )

    # General → END
    g.add_edge("handle_general", END)

    # Data path: search → validate
    g.add_edge("parallel_search", "validate_question")

    # Route: valid vs needs clarification
    g.add_conditional_edges(
        "validate_question",
        route_validation,
        {
            "valid": "passthrough",
            "clarify": "return_clarification",
        },
    )

    # Terminal → END
    g.add_edge("passthrough", END)
    g.add_edge("return_clarification", END)

    return g.compile()


# ──────────────────────────────────────────────────────────────────────
# Public entry point
# ──────────────────────────────────────────────────────────────────────

hitl_graph = build_hitl_graph()


async def run_hitl_agent(user_query: str) -> dict:
    """
    Run the human-in-the-loop validation pipeline.

    Returns dict with keys:
      - query: the original user question
      - query_type: "data" | "general"
      - ready_for_sql: bool — True if the question should go to text-to-SQL
      - general_response: str — reply if query_type == "general"
      - clarifying_message: str — guidance if data question was invalid
      - keyword_names: list[str] — detected keywords (data path only)
      - kpi_names: list[str] — matched KPI names (data path only)
      - qb_questions: list[str] — similar reference questions (data path only)
      - node_timestamps: per-node timing breakdown
    """
    initial_state: HITLState = {
        "user_query": user_query,
        "query_type": "",
        "general_response": "",
        "keyword_results": [],
        "kpi_results": [],
        "qb_results": [],
        "keyword_names": [],
        "kpi_names": [],
        "qb_questions": [],
        "is_valid": False,
        "clarifying_message": "",
        "ready_for_sql": False,
        "node_timestamps": {},
    }

    final = await hitl_graph.ainvoke(initial_state)

    return {
        "query": user_query,
        "query_type": final["query_type"],
        "ready_for_sql": final["ready_for_sql"],
        "general_response": final.get("general_response", ""),
        "clarifying_message": final.get("clarifying_message", ""),
        "keyword_names": final.get("keyword_names", []),
        "kpi_names": final.get("kpi_names", []),
        "qb_questions": final.get("qb_questions", []),
        "node_timestamps": final.get("node_timestamps", {}),
    }
