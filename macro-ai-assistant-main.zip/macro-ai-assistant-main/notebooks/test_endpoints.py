import requests

BASE_URL = "https://pm-copilot-macro-aiassistant3-osdp-gsd-gsd-delivery-staging.aibi-americas-002.dyn.nesc.nokia.net"

# Test different possible endpoint paths
paths_to_test = [
    "/api/v1/voice/ws/transcribe",
    "/voice/ws/transcribe",
    "/ws/transcribe",
    "/api/v1/voice",
    "/health",  # Test if server is alive
]

print("Testing endpoint paths on staging server...\n")
print(f"Base URL: {BASE_URL}\n")

for path in paths_to_test:
    url = f"{BASE_URL}{path}"
    try:
        # Use a short timeout and follow redirects
        response = requests.get(url, timeout=5, allow_redirects=True)
        print(f"✓ {path:<40} Status: {response.status_code}")
    except requests.exceptions.RequestException as e:
        # WebSocket routes won't respond to GET, so 400+ errors are expected
        if "WebSocket" in str(e) or "connection" in str(e).lower():
            print(f"⚠ {path:<40} WebSocket endpoint (OK)")
        else:
            print(f"✗ {path:<40} Error: {type(e).__name__}")

print("\n" + "="*70)
print("Summary:")
print("- If /health returns 200, server is up")
print("- WebSocket endpoints may return 400+ on GET (that's OK)")
print("- If /api/v1/voice returns 404, the router prefix might be wrong")
