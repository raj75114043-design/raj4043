# Quick Start Examples: Nokia PM Copilot Frontend Integration

**Quick reference guide with copy-paste ready code examples**

---

## Table of Contents

1. [JavaScript/Fetch Examples](#javascriptfetch-examples)
2. [Python (for Backend Teams)](#python-for-backend-teams)
3. [cURL Examples](#curl-examples)
4. [Common Scenarios](#common-scenarios)
5. [Troubleshooting](#troubleshooting)

---

## JavaScript/Fetch Examples

### **1. Complete Query Workflow**

```javascript
// Helper function to parse SSE stream
async function* parseSSEStream(response) {
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n\n");

    for (let i = 0; i < lines.length - 1; i++) {
      const event = lines[i];
      if (event.startsWith("event:")) {
        const [eventLine, dataLine] = event.split("\n");
        const eventType = eventLine.replace("event: ", "");
        const data = JSON.parse(dataLine.replace("data: ", ""));
        yield { eventType, data };
      }
    }

    buffer = lines[lines.length - 1];
  }
}

// Main workflow
async function main() {
  // Step 1: Create session
  const sessionResponse = await fetch("/api/v1/assistant/session", {
    method: "POST",
  });
  const { session_id } = await sessionResponse.json();
  console.log("✓ Session created:", session_id);

  // Step 2: Submit query
  const queryResponse = await fetch("/api/v1/assistant/query", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      session_id,
      username: "john.doe",
      query: "How many active New Site Build projects are in the Northeast region?",
      is_follow_up: false,
    }),
  });

  // Step 3: Process SSE events
  for await (const { eventType, data } of parseSSEStream(queryResponse)) {
    console.log(`[${eventType}]`, data);

    switch (eventType) {
      case "search_keywords":
        console.log("📌 Keywords:", data.keyword_names);
        break;
      case "search_kpis":
        console.log("📊 KPIs:", data.kpi_names);
        break;
      case "search_qb":
        console.log("❓ Questions:", data.qb_names);
        break;
      case "hitl_complete":
        if (data.query_type === "general") {
          console.log("💬 Response:", data.general_response);
        } else if (!data.ready_for_sql) {
          console.log("🤔 Clarification needed:", data.clarifying_message);
        }
        break;
      case "sql_complete":
        if (data.success) {
          console.log("✅ SQL executed successfully");
          console.log("SQL:", data.generated_sql);
          console.log("Results:", JSON.parse(data.table_json));
        }
        break;
      case "error":
        console.error("❌ Error:", data.message);
        break;
    }
  }
}

main();
```

---

### **2. Voice Input → Query Flow**

```javascript
class VoiceQueryHelper {
  constructor(sessionId) {
    this.sessionId = sessionId;
    this.mediaRecorder = null;
    this.ws = null;
  }

  async startVoiceInput() {
    // Get microphone
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    this.mediaRecorder = new MediaRecorder(stream, {
      mimeType: "audio/webm;codecs=opus",
    });

    // Connect WebSocket
    this.ws = new WebSocket(
      "ws://localhost:8000/api/v1/voice/ws/transcribe?language=en-US"
    );

    let transcribedText = "";

    this.ws.onmessage = (event) => {
      const msg = JSON.parse(event.data);

      if (msg.event === "recognizing") {
        console.log("🎤 Transcribing:", msg.text);
        document.getElementById("transcription").textContent = msg.text;
      } else if (msg.event === "recognized") {
        transcribedText = msg.text;
      } else if (msg.event === "done") {
        this.ws.close();
        this.mediaRecorder.stop();
        console.log("✓ Transcription complete:", transcribedText);

        // Automatically submit as query
        return this.submitQuery(transcribedText);
      }
    };

    // Send audio chunks
    this.mediaRecorder.ondataavailable = (event) => {
      if (this.ws.readyState === WebSocket.OPEN && event.data.size > 0) {
        this.ws.send(event.data);
      }
    };

    this.mediaRecorder.start(250);
  }

  stopVoiceInput() {
    if (this.mediaRecorder) {
      this.mediaRecorder.stop();
    }
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send("STOP");
    }
  }

  async submitQuery(queryText, isFollowUp = false, followUpChatId = null) {
    const response = await fetch("/api/v1/assistant/query", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        session_id: this.sessionId,
        username: "john.doe",
        query: queryText,
        is_follow_up: isFollowUp,
        follow_up_chat_id: followUpChatId,
      }),
    });

    return response;
  }
}

// Usage
const helper = new VoiceQueryHelper(sessionId);
document.getElementById("startBtn").onclick = () => helper.startVoiceInput();
document.getElementById("stopBtn").onclick = () => helper.stopVoiceInput();
```

---

### **3. Chat History & Feedback**

```javascript
// Get chat history
async function getChatHistory(sessionId) {
  const response = await fetch(`/api/v1/chat/history/${sessionId}`);
  return response.json();
}

// Display chat history
async function displayChatHistory(sessionId) {
  const { messages } = await getChatHistory(sessionId);

  messages.forEach((msg) => {
    const turn = document.createElement("div");
    turn.className = "chat-turn";
    turn.innerHTML = `
      <div class="user-query">${msg.user_query}</div>
      ${
        msg.sql_generated
          ? `<div class="sql-code">
          SQL: ${msg.sql_generated}
          <button onclick="submitFeedback('${msg.unique_chat_id}', 5, 'Great!')">👍</button>
          <button onclick="submitFeedback('${msg.unique_chat_id}', 1, 'Incorrect')">👎</button>
        </div>`
          : ""
      }
      ${
        msg.table_json
          ? `<table class="results">
          ${renderTableFromJSON(JSON.parse(msg.table_json))}
        </table>`
          : ""
      }
    `;
    document.getElementById("chat-container").appendChild(turn);
  });
}

// Submit feedback
async function submitFeedback(uniqueChatId, rating, comment) {
  const sessionId = localStorage.getItem("sessionId");
  const response = await fetch("/api/v1/feedback/submit", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      session_id: sessionId,
      unique_chat_id: uniqueChatId,
      username: "john.doe",
      rating,
      is_positive: rating >= 4,
      comment,
    }),
  });
  const result = await response.json();
  console.log("Feedback submitted:", result);
}

// Get feedback stats
async function getFeedbackStats(sessionId) {
  const response = await fetch(`/api/v1/feedback/stats?session_id=${sessionId}`);
  return response.json();
}
```

---

## Python (for Backend Teams)

### **1. Basic Query Submission**

```python
import aiohttp
import asyncio
import json

async def submit_query(session_id: str, query: str):
    """Submit a query and receive SSE stream."""

    async with aiohttp.ClientSession() as session:
        payload = {
            "session_id": session_id,
            "username": "john.doe",
            "query": query,
            "is_follow_up": False,
        }

        async with session.post(
            "http://localhost:8000/api/v1/assistant/query",
            json=payload,
        ) as response:
            async for line in response.content:
                if line.startswith(b"event:"):
                    event_type = line.decode().replace("event: ", "").strip()
                    data_line = await response.content.readline()
                    data = json.loads(data_line.decode().replace("data: ", ""))
                    print(f"[{event_type}] {data}")

# Usage
asyncio.run(submit_query(
    "550e8400-e29b-41d4-a716-446655440000",
    "Show active New Site Build projects by region"
))
```

### **2. Upload Audio File**

```python
import aiohttp
import asyncio

async def transcribe_audio(audio_path: str, language: str = "en-US"):
    """Transcribe an audio file."""

    with open(audio_path, "rb") as f:
        audio_data = f.read()

    async with aiohttp.ClientSession() as session:
        data = aiohttp.FormData()
        data.add_field("audio", audio_data, filename=audio_path)
        data.add_field("language", language)

        async with session.post(
            "http://localhost:8000/api/v1/voice/transcribe",
            data=data,
        ) as response:
            return await response.json()

# Usage
result = asyncio.run(transcribe_audio("recording.wav"))
print("Transcribed text:", result["text"])
```

### **3. WebSocket Voice Input**

```python
import asyncio
import websockets
import json

async def voice_input_websocket():
    """Connect to voice WebSocket and send audio chunks."""

    uri = "ws://localhost:8000/api/v1/voice/ws/transcribe?language=en-US"

    async with websockets.connect(uri) as websocket:
        # Read audio file
        with open("recording.wav", "rb") as f:
            audio_chunks = [f.read(3200) for _ in range(100)]

        # Send audio
        for chunk in audio_chunks:
            await websocket.send(chunk)

        # Receive transcription
        while True:
            msg = await websocket.recv()
            data = json.loads(msg)

            if data.get("event") == "recognizing":
                print("Partial:", data.get("text"))
            elif data.get("event") == "recognized":
                print("Final:", data.get("text"))
            elif data.get("event") in ("done", "error"):
                break

# Usage
asyncio.run(voice_input_websocket())
```

---

## cURL Examples

### **1. Create Session**

```bash
curl -X POST http://localhost:8000/api/v1/assistant/session \
  -H "Content-Type: application/json"

# Output:
# {"session_id": "550e8400-e29b-41d4-a716-446655440000"}
```

### **2. Submit Query (with SSE streaming)**

```bash
curl -N -X POST http://localhost:8000/api/v1/assistant/query \
  -H "Content-Type: application/json" \
  -d '{
    "session_id": "550e8400-e29b-41d4-a716-446655440000",
    "username": "john.doe",
    "query": "How many active New Site Build projects are in the Northeast region?",
    "is_follow_up": false
  }'

# Output (SSE events):
# event: search_keywords
# data: {"keyword_names": ["New Site Build", "Site", "Region"], ...}
#
# event: search_kpis
# data: {"kpi_names": ["Active Project Count"], ...}
#
# ... (more events)
```

### **3. Get Chat History**

```bash
curl http://localhost:8000/api/v1/chat/history/550e8400-e29b-41d4-a716-446655440000 \
  -H "Accept: application/json"

# Output:
# {"session_id": "550e8400-e29b-41d4-a716-446655440000", "messages": [...]}
```

### **4. Submit Feedback**

```bash
curl -X POST http://localhost:8000/api/v1/feedback/submit \
  -H "Content-Type: application/json" \
  -d '{
    "session_id": "550e8400-e29b-41d4-a716-446655440000",
    "unique_chat_id": "660e8400-e29b-41d4-a716-446655440001",
    "username": "john.doe",
    "rating": 5,
    "is_positive": true,
    "comment": "Excellent results!"
  }'

# Output:
# {"feedback_id": "880e8400-e29b-41d4-a716-446655440003", "status": "submitted"}
```

### **5. Upload Audio File**

```bash
curl -X POST http://localhost:8000/api/v1/voice/transcribe \
  -F "audio=@recording.wav" \
  -F "language=en-US"

# Output:
# {"text": "Show me the Northeast region details", "status": "success", ...}
```

---

## Common Scenarios

### **Scenario A: General Question (No SQL Needed)**

```javascript
// User asks: "What can you help me with?"

// 1. Query submitted
const response = await fetch("/api/v1/assistant/query", {
  method: "POST",
  body: JSON.stringify({
    session_id: "...",
    username: "john.doe",
    query: "What can you help me with?",
    is_follow_up: false,
  }),
});

// 2. Events received:
// - search_keywords (finds nothing)
// - search_kpis (finds nothing)
// - search_qb (finds nothing)
// - search_complete (status: "no_results")
// - hitl_start
// - hitl_complete (query_type: "general")
//   → Display: "I'm the Nokia PM Copilot, your AI assistant for telecom..."

// 3. Database saved, conversation ends
```

---

### **Scenario B: Data Question Needs Clarification**

```javascript
// User asks: "Show me project status"

// 1. Query submitted
const response = await fetch("/api/v1/assistant/query", {
  method: "POST",
  body: JSON.stringify({
    session_id: "...",
    username: "john.doe",
    query: "Show me project status",
    is_follow_up: false,
  }),
});

// 2. Events received:
// - search_keywords (finds: "project")
// - search_kpis (finds: "Project Status KPI")
// - search_qb (finds: 2 similar questions)
// - search_complete (status: "ok")
// - hitl_start
// - hitl_complete (query_type: "data", ready_for_sql: false)
//   → Display clarifying_message: "I found 'project' but need clarification:
//     Are you asking by region, by market, or by specific status?"

// 3. User provides follow-up
const followUpResponse = await fetch("/api/v1/assistant/query", {
  method: "POST",
  body: JSON.stringify({
    session_id: "...",
    username: "john.doe",
    query: "By region please",
    is_follow_up: true,
    follow_up_chat_id: "660e8400-e29b-41d4-a716-446655440001",
  }),
});

// 4. Second attempt with clarification context
// - HITL agent receives previous query + clarifying message
// - Determines query is now ready for SQL
// - SQL agent generates and executes query
// - Results displayed as table
```

---

### **Scenario C: Ready for SQL Directly**

```javascript
// User asks specific question: "Count New Site Build projects in Northeast region"

// 1. Query submitted
const response = await fetch("/api/v1/assistant/query", {
  method: "POST",
  body: JSON.stringify({
    session_id: "...",
    username: "john.doe",
    query: "Count New Site Build projects in Northeast region",
    is_follow_up: false,
  }),
});

// 2. Events received:
// - search_keywords (finds: "New Site Build", "Region")
// - search_kpis (finds: multiple KPIs)
// - search_qb (finds: reference questions)
// - search_complete (status: "ok")
// - hitl_start
// - hitl_complete (query_type: "data", ready_for_sql: true)
//   → Proceed directly to SQL generation

// 3. SQL Events:
// - sql_start
// - sql_complete (success: true, table_json: "[...]")
//   → Display table with results

// 4. Database saved
// - Chat history persisted
// - SQL query stored for reference
```

---

### **Scenario D: Collect Feedback**

```javascript
// After displaying results...

async function collectFeedback(sessionId, uniqueChatId) {
  // Show rating dialog
  const rating = await showRatingDialog(); // 1-5

  if (rating >= 4) {
    // Positive feedback
    const response = await fetch("/api/v1/feedback/submit", {
      method: "POST",
      body: JSON.stringify({
        session_id: sessionId,
        unique_chat_id: uniqueChatId,
        username: "john.doe",
        rating: rating,
        is_positive: true,
        comment: "Excellent results!",
      }),
    });
  } else {
    // Negative feedback - request comment
    const comment = await showCommentDialog();
    const response = await fetch("/api/v1/feedback/submit", {
      method: "POST",
      body: JSON.stringify({
        session_id: sessionId,
        unique_chat_id: uniqueChatId,
        username: "john.doe",
        rating: rating,
        is_positive: false,
        comment: comment,
      }),
    });
  }

  // Get stats
  const stats = await fetch(
    `/api/v1/feedback/stats?session_id=${sessionId}`
  ).then((r) => r.json());
  console.log("Feedback stats:", stats);
}
```

---

## Troubleshooting

### **Issue: "No matching keywords, KPIs, or questions found"**

**Cause:** Search returned empty results
**Solution:**
- Try more specific terminology
- Use domain-specific keywords (e.g., "On-Air Completion Rate" instead of "completion")
- Add context (e.g., region name, project type)

```javascript
// ❌ Too vague
"Tell me about projects"

// ✅ Better
"How many active New Site Build projects are in the Northeast region?"
```

---

### **Issue: SSE stream connection closes prematurely**

**Cause:** Network timeout or large response
**Solution:**
- Increase HTTP timeout on frontend
- Check server logs for errors
- Verify session is valid

```javascript
// Add timeout handling
const controller = new AbortController();
const timeout = setTimeout(() => controller.abort(), 30000); // 30s

try {
  const response = await fetch("/api/v1/assistant/query", {
    method: "POST",
    body: JSON.stringify(payload),
    signal: controller.signal,
  });
} finally {
  clearTimeout(timeout);
}
```

---

### **Issue: WebSocket connection fails**

**Cause:** ffmpeg not installed, Azure Speech key invalid, or CORS issue
**Solution:**
- Check server has ffmpeg installed: `ffmpeg -version`
- Verify `SPEECH_KEY_1` environment variable is set
- Ensure WebSocket URL is correct (ws:// not http://)
- Check browser console for specific error

```javascript
ws.onerror = (event) => {
  console.error("WebSocket error:", event);
  // Check server logs for details
};

ws.onclose = (event) => {
  console.log("WebSocket closed:", event.code, event.reason);
};
```

---

### **Issue: Results table doesn't render**

**Cause:** `table_json` field is empty or malformed
**Solution:**
- Check `sql_complete` event has `success: true`
- Verify `table_json` is valid JSON array
- Handle empty result sets gracefully

```javascript
if (data.success && data.table_json) {
  try {
    const rows = JSON.parse(data.table_json);
    if (rows.length === 0) {
      showMessage("Query returned no results");
    } else {
      renderTable(rows);
    }
  } catch (error) {
    console.error("Failed to parse table_json:", error);
  }
}
```

---

### **Issue: Follow-up query doesn't use previous context**

**Cause:** `follow_up_chat_id` is not set or incorrect
**Solution:**
- Store `unique_chat_id` from previous `hitl_complete` event
- Pass it correctly in follow-up request
- Verify `is_follow_up: true` is set

```javascript
let lastChatId = null;

// Store from previous response
if (event.type === "hitl_complete") {
  lastChatId = event.data.unique_chat_id;
}

// Use in follow-up
await submitQuery({
  is_follow_up: true,
  follow_up_chat_id: lastChatId, // ✅ Must be set
});
```

---

### **Issue: "SPEECH_KEY_1 is not configured"**

**Cause:** Azure Speech Services credentials not set
**Solution:**
- Set environment variables:
  ```bash
  export SPEECH_KEY_1="your-azure-speech-key"
  export SPEECH_REGION="eastus"  # or your region
  ```
- Restart the server
- Verify in backend logs: `SPEECH_KEY_1 is configured`

---

## Support & Resources

- **API Documentation:** `/docs` (Swagger UI)
- **Backend Team:** Contact for infrastructure/config issues
- **Feedback:** Use `/feedback/submit` endpoint to report issues

---

**Last Updated:** February 2026
**Questions?** Check the main FRONTEND_INTEGRATION_GUIDE.md for detailed documentation.
