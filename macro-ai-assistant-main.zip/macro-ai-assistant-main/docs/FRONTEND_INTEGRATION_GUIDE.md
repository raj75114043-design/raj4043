# Frontend Integration Guide: Nokia PM Copilot AI Assistant

**Author:** AI Assistant Team
**Version:** 1.0
**Last Updated:** February 2026

---

## Table of Contents

1. [Overview](#overview)
2. [Core API Endpoints](#core-api-endpoints)
3. [WebSocket Voice-to-Text Integration](#websocket-voice-to-text-integration)
4. [Chat History API](#chat-history-api)
5. [Feedback API](#feedback-api)
6. [Complete Integration Flow](#complete-integration-flow)
7. [Frontend Implementation Examples](#frontend-implementation-examples)
8. [Error Handling & Best Practices](#error-handling--best-practices)

---

## Overview

The Nokia PM Copilot AI Assistant provides a **multi-turn conversational interface** for querying telecom project management databases. The system supports:

- **Voice-to-Text Transcription** via Azure Speech Services (WebSocket real-time or REST streaming)
- **AI Query Processing** through a Human-In-The-Loop (HITL) validation pipeline
- **SQL Generation & Execution** for data queries
- **Conversation History Tracking** with multi-session support
- **User Feedback Collection** for continuous improvement

### Architecture Overview

```
Frontend (Browser/Mobile)
    ↓
[Voice Input / Text Query]
    ↓ WebSocket or REST
[API Layer]
    ├─ /voice/ws/transcribe (WebSocket)
    ├─ /voice/transcribe/stream (SSE)
    ├─ /assistant/query (SSE stream)
    ├─ /chat/history/* (Chat History)
    └─ /feedback/submit (Feedback)
    ↓
[Backend Services]
    ├─ Parallel Search (Keywords, KPIs, Question Bank)
    ├─ HITL Validation Agent
    ├─ SQL Generation & Execution Agent
    └─ Database Persistence
```

---

## Core API Endpoints

### 1. Session Management

#### **Create a New Chat Session**

```http
POST /api/v1/assistant/session
Content-Type: application/json
```

**Response:**
```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000"
}
```

**Usage:**
- Call this endpoint when the user logs in or clicks "New Chat"
- Store the `session_id` in your frontend state for the entire chat session
- Pass it to all subsequent API calls

---

### 2. Main Query Endpoint (Server-Sent Events)

#### **Submit a Query and Stream Results**

```http
POST /api/v1/assistant/query
Content-Type: application/json

{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "username": "john.doe",
  "query": "Show me the total number of active New Site Build projects by region",
  "is_follow_up": false,
  "follow_up_chat_id": null
}
```

**Key Fields:**
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `session_id` | string | ✓ | Session identifier from `/session` endpoint |
| `username` | string | ✓ | User identifier (for audit & personalization) |
| `query` | string | ✓ | Natural language question (min 1 char) |
| `is_follow_up` | bool | ✗ | Set to `true` for follow-up questions |
| `follow_up_chat_id` | string | ✗ | Required when `is_follow_up=true` |

**Response Type:** Server-Sent Events (SSE)

The endpoint streams results as they become available. Each event contains:

```
event: <event_type>
data: <JSON_payload>

```

#### **Event Types & Flow**

**1. Search Events (Keywords, KPIs, Question Bank)**

```json
{
  "event": "search_keywords",
  "data": {
    "keyword_names": ["New Site Build", "Site", "EC"],
    "keyword_ids": [396956, 845461, 768015],
    "found": true,
    "message": ""
  }
}
```

```json
{
  "event": "search_kpis",
  "data": {
    "kpi_names": ["Site Completion Cycle Time", "Civil Start Delay"],
    "kpi_ids": ["487623", "607143"],
    "found": true,
    "message": ""
  }
}
```

```json
{
  "event": "search_qb",
  "data": {
    "qb_names": ["List high cycle time sites region wise", "List WIP sites"],
    "qb_ids": ["662881", "654321"],
    "found": true,
    "message": ""
  }
}
```

**2. Search Complete Event**

```json
{
  "event": "search_complete",
  "data": {
    "status": "ok",  // "ok", "partial", or "no_results"
    "keyword_names": ["New Site Build", "Site", "EC"],
    "keyword_ids": [396956, 845461, 768015],
    "kpi_names": ["Site Completion Cycle Time"],
    "kpi_ids": ["487623"],
    "qb_names": ["List high cycle time sites region wise"],
    "qb_ids": ["662881"],
    "search_duration_s": 2.341
  }
}
```

**3. HITL Processing Events**

```json
{
  "event": "hitl_start",
  "data": {
    "unique_chat_id": "660e8400-e29b-41d4-a716-446655440001",
    "hitl_id": "770e8400-e29b-41d4-a716-446655440002",
    "message": "Analysing your query…"
  }
}
```

**4. HITL Response - Scenario 1: General Query**

```json
{
  "event": "hitl_complete",
  "data": {
    "unique_chat_id": "660e8400-e29b-41d4-a716-446655440001",
    "hitl_id": "770e8400-e29b-41d4-a716-446655440002",
    "query_type": "general",
    "ready_for_sql": false,
    "general_response": "I'm the Nokia PM Copilot, your AI assistant for telecom project management. I can help you query KPIs, project status, site information, and more.",
    "hitl_duration_s": {"classify_query": {...}, ...}
  }
}
```

**Display general_response to user and end conversation.**

**5. HITL Response - Scenario 2: Data Question Needs Clarification**

```json
{
  "event": "hitl_complete",
  "data": {
    "unique_chat_id": "660e8400-e29b-41d4-a716-446655440001",
    "hitl_id": "770e8400-e29b-41d4-a716-446655440002",
    "query_type": "data",
    "ready_for_sql": false,
    "clarifying_message": "I found 'New Site Build' and 'Site' in your query, but I need clarification: Are you asking for count by region, by market, or by project status? Please refine your question.",
    "keyword_names": ["New Site Build", "Site"],
    "kpi_names": [],
    "qb_names": ["List CxS to On Air high cycle time sites region wise"]
  }
}
```

**Display clarifying_message to user. Prompt for a follow-up query.**

**When user provides follow-up:**
```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "username": "john.doe",
  "query": "Count by region please",
  "is_follow_up": true,
  "follow_up_chat_id": "660e8400-e29b-41d4-a716-446655440001"
}
```

**6. HITL Response - Scenario 3: Data Question Ready for SQL**

```json
{
  "event": "hitl_complete",
  "data": {
    "unique_chat_id": "660e8400-e29b-41d4-a716-446655440001",
    "hitl_id": "770e8400-e29b-41d4-a716-446655440002",
    "query_type": "data",
    "ready_for_sql": true,
    "keyword_names": ["New Site Build", "Site", "Region"],
    "kpi_names": ["Active Project Count"],
    "qb_names": ["List projects by region"]
  }
}
```

**7. SQL Generation Event**

```json
{
  "event": "sql_start",
  "data": {
    "unique_chat_id": "660e8400-e29b-41d4-a716-446655440001",
    "message": "Generating SQL query…"
  }
}
```

**8. SQL Execution Results**

```json
{
  "event": "sql_complete",
  "data": {
    "unique_chat_id": "660e8400-e29b-41d4-a716-446655440001",
    "success": true,
    "generated_sql": "SELECT rgn_region, COUNT(*) as project_count FROM pwc_macro_staging_schema.ndpd_mbt_tmobile_macro_combined WHERE pj_project_type = 'N-NSD Macro' GROUP BY rgn_region ORDER BY project_count DESC LIMIT 200;",
    "table_json": "[{\"rgn_region\": \"Northeast\", \"project_count\": 45}, {\"rgn_region\": \"Southeast\", \"project_count\": 38}, ...]",
    "error": "",
    "node_timestamps": {"fetch_world_view": {...}, "generate_sql": {...}, ...}
  }
}
```

**Render table_json as a data table for the user.**

**9. Database Saved Event**

```json
{
  "event": "db_saved",
  "data": {
    "unique_chat_id": "660e8400-e29b-41d4-a716-446655440001",
    "message": "Chat history saved."
  }
}
```

**10. Error Events**

```json
{
  "event": "error",
  "data": {
    "message": "Search failed: Connection timeout"
  }
}
```

---

## WebSocket Voice-to-Text Integration

### Overview

The system provides **real-time speech-to-text** using Azure Cognitive Services via WebSocket. The browser captures audio and sends it to the server, which returns transcription results in real-time.

### Browser Setup

#### **1. Request Microphone Permission**

```javascript
async function requestMicrophoneAccess() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    return stream;
  } catch (error) {
    console.error("Microphone access denied:", error);
  }
}
```

#### **2. Initialize MediaRecorder**

```javascript
const stream = await requestMicrophoneAccess();
const mediaRecorder = new MediaRecorder(stream, {
  mimeType: "audio/webm;codecs=opus"
});

const audioChunks = [];
mediaRecorder.ondataavailable = (event) => {
  audioChunks.push(event.data);
};

mediaRecorder.onstop = async () => {
  const audioBlob = new Blob(audioChunks, { type: "audio/webm" });
  // Send to server
};

// Start recording with 250ms chunks
mediaRecorder.start(250);
```

### WebSocket Connection

#### **Connect to the WebSocket Endpoint**

```javascript
const language = "en-US"; // BCP-47 language tag
const audioFormat = "webm"; // "webm" (default) or "pcm"

const ws = new WebSocket(
  `ws://your-api-host/api/v1/voice/ws/transcribe?language=${language}&audio_format=${audioFormat}`
);
```

#### **Handle WebSocket Events**

```javascript
ws.onopen = () => {
  console.log("WebSocket connected");
  // Start streaming audio
};

ws.onmessage = (event) => {
  const message = JSON.parse(event.data);

  if (message.event === "recognizing") {
    // Partial result (updates as user speaks)
    console.log("Partial:", message.text);
    updateTranscriptionPreview(message.text);
  }
  else if (message.event === "recognized") {
    // Final result for this segment
    console.log("Final:", message.text);
    appendToTranscription(message.text);
  }
  else if (message.event === "done") {
    console.log("Transcription complete");
    ws.close();
  }
  else if (message.event === "error") {
    console.error("Transcription error:", message.error_details);
    ws.close();
  }
};

ws.onerror = (error) => {
  console.error("WebSocket error:", error);
};
```

#### **Send Audio Data**

```javascript
mediaRecorder.ondataavailable = (event) => {
  if (ws.readyState === WebSocket.OPEN && event.data.size > 0) {
    ws.send(event.data); // Send binary audio chunk
  }
};
```

#### **Stop Recording**

```javascript
function stopRecording() {
  mediaRecorder.stop();

  // Optionally send "STOP" command to force finalization
  if (ws.readyState === WebSocket.OPEN) {
    ws.send("STOP");
  }
}
```

### Alternative: REST Audio Transcription (Without WebSocket)

If you prefer not to use WebSocket, you can upload a complete audio file:

#### **Upload Audio File**

```http
POST /api/v1/voice/transcribe
Content-Type: multipart/form-data

audio: <binary audio file>
language: en-US
```

**Supported formats:** WAV, MP3, OGG, WEBM

**Response:**
```json
{
  "text": "Show me the total number of active New Site Build projects by region",
  "status": "success",
  "language": "en-US",
  "duration_seconds": 5.234
}
```

#### **Stream Results with SSE**

```http
POST /api/v1/voice/transcribe/stream
Content-Type: multipart/form-data

audio: <binary audio file>
language: en-US
```

**Response:** Server-Sent Events

```
event: recognizing
data: {"text": "Show me", "offset": 0, "duration": 1000}

event: recognized
data: {"text": "Show me the total", "offset": 500, "duration": 2000}

event: done
data: {}
```

---

## Chat History API

### **Get Chat History for a Session**

```http
GET /api/v1/chat/history/{session_id}
```

**Response:**
```json
{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "messages": [
    {
      "unique_chat_id": "660e8400-e29b-41d4-a716-446655440001",
      "session_id": "550e8400-e29b-41d4-a716-446655440000",
      "hitl_id": "770e8400-e29b-41d4-a716-446655440002",
      "username": "john.doe",
      "user_query": "Show me active New Site Build projects by region",
      "ai_assistant_output": null,
      "sql_generated": "SELECT rgn_region, COUNT(*) ...",
      "table_json": "[{\"rgn_region\": \"Northeast\", ...}]",
      "kpi_identified": "Active Project Count, Site Completion Cycle Time",
      "keywords_indentifed": "New Site Build, Site, Region",
      "qb_indentifed": "List projects by region",
      "is_follow_up": false,
      "created_at": "2026-02-24T10:30:45.123Z"
    },
    {
      "unique_chat_id": "660e8400-e29b-41d4-a716-446655440003",
      "session_id": "550e8400-e29b-41d4-a716-446655440000",
      "hitl_id": "770e8400-e29b-41d4-a716-446655440004",
      "username": "john.doe",
      "user_query": "Show the Southeast region details",
      "sql_generated": "SELECT * FROM ndpd_mbt_tmobile_macro_combined WHERE rgn_region = 'Southeast' ...",
      "table_json": "[{...}, {...}]",
      "is_follow_up": true,
      "created_at": "2026-02-24T10:32:10.456Z"
    }
  ]
}
```

### **Get a Single Chat Turn**

```http
GET /api/v1/chat/turn/{unique_chat_id}
```

### **List Recent Chat Sessions**

```http
GET /api/v1/chat/sessions?username=john.doe&limit=20
```

**Response:**
```json
[
  {
    "session_id": "550e8400-e29b-41d4-a716-446655440000",
    "username": "john.doe",
    "started_at": "2026-02-24T09:00:00.000Z",
    "last_message_at": "2026-02-24T10:45:30.123Z",
    "turn_count": 8
  },
  {
    "session_id": "550e8400-e29b-41d4-a716-446655440005",
    "username": "john.doe",
    "started_at": "2026-02-23T14:20:00.000Z",
    "last_message_at": "2026-02-23T15:10:45.789Z",
    "turn_count": 3
  }
]
```

---

## Feedback API

### **Submit Feedback for a Chat Turn**

```http
POST /api/v1/feedback/submit
Content-Type: application/json

{
  "session_id": "550e8400-e29b-41d4-a716-446655440000",
  "unique_chat_id": "660e8400-e29b-41d4-a716-446655440001",
  "username": "john.doe",
  "rating": 5,
  "is_positive": true,
  "comment": "Great! The SQL query was accurate and fast."
}
```

**Fields:**
| Field | Type | Valid Values | Description |
|-------|------|--------------|-------------|
| `session_id` | string | - | Session identifier |
| `unique_chat_id` | string | - | Chat turn being rated |
| `username` | string | - | User identifier |
| `rating` | integer | 1-5 | Likert scale rating (optional) |
| `is_positive` | boolean | true/false | Thumbs up/down (optional) |
| `comment` | string | - | Free-text feedback (optional) |

**Response:**
```json
{
  "feedback_id": "880e8400-e29b-41d4-a716-446655440003",
  "status": "submitted"
}
```

### **Get Feedback for a Chat Turn**

```http
GET /api/v1/feedback/chat/{unique_chat_id}
```

**Response:**
```json
[
  {
    "feedback_id": "880e8400-e29b-41d4-a716-446655440003",
    "session_id": "550e8400-e29b-41d4-a716-446655440000",
    "unique_chat_id": "660e8400-e29b-41d4-a716-446655440001",
    "username": "john.doe",
    "rating": 5,
    "is_positive": true,
    "comment": "Great! The SQL query was accurate and fast.",
    "created_at": "2026-02-24T10:35:00.789Z"
  }
]
```

### **Get Feedback Statistics**

```http
GET /api/v1/feedback/stats?session_id=550e8400-e29b-41d4-a716-446655440000
```

**Response:**
```json
{
  "total": 8,
  "avg_rating": 4.5,
  "thumbs_up": 6,
  "thumbs_down": 2
}
```

---

## Complete Integration Flow

### **Full Chat Workflow**

```mermaid
sequenceDiagram
    Frontend->>Backend: 1. POST /session → session_id
    rect rgb(0, 100, 200)
        Frontend->>Backend: 2. POST /query (SSE)
        Backend->>Backend: Parallel search (keywords, KPIs, QBs)
        Backend-->>Frontend: search_keywords event
        Backend-->>Frontend: search_kpis event
        Backend-->>Frontend: search_qb event
        Backend-->>Frontend: search_complete event
    end

    rect rgb(0, 150, 100)
        Backend->>Backend: HITL validation
        Backend-->>Frontend: hitl_start event
        Backend-->>Frontend: hitl_complete event
    end

    alt Query is General (Scenario 1)
        Backend-->>Frontend: Display general_response
        Backend->>DB: Save chat (general)
        Backend-->>Frontend: db_saved event
    else Query needs clarification (Scenario 2)
        Backend-->>Frontend: Display clarifying_message
        Backend->>DB: Save chat (pending)
        Frontend->>Backend: 3. POST /query (is_follow_up=true)
        note over Frontend,Backend: Repeat flow with follow_up_chat_id
    else Query ready for SQL (Scenario 3)
        rect rgb(150, 100, 0)
            Backend->>Backend: SQL generation
            Backend-->>Frontend: sql_start event
            Backend->>Database: Execute SQL query
            Backend-->>Frontend: sql_complete event (with table_json)
        end
        Backend->>DB: Save chat + SQL results
        Backend-->>Frontend: db_saved event
    end

    Frontend->>Backend: 4. POST /feedback/submit (optional)
    Backend->>DB: Save feedback
```

---

## Frontend Implementation Examples

### **React Hook: useAIAssistant**

```jsx
import { useEffect, useState, useRef } from "react";

function useAIAssistant(sessionId) {
  const [events, setEvents] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const submitQuery = async (query, isFollowUp = false, followUpChatId = null) => {
    setIsLoading(true);
    setError(null);
    setEvents([]);

    const payload = {
      session_id: sessionId,
      username: "john.doe",
      query,
      is_follow_up: isFollowUp,
      follow_up_chat_id: followUpChatId,
    };

    try {
      const response = await fetch("/api/v1/assistant/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n\n");

        for (let i = 0; i < lines.length - 1; i++) {
          const [eventLine, dataLine] = lines[i].split("\n");
          if (eventLine && dataLine) {
            const eventType = eventLine.replace("event: ", "");
            const data = JSON.parse(dataLine.replace("data: ", ""));

            setEvents((prev) => [...prev, { type: eventType, data }]);

            if (eventType === "error" || eventType === "db_saved") {
              setIsLoading(false);
            }
          }
        }

        buffer = lines[lines.length - 1];
      }
    } catch (err) {
      setError(err.message);
      setIsLoading(false);
    }
  };

  return { events, isLoading, error, submitQuery };
}

export default useAIAssistant;
```

### **React Component: ChatInterface**

```jsx
import React, { useState, useEffect } from "react";
import useAIAssistant from "./useAIAssistant";

function ChatInterface({ sessionId }) {
  const { events, isLoading, error, submitQuery } = useAIAssistant(sessionId);
  const [query, setQuery] = useState("");
  const [chatHistory, setChatHistory] = useState([]);
  const [lastUniqueChatId, setLastUniqueChatId] = useState(null);
  const [clarifyingMessage, setClarifyingMessage] = useState(null);
  const [tableData, setTableData] = useState(null);

  // Process events
  useEffect(() => {
    for (const event of events) {
      if (event.type === "hitl_complete") {
        const hitl = event.data;
        if (hitl.query_type === "general") {
          setChatHistory((prev) => [
            ...prev,
            { role: "assistant", content: hitl.general_response, type: "general" },
          ]);
        } else if (!hitl.ready_for_sql) {
          setClarifyingMessage(hitl.clarifying_message);
          setLastUniqueChatId(hitl.unique_chat_id);
        }
      } else if (event.type === "sql_complete") {
        const sql = event.data;
        if (sql.success && sql.table_json) {
          setTableData(JSON.parse(sql.table_json));
          setChatHistory((prev) => [
            ...prev,
            { role: "assistant", content: sql.table_json, type: "table" },
          ]);
        }
      }
    }
  }, [events]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    setChatHistory((prev) => [...prev, { role: "user", content: query }]);
    setQuery("");

    await submitQuery(query);
  };

  const handleFollowUp = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    setChatHistory((prev) => [...prev, { role: "user", content: query }]);
    setClarifyingMessage(null);
    setQuery("");

    await submitQuery(query, true, lastUniqueChatId);
  };

  return (
    <div className="chat-container">
      <div className="messages">
        {chatHistory.map((msg, idx) => (
          <div key={idx} className={`message ${msg.role}`}>
            {msg.type === "table" ? (
              <Table data={JSON.parse(msg.content)} />
            ) : (
              <p>{msg.content}</p>
            )}
          </div>
        ))}

        {isLoading && <p className="loading">Processing...</p>}
        {error && <p className="error">{error}</p>}
      </div>

      {clarifyingMessage ? (
        <div className="clarification">
          <p>{clarifyingMessage}</p>
          <form onSubmit={handleFollowUp}>
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Refine your question..."
            />
            <button type="submit">Submit Follow-up</button>
          </form>
        </div>
      ) : (
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ask a question..."
            disabled={isLoading}
          />
          <button type="submit" disabled={isLoading}>
            Send
          </button>
        </form>
      )}
    </div>
  );
}

export default ChatInterface;
```

### **Voice Recording Component**

```jsx
import React, { useState, useRef } from "react";

function VoiceInput({ onTranscriptionComplete }) {
  const [isRecording, setIsRecording] = useState(false);
  const [transcription, setTranscription] = useState("");
  const mediaRecorderRef = useRef(null);
  const wsRef = useRef(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: "audio/webm;codecs=opus",
      });

      mediaRecorderRef.current = mediaRecorder;
      setIsRecording(true);
      setTranscription("");

      // Connect WebSocket
      const ws = new WebSocket(
        `ws://your-api-host/api/v1/voice/ws/transcribe?language=en-US`
      );

      ws.onmessage = (event) => {
        const message = JSON.parse(event.data);

        if (message.event === "recognizing") {
          setTranscription(message.text);
        } else if (message.event === "recognized") {
          setTranscription(message.text);
        } else if (message.event === "done" || message.event === "error") {
          ws.close();
          mediaRecorder.stop();
          setIsRecording(false);
          onTranscriptionComplete(transcription);
        }
      };

      wsRef.current = ws;

      mediaRecorder.ondataavailable = (event) => {
        if (ws.readyState === WebSocket.OPEN && event.data.size > 0) {
          ws.send(event.data);
        }
      };

      mediaRecorder.start(250);
    } catch (error) {
      console.error("Microphone access denied:", error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);

      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send("STOP");
      }
    }
  };

  return (
    <div className="voice-input">
      <button
        onClick={isRecording ? stopRecording : startRecording}
        className={isRecording ? "recording" : ""}
      >
        {isRecording ? "Stop Recording" : "Start Voice Input"}
      </button>
      {transcription && <p className="transcription">{transcription}</p>}
    </div>
  );
}

export default VoiceInput;
```

---

## Error Handling & Best Practices

### **HTTP Status Codes**

| Code | Meaning | Action |
|------|---------|--------|
| 200 | Success | Process response normally |
| 400 | Bad Request | Check request parameters (e.g., missing `session_id`) |
| 404 | Not Found | Resource doesn't exist (e.g., invalid `unique_chat_id`) |
| 500 | Server Error | Retry after delay; show user-friendly message |

### **SSE Error Handling**

```javascript
async function handleSSEStream(url, payload) {
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value);
      // Parse SSE events...
    }
  } catch (error) {
    console.error("Stream error:", error);
    // Show user-friendly error message
    showErrorNotification("Failed to process query. Please try again.");
  }
}
```

### **Retry Logic for Failed Queries**

```javascript
async function submitQueryWithRetry(sessionId, query, maxRetries = 3) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetch("/api/v1/assistant/query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          session_id: sessionId,
          username: "john.doe",
          query,
        }),
      });

      if (response.ok) {
        return response;
      }

      if (response.status === 500 && attempt < maxRetries) {
        // Exponential backoff
        await new Promise((resolve) =>
          setTimeout(resolve, Math.pow(2, attempt) * 1000)
        );
        continue;
      }

      throw new Error(`HTTP ${response.status}`);
    } catch (error) {
      if (attempt === maxRetries) {
        throw error;
      }
    }
  }
}
```

### **Session Management Best Practices**

1. **Create a session on login/app start** — Don't reuse sessions across user sessions
2. **Store session_id in localStorage** — Persist across page reloads
3. **Include username for audit** — Helps track feedback and usage patterns
4. **Handle session expiration** — Prompt user to start a new session if needed

```javascript
// Initialize session on app startup
async function initializeSession() {
  let sessionId = localStorage.getItem("sessionId");

  if (!sessionId) {
    const response = await fetch("/api/v1/assistant/session", {
      method: "POST",
    });
    const { session_id } = await response.json();
    sessionId = session_id;
    localStorage.setItem("sessionId", sessionId);
  }

  return sessionId;
}
```

### **Follow-Up Query Best Practices**

1. **Always pass `follow_up_chat_id`** when `is_follow_up=true`
2. **Store `unique_chat_id`** from previous responses for follow-ups
3. **Check `clarifying_message` field** — If present, prompt user for refinement
4. **Maintain conversation context** — Don't clear chat history between turns

```javascript
let lastUniqueChatId = null;

async function handleUserQuery(query) {
  const response = await fetch("/api/v1/assistant/query", {
    method: "POST",
    body: JSON.stringify({
      session_id: sessionId,
      username: "john.doe",
      query,
      is_follow_up: !!lastUniqueChatId,
      follow_up_chat_id: lastUniqueChatId,
    }),
  });

  // Process events...
  // Update lastUniqueChatId when hitl_complete event arrives
}
```

### **Feedback Collection**

Always collect feedback after SQL queries are executed:

```javascript
async function submitFeedback(sessionId, uniqueChatId, rating, comment) {
  const response = await fetch("/api/v1/feedback/submit", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      session_id: sessionId,
      unique_chat_id: uniqueChatId,
      username: "john.doe",
      rating, // 1-5
      is_positive: rating >= 4, // Auto-derive from rating
      comment,
    }),
  });

  if (response.ok) {
    console.log("Feedback submitted");
  }
}
```

---

## Conclusion

This guide provides everything needed to integrate the Nokia PM Copilot AI Assistant into your frontend application. For questions or additional features, contact the backend team.

**Key Takeaways:**
- Start with `/session` to create a session
- Use `/query` endpoint with SSE for the main workflow
- Handle follow-ups by storing `unique_chat_id` and setting `is_follow_up=true`
- Optionally use WebSocket voice-to-text for voice input
- Always collect feedback to improve model quality

---

**Document Version History**

| Date | Version | Changes |
|------|---------|---------|
| 2026-02-24 | 1.0 | Initial release |

