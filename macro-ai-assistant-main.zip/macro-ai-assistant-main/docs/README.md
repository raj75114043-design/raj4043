# Nokia PM Copilot AI Assistant - Frontend Documentation

**Complete Integration Guide for Frontend Teams**

---

##  Documentation Structure

### 1. **[FRONTEND_INTEGRATION_GUIDE.md](./FRONTEND_INTEGRATION_GUIDE.md)**
**→ START HERE for comprehensive documentation**

Complete reference guide covering:
- System architecture overview
- Core API endpoints with request/response examples
- WebSocket voice-to-text integration
- Chat history APIs
- Feedback collection mechanism
- Complete integration workflows with sequence diagrams
- Full React component examples
- Error handling best practices

**Best for:** Understanding the complete system, API contracts, and best practices

---

### 2. **[QUICK_START_EXAMPLES.md](./QUICK_START_EXAMPLES.md)**
**→ Quick reference with copy-paste code**

Practical examples including:
- JavaScript Fetch API examples
- Python async/await examples
- cURL commands for testing
- Complete code walkthroughs
- Four common scenarios (general query, needs clarification, ready for SQL, feedback)
- Troubleshooting guide

**Best for:** Quick implementation, testing, debugging

---

## Quick Navigation by Task

### I need to...

#### **Get started with the API**
1. Read: [FRONTEND_INTEGRATION_GUIDE.md → Core API Endpoints](./FRONTEND_INTEGRATION_GUIDE.md#core-api-endpoints)
2. Try: [QUICK_START_EXAMPLES.md → cURL Examples](./QUICK_START_EXAMPLES.md#curl-examples)

#### **Implement voice-to-text**
1. Read: [FRONTEND_INTEGRATION_GUIDE.md → WebSocket Voice-to-Text](./FRONTEND_INTEGRATION_GUIDE.md#websocket-voice-to-text-integration)
2. Code: [QUICK_START_EXAMPLES.md → Voice Input React Component](./QUICK_START_EXAMPLES.md#javascript-examples) or [Python WebSocket Example](./QUICK_START_EXAMPLES.md#3-websocket-voice-input)

#### **Handle follow-up questions**
1. Read: [FRONTEND_INTEGRATION_GUIDE.md → Complete Integration Flow](./FRONTEND_INTEGRATION_GUIDE.md#complete-integration-flow)
2. Code: [QUICK_START_EXAMPLES.md → Scenario B (Clarification)](./QUICK_START_EXAMPLES.md#scenario-b-data-question-needs-clarification)
3. Reference: [FRONTEND_INTEGRATION_GUIDE.md → Follow-Up Query Best Practices](./FRONTEND_INTEGRATION_GUIDE.md#follow-up-query-best-practices)

#### **Retrieve chat history**
1. Read: [FRONTEND_INTEGRATION_GUIDE.md → Chat History API](./FRONTEND_INTEGRATION_GUIDE.md#chat-history-api)
2. Code: [QUICK_START_EXAMPLES.md → Chat History & Feedback](./QUICK_START_EXAMPLES.md#3-chat-history--feedback)

#### **Collect user feedback**
1. Read: [FRONTEND_INTEGRATION_GUIDE.md → Feedback API](./FRONTEND_INTEGRATION_GUIDE.md#feedback-api)
2. Code: [QUICK_START_EXAMPLES.md → Scenario D (Feedback)](./QUICK_START_EXAMPLES.md#scenario-d-collect-feedback)

#### **Debug integration issues**
1. Check: [QUICK_START_EXAMPLES.md → Troubleshooting](./QUICK_START_EXAMPLES.md#troubleshooting)
2. Review: [FRONTEND_INTEGRATION_GUIDE.md → Error Handling](./FRONTEND_INTEGRATION_GUIDE.md#error-handling--best-practices)

#### **Set up WebSocket voice with microphone**
1. Read: [FRONTEND_INTEGRATION_GUIDE.md → Browser Setup](./FRONTEND_INTEGRATION_GUIDE.md#browser-setup)
2. Code: [QUICK_START_EXAMPLES.md → Voice Input React Component](./QUICK_START_EXAMPLES.md#2-voice-input--query-flow)

#### **Test endpoints without writing code**
1. Use: [QUICK_START_EXAMPLES.md → cURL Examples](./QUICK_START_EXAMPLES.md#curl-examples)
2. Visit: `http://your-api-host/docs` (Swagger UI for interactive testing)

---

##  System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     Frontend Application                        │
│  (Browser, React/Vue/Vanilla JS, Mobile App)                    │
└──────────────┬────────────────────────────────────────────────┬─┘
               │                                                  │
         HTTP/Text-based                                    WebSocket
         REST/SSE Stream                                    (Real-time)
               │                                                  │
┌──────────────▼────────────────────────────────────────────────▼─┐
│                         API Gateway                             │
│  (FastAPI, Port 8000)                                           │
└─┬────────────────────────────────────────────────────────────┬──┘
  │                                                              │
  ├─ /api/v1/assistant/session       (Create session)          │
  ├─ /api/v1/assistant/query         (Main query SSE)          │
  ├─ /api/v1/voice/ws/transcribe     (WebSocket ←────┘
  ├─ /api/v1/voice/transcribe        (REST upload)
  ├─ /api/v1/chat/history/*          (Chat history)
  └─ /api/v1/feedback/*              (Feedback)

       ↓

┌─────────────────────────────────────────────────────┐
│               Backend Services                      │
│                                                      │
│  ├─ Parallel Search                                │
│  │  ├─ Keyword API                                 │
│  │  ├─ KPI Search API                              │
│  │  └─ Question Bank API                           │
│  │                                                  │
│  ├─ HITL Validation Agent (LangGraph)              │
│  │  ├─ Query Classification                        │
│  │  ├─ General Response                            │
│  │  └─ Data Validation                             │
│  │                                                  │
│  ├─ SQL Generation Agent (LangGraph)               │
│  │  ├─ SQL Generation                              │
│  │  ├─ SQL Retry Logic                             │
│  │  └─ SQL Execution                               │
│  │                                                  │
│  ├─ Voice-to-Text (Azure Cognitive Services)       │
│  │  ├─ WebSocket Real-time                         │
│  │  └─ REST File Upload                            │
│  │                                                  │
│  └─ Database (PostgreSQL)                          │
│     ├─ Chat History                                │
│     ├─ HITL Responses                              │
│     └─ Feedback                                    │
└─────────────────────────────────────────────────────┘
```

---

## Data Flow Examples

### Query → SQL Results

```
User Query
   ↓
[/api/v1/assistant/query] ─→ SSE Stream
   ├─ search_keywords event
   ├─ search_kpis event
   ├─ search_qb event
   ├─ search_complete event
   ├─ hitl_start event
   ├─ hitl_complete event
   │  ├─ IF general query → display response, END
   │  ├─ IF needs clarification → prompt user for follow-up
   │  └─ IF ready for SQL → continue
   ├─ sql_start event
   ├─ sql_complete event (with table_json)
   └─ db_saved event

Display Results to User
   ↓
[Optional] /api/v1/feedback/submit
```

### Voice Input Flow

```
User speaks → Browser MediaRecorder
   ↓
[WebSocket: /api/v1/voice/ws/transcribe]
   ├─ Send: audio chunks (webm/opus)
   ├─ Receive: recognizing event (partial)
   ├─ Receive: recognized event (final)
   └─ Receive: done event

Transcribed Text
   ↓
[Pass to /api/v1/assistant/query]
   ↓
(Same as Query → SQL Results flow above)
```

---

## Key Concepts

### **Session**
- Unique identifier for a user's conversation
- Created via `/assistant/session` endpoint
- Used in all subsequent requests
- Should persist across page reloads

### **unique_chat_id**
- Identifier for a single Q&A turn
- Returned in `hitl_complete` event
- Used for feedback and follow-ups
- Stored in database for history

### **Follow-up Question**
- When user needs to clarify or refine query
- Requires `is_follow_up=true` and `follow_up_chat_id`
- System provides previous context to HITL agent
- Improves accuracy with conversation history

### **Server-Sent Events (SSE)**
- One-way streaming from server to client
- Events stream as they complete
- Better for progressive UI updates
- Connection closes when `db_saved` event arrives

### **WebSocket**
- Two-way real-time communication
- Used for voice transcription
- Browser sends binary audio chunks
- Server sends transcription updates

---

## Checklist for Frontend Implementation

- [ ] **Setup**
  - [ ] Review system architecture
  - [ ] Install required dependencies (axios/fetch, EventSource handling)
  - [ ] Configure API base URL

- [ ] **Session Management**
  - [ ] Create session on app startup
  - [ ] Store session_id in localStorage
  - [ ] Validate session on every request

- [ ] **Main Query Endpoint**
  - [ ] Implement SSE stream parser
  - [ ] Handle all event types
  - [ ] Display search results progressively
  - [ ] Show HITL responses (general/clarification/ready for SQL)
  - [ ] Handle errors gracefully

- [ ] **Follow-up Questions**
  - [ ] Store unique_chat_id from responses
  - [ ] Detect when clarification is needed
  - [ ] Implement follow-up form
  - [ ] Pass follow_up_chat_id correctly

- [ ] **Voice Input (Optional)**
  - [ ] Request microphone permissions
  - [ ] Initialize MediaRecorder
  - [ ] Connect to WebSocket endpoint
  - [ ] Handle real-time transcription updates
  - [ ] Auto-submit transcribed text

- [ ] **Results Display**
  - [ ] Parse JSON tables from sql_complete event
  - [ ] Render data tables
  - [ ] Format dates/numbers appropriately
  - [ ] Handle empty result sets

- [ ] **Chat History**
  - [ ] Fetch chat history on session start
  - [ ] Display previous conversations
  - [ ] Show search results for each turn
  - [ ] Allow re-running previous queries

- [ ] **Feedback**
  - [ ] Show rating interface after queries
  - [ ] Submit feedback with unique_chat_id
  - [ ] Get feedback statistics
  - [ ] Display feedback summary

- [ ] **Error Handling**
  - [ ] Catch HTTP errors
  - [ ] Handle connection timeouts
  - [ ] Implement retry logic
  - [ ] Show user-friendly error messages

- [ ] **Testing**
  - [ ] Test with cURL first
  - [ ] Use Swagger UI at /docs for testing
  - [ ] Test voice input with sample audio
  - [ ] Test follow-up flows
  - [ ] Test chat history retrieval

---

##  API Reference Quick Links

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/assistant/session` | POST | Create new session |
| `/assistant/query` | POST | Submit query (SSE stream) |
| `/voice/transcribe` | POST | Upload audio file |
| `/voice/transcribe/stream` | POST | Stream audio transcription (SSE) |
| `/voice/ws/transcribe` | WebSocket | Real-time voice-to-text |
| `/chat/history/{session_id}` | GET | Get conversation history |
| `/chat/turn/{unique_chat_id}` | GET | Get single turn |
| `/chat/sessions` | GET | List recent sessions |
| `/feedback/submit` | POST | Submit feedback |
| `/feedback/chat/{unique_chat_id}` | GET | Get feedback for turn |
| `/feedback/session/{session_id}` | GET | Get feedback for session |
| `/feedback/stats` | GET | Get feedback statistics |

**Full Swagger Documentation:** `http://your-api-host/docs`

---

## Common Issues & Solutions

| Issue | Solution | Reference |
|-------|----------|-----------|
| "No keywords/KPIs found" | Use more specific terminology | [Troubleshooting](./QUICK_START_EXAMPLES.md#issue-no-matching-keywords-kpis-or-questions-found) |
| SSE stream closes early | Increase timeout, check server logs | [Troubleshooting](./QUICK_START_EXAMPLES.md#issue-sse-stream-connection-closes-prematurely) |
| WebSocket connection fails | Check ffmpeg, Azure Speech key | [Troubleshooting](./QUICK_START_EXAMPLES.md#issue-websocket-connection-fails) |
| Follow-up not using context | Verify follow_up_chat_id is passed | [Troubleshooting](./QUICK_START_EXAMPLES.md#issue-follow-up-query-doesnt-use-previous-context) |
| Table doesn't render | Check table_json is valid JSON | [Troubleshooting](./QUICK_START_EXAMPLES.md#issue-results-table-doesnt-render) |
| Speech credentials missing | Set SPEECH_KEY_1 environment variable | [Troubleshooting](./QUICK_START_EXAMPLES.md#issue-speech_key_1-is-not-configured) |

---

## Getting Help

1. **Check Documentation:**
   - Main guide: [FRONTEND_INTEGRATION_GUIDE.md](./FRONTEND_INTEGRATION_GUIDE.md)
   - Quick examples: [QUICK_START_EXAMPLES.md](./QUICK_START_EXAMPLES.md)

2. **Test with Tools:**
   - Swagger UI: `http://your-api-host/docs`
   - cURL: [Examples](./QUICK_START_EXAMPLES.md#curl-examples)
   - Postman: Import from Swagger endpoint

3. **Review Code Examples:**
   - React components: [FRONTEND_INTEGRATION_GUIDE.md](./FRONTEND_INTEGRATION_GUIDE.md#frontend-implementation-examples)
   - Complete workflows: [QUICK_START_EXAMPLES.md](./QUICK_START_EXAMPLES.md#javascript-examples)

4. **Debug Issues:**
   - Check [Troubleshooting](./QUICK_START_EXAMPLES.md#troubleshooting) section
   - Review server logs for errors
   - Test endpoints individually with cURL

---

## Document Versions

| Document | Version | Last Updated | Status |
|----------|---------|--------------|--------|
| README.md | 1.0 | Feb 24, 2026 | Current |
| FRONTEND_INTEGRATION_GUIDE.md | 1.0 | Feb 24, 2026 | Current |
| QUICK_START_EXAMPLES.md | 1.0 | Feb 24, 2026 | Current |

---


*Last Updated: February 24, 2026*
*For the Nokia PM Copilot AI Assistant Team*
