"""
PM Copilot AI Assistant 2.0 – FastAPI Application
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia

Run:
    uvicorn main:app --host 0.0.0.0 --port 8000 --reload
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import settings
from app.db.database import init_db, close_db

# ── Routers ──────────────────────────────────────────────────────────
from app.api.endpoints.ai_assistant import router as ai_assistant_router
from app.api.endpoints.chat_history import router as chat_history_router
from app.api.endpoints.feedback import router as feedback_router
from app.api.endpoints.voice_2_text import router as voice_router
from app.api.endpoints.ai_assistant_to_agents import router as agents_router
from app.api.endpoints.database_endpoints import router as database_router
from app.api.endpoints.ai_assistant_to_pm_playgorund import router as playground_router

# ── Logging ──────────────────────────────────────────────────────────
logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)


# ── Lifespan ─────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown lifecycle hooks."""
    logger.info("Starting PM Copilot AI Assistant 2.0 ...")
    await init_db()
    logger.info("Database connection pools ready")
    yield
    logger.info("Shutting down ...")
    await close_db()
    logger.info("Shutdown complete")


# ── App ──────────────────────────────────────────────────────────────

app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="Nokia PM Copilot AI Assistant – HITL gateway, text-to-SQL agents, "
                "chat history, feedback, and voice-to-text services.",
    lifespan=lifespan,
)

# ── CORS ─────────────────────────────────────────────────────────────

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # Removed CORS ORIGIN, But need to know Later
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Register routers ────────────────────────────────────────────────

API_PREFIX = settings.api_v1_prefix  # /api/v1

app.include_router(ai_assistant_router, prefix=API_PREFIX)
app.include_router(chat_history_router, prefix=API_PREFIX)
app.include_router(feedback_router, prefix=API_PREFIX)
app.include_router(voice_router, prefix=API_PREFIX)
app.include_router(agents_router, prefix=API_PREFIX)
app.include_router(playground_router, prefix=API_PREFIX)
app.include_router(database_router,prefix=API_PREFIX)


# ── Health check ─────────────────────────────────────────────────────

@app.get("/health", tags=["Health"])
async def health():
    """Application health check."""
    from app.db.database import health_check_async
    db_healthy = await health_check_async()
    return {
        "status": "healthy" if db_healthy else "degraded",
        "version": settings.app_version,
        "database": "connected" if db_healthy else "disconnected",
    }


@app.get("/", tags=["Root"])
async def root():
    """Root endpoint – service info."""
    return {
        "service": settings.app_name,
        "version": settings.app_version,
        "docs": "/docs",
    }


# ── Uvicorn entry point ─────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host=settings.host,
        port=settings.port,
        reload=True,
        log_level=settings.log_level.lower(),
        timeout_keep_alive=300,    
        timeout_graceful_shutdown=60,
    )
