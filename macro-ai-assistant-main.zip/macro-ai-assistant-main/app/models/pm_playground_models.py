import uuid
from datetime import datetime
from typing import Optional
from sqlalchemy import (
    ForeignKey,
    Integer,
    String,
    Text,
    DateTime,
    Boolean,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.dialects.postgresql import UUID
from app.db.database import Base
from app.core.config import settings


class PMPlaygroundUserUploadData(Base):
    """
    PM Playground User Upload Data Table: Stores user-uploaded data with session tracking.
    """
    __tablename__ = "pm_playground_user_upload_data"
    __table_args__ = {"schema": settings.db_schema}

    data_upload_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=lambda: str(uuid.uuid4())
    )

    session_id: Mapped[str] = mapped_column(
        String(255), nullable=False, index=True
    )

    table_json: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True, comment="JSON representation of the uploaded table data"
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )

    def __repr__(self) -> str:
        return (
            f"<PMPlaygroundUserUploadData(data_upload_id={self.data_upload_id}, "
            f"session_id='{self.session_id}')>"
        )
