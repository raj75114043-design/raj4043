# # ── Async Job Queue Endpoints (for long-running queries) ────────────

# @router.post(
#     "/query-async",
#     summary="Submit a query asynchronously (streams search + HITL, job_id for SQL)",
#     description="Streams search & HITL analysis immediately, then returns job_id if SQL generation is needed. "
#                 "No timeout limits for SQL — let it run as long as needed.",
# )
# async def submit_query_async(request: QueryRequest):
#     """
#     Hybrid SSE streaming endpoint for long-running queries.

#     Flow:
#     1. Stream search results (keywords, KPIs, QB)
#     2. Stream HITL analysis
#     3. If general question: return immediately (no SQL)
#     4. If needs clarification: return immediately (no SQL)
#     5. If SQL needed: create background job, stream job_id, let client poll
#     """

#     async def _event_generator():
#         # ── Step 1 – Parallel search ──────────────────────────────────────
#         try:
#             search = await parallel_search(request.query)
#         except Exception as e:
#             logger.error(f"Parallel search failed: {e}")
#             yield _sse_event("error", {"message": f"Search failed: {e}"})
#             return

#         keyword_names = search.get("keyword_names", [])
#         keyword_ids = search.get("keyword_ids", [])
#         keyword_results = search.get("keyword_results", [])
#         kpi_names = search.get("kpi_names", [])
#         kpi_ids = search.get("kpi_ids", [])
#         kpi_results = search.get("kpi_results", [])
#         qb_names = search.get("qb_names", [])
#         qb_ids = search.get("qb_ids", [])
#         qb_results = search.get("qb_results", [])

#         # Stream search categories
#         yield _sse_event("search_keywords", {
#             "keyword_names": keyword_names,
#             "keyword_ids": keyword_ids,
#             "found": len(keyword_names) > 0,
#             "message": "" if keyword_names else "No matching keywords found.",
#         })

#         yield _sse_event("search_kpis", {
#             "kpi_names": kpi_names,
#             "kpi_ids": kpi_ids,
#             "found": len(kpi_names) > 0,
#             "message": "" if kpi_names else "No matching KPIs found.",
#         })

#         yield _sse_event("search_qb", {
#             "qb_names": qb_names,
#             "qb_ids": qb_ids,
#             "found": len(qb_names) > 0,
#             "message": "" if qb_names else "No matching reference questions found.",
#         })

#         # Determine overall status
#         has_keywords = len(keyword_names) > 0
#         has_kpis = len(kpi_names) > 0
#         has_qb = len(qb_names) > 0
#         all_empty = not has_keywords and not has_kpis and not has_qb
#         partial = not all_empty and not (has_keywords and has_kpis and has_qb)

#         if all_empty:
#             yield _sse_event("search_complete", {
#                 "status": "no_results",
#                 "message": (
#                     "I couldn't find any matching keywords, KPIs, or reference "
#                     "questions for your query. Could you rephrase your question?"
#                 ),
#             })
#             return

#         if partial:
#             missing = []
#             if not has_keywords:
#                 missing.append("keywords")
#             if not has_kpis:
#                 missing.append("KPIs")
#             if not has_qb:
#                 missing.append("reference questions")

#             yield _sse_event("search_complete", {
#                 "status": "partial",
#                 "message": f"No matching {', '.join(missing)} found — proceeding with available context.",
#                 "keyword_names": keyword_names,
#                 "keyword_ids": keyword_ids,
#                 "kpi_names": kpi_names,
#                 "kpi_ids": kpi_ids,
#                 "qb_names": qb_names,
#                 "qb_ids": qb_ids,
#                 "search_duration_s": search.get("node_timestamps", 0),
#             })
#         else:
#             yield _sse_event("search_complete", {
#                 "status": "ok",
#                 "keyword_names": keyword_names,
#                 "keyword_ids": keyword_ids,
#                 "kpi_names": kpi_names,
#                 "kpi_ids": kpi_ids,
#                 "qb_names": qb_names,
#                 "qb_ids": qb_ids,
#                 "search_duration_s": search.get("node_timestamps", 0),
#             })

#         # ── Step 2 – HITL agent invocation ──────────────────────────────
#         unique_chat_id = str(uuid4())
#         hitl_id = str(uuid4())

#         yield _sse_event("hitl_start", {
#             "unique_chat_id": unique_chat_id,
#             "hitl_id": hitl_id,
#             "message": "Analysing your query…",
#         })

#         # Fetch previous context if this is a follow-up
#         prev_query = ""
#         prev_msg = ""
#         prev_sql = ""
#         if request.is_follow_up and request.follow_up_chat_id:
#             prev_query, prev_msg, prev_sql = await _fetch_previous_context(request.follow_up_chat_id)

#         try:
#             hitl = await run_hitl_agent(
#                 user_query=request.query,
#                 keyword_results=keyword_results,
#                 kpi_results=kpi_results,
#                 qb_results=qb_results,
#                 keyword_names=keyword_names,
#                 kpi_names=kpi_names,
#                 qb_questions=qb_names,
#                 is_follow_up=request.is_follow_up,
#                 previous_user_query=prev_query,
#                 previous_clarifying_message=prev_msg,
#             )
#         except Exception as e:
#             logger.error(f"HITL agent failed: {e}")
#             yield _sse_event("error", {"message": f"HITL processing failed: {e}"})
#             return

#         query_type = hitl.get("query_type", "")
#         ready_for_sql = hitl.get("ready_for_sql", False)

#         # ── Scenario 1: General / chitchat query ──────────────────────
#         if query_type == "general":
#             general_response = hitl.get("general_response", "")

#             yield _sse_event("hitl_complete", {
#                 "unique_chat_id": unique_chat_id,
#                 "hitl_id": hitl_id,
#                 "query_type": "general",
#                 "ready_for_sql": False,
#                 "general_response": general_response,
#                 "hitl_duration_s": hitl.get("node_timestamps", {}),
#             })

#             # Persist chat_history + hitl in background
#             await _save_chat_and_hitl(
#                 unique_chat_id=unique_chat_id,
#                 hitl_id=hitl_id,
#                 session_id=request.session_id,
#                 username=request.username,
#                 user_query=request.query,
#                 keyword_names=keyword_names,
#                 kpi_names=kpi_names,
#                 qb_names=qb_names,
#                 is_follow_up=request.is_follow_up,
#                 hitl_generic_response=general_response,
#                 hitl_assisted_response="",
#                 hitl_status="completed_general",
#             )

#             yield _sse_event("db_saved", {
#                 "unique_chat_id": unique_chat_id,
#                 "message": "Chat history saved.",
#             })
#             return  # No SQL needed

#         # ── Scenario 2: Data question but needs clarification ─────────
#         if query_type == "data" and not ready_for_sql:
#             clarifying_message = hitl.get("clarifying_message", "")

#             yield _sse_event("hitl_complete", {
#                 "unique_chat_id": unique_chat_id,
#                 "hitl_id": hitl_id,
#                 "query_type": "data",
#                 "ready_for_sql": False,
#                 "clarifying_message": clarifying_message,
#                 "keyword_names": keyword_names,
#                 "kpi_names": kpi_names,
#                 "qb_names": qb_names,
#                 "hitl_duration_s": hitl.get("node_timestamps", {}),
#             })

#             # Persist so follow-up can reference this turn
#             await _save_chat_and_hitl(
#                 unique_chat_id=unique_chat_id,
#                 hitl_id=hitl_id,
#                 session_id=request.session_id,
#                 username=request.username,
#                 user_query=request.query,
#                 keyword_names=keyword_names,
#                 kpi_names=kpi_names,
#                 qb_names=qb_names,
#                 is_follow_up=request.is_follow_up,
#                 hitl_generic_response="",
#                 hitl_assisted_response=clarifying_message,
#                 hitl_status="needs_clarification",
#             )

#             yield _sse_event("db_saved", {
#                 "unique_chat_id": unique_chat_id,
#                 "message": "Chat history saved. Awaiting follow-up from user.",
#             })
#             return  # No SQL needed

#         # ── Scenario 3: Data question ready for SQL — kick off background job ────
#         yield _sse_event("hitl_complete", {
#             "unique_chat_id": unique_chat_id,
#             "hitl_id": hitl_id,
#             "query_type": "data",
#             "ready_for_sql": True,
#             "keyword_names": keyword_names,
#             "kpi_names": kpi_names,
#             "qb_names": qb_names,
#             "hitl_duration_s": hitl.get("node_timestamps", {}),
#             "message": "Query validated — starting SQL generation (this may take several minutes).",
#         })

#         # Create background job for SQL generation (no timeout)
#         job_id = str(uuid4())
#         JOB_STORE[job_id] = {
#             "job_id": job_id,
#             "status": "pending",
#             "created_at": datetime.now(timezone.utc).isoformat(),
#             "started_at": None,
#             "completed_at": None,
#             "progress": "Starting SQL generation…",
#             "error": None,
#             "unique_chat_id": unique_chat_id,
#             "hitl_id": hitl_id,
#             "result": None,
#         }

#         # Fire off background SQL job (non-blocking)
#         asyncio.create_task(_process_query_job(
#             job_id=job_id,
#             request=request,
#             search_result=search,
#             keyword_names=keyword_names,
#             keyword_ids=keyword_ids,
#             keyword_results=keyword_results,
#             kpi_names=kpi_names,
#             kpi_ids=kpi_ids,
#             kpi_results=kpi_results,
#             qb_names=qb_names,
#             qb_ids=qb_ids,
#             qb_results=qb_results,
#         ))

#         # Stream job_id immediately
#         yield _sse_event("sql_job_submitted", {
#             "job_id": job_id,
#             "unique_chat_id": unique_chat_id,
#             "message": "SQL generation started in background. Use GET /assistant/query-status/{job_id} to check progress.",
#             "poll_endpoint": f"/assistant/query-status/{job_id}",
#             "results_endpoint": f"/assistant/query-results/{job_id}",
#         })

#     return StreamingResponse(
#         _event_generator(),
#         media_type="text/event-stream",
#         headers={
#             "Cache-Control": "no-cache",
#             "Connection": "keep-alive",
#             "X-Accel-Buffering": "no",
#         },
#     )


# @router.get(
#     "/query-status/{job_id}",
#     summary="Check the status of an async query job",
#     description="Returns current status, progress, and any error messages.",
#     response_model=JobStatusResponse,
# )
# async def get_query_status(job_id: str):
#     """
#     Polls the status of a background query job.

#     Status can be: pending, processing, completed, or failed.
#     """
#     if job_id not in JOB_STORE:
#         raise HTTPException(status_code=404, detail=f"Job {job_id} not found")

#     job = JOB_STORE[job_id]
#     return JobStatusResponse(
#         job_id=job_id,
#         status=job["status"],
#         created_at=job["created_at"],
#         started_at=job["started_at"],
#         completed_at=job["completed_at"],
#         progress=job["progress"],
#         error=job["error"],
#     )


# @router.get(
#     "/query-results/{job_id}",
#     summary="Retrieve final results of a completed async query",
#     description="Returns the full result including generated SQL and data.",
# )
# async def get_query_results(job_id: str):
#     """
#     Retrieves the final results of a completed job.

#     Only available once status is "completed" or "failed".
#     If "pending" or "processing", returns a 202 Accepted status code.
#     """
#     if job_id not in JOB_STORE:
#         raise HTTPException(status_code=404, detail=f"Job {job_id} not found")

#     job = JOB_STORE[job_id]

#     if job["status"] in ["pending", "processing"]:
#         return {
#             "status": "still_processing",
#             "job_id": job_id,
#             "progress": job["progress"],
#             "message": "Job is still running. Check back soon.",
#         }

#     if job["status"] == "failed":
#         return {
#             "job_id": job_id,
#             "status": "failed",
#             "error": job["error"],
#             "completed_at": job["completed_at"],
#         }

#     # Status is "completed"
#     result = job["result"]
#     return JobResultResponse(
#         job_id=job_id,
#         status="completed",
#         unique_chat_id=job["unique_chat_id"],
#         hitl_id=job["hitl_id"],
#         success=result.get("success", False),
#         generated_sql=result.get("generated_sql", ""),
#         table_json=result.get("table_json", ""),
#         error=result.get("error", ""),
#         node_timestamps=result.get("node_timestamps", {}),
#     )
