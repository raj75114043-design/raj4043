"""
Email endpoints for PM Copilot AI Assistant
Sends formatted chat history as HTML email via Nokia mail gateway

Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import base64
import csv
import io
import json
import logging
import re
import requests
from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.database import get_db

logger = logging.getLogger(__name__)

# ── Nokia Email Gateway Configuration ──────────────────────────────────────
AUTH_URL = "https://nokiaosdp-gsd-staging.aibi-americas-002.dyn.nesc.nokia.net/web/session/authenticate"
SEND_MAIL_URL = "https://nokiaosdp-gsd-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/send_mail"

_AUTH_PAYLOAD = {
    "jsonrpc": "2.0",
    "method": "call",
    "params": {
        "db": "postgres",
        "login": "pwc_osdp_user",
        "password": "pwc_osdp_user",
    },
}

# ── Database & Router Configuration ────────────────────────────────────────
SCHEMA = settings.db_schema
TABLE = f"{SCHEMA}.ai_assistant_chat_history"
router = APIRouter(prefix="/email", tags=["Email"])

# ── Nokia Brand Colors ─────────────────────────────────────────────────────
NOKIA_COLORS = {
    "primary": "#005AFF",      # Nokia blue
    "light": "#E8F0FF",        # Light blue background
    "alt_row": "#F5F8FF",      # Alternate table row
    "page_bg": "#F4F6F9",      # Page background
    "footer": "#666666",       # Footer text
}


# ── Pydantic Models ────────────────────────────────────────────────────────

class SendEmailRequest(BaseModel):
    """Request to send a chat turn as email."""

    session_id: str = Field(..., description="Session ID identifying the chat session")
    unique_chat_id: str = Field(..., description="Unique chat ID of the specific turn to email")
    to_list: List[str] = Field(..., min_length=1, description="List of recipient email addresses")
    cc_list: List[str] = Field(default=[], description="List of CC email addresses (optional)")
    bcc_list: List[str] = Field(default=[], description="List of BCC email addresses (optional)")
    custom_message: Optional[str] = Field(default=None, description="Custom message from sender (optional)")


# ── Helper Functions ───────────────────────────────────────────────────────

def _get_session_id() -> str:
    """
    Authenticate with Nokia mail gateway and retrieve session cookie.

    Returns:
        str: Session ID (cookie) for use in subsequent mail gateway requests

    Raises:
        RuntimeError: If authentication fails or session_id not returned
        requests.RequestException: If HTTP request fails
    """
    try:
        session = requests.Session()
        resp = session.post(AUTH_URL, json=_AUTH_PAYLOAD, timeout=15)
        resp.raise_for_status()
        sid = session.cookies.get("session_id")
        if not sid:
            raise RuntimeError("Nokia gateway did not return session_id cookie")
        return sid
    except Exception as e:
        logger.error(f"Failed to authenticate with Nokia mail gateway: {e}")
        raise


def _build_csv_attachment(records: List[Dict[str, Any]], filename: str = "data.csv") -> Dict[str, str]:
    """
    Build a base64-encoded CSV attachment from table records.

    Args:
        records: List of dicts (parsed from table_json)
        filename: Name of the CSV file in the attachment

    Returns:
        Dict with "filename" and "filedata" (base64 encoded CSV)
    """
    try:
        output = io.StringIO()
        if not records:
            writer = csv.writer(output)
            writer.writerow(["No data"])
            csv_data = output.getvalue().encode("utf-8")
        else:
            fieldnames = list(records[0].keys())
            writer = csv.DictWriter(output, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(records)
            csv_data = output.getvalue().encode("utf-8")

        return {
            "filename": filename,
            "filedata": base64.b64encode(csv_data).decode("utf-8"),
        }
    except Exception as e:
        logger.error(f"Failed to build CSV attachment: {e}")
        raise


def _escape_html(text: str) -> str:
    """Escape HTML special characters."""
    if not text:
        return ""
    return (
        str(text)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


def _markdown_to_html(text: str) -> str:
    """
    Convert markdown to HTML for email display.
    Handles: bold, italic, code blocks, inline code, lists, line breaks.
    """
    if not text:
        return ""

    text = str(text)

    # First, process line-by-line structure (lists, paragraphs)
    lines = text.split('\n')
    processed_lines = []
    in_list = False

    for line in lines:
        # Check if this is a bullet list item
        if re.match(r'^\s*[-*]\s+', line):
            if not in_list:
                processed_lines.append('__LIST_START__')
                in_list = True
            # Extract the item content
            item_content = re.sub(r'^\s*[-*]\s+', '', line)
            processed_lines.append(f'__LIST_ITEM__{_escape_html(item_content)}__END_LIST_ITEM__')
        else:
            if in_list:
                processed_lines.append('__LIST_END__')
                in_list = False
            if line.strip():
                processed_lines.append(f'__PARA__{_escape_html(line)}__END_PARA__')
            else:
                processed_lines.append('__BLANK__')

    if in_list:
        processed_lines.append('__LIST_END__')

    text = '\n'.join(processed_lines)

    # Now process inline markdown on escaped content
    # Handle bold (**text**) - text is already escaped
    text = re.sub(r'\*\*([^\*]+)\*\*', r'<strong>\1</strong>', text)

    # Handle italic (*text*) - be careful not to match **
    text = re.sub(r'(?<!\*)\*([^\*]+)\*(?!\*)', r'<em>\1</em>', text)

    # Handle inline code (`code`) - text is already escaped
    text = re.sub(r'`([^`]+)`', r'<code style="background-color:#f0f0f0; padding:2px 4px; border-radius:3px; font-family:monospace; font-size:12px;">\1</code>', text)

    # Handle code blocks (```...```) - must be after inline code
    def replace_code_blocks(match):
        code = _escape_html(match.group(1).strip())
        return f'<pre style="background-color:#f5f5f5; padding:10px; border-radius:4px; overflow-x:auto; font-family:monospace; font-size:12px;"><code>{code}</code></pre>'

    text = re.sub(r'```(.*?)```', replace_code_blocks, text, flags=re.DOTALL)

    # Replace placeholders with HTML structure
    text = text.replace('__LIST_START__', '<ul style="margin:10px 0; padding-left:20px;">')
    text = text.replace('__LIST_END__', '</ul>')
    text = text.replace('__LIST_ITEM__', '<li>')
    text = text.replace('__END_LIST_ITEM__', '</li>')
    text = text.replace('__PARA__', '<p style="margin:8px 0; line-height:1.6;">')
    text = text.replace('__END_PARA__', '</p>')
    text = text.replace('__BLANK__', '')

    return text


def _build_html_email(row: Dict[str, Any], custom_message: Optional[str] = None) -> str:
    """
    Build a professional Nokia-blue HTML email from chat history row.

    Args:
        row: Chat history record (dict-like with columns)
        custom_message: Optional custom message from sender

    Returns:
        str: HTML email body
    """
    # Extract fields
    unique_chat_id = row.get("unique_chat_id", "")
    session_id = row.get("session_id", "")
    username = _escape_html(row.get("username", "Unknown"))
    user_query = _escape_html(row.get("user_query", ""))
    # AI output may contain markdown, so convert it to HTML instead of escaping
    ai_output = _markdown_to_html(row.get("ai_assistant_output") or row.get("hitl_assisted_response") or row.get("hitl_generic_response") or "")
    sql_generated = _escape_html(row.get("sql_generated", ""))
    table_json_str = row.get("table_json", "")
    kpi_identified = _escape_html(row.get("kpi_identified", ""))
    keywords = _escape_html(row.get("keywords_indentifed", ""))
    created_at = row.get("created_at", datetime.utcnow())

    # Parse created_at
    if isinstance(created_at, datetime):
        created_at_str = created_at.strftime("%Y-%m-%d %H:%M:%S UTC")
    else:
        created_at_str = str(created_at)

    # Parse table JSON
    table_html = ""
    if table_json_str:
        try:
            records = json.loads(table_json_str)
            if records and isinstance(records, list):
                # Build HTML table
                fieldnames = list(records[0].keys())
                table_html = '<table style="width:100%; border-collapse:collapse; margin:15px 0;">'
                table_html += '<thead><tr style="background-color:' + NOKIA_COLORS["primary"] + '; color:white;">'
                for field in fieldnames:
                    table_html += f'<th style="padding:10px; border:1px solid #ddd; text-align:left; font-weight:bold;">{_escape_html(field)}</th>'
                table_html += "</tr></thead><tbody>"

                for idx, record in enumerate(records):
                    bg_color = NOKIA_COLORS["alt_row"] if idx % 2 == 1 else "white"
                    table_html += f'<tr style="background-color:{bg_color};">'
                    for field in fieldnames:
                        value = _escape_html(str(record.get(field, "")))
                        table_html += f'<td style="padding:10px; border:1px solid #ddd;">{value}</td>'
                    table_html += "</tr>"

                table_html += "</tbody></table>"
        except Exception as e:
            logger.warning(f"Failed to parse table_json: {e}")
            table_html = '<p style="color:#d32f2f;">Unable to render table data</p>'

    # Build SQL code block
    sql_html = ""
    if sql_generated:
        sql_html = (
            '<div style="background-color:#f5f5f5; padding:15px; border-left:4px solid '
            + NOKIA_COLORS["primary"]
            + '; margin:15px 0; border-radius:4px;">'
            '<h3 style="margin-top:0; color:' + NOKIA_COLORS["primary"] + ';">Generated SQL</h3>'
            '<pre style="margin:0; overflow-x:auto; font-family:monospace; font-size:12px; color:#333;">'
            f'{sql_generated}</pre></div>'
        )

    # Build custom message section
    custom_msg_html = ""
    if custom_message:
        custom_msg_html = f"""
                <div class="section" style="background-color:{NOKIA_COLORS["light"]}; padding:15px; border-left:4px solid {NOKIA_COLORS["primary"]}; border-radius:4px;">
                    <div class="section-title">Sender Note</div>
                    <p style="margin:8px 0; line-height:1.6;">{_markdown_to_html(custom_message)}</p>
                </div>
        """

    # Build KPI/Keywords badges
    badges_html = ""
    badges = []
    if kpi_identified:
        badges.append(f'<span style="background-color:{NOKIA_COLORS["light"]}; color:{NOKIA_COLORS["primary"]}; padding:4px 8px; border-radius:12px; margin-right:8px; font-size:12px; display:inline-block;">KPI: {kpi_identified}</span>')
    if keywords:
        badges.append(f'<span style="background-color:{NOKIA_COLORS["light"]}; color:{NOKIA_COLORS["primary"]}; padding:4px 8px; border-radius:12px; margin-right:8px; font-size:12px; display:inline-block;">Keywords: {keywords}</span>')

    if badges:
        badges_html = '<div style="margin:15px 0;">' + "".join(badges) + "</div>"

    # Build HTML email
    html = f"""
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body {{
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                background-color: {NOKIA_COLORS["page_bg"]};
                margin: 0;
                padding: 0;
                color: #333;
            }}
            .container {{
                max-width: 800px;
                margin: 0 auto;
                background-color: white;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            }}
            .header {{
                background-color: {NOKIA_COLORS["primary"]};
                color: white;
                padding: 30px 20px;
                text-align: center;
            }}
            .header h1 {{
                margin: 0;
                font-size: 28px;
                font-weight: 600;
            }}
            .header p {{
                margin: 5px 0 0 0;
                font-size: 12px;
                opacity: 0.9;
            }}
            .meta-section {{
                background-color: {NOKIA_COLORS["page_bg"]};
                padding: 15px 20px;
                border-bottom: 1px solid #e0e0e0;
                display: flex;
                gap: 15px;
                flex-wrap: wrap;
                font-size: 12px;
            }}
            .meta-badge {{
                background-color: white;
                border: 1px solid {NOKIA_COLORS["primary"]};
                color: {NOKIA_COLORS["primary"]};
                padding: 6px 12px;
                border-radius: 4px;
                font-weight: 500;
            }}
            .content {{
                padding: 20px;
            }}
            .section {{
                margin: 20px 0;
            }}
            .section-title {{
                color: {NOKIA_COLORS["primary"]};
                font-size: 16px;
                font-weight: 600;
                margin-bottom: 10px;
                border-bottom: 2px solid {NOKIA_COLORS["primary"]};
                padding-bottom: 8px;
            }}
            .query-box {{
                background-color: {NOKIA_COLORS["light"]};
                padding: 15px;
                border-left: 4px solid {NOKIA_COLORS["primary"]};
                border-radius: 4px;
                line-height: 1.6;
            }}
            .response-box {{
                background-color: #f9f9f9;
                padding: 15px;
                border-left: 4px solid {NOKIA_COLORS["primary"]};
                border-radius: 4px;
                line-height: 1.6;
            }}
            .footer {{
                background-color: {NOKIA_COLORS["page_bg"]};
                border-top: 1px solid #e0e0e0;
                padding: 20px;
                text-align: center;
                font-size: 12px;
                color: {NOKIA_COLORS["footer"]};
            }}
            .footer a {{
                color: {NOKIA_COLORS["primary"]};
                text-decoration: none;
            }}
            table {{
                width: 100%;
                border-collapse: collapse;
                margin: 15px 0;
            }}
            th {{
                background-color: {NOKIA_COLORS["primary"]};
                color: white;
                padding: 10px;
                border: 1px solid #ddd;
                text-align: left;
                font-weight: bold;
            }}
            td {{
                padding: 10px;
                border: 1px solid #ddd;
            }}
            tr:nth-child(even) {{
                background-color: {NOKIA_COLORS["alt_row"]};
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <!-- Header -->
            <div class="header">
                <h1>PM Twin AI Assistant</h1>
                <p>Chat Summary | Nokia</p>
            </div>

            <!-- Meta Section -->
            <div class="meta-section">
                <div class="meta-badge">Chat ID: <span style="color:#333;">{unique_chat_id}</span></div>
                <div class="meta-badge">Session: <span style="color:#333;">{session_id[:8]}...</span></div>
                <div class="meta-badge">User: <span style="color:#333;">{username}</span></div>
                <div class="meta-badge">Date: <span style="color:#333;">{created_at_str}</span></div>
            </div>

            <!-- Content -->
            <div class="content">
                <!-- Custom Sender Message -->
                {custom_msg_html}

                <!-- User Query -->
                <div class="section">
                    <div class="section-title">Your Question</div>
                    <div class="query-box">{user_query}</div>
                </div>

                <!-- AI Response -->
                <div class="section">
                    <div class="section-title">AI Assistant Response</div>
                    <div class="response-box">{ai_output}</div>
                </div>

                <!-- KPIs and Keywords -->
                {badges_html}

                <!-- Data Table -->
                {f'<div class="section"><div class="section-title">Data Results</div>{table_html}</div>' if table_html else ''}

                <!-- SQL Query -->
                {sql_html}
            </div>

            <!-- Footer -->
            <div class="footer">
                <p>Powered by <strong>PM Twin: AI Assistant</strong> | Nokia </p>
                <p style="margin:5px 0 0 0; font-size:11px;">This email was automatically generated. Please do not reply to this message.</p>
            </div>
        </div>
    </body>
    </html>
    """

    return html


def send_email(
    session_id: str,
    to_list: List[str],
    cc_list: List[str],
    bcc_list: List[str],
    subject: str,
    body: str,
    attachments: List[Dict[str, str]],
) -> Dict[str, Any]:
    """
    Send email via Nokia mail gateway.

    Args:
        session_id: Nokia gateway session cookie
        to_list: Recipient email addresses
        cc_list: CC email addresses
        bcc_list: BCC email addresses
        subject: Email subject line
        body: Email body (HTML)
        attachments: List of dicts with "filename" and "filedata" (base64)

    Returns:
        dict: Gateway response

    Raises:
        requests.RequestException: If HTTP request to gateway fails
    """
    payload = {
        "params": {
            "tolist": to_list,
            "cclist": cc_list,
            "bcclist": bcc_list,
            "subject": subject,
            "body": body,
            "file": attachments,
        }
    }

    resp = requests.post(
        SEND_MAIL_URL,
        json=payload,
        headers={
            "Content-Type": "application/json",
            "Cookie": f"session_id={session_id}",
        },
        timeout=30,
    )

    resp.raise_for_status()
    return resp.json()


# ── Endpoints ──────────────────────────────────────────────────────────────

@router.post(
    "/send-chat",
    summary="Send chat turn as formatted email",
    description="Fetches a specific chat turn by session_id + unique_chat_id and emails it with Nokia-blue formatting",
)
async def send_chat_email(request: SendEmailRequest, db: AsyncSession = Depends(get_db)):
    """
    Send a formatted email of a specific chat turn.

    Flow:
    1. Query chat_history for the given session_id + unique_chat_id
    2. Build Nokia-blue HTML email with query, response, table, SQL
    3. If table_json exists, build CSV attachment
    4. Authenticate with Nokia gateway
    5. Send email via gateway

    Args:
        request: SendEmailRequest with session_id, unique_chat_id, recipient list
        db: Async database session

    Returns:
        dict: { "status": "sent", "unique_chat_id": "...", "recipients": [...] }

    Raises:
        HTTPException 404: If chat record not found
        HTTPException 500: If email send fails
    """
    
    try:
        # Step 1: Query chat history
        query = text(f"""
            SELECT unique_chat_id, session_id, hitl_id, username, user_query,
                   ai_assistant_output, hitl_assisted_response, hitl_generic_response,
                   sql_generated, table_json, kpi_identified, keywords_indentifed,
                   qb_indentifed, is_follow_up, created_at
            FROM {TABLE}
            WHERE session_id = :session_id AND unique_chat_id = :unique_chat_id
        """)

        result = await db.execute(query, {
            "session_id": request.session_id,
            "unique_chat_id": request.unique_chat_id,
        })
        row = result.mappings().first()

        if not row:
            raise HTTPException(status_code=404, detail="Chat record not found")

        # Step 2: Build HTML email
        html_body = _build_html_email(dict(row), custom_message=request.custom_message)

        # Step 3: Build CSV attachment if table_json exists
        attachments = []
        table_json_str = row.get("table_json")
        if table_json_str:
            try:
                records = json.loads(table_json_str)
                if records and isinstance(records, list):
                    csv_attachment = _build_csv_attachment(records, "results.csv")
                    attachments.append(csv_attachment)
            except Exception as e:
                logger.warning(f"Failed to create CSV attachment: {e}")

        # Step 4: Get Nokia gateway session
        gateway_session_id = _get_session_id()

        # Step 5: Send email
        email_subject = f"PM Twin Summary: {row.get('user_query', 'Chat')[:50]}"
        send_email(
            session_id=gateway_session_id,
            to_list=request.to_list,
            cc_list=request.cc_list,
            bcc_list=request.bcc_list,
            subject=email_subject,
            body=html_body,
            attachments=attachments,
        )

        logger.info(f"Email sent for chat {request.unique_chat_id} to {request.to_list}")

        return {
            "status": "sent",
            "unique_chat_id": str(request.unique_chat_id),
            "recipients": request.to_list,
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Email send failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Email send failed: {str(e)}")
