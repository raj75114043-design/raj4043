"""
Chat History endpoints – store and retrieve conversation history
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import logging
from datetime import datetime
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.database import get_db

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/chat", tags=["Chat History"])

SCHEMA = settings.db_schema
TABLE = f"{SCHEMA}.ai_assistant_chat_history"


# ── Schemas ──────────────────────────────────────────────────────────

class SaveChatRequest(BaseModel):
    session_id: str
    hitl_id: str
    username: str
    user_query: str = Field(..., min_length=1)
    ai_assistant_output: Optional[str] = None
    sql_generated: Optional[str] = None
    table_json: Optional[str] = Field(None, description="JSON table output from the text-to-SQL engine")
    kpi_identified: Optional[str] = None
    keywords_indentifed: Optional[str] = None
    qb_indentifed: Optional[str] = None
    is_follow_up: Optional[bool] = None


class SaveChatResponse(BaseModel):
    unique_chat_id: str
    status: str = "saved"


class ChatTurnOut(BaseModel):
    unique_chat_id: str
    session_id: str
    hitl_id: str
    username: str
    user_query: str
    ai_assistant_output: Optional[str] = None
    sql_generated: Optional[str] = None
    table_json: Optional[str] = None
    kpi_identified: Optional[str] = None
    keywords_indentifed: Optional[str] = None
    qb_indentifed: Optional[str] = None
    is_follow_up: Optional[bool] = None
    created_at: datetime


class ChatHistoryResponse(BaseModel):
    session_id: str
    messages: list[ChatTurnOut]


# ── Endpoints ────────────────────────────────────────────────────────

# @router.post(
#     "/save",
#     response_model=SaveChatResponse,
#     summary="Save a chat turn",
#     status_code=201,
# )
# async def save_chat_turn(msg: SaveChatRequest, db: AsyncSession = Depends(get_db)):
#     """Persist a single chat turn (user query + assistant output) to the database."""
#     chat_id = str(uuid4())
#     query = text(f"""
#         INSERT INTO {TABLE}
#             (unique_chat_id, session_id, hitl_id, username, user_query,
#              ai_assistant_output, sql_generated, table_json, kpi_identified,
#              keywords_indentifed, qb_indentifed, is_follow_up, created_at)
#         VALUES
#             (:unique_chat_id, :session_id, :hitl_id, :username, :user_query,
#              :ai_assistant_output, :sql_generated, :table_json, :kpi_identified,
#              :keywords_indentifed, :qb_indentifed, :is_follow_up, :created_at)
#     """)
#     await db.execute(query, {
#         "unique_chat_id": chat_id,
#         "session_id": msg.session_id,
#         "hitl_id": msg.hitl_id,
#         "username": msg.username,
#         "user_query": msg.user_query,
#         "ai_assistant_output": msg.ai_assistant_output,
#         "sql_generated": msg.sql_generated,
#         "table_json": msg.table_json,
#         "kpi_identified": msg.kpi_identified,
#         "keywords_indentifed": msg.keywords_indentifed,
#         "qb_indentifed": msg.qb_indentifed,
#         "is_follow_up": msg.is_follow_up,
#         "created_at": datetime.utcnow(),
#     })
#     return SaveChatResponse(unique_chat_id=chat_id)


@router.get(
    "/history/{session_id}",
    response_model=ChatHistoryResponse,
    summary="Get chat history for a session",
)
async def get_history(session_id: str, db: AsyncSession = Depends(get_db)):
    """Retrieve all chat turns for a given session, ordered by creation time."""
    query = text(f"""
        SELECT unique_chat_id, session_id, hitl_id, username, user_query,
               ai_assistant_output, sql_generated, table_json, kpi_identified,
               keywords_indentifed, qb_indentifed, is_follow_up, created_at
        FROM {TABLE}
        WHERE session_id = :session_id
        ORDER BY created_at ASC
    """)
    result = await db.execute(query, {"session_id": session_id})
    rows = result.mappings().all()

    messages = []
    for r in rows:
        try:
            row_dict = dict(r)
            # Convert UUID objects to strings for Pydantic
            if row_dict.get("unique_chat_id"):
                row_dict["unique_chat_id"] = str(row_dict["unique_chat_id"])
            if row_dict.get("hitl_id"):
                row_dict["hitl_id"] = str(row_dict["hitl_id"])
            messages.append(ChatTurnOut(**row_dict))
        except Exception as e:
            logger.error(f"Failed to parse row {dict(r)}: {str(e)}", exc_info=True)
            raise HTTPException(status_code=500, detail=f"Data parsing error: {str(e)}")

    return ChatHistoryResponse(
        session_id=session_id,
        messages=messages,
    )


@router.get(
    "/turn/{unique_chat_id}",
    response_model=ChatTurnOut,
    summary="Get a single chat turn by unique_chat_id",
)
async def get_chat_turn(unique_chat_id: str, db: AsyncSession = Depends(get_db)):
    """Retrieve a single chat turn by its unique_chat_id."""
    query = text(f"""
        SELECT unique_chat_id, session_id, hitl_id, username, user_query,
               ai_assistant_output, sql_generated, table_json, kpi_identified,
               keywords_indentifed, qb_indentifed, is_follow_up, created_at
        FROM {TABLE}
        WHERE unique_chat_id = :cid
    """)
    result = await db.execute(query, {"cid": unique_chat_id})
    row = result.mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail=f"Chat turn '{unique_chat_id}' not found")

    row_dict = dict(row)
    # Convert UUID objects to strings for Pydantic
    if row_dict.get("unique_chat_id"):
        row_dict["unique_chat_id"] = str(row_dict["unique_chat_id"])
    if row_dict.get("hitl_id"):
        row_dict["hitl_id"] = str(row_dict["hitl_id"])

    return ChatTurnOut(**row_dict)


@router.get(
    "/sessions",
    summary="List recent chat sessions",
)
async def list_sessions(
    username: Optional[str] = Query(None, description="Filter by username"),
    limit: int = Query(20, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
):
    """Return the most recent chat sessions with their last message timestamp."""
    where = "WHERE username = :username" if username else ""
    params: dict = {"lim": limit}
    if username:
        params["username"] = username

    query = text(f"""
        SELECT session_id, username,
               MIN(created_at) AS started_at,
               MAX(created_at) AS last_message_at,
               COUNT(*) AS turn_count
        FROM {TABLE}
        {where}
        GROUP BY session_id, username
        ORDER BY last_message_at DESC
        LIMIT :lim
    """)
    result = await db.execute(query, params)
    return [dict(r) for r in result.mappings().all()]
