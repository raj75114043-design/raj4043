"""
Database management endpoints – create, reset, and debug tables
Author: Venkatesh Manikantan - PwC India
Client: Nokia
"""

import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.database import get_db, async_engine, Base
from app.models.ai_assistant_models import ChatHistory, FeedBack, HumanInTheLoop

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/db", tags=["Database Management"])

SCHEMA = settings.db_schema

TABLE_MODELS = {
    "chat_history": ChatHistory,
    "feedback": FeedBack,
    "hitl": HumanInTheLoop,
}

TABLE_NAMES = {
    "chat_history": f"{SCHEMA}.ai_assistant_chat_history",
    "feedback": f"{SCHEMA}.ai_assistant_feedback_table",
    "hitl": f"{SCHEMA}.human_in_the_loop",
}


# ── Create Tables ───────────────────────────────────────────────────

@router.post(
    "/tables/create",
    summary="Create all AI Assistant tables",
    status_code=201,
)
async def create_tables():
    """
    Create the schema (if missing) and all three tables:
    ai_assistant_chat_history, ai_assistant_feedback_table, human_in_the_loop.
    Safe to call multiple times – existing tables are not recreated.
    """
    try:
        async with async_engine.begin() as conn:
            # await conn.execute(text(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}"))
            await conn.run_sync(Base.metadata.create_all)
        return {
            "status": "success",
            "tables_created": list(TABLE_NAMES.values()),
        }
    except Exception as e:
        logger.exception("Failed to create tables")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/tables/create/{table_key}",
    summary="Create a single table",
    status_code=201,
)
async def create_single_table(table_key: str):
    """
    Create a single table by key: chat_history | feedback | hitl.
    """
    if table_key not in TABLE_MODELS:
        raise HTTPException(status_code=400, detail=f"Unknown table key '{table_key}'. Use: {list(TABLE_MODELS.keys())}")

    model = TABLE_MODELS[table_key]
    try:
        async with async_engine.begin() as conn:
            # await conn.execute(text(f"CREATE SCHEMA IF NOT EXISTS {SCHEMA}"))
            await conn.run_sync(Base.metadata.create_all, tables=[model.__table__])
        return {"status": "success", "table_created": TABLE_NAMES[table_key]}
    except Exception as e:
        logger.exception(f"Failed to create table {table_key}")
        raise HTTPException(status_code=500, detail=str(e))


# ── Reset (Delete) Tables ──────────────────────────────────────────

@router.delete(
    "/tables/reset",
    summary="Drop and recreate all AI Assistant tables",
)
async def reset_all_tables():
    """
    Drop all three tables and recreate them.
    WARNING: This permanently deletes all data.
    Child tables (feedback, hitl) are dropped first to respect FK constraints.
    """
    try:
        async with async_engine.begin() as conn:
            await conn.execute(text(f"DROP TABLE IF EXISTS {TABLE_NAMES['feedback']} CASCADE"))
            await conn.execute(text(f"DROP TABLE IF EXISTS {TABLE_NAMES['hitl']} CASCADE"))
            await conn.execute(text(f"DROP TABLE IF EXISTS {TABLE_NAMES['chat_history']} CASCADE"))
            await conn.run_sync(Base.metadata.create_all)
        return {"status": "success", "message": "All tables dropped and recreated"}
    except Exception as e:
        logger.exception("Failed to reset tables")
        raise HTTPException(status_code=500, detail=str(e))


@router.delete(
    "/tables/reset/{table_key}",
    summary="Truncate a single table",
)
async def reset_single_table(table_key: str):
    """
    Truncate (delete all rows from) a single table by key: chat_history | feedback | hitl.
    Uses CASCADE so FK-dependent rows are also removed.
    """
    if table_key not in TABLE_NAMES:
        raise HTTPException(status_code=400, detail=f"Unknown table key '{table_key}'. Use: {list(TABLE_NAMES.keys())}")

    try:
        async with async_engine.begin() as conn:
            await conn.execute(text(f"TRUNCATE TABLE {TABLE_NAMES[table_key]} CASCADE"))
        return {"status": "success", "table_truncated": TABLE_NAMES[table_key]}
    except Exception as e:
        logger.exception(f"Failed to truncate {table_key}")
        raise HTTPException(status_code=500, detail=str(e))


# ── Debug / Search Endpoints ───────────────────────────────────────

@router.get(
    "/debug/session/{session_id}",
    summary="Get all data for a session across all three tables",
)
async def debug_session(session_id: str, db: AsyncSession = Depends(get_db)):
    """
    Developer debug endpoint: returns chat history, feedback, and HITL records
    for a given session_id, joined together for easy troubleshooting.
    """
    chat_query = text(f"""
        SELECT * FROM {TABLE_NAMES['chat_history']}
        WHERE session_id = :sid
        ORDER BY created_at ASC
    """)
    feedback_query = text(f"""
        SELECT * FROM {TABLE_NAMES['feedback']}
        WHERE session_id = :sid
        ORDER BY created_at ASC
    """)
    hitl_query = text(f"""
        SELECT * FROM {TABLE_NAMES['hitl']}
        WHERE session_id = :sid
        ORDER BY created_at ASC
    """)

    chat_rows = (await db.execute(chat_query, {"sid": session_id})).mappings().all()
    feedback_rows = (await db.execute(feedback_query, {"sid": session_id})).mappings().all()
    hitl_rows = (await db.execute(hitl_query, {"sid": session_id})).mappings().all()

    return {
        "session_id": session_id,
        "chat_history": [dict(r) for r in chat_rows],
        "feedback": [dict(r) for r in feedback_rows],
        "hitl": [dict(r) for r in hitl_rows],
    }


@router.get(
    "/debug/chat/{unique_chat_id}",
    summary="Get a single chat turn with its feedback and HITL records",
)
async def debug_chat_turn(unique_chat_id: str, db: AsyncSession = Depends(get_db)):
    """
    Developer debug endpoint: given a unique_chat_id, returns the chat turn
    along with any linked feedback and HITL reviews.
    """
    chat_query = text(f"""
        SELECT * FROM {TABLE_NAMES['chat_history']}
        WHERE unique_chat_id = :cid
    """)
    feedback_query = text(f"""
        SELECT * FROM {TABLE_NAMES['feedback']}
        WHERE unique_chat_id = :cid
        ORDER BY created_at ASC
    """)
    hitl_query = text(f"""
        SELECT * FROM {TABLE_NAMES['hitl']}
        WHERE unique_chat_id = :cid
        ORDER BY created_at ASC
    """)

    chat_row = (await db.execute(chat_query, {"cid": unique_chat_id})).mappings().first()
    if not chat_row:
        raise HTTPException(status_code=404, detail=f"Chat turn '{unique_chat_id}' not found")

    feedback_rows = (await db.execute(feedback_query, {"cid": unique_chat_id})).mappings().all()
    hitl_rows = (await db.execute(hitl_query, {"cid": unique_chat_id})).mappings().all()

    return {
        "chat": dict(chat_row),
        "feedback": [dict(r) for r in feedback_rows],
        "hitl": [dict(r) for r in hitl_rows],
    }


@router.get(
    "/debug/search",
    summary="Search chat history by username, keyword, or date range",
)
async def debug_search(
    db: AsyncSession = Depends(get_db),
    username: Optional[str] = Query(None, description="Filter by username"),
    keyword: Optional[str] = Query(None, description="Search in user_query and ai_assistant_output"),
    session_id: Optional[str] = Query(None, description="Filter by session_id"),
    limit: int = Query(50, ge=1, le=500, description="Max rows to return"),
):
    """
    Flexible search across chat history for developer debugging.
    All filters are optional and combined with AND.
    """
    conditions = []
    params = {"lim": limit}

    if session_id:
        conditions.append("session_id = :sid")
        params["sid"] = session_id
    if username:
        conditions.append("username = :uname")
        params["uname"] = username
    if keyword:
        conditions.append("(user_query ILIKE :kw OR ai_assistant_output ILIKE :kw)")
        params["kw"] = f"%{keyword}%"

    where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""

    query = text(f"""
        SELECT * FROM {TABLE_NAMES['chat_history']}
        {where_clause}
        ORDER BY created_at DESC
        LIMIT :lim
    """)

    rows = (await db.execute(query, params)).mappings().all()
    return {"count": len(rows), "results": [dict(r) for r in rows]}
