"""
Voice-to-Text endpoint using Azure Cognitive Services Speech SDK
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import asyncio
import json
import logging
import os
import subprocess
import tempfile

from fastapi import APIRouter, UploadFile, File, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from app.core.config import settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/voice", tags=["Voice-to-Text"])


class TranscriptionResponse(BaseModel):
    text: str
    status: str
    language: str | None = None
    duration_seconds: float | None = None


@router.post(
    "/transcribe",
    response_model=TranscriptionResponse,
    summary="Transcribe audio to text",
    description="Accepts an audio file (WAV, MP3, OGG, WEBM) and returns transcribed text using Azure Speech Services.",
)
async def transcribe_audio(
    audio: UploadFile = File(..., description="Audio file to transcribe"),
    language: str = "en-US",
):
    """
    Transcribe uploaded audio file to text via Azure Speech-to-Text.

    Supported formats: WAV (recommended), MP3, OGG, WEBM.
    """
    try:
        import azure.cognitiveservices.speech as speechsdk
    except ImportError:
        raise HTTPException(
            status_code=500,
            detail="azure-cognitiveservices-speech package is not installed. "
                   "Run: pip install azure-cognitiveservices-speech",
        )

    speech_key = settings.speech_key_1
    speech_region = settings.speech_region

    if not speech_key:
        raise HTTPException(status_code=500, detail="SPEECH_KEY_1 is not configured in .env")

    # Read the uploaded audio into memory
    audio_bytes = await audio.read()
    if not audio_bytes:
        raise HTTPException(status_code=400, detail="Empty audio file")

    logger.info(f"Received audio file: {audio.filename}, size: {len(audio_bytes)} bytes, language: {language}")

    # Write to temp file so the SDK can parse the WAV/MP3 header correctly
    suffix = os.path.splitext(audio.filename or ".wav")[1] or ".wav"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    try:
        tmp.write(audio_bytes)
        tmp.close()

        # Configure Azure Speech SDK
        speech_config = speechsdk.SpeechConfig(
            subscription=speech_key,
            region=speech_region,
        )
        speech_config.speech_recognition_language = language

        audio_config = speechsdk.audio.AudioConfig(filename=tmp.name)
        recognizer = speechsdk.SpeechRecognizer(
            speech_config=speech_config,
            audio_config=audio_config,
        )

        # Perform recognition
        result = recognizer.recognize_once()

        if result.reason == speechsdk.ResultReason.RecognizedSpeech:
            logger.info(f"Transcription successful: {len(result.text)} chars")
            return TranscriptionResponse(
                text=result.text,
                status="success",
                language=language,
                duration_seconds=result.duration / 10_000_000 if result.duration else None,
            )
        elif result.reason == speechsdk.ResultReason.NoMatch:
            detail = result.no_match_details
            logger.warning(f"No speech recognized: {detail}")
            return TranscriptionResponse(
                text="",
                status="no_match",
                language=language,
            )
        elif result.reason == speechsdk.ResultReason.Canceled:
            cancellation = result.cancellation_details
            logger.error(f"Speech recognition canceled: {cancellation.reason}, error: {cancellation.error_details}")
            raise HTTPException(
                status_code=500,
                detail=f"Speech recognition canceled: {cancellation.error_details}",
            )
        else:
            raise HTTPException(status_code=500, detail=f"Unexpected recognition result: {result.reason}")
    finally:
        os.unlink(tmp.name)


# ── Streaming endpoint ────────────────────────────────────────────────

@router.post(
    "/transcribe/stream",
    summary="Stream transcription results via SSE",
    description="Accepts an audio file and streams partial (recognizing) and final (recognized) "
                "transcription results as Server-Sent Events.",
)
async def transcribe_audio_stream(
    audio: UploadFile = File(..., description="Audio file to transcribe"),
    language: str = "en-US",
):
    """
    Stream transcription of an uploaded audio file via Server-Sent Events.

    Each SSE event is a JSON object with:
    - event: "recognizing" (partial), "recognized" (final segment), "done", or "error"
    - data: {"text": "...", "offset": ..., "duration": ...}

    The frontend can consume this with an EventSource or fetch + ReadableStream.
    """
    try:
        import azure.cognitiveservices.speech as speechsdk
    except ImportError:
        raise HTTPException(
            status_code=500,
            detail="azure-cognitiveservices-speech package is not installed. "
                   "Run: pip install azure-cognitiveservices-speech",
        )

    speech_key = settings.speech_key_1
    speech_region = settings.speech_region

    if not speech_key:
        raise HTTPException(status_code=500, detail="SPEECH_KEY_1 is not configured in .env")

    audio_bytes = await audio.read()
    if not audio_bytes:
        raise HTTPException(status_code=400, detail="Empty audio file")

    logger.info(
        f"[stream] Received audio: {audio.filename}, size: {len(audio_bytes)} bytes, language: {language}"
    )

    # Write to temp file so the SDK can parse the WAV/MP3 header correctly
    suffix = os.path.splitext(audio.filename or ".wav")[1] or ".wav"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    tmp.write(audio_bytes)
    tmp.close()

    async def event_generator():
        loop = asyncio.get_event_loop()
        queue: asyncio.Queue = asyncio.Queue()

        # Azure Speech SDK config
        speech_config = speechsdk.SpeechConfig(
            subscription=speech_key,
            region=speech_region,
        )
        speech_config.speech_recognition_language = language

        audio_config = speechsdk.audio.AudioConfig(filename=tmp.name)
        recognizer = speechsdk.SpeechRecognizer(
            speech_config=speech_config,
            audio_config=audio_config,
        )

        # ── SDK callbacks (run on SDK thread → put into async queue) ──

        def on_recognizing(evt):
            loop.call_soon_threadsafe(
                queue.put_nowait,
                {
                    "event": "recognizing",
                    "text": evt.result.text,
                    "offset": evt.result.offset,
                    "duration": evt.result.duration,
                },
            )

        def on_recognized(evt):
            loop.call_soon_threadsafe(
                queue.put_nowait,
                {
                    "event": "recognized",
                    "text": evt.result.text,
                    "offset": evt.result.offset,
                    "duration": evt.result.duration,
                },
            )

        def on_canceled(evt):
            details = evt.cancellation_details
            loop.call_soon_threadsafe(
                queue.put_nowait,
                {
                    "event": "error",
                    "reason": str(details.reason),
                    "error_details": details.error_details,
                },
            )

        def on_session_stopped(evt):
            loop.call_soon_threadsafe(
                queue.put_nowait,
                {"event": "done"},
            )

        recognizer.recognizing.connect(on_recognizing)
        recognizer.recognized.connect(on_recognized)
        recognizer.canceled.connect(on_canceled)
        recognizer.session_stopped.connect(on_session_stopped)

        # Start continuous recognition
        recognizer.start_continuous_recognition()

        # Yield SSE events from the queue until done / error
        try:
            while True:
                msg = await queue.get()
                event_type = msg.get("event", "message")
                payload = json.dumps(msg, default=str)
                yield f"event: {event_type}\ndata: {payload}\n\n"

                if event_type in ("done", "error"):
                    break
        finally:
            recognizer.stop_continuous_recognition()
            os.unlink(tmp.name)

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


# ── WebSocket endpoint (real-time mic from frontend) ─────────────────
#
# The browser's MediaRecorder sends compressed audio (webm/opus).
# Azure PushAudioInputStream needs raw PCM 16kHz 16-bit mono.
# We bridge the two with an ffmpeg subprocess that decodes on the fly.
#

def _configure_speech(speechsdk, speech_key: str, speech_region: str, language: str):
    """Create a tuned SpeechConfig for best recognition accuracy."""
    cfg = speechsdk.SpeechConfig(subscription=speech_key, region=speech_region)
    cfg.speech_recognition_language = language

    # Show spoken text exactly as-is (no masking)
    cfg.set_profanity(speechsdk.ProfanityOption.Raw)

    # Enable dictation mode — better for continuous speech (adds punctuation)
    cfg.enable_dictation()

    # Request detailed output (includes confidence, alternatives)
    cfg.output_format = speechsdk.OutputFormat.Detailed

    # Tune silence thresholds so it doesn't cut off mid-sentence
    # InitialSilenceTimeout: how long to wait for first speech (ms)
    cfg.set_property(
        speechsdk.PropertyId.SpeechServiceConnection_InitialSilenceTimeoutMs,
        "10000",
    )
    # EndSilenceTimeout: how long to wait after speech stops before finalising (ms)
    cfg.set_property(
        speechsdk.PropertyId.SpeechServiceConnection_EndSilenceTimeoutMs,
        "3000",
    )

    return cfg


class WSTranscribeInfo(BaseModel):
    """Documentation model for the WebSocket transcription endpoint."""
    endpoint: str = "ws://<host>/api/v1/voice/ws/transcribe"
    query_params: dict = {
        "language": "BCP-47 language tag (default: en-US)",
        "audio_format": "webm (default, browser MediaRecorder) or pcm (raw 16kHz/16-bit/mono)",
    }
    send: dict = {
        "binary": "Audio chunks from MediaRecorder (webm/opus, every ~250ms)",
        "text": "Send 'STOP' to end recognition",
    }
    receive: dict = {
        "recognizing": "Partial transcription result (updates as you speak)",
        "recognized": "Final transcription segment",
        "done": "Session finished",
        "error": "Something went wrong",
    }


@router.get(
    "/ws/transcribe",
    response_model=WSTranscribeInfo,
    summary="[WebSocket] Real-time speech-to-text (connection info)",
    description="**This is a WebSocket endpoint — not a REST endpoint.**\n\n"
                "Use `ws://<host>/api/v1/voice/ws/transcribe` to connect.\n\n"
                "This GET route exists only to document the WebSocket contract in Swagger UI.",
)
async def ws_transcribe_docs():
    """Return WebSocket connection info (documentation only)."""
    return WSTranscribeInfo()


@router.websocket("/ws/transcribe")
async def ws_transcribe(ws: WebSocket, language: str = "en-US", audio_format: str = "webm"):
    """
    Real-time speech-to-text over WebSocket.

    Query params:
        language     — BCP-47 language tag (default "en-US")
        audio_format — "webm" (default, browser MediaRecorder) or "pcm" (raw 16kHz/16-bit/mono)

    Frontend flow:
        1. Connect:  ws://host/api/v1/voice/ws/transcribe?language=en-US
        2. Send:     binary audio chunks from MediaRecorder (webm/opus, every ~250ms)
        3. Receive:  JSON messages with event types:
                     "recognizing" – partial result (updates as you speak)
                     "recognized"  – final segment
                     "done"        – session finished
                     "error"       – something went wrong
        4. Send:     text message "STOP" to end recognition
        5. Server sends "done" and closes the socket.

    The browser should use:
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const recorder = new MediaRecorder(stream, {
            mimeType: "audio/webm;codecs=opus"
        });
        recorder.start(250);  // chunk every 250ms

    The server uses ffmpeg to decode webm/opus → raw PCM 16kHz mono on the fly
    before feeding into Azure Speech SDK, so any browser audio format works.
    """
    try:
        import azure.cognitiveservices.speech as speechsdk
    except ImportError:
        await ws.close(code=1011, reason="azure-cognitiveservices-speech not installed")
        return

    speech_key = settings.speech_key_1
    speech_region = settings.speech_region

    if not speech_key:
        await ws.close(code=1011, reason="SPEECH_KEY_1 not configured")
        return

    await ws.accept()
    logger.info(f"[ws] Client connected, language={language}")

    loop = asyncio.get_event_loop()
    queue: asyncio.Queue = asyncio.Queue()

    # ── Azure Speech SDK setup ───────────────────────────────────────

    speech_config = _configure_speech(speechsdk, speech_key, speech_region, language)

    PCM_RATE = 16000
    stream_format = speechsdk.audio.AudioStreamFormat(
        samples_per_second=PCM_RATE,
        bits_per_sample=16,
        channels=1,
    )
    push_stream = speechsdk.audio.PushAudioInputStream(stream_format=stream_format)
    audio_config = speechsdk.audio.AudioConfig(stream=push_stream)

    recognizer = speechsdk.SpeechRecognizer(
        speech_config=speech_config,
        audio_config=audio_config,
    )

    # ── SDK callbacks → async queue ──────────────────────────────────

    def _best_text(evt):
        """Extract best text — use detailed JSON if available, else .text."""
        try:
            detailed = json.loads(evt.result.json)
            nbest = detailed.get("NBest", [])
            if nbest:
                return nbest[0].get("Display", evt.result.text)
        except Exception:
            pass
        return evt.result.text

    def on_recognizing(evt):
        loop.call_soon_threadsafe(
            queue.put_nowait,
            {"event": "recognizing", "text": evt.result.text},
        )

    def on_recognized(evt):
        text = _best_text(evt)
        loop.call_soon_threadsafe(
            queue.put_nowait,
            {"event": "recognized", "text": text},
        )

    def on_canceled(evt):
        details = evt.cancellation_details
        if details.reason == speechsdk.CancellationReason.EndOfStream:
            return
        loop.call_soon_threadsafe(
            queue.put_nowait,
            {"event": "error", "reason": str(details.reason), "error_details": details.error_details},
        )

    def on_session_stopped(evt):
        loop.call_soon_threadsafe(queue.put_nowait, {"event": "done"})

    recognizer.recognizing.connect(on_recognizing)
    recognizer.recognized.connect(on_recognized)
    recognizer.canceled.connect(on_canceled)
    recognizer.session_stopped.connect(on_session_stopped)

    recognizer.start_continuous_recognition()

    use_ffmpeg = audio_format != "pcm"

    # ── Concurrent tasks ─────────────────────────────────────────────

    async def send_results():
        """Read transcription results from the queue and send to the browser."""
        while True:
            msg = await queue.get()
            try:
                await ws.send_json(msg)
            except Exception:
                break
            if msg.get("event") in ("done", "error"):
                break

    if use_ffmpeg:
        # ── ffmpeg: decode webm/opus → raw PCM 16kHz s16le mono ──────
        ffmpeg_proc = await asyncio.create_subprocess_exec(
            "ffmpeg",
            "-hide_banner", "-loglevel", "error",
            "-f", "webm",               # input format
            "-i", "pipe:0",             # read from stdin
            "-ar", str(PCM_RATE),       # resample to 16kHz
            "-ac", "1",                 # mono
            "-f", "s16le",              # raw PCM 16-bit LE output
            "pipe:1",                   # write to stdout
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        logger.info("[ws] ffmpeg transcoder started")

        async def receive_audio():
            """Read binary audio chunks from the browser and pipe into ffmpeg stdin."""
            try:
                while True:
                    msg = await ws.receive()
                    if msg["type"] == "websocket.receive":
                        if "bytes" in msg and msg["bytes"]:
                            ffmpeg_proc.stdin.write(msg["bytes"])
                            await ffmpeg_proc.stdin.drain()
                        elif "text" in msg and msg["text"]:
                            if msg["text"].strip().upper() == "STOP":
                                logger.info("[ws] Client sent STOP")
                                break
                    elif msg["type"] == "websocket.disconnect":
                        break
            except WebSocketDisconnect:
                logger.info("[ws] Client disconnected")
            finally:
                ffmpeg_proc.stdin.close()

        async def ffmpeg_to_sdk():
            """Read decoded PCM from ffmpeg stdout and push into Azure PushAudioInputStream."""
            try:
                while True:
                    chunk = await ffmpeg_proc.stdout.read(3200)
                    if not chunk:
                        break
                    push_stream.write(chunk)
            finally:
                push_stream.close()

        try:
            await asyncio.gather(receive_audio(), ffmpeg_to_sdk(), send_results())
        finally:
            recognizer.stop_continuous_recognition()
            if ffmpeg_proc.returncode is None:
                ffmpeg_proc.kill()
                await ffmpeg_proc.wait()
    else:
        # ── Raw PCM mode (notebook / direct testing) ─────────────────
        logger.info("[ws] Raw PCM mode (no ffmpeg)")

        async def receive_pcm():
            """Read raw PCM chunks from WS and push directly into Azure SDK."""
            try:
                while True:
                    msg = await ws.receive()
                    if msg["type"] == "websocket.receive":
                        if "bytes" in msg and msg["bytes"]:
                            push_stream.write(msg["bytes"])
                        elif "text" in msg and msg["text"]:
                            if msg["text"].strip().upper() == "STOP":
                                logger.info("[ws] Client sent STOP")
                                break
                    elif msg["type"] == "websocket.disconnect":
                        break
            except WebSocketDisconnect:
                logger.info("[ws] Client disconnected")
            finally:
                push_stream.close()

        try:
            await asyncio.gather(receive_pcm(), send_results())
        finally:
            recognizer.stop_continuous_recognition()
        logger.info("[ws] Session ended")
