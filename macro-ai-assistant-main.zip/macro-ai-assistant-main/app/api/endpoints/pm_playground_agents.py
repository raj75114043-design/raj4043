"""
AI Assistant → PM Playground bridge endpoint
Forwards validated queries to the PM Copilot Playground backend

Author: Venkatesh Manikantan, Senior Associate, PwC India

Client: Nokia
"""

import asyncio
import json
import logging
import time
from datetime import datetime
from typing import Optional, List
from uuid import uuid4
import pandas as pd

from fastapi import APIRouter, Query, Depends, HTTPException, UploadFile, File
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field, field_validator
import asyncpg
import httpx
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import insert, update, text

from app.core.config import settings
from app.db.database import get_db, AsyncSessionLocal
from app.models.pm_playground_models import PMPlaygroundUserUploadData
from app.services.pm_playground_file_service import process_upload_file
from app.services.parallel_kpi_key_qb_search import parallel_search
from app.agents.hitL_play_agent import run_hitl_agent
from app.agents.pm_playground_agent import run_playground_agent
from app.agents.sql_agent.graph import run_sql_agent
from app.agents.csv_agent.graph import CSVAgent
from app.agents.csv_agent.state import create_initial_state
from app.chains.high_chart_graph_gen.hi_chart_graph import generate_hichart_graphs

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/playground", tags=["PM Playground"])


# ── Helper: Adaptive CSV agent query generation ────────────────────────
def _generate_csv_agent_query(
    original_query: str,
    sub_questions: List[str],
    dataframes: List[pd.DataFrame],
) -> str:
    """
    Generate an adaptive query for CSV agent based on the number of tables.

    Logic:
    - If 1 table: Drill down into detailed analysis of that single table
    - If >1 table: Do compare/contrast analysis across tables, synthesize insights

    Args:
        original_query: User's original query
        sub_questions: List of sub-questions that generated these tables
        dataframes: List of DataFrames from SQL queries

    Returns:
        Adapted query for CSV agent
    """
    num_tables = len(dataframes)

    if num_tables == 0:
        return f"Analyze: {original_query}"

    elif num_tables == 1:
        # Single table: Drill down deeper
        df = dataframes[0]
        shape_info = f"({df.shape[0]} rows, {df.shape[1]} columns)"
        return (
            f"Drill deeper into this single result table {shape_info}. "
            f"Original query: {original_query}. "
            f"Identify key patterns, outliers, trends, and insights within the data. "
            f"Provide detailed analysis rather than just summarizing the data."
        )

    else:
        # Multiple tables: Compare and contrast
        table_descriptions = []
        for i, df in enumerate(dataframes, 1):
            # Infer what this table is from its sub-question if available
            sub_q = sub_questions[i-1] if i-1 < len(sub_questions) else f"Sub-question {i}"
            shape_info = f"({df.shape[0]} rows)"
            table_descriptions.append(f"Table {i} from '{sub_q}': {shape_info}")

        tables_summary = "\n".join(table_descriptions)

        return (
            f"Compare and contrast analysis across {num_tables} result tables:\n{tables_summary}\n\n"
            f"Original user query: {original_query}\n\n"
            f"Synthesize a consolidated analysis that:\n"
            f"1. Identifies what each table represents and its key metrics\n"
            f"2. Compares performance/patterns across the tables\n"
            f"3. Highlights similarities and differences\n"
            f"4. Provides integrated insights that answer the original query holistically\n"
            f"5. Synthesizes a single consolidated output that combines findings from all tables"
        )


# ── Database configuration ────────────────────────────────────────
DB_CONFIG = {
    "host": settings.db_host,
    "port": settings.db_port,
    "user": settings.db_user,
    "password": settings.db_password,
    "database": settings.db_name,
    "server_settings": {"search_path": f"{settings.db_schema_staging},public"},
}

SCHEMA = settings.db_schema
TABLE_NAMES = {
    "pm_playground_user_upload_data": f"{SCHEMA}.pm_playground_user_upload_data",
}


# Create a New Session

@router.post(
    "/session_play",
    summary="Create a new chat session",
    description="Returns a unique session_id for the frontend to use when "
                "the user logs in or clicks 'New Chat'.",
)
async def create_session():
    """Generate and return a new unique session ID."""
    return {"session_id": str(uuid4())}



# ── PM Playground Upload Data Endpoints ────────────────────────────────
# End Point to Upload CSV/EXCEL Data into Backend
# Note: Only one upload per session_id is allowed

@router.post(
    "/pm-playground/upload-data/save",
    summary="Save user-uploaded CSV/Excel file as JSON",
    status_code=201,
)
async def save_upload_data(
    session_id: str = Query(..., description="Session identifier (required)"),
    file: UploadFile = File(..., description="CSV or Excel file to upload"),
    db: AsyncSession = Depends(get_db)
):
    """
    Upload and process a CSV or Excel file, converting it to JSON and storing in the database.

    - Only one upload per session_id is allowed. If data already exists, it will be updated.
    - CSV files are read directly.
    - Excel files: only the first sheet is processed.
    - Generates a unique data_upload_id using UUID4.

    Query Parameters:
    - session_id: Session identifier (required)

    Form Data:
    - file: CSV or Excel file (required)

    Supported file types: .csv, .xlsx, .xls

    Returns:
    - status: "success" or error status
    - message: Human-readable status message
    - session_id: The provided session ID
    - data_upload_id: Generated UUID for this upload
    - num_rows: Number of rows in the table
    - num_columns: Number of columns in the table
    - table_data: The extracted table data as JSON (array of objects) - for frontend rendering
    - action: "created" (new upload) or "updated" (existing upload)
    """
    try:
        # Validate session_id
        if not session_id or not session_id.strip():
            raise HTTPException(
                status_code=400,
                detail="session_id is required and cannot be empty"
            )

        # Process the uploaded file
        logger.info(f"Processing file upload for session_id: {session_id}, filename: {file.filename}")
        table_json, num_rows, num_columns = await process_upload_file(file)

        # Check if data already exists for this session
        check_query = text(f"""
            SELECT data_upload_id FROM {TABLE_NAMES['pm_playground_user_upload_data']}
            WHERE session_id = :sid
        """)
        existing = (await db.execute(check_query, {"sid": session_id})).mappings().first()

        if existing:
            # Update existing record
            logger.info(f"Updating existing upload data for session_id: {session_id}")
            update_stmt = update(PMPlaygroundUserUploadData).where(
                PMPlaygroundUserUploadData.session_id == session_id
            ).values(table_json=table_json)
            await db.execute(update_stmt)
            await db.commit()

            return {
                "status": "success",
                "message": "Upload data updated successfully",
                "session_id": session_id,
                "data_upload_id": existing['data_upload_id'],
                "num_rows": num_rows,
                "num_columns": num_columns,
                "table_data": table_json,
                "action": "updated"
            }
        else:
            # Create new record
            logger.info(f"Creating new upload data for session_id: {session_id}")
            stmt = insert(PMPlaygroundUserUploadData).values(
                session_id=session_id,
                table_json=table_json
            )
            await db.execute(stmt)
            await db.commit()

            # Query back to get the ID that was created
            get_query = text(f"""
                SELECT data_upload_id FROM {TABLE_NAMES['pm_playground_user_upload_data']}
                WHERE session_id = :sid
                ORDER BY created_at DESC
                LIMIT 1
            """)
            new_record = (await db.execute(get_query, {"sid": session_id})).mappings().first()
            data_upload_id = new_record['data_upload_id'] if new_record else None

            logger.info(f"Successfully created upload data. data_upload_id: {data_upload_id}")

            return {
                "status": "success",
                "message": "Upload data saved successfully",
                "session_id": session_id,
                "data_upload_id": data_upload_id,
                "num_rows": num_rows,
                "num_columns": num_columns,
                "table_data": table_json,
                "action": "created"
            }

    except HTTPException:
        await db.rollback()
        raise
    except Exception as e:
        await db.rollback()
        logger.exception(f"Failed to save upload data for session_id: {session_id}")
        raise HTTPException(
            status_code=500,
            detail=f"Error saving upload data: {str(e)}"
        )




# ── PM Playground Query Request Schema ────────────────────────────────────────

class PlaygroundQueryRequest(BaseModel):
    """Request schema for PM Playground query with dropdown filters."""

    session_id: str = Field(..., description="Session identifier")
    username: str = Field(default="anonymous", description="Username of requester")
    data_upload: bool = Field(default=False, description="Whether user uploaded a file")
    data_upload_id: Optional[str] = Field(
        default=None, description="UUID of uploaded data if data_upload=True"
    )
    user_query: str = Field(..., min_length=1, description="User's natural language question")
    market: List[str] = Field(
        default=[], max_length=3, description="Selected markets (max 3)"
    )
    region: List[str] = Field(
        default=[], max_length=3, description="Selected regions (max 3)"
    )
    area: List[str] = Field(
        default=[], max_length=3, description="Selected areas (max 3)"
    )
    vendors: List[str] = Field(
        default=[], max_length=3, description="Selected vendors/construction status (max 3)"
    )
    kpis: List[str] = Field(
        default=[], max_length=3, description="Selected KPIs (max 3)"
    )
    project: str = Field(
        ..., description="Project code: NTM, NAS, or AHLO-A"
    )
    date_start: Optional[str] = Field(
        default=None, description="Start date in mm/dd/yyyy format"
    )
    date_end: Optional[str] = Field(
        default=None, description="End date in mm/dd/yyyy format"
    )

    @field_validator("date_start", "date_end", mode="before")
    @classmethod
    def validate_date_format(cls, v: Optional[str]) -> Optional[str]:
        """Accept mm/dd/yyyy or yyyy-mm-dd; normalize to mm/dd/yyyy."""
        if v is None or v == "":
            return None
        for fmt in ("%m/%d/%Y", "%Y-%m-%d"):
            try:
                return datetime.strptime(v, fmt).strftime("%m/%d/%Y")
            except ValueError:
                continue
        raise ValueError(
            f"Invalid date format '{v}'. Expected mm/dd/yyyy or yyyy-mm-dd"
        )


# ── SSE Event Helper ───────────────────────────────────────────────────────

def _sse_event(event: str, data: dict) -> str:
    """Format a Server-Sent Event string."""
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"


# ── Database Helper Functions ──────────────────────────────────────────────

async def _fetch_user_upload_df(data_upload_id: str) -> Optional[pd.DataFrame]:
    """
    Fetch uploaded data from DB and convert to DataFrame.

    Returns DataFrame or None if not found/empty.
    """
    try:
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                text(f"""
                    SELECT table_json FROM {SCHEMA}.pm_playground_user_upload_data
                    WHERE data_upload_id = :id
                """),
                {"id": data_upload_id},
            )
            row = result.mappings().first()
            if row and row["table_json"]:
                records = json.loads(row["table_json"])
                return pd.DataFrame(records)
    except Exception as e:
        logger.error(f"Failed to fetch user upload {data_upload_id}: {e}")
    return None


# ── Endpoints ──────────────────────────────────────────────────────────────

@router.post(
    "/pm-playground/query",
    summary="Query PM Playground with dropdown filters (SSE stream)",
    description="Streams results via SSE: parallel search → HITL → query splitting → SQL agents → CSV synthesis → final chart",
)
async def query_playground(request: PlaygroundQueryRequest):
    """
    Full PM Playground orchestration with SSE streaming.

    Flow:
    1. Validate inputs (project required, at least one filter)
    2. Enrich query with dropdown context
    3. Run parallel search
    4. Run HITL agent (route general/clarification/data)
    5. If data query: run playground agent to split into 1-3 sub-questions
    6. For each sub-question: parallel search → SQL agent → high chart
    7. CSV agent synthesis on all collected tables (+ user upload if provided)
    8. Final aggregate high chart
    9. Send chat_end event

    Returns:
        StreamingResponse with SSE events
    """

    async def _event_generator():
        # ── Step 1: Validation ─────────────────────────────────────────
        valid_projects = {"NTM", "NAS", "AHLO-A"}
        if request.project not in valid_projects:
            yield _sse_event("validation_failed", {
                "message": f"Invalid project. Choose from: {', '.join(valid_projects)}"
            })
            yield "event:chat_end\n\n"
            return

        has_filters = any([
            request.market,
            request.region,
            request.area,
            request.vendors,
            request.kpis,
        ])

        if not has_filters:
            yield _sse_event("validation_failed", {
                "message": "At least one filter (Market, Region, Area, Vendor, or KPI) is required"
            })
            yield "event:chat_end\n\n"
            return

        # ── Step 2: Build enriched query ───────────────────────────────
        enriched_query = f"{request.user_query} [Project: {request.project}]"
        if request.region:
            enriched_query += f" [Region: {', '.join(request.region)}]"
        if request.area:
            enriched_query += f" [Area: {', '.join(request.area)}]"
        if request.market:
            enriched_query += f" [Market: {', '.join(request.market)}]"
        if request.vendors:
            enriched_query += f" [Vendor: {', '.join(request.vendors)}]"
        if request.kpis:
            enriched_query += f" [KPIs: {', '.join(request.kpis)}]"
        if request.date_start or request.date_end:
            date_range = f"[Date Range: "
            if request.date_start:
                date_range += f"from {request.date_start}"
            if request.date_end:
                date_range += f" to {request.date_end}" if request.date_start else f"until {request.date_end}"
            enriched_query += date_range + "]"

        # Add SQL table + column mapping context
        enriched_query += " [Data Source: stg_ndpd_mbt_tmobile_macro_combined | Relevant Columns: rgn_region, m_area, m_market, construction_gc, and related KPI metrics]"

        yield _sse_event("validation_complete", {
            "project": request.project,
            "market": request.market,
            "region": request.region,
            "area": request.area,
            "vendors": request.vendors,
            "kpis": request.kpis,
            "date_start": request.date_start,
            "date_end": request.date_end,
            "enriched_query": enriched_query,
        })

        # ── Step 3: Parallel Search ────────────────────────────────────
        try:
            search = await parallel_search(enriched_query)
        except Exception as e:
            logger.error(f"Parallel search failed: {e}")
            yield _sse_event("error", {"message": f"Search failed: {e}"})
            yield "event:chat_end\n\n"
            return

        keyword_names = search.get("keyword_names", [])
        keyword_ids = search.get("keyword_ids", [])
        keyword_results = search.get("keyword_results", [])
        kpi_names = search.get("kpi_names", [])
        kpi_ids = search.get("kpi_ids", [])
        kpi_results = search.get("kpi_results", [])
        qb_names = search.get("qb_names", [])
        qb_ids = search.get("qb_ids", [])
        qb_results = search.get("qb_results", [])

        yield _sse_event("search_keywords", {
            "keyword_names": keyword_names,
            "keyword_ids": keyword_ids,
            "keyword_results": keyword_results,
            "found": len(keyword_names) > 0,
        })

        yield _sse_event("search_kpis", {
            "kpi_names": kpi_names,
            "kpi_ids": kpi_ids,
            "kpi_results": kpi_results,
            "found": len(kpi_names) > 0,
        })

        yield _sse_event("search_qb", {
            "qb_names": qb_names,
            "qb_ids": qb_ids,
            "qb_results": qb_results,
            "found": len(qb_names) > 0,
        })

        yield _sse_event("search_complete", {
            "status": "ok",
            "keyword_names": keyword_names,
            "keyword_ids": keyword_ids,
            "keyword_results": keyword_results,
            "kpi_names": kpi_names,
            "kpi_ids": kpi_ids,
            "kpi_results": kpi_results,
            "qb_names": qb_names,
            "qb_ids": qb_ids,
            "qb_results": qb_results,
        })

        # ── Step 4: HITL Agent ─────────────────────────────────────────
        unique_chat_id = str(uuid4())
        hitl_id = str(uuid4())

        yield _sse_event("hitl_start", {
            "unique_chat_id": unique_chat_id,
            "hitl_id": hitl_id,
            "message": "Analysing your query…",
        })

        try:
            hitl = await run_hitl_agent(
                user_query=enriched_query,
                keyword_results=keyword_results,
                kpi_results=kpi_results,
                qb_results=qb_results,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_questions=qb_names,
                is_follow_up=False,
                previous_user_query="",
                previous_clarifying_message="",
            )
        except Exception as e:
            logger.error(f"HITL agent failed: {e}")
            yield _sse_event("error", {"message": f"HITL processing failed: {e}"})
            yield "event:chat_end\n\n"
            return

        query_type = hitl.get("query_type", "")
        ready_for_sql = hitl.get("ready_for_sql", False)

        # Route: general query
        if query_type == "general":
            yield _sse_event("hitl_complete", {
                "unique_chat_id": unique_chat_id,
                "hitl_id": hitl_id,
                "query_type": "general",
                "ready_for_sql": False,
                "general_response": hitl.get("general_response", ""),
            })
            yield "event:chat_end\n\n"
            return

        # Route: needs clarification
        if query_type == "data" and not ready_for_sql:
            yield _sse_event("hitl_complete", {
                "unique_chat_id": unique_chat_id,
                "hitl_id": hitl_id,
                "query_type": "data",
                "ready_for_sql": False,
                "clarifying_message": hitl.get("clarifying_message", ""),
            })
            yield "event:chat_end\n\n"
            return

        # Route: ready for SQL
        yield _sse_event("hitl_complete", {
            "unique_chat_id": unique_chat_id,
            "hitl_id": hitl_id,
            "query_type": "data",
            "ready_for_sql": True,
            "message": "Query validated — proceeding to analysis.",
        })

        # ── Step 5: Playground Agent (Query Splitter) ──────────────────
        yield _sse_event("playground_start", {
            "message": "Splitting query into sub-questions…",
        })

        try:
            playground = await run_playground_agent(
                user_query=request.user_query,
                project=request.project,
                market=request.market,
                region=request.region,
                area=request.area,
                vendors=request.vendors,
                kpis=request.kpis,
            )
        except Exception as e:
            logger.error(f"Playground agent failed: {e}")
            yield _sse_event("error", {"message": f"Query splitting failed: {e}"})
            yield "event:chat_end\n\n"
            return

        sub_questions = playground.get("sub_questions", [request.user_query])
        if not sub_questions:
            sub_questions = [request.user_query]

        yield _sse_event("playground_split", {
            "num_sub_questions": len(sub_questions),
            "sub_questions": sub_questions,
        })

        # ── Step 6: SQL Agents (reuse initial search results) ────────────────────────
        # Reuse the search results from Step 3 for all sub-questions to reduce API load
        # No need to search again—the enriched query already captured all relevant context
        logger.info(f"Reusing initial search results for {len(sub_questions)} sub-questions")

        # Yield per-question search events using the cached search results
        for i, q in enumerate(sub_questions):
            yield _sse_event(f"sql_search_complete_{i+1}", {
                "question_index": i + 1,
                "question": q,
                "keyword_names": keyword_names,
                "keyword_ids": keyword_ids,
                "keyword_results": keyword_results,
                "kpi_names": kpi_names,
                "kpi_ids": kpi_ids,
                "kpi_results": kpi_results,
                "qb_names": qb_names,
                "qb_ids": qb_ids,
                "qb_results": qb_results,
            })

        # Launch SQL agents in parallel using cached search results
        sql_tasks = [
            asyncio.create_task(
                asyncio.wait_for(
                    run_sql_agent(
                        user_query=q,
                        keyword_names=keyword_names,
                        kpi_names=kpi_names,
                        qb_names=qb_names,
                        is_follow_up=False,
                        previous_user_query="",
                        previous_clarifying_message="",
                        previous_generated_sql="",
                    ),
                    timeout=360.0,
                )
            )
            for q in sub_questions
        ]

        # ── Step 6 & 7 (Pipelined): SQL → Chart as each completes ─────────────
        # Track results indexed by question number
        sql_results = [None] * len(sub_questions)
        chart_tasks = {}  # {question_index: task}

        # Create a mapping from task to question index
        task_to_index = {task: i for i, task in enumerate(sql_tasks)}

        # Monitor SQL tasks as they complete and spawn charts immediately
        last_ping = time.time()
        pending_sql = set(sql_tasks)
        pending_charts = set()

        while pending_sql or pending_charts:
            # Combine all pending tasks for unified monitoring
            all_pending = pending_sql | pending_charts

            # Wait for any task to complete (timeout=15 to ensure keep-alive fires every ~30s)
            if all_pending:
                done_tasks, _ = await asyncio.wait(all_pending, timeout=15, return_when=asyncio.FIRST_COMPLETED)
            else:
                # No tasks pending, exit loop
                break

            # Process completed SQL tasks
            for task in done_tasks:
                if task in pending_sql:
                    pending_sql.discard(task)
                    q_idx = task_to_index[task]
                    question_index = q_idx + 1
                    q = sub_questions[q_idx]

                    # Collect SQL result
                    try:
                        sql_result = task.result()
                        sql_results[q_idx] = sql_result
                        yield _sse_event(f"sql_complete_{question_index}", {
                            "question_index": question_index,
                            "success": sql_result.get("success", False),
                            "generated_sql": sql_result.get("generated_sql", ""),
                            "table_json": sql_result.get("result_df", None).to_json(orient="records") if sql_result.get("result_df") is not None else "",
                            "error": sql_result.get("error", ""),
                        })

                        # Spawn chart task immediately if SQL succeeded
                        if sql_result.get("success", False) and sql_result.get("result_df") is not None:
                            table_json = sql_result["result_df"].to_json(orient="records")
                            chart_task = asyncio.create_task(
                                asyncio.wait_for(
                                    generate_hichart_graphs(
                                        user_query=q,
                                        table_json=table_json,
                                        generated_sql=sql_result.get("generated_sql", ""),
                                    ),
                                    timeout=300.0,
                                )
                            )
                            chart_tasks[question_index] = chart_task
                            pending_charts.add(chart_task)

                    except asyncio.TimeoutError:
                        logger.error(f"SQL agent {question_index} timed out")
                        sql_results[q_idx] = {"success": False, "error": "Timeout"}
                        yield _sse_event(f"sql_complete_{question_index}", {
                            "question_index": question_index,
                            "success": False,
                            "error": "SQL generation timed out",
                        })
                    except Exception as e:
                        logger.error(f"SQL agent {question_index} failed: {e}")
                        sql_results[q_idx] = {"success": False, "error": str(e)}
                        yield _sse_event(f"sql_complete_{question_index}", {
                            "question_index": question_index,
                            "success": False,
                            "error": str(e),
                        })

            # Process completed chart tasks
            for task in done_tasks:
                if task in pending_charts:
                    pending_charts.discard(task)
                    # Find which question index this chart belongs to
                    question_index = next((idx for idx, t in chart_tasks.items() if t is task), None)
                    if question_index:
                        try:
                            chart_result = task.result()
                            yield _sse_event(f"graph_complete_{question_index}", {
                                "question_index": question_index,
                                "charts": chart_result.charts if hasattr(chart_result, "charts") else [],
                                "rationale": chart_result.rationale if hasattr(chart_result, "rationale") else "",
                            })
                        except Exception as e:
                            logger.error(f"Chart generation {question_index} failed: {e}")
                            yield _sse_event(f"graph_complete_{question_index}", {
                                "question_index": question_index,
                                "error": str(e),
                            })

            # Keep-alive ping every 30 seconds (guaranteed even during task transitions)
            if time.time() - last_ping > 25:
                yield ": keep-alive\n\n"
                last_ping = time.time()

        # ── Step 8: CSV Agent Synthesis ────────────────────────────────
        # Collect all result DataFrames
        all_dfs = []
        for sql_result in sql_results:
            if sql_result and sql_result.get("success", False) and sql_result.get("result_df") is not None:
                all_dfs.append(sql_result["result_df"])

        # Fetch user upload if provided
        if request.data_upload and request.data_upload_id:
            user_df = await _fetch_user_upload_df(request.data_upload_id)
            if user_df is not None:
                all_dfs.append(user_df)

        # If no data collected, skip CSV synthesis
        total_rows = sum(df.shape[0] for df in all_dfs)
        if not all_dfs or total_rows == 0:
            logger.warning(f"No data available for CSV synthesis (total_rows={total_rows})")
            yield _sse_event("csv_complete", {
                "message": "No data available for synthesis",
                "final_table_json": "[]",
            })
            yield "event:chat_end\n\n"
            return

        # Build schema string
        schema_text = ""
        for i, df in enumerate(all_dfs):
            schema_text += f"\nDataFrame {i+1}: {list(df.columns)} ({df.shape[0]} rows)\n"

        # Run CSV agent
        yield _sse_event("csv_start", {
            "num_dataframes": len(all_dfs),
            "has_upload": bool(request.data_upload and request.data_upload_id),
        })

        try:
            # Generate adaptive query based on number of tables
            csv_agent_query = _generate_csv_agent_query(
                original_query=request.user_query,
                sub_questions=sub_questions,
                dataframes=all_dfs,
            )
            logger.info(
                f"CSV Agent Query (num_tables={len(all_dfs)}):\n{csv_agent_query}"
            )

            csv_state = create_initial_state(
                user_query=csv_agent_query,
                dataframes=all_dfs,
                schema=schema_text,
                user_context=f"Project: {request.project}",
            )

            logger.info("Creating CSVAgent...")
            csv_agent = CSVAgent()
            logger.info("CSVAgent created, invoking with state...")
            csv_task = asyncio.create_task(
                asyncio.wait_for(csv_agent.ainvoke(csv_state), timeout=360.0)
            )

            # Keep-alive
            last_ping = time.time()
            while not csv_task.done():
                if time.time() - last_ping > 30:
                    yield ": keep-alive\n\n"
                    last_ping = time.time()
                await asyncio.sleep(1)

            logger.info("CSV agent task completed, retrieving result...")
            try:
                csv_final = csv_task.result()
                logger.info("CSV agent result retrieved successfully")
            except Exception as e:
                logger.error(f"CSV agent task.result() raised: {type(e).__name__}: {e}", exc_info=True)
                raise

            # Extract output
            output_df = csv_final.get("output_df", [])
            output_df = output_df[-1] if output_df else None
            output_data = csv_final.get("output_data", [])
            output_data = output_data[-1] if output_data else ""
            text_explanation = csv_final.get("text_explanation", [])
            text_explanation = text_explanation[-1] if text_explanation else ""
            agent_steps = csv_final.get("agent_steps_explanation", [])
            agent_steps = agent_steps[-1] if agent_steps else ""

            final_table_json = ""
            if output_df is not None and isinstance(output_df, pd.DataFrame):
                final_table_json = output_df.to_json(orient="records")

            # Convert Message objects to strings for JSON serialization
            output_data_str = str(output_data)[:500] if output_data else ""
            text_explanation_str = str(text_explanation) if text_explanation else ""
            agent_steps_str = str(agent_steps) if agent_steps else ""

            yield _sse_event("csv_complete", {
                "output_data": output_data_str,
                "text_explanation": text_explanation_str,
                "agent_steps_explanation": agent_steps_str,
                "final_table_json": final_table_json,
            })

            # ── Step 9: Final High Chart ──────────────────────────────
            if final_table_json:
                yield _sse_event("final_graph_start", {
                    "message": "Generating final aggregate chart…",
                })

                try:
                    final_chart_task = asyncio.create_task(
                        asyncio.wait_for(
                            generate_hichart_graphs(
                                user_query=request.user_query,
                                table_json=final_table_json,
                                generated_sql="",
                            ),
                            timeout=300.0,
                        )
                    )

                    # Keep-alive
                    last_ping = time.time()
                    while not final_chart_task.done():
                        if time.time() - last_ping > 30:
                            yield ": keep-alive\n\n"
                            last_ping = time.time()
                        await asyncio.sleep(1)

                    final_chart = final_chart_task.result()
                    yield _sse_event("final_graph_complete", {
                        "charts": final_chart.charts if hasattr(final_chart, "charts") else [],
                        "rationale": str(final_chart.rationale) if hasattr(final_chart, "rationale") else "",
                    })
                except Exception as e:
                    logger.error(f"Final chart generation failed: {e}")
                    yield _sse_event("final_graph_error", {
                        "error": str(e),
                    })

        except asyncio.TimeoutError:
            logger.error("CSV agent timed out")
            yield _sse_event("csv_error", {"error": "CSV synthesis timed out"})
            yield "event:chat_end\n\n"
        except Exception as e:
            logger.error(f"CSV agent failed: {type(e).__name__}: {e}", exc_info=True)
            yield _sse_event("csv_error", {"error": f"{type(e).__name__}: {str(e)[:150]}"})
            yield "event:chat_end\n\n"

        # ── Step 10: End of stream ─────────────────────────────────────
        yield "event:chat_end\n\n"

    return StreamingResponse(_event_generator(), media_type="text/event-stream")

