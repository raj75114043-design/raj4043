"""
AI Assistant → PM Playground bridge endpoint
Forwards validated queries to the PM Copilot Playground backend

Author: Venkatesh Manikantan, Senior Associate, PwC India

Client: Nokia
"""

import logging
from typing import Optional, List
from fastapi import APIRouter, Query
from pydantic import BaseModel, Field
from uuid import uuid4
import asyncpg
import httpx

from app.core.config import settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/playground_utility", tags=["PM Playground Utility"])

DB_CONFIG = {
    "host": settings.db_host,
    "port": settings.db_port,
    "user": settings.db_user,
    "password": settings.db_password,
    "database": settings.db_name,
    "server_settings": {"search_path": f"{settings.db_schema_staging},public"},
}


# ── Dropdown Selection Schemas ────────────────────────────────────

class AreaItem(BaseModel):
    """Dropdown item for areas."""
    market: Optional[str] = None
    region: Optional[str] = None
    area: Optional[str] = None


class AreaListResponse(BaseModel):
    """Response for areas dropdown."""
    success: bool
    areas: List[AreaItem] = []
    total: int = 0


class KPIItem(BaseModel):
    """KPI item from external API."""
    kpi_name: str
    kpi_id: int
    kpi_description: Optional[str] = None


class KPIListResponse(BaseModel):
    """Response for KPI dropdown."""
    success: bool
    kpis: List[KPIItem] = []
    total: int = 0
    skip: int = 0
    limit: int = 0


class SiteItem(BaseModel):
    """Site item from database."""
    site_id: str


class SiteListResponse(BaseModel):
    """Response for sites dropdown."""
    success: bool
    sites: List[SiteItem] = []
    total: int = 0


class ConstructionItem(BaseModel):
    """Construction status item from database."""
    status: str


class ConstructionListResponse(BaseModel):
    """Response for construction status dropdown."""
    success: bool
    statuses: List[ConstructionItem] = []
    total: int = 0


class ProjectItem(BaseModel):
    """Project item."""
    name: str
    code: str


class ProjectListResponse(BaseModel):
    """Response for projects dropdown."""
    success: bool
    projects: List[ProjectItem] = []
    total: int = 0


# ── Nested Hierarchy Schemas ──────────────────────────────────────

class VendorItem(BaseModel):
    """Vendor (construction status) item."""
    vendor: str


class MarketItem(BaseModel):
    """Market item with vendors."""
    market: str
    vendors: List[VendorItem] = []


class AreaNested(BaseModel):
    """Area item with markets and vendors."""
    area: str
    markets: List[MarketItem] = []


class RegionItem(BaseModel):
    """Region item with full hierarchy."""
    region: str
    areas: List[AreaNested] = []


class HierarchyResponse(BaseModel):
    """Response for nested dropdown hierarchy (Region > Area > Market > Vendor)."""
    success: bool
    regions: List[RegionItem] = []
    total: int = 0


# ── Dropdown Selection Endpoints ───────────────────────────────────


@router.get(
    "/dropdown/kpis",
    response_model=KPIListResponse,
    summary="Get KPIs for dropdown selection",
    description="Returns list of KPIs from external KPI List API with pagination support.",
)
async def get_kpis_dropdown(skip: int = Query(0, ge=0), limit: int = Query(100, ge=1, le=1000)):
    """
    Fetch KPIs from external PM Copilot KPI List API.
    Used to populate KPI selection dropdown in PM Playground frontend.
    """
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            params = {
                "skip": skip,
                "limit": limit,
            }
            response = await client.get(
                "https://pm-copilot-macro-gcl-osdp-gsd-gsd-delivery-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/kpi/kpi",
                params=params,
            )
            response.raise_for_status()

            data = response.json()

            # Handle both list response and paginated response formats
            if isinstance(data, list):
                kpi_list = data
                total = len(data)
            elif isinstance(data, dict) and "items" in data:
                kpi_list = data.get("items", [])
                total = data.get("total", len(kpi_list))
            else:
                kpi_list = []
                total = 0

            kpis = [
                KPIItem(
                    kpi_name=kpi.get("kpi_name", ""),
                    kpi_id=kpi.get("kpi_id", 0),
                    kpi_description=kpi.get("kpi_description"),
                )
                for kpi in kpi_list
            ]

            logger.info(f"Retrieved {len(kpis)} KPIs from external API")
            return KPIListResponse(
                success=True,
                kpis=kpis,
                total=total,
                skip=skip,
                limit=limit,
            )
    except Exception:
        logger.exception("Error fetching KPIs dropdown")
        return KPIListResponse(
            success=False,
            kpis=[],
            total=0,
            skip=skip,
            limit=limit,
        )






@router.get(
    "/dropdown/projects",
    response_model=ProjectListResponse,
    summary="Get available projects for dropdown selection",
    description="Returns the list of available projects: NTM, AHLO-A, and NAS.",
)
async def get_projects_dropdown():
    """
    Returns hardcoded list of available projects.
    Used to populate project selection dropdown in PM Playground frontend.
    """
    try:
        projects = [
            ProjectItem(name="MACRO", code="NTM"),
            ProjectItem(name="AHLOB Modernization", code="AHLO-A"),
            ProjectItem(name="Network Assurance Services", code="NAS"),
        ]

        logger.info(f"Retrieved {len(projects)} projects")
        return ProjectListResponse(
            success=True,
            projects=projects,
            total=len(projects),
        )
    except Exception:
        logger.exception("Error fetching projects dropdown")
        return ProjectListResponse(
            success=False,
            projects=[],
            total=0,
        )


@router.get(
    "/dropdown/hierarchy",
    response_model=HierarchyResponse,
    summary="Get nested dropdown hierarchy (Region > Area > Market > Vendor)",
    description="Returns the complete hierarchical structure for cascading dropdowns. "
                "Region contains Areas, Area contains Markets, Market contains Vendors (construction statuses).",
)
async def get_hierarchy_dropdown():
    """
    Fetch complete hierarchy from stg_ndpd_mbt_tmobile_macro_combined table.
    Builds nested structure: Region > Area > Market > Vendor

    Used to populate cascading dropdown menus in PM Playground frontend.
    """
    try:
        conn = await asyncpg.connect(**DB_CONFIG)
        try:
            # Fetch all distinct combinations of region, area, market, and vendor (construction_gc)
            rows = await conn.fetch("""
                SELECT DISTINCT
                    rgn_region,
                    m_area,
                    m_market,
                    construction_gc
                FROM stg_ndpd_mbt_tmobile_macro_combined
                WHERE rgn_region IS NOT NULL
                  AND m_area IS NOT NULL
                  AND m_market IS NOT NULL
                  AND construction_gc IS NOT NULL
                ORDER BY rgn_region, m_area, m_market, construction_gc
            """)

            # Build nested hierarchy using dictionaries
            regions_dict = {}

            for row in rows:
                region = row["rgn_region"]
                area = row["m_area"]
                market = row["m_market"]
                vendor = row["construction_gc"]

                # Ensure region exists
                if region not in regions_dict:
                    regions_dict[region] = {}

                # Ensure area exists in region
                if area not in regions_dict[region]:
                    regions_dict[region][area] = {}

                # Ensure market exists in area
                if market not in regions_dict[region][area]:
                    regions_dict[region][area][market] = set()

                # Add vendor to market
                regions_dict[region][area][market].add(vendor)

            # Convert dictionaries to nested objects
            regions_list = []
            for region_name, areas_dict in sorted(regions_dict.items()):
                areas_list = []
                for area_name, markets_dict in sorted(areas_dict.items()):
                    markets_list = []
                    for market_name, vendors_set in sorted(markets_dict.items()):
                        vendors_list = [VendorItem(vendor=v) for v in sorted(vendors_set)]
                        markets_list.append(MarketItem(market=market_name, vendors=vendors_list))
                    areas_list.append(AreaNested(area=area_name, markets=markets_list))
                regions_list.append(RegionItem(region=region_name, areas=areas_list))

            logger.info(
                f"Built hierarchy: {len(regions_list)} regions, "
                f"{sum(len(r.areas) for r in regions_list)} areas, "
                f"{sum(len(a.markets) for r in regions_list for a in r.areas)} markets"
            )

            return HierarchyResponse(
                success=True,
                regions=regions_list,
                total=len(regions_list),
            )
        finally:
            await conn.close()
    except Exception:
        logger.exception("Error fetching hierarchy dropdown")
        return HierarchyResponse(
            success=False,
            regions=[],
            total=0,
        )
