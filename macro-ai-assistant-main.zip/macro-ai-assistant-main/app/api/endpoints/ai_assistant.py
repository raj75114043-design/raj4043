"""
AI Assistant endpoint – HITL gateway for user queries
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import asyncio
import json
import logging
import time
from datetime import datetime, timezone
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from sqlalchemy import text

from app.services.parallel_kpi_key_qb_search import parallel_search
from app.agents.hitl_agent import run_hitl_agent
from app.agents.sql_agent.graph import run_sql_agent
from app.db.database import AsyncSessionLocal
from app.core.config import settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/assistant", tags=["AI Assistant"])

SCHEMA = settings.db_schema
CHAT_TABLE = f"{SCHEMA}.ai_assistant_chat_history"
HITL_TABLE = f"{SCHEMA}.human_in_the_loop"


# ── Job Store (in-memory) ────────────────────────────────────────────
# In production, consider using Redis or a database for persistence across pod restarts

JOB_STORE: dict = {}  # job_id -> job_state


# ── Request / Response schemas ───────────────────────────────────────

class QueryRequest(BaseModel):
    session_id: str = Field(description="Mandatory Session ID")
    username: str = Field(default="anonymous", description="Username of the requester")
    query: str = Field(..., min_length=1, description="User's natural language query")
    is_follow_up: bool = Field(default=False, description="True if this is a follow-up to a clarification")
    follow_up_chat_id: Optional[str] = Field(
        default=None,
        description="Needed when is_follow_up=True"
    )


class JobStatusResponse(BaseModel):
    job_id: str = Field(description="Unique job identifier")
    status: str = Field(description="pending | processing | completed | failed")
    created_at: str = Field(description="ISO timestamp when job was created")
    started_at: Optional[str] = Field(default=None, description="ISO timestamp when processing started")
    completed_at: Optional[str] = Field(default=None, description="ISO timestamp when processing completed")
    progress: str = Field(default="Initializing...", description="Current progress message")
    error: Optional[str] = Field(default=None, description="Error message if failed")


class JobResultResponse(BaseModel):
    job_id: str = Field(description="Unique job identifier")
    status: str = Field(description="completed | failed")
    unique_chat_id: str = Field(description="Chat ID for this query")
    hitl_id: str = Field(description="HITL ID for this query")
    success: bool = Field(description="Whether SQL execution was successful")
    generated_sql: str = Field(default="", description="Generated SQL query")
    table_json: str = Field(default="", description="Result data as JSON")
    error: str = Field(default="", description="Error message if applicable")
    node_timestamps: dict = Field(default_factory=dict, description="Execution timestamps")


# ── SSE helper ───────────────────────────────────────────────────────

def _sse_event(event: str, data: dict) -> str:
    """Format a Server-Sent Event string."""
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"


# ── Background Job Worker ─────────────────────────────────────────

async def _process_query_job(
    job_id: str,
    request: QueryRequest,
    search_result: dict,
    keyword_names: list[str],
    keyword_ids: list[str],
    keyword_results: list,
    kpi_names: list[str],
    kpi_ids: list[str],
    kpi_results: list,
    qb_names: list[str],
    qb_ids: list[str],
    qb_results: list,
) -> None:
    """
    Background worker that processes a query job asynchronously.
    Updates JOB_STORE with progress and results.
    """
    job = JOB_STORE[job_id]

    try:
        job["started_at"] = datetime.now(timezone.utc).isoformat()
        job["status"] = "processing"
        job["progress"] = "Running HITL analysis…"

        # ── Step 2: HITL agent invocation ──────────────────────────────
        unique_chat_id = str(uuid4())
        hitl_id = str(uuid4())
        job["unique_chat_id"] = unique_chat_id
        job["hitl_id"] = hitl_id

        # Fetch previous context if this is a follow-up
        prev_query = ""
        prev_msg = ""
        prev_sql = ""
        if request.is_follow_up and request.follow_up_chat_id:
            prev_query, prev_msg, prev_sql = await _fetch_previous_context(request.follow_up_chat_id)

        try:
            hitl = await run_hitl_agent(
                user_query=request.query,
                keyword_results=keyword_results,
                kpi_results=kpi_results,
                qb_results=qb_results,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_questions=qb_names,
                is_follow_up=request.is_follow_up,
                previous_user_query=prev_query,
                previous_clarifying_message=prev_msg,
            )
        except Exception as e:
            logger.error(f"HITL agent failed: {e}")
            job["status"] = "failed"
            job["error"] = f"HITL processing failed: {e}"
            job["completed_at"] = datetime.now(timezone.utc).isoformat()
            return

        query_type = hitl.get("query_type", "")
        ready_for_sql = hitl.get("ready_for_sql", False)

        # ── Scenario 1: General / chitchat query ──────────────────────
        if query_type == "general":
            general_response = hitl.get("general_response", "")

            # Persist chat_history + hitl in background (no SQL output)
            await _save_chat_and_hitl(
                unique_chat_id=unique_chat_id,
                hitl_id=hitl_id,
                session_id=request.session_id,
                username=request.username,
                user_query=request.query,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_names=qb_names,
                is_follow_up=request.is_follow_up,
                hitl_generic_response=general_response,
                hitl_assisted_response="",
                hitl_status="completed_general",
            )

            job["status"] = "completed"
            job["result"] = {
                "unique_chat_id": unique_chat_id,
                "hitl_id": hitl_id,
                "query_type": "general",
                "ready_for_sql": False,
                "general_response": general_response,
                "success": True,
            }
            job["completed_at"] = datetime.now(timezone.utc).isoformat()
            return

        # ── Scenario 2: Data question but needs clarification ─────────
        if query_type == "data" and not ready_for_sql:
            clarifying_message = hitl.get("clarifying_message", "")

            # Persist so the follow-up can reference this chat turn
            await _save_chat_and_hitl(
                unique_chat_id=unique_chat_id,
                hitl_id=hitl_id,
                session_id=request.session_id,
                username=request.username,
                user_query=request.query,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_names=qb_names,
                is_follow_up=request.is_follow_up,
                hitl_generic_response="",
                hitl_assisted_response=clarifying_message,
                hitl_status="needs_clarification",
            )

            job["status"] = "completed"
            job["result"] = {
                "unique_chat_id": unique_chat_id,
                "hitl_id": hitl_id,
                "query_type": "data",
                "ready_for_sql": False,
                "clarifying_message": clarifying_message,
                "success": True,
            }
            job["completed_at"] = datetime.now(timezone.utc).isoformat()
            return

        # ── Scenario 3: Data question ready for SQL agent ─────────────
        job["progress"] = "Generating SQL query (this may take a few minutes)…"

        try:
            # No timeout here - let it run until completion
            sql_result = await run_sql_agent(
                user_query=request.query,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_names=qb_names,
                is_follow_up=request.is_follow_up,
                previous_user_query=prev_query,
                previous_clarifying_message=prev_msg,
                previous_generated_sql=prev_sql,
            )
        except Exception as e:
            logger.error(f"SQL agent failed: {e}", exc_info=True)
            job["status"] = "failed"
            job["error"] = f"SQL generation failed: {e}"
            job["completed_at"] = datetime.now(timezone.utc).isoformat()
            return

        sql_success = sql_result.get("success", False)
        generated_sql = sql_result.get("generated_sql", "")
        result_df = sql_result.get("result_df")
        sql_error = sql_result.get("error", "")

        # Serialize DataFrame to JSON for storage
        table_json = ""
        if result_df is not None and not result_df.empty:
            table_json = result_df.to_json(orient="records", date_format="iso")

        # Save chat history with full SQL output
        await _save_chat_and_hitl(
            unique_chat_id=unique_chat_id,
            hitl_id=hitl_id,
            session_id=request.session_id,
            username=request.username,
            user_query=request.query,
            keyword_names=keyword_names,
            kpi_names=kpi_names,
            qb_names=qb_names,
            is_follow_up=request.is_follow_up,
            hitl_generic_response="",
            hitl_assisted_response="",
            hitl_status="Data Question",
            sql_generated=generated_sql,
            table_json=table_json,
        )

        job["status"] = "completed"
        job["result"] = {
            "unique_chat_id": unique_chat_id,
            "hitl_id": hitl_id,
            "query_type": "data",
            "ready_for_sql": True,
            "success": sql_success,
            "generated_sql": generated_sql,
            "table_json": table_json,
            "error": sql_error,
            "node_timestamps": sql_result.get("node_timestamps", {}),
        }
        job["completed_at"] = datetime.now(timezone.utc).isoformat()

    except Exception as e:
        logger.error(f"Background job {job_id} failed unexpectedly: {e}", exc_info=True)
        job["status"] = "failed"
        job["error"] = str(e)
        job["completed_at"] = datetime.now(timezone.utc).isoformat()


# ── Follow-up context helper ──────────────────────────────────────

async def _fetch_previous_context(follow_up_chat_id: str | None) -> tuple[str, str, str]:
    """
    Fetch previous chat context for follow-up questions.
    Returns (previous_user_query, previous_clarifying_message, previous_generated_sql) or ("", "", "") if not found.
    """
    if not follow_up_chat_id:
        return "", "", ""

    try:
        async with AsyncSessionLocal() as db:
            # Fetch chat_history row
            chat_result = await db.execute(
                text(f"""
                    SELECT unique_chat_id, hitl_id, user_query, sql_generated
                    FROM {CHAT_TABLE}
                    WHERE unique_chat_id = :chat_id
                    LIMIT 1
                """),
                {"chat_id": follow_up_chat_id},
            )
            chat_row = chat_result.fetchone()
            if not chat_row:
                return "", "", ""

            prev_query = chat_row[2] if len(chat_row) > 2 else ""
            prev_sql = chat_row[3] if len(chat_row) > 3 else ""
            hitl_id = chat_row[1] if len(chat_row) > 1 else None

            # Fetch HITL response
            if hitl_id:
                hitl_result = await db.execute(
                    text(f"""
                        SELECT hitl_assisted_response
                        FROM {HITL_TABLE}
                        WHERE hitl_id = :hitl_id
                        LIMIT 1
                    """),
                    {"hitl_id": hitl_id},
                )
                hitl_row = hitl_result.fetchone()
                prev_msg = hitl_row[0] if hitl_row else ""
            else:
                prev_msg = ""

            return prev_query, prev_msg, prev_sql
    except Exception as e:
        logger.warning(f"Failed to fetch previous context for follow-up: {e}")
        return "", "", ""


# ── DB persistence helper ─────────────────────────────────────────────

async def _save_chat_and_hitl(
    *,
    unique_chat_id: str,
    hitl_id: str,
    session_id: str,
    username: str,
    user_query: str,
    keyword_names: list[str],
    kpi_names: list[str],
    qb_names: list[str],
    is_follow_up: bool,
    hitl_generic_response: str,
    hitl_assisted_response: str,
    hitl_status: str,
    sql_generated: str = "",
    table_json: str = "",
) -> None:
    """
    Persist a chat_history row and a human_in_the_loop row in a single
    transaction. Used for all scenarios (including Scenario 3 with SQL results).
    """
    # now = datetime.now(timezone.utc)
    now = datetime.now().replace(tzinfo=None)
    
    async with AsyncSessionLocal() as db:
        try:
            # ── Insert chat_history ──
            await db.execute(
                text(f"""
                    INSERT INTO {CHAT_TABLE}
                        (unique_chat_id, session_id, hitl_id, username,
                         user_query, kpi_identified, keywords_indentifed,
                         qb_indentifed, is_follow_up, sql_generated, table_json, created_at)
                    VALUES
                        (:unique_chat_id, :session_id, :hitl_id, :username,
                         :user_query, :kpi_identified, :keywords_indentifed,
                         :qb_indentifed, :is_follow_up, :sql_generated, :table_json, :created_at)
                """),
                {
                    "unique_chat_id": unique_chat_id,
                    "session_id": session_id,
                    "hitl_id": hitl_id,
                    "username": username,
                    "user_query": user_query,
                    "kpi_identified": (", ".join(kpi_names)[:255]) if kpi_names else None,
                    "keywords_indentifed": (", ".join(keyword_names)[:255]) if keyword_names else None,
                    "qb_indentifed": (", ".join(qb_names)[:1024]) if qb_names else None,
                    "is_follow_up": is_follow_up,
                    "sql_generated": sql_generated if sql_generated else None,
                    "table_json": table_json if table_json else None,
                    "created_at": now,
                },
            )

            # ── Insert human_in_the_loop ──
            await db.execute(
                text(f"""
                    INSERT INTO {HITL_TABLE}
                        (hitl_id, session_id, unique_chat_id, username,
                         user_query, hitl_assisted_response,
                         hitl_generic_response, status, created_at)
                    VALUES
                        (:hitl_id, :session_id, :unique_chat_id, :username,
                         :user_query, :hitl_assisted_response,
                         :hitl_generic_response, :status, :created_at)
                """),
                {
                    "hitl_id": hitl_id,
                    "session_id": session_id,
                    "unique_chat_id": unique_chat_id,
                    "username": username,
                    "user_query": user_query,
                    "hitl_assisted_response": hitl_assisted_response,
                    "hitl_generic_response": hitl_generic_response,
                    "status": hitl_status,
                    "created_at": now,
                },
            )

            await db.commit()
            logger.info(
                f"Saved chat_history ({unique_chat_id}) and "
                f"hitl ({hitl_id}) — status={hitl_status}"
            )
        except Exception as e:
            await db.rollback()
            logger.error(f"Failed to save chat/hitl records: {e}")
            raise


# ── Endpoints ────────────────────────────────────────────────────────

@router.post(
    "/session",
    summary="Create a new chat session",
    description="Returns a unique session_id for the frontend to use when "
                "the user logs in or clicks 'New Chat'.",
)
async def create_session():
    """Generate and return a new unique session ID."""
    return {"session_id": str(uuid4())}


@router.post(
    "/query",
    summary="Submit a query to the AI Assistant (SSE stream)",
    description="Runs parallel search and streams each result chunk via SSE. "
                "Events: search_keywords, search_kpis, search_qb, search_complete, error.",
)
async def submit_query(request: QueryRequest):
    """
    Step 1 – Parallel search with SSE streaming.

    Fires keyword, KPI, and question-bank searches in parallel.
    As each completes, the result is streamed to the frontend as an SSE event.
    If all three return empty, a graceful message is sent instead.
    """

    async def _event_generator():
        # Step 1 – Run parallel search
        try:
            search = await parallel_search(request.query)
        except Exception as e:
            logger.error(f"Parallel search failed: {e}")
            yield _sse_event("error", {"message": f"Search failed: {e}"})
            return

        keyword_names = search.get("keyword_names", [])
        keyword_ids = search.get("keyword_ids", [])
        keyword_results = search.get("keyword_results", [])
        kpi_names = search.get("kpi_names", [])
        kpi_ids = search.get("kpi_ids", [])
        kpi_results = search.get("kpi_results", [])
        qb_names = search.get("qb_names", [])
        qb_ids = search.get("qb_ids", [])
        qb_results = search.get("qb_results", [])

        # Stream each category — indicate which ones found results
        yield _sse_event("search_keywords", {
            "keyword_names": keyword_names,
            "keyword_ids": keyword_ids,
            "found": len(keyword_names) > 0,
            "message": "" if keyword_names else "No matching keywords found.",
        })

        yield _sse_event("search_kpis", {
            "kpi_names": kpi_names,
            "kpi_ids": kpi_ids,
            "found": len(kpi_names) > 0,
            "message": "" if kpi_names else "No matching KPIs found.",
        })

        yield _sse_event("search_qb", {
            "qb_names": qb_names,
            "qb_ids": qb_ids,
            "found": len(qb_names) > 0,
            "message": "" if qb_names else "No matching reference questions found.",
        })

        # Determine overall status
        has_keywords = len(keyword_names) > 0
        has_kpis = len(kpi_names) > 0
        has_qb = len(qb_names) > 0
        all_empty = not has_keywords and not has_kpis and not has_qb
        partial = not all_empty and not (has_keywords and has_kpis and has_qb)

        if all_empty:
            yield _sse_event("search_complete", {
                "status": "no_results",
                "message": (
                    "I couldn't find any matching keywords, KPIs, or reference "
                    "questions for your query. Could you rephrase your question? "
                    "For example, you could ask about specific telecom KPIs like "
                    "On-Air Completion Rate, site counts by region, or milestone progress."
                ),
            })
        elif partial:
            missing = []
            if not has_keywords:
                missing.append("keywords")
            if not has_kpis:
                missing.append("KPIs")
            if not has_qb:
                missing.append("reference questions")

            yield _sse_event("search_complete", {
                "status": "partial",
                "message": f"No matching {', '.join(missing)} found — proceeding with available context.",
                "keyword_names": keyword_names,
                "keyword_ids": keyword_ids,
                "kpi_names": kpi_names,
                "kpi_ids": kpi_ids,
                "qb_names": qb_names,
                "qb_ids": qb_ids,
                "search_duration_s": search.get("node_timestamps", 0),
            })
        else:
            yield _sse_event("search_complete", {
                "status": "ok",
                "keyword_names": keyword_names,
                "keyword_ids": keyword_ids,
                "kpi_names": kpi_names,
                "kpi_ids": kpi_ids,
                "qb_names": qb_names,
                "qb_ids": qb_ids,
                "search_duration_s": search.get("node_timestamps", 0),
            })

        # ── Step 2 – HITL agent invocation ──────────────────────────────
        unique_chat_id = str(uuid4())
        hitl_id = str(uuid4())

        yield _sse_event("hitl_start", {
            "unique_chat_id": unique_chat_id,
            "hitl_id": hitl_id,
            "message": "Analysing your query…",
        })

        # Fetch previous context if this is a follow-up
        prev_query = ""
        prev_msg = ""
        prev_sql = ""
        if request.is_follow_up and request.follow_up_chat_id:
            prev_query, prev_msg, prev_sql = await _fetch_previous_context(request.follow_up_chat_id)

        try:
            hitl = await run_hitl_agent(
                user_query=request.query,
                keyword_results=keyword_results,
                kpi_results=kpi_results,
                qb_results=qb_results,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_questions=qb_names,
                is_follow_up=request.is_follow_up,
                previous_user_query=prev_query,
                previous_clarifying_message=prev_msg,
            )
        except Exception as e:
            logger.error(f"HITL agent failed: {e}")
            yield _sse_event("error", {"message": f"HITL processing failed: {e}"})
            return

        query_type = hitl.get("query_type", "")
        ready_for_sql = hitl.get("ready_for_sql", False)

        # ── Scenario 1: General / chitchat query ──────────────────────
        if query_type == "general":
            general_response = hitl.get("general_response", "")

            yield _sse_event("hitl_complete", {
                "unique_chat_id": unique_chat_id,
                "hitl_id": hitl_id,
                "query_type": "general",
                "ready_for_sql": False,
                "general_response": general_response,
                "hitl_duration_s": hitl.get("node_timestamps", {}),
            })

            # Persist chat_history + hitl in background (no SQL output)
            await _save_chat_and_hitl(
                unique_chat_id=unique_chat_id,
                hitl_id=hitl_id,
                session_id=request.session_id,
                username=request.username,
                user_query=request.query,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_names=qb_names,
                is_follow_up=request.is_follow_up,
                hitl_generic_response=general_response,
                hitl_assisted_response="",
                hitl_status="completed_general",
            )

            yield _sse_event("db_saved", {
                "unique_chat_id": unique_chat_id,
                "message": "Chat history saved.",
            })
            return  # Flow ends — no SQL agent needed

        # ── Scenario 2: Data question but needs clarification ─────────
        if query_type == "data" and not ready_for_sql:
            clarifying_message = hitl.get("clarifying_message", "")

            yield _sse_event("hitl_complete", {
                "unique_chat_id": unique_chat_id,
                "hitl_id": hitl_id,
                "query_type": "data",
                "ready_for_sql": False,
                "clarifying_message": clarifying_message,
                "keyword_names": keyword_names,
                "kpi_names": kpi_names,
                "qb_names": qb_names,
                "hitl_duration_s": hitl.get("node_timestamps", {}),
            })

            # Persist so the follow-up can reference this chat turn
            await _save_chat_and_hitl(
                unique_chat_id=unique_chat_id,
                hitl_id=hitl_id,
                session_id=request.session_id,
                username=request.username,
                user_query=request.query,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_names=qb_names,
                is_follow_up=request.is_follow_up,
                hitl_generic_response="",
                hitl_assisted_response=clarifying_message,
                hitl_status="needs_clarification",
            )

            yield _sse_event("db_saved", {
                "unique_chat_id": unique_chat_id,
                "message": "Chat history saved. Awaiting follow-up from user.",
            })
            return  # Flow pauses — frontend sends follow-up

        # ── Scenario 3: Data question ready for SQL agent ─────────────
        yield _sse_event("hitl_complete", {
            "unique_chat_id": unique_chat_id,
            "hitl_id": hitl_id,
            "query_type": "data",
            "ready_for_sql": True,
            "keyword_names": keyword_names,
            "kpi_names": kpi_names,
            "qb_names": qb_names,
            "hitl_duration_s": hitl.get("node_timestamps", {}),
            "message": "Query validated — proceeding to SQL generation.",
        })

        # ── Step 3: SQL Agent invocation ─────────────────────────────
        yield _sse_event("sql_start", {
            "unique_chat_id": unique_chat_id,
            "message": "Generating SQL query…",
        })

        try:
            # ── Keep-alive pinging mechanism for long-running SQL generation ──
            # Create task for SQL agent with 360s timeout
            sql_task = asyncio.create_task(
                asyncio.wait_for(
                    run_sql_agent(
                        user_query=request.query,
                        keyword_names=keyword_names,
                        kpi_names=kpi_names,
                        qb_names=qb_names,
                        is_follow_up=request.is_follow_up,
                        previous_user_query=prev_query,
                        previous_clarifying_message=prev_msg,
                        previous_generated_sql=prev_sql,
                    ),
                    timeout=360.0
                )
            )

            # Monitor task and send keep-alive pings every 30 seconds
            last_ping = time.time()
            while not sql_task.done():
                # Check if 30 seconds have passed since last ping
                if time.time() - last_ping > 30:
                    yield ": keep-alive\n\n"  # SSE comment (client ignores, connection stays alive)
                    last_ping = time.time()
                    logger.debug("Keep-alive ping sent during SQL generation")

                # Small sleep to avoid busy-waiting
                await asyncio.sleep(1)

            # Task is done, get result (may raise TimeoutError or other exceptions)
            sql_result = sql_task.result()

        except asyncio.TimeoutError:
            logger.error("SQL agent timed out after 360 seconds")
            yield _sse_event("sql_complete", {
                "unique_chat_id": unique_chat_id,
                "success": False,
                "generated_sql": "",
                "table_json": "",
                "error": "SQL generation timed out after 360 seconds",
                "node_timestamps": {},
                "message": "SQL generation timed out.",
            })
            return
        except Exception as e:
            logger.error(f"SQL agent failed: {e}", exc_info=True)
            yield _sse_event("sql_complete", {
                "unique_chat_id": unique_chat_id,
                "success": False,
                "generated_sql": "",
                "table_json": "",
                "error": str(e),
                "node_timestamps": {},
                "message": f"SQL generation failed: {e}",
            })
            return

        sql_success = sql_result.get("success", False)
        generated_sql = sql_result.get("generated_sql", "")
        result_df = sql_result.get("result_df")
        sql_error = sql_result.get("error", "")

        # Serialize DataFrame to JSON for storage / SSE
        table_json = ""
        if result_df is not None and not result_df.empty:
            table_json = result_df.to_json(orient="records", date_format="iso")

        # Save chat history with full SQL output
        await _save_chat_and_hitl(
            unique_chat_id=unique_chat_id,
            hitl_id=hitl_id,
            session_id=request.session_id,
            username=request.username,
            user_query=request.query,
            keyword_names=keyword_names,
            kpi_names=kpi_names,
            qb_names=qb_names,
            is_follow_up=request.is_follow_up,
            hitl_generic_response="",
            hitl_assisted_response="",
            hitl_status="Data Question",
            sql_generated=generated_sql,
            table_json=table_json,
        )

        yield _sse_event("sql_complete", {
            "unique_chat_id": unique_chat_id,
            "success": sql_success,
            "generated_sql": generated_sql,
            "table_json": table_json,
            "error": sql_error,
            "node_timestamps": sql_result.get("node_timestamps", {}),
            "message": "SQL executed successfully." if sql_success else "SQL execution failed.",
        }) 

    return StreamingResponse(
        _event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ── Async Job Queue Endpoints (for long-running queries) ────────────

@router.post(
    "/query-async",
    summary="Submit a query asynchronously (streams search + HITL, job_id for SQL)",
    description="Streams search & HITL analysis immediately, then returns job_id if SQL generation is needed. "
                "No timeout limits for SQL — let it run as long as needed.",
)
async def submit_query_async(request: QueryRequest):
    """
    Hybrid SSE streaming endpoint for long-running queries.

    Flow:
    1. Stream search results (keywords, KPIs, QB)
    2. Stream HITL analysis
    3. If general question: return immediately (no SQL)
    4. If needs clarification: return immediately (no SQL)
    5. If SQL needed: create background job, stream job_id, let client poll
    """

    async def _event_generator():
        # ── Step 1 – Parallel search ──────────────────────────────────────
        try:
            search = await parallel_search(request.query)
        except Exception as e:
            logger.error(f"Parallel search failed: {e}")
            yield _sse_event("error", {"message": f"Search failed: {e}"})
            return

        keyword_names = search.get("keyword_names", [])
        keyword_ids = search.get("keyword_ids", [])
        keyword_results = search.get("keyword_results", [])
        kpi_names = search.get("kpi_names", [])
        kpi_ids = search.get("kpi_ids", [])
        kpi_results = search.get("kpi_results", [])
        qb_names = search.get("qb_names", [])
        qb_ids = search.get("qb_ids", [])
        qb_results = search.get("qb_results", [])

        # Stream search categories
        yield _sse_event("search_keywords", {
            "keyword_names": keyword_names,
            "keyword_ids": keyword_ids,
            "found": len(keyword_names) > 0,
            "message": "" if keyword_names else "No matching keywords found.",
        })

        yield _sse_event("search_kpis", {
            "kpi_names": kpi_names,
            "kpi_ids": kpi_ids,
            "found": len(kpi_names) > 0,
            "message": "" if kpi_names else "No matching KPIs found.",
        })

        yield _sse_event("search_qb", {
            "qb_names": qb_names,
            "qb_ids": qb_ids,
            "found": len(qb_names) > 0,
            "message": "" if qb_names else "No matching reference questions found.",
        })

        # Determine overall status
        has_keywords = len(keyword_names) > 0
        has_kpis = len(kpi_names) > 0
        has_qb = len(qb_names) > 0
        all_empty = not has_keywords and not has_kpis and not has_qb
        partial = not all_empty and not (has_keywords and has_kpis and has_qb)

        if all_empty:
            yield _sse_event("search_complete", {
                "status": "no_results",
                "message": (
                    "I couldn't find any matching keywords, KPIs, or reference "
                    "questions for your query. Could you rephrase your question?"
                ),
            })
            return

        if partial:
            missing = []
            if not has_keywords:
                missing.append("keywords")
            if not has_kpis:
                missing.append("KPIs")
            if not has_qb:
                missing.append("reference questions")

            yield _sse_event("search_complete", {
                "status": "partial",
                "message": f"No matching {', '.join(missing)} found — proceeding with available context.",
                "keyword_names": keyword_names,
                "keyword_ids": keyword_ids,
                "kpi_names": kpi_names,
                "kpi_ids": kpi_ids,
                "qb_names": qb_names,
                "qb_ids": qb_ids,
                "search_duration_s": search.get("node_timestamps", 0),
            })
        else:
            yield _sse_event("search_complete", {
                "status": "ok",
                "keyword_names": keyword_names,
                "keyword_ids": keyword_ids,
                "kpi_names": kpi_names,
                "kpi_ids": kpi_ids,
                "qb_names": qb_names,
                "qb_ids": qb_ids,
                "search_duration_s": search.get("node_timestamps", 0),
            })

        # ── Step 2 – HITL agent invocation ──────────────────────────────
        unique_chat_id = str(uuid4())
        hitl_id = str(uuid4())

        yield _sse_event("hitl_start", {
            "unique_chat_id": unique_chat_id,
            "hitl_id": hitl_id,
            "message": "Analysing your query…",
        })

        # Fetch previous context if this is a follow-up
        prev_query = ""
        prev_msg = ""
        prev_sql = ""
        if request.is_follow_up and request.follow_up_chat_id:
            prev_query, prev_msg, prev_sql = await _fetch_previous_context(request.follow_up_chat_id)

        try:
            hitl = await run_hitl_agent(
                user_query=request.query,
                keyword_results=keyword_results,
                kpi_results=kpi_results,
                qb_results=qb_results,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_questions=qb_names,
                is_follow_up=request.is_follow_up,
                previous_user_query=prev_query,
                previous_clarifying_message=prev_msg,
            )
        except Exception as e:
            logger.error(f"HITL agent failed: {e}")
            yield _sse_event("error", {"message": f"HITL processing failed: {e}"})
            return

        query_type = hitl.get("query_type", "")
        ready_for_sql = hitl.get("ready_for_sql", False)

        # ── Scenario 1: General / chitchat query ──────────────────────
        if query_type == "general":
            general_response = hitl.get("general_response", "")

            yield _sse_event("hitl_complete", {
                "unique_chat_id": unique_chat_id,
                "hitl_id": hitl_id,
                "query_type": "general",
                "ready_for_sql": False,
                "general_response": general_response,
                "hitl_duration_s": hitl.get("node_timestamps", {}),
            })

            # Persist chat_history + hitl in background
            await _save_chat_and_hitl(
                unique_chat_id=unique_chat_id,
                hitl_id=hitl_id,
                session_id=request.session_id,
                username=request.username,
                user_query=request.query,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_names=qb_names,
                is_follow_up=request.is_follow_up,
                hitl_generic_response=general_response,
                hitl_assisted_response="",
                hitl_status="completed_general",
            )

            yield _sse_event("db_saved", {
                "unique_chat_id": unique_chat_id,
                "message": "Chat history saved.",
            })
            return  # No SQL needed

        # ── Scenario 2: Data question but needs clarification ─────────
        if query_type == "data" and not ready_for_sql:
            clarifying_message = hitl.get("clarifying_message", "")

            yield _sse_event("hitl_complete", {
                "unique_chat_id": unique_chat_id,
                "hitl_id": hitl_id,
                "query_type": "data",
                "ready_for_sql": False,
                "clarifying_message": clarifying_message,
                "keyword_names": keyword_names,
                "kpi_names": kpi_names,
                "qb_names": qb_names,
                "hitl_duration_s": hitl.get("node_timestamps", {}),
            })

            # Persist so follow-up can reference this turn
            await _save_chat_and_hitl(
                unique_chat_id=unique_chat_id,
                hitl_id=hitl_id,
                session_id=request.session_id,
                username=request.username,
                user_query=request.query,
                keyword_names=keyword_names,
                kpi_names=kpi_names,
                qb_names=qb_names,
                is_follow_up=request.is_follow_up,
                hitl_generic_response="",
                hitl_assisted_response=clarifying_message,
                hitl_status="needs_clarification",
            )

            yield _sse_event("db_saved", {
                "unique_chat_id": unique_chat_id,
                "message": "Chat history saved. Awaiting follow-up from user.",
            })
            return  # No SQL needed

        # ── Scenario 3: Data question ready for SQL — kick off background job ────
        yield _sse_event("hitl_complete", {
            "unique_chat_id": unique_chat_id,
            "hitl_id": hitl_id,
            "query_type": "data",
            "ready_for_sql": True,
            "keyword_names": keyword_names,
            "kpi_names": kpi_names,
            "qb_names": qb_names,
            "hitl_duration_s": hitl.get("node_timestamps", {}),
            "message": "Query validated — starting SQL generation (this may take several minutes).",
        })

        # Create background job for SQL generation (no timeout)
        job_id = str(uuid4())
        JOB_STORE[job_id] = {
            "job_id": job_id,
            "status": "pending",
            "created_at": datetime.now(timezone.utc).isoformat(),
            "started_at": None,
            "completed_at": None,
            "progress": "Starting SQL generation…",
            "error": None,
            "unique_chat_id": unique_chat_id,
            "hitl_id": hitl_id,
            "result": None,
        }

        # Fire off background SQL job (non-blocking)
        asyncio.create_task(_process_query_job(
            job_id=job_id,
            request=request,
            search_result=search,
            keyword_names=keyword_names,
            keyword_ids=keyword_ids,
            keyword_results=keyword_results,
            kpi_names=kpi_names,
            kpi_ids=kpi_ids,
            kpi_results=kpi_results,
            qb_names=qb_names,
            qb_ids=qb_ids,
            qb_results=qb_results,
        ))

        # Stream job_id immediately
        yield _sse_event("sql_job_submitted", {
            "job_id": job_id,
            "unique_chat_id": unique_chat_id,
            "message": "SQL generation started in background. Use GET /assistant/query-status/{job_id} to check progress.",
            "poll_endpoint": f"/assistant/query-status/{job_id}",
            "results_endpoint": f"/assistant/query-results/{job_id}",
        })

    return StreamingResponse(
        _event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.get(
    "/query-status/{job_id}",
    summary="Check the status of an async query job",
    description="Returns current status, progress, and any error messages.",
    response_model=JobStatusResponse,
)
async def get_query_status(job_id: str):
    """
    Polls the status of a background query job.

    Status can be: pending, processing, completed, or failed.
    """
    if job_id not in JOB_STORE:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")

    job = JOB_STORE[job_id]
    return JobStatusResponse(
        job_id=job_id,
        status=job["status"],
        created_at=job["created_at"],
        started_at=job["started_at"],
        completed_at=job["completed_at"],
        progress=job["progress"],
        error=job["error"],
    )


@router.get(
    "/query-results/{job_id}",
    summary="Retrieve final results of a completed async query",
    description="Returns the full result including generated SQL and data.",
)
async def get_query_results(job_id: str):
    """
    Retrieves the final results of a completed job.

    Only available once status is "completed" or "failed".
    If "pending" or "processing", returns a 202 Accepted status code.
    """
    if job_id not in JOB_STORE:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")

    job = JOB_STORE[job_id]

    if job["status"] in ["pending", "processing"]:
        return {
            "status": "still_processing",
            "job_id": job_id,
            "progress": job["progress"],
            "message": "Job is still running. Check back soon.",
        }

    if job["status"] == "failed":
        return {
            "job_id": job_id,
            "status": "failed",
            "error": job["error"],
            "completed_at": job["completed_at"],
        }

    # Status is "completed"
    result = job["result"]
    return JobResultResponse(
        job_id=job_id,
        status="completed",
        unique_chat_id=job["unique_chat_id"],
        hitl_id=job["hitl_id"],
        success=result.get("success", False),
        generated_sql=result.get("generated_sql", ""),
        table_json=result.get("table_json", ""),
        error=result.get("error", ""),
        node_timestamps=result.get("node_timestamps", {}),
    )
