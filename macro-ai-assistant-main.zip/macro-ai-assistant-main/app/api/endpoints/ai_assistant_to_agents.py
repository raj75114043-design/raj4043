"""
AI Assistant → Agent routing endpoint
Routes validated queries to the appropriate LangGraph agent (SQL, CSV, etc.)
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import logging
from typing import Optional

from fastapi import APIRouter
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/agents", tags=["Agent Routing"])


# ── Schemas ──────────────────────────────────────────────────────────

class AgentRequest(BaseModel):
    query: str = Field(..., min_length=1)
    agent_type: str = Field(default="sql", pattern="^(sql|csv)$")
    session_id: Optional[str] = None
    schema_name: Optional[str] = None


class AgentResponse(BaseModel):
    query: str
    agent_type: str
    result: dict
    node_timestamps: dict = {}


# ── Endpoints ────────────────────────────────────────────────────────

@router.post(
    "/invoke",
    response_model=AgentResponse,
    summary="Invoke an agent to process a validated query",
)
async def invoke_agent(request: AgentRequest):
    """
    Route the query to the specified agent type:
    - sql: Text-to-SQL agent (generates and executes SQL)
    - csv: CSV/DataFrame analysis agent
    """
    if request.agent_type == "sql":
        # TODO: wire up sql_agent graph once nodes are implemented
        return AgentResponse(
            query=request.query,
            agent_type="sql",
            result={"status": "not_implemented", "message": "SQL agent endpoint ready — wire up graph"},
            node_timestamps={},
        )
    elif request.agent_type == "csv":
        # TODO: wire up csv_agent graph once invocation is ready
        return AgentResponse(
            query=request.query,
            agent_type="csv",
            result={"status": "not_implemented", "message": "CSV agent endpoint ready — wire up graph"},
            node_timestamps={},
        )
