"""
AI Assistant → Agent routing endpoint
Routes validated queries to the appropriate LangGraph agent (SQL, CSV, etc.)
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import asyncio
import json
import logging
import time
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from app.agents.generic_sql_agent import run_generic_sql_agent
from app.agents.sql_agent.graph import run_sql_agent
from app.chains.high_chart_graph_gen import generate_hichart_graphs
from app.services.parallel_kpi_key_qb_search import parallel_search

logger = logging.getLogger(__name__)


class DecimalEncoder(json.JSONEncoder):
    """Custom JSON encoder that handles Decimal types from database results."""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super().default(obj)

router = APIRouter(prefix="/agents", tags=["Agent Routing"])


class WorkflowAIAssistantRequest(BaseModel):
    """Request model for workflow_ai_assistant endpoint."""
    step_id: str = Field(..., description="Unique step identifier for tracking")
    user_query: str = Field(..., min_length=1, description="User's natural language question")
    table_schema: str = Field(..., description="PostgreSQL table DDL/schema")
    table_name: str = Field(..., description="Target table name")
    workflow_name: str = Field(..., description="Target table name")


class AI_Assistant_to_Workflow_AgentResponse(BaseModel):
    query: str
    agent_type: str
    result: dict
    node_timestamps: dict = {}


# ── Helper Functions ────────────────────────────────────────────

def _sse_event(event_name: str, data_dict: dict) -> str:
    """Format a Server-Sent Event message."""
    return f"event:{event_name}\ndata:{json.dumps(data_dict, cls=DecimalEncoder)}\n\n"

# ── Workflow AI Assistant Endpoint ──────────────────────────────
@router.post(
    "/workflow_ai_assistant",
    summary="Generic SQL Agent with SSE streaming",
    description="Validates a query against a schema, generates SQL, executes it, and generates a graph.",
)
async def workflow_ai_assistant(request: WorkflowAIAssistantRequest):
    """
    
    Process a user query against a provided table schema.

    Returns a Server-Sent Event (SSE) stream with:
    - validation_start: query validation beginning
    - validation_complete: validation result
    - text_response (if invalid): helpful response
    - sql_start (if valid): SQL generation beginning
    - sql_complete (if valid): SQL results
    - graph_start (if valid): graph generation beginning
    - graph_complete (if valid): Highchart configuration
    - chat_end: stream termination event

    """

    async def event_stream():
        try:
            # Event 1: Validation start
            yield _sse_event("validation_start", {
                "step_id": request.step_id,
                "message": "Validating query against schema...",
            })

            # Run generic SQL agent with keep-alive
            agent_task = asyncio.create_task(
                asyncio.wait_for(
                    run_generic_sql_agent(
                        step_id=request.step_id,
                        user_query=request.user_query,
                        table_schema=request.table_schema,
                        table_name=request.table_name,
                    ),
                    timeout=360.0,
                )
            )

            # Keep-alive loop while agent runs
            last_ping = time.time()
            while not agent_task.done():
                if time.time() - last_ping > 30:
                    yield ": keep-alive\n\n"
                    last_ping = time.time()
                await asyncio.sleep(1)

            # Get agent result
            agent_result = agent_task.result()

            # Event 2: Validation complete
            yield _sse_event("validation_complete", {
                "step_id": request.step_id,
                "is_valid": agent_result["is_valid"],
                "message": agent_result.get("text_response", "Query validated."),
            })

            # If invalid, send text response and close stream
            if not agent_result["is_valid"]:
                yield _sse_event("text_response", {
                    "step_id": request.step_id,
                    "response": agent_result.get("text_response", "Unable to answer your question with this schema."),
                })
                yield "event:chat_end\ndata:{}\n\n"
                return

            # If valid, continue with SQL and graph generation

            # Event 3: SQL start
            yield _sse_event("sql_start", {
                "step_id": request.step_id,
                "message": "Generating SQL query...",
            })

            # Event 4: SQL complete
            sql_event_data = {
                "step_id": request.step_id,
                "success": agent_result["success"],
                "generated_sql": agent_result.get("generated_sql", ""),
                "table_json": agent_result.get("table_json", None),
                "error": agent_result.get("error", ""),
                "node_timestamps": agent_result.get("node_timestamps", {}),
            }
            yield _sse_event("sql_complete", sql_event_data)

            # Skip graph generation if SQL failed
            if not agent_result["success"]:
                yield "event:chat_end\ndata:{}\n\n"
                return

            # Event 5: Graph start
            yield _sse_event("graph_start", {
                "step_id": request.step_id,
                "message": "Generating graph...",
            })

            # Generate graph with keep-alive
            table_json = agent_result.get("table_json", [])
            generated_sql = agent_result.get("generated_sql", "")

            graph_task = asyncio.create_task(
                asyncio.wait_for(
                    generate_hichart_graphs(
                        user_query=request.user_query,
                        table_json=json.dumps(table_json) if table_json else "[]",
                        generated_sql=generated_sql,
                    ),
                    timeout=300.0,
                )
            )

            # Keep-alive loop for graph generation
            last_ping = time.time()
            while not graph_task.done():
                if time.time() - last_ping > 30:
                    yield ": keep-alive\n\n"
                    last_ping = time.time()
                await asyncio.sleep(1)

            # Get graph result
            try:
                graph_result = graph_task.result()
                graph_charts = graph_result.charts if graph_result else []
                graph_rationale = graph_result.rationale if graph_result else ""
                graph_status = "success"
            except asyncio.TimeoutError:
                logger.warning(f"[{request.step_id}] Graph generation timed out")
                graph_charts = []
                graph_rationale = "Graph generation timed out after 5 minutes."
                graph_status = "timeout"
            except Exception as e:
                logger.exception(f"[{request.step_id}] Graph generation failed")
                graph_charts = []
                graph_rationale = f"Graph generation error: {str(e)}"
                graph_status = "error"

            # Event 6: Graph complete
            yield _sse_event("graph_complete", {
                "step_id": request.step_id,
                "charts": graph_charts,
                "rationale": graph_rationale,
                "status": graph_status,
            })

            # Event 7: Chat end
            yield "event:chat_end\ndata:{}\n\n"

        except asyncio.TimeoutError:
            logger.warning(f"[{request.step_id}] Agent execution timed out")
            yield _sse_event("error_complete", {
                "step_id": request.step_id,
                "error": "Query processing timed out after 6 minutes. Please try with a simpler query.",
                "status": "timeout",
            })
            yield "event:chat_end\ndata:{}\n\n"
        except Exception as e:
            logger.exception(f"[{request.step_id}] Unexpected error in workflow_ai_assistant")
            yield _sse_event("error_complete", {
                "step_id": request.step_id,
                "error": f"An unexpected error occurred: {str(e)}",
                "status": "error",
            })
            yield "event:chat_end\ndata:{}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


# ── AI Insight Plugin Endpoint ──────────────────────────────────

# ── New request/response models for plugin endpoints ──────────────

class PluginAgentRequest(BaseModel):
    """Request model for AI Insight Plugin and Escalation Agent endpoints."""
    session_id: str = Field(..., description="Unique session identifier")
    username: str = Field(default="anonymous", description="Username of the requester")
    user_query: str = Field(..., min_length=1, description="User's natural language query")


class PluginAgentSearchResult(BaseModel):
    """Represents the parallel search output."""
    keyword_names: list[str] = Field(default_factory=list)
    keyword_ids: list[str] = Field(default_factory=list)
    kpi_names: list[str] = Field(default_factory=list)
    kpi_ids: list[str] = Field(default_factory=list)
    qb_names: list[str] = Field(default_factory=list)
    qb_ids: list[str] = Field(default_factory=list)


class PluginAgentResponse(BaseModel):
    """Response model for plugin endpoints."""
    session_id: str
    agent_type: str = Field(description="'ai-insight-plugin' or 'escalation-agent'")
    success: bool
    generated_sql: str = Field(default="")
    table_json: Optional[dict] = Field(default=None)
    parallel_search_output: PluginAgentSearchResult = Field(default_factory=PluginAgentSearchResult)
    error: Optional[str] = Field(default=None)
    node_timestamps: dict = Field(default_factory=dict)
    

@router.post(
    "/ai-insight-plugin",
    summary="AI Insight Plugin – Parallel Search + SQL Engine with SSE",
    description="Runs parallel search (KPIs, keywords, question bank), executes SQL agent. Returns context used, generated SQL, and table results.",
)
async def ai_insight_plugin(request: PluginAgentRequest):
    """
    AI Insight Plugin endpoint with comprehensive context output.

    Flow:
    1. Run parallel search on user query
    2. Stream search results (keywords, KPIs, question bank)
    3. Run SQL agent with search context
    4. Stream SQL generation and execution
    5. Return all context: parallel_search_output + generated_sql + table_json

    Returns SSE stream with events:
    - search_keywords: keyword search results
    - search_kpis: KPI search results
    - search_qb: question bank search results
    - search_complete: search phase complete
    - sql_start: SQL generation beginning
    - sql_complete: SQL generation and execution complete (with full context)
    - chat_end: stream termination
    """

    async def event_stream():
        try:
            # ── Phase 1: Parallel Search ──────────────────────────────
            logger.info(f"[{request.session_id}] Starting parallel search for: {request.user_query[:100]}")

            search_task = asyncio.create_task(
                asyncio.wait_for(
                    parallel_search(request.user_query),
                    timeout=60.0,
                )
            )

            # Monitor search task with keep-alive
            last_ping = time.time()
            while not search_task.done():
                if time.time() - last_ping > 30:
                    yield ": keep-alive\n\n"
                    last_ping = time.time()
                await asyncio.sleep(1)

            search_result = search_task.result()
            logger.info(f"[{request.session_id}] Search complete: {len(search_result.get('keyword_names', []))} keywords, {len(search_result.get('kpi_names', []))} KPIs, {len(search_result.get('qb_names', []))} QB items")

            # Yield search results
            yield _sse_event("search_keywords", {
                "session_id": request.session_id,
                "keyword_names": search_result.get("keyword_names", []),
                "keyword_ids": search_result.get("keyword_ids", []),
                "found": len(search_result.get("keyword_names", [])) > 0,
            })

            yield _sse_event("search_kpis", {
                "session_id": request.session_id,
                "kpi_names": search_result.get("kpi_names", []),
                "kpi_ids": search_result.get("kpi_ids", []),
                "found": len(search_result.get("kpi_names", [])) > 0,
            })

            yield _sse_event("search_qb", {
                "session_id": request.session_id,
                "qb_names": search_result.get("qb_names", []),
                "qb_ids": search_result.get("qb_ids", []),
                "found": len(search_result.get("qb_names", [])) > 0,
            })

            yield _sse_event("search_complete", {
                "session_id": request.session_id,
                "status": "success",
                "total_keywords": len(search_result.get("keyword_names", [])),
                "total_kpis": len(search_result.get("kpi_names", [])),
                "total_qb": len(search_result.get("qb_names", [])),
            })

            # ── Phase 2: SQL Agent ────────────────────────────────────
            yield _sse_event("sql_start", {
                "session_id": request.session_id,
                "message": "Running SQL agent with search context...",
            })

            sql_task = asyncio.create_task(
                asyncio.wait_for(
                    run_sql_agent(
                        user_query=request.user_query,
                        keyword_names=search_result.get("keyword_names", []),
                        kpi_names=search_result.get("kpi_names", []),
                        qb_names=search_result.get("qb_names", []),
                    ),
                    timeout=360.0,
                )
            )

            # Monitor SQL task with keep-alive
            last_ping = time.time()
            while not sql_task.done():
                if time.time() - last_ping > 30:
                    yield ": keep-alive\n\n"
                    last_ping = time.time()
                await asyncio.sleep(1)

            sql_result = sql_task.result()
            logger.info(f"[{request.session_id}] SQL execution: success={sql_result['success']}")

            # Convert DataFrame to JSON if available
            table_json = None
            if sql_result.get("result_df") is not None:
                table_json = json.loads(
                    sql_result["result_df"].to_json(orient="records"),
                )

            # Yield SQL complete with full context
            yield _sse_event("sql_complete", {
                "session_id": request.session_id,
                "success": sql_result["success"],
                "generated_sql": sql_result.get("generated_sql", ""),
                "table_json": table_json,
                "parallel_search_output": {
                    "keyword_names": search_result.get("keyword_names", []),
                    "keyword_ids": search_result.get("keyword_ids", []),
                    "kpi_names": search_result.get("kpi_names", []),
                    "kpi_ids": search_result.get("kpi_ids", []),
                    "qb_names": search_result.get("qb_names", []),
                    "qb_ids": search_result.get("qb_ids", []),
                },
                "error": sql_result.get("error", ""),
                "retries": sql_result.get("retries", 0),
                "node_timestamps": sql_result.get("node_timestamps", {}),
            })

            yield "event:chat_end\ndata:{}\n\n"

        except asyncio.TimeoutError:
            logger.warning(f"[{request.session_id}] AI Insight Plugin timed out")
            yield _sse_event("error_complete", {
                "session_id": request.session_id,
                "error": "Query processing timed out. Please try with a simpler query.",
                "status": "timeout",
            })
            yield "event:chat_end\ndata:{}\n\n"
        except Exception as e:
            logger.exception(f"[{request.session_id}] Unexpected error in ai_insight_plugin")
            yield _sse_event("error_complete", {
                "session_id": request.session_id,
                "error": f"An unexpected error occurred: {str(e)}",
                "status": "error",
            })
            yield "event:chat_end\ndata:{}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")


# ── Escalation Agent Endpoint ───────────────────────────────────

@router.post(
    "/escalation-agent",
    summary="Escalation Agent – Parallel Search + SQL Engine with SSE",
    description="Escalation Agent endpoint with identical functionality to AI Insight Plugin. Allows for future customization.",
)
async def escalation_agent(request: PluginAgentRequest):
    """
    Escalation Agent endpoint with comprehensive context output.

    This endpoint has identical functionality to the AI Insight Plugin but is separated
    to allow for independent customization in the future (e.g., different prompt strategies,
    enhanced error handling, custom validation rules, etc.).

    Flow:
    1. Run parallel search on user query
    2. Stream search results (keywords, KPIs, question bank)
    3. Run SQL agent with search context
    4. Stream SQL generation and execution
    5. Return all context: parallel_search_output + generated_sql + table_json

    Returns SSE stream with events:
    - search_keywords: keyword search results
    - search_kpis: KPI search results
    - search_qb: question bank search results
    - search_complete: search phase complete
    - sql_start: SQL generation beginning
    - sql_complete: SQL generation and execution complete (with full context)
    - chat_end: stream termination
    """

    async def event_stream():
        try:
            # ── Phase 1: Parallel Search ──────────────────────────────
            logger.info(f"[{request.session_id}] Starting escalation search for: {request.user_query[:100]}")

            search_task = asyncio.create_task(
                asyncio.wait_for(
                    parallel_search(request.user_query),
                    timeout=60.0,
                )
            )

            # Monitor search task with keep-alive
            last_ping = time.time()
            while not search_task.done():
                if time.time() - last_ping > 30:
                    yield ": keep-alive\n\n"
                    last_ping = time.time()
                await asyncio.sleep(1)

            search_result = search_task.result()
            logger.info(f"[{request.session_id}] Escalation search complete: {len(search_result.get('keyword_names', []))} keywords, {len(search_result.get('kpi_names', []))} KPIs, {len(search_result.get('qb_names', []))} QB items")

            # Yield search results
            yield _sse_event("search_keywords", {
                "session_id": request.session_id,
                "keyword_names": search_result.get("keyword_names", []),
                "keyword_ids": search_result.get("keyword_ids", []),
                "found": len(search_result.get("keyword_names", [])) > 0,
            })

            yield _sse_event("search_kpis", {
                "session_id": request.session_id,
                "kpi_names": search_result.get("kpi_names", []),
                "kpi_ids": search_result.get("kpi_ids", []),
                "found": len(search_result.get("kpi_names", [])) > 0,
            })

            yield _sse_event("search_qb", {
                "session_id": request.session_id,
                "qb_names": search_result.get("qb_names", []),
                "qb_ids": search_result.get("qb_ids", []),
                "found": len(search_result.get("qb_names", [])) > 0,
            })

            yield _sse_event("search_complete", {
                "session_id": request.session_id,
                "status": "success",
                "total_keywords": len(search_result.get("keyword_names", [])),
                "total_kpis": len(search_result.get("kpi_names", [])),
                "total_qb": len(search_result.get("qb_names", [])),
            })

            # ── Phase 2: SQL Agent ────────────────────────────────────
            yield _sse_event("sql_start", {
                "session_id": request.session_id,
                "message": "Running SQL agent with search context...",
            })

            sql_task = asyncio.create_task(
                asyncio.wait_for(
                    run_sql_agent(
                        user_query=request.user_query,
                        keyword_names=search_result.get("keyword_names", []),
                        kpi_names=search_result.get("kpi_names", []),
                        qb_names=search_result.get("qb_names", []),
                    ),
                    timeout=360.0,
                )
            )

            # Monitor SQL task with keep-alive
            last_ping = time.time()
            while not sql_task.done():
                if time.time() - last_ping > 30:
                    yield ": keep-alive\n\n"
                    last_ping = time.time()
                await asyncio.sleep(1)

            sql_result = sql_task.result()
            logger.info(f"[{request.session_id}] Escalation SQL execution: success={sql_result['success']}")

            # Convert DataFrame to JSON if available
            table_json = None
            if sql_result.get("result_df") is not None:
                table_json = json.loads(
                    sql_result["result_df"].to_json(orient="records"),
                )

            # Yield SQL complete with full context
            yield _sse_event("sql_complete", {
                "session_id": request.session_id,
                "success": sql_result["success"],
                "generated_sql": sql_result.get("generated_sql", ""),
                "table_json": table_json,
                "parallel_search_output": {
                    "keyword_names": search_result.get("keyword_names", []),
                    "keyword_ids": search_result.get("keyword_ids", []),
                    "kpi_names": search_result.get("kpi_names", []),
                    "kpi_ids": search_result.get("kpi_ids", []),
                    "qb_names": search_result.get("qb_names", []),
                    "qb_ids": search_result.get("qb_ids", []),
                },
                "error": sql_result.get("error", ""),
                "retries": sql_result.get("retries", 0),
                "node_timestamps": sql_result.get("node_timestamps", {}),
            })

            yield "event:chat_end\ndata:{}\n\n"

        except asyncio.TimeoutError:
            logger.warning(f"[{request.session_id}] Escalation Agent timed out")
            yield _sse_event("error_complete", {
                "session_id": request.session_id,
                "error": "Query processing timed out. Please try with a simpler query.",
                "status": "timeout",
            })
            yield "event:chat_end\ndata:{}\n\n"
        except Exception as e:
            logger.exception(f"[{request.session_id}] Unexpected error in escalation_agent")
            yield _sse_event("error_complete", {
                "session_id": request.session_id,
                "error": f"An unexpected error occurred: {str(e)}",
                "status": "error",
            })
            yield "event:chat_end\ndata:{}\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")