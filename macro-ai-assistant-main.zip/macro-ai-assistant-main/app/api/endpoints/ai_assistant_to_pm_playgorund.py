"""
AI Assistant → PM Playground bridge endpoint
Forwards validated queries to the PM Copilot Playground backend
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import logging
from typing import Optional

from fastapi import APIRouter
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/playground", tags=["PM Playground"])


# ── Schemas ──────────────────────────────────────────────────────────

class PlaygroundRequest(BaseModel):
    query: str = Field(..., min_length=1)
    session_id: Optional[str] = None
    schema_name: Optional[str] = "pwc_macro_staging_schema"


class PlaygroundResponse(BaseModel):
    query: str
    status: str
    result: dict = {}


# ── Endpoints ────────────────────────────────────────────────────────

@router.post(
    "/forward",
    response_model=PlaygroundResponse,
    summary="Forward a query to PM Playground",
)
async def forward_to_playground(request: PlaygroundRequest):
    """
    Forwards a validated query to the PM Copilot Playground backend.
    This acts as a bridge between the AI Assistant frontend and the
    existing PM Playground SQL execution pipeline.
    """
    
    # TODO: integrate with PM Playground backend API
    
    return PlaygroundResponse(
        query=request.query,
        status="not_implemented",
        result={"message": "PM Playground bridge endpoint ready — wire up integration"},
    )
