"""
Feedback endpoints – collect user feedback on AI Assistant responses
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import logging
from datetime import datetime
from typing import Optional
from uuid import uuid4

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.db.database import get_db

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/feedback", tags=["Feedback"])

SCHEMA = settings.db_schema
TABLE = f"{SCHEMA}.ai_assistant_feedback_table"


# ── Schemas ──────────────────────────────────────────────────────────

class FeedbackRequest(BaseModel):
    session_id: str
    unique_chat_id: str = Field(..., description="References the chat turn being rated")
    username: str
    rating: Optional[int] = Field(None, ge=1, le=5, description="Numeric rating (1-5)")
    is_positive: Optional[bool] = Field(None, description="Thumbs up (true) / thumbs down (false)")
    comment: Optional[str] = None


class FeedbackOut(BaseModel):
    feedback_id: str
    session_id: str
    unique_chat_id: str
    username: str
    rating: Optional[int] = None
    is_positive: Optional[bool] = None
    comment: Optional[str] = None
    created_at: datetime


class FeedbackSubmitResponse(BaseModel):
    feedback_id: str
    status: str = "submitted"


# ── Endpoints ────────────────────────────────────────────────────────

@router.post(
    "/submit",
    response_model=FeedbackSubmitResponse,
    status_code=201,
    summary="Submit feedback for a chat turn",
)
async def submit_feedback(fb: FeedbackRequest, db: AsyncSession = Depends(get_db)):
    """Store user feedback (rating / thumbs / comment) linked to a chat turn via unique_chat_id."""
    feedback_id = str(uuid4())
    query = text(f"""
        INSERT INTO {TABLE}
            (feedback_id, session_id, unique_chat_id, username,
             rating, is_positive, comment, created_at)
        VALUES
            (:feedback_id, :session_id, :unique_chat_id, :username,
             :rating, :is_positive, :comment, :created_at)
    """)
    await db.execute(query, {
        "feedback_id": feedback_id,
        "session_id": fb.session_id,
        "unique_chat_id": fb.unique_chat_id,
        "username": fb.username,
        "rating": fb.rating,
        "is_positive": fb.is_positive,
        "comment": fb.comment,
        "created_at": datetime.utcnow(),
    })
    return FeedbackSubmitResponse(feedback_id=feedback_id)


@router.get(
    "/chat/{unique_chat_id}",
    response_model=list[FeedbackOut],
    summary="Get all feedback for a chat turn",
)
async def get_feedback_for_chat(unique_chat_id: str, db: AsyncSession = Depends(get_db)):
    """Retrieve all feedback entries linked to a specific chat turn."""
    query = text(f"""
        SELECT feedback_id, session_id, unique_chat_id, username,
               rating, is_positive, comment, created_at
        FROM {TABLE}
        WHERE unique_chat_id = :cid
        ORDER BY created_at ASC
    """)
    result = await db.execute(query, {"cid": unique_chat_id})
    rows = result.mappings().all()
    return [FeedbackOut(**dict(r)) for r in rows]


@router.get(
    "/session/{session_id}",
    response_model=list[FeedbackOut],
    summary="Get all feedback for a session",
)
async def get_feedback_for_session(session_id: str, db: AsyncSession = Depends(get_db)):
    """Retrieve all feedback entries for a given session."""
    query = text(f"""
        SELECT feedback_id, session_id, unique_chat_id, username,
               rating, is_positive, comment, created_at
        FROM {TABLE}
        WHERE session_id = :sid
        ORDER BY created_at ASC
    """)
    result = await db.execute(query, {"sid": session_id})
    rows = result.mappings().all()
    return [FeedbackOut(**dict(r)) for r in rows]


@router.get(
    "/stats",
    summary="Get feedback statistics",
)
async def feedback_stats(
    session_id: Optional[str] = Query(None, description="Filter stats by session"),
    db: AsyncSession = Depends(get_db),
):
    """Return aggregate feedback stats (count, avg rating, positive/negative counts)."""
    where = "WHERE session_id = :sid" if session_id else ""
    params = {"sid": session_id} if session_id else {}

    query = text(f"""
        SELECT
            COUNT(*) AS total,
            ROUND(AVG(rating)::numeric, 2) AS avg_rating,
            COUNT(*) FILTER (WHERE is_positive = true) AS thumbs_up,
            COUNT(*) FILTER (WHERE is_positive = false) AS thumbs_down
        FROM {TABLE}
        {where}
    """)
    result = await db.execute(query, params)
    row = result.mappings().first()
    return dict(row) if row else {"total": 0, "avg_rating": None, "thumbs_up": 0, "thumbs_down": 0}
