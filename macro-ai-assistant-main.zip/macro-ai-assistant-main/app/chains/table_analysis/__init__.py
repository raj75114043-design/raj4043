"""
Table Analysis Chain – Generate compelling analysis of SQL query results.
"""

from .analysis import extract_eda, generate_table_analysis
from .prompt import TableAnalysis, EDAContext

__all__ = ["extract_eda", "generate_table_analysis", "TableAnalysis", "EDAContext"]
