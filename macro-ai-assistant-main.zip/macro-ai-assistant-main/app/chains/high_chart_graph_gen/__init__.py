"""
Hi-Chart Graph Generation Chain – Generate Highcharts configurations from table data.
"""

from .hi_chart_graph import generate_hichart_graphs
from .prompt import HiChartOutput

__all__ = ["generate_hichart_graphs", "HiChartOutput"]
