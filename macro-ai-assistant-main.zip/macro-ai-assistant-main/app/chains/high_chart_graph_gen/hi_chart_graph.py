"""
Hi-Chart Graph Generation – Generate Highcharts-compatible graph configurations.
Author: AI Assistant Development
Client: Nokia
"""

import json
import logging
import pandas as pd
from toon import encode

from langchain_core.output_parsers import JsonOutputParser, StrOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI

from app.core.config import settings
from .prompt import HiChartOutput, HICHART_GRAPH_PROMPT

logger = logging.getLogger(__name__)

# ── LLM Configuration ─────────────────────────────────────────────

llm = ChatOpenAI(
    api_key="NONE",
    model="gpt-5-mini",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
    reasoning_effort="medium",
    timeout=240,
)


# ── Helper: Generate empty chart ────────────────────────────────

def _generate_empty_chart(user_query: str) -> HiChartOutput:
    """
    Generate a standard empty/placeholder chart when no data is available.

    Args:
        user_query: The original user query (for context)

    Returns:
        HiChartOutput with empty state chart
    """
    empty_chart = {
        "type": "column",
        "title": {
            "text": "No Data Available",
            "style": {"color": "#666", "fontSize": "18px"}
        },
        "subtitle": {
            "text": f"No results found for: {user_query[:60]}..."
            if user_query and len(user_query) > 60
            else f"No results found for your query",
            "style": {"color": "#999", "fontSize": "14px"}
        },
        "xAxis": {
            "categories": ["No Data"],
            "title": {"text": ""},
        },
        "yAxis": {
            "title": {"text": ""},
            "min": 0,
            "labels": {"enabled": False}
        },
        "series": [
            {
                "name": "No Data",
                "data": [0],
                "color": "#e0e0e0"
            }
        ],
        "legend": {"enabled": False},
        "tooltip": {
            "enabled": False
        },
        "credits": {"enabled": False},
        "plotOptions": {
            "column": {
                "enableMouseTracking": False,
                "dataLabels": {
                    "enabled": True,
                    "text": "No results",
                    "style": {"color": "#999"}
                }
            }
        }
    }

    return HiChartOutput(
        charts=[empty_chart],
        rationale="No data matched your query criteria. The empty state chart is displayed above. Try refining your search parameters or expanding the date range."
    )


# ── Helper: Build table preview ──────────────────────────────────

def _build_table_preview(table_json: str) -> str:
    """
    Convert table_json to a readable preview string.

    Args:
        table_json: JSON string representing the table data
        max_rows: Maximum rows to include in preview

    Returns:
        String representation of table data (first max_rows)
    """
    try:
        # Parse JSON to DataFrame
        

        table_toon = encode(table_json)

        # Convert to string
        return table_toon

    except Exception as e:
        logger.warning(f"Failed to build table preview: {e}")
        return "[Unable to parse table data]"


# ── Helper: Build statistical summary for large tables ──────────────

_TEMPORAL_PARSE_THRESHOLD = 0.7  # fraction of values that must parse as dates

def _build_statistical_summary(table_json: str) -> str:
    """
    For tables with >30 rows, produce a compact statistical summary instead of raw data.

    Detects three column types:
      - temporal  : date/datetime columns → range + count of valid dates
      - numerical : int/float columns    → min, max, mean, std, p25/p50/p75, null count
      - categorical: string/object cols  → unique count + top-10 value frequencies

    Returns a structured text block the LLM can use to build charts without
    needing to see every row.
    """
    try:
        data = json.loads(table_json) if table_json else []
        df = pd.DataFrame(data)

        if df.empty:
            return "[No data]"

        n_rows, n_cols = df.shape
        lines: list[str] = []
        lines.append(f"## Data Summary ({n_rows} rows × {n_cols} columns)")
        lines.append(f"Columns: {', '.join(df.columns.tolist())}")
        lines.append("")

        # Always include a small sample so the LLM can see row structure
        sample_str = df.head(5).to_string(index=False, max_colwidth=40)
        lines.append("## First 5 rows (sample):")
        lines.append(sample_str)
        lines.append("")

        lines.append("## Column Statistics:")

        for col in df.columns:
            series = df[col]
            non_null = series.dropna()
            null_count = series.isna().sum()

            if non_null.empty:
                lines.append(f"- {col}: all null values")
                continue

            # ── Temporal detection ──────────────────────────────────
            if series.dtype == object or pd.api.types.is_datetime64_any_dtype(series):
                if pd.api.types.is_datetime64_any_dtype(series):
                    parsed = series
                    valid_ratio = non_null.shape[0] / len(series)
                else:
                    parsed = pd.to_datetime(non_null, infer_datetime_format=True, errors="coerce")
                    valid_ratio = parsed.notna().sum() / len(non_null)

                if valid_ratio >= _TEMPORAL_PARSE_THRESHOLD:
                    valid = parsed.dropna()
                    lines.append(
                        f"- {col} [temporal]: {valid.min().date()} → {valid.max().date()}, "
                        f"{len(valid)} valid dates, nulls={null_count}"
                    )
                    continue

            # ── Numerical detection ─────────────────────────────────
            if pd.api.types.is_numeric_dtype(series):
                lines.append(
                    f"- {col} [numerical]: "
                    f"min={non_null.min():.4g}, max={non_null.max():.4g}, "
                    f"mean={non_null.mean():.4g}, std={non_null.std():.4g}, "
                    f"p25={non_null.quantile(0.25):.4g}, "
                    f"p50={non_null.median():.4g}, "
                    f"p75={non_null.quantile(0.75):.4g}, "
                    f"nulls={null_count}"
                )
                continue

            # ── Categorical (fallback) ──────────────────────────────
            nunique = non_null.nunique()
            top = non_null.value_counts().head(10)
            top_str = ", ".join(f"{k}({v})" for k, v in top.items())
            lines.append(
                f"- {col} [categorical]: {nunique} unique values, "
                f"top: {top_str}, nulls={null_count}"
            )

        return "\n".join(lines)

    except Exception as e:
        logger.warning(f"Failed to build statistical summary: {e}")
        return "[Unable to build summary]"


# ── Main Async Chart Generation Function ───────────────────────────

async def generate_hichart_graphs(
    user_query: str,
    table_json: str,
    generated_sql: str = "",
) -> HiChartOutput:
    """
    Generate Highcharts-compatible chart configurations based on table data and user query.

    Args:
        user_query: The original user query (intent)
        table_json: JSON string of the table data
        generated_sql: The SQL query that generated the data (optional context)

    Returns:
        HiChartOutput with charts list and rationale

    Raises:
        Exception: If LLM call fails or output parsing fails
    """
    try:
        # Check if table is empty early
        is_empty = False
        try:
            data = json.loads(table_json) if table_json else []
            is_empty = not data or (isinstance(data, list) and len(data) == 0)
        except (json.JSONDecodeError, TypeError):
            is_empty = True

        # Build table preview — use compact stats for large tables
        row_count = len(data) if isinstance(data, list) else 0
        if row_count > 30:
            logger.info(f"Table has {row_count} rows (>30), using statistical summary for chart context")
            table_preview = _build_statistical_summary(table_json)
        else:
            table_preview = _build_table_preview(table_json)

        # If empty, return standard empty chart
        if is_empty:
            logger.info("Table is empty, returning standard empty chart")
            return _generate_empty_chart(user_query)


        # Set up the LLM chain
        parser = JsonOutputParser(pydantic_object=HiChartOutput)
        format_instructions = parser.get_format_instructions()

        prompt = PromptTemplate(
            template=HICHART_GRAPH_PROMPT,
            input_variables=["user_query", "generated_sql", "table_preview"],
            partial_variables={
                "format": format_instructions,
            },
        )

        chain = prompt | llm | StrOutputParser() | parser

        # Call LLM asynchronously
        result = await chain.ainvoke({
            "user_query": user_query or "[No query provided]",
            "generated_sql": generated_sql or "[No SQL context]",
            "table_preview": table_preview,
        })

        # Ensure result is a HiChartOutput object (not a dict)
        if isinstance(result, dict):
            result = HiChartOutput(**result)

        logger.info(f"Hi-Chart graphs generated successfully ({len(result.charts)} charts)")
        return result

    except Exception as e:
        logger.error(f"Failed to generate Hi-Chart graphs: {e}", exc_info=True)
        # Return default output on failure
        return HiChartOutput(
            charts=[],
            rationale="Unable to generate chart recommendations at this time. Please review the table data and SQL query above to manually create visualizations.",
        )
