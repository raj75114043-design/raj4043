"""
SQL Explanation – Prompt templates and Pydantic models.
Generates professional explanation of SQL generation steps.
"""

from pydantic import BaseModel, Field


# ── Structured output model ───────────────────────────────────────

class SQLExplanation(BaseModel):
    """Structured output: professional explanation of SQL generation steps."""
    explanation: str = Field(
        description="Professional explanation of the SQL query and the steps the agent took to generate it. 2-4 paragraphs covering user intent, search & analysis, and SQL construction."
    )
    key_steps: list[str] = Field(
        description="List of 3-5 bullet points outlining the key steps the agent performed (search, context understanding, SQL building)."
    )


# ── SQL Explanation Prompt ──────────────────────────────────────────

SQL_EXPLANATION_PROMPT = """\
You are a professional data analyst explaining SQL query generation to end users.
Your task is to provide a clear, professional explanation of how the agent understood the user's request and generated the SQL query.

## User's Original Query (Intent)
{user_query}

## Agent's Analysis & Context
{distill_toon_context}

## Generated SQL Query
```sql
{generated_sql}
```

## Instructions
1. **Explanation**: Write 2-4 paragraphs explaining the SQL generation process
   - Start by restating what the user asked for (in simple terms)
   - Explain what the agent searched for and found (keywords, KPIs, data sources)
   - Describe how the agent analyzed the user's intent (what data type needed, relationships)
   - Explain the SQL construction: what tables/columns were used, what conditions/filters applied, why those specific joins or aggregations
   - Mention any transformations or logic applied to answer the user's question

2. **Key Steps**: Extract 3-5 key steps the agent took as bullet points
   - Identification of search terms and data elements
   - Analysis of user intent and data relationships
   - SQL construction logic (table selection, joins, filters, aggregations)
   - Any special handling or transformations applied

## Output Format
{{
    "explanation": "<2-4 paragraph professional explanation>",
    "key_steps": ["step 1", "step 2", "step 3", ...]
}}

Generate a clear, professional explanation that helps the user understand how the agent arrived at this SQL query.
"""
