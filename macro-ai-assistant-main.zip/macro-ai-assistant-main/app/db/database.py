"""
Database connection and session management using SQLAlchemy
Supports both sync (Streamlit) and async (FastAPI) operations
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import logging
from typing import Generator, AsyncGenerator
from contextlib import contextmanager
from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session, sessionmaker, declarative_base
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    create_async_engine,
    async_sessionmaker,
)
from sqlalchemy.pool import QueuePool

from app.core.config import settings

logger = logging.getLogger(__name__)

Base = declarative_base()


# ==================== Async Engine (FastAPI) ====================

async_engine = create_async_engine(
    settings.database_url,
    echo=settings.debug,
    pool_size=settings.db_pool_min_size,
    max_overflow=settings.db_pool_max_size - settings.db_pool_min_size,
    pool_pre_ping=True,
)

AsyncSessionLocal = async_sessionmaker(
    async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False,
)


# ==================== Sync Engine (Streamlit) ====================

sync_engine = create_engine(
    settings.sync_database_url,
    echo=settings.debug,
    pool_size=settings.db_pool_min_size,
    max_overflow=settings.db_pool_max_size - settings.db_pool_min_size,
    pool_pre_ping=True,
    poolclass=QueuePool,
)

SyncSessionLocal = sessionmaker(
    sync_engine,
    class_=Session,
    expire_on_commit=False,
    autocommit=False,
    autoflush=False,
)


# ==================== Async Session (FastAPI) ====================

async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    FastAPI dependency for async database sessions.

    Usage:
        @router.get("/items")
        async def get_items(db: AsyncSession = Depends(get_db)):
            result = await db.execute(select(Item))
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


# ==================== Sync Session (Streamlit) ====================

@contextmanager
def get_sync_db() -> Generator[Session, None, None]:
    """
    Context manager for sync database sessions.

    Usage:
        with get_sync_db() as db:
            result = db.execute(select(Item)).all()
    """
    session = SyncSessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def get_sync_session() -> Session:
    """
    Get a sync session directly (caller must manage lifecycle).

    Usage in Streamlit:
        db = get_sync_session()
        try:
            result = db.execute(select(Item)).all()
            db.commit()
        finally:
            db.close()
    """
    return SyncSessionLocal()


# ==================== Health Check ====================

async def health_check_async() -> bool:
    """Check async database connection health."""
    try:
        async with AsyncSessionLocal() as session:
            await session.execute(text("SELECT 1"))
        return True
    except Exception:
        return False


def health_check_sync() -> bool:
    """Check sync database connection health."""
    try:
        with get_sync_db() as session:
            session.execute(text("SELECT 1"))
        return True
    except Exception:
        return False


# ==================== Lifecycle ====================

async def init_db() -> None:
    """
    Initialize database connection pool and verify connectivity.
    Called on application startup.
    """
    logger.info("Establishing database connection pool...")

    # Test async connection
    try:
        async with async_engine.connect() as conn:
            result = await conn.execute(text("SELECT 1"))
            result.close()
        logger.info("Async database connection pool established successfully")
        logger.info(f"  Pool class: {async_engine.pool.__class__.__name__}")
        logger.info(f"  Pool size: {async_engine.pool.size()}")
        logger.info(f"  Checked out connections: {async_engine.pool.checkedout()}")
    except Exception as e:
        logger.error(f"Failed to establish async database connection: {e}")
        raise

    # Test sync connection
    try:
        with sync_engine.connect() as conn:
            result = conn.execute(text("SELECT 1"))
            result.close()
        logger.info("Sync database connection pool established successfully")
        logger.info(f"  Pool class: {sync_engine.pool.__class__.__name__}")
        logger.info(f"  Pool size: {sync_engine.pool.size()}")
    except Exception as e:
        logger.error(f"Failed to establish sync database connection: {e}")
        raise

    logger.info("Database connection pools ready")


async def close_db() -> None:
    """
    Close all database connections gracefully.
    Called on application shutdown.
    """
    logger.info("Disposing async engine connection pool...")
    await async_engine.dispose()
    logger.info("Async connection pool disposed")

    logger.info("Disposing sync engine connection pool...")
    sync_engine.dispose()
    logger.info("Sync connection pool disposed")
