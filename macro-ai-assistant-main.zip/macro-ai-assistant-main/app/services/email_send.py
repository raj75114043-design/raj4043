# import base64
# import csv
# import io
# import json
# import requests
# import re
# from datetime import datetime
# from typing import Any, Dict, List, Literal, Optional
# from asyncpg import Connection
# from langchain_openai import ChatOpenAI
# from app.services.load_storage_pipeline import load_latest_workflow_execution
# from app.core.llm_client import get_llm_client


# AUTH_URL = "https://nokiaosdp-gsd-staging.aibi-americas-002.dyn.nesc.nokia.net/web/session/authenticate"
# SEND_MAIL_URL = "https://nokiaosdp-gsd-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/send_mail"

# _AUTH_PAYLOAD = {
#     "jsonrpc": "2.0",
#     "method": "call",
#     "params": {
#         "db": "postgres",
#         "login": "pwc_osdp_user",
#         "password": "pwc_osdp_user",
#     },
# }

# AllowedSites = Literal["FAIL", "PASS", "ALL"]


# # ---------------------------------------------------------------------------
# # Logging helper
# # ---------------------------------------------------------------------------

# def log(message: str):
#     print(f"[EMAIL_SERVICE] {datetime.now().isoformat()} | {message}")


# # ---------------------------------------------------------------------------
# # Step config
# # ---------------------------------------------------------------------------

# async def fetch_step_config(
#     db: Connection,
#     workflow_name: str,
#     step_id: str,
# ) -> Dict[str, Any]:

#     # log(f"Fetching step config | workflow={workflow_name} step_id={step_id}")

#     execution_data = await load_latest_workflow_execution(db, workflow_name)

#     step_results: List[Dict[str, Any]] = execution_data.get("step_results", [])

#     for step in step_results:
#         if str(step.get("step_id", "")) == str(step_id):
#             # log(f"Step config found | step_name={step.get('step_name')}")
#             return step

#     raise ValueError(f"Step '{step_id}' not found in workflow '{workflow_name}'.")


# # ---------------------------------------------------------------------------
# # Output table fetch
# # ---------------------------------------------------------------------------

# def _normalize_identifier(name: str) -> str:
#     return re.sub(r"\s+", "_", name.strip()).lower()


# async def fetch_step_output(
#     db: Connection,
#     workflow_name: str,
#     step_id: str,
#     allowed_sites: AllowedSites,
#     step_config: Optional[Dict[str, Any]] = None,
# ) -> List[Dict[str, Any]]:

#     output_table: Optional[str] = step_config.get("output_table")

#     if not output_table:
#         # log(f"No output table for step={step_id}. Skipping.")
#         return []

#     # log(f"Fetching step output | table={output_table} filter={allowed_sites}")

#     try:

#         if allowed_sites == "ALL":

#             rows = await db.fetch(f"SELECT * FROM {output_table}")

#         else:

#             rows = await db.fetch(
#                 f"""
#                 SELECT *
#                 FROM {output_table}
#                 WHERE final_status = $1
#                 """,
#                 allowed_sites,
#             )

#     except Exception as e:
#         # log(f"Error fetching table {output_table}: {e}")
#         raise

#     rows = [dict(row) for row in rows]

#     # log(f"Rows fetched: {len(rows)}")

#     return rows


# # ---------------------------------------------------------------------------
# # CSV builder
# # ---------------------------------------------------------------------------

# def build_csv_attachment(rows: List[Dict[str, Any]], filename: str) -> Dict[str, str]:

#     # log(f"Building CSV attachment | filename={filename}")

#     if not rows:
#         encoded = base64.b64encode(b"No data available").decode()
#         return {"filename": filename, "filedata": encoded}

#     buf = io.StringIO()

#     writer = csv.DictWriter(buf, fieldnames=list(rows[0].keys()))
#     writer.writeheader()
#     writer.writerows(rows)

#     encoded = base64.b64encode(buf.getvalue().encode()).decode()

#     return {"filename": filename, "filedata": encoded}


# # ---------------------------------------------------------------------------
# # LLM email generation
# # ---------------------------------------------------------------------------

# def generate_email_content(
#     llm: ChatOpenAI,
#     workflow_name: str,
#     step_config: Dict[str, Any],
#     rows: List[Dict[str, Any]],
#     allowed_sites: AllowedSites,
# ) -> tuple[str, str]:

#     # log("Generating email content via LLM")

#     current_time = datetime.now().isoformat()

#     sample = rows[:5] if rows else []

#     prompt = f"""
# You are generating a professional workflow notification email for a telecom network operations team.

# Context:
# - Workflow      : {workflow_name}
# - Step ID       : {step_config.get("step_id")}
# - Step Name     : {step_config.get("step_name")}
# - Description   : {step_config.get("step_description")}
# - Phase         : {step_config.get("phase_name")}
# - Filter        : final_status = {allowed_sites}
# - Rows in email : {len(rows)}
# - Passed (total): {step_config.get("passed_count")}
# - Failed (total): {step_config.get("failed_count")}
# - Sample rows   : {json.dumps(sample, indent=2, default=str)}
# - Generated at  : {current_time}

# Generate EXACTLY this JSON (no markdown fences, no preamble):
# {{
#   "subject": "<concise: [PMCopilot] Workflow | Step Name | Filter | N sites>",
#   "body": "<complete HTML email — inline CSS only, professional tone, summary table of sample rows if data exists, total count prominent, disclaimer do not reply, signed PMCopilot Automation>"
# }}

# Rule:
# Dont Add any link or email.
# """

#     response = llm.invoke(prompt)
#     raw = response.content.strip()

#     if raw.startswith("```"):
#         raw = raw.split("```")[1]
#         if raw.startswith("json"):
#             raw = raw[4:]
#     raw = raw.strip()

#     parsed = json.loads(raw)
#     return parsed["subject"], parsed["body"]

#     response = llm.invoke(prompt)

#     raw = response.content.strip()

#     if raw.startswith("```"):
#         raw = raw.split("```")[1]
#         if raw.startswith("json"):
#             raw = raw[4:]

#     parsed = json.loads(raw.strip())

#     # log("Email subject generated")

#     return parsed["subject"], parsed["body"]


# # ---------------------------------------------------------------------------
# # Mail gateway
# # ---------------------------------------------------------------------------

# def _get_session_id() -> str:

#     # log("Authenticating with Nokia mail gateway")

#     session = requests.Session()

#     resp = session.post(
#         AUTH_URL,
#         json=_AUTH_PAYLOAD,
#         headers={"Content-Type": "application/json"},
#         timeout=30,
#     )

#     resp.raise_for_status()

#     session_id = session.cookies.get("session_id")

#     if not session_id:
#         raise RuntimeError("Authentication failed — session_id missing")

#     # log("Mail gateway authentication successful")

#     return session_id


# def send_email(
#     session_id: str,
#     to_list: List[str],
#     cc_list: List[str],
#     bcc_list: List[str],
#     subject: str,
#     body: str,
#     attachments: List[Dict[str, str]],
# ) -> Dict[str, Any]:

#     # log("Sending email via gateway")

#     payload = {
#         "params": {
#             "tolist": to_list,
#             "cclist": cc_list,
#             "bcclist": bcc_list,
#             "subject": subject,
#             "body": body,
#             "file": attachments,
#         }
#     }

#     resp = requests.post(
#         SEND_MAIL_URL,
#         json=payload,
#         headers={
#             "Content-Type": "application/json",
#             "Cookie": f"session_id={session_id}",
#         },
#         timeout=30,
#     )

#     resp.raise_for_status()

#     # log("Email sent successfully")

#     return resp.json()


# # ---------------------------------------------------------------------------
# # Orchestrator
# # ---------------------------------------------------------------------------

# async def send_workflow_step_email(
#     db: Connection,
#     workflow_name: str,
#     step_id: int,
#     to_list: List[str],
#     cc_list: List[str],
#     bcc_list: List[str],
#     allowed_sites: AllowedSites,
#     llm: Optional[ChatOpenAI] = None,
# ) -> Dict[str, Any]:

#     # log(f"Starting email workflow | workflow={workflow_name} step_id={step_id}")

#     if llm is None:
#         llm = get_llm_client("medium")

#     step_config = await fetch_step_config(db, workflow_name, step_id)

#     rows = await fetch_step_output(
#         db,
#         workflow_name,
#         step_id,
#         allowed_sites,
#         step_config,
#     )

#     # ------------------------------------------------------------------
#     # Skip email if PASS/FAIL rows are empty
#     # ------------------------------------------------------------------

#     if allowed_sites in ["PASS", "FAIL"] and len(rows) == 0:

#         # log(f"No {allowed_sites} rows found — email will NOT be sent")

#         return {
#             "status": "skipped",
#             "message": f"No rows found with status {allowed_sites}",
#             "step_name": step_config.get("step_name"),
#         }

#     # ------------------------------------------------------------------

#     subject, body = generate_email_content(
#         llm,
#         workflow_name,
#         step_config,
#         rows,
#         allowed_sites,
#     )

#     step_name_safe = _normalize_identifier(
#         step_config.get("step_name", step_id)
#     )

#     csv_filename = f"{_normalize_identifier(workflow_name)}_{step_name_safe}_{allowed_sites}.csv"

#     attachment = build_csv_attachment(rows, csv_filename)

#     session_id = _get_session_id()

#     result = send_email(
#         session_id=session_id,
#         to_list=to_list,
#         cc_list=cc_list,
#         bcc_list=bcc_list,
#         subject=subject,
#         body=body,
#         attachments=[attachment],
#     )

#     # log("Workflow email process completed")

#     return {
#         "status": "sent",
#         "subject": subject,
#         "step_name": step_config.get("step_name"),
#         "total_rows": len(rows),
#         "attachment": csv_filename,
#         "gateway_response": result,
#     }



# async def send_simple_email(
#     to_list: List[str],
#     cc_list: List[str],
#     bcc_list: List[str],
#     subject: str,
#     email_body: str,
#     attachments: Optional[List[Dict[str, str]]] = None,
# ) -> Dict[str, Any]:
#     """
#     Send a simple email without workflow processing.
#     """

#     # log("Starting simple email send")

#     if attachments is None:
#         attachments = []

#     try:

#         # authenticate with mail gateway
#         session_id = _get_session_id()

#         result = send_email(
#             session_id=session_id,
#             to_list=to_list,
#             cc_list=cc_list,
#             bcc_list=bcc_list,
#             subject=subject,
#             body=email_body,
#             attachments=attachments,
#         )

#         # log("Simple email sent successfully")

#         return {
#             "status": "sent",
#             "subject": subject,
#             "gateway_response": result,
#         }

#     except Exception as e:

#         # log(f"Simple email failed: {str(e)}")
#         raise




################ API Route Example ##########################

# """
# Email Router — Async Background Email Sender

# Endpoints
# ---------
# POST   /email/send-workflow-step   -> start email job
# GET    /email/status/{token_id}    -> check job status
# """

# import uuid
# import asyncio
# from datetime import datetime
# from typing import List, Optional, Dict, Any

# from fastapi import APIRouter, Depends, HTTPException, status
# from pydantic import BaseModel
# from asyncpg import Connection

# from app.db.pool import get_db, get_connection
# from app.services.email_service import send_workflow_step_email, AllowedSites, send_simple_email


# router = APIRouter(prefix="/email", tags=["Email"])


# # ---------------------------------------------------------------------------
# # In-memory job store
# # ---------------------------------------------------------------------------

# EMAIL_JOBS: Dict[str, Dict[str, Any]] = {}


# def log(message: str):
#     print(f"[EMAIL_JOB] {datetime.now().isoformat()} | {message}")


# # ---------------------------------------------------------------------------
# # Request / Response models
# # ---------------------------------------------------------------------------

# class SendWorkflowStepEmailRequest(BaseModel):
#     workflow_name: str
#     step_id: int
#     to_list: List[str]
#     cc_list: List[str] = []
#     bcc_list: List[str] = []
#     allowed_sites: AllowedSites = "ALL"


# class EmailJobStartResponse(BaseModel):
#     token_id: str
#     status: str


# class EmailJobStatusResponse(BaseModel):
#     token_id: str
#     status: str
#     result: Optional[Dict[str, Any]] = None
#     error: Optional[str] = None

# class SendSimpleEmailRequest(BaseModel):
#     to_list: List[str]
#     cc_list: List[str] = []
#     bcc_list: List[str] = []
#     subject: str
#     email_body: str

# # ---------------------------------------------------------------------------
# # Background job runner
# # ---------------------------------------------------------------------------

# async def run_email_job(
#     token_id: str,
#     request: SendWorkflowStepEmailRequest,
# ):

#     # log(f"Starting background job | token={token_id}")

#     EMAIL_JOBS[token_id]["status"] = "RUNNING"

#     try:

#         # Create fresh DB connection for background task
#         async with get_connection() as db:

#             result = await send_workflow_step_email(
#                 db=db,
#                 workflow_name=request.workflow_name,
#                 step_id=request.step_id,
#                 to_list=request.to_list,
#                 cc_list=request.cc_list,
#                 bcc_list=request.bcc_list,
#                 allowed_sites=request.allowed_sites,
#             )

#         EMAIL_JOBS[token_id]["status"] = result.get("status", "COMPLETED")
#         EMAIL_JOBS[token_id]["result"] = result

#         # log(f"Email job finished | token={token_id} status={EMAIL_JOBS[token_id]['status']}")

#     except Exception as e:

#         EMAIL_JOBS[token_id]["status"] = "FAILED"
#         EMAIL_JOBS[token_id]["error"] = str(e)

#         # log(f"Email job failed | token={token_id} error={str(e)}")


# # ---------------------------------------------------------------------------
# # Start Email Job Endpoint
# # ---------------------------------------------------------------------------

# @router.post(
#     "/send-workflow-step",
#     response_model=EmailJobStartResponse,
#     status_code=status.HTTP_202_ACCEPTED,
#     summary="Start workflow step email job",
# )
# async def send_workflow_step_email_endpoint(
#     request: SendWorkflowStepEmailRequest,
#     db: Connection = Depends(get_db),
# ):

#     token_id = str(uuid.uuid4())[:8]

#     EMAIL_JOBS[token_id] = {
#         "status": "PENDING",
#         "result": None,
#         "error": None,
#     }

#     # log(f"Job created | token={token_id}")

#     asyncio.create_task(
#         run_email_job(
#             token_id,
#             request,
#         )
#     )

#     return {
#         "token_id": token_id,
#         "status": "PENDING",
#     }


# # ---------------------------------------------------------------------------
# # Job Status Endpoint
# # ---------------------------------------------------------------------------

# @router.get(
#     "/status/{token_id}",
#     response_model=EmailJobStatusResponse,
#     summary="Check email job status",
# )
# async def get_email_job_status(token_id: str):

#     job = EMAIL_JOBS.get(token_id)

#     if not job:
#         raise HTTPException(
#             status_code=404,
#             detail="Token ID not found",
#         )

#     return {
#         "token_id": token_id,
#         "status": job["status"],
#         "result": job.get("result"),
#         "error": job.get("error"),
#     }


# @router.post(
#     "/send",
#     summary="Send simple email",
# )
# async def send_simple_email_endpoint(
#     request: SendSimpleEmailRequest,
# ):

#     try:

#         result = await send_simple_email(
#             to_list=request.to_list,
#             cc_list=request.cc_list,
#             bcc_list=request.bcc_list,
#             subject=request.subject,
#             email_body=request.email_body,
#             attachments=None,
#         )

#         return result

#     except Exception as e:

#         raise HTTPException(
#             status_code=500,
#             detail=f"Email send failed: {str(e)}",
#         )
