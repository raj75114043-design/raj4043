import httpx
from app.core.config import settings
import asyncio
import importlib
import json
import time
from datetime import datetime, timezone

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


'''
{'input_sentence': 'For each Region and General Contractor, calculate the total number of active New Site Build projects, the On-Air Completion Rate (%), the average Site Completion Cycle Time from Construction Start to On-Air, and the count of sites where Civil Start was delayed by more than 60 days after Entitlement Completion.',
 'detected_count': 3,
 'detected_keywords': [{'keyword_id': 396956,
   'keyword_name': 'New Site Build',
   'keyword_description': 'Type of scope',
   'mapped_tables_columns': 'por_category',
   'logic': 'por_category from MB shows the type of scope',
   'synonyms': 'NSD, Project Type',
   'matched_terms': ['New Site Build'],
   'created_at': '2026-02-18T05:42:24.994454',
   'updated_at': '2026-02-18T05:42:24.994458'},
  {'keyword_id': 845461,
   'keyword_name': 'Site',
   'keyword_description': 'Assigned to each tower site for tracking throughout its lifecycle',
   'mapped_tables_columns': 's_site_id',
   'logic': 'using ndpd_mbt_tmobile_macro_combined tracker refer column s_site_id',
   'synonyms': 'Site ID , Site, Site Code',
   'matched_terms': ['Site'],
   'created_at': '2026-02-18T05:42:24.995747',
   'updated_at': '2026-02-18T05:42:24.995751'},
  {'keyword_id': 768015,
   'keyword_name': 'EC',
   'keyword_description': 'Authorization for the contractor,Entitlement complete',
   'mapped_tables_columns': 'pj_a_3710_ran_entitlement_complete_finish',
   'logic': 'if pj_a_3710_ran_entitlement_complete_finish from MB is not null then Nokia is Entitled',
   'synonyms': 'Entitlement Completed, Entitled',
   'matched_terms': ['EC'],
   'created_at': '2026-02-18T05:43:21.273356',
   'updated_at': '2026-02-18T05:43:21.273361'}]}
'''

async def _fetch_keywords(client: httpx.AsyncClient, query: str) -> dict:

    resp = await client.get(
        settings.keyword_search_api,
        params={"sentence": query},
        headers={"Accept": "application/json"},
        timeout=30,
    )

    resp.raise_for_status()

    data = resp.json()

    names = []
    ids = []
    results = []
    for kw in data.get("detected_keywords", []):
        if kw.get("keyword_name"):
            names.append(kw["keyword_name"])
            ids.append(kw.get("keyword_id"))
            # Build result object with content for HITL agent
            results.append({
                "keyword_name": kw.get("keyword_name"),
                "keyword_id": kw.get("keyword_id"),
                "description": kw.get("keyword_description", ""),
                "score": 1.0,  # Keywords don't have scores, set default
            })

    return {"keyword_names": names, "keyword_ids": ids, "keyword_results": results}

'''
{'query': 'For each Region and General Contractor, calculate the total number of active New Site Build projects, the On-Air Completion Rate (%), the average Site Completion Cycle Time from Construction Start to On-Air, and the count of sites where Civil Start was delayed by more than 60 days after Entitlement Completion.',
 'total_results': 8,
 'results': [{'table': 'kpi',
   'id': 487623,
   'content': {'formula': 'Average(PJ:Completion Objective Actual Date" – PJ(A 4225) Construction Start-Finish)',
    'kpi_id': '487623',
    'logic': 'Consider base table as mbt_tracker and match with pm_tracker then In MBT ‘Project Type’ column should be considered as either Site Mod or New Build. The ‘PJ(A 4225) Construction Start-Finish’ column should be treated as a date, and the "PJ:Completion Objective Actual Date" column should be considered based on both the start and end dates',
    'root_cause_positive': '',
    'updated_at': '2026-02-17 12:49:18.123201',
    'description': 'Measures the average number of days from project start (Cx Start) to On-Air for Site Mods and New Builds',
    'kpi_name': 'Site Completion Cycle Time',
    'mapped_tables_columns': 'tmo_retro_mbt_tracker(pj_project_id m_area, m_market, rgn_region,pj_project_type,pj_a_4225_construction_start_finish)\n\npm_tracker(project_id,)',
    'root_cause_negative': '',
    'created_at': '2026-02-17 12:49:18.123196'},
   'similarity_score': 0.8811},
  {'table': 'kpi',
   'id': 607143,
   'content': {'formula': 'Count of sites where (Civil Start Date(pj_a_4250_civil_construction_start_finish) – Entitlement Completion Date)(pj_a_3710_ran_entitlement_complete_finish) > 60',
    'kpi_id': '607143',
    'logic': 'Use the MBT_Tracker as the base table and match it with PM_Tracker. In MBT, calculate the difference between Civil Start Date and Entitlement Completion (EC) date, and count the sites where the difference is greater than 60 days.',
    'root_cause_positive': '',
    'updated_at': '2026-02-17 12:49:21.529443',
    'description': 'Number of sites where civil construction has not started within 60 days after Entitlement Completion',
    'kpi_name': 'Civil Start Delay (>60 Days)',
    'mapped_tables_columns': 'tmo_retro_mbt_tracker(pj_project_id m_area, m_market, rgn_region,pj_project_type,pj_a_3710_ran_entitlement_complete_finish,pj_a_4250_civil_construction_start_finish)\n\npm_tracker(project_id,)',
    'root_cause_negative': '',
    'created_at': '2026-02-17 12:49:21.529436'},
   'similarity_score': 0.874},
  {'table': 'kpi',
   'id': 623400,
   'content': {'formula': 'Count of sites where (Civil Completion Date (pj_a_4750_civil_construction_complete_finish) – Civil Start Date(pj_a_4250_civil_construction_start_finish)) > 21',
    'kpi_id': '623400',
    'logic': 'Use the MBT_Tracker as the base table and match it with PM_Tracker. In MBT, calculate the difference between Civil Complete and Civil Start Date, and count the sites where the difference is greater than 21 days.',
    'root_cause_positive': '',
    'updated_at': '2026-02-17 12:49:22.406942',
    'description': 'Number of sites where civil work started but was not completed within SLA (21 days)',
    'kpi_name': 'Civil Completion Delay',
    'mapped_tables_columns': 'tmo_retro_mbt_tracker(pj_project_id m_area, m_market, rgn_region,pj_project_type,pj_a_4250_civil_construction_start_finish, pj_a_4750_civil_construction_complete_finish)\n\npm_tracker(project_id,)',
    'root_cause_negative': '',
    'created_at': '2026-02-17 12:49:22.406937'},
   'similarity_score': 0.8649}
   ]}
'''


async def _fetch_kpis(client: httpx.AsyncClient, query: str) -> dict:

    resp = await client.post(
        settings.kpi_search_api,
        json={"query": query, "table": "kpi", "top_k": 5},
        headers={"Accept": "application/json", "Content-Type": "application/json"},
        timeout=30,
    )

    resp.raise_for_status()

    data = resp.json()

    names = []
    ids = []
    results = []
    for r in data.get("results", []):
        content = r.get("content", {})
        if content.get("kpi_name"):
            names.append(content["kpi_name"])
            ids.append(content.get("kpi_id"))
            # Build result object with content for HITL agent
            results.append({
                "content": {
                    "kpi_name": content.get("kpi_name"),
                    "description": content.get("description", ""),
                    "kpi_id": content.get("kpi_id"),
                },
                "score": r.get("similarity_score", 1.0),
            })

    return {"kpi_names": names, "kpi_ids": ids, "kpi_results": results}

'''
{'query': 'For each Region and General Contractor, calculate the total number of active New Site Build projects, the On-Air Completion Rate (%), the average Site Completion Cycle Time from Construction Start to On-Air, and the count of sites where Civil Start was delayed by more than 60 days after Entitlement Completion.',
 'total_results': 3,
 'results': [{'table': 'question_bank',
   'id': 662881,
   'content': {'question': 'List the CxS to On Air high cycle time sites region wise',
    'question_id': '662881',
    'created_at': '2026-02-18 07:42:53.402942',
    'sql': 'SELECT rgn_region,\n    pj_project_id,\n    "ms_1550_construction_start_actual",\n    ms_1970_integration_complete_actual,\n    current_date - "ms_1550_construction_start_actual"::date AS aging_days\nFROM ndpd_mbt_tmobile_macro_combined\nWHERE "ms_1970_integration_complete_actual" IS NULL\n  AND "ms_1550_construction_start_actual" IS NOT NULL\nORDER BY aging_days DESC;',
    'updated_at': '2026-02-18 07:42:53.402947'},
   'similarity_score': 0.831},
  {'table': 'question_bank',
   'id': 654321,
   'content': {'question': 'List the sites in WIP status and no. of days since WIP',
    'question_id': '654321',
    'created_at': '2026-02-18 07:37:53.704953',
    'sql': 'SELECT DISTINCT rgn_region AS "Region",m_market AS "Market",pj_project_id AS "Project_Id",\n    pj_a_4225_construction_start_finish::date AS "CX Start Date",\n    (CURRENT_DATE - pj_a_4225_construction_start_finish::date) AS "Days Since CX Start"\nFROM\n    public.ndpd_mbt_tmobile_macro_combined\nWHERE\n    pj_a_4225_construction_start_finish IS NOT NULL AND pj_a_5175_construction_complete_finish IS NULL\nORDER BY rgn_region, m_market;',
    'updated_at': '2026-02-18 07:37:53.704959'},
   'similarity_score': 0.8271},
  {'table': 'question_bank',
   'id': 941553,
   'content': {'question': 'List all sites ready for Civil start in next 8 weeks',
    'question_id': '941553',
    'created_at': '2026-02-17 12:55:33.708253',
    'sql': 'select rgn_region AS "Region",m_market AS "Market",pj_project_id AS "Project_Id",\npj_a_4200_pull_construction_po_number_finish::date AS "PO Available", \npj_p_4250_civil_construction_start_finish::date AS "Civil Start Forecast Date"\nfrom public.ndpd_mbt_tmobile_macro_combined \nwhere pj_a_4200_pull_construction_po_number_finish IS NOT NULL AND  \npj_project_type = \'N-NSD Macro\'AND \npj_a_4250_civil_construction_start_finish IS NULL\nAND pj_p_4250_civil_construction_start_finish::date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL \'8 weeks\';',
    'updated_at': '2026-02-17 12:55:33.708257'},
   'similarity_score': 0.8249}]}
'''

async def _fetch_question_bank(client: httpx.AsyncClient, query: str) -> dict:

    resp = await client.post(
        settings.qb_search_api,
        json={"query": query, "table": "question_bank", "top_k": 3},
        headers={"Accept": "application/json", "Content-Type": "application/json"},
        timeout=30,
    )

    resp.raise_for_status()

    data = resp.json()

    names = []
    ids = []
    results = []
    for r in data.get("results", []):
        content = r.get("content", {})
        if content.get("question"):
            names.append(content["question"])
            ids.append(content.get("question_id"))
            # Build result object with content for HITL agent
            results.append({
                "content": {
                    "question": content.get("question"),
                    "question_id": content.get("question_id"),
                },
                "score": r.get("similarity_score", 1.0),
            })

    return {"qb_names": names, "qb_ids": ids, "qb_results": results}


# ──────────────────────────────────────────────────────────────────────
# Parallel_Search
# ──────────────────────────────────────────────────────────────────────

async def parallel_search(user_query:str) -> dict:
    """Fire keyword, KPI, and question-bank searches in parallel."""
    t_start, iso_start = time.perf_counter(), _now_iso()

    query = user_query
    async with httpx.AsyncClient() as client:
        keyword_result, kpi_result, qb_result = await asyncio.gather(
            _fetch_keywords(client, query),
            _fetch_kpis(client, query),
            _fetch_question_bank(client, query),
        )

    duration = time.perf_counter() - t_start
    return {
        "keyword_names": keyword_result["keyword_names"],
        "keyword_ids": keyword_result["keyword_ids"],
        "keyword_results": keyword_result.get("keyword_results", []),
        "kpi_names": kpi_result["kpi_names"],
        "kpi_ids": kpi_result["kpi_ids"],
        "kpi_results": kpi_result.get("kpi_results", []),
        "qb_names": qb_result["qb_names"],
        "qb_ids": qb_result["qb_ids"],
        "qb_results": qb_result.get("qb_results", []),
        "node_timestamps": duration,
    }
