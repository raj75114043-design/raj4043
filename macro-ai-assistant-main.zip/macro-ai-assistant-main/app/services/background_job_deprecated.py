
# # ── Background Job Worker ─────────────────────────────────────────

# async def _process_query_job(
#     job_id: str,
#     request: QueryRequest,
#     search_result: dict,
#     keyword_names: list[str],
#     keyword_ids: list[str],
#     keyword_results: list,
#     kpi_names: list[str],
#     kpi_ids: list[str],
#     kpi_results: list,
#     qb_names: list[str],
#     qb_ids: list[str],
#     qb_results: list,
# ) -> None:
#     """
#     Background worker that processes a query job asynchronously.
#     Updates JOB_STORE with progress and results.
#     """
#     job = JOB_STORE[job_id]

#     try:
#         job["started_at"] = datetime.now(timezone.utc).isoformat()
#         job["status"] = "processing"
#         job["progress"] = "Running HITL analysis…"

#         # ── Step 2: HITL agent invocation ──────────────────────────────
#         unique_chat_id = str(uuid4())
#         hitl_id = str(uuid4())
#         job["unique_chat_id"] = unique_chat_id
#         job["hitl_id"] = hitl_id

#         # Fetch previous context if this is a follow-up
#         prev_query = ""
#         prev_msg = ""
#         prev_sql = ""
#         if request.is_follow_up and request.follow_up_chat_id:
#             prev_query, prev_msg, prev_sql = await _fetch_previous_context(request.follow_up_chat_id)

#         try:
#             hitl = await run_hitl_agent(
#                 user_query=request.query,
#                 keyword_results=keyword_results,
#                 kpi_results=kpi_results,
#                 qb_results=qb_results,
#                 keyword_names=keyword_names,
#                 kpi_names=kpi_names,
#                 qb_questions=qb_names,
#                 is_follow_up=request.is_follow_up,
#                 previous_user_query=prev_query,
#                 previous_clarifying_message=prev_msg,
#             )
#         except Exception as e:
#             logger.error(f"HITL agent failed: {e}")
#             job["status"] = "failed"
#             job["error"] = f"HITL processing failed: {e}"
#             job["completed_at"] = datetime.now(timezone.utc).isoformat()
#             return

#         query_type = hitl.get("query_type", "")
#         ready_for_sql = hitl.get("ready_for_sql", False)

#         # ── Scenario 1: General / chitchat query ──────────────────────
#         if query_type == "general":
#             general_response = hitl.get("general_response", "")

#             # Persist chat_history + hitl in background (no SQL output)
#             await _save_chat_and_hitl(
#                 unique_chat_id=unique_chat_id,
#                 hitl_id=hitl_id,
#                 session_id=request.session_id,
#                 username=request.username,
#                 user_query=request.query,
#                 keyword_names=keyword_names,
#                 kpi_names=kpi_names,
#                 qb_names=qb_names,
#                 is_follow_up=request.is_follow_up,
#                 hitl_generic_response=general_response,
#                 hitl_assisted_response="",
#                 hitl_status="completed_general",
#             )

#             job["status"] = "completed"
#             job["result"] = {
#                 "unique_chat_id": unique_chat_id,
#                 "hitl_id": hitl_id,
#                 "query_type": "general",
#                 "ready_for_sql": False,
#                 "general_response": general_response,
#                 "success": True,
#             }
#             job["completed_at"] = datetime.now(timezone.utc).isoformat()
#             return

#         # ── Scenario 2: Data question but needs clarification ─────────
#         if query_type == "data" and not ready_for_sql:
#             clarifying_message = hitl.get("clarifying_message", "")

#             # Persist so the follow-up can reference this chat turn
#             await _save_chat_and_hitl(
#                 unique_chat_id=unique_chat_id,
#                 hitl_id=hitl_id,
#                 session_id=request.session_id,
#                 username=request.username,
#                 user_query=request.query,
#                 keyword_names=keyword_names,
#                 kpi_names=kpi_names,
#                 qb_names=qb_names,
#                 is_follow_up=request.is_follow_up,
#                 hitl_generic_response="",
#                 hitl_assisted_response=clarifying_message,
#                 hitl_status="needs_clarification",
#             )

#             job["status"] = "completed"
#             job["result"] = {
#                 "unique_chat_id": unique_chat_id,
#                 "hitl_id": hitl_id,
#                 "query_type": "data",
#                 "ready_for_sql": False,
#                 "clarifying_message": clarifying_message,
#                 "success": True,
#             }
#             job["completed_at"] = datetime.now(timezone.utc).isoformat()
#             return

#         # ── Scenario 3: Data question ready for SQL agent ─────────────
#         job["progress"] = "Generating SQL query (this may take a few minutes)…"

#         try:
#             # No timeout here - let it run until completion
#             sql_result = await run_sql_agent(
#                 user_query=request.query,
#                 keyword_names=keyword_names,
#                 kpi_names=kpi_names,
#                 qb_names=qb_names,
#                 is_follow_up=request.is_follow_up,
#                 previous_user_query=prev_query,
#                 previous_clarifying_message=prev_msg,
#                 previous_generated_sql=prev_sql,
#             )
#         except Exception as e:
#             logger.error(f"SQL agent failed: {e}", exc_info=True)
#             job["status"] = "failed"
#             job["error"] = f"SQL generation failed: {e}"
#             job["completed_at"] = datetime.now(timezone.utc).isoformat()
#             return

#         sql_success = sql_result.get("success", False)
#         generated_sql = sql_result.get("generated_sql", "")
#         result_df = sql_result.get("result_df")
#         sql_error = sql_result.get("error", "")

#         # Serialize DataFrame to JSON for storage
#         table_json = ""
#         if result_df is not None and not result_df.empty:
#             table_json = result_df.to_json(orient="records", date_format="iso")

#         # Save chat history with full SQL output
#         await _save_chat_and_hitl(
#             unique_chat_id=unique_chat_id,
#             hitl_id=hitl_id,
#             session_id=request.session_id,
#             username=request.username,
#             user_query=request.query,
#             keyword_names=keyword_names,
#             kpi_names=kpi_names,
#             qb_names=qb_names,
#             is_follow_up=request.is_follow_up,
#             hitl_generic_response="",
#             hitl_assisted_response="",
#             hitl_status="Data Question",
#             sql_generated=generated_sql,
#             table_json=table_json,
#         )

#         job["status"] = "completed"
#         job["result"] = {
#             "unique_chat_id": unique_chat_id,
#             "hitl_id": hitl_id,
#             "query_type": "data",
#             "ready_for_sql": True,
#             "success": sql_success,
#             "generated_sql": generated_sql,
#             "table_json": table_json,
#             "error": sql_error,
#             "node_timestamps": sql_result.get("node_timestamps", {}),
#         }
#         job["completed_at"] = datetime.now(timezone.utc).isoformat()

#     except Exception as e:
#         logger.error(f"Background job {job_id} failed unexpectedly: {e}", exc_info=True)
#         job["status"] = "failed"
#         job["error"] = str(e)
#         job["completed_at"] = datetime.now(timezone.utc).isoformat()



