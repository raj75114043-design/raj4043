def build_text2sql_context(world_view: dict) -> dict:
    """
    Distills the raw world_view JSON into a compact context
    optimized for a text-to-SQL LLM. Drops all_columns, validation
    blocks, related_tables, and other metadata noise.

    Gracefully handles None / missing / empty values at every level
    so a single bad record never crashes the pipeline.
    """
    if not world_view:
        return {"schema_name": None, "user_input": None, "kpis": [], "reference_questions": [], "keywords": [], "tables": {}}

    wv = world_view.get("world_view") or world_view

    context = {
        "schema_name": wv.get("schema_name"),
        "user_input": wv.get("input"),
    }

    # --- KPI contexts: keep only what the LLM needs to write SQL ---
    context["kpis"] = []
    for kpi in wv.get("kpi_contexts") or []:
        if not isinstance(kpi, dict):
            continue
        # skip entries that have no name at all
        kpi_name = kpi.get("kpi_name")
        if not kpi_name:
            continue
        context["kpis"].append({
            "kpi_name": kpi_name,
            "description": kpi.get("description") or "",
            "formula": kpi.get("formula") or "",
            "logic": kpi.get("logic") or "",
            "tables": kpi.get("tables_involved") or [],
            "columns": kpi.get("matched_columns_by_table") or {},
        })

    # --- Question bank: keep reference SQL as few-shot examples ---
    context["reference_questions"] = []
    for q in wv.get("question_contexts") or []:
        if not isinstance(q, dict):
            continue
        question_text = q.get("question")
        if not question_text:
            continue
        entry = {
            "question": question_text,
            "tables": q.get("tables_involved") or [],
            "columns": q.get("matched_columns_by_table") or {},
        }
        ref_sql = q.get("reference_sql")
        if ref_sql:
            entry["reference_sql"] = ref_sql
        context["reference_questions"].append(entry)

    # --- Keywords: domain vocabulary for the LLM ---
    context["keywords"] = []
    for kw in wv.get("keyword_contexts") or []:
        if not isinstance(kw, dict):
            continue
        keyword_name = kw.get("keyword_name")
        if not keyword_name:
            continue
        context["keywords"].append({
            "keyword": keyword_name,
            "description": kw.get("description") or "",
            "synonyms": kw.get("synonyms") or [],
            "columns": kw.get("matched_columns_by_table") or {},
        })

    # --- Focused tables: only referenced columns, no all_columns ---
    context["tables"] = {}
    for table_name, info in (wv.get("focused_tables") or {}).items():
        if not table_name or not isinstance(info, dict):
            continue
        ref_cols = info.get("referenced_columns")
        if ref_cols:
            context["tables"][table_name] = ref_cols

    return context
