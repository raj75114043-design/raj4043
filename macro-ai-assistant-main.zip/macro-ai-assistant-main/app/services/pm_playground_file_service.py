"""
PM Playground File Processing Service
Handles CSV and Excel file uploads, converts to pandas DataFrames, and stores as JSON.

Author: Venkatesh Manikantan - PwC India
Client: Nokia
"""

import logging
import json
from typing import Tuple
from io import BytesIO
import pandas as pd
from fastapi import UploadFile, HTTPException

logger = logging.getLogger(__name__)

# Supported file extensions
ALLOWED_CSV_EXTENSIONS = {".csv"}
ALLOWED_EXCEL_EXTENSIONS = {".xlsx", ".xls"}
ALL_ALLOWED_EXTENSIONS = ALLOWED_CSV_EXTENSIONS | ALLOWED_EXCEL_EXTENSIONS


def _get_file_extension(filename: str) -> str:
    """Extract file extension from filename."""
    return "." + filename.rsplit(".", 1)[-1].lower() if "." in filename else ""


def _validate_file_extension(filename: str) -> str:
    """
    Validate file extension.

    Args:
        filename: The uploaded file name

    Returns:
        The validated extension

    Raises:
        HTTPException: If file extension is not supported
    """
    ext = _get_file_extension(filename)
    if ext not in ALL_ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{ext}'. Allowed: {', '.join(ALL_ALLOWED_EXTENSIONS)}"
        )
    return ext


async def process_csv_file(file_content: bytes) -> pd.DataFrame:
    """
    Process CSV file and return pandas DataFrame.

    Args:
        file_content: Raw bytes of the CSV file

    Returns:
        pandas DataFrame

    Raises:
        HTTPException: If file processing fails
    """
    try:
        df = pd.read_csv(BytesIO(file_content))

        if df.empty:
            raise HTTPException(
                status_code=400,
                detail="CSV file is empty or contains no readable data"
            )

        logger.info(f"CSV file processed successfully. Shape: {df.shape}")
        return df

    except pd.errors.ParserError as e:
        logger.exception("Failed to parse CSV file")
        raise HTTPException(
            status_code=400,
            detail=f"Failed to parse CSV file: {str(e)}"
        )
    except Exception as e:
        logger.exception("Unexpected error processing CSV file")
        raise HTTPException(
            status_code=500,
            detail=f"Error processing CSV file: {str(e)}"
        )


async def process_excel_file(file_content: bytes) -> pd.DataFrame:
    """
    Process Excel file (reads first sheet only) and return pandas DataFrame.

    Args:
        file_content: Raw bytes of the Excel file

    Returns:
        pandas DataFrame from first sheet

    Raises:
        HTTPException: If file processing fails
    """
    try:
        # Try to read Excel file using openpyxl engine first (supports .xlsx)
        try:
            df = pd.read_excel(BytesIO(file_content), sheet_name=0)
        except ImportError:
            # Fallback to xlrd engine if openpyxl not available
            logger.warning("openpyxl not available, trying xlrd engine")
            df = pd.read_excel(BytesIO(file_content), sheet_name=0, engine="xlrd")

        if df.empty:
            raise HTTPException(
                status_code=400,
                detail="Excel file is empty or contains no readable data in the first sheet"
            )

        logger.info(f"Excel file processed successfully. Sheet shape: {df.shape}")
        return df

    except HTTPException:
        raise
    except ImportError as e:
        logger.exception("Required library not available for Excel processing")
        raise HTTPException(
            status_code=500,
            detail="Excel processing library not available. Install openpyxl or xlrd."
        )
    except Exception as e:
        logger.exception("Error processing Excel file")
        raise HTTPException(
            status_code=400,
            detail=f"Failed to process Excel file: {str(e)}"
        )


def _dataframe_to_json(df: pd.DataFrame) -> str:
    """
    Convert pandas DataFrame to JSON string.
    Handles special data types gracefully.

    Args:
        df: pandas DataFrame

    Returns:
        JSON string representation of the DataFrame

    Raises:
        HTTPException: If conversion fails
    """
    try:
        # Convert to JSON with default handler for non-serializable types
        json_str = df.to_json(orient="records", indent=2)

        # Validate JSON is valid
        json.loads(json_str)

        logger.info(f"DataFrame converted to JSON successfully. Records: {len(df)}")
        return json_str

    except Exception as e:
        logger.exception("Error converting DataFrame to JSON")
        raise HTTPException(
            status_code=500,
            detail=f"Error converting table to JSON: {str(e)}"
        )


async def process_upload_file(upload_file: UploadFile) -> Tuple[str, int, int]:
    """
    Process uploaded file (CSV or Excel) and convert to JSON.

    Args:
        upload_file: FastAPI UploadFile object

    Returns:
        Tuple of (table_json, num_rows, num_columns)

    Raises:
        HTTPException: If file processing fails
    """
    try:
        # Validate file extension
        ext = _validate_file_extension(upload_file.filename)

        # Read file content
        file_content = await upload_file.read()

        if not file_content:
            raise HTTPException(
                status_code=400,
                detail="Uploaded file is empty"
            )

        logger.info(f"Processing {ext} file: {upload_file.filename}")

        # Process based on file type
        if ext in ALLOWED_CSV_EXTENSIONS:
            df = await process_csv_file(file_content)
        elif ext in ALLOWED_EXCEL_EXTENSIONS:
            df = await process_excel_file(file_content)
        else:
            raise HTTPException(
                status_code=400,
                detail=f"Unsupported file type: {ext}"
            )

        # Convert to JSON
        table_json = _dataframe_to_json(df)

        # Return JSON and dimensions
        return table_json, len(df), len(df.columns)

    except HTTPException:
        raise
    except Exception as e:
        logger.exception(f"Error processing uploaded file '{upload_file.filename}'")
        raise HTTPException(
            status_code=500,
            detail=f"Error processing file: {str(e)}"
        )
