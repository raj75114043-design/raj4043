"""
SQL Agent – LangGraph graph assembly and public entry point.
The graph starts at fetch_world_view; parallel search is done
externally (by the endpoint / service) and passed in as initial state.
"""

import logging
from langgraph.graph import END, StateGraph

from .state import AgentState
from .nodes import (
    fetch_world_view,
    distill_context,
    generate_sql,
    generate_sql_followup,
    execute_sql,
    format_output,
    route_followup,
    should_retry,
)

logger = logging.getLogger(__name__)


# ── Graph assembly ────────────────────────────────────────────────

def build_graph():
    g = StateGraph(AgentState)

    # Nodes
    g.add_node("fetch_world_view", fetch_world_view)
    g.add_node("distill_context", distill_context)
    g.add_node("generate_sql", generate_sql)
    g.add_node("generate_sql_followup", generate_sql_followup)
    g.add_node("execute_sql", execute_sql)
    g.add_node("format_output", format_output)

    # Edges
    g.set_entry_point("fetch_world_view")
    g.add_edge("fetch_world_view", "distill_context")

    # Branch: follow-up vs normal
    g.add_conditional_edges(
        "distill_context",
        route_followup,
        {
            "normal": "generate_sql",
            "followup": "generate_sql_followup",
        },
    )

    g.add_edge("generate_sql", "execute_sql")
    g.add_edge("generate_sql_followup", "execute_sql")

    g.add_conditional_edges(
        "execute_sql",
        should_retry,
        {
            "success": "format_output",
            "retry": "generate_sql",
            "max_retries": "format_output",
        },
    )

    g.add_edge("format_output", END)

    return g.compile()


graph = build_graph()


# ── Public entry point ────────────────────────────────────────────

async def run_sql_agent(
    user_query: str,
    keyword_names: list[str] | None = None,
    kpi_names: list[str] | None = None,
    qb_names: list[str] | None = None,
    is_follow_up: bool = False,
    previous_user_query: str = "",
    previous_clarifying_message: str = "",
    previous_generated_sql: str = "",
) -> dict:
    """
    Run the text-to-SQL pipeline for a natural language question.

    The caller is responsible for running parallel search beforehand
    and passing keyword_names, kpi_names, qb_names into this function.
    Any of these may be None or empty if the search returned no results.

    For follow-up queries (Scenario 2 follow-ups), pass is_follow_up=True
    along with previous_user_query, previous_clarifying_message, and
    previous_generated_sql to provide conversation context to the SQL generator.

    Returns dict with keys:
      - success: bool
      - query: the user question
      - generated_sql: final SQL
      - result_df: pandas DataFrame (or None)
      - retries: number of SQL retries used
      - error: last error message if failed
      - context: distilled world-view context (toon-encoded string)
      - node_timestamps: per-node timing breakdown
    """
    initial_state: AgentState = {
        "user_query": user_query,
        "keyword_names": keyword_names or [],
        "kpi_names": kpi_names or [],
        "qb_names": qb_names or [],
        "is_follow_up": is_follow_up,
        "previous_user_query": previous_user_query,
        "previous_clarifying_message": previous_clarifying_message,
        "previous_generated_sql": previous_generated_sql,
        "raw_world_view": {},
        "context": "",
        "generated_sql": "",
        "sql_error": "",
        "retry_count": 0,
        "result_df": None,
        "final_status": "",
        "node_timestamps": {},
    }

    try:
        logger.info(f"Starting SQL agent for query: {user_query[:100]}")
        final_state = await graph.ainvoke(initial_state)

        logger.info(f"SQL agent completed with status: {final_state.get('final_status', 'unknown')}")
        return {
            "success": final_state["final_status"] == "success",
            "query": user_query,
            "generated_sql": final_state["generated_sql"],
            "result_df": final_state["result_df"],
            "retries": final_state.get("retry_count", 0),
            "error": final_state.get("sql_error", ""),
            "context": final_state.get("context", ""),
            "node_timestamps": final_state.get("node_timestamps", {}),
        }
    except Exception as exc:
        logger.error(f"SQL agent execution failed: {str(exc)}", exc_info=True)
        return {
            "success": False,
            "query": user_query,
            "generated_sql": "",
            "result_df": None,
            "retries": 0,
            "error": f"SQL agent failed: {str(exc)}",
            "context": "",
            "node_timestamps": {},
        }
