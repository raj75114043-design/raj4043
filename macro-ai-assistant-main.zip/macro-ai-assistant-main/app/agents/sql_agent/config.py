"""
SQL Agent – Configuration
All values sourced from app.core.config.settings (loaded from .env).
"""

from langchain_openai import ChatOpenAI
from app.core.config import settings

# ── Database (asyncpg direct connection for SQL execution) ────────

DB_CONFIG = {
    "host": settings.db_host,
    "port": settings.db_port,
    "user": settings.db_user,
    "password": settings.db_password,
    "database": settings.db_name,
    "server_settings": {"search_path": f"{settings.db_schema_staging},public"},
}

# ── External API endpoints (Global Context Layer) ─────────────────

SCHEMA_WORLD_VIEW_API = settings.schema_world_view_api
WORLD_VIEW_AUTH = ("Any_string", settings.world_view_auth_password)

# ── Retry budget ──────────────────────────────────────────────────

MAX_SQL_RETRIES = 3

# ── LLM ───────────────────────────────────────────────────────────

llm = ChatOpenAI(
    api_key="NONE",
    model="gpt-5-mini",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
    reasoning_effort="medium",
    timeout= 360,  
)
