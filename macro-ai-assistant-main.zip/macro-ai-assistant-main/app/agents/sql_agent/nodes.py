"""
SQL Agent – LangGraph node functions.
Each function receives AgentState and returns a partial state update dict.
"""

import logging
import time
from datetime import datetime, timezone

import asyncpg
import httpx
import pandas as pd
from langchain_core.output_parsers import JsonOutputParser, StrOutputParser
from langchain_core.prompts import PromptTemplate
from toon import encode

from app.services.world_view_utils import build_text2sql_context
from .config import DB_CONFIG, SCHEMA_WORLD_VIEW_API, WORLD_VIEW_AUTH, MAX_SQL_RETRIES, llm
from .prompts import SQL_GENERATION_PROMPT, SQL_RETRY_PROMPT, SQL_FOLLOWUP_PROMPT, SQLGeneration
from .state import AgentState

logger = logging.getLogger(__name__)


# ── Timestamp helpers ─────────────────────────────────────────────

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def _merge_timestamps(existing: dict, node_name: str, start: str, end: str, duration: float) -> dict:
    """Return a new dict with the node entry added (avoids mutating state)."""
    updated = {**existing}
    updated[node_name] = {"start": start, "end": end, "duration_s": round(duration, 3)}
    return updated


# ── Node: fetch_world_view ────────────────────────────────────────

async def fetch_world_view(state: AgentState) -> dict:
    """Call schema-world-view endpoint with the pre-fetched search results."""
    t_start, iso_start = time.perf_counter(), _now_iso()

    payload = {
        "kpi_names": state["kpi_names"],
        "question_texts": state["qb_names"],
        "keyword_names": state["keyword_names"],
    }

    try:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                SCHEMA_WORLD_VIEW_API,
                json=payload,
                headers={
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                },
                auth=WORLD_VIEW_AUTH,
                timeout=30,
            )
            resp.raise_for_status()
            data = resp.json()

        logger.info("World-view context fetched successfully")
        duration = time.perf_counter() - t_start
        return {
            "raw_world_view": data,
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), "fetch_world_view", iso_start, _now_iso(), duration
            ),
        }
    except Exception as exc:
        logger.error(f"Failed to fetch world-view context: {exc}", exc_info=True)
        raise


# ── Node: distill_context ────────────────────────────────────────

async def distill_context(state: AgentState) -> dict:
    """Apply build_text2sql_context to strip noise, then toon-encode to string."""
    t_start, iso_start = time.perf_counter(), _now_iso()

    try:
        context = build_text2sql_context(state["raw_world_view"])
        context = encode(context)

        logger.info(f"Context distilled successfully: {len(context)} chars")

        duration = time.perf_counter() - t_start
        return {
            "context": context,
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), "distill_context", iso_start, _now_iso(), duration
            ),
        }
    except Exception as exc:
        logger.error(f"Failed to distill context: {exc}", exc_info=True)
        raise


# ── Helper: extract schema name ──────────────────────────────────

def _extract_schema_name(raw_world_view: dict) -> str:
    """Pull schema_name from the raw world-view response."""
    wv = raw_world_view.get("world_view") or raw_world_view
    return wv.get("schema_name") or "pwc_macro_staging_schema"


# ── Node: generate_sql ───────────────────────────────────────────

async def generate_sql(state: AgentState) -> dict:
    """Generate SQL from the distilled context (or fix a previous error)."""
    t_start, iso_start = time.perf_counter(), _now_iso()

    context_str = state["context"]
    schema = _extract_schema_name(state.get("raw_world_view", {}))

    try:
        parser = JsonOutputParser(pydantic_object=SQLGeneration)
        format_instructions = parser.get_format_instructions()

        if state.get("sql_error") and state.get("generated_sql"):
            # Retry path
            prompt = PromptTemplate(
                template=SQL_RETRY_PROMPT,
                input_variables=["schema_name", "context_str", "error", "sql"],
                partial_variables={"format": format_instructions},
            )
            chain = prompt | llm | StrOutputParser() | parser
            logger.debug(f"Retrying SQL generation (attempt {state.get('retry_count', 0) + 1})")
            result = await chain.ainvoke({
                "schema_name": schema,
                "context_str": context_str,
                "error": state["sql_error"],
                "sql": state["generated_sql"],
            })
        else:
            # First attempt
            prompt = PromptTemplate(
                template=SQL_GENERATION_PROMPT,
                input_variables=["schema_name", "context_str", "user_query"],
                partial_variables={"format": format_instructions},
            )
            chain = prompt | llm | StrOutputParser() | parser
            logger.info("Generating SQL from context")
            result = await chain.ainvoke({
                "schema_name": schema,
                "context_str": context_str,
                "user_query": state["user_query"],
            })

        sql = result["sql_code"].strip()

        # Strip markdown fences if the LLM wraps them
        if sql.startswith("```"):
            sql = "\n".join(sql.split("\n")[1:])
        if sql.endswith("```"):
            sql = "\n".join(sql.split("\n")[:-1])
        sql = sql.strip()

        logger.info(f"SQL generation successful: {len(sql)} chars")

        duration = time.perf_counter() - t_start
        retry_count = state.get("retry_count", 0)
        node_label = "generate_sql" if retry_count == 0 else f"generate_sql_retry_{retry_count}"
        return {
            "generated_sql": sql,
            "sql_error": "",
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), node_label, iso_start, _now_iso(), duration
            ),
        }
    except Exception as exc:
        duration = time.perf_counter() - t_start
        retry_count = state.get("retry_count", 0)
        node_label = f"generate_sql_fail_{retry_count}"
        error_msg = str(exc)

        logger.error(f"SQL generation failed (attempt {retry_count}): {error_msg}", exc_info=True)

        return {
            "generated_sql": "",
            "sql_error": error_msg,
            "retry_count": retry_count + 1,
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), node_label, iso_start, _now_iso(), duration
            ),
        }


# ── Node: execute_sql ────────────────────────────────────────────

async def execute_sql(state: AgentState) -> dict:
    """Run the generated SQL against PostgreSQL via asyncpg, return a DataFrame."""
    t_start, iso_start = time.perf_counter(), _now_iso()
    sql = state["generated_sql"]

    try:
        if not sql or sql.strip() == "":
            raise ValueError("No SQL query generated")

        logger.debug(f"Executing SQL: {sql[:200]}...")
        conn = await asyncpg.connect(**DB_CONFIG)
        try:
            rows = await conn.fetch(sql)
            if rows:
                columns = list(rows[0].keys())
                df = pd.DataFrame([dict(r) for r in rows], columns=columns)
            else:
                df = pd.DataFrame()
        finally:
            await conn.close()

        logger.info(f"SQL executed successfully: {len(rows) if rows else 0} rows returned")
        duration = time.perf_counter() - t_start
        retry_count = state.get("retry_count", 0)
        node_label = "execute_sql" if retry_count == 0 else f"execute_sql_retry_{retry_count}"
        return {
            "result_df": df,
            "sql_error": "",
            "final_status": "success",
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), node_label, iso_start, _now_iso(), duration
            ),
        }
    except Exception as exc:
        duration = time.perf_counter() - t_start
        retry_count = state.get("retry_count", 0)
        node_label = f"execute_sql_fail_{retry_count}"
        error_msg = str(exc)
        logger.error(f"SQL execution failed (attempt {retry_count}): {error_msg}", exc_info=True)
        return {
            "result_df": None,
            "sql_error": error_msg,
            "retry_count": retry_count + 1,
            "final_status": "error",
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), node_label, iso_start, _now_iso(), duration
            ),
        }


# ── Node: format_output ──────────────────────────────────────────

async def format_output(state: AgentState) -> dict:
    """Terminal node — nothing to transform, df is already on state."""
    iso_now = _now_iso()
    return {
        "node_timestamps": _merge_timestamps(
            state.get("node_timestamps", {}), "format_output", iso_now, iso_now, 0.0
        ),
    }


# ── Node: generate_sql_followup ──────────────────────────────────

async def generate_sql_followup(state: AgentState) -> dict:
    """Generate SQL for a follow-up query with full previous conversation context."""
    t_start, iso_start = time.perf_counter(), _now_iso()

    schema = _extract_schema_name(state.get("raw_world_view", {}))

    try:
        parser = JsonOutputParser(pydantic_object=SQLGeneration)
        format_instructions = parser.get_format_instructions()

        prompt = PromptTemplate(
            template=SQL_FOLLOWUP_PROMPT,
            input_variables=[
                "schema_name", "context_str", "user_query",
                "previous_user_query", "previous_clarifying_message", "previous_generated_sql",
            ],
            partial_variables={"format": format_instructions},
        )
        chain = prompt | llm | StrOutputParser() | parser
        logger.debug("Generating follow-up SQL")
        result = await chain.ainvoke({
            "schema_name": schema,
            "context_str": state["context"],
            "user_query": state["user_query"],
            "previous_user_query": state.get("previous_user_query", ""),
            "previous_clarifying_message": state.get("previous_clarifying_message", ""),
            "previous_generated_sql": state.get("previous_generated_sql", "None"),
        })

        sql = result["sql_code"].strip()

        # Strip markdown fences if present
        if sql.startswith("```"):
            sql = "\n".join(sql.split("\n")[1:])
        if sql.endswith("```"):
            sql = "\n".join(sql.split("\n")[:-1])
        sql = sql.strip()

        logger.info(f"Follow-up SQL generation successful: {len(sql)} chars")

        duration = time.perf_counter() - t_start
        return {
            "generated_sql": sql,
            "sql_error": "",
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), "generate_sql_followup", iso_start, _now_iso(), duration
            ),
        }
    except Exception as exc:
        duration = time.perf_counter() - t_start
        error_msg = str(exc)
        logger.error(f"Follow-up SQL generation failed: {error_msg}", exc_info=True)

        return {
            "generated_sql": "",
            "sql_error": error_msg,
            "retry_count": 1,
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), "generate_sql_followup_fail", iso_start, _now_iso(), duration
            ),
        }


# ── Conditional edge ─────────────────────────────────────────────

def route_followup(state: AgentState) -> str:
    """After distill_context: route to follow-up SQL generation or standard generation."""
    if state.get("is_follow_up"):
        return "followup"
    return "normal"


def should_retry(state: AgentState) -> str:
    if not state.get("sql_error"):
        return "success"
    if state.get("retry_count", 0) >= MAX_SQL_RETRIES:
        return "max_retries"
    return "retry"
