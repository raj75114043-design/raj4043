"""
SQL Agent – State definition for the LangGraph flow.
"""

from typing import Any, TypedDict


class AgentState(TypedDict):
    user_query: str
    # parallel search results (pre-fetched by the endpoint, passed in)
    keyword_names: list[str]
    kpi_names: list[str]
    qb_names: list[str]
    # follow-up context (for handling clarification follow-ups)
    is_follow_up: bool
    previous_user_query: str
    previous_clarifying_message: str
    previous_generated_sql: str
    # world view
    raw_world_view: dict
    context: str
    # sql generation / execution
    generated_sql: str
    sql_error: str
    retry_count: int
    # final output
    result_df: Any
    final_status: str
    # per-node timing
    node_timestamps: dict
