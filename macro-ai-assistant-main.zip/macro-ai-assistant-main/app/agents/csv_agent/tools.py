"""
CSV Agent Tools

Contains tools for code execution and DataFrame processing.
Based on: tools/new_df_agent.py
"""

import re
import json
import warnings
import pandas as pd
import numpy as np
from typing import List, Tuple, Dict, Any
from ast import literal_eval

try:
    from langchain_experimental.utilities import PythonREPL
except ImportError:
    PythonREPL = None


def strip_think_and_nonjson(text: str) -> str:
    """Remove <think>...</think> and text before first '{'"""
    if hasattr(text, "content"):
        text = text.content
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)
    text = text.strip()
    first_brace = text.find('{')
    if first_brace != -1:
        return text[first_brace:]
    return text


def parse_partial_json(json_str: str) -> Dict[str, Any]:
    """Parse JSON string with error recovery"""
    json_str = re.sub(r"<think>.*?</think>", "", json_str, flags=re.DOTALL)
    json_str = json_str.strip()
    first_brace = json_str.find('{')
    last_brace = json_str.rfind('}')
    if first_brace != -1 and last_brace != -1:
        json_str = json_str[first_brace:last_brace+1]
    json_str = re.sub(r',\s*([}\]])', r'\1', json_str)
    try:
        return json.loads(json_str)
    except json.JSONDecodeError:
        if not json_str.endswith('}'):
            json_str += '}'
        try:
            return json.loads(json_str)
        except Exception as e:
            try:
                return literal_eval(json_str)
            except Exception:
                raise e


def safe_parse_json(possible_json: Any) -> Dict[str, Any]:
    """Safely parse JSON from various input types"""
    if isinstance(possible_json, dict):
        return possible_json
    elif isinstance(possible_json, str):
        return parse_partial_json(possible_json)
    else:
        raise ValueError("Input must be a dict or str")


def process_dataframes(df_list: List[pd.DataFrame]) -> Tuple:
    """Process list of dataframes into df_1 to df_10"""
    if len(df_list) > 10:
        warnings.warn(f"Only first 10 of {len(df_list)} dataframes will be used")
        df_list = df_list[:10]

    # Initialize empty dataframes
    df_1 = df_2 = df_3 = df_4 = df_5 = pd.DataFrame()
    df_6 = df_7 = df_8 = df_9 = df_10 = pd.DataFrame()
    result_df = pd.DataFrame()

    # Assign available dataframes
    if len(df_list) >= 1: df_1 = df_list[0]
    if len(df_list) >= 2: df_2 = df_list[1]
    if len(df_list) >= 3: df_3 = df_list[2]
    if len(df_list) >= 4: df_4 = df_list[3]
    if len(df_list) >= 5: df_5 = df_list[4]
    if len(df_list) >= 6: df_6 = df_list[5]
    if len(df_list) >= 7: df_7 = df_list[6]
    if len(df_list) >= 8: df_8 = df_list[7]
    if len(df_list) >= 9: df_9 = df_list[8]
    if len(df_list) >= 10: df_10 = df_list[9]

    my_globals = {
        "df_1": df_1, "df_2": df_2, "df_3": df_3, "df_4": df_4, "df_5": df_5,
        "df_6": df_6, "df_7": df_7, "df_8": df_8, "df_9": df_9, "df_10": df_10,
        "result_df": result_df
    }

    return df_1, df_2, df_3, df_4, df_5, df_6, df_7, df_8, df_9, df_10, result_df, my_globals


def python_repl_tool(df_list: List[pd.DataFrame], code: str) -> Tuple[str, pd.DataFrame, str]:
    """Execute Python code using Python REPL"""
    print('\nREPL tool is called\n')

    df_error_msg = ""
    result_df = pd.DataFrame()
    output_text = ""

    try:
        df_1, df_2, df_3, df_4, df_5, df_6, df_7, df_8, df_9, df_10, result_df, my_globals = process_dataframes(df_list)

        if PythonREPL is None:
            raise ImportError("PythonREPL not available")

        python_repl = PythonREPL(_globals=my_globals)

        try:
            output_text = python_repl.run(code)
            if 'result_df' in python_repl.locals:
                result_df = python_repl.locals['result_df']
                print(f"\nResult DataFrame:\n{result_df}\n")
        except Exception as e:
            df_error_msg = f"Error executing code: {str(e)}"

        # Check for error indicators
        error_keywords = ["error", "exception", "traceback", "failed", "invalid"]
        if any(kw.lower() in output_text.lower() for kw in error_keywords):
            error_lines = [
                line.strip() for line in output_text.split('\n')
                if any(kw.lower() in line.lower() for kw in error_keywords)
            ]
            if error_lines:
                df_error_msg = " | ".join(error_lines)
            else:
                df_error_msg = "Unknown error detected"

        # Check result quality
        if isinstance(result_df, pd.DataFrame):
            if result_df.empty:
                df_error_msg = "Resulting dataframe is empty"
            else:
                numeric_cols = result_df.select_dtypes(include=["number"]).columns
                if len(numeric_cols) > 0 and all(result_df[col].isna().all() for col in numeric_cols):
                    df_error_msg = "All numeric columns are NA"

    except Exception as e:
        df_error_msg = str(e)

    return output_text, result_df, df_error_msg


def eda_summary(df: pd.DataFrame, categorical_threshold: int = 10, sample_size: int = 5) -> str:
    """Generate EDA summary for DataFrame"""
    output = []

    # Schema
    output.append("SCHEMA:")
    for col in df.columns:
        null_count = df[col].isna().sum()
        null_pct = null_count / len(df) * 100 if len(df) > 0 else 0
        try:
            unique_count = df[col].nunique()
        except TypeError:
            unique_count = "unhashable"
        output.append(f"{col}: {df[col].dtype} | Nulls: {null_count} ({null_pct:.1f}%) | Unique: {unique_count}")

    # Head/tail
    output.append(f"\nHEAD ({sample_size} rows):\n{df.head(sample_size).to_string()}")
    output.append(f"\nTAIL ({sample_size} rows):\n{df.tail(sample_size).to_string()}")

    # Numeric stats
    numeric_cols = df.select_dtypes(include=np.number).columns.tolist()
    if numeric_cols:
        output.append(f"\nNUMERIC STATISTICS:\n{df[numeric_cols].describe().to_string()}")

    # Categorical
    cat_cols = [col for col in df.columns if df[col].dtype == 'object' or df[col].nunique() <= categorical_threshold]
    if cat_cols:
        output.append("\nCATEGORICAL COLUMNS:")
        for col in cat_cols[:3]:  # Limit to 3 to avoid huge output
            output.append(f"\n{col} - Top 5:\n{df[col].value_counts().head(5).to_string()}")

    return "\n".join(output)
