"""
CSV Agent Module

Complete CSV/DataFrame analysis agent based on LangGraph.
Based on: tools/new_df_agent.py

Usage:
    from app.agents.csv_agent import CSVAgent, create_initial_state

    # Create agent
    agent = CSVAgent()

    # Create initial state
    state = create_initial_state(
        user_query="What are the top 10 products by sales?",
        dataframes=[df],
        schema=eda_summary(df),
        chat_history="",
        user_context=""
    )

    # Invoke agent
    result = agent.invoke(state)

    # Get results
    output_df = result["output_df"][-1]
    output_text = result["output_data"][-1]
    python_code = result["python_output"][-1]
    text_explanation = result["text_explanation"][-1]  # NEW
    agent_steps = result["agent_steps_explanation"][-1]  # NEW
"""

from app.agents.csv_agent.state import CSVAgentState, create_initial_state
from app.agents.csv_agent.graph import CSVAgent, create_csv_agent_workflow
from app.agents.csv_agent.config import CSVAgentConfig, get_csv_agent_config
from app.agents.csv_agent.tools import eda_summary, python_repl_tool
from app.agents.csv_agent.nodes import (
    text_final_output,
    generate_text_explanation_node,
    generate_agent_steps_explanation_node,
    parallel_explanations_node_sync
)

__all__ = [
    # Main agent
    "CSVAgent",
    "create_csv_agent_workflow",

    # State management
    "CSVAgentState",
    "create_initial_state",

    # Configuration
    "CSVAgentConfig",
    "get_csv_agent_config",

    # Utilities
    "eda_summary",
    "python_repl_tool",
    "text_final_output",

    # Explanation nodes
    "generate_text_explanation_node",
    "generate_agent_steps_explanation_node",
    "parallel_explanations_node_sync",
]
