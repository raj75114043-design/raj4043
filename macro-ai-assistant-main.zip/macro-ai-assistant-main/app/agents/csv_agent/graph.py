"""
CSV Agent Graph

Defines the LangGraph workflow for CSV/DataFrame analysis.
Based on: tools/new_df_agent.py (lines 533-556)
"""

from typing import Optional
from app.agents.csv_agent.state import CSVAgentState
from app.agents.csv_agent.nodes import (
    python_generate,
    final_output,
    feedback_decider,
    parallel_explanations_node  # ASYNC VERSION for true parallel execution
)

try:
    from langgraph.graph import StateGraph, START, END
except ImportError:
    # Fallback for development
    StateGraph = None
    START = "START"
    END = "END"


def create_csv_agent_workflow():
    """
    Create the CSV agent workflow graph with parallel explanations.

    NEW Workflow:
    1. START → python_generator
    2. python_generator → executor
    3. executor → feedback_decider (conditional)
        - If error and retries < 3: go back to python_generator
        - If no error or max retries: parallel_explanations
    4. parallel_explanations → END
       - Runs text_explanation and agent_steps_explanation in PARALLEL

    Based on: tools/new_df_agent.py + tools/agent_steps_explain.py
    """
    if StateGraph is None:
        raise ImportError("langgraph package not installed")

    workflow = StateGraph(CSVAgentState)

    # Add nodes
    workflow.add_node("python_generator", python_generate)
    workflow.add_node("executor", final_output)
    workflow.add_node("parallel_explanations", parallel_explanations_node)

    # Add edges
    workflow.add_edge(START, "python_generator")
    workflow.add_edge("python_generator", "executor")

    # Add conditional edge for feedback loop
    workflow.add_conditional_edges(
        "executor",
        feedback_decider,
        {
            True: "python_generator",  # Retry if error
            False: "parallel_explanations"  # Generate explanations if success
        }
    )

    # After parallel explanations, go to END
    workflow.add_edge("parallel_explanations", END)

    return workflow.compile()


class CSVAgent:
    """
    CSV Agent wrapper for easy invocation.
    
    Usage:
        agent = CSVAgent()
        result = agent.invoke(user_query, dataframes, schema)
    """

    def __init__(self):
        """Initialize CSV agent with compiled workflow"""
        self.workflow = create_csv_agent_workflow()

    def invoke(self, state: CSVAgentState, config: Optional[dict] = None) -> CSVAgentState:
        """
        Invoke the CSV agent workflow.
        
        Args:
            state: Initial CSVAgentState
            config: Optional configuration dict
            
        Returns:
            Final CSVAgentState with results
        """
        if not self.workflow:
            raise RuntimeError("Workflow not initialized")

        result = self.workflow.invoke(state, config=config)
        return result

    async def ainvoke(self, state: CSVAgentState, config: Optional[dict] = None) -> CSVAgentState:
        """
        Async invoke the CSV agent workflow.
        
        Args:
            state: Initial CSVAgentState
            config: Optional configuration dict
            
        Returns:
            Final CSVAgentState with results
        """
        if not self.workflow:
            raise RuntimeError("Workflow not initialized")

        result = await self.workflow.ainvoke(state, config=config)
        return result
