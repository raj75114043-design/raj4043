"""
CSV Agent Configuration

Configuration settings for the CSV/DataFrame analysis agent.
"""

from typing import Optional
from pydantic import BaseModel, Field


class CSVAgentConfig(BaseModel):
    """Configuration for CSV Agent"""

    # LLM Settings
    llm_model: str = Field(default="openai/gpt-oss-120b", description="LLM model to use")
    llm_temperature: float = Field(default=0.0, description="LLM temperature")
    llm_provider: str = Field(default="groq", description="LLM provider (groq, openai, azure)")

    # Execution Settings
    max_retries: int = Field(default=2, description="Maximum code generation retries on error")
    execution_timeout: int = Field(default=30, description="Code execution timeout in seconds")

    # DataFrame Settings
    max_dataframes: int = Field(default=10, description="Maximum number of dataframes to process")
    max_output_rows: int = Field(default=200, description="Maximum rows in output dataframe")

    # EDA Settings
    eda_sample_size: int = Field(default=5, description="Number of rows for head/tail in EDA")
    eda_categorical_threshold: int = Field(default=10, description="Threshold for categorical columns")
    eda_include_correlation: bool = Field(default=True, description="Include correlation matrix in EDA")

    # Output Settings
    generate_text_explanation: bool = Field(default=True, description="Generate text explanation of results")
    include_code_in_response: bool = Field(default=True, description="Include generated code in response")

    # Safety Settings
    allow_imports: bool = Field(default=True, description="Allow import statements in generated code")
    sandbox_execution: bool = Field(default=True, description="Execute code in sandboxed environment")

    class Config:
        frozen = False


# Default configuration instance
DEFAULT_CSV_AGENT_CONFIG = CSVAgentConfig()


def get_csv_agent_config() -> CSVAgentConfig:
    """Get default CSV agent configuration"""
    return DEFAULT_CSV_AGENT_CONFIG
