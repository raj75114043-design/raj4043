"""
CSV Agent State Definition

Defines the LangGraph state for DataFrame/CSV analysis agent.
Based on: tools/new_df_agent.py

Workflow:
1. Input: user_query + df + full_schema + chat_history + user_provided_context
2. Node: python_generate → Generates Python code to answer query
3. Node: executor (final_output) → Executes code and captures result_df
4. Conditional: feedback_decider → Check if error exists (max 2 retries)
5. If error: Loop back to python_generate with error message
6. If no error or max retries: END
"""

from typing import TypedDict, List, Annotated, Any
import operator
import pandas as pd

# Note: These imports will be available when langchain packages are installed
try:
    from langchain_core.messages import AnyMessage
    from langgraph.graph.message import add_messages
except ImportError:
    # Fallback types for development without langchain installed
    AnyMessage = Any

    def add_messages(left: List[Any], right: List[Any]) -> List[Any]:
        """Fallback implementation of add_messages"""
        return left + right


class CSVAgentState(TypedDict):
    """
    State for CSV/DataFrame analysis agent.

    Exactly matches the State from tools/new_df_agent.py
    """

    # Input State Variables
    user_query: Annotated[List[AnyMessage], add_messages]
    """User's natural language query about the data"""

    user_provided_context: Annotated[List[AnyMessage], add_messages]
    """Additional context provided by user"""

    df: List[pd.DataFrame]
    """List of pandas DataFrames to analyze (max 10: df_1 to df_10)"""

    full_schema: Annotated[List[AnyMessage], add_messages]
    """Schema information for all dataframes (from eda_summary)"""

    chat_history: Annotated[List[AnyMessage], add_messages]
    """Previous conversation context (max 3 items from chat memory)"""

    # Agentic Workflow State Variables
    python_output: Annotated[List[AnyMessage], operator.add]
    """Generated Python code (latest is used for execution)"""

    # Agentic Output State Variables
    tool_error: Annotated[List[AnyMessage], operator.add]
    """Error messages from code execution (used for retry logic)"""

    output_df: Annotated[List[pd.DataFrame], operator.add]
    """Resulting DataFrames from code execution (result_df)"""

    output_data: Annotated[List[AnyMessage], add_messages]
    """Raw output text from print(result_df)"""

    # Final Explanations (Generated in Parallel)
    text_explanation: Annotated[List[AnyMessage], add_messages]
    """Natural language explanation of analysis results"""

    agent_steps_explanation: Annotated[List[AnyMessage], add_messages]
    """Business-friendly explanation of agent workflow steps"""


def create_initial_state(
    user_query: str,
    dataframes: List[pd.DataFrame],
    schema: str,
    chat_history: str = "",
    user_context: str = "",
) -> CSVAgentState:
    """
    Create initial state for CSV agent.

    Args:
        user_query: User's question
        dataframes: List of DataFrames to analyze
        schema: Schema information
        chat_history: Previous conversation
        user_context: Additional user-provided context

    Returns:
        Initial CSVAgentState
    """
    try:
        from langchain_core.messages import HumanMessage
        return {
            "user_query": [HumanMessage(content=user_query)],
            "user_provided_context": [HumanMessage(content=user_context)],
            "df": dataframes,
            "full_schema": [HumanMessage(content=schema)],
            "chat_history": [HumanMessage(content=chat_history)],
            "python_output": [],
            "tool_error": [],
            "output_df": [],
            "output_data": [],
            "text_explanation": [],
            "agent_steps_explanation": []
        }
    except ImportError:
        # Fallback for development without langchain
        return {
            "user_query": [{"content": user_query}],
            "user_provided_context": [{"content": user_context}],
            "df": dataframes,
            "full_schema": [{"content": schema}],
            "chat_history": [{"content": chat_history}],
            "python_output": [],
            "tool_error": [],
            "output_df": [],
            "output_data": [],
            "text_explanation": [],
            "agent_steps_explanation": []
        }
