"""
HITL Agent – LangGraph graph assembly and public entry point.

Flow:
  1. classify_query  → data question vs general/chitchat
  2a. general        → handle_general → END
  2b. data           → validate_question → passthrough / return_clarification → END

Parallel search is done externally (by the endpoint / service) and passed
in as initial state — the graph no longer contains a parallel_search node.
"""

from langgraph.graph import END, StateGraph

from .state import HITLState
from .nodes import (
    classify_query,
    handle_general,
    validate_question,
    passthrough,
    return_clarification,
    route_query_type,
    route_validation,
)


# ── Graph assembly ────────────────────────────────────────────────

def build_hitl_graph():
    g = StateGraph(HITLState)

    # Nodes
    g.add_node("classify_query", classify_query)
    g.add_node("handle_general", handle_general)
    g.add_node("validate_question", validate_question)
    g.add_node("passthrough", passthrough)
    g.add_node("return_clarification", return_clarification)

    # Entry
    g.set_entry_point("classify_query")

    # Route: general vs data
    g.add_conditional_edges(
        "classify_query",
        route_query_type,
        {
            "general": "handle_general",
            "data": "validate_question",
        },
    )

    # General → END
    g.add_edge("handle_general", END)

    # Route: valid vs needs clarification
    g.add_conditional_edges(
        "validate_question",
        route_validation,
        {
            "valid": "passthrough",
            "clarify": "return_clarification",
        },
    )

    # Terminal → END
    g.add_edge("passthrough", END)
    g.add_edge("return_clarification", END)

    return g.compile()


hitl_graph = build_hitl_graph()


# ── Public entry point ────────────────────────────────────────────

async def run_hitl_agent(
    user_query: str,
    keyword_results: list[dict] | None = None,
    kpi_results: list[dict] | None = None,
    qb_results: list[dict] | None = None,
    keyword_names: list[str] | None = None,
    kpi_names: list[str] | None = None,
    qb_questions: list[str] | None = None,
    is_follow_up: bool = False,
    previous_user_query: str = "",
    previous_clarifying_message: str = "",
) -> dict:
    """
    Run the human-in-the-loop validation pipeline.

    The caller is responsible for running parallel search beforehand
    and passing the results into this function. For general queries
    (chitchat, greetings) the search results are ignored.

    Returns dict with keys:
      - query: the original user question
      - query_type: "data" | "general"
      - ready_for_sql: bool — True if the question should go to text-to-SQL
      - general_response: str — reply if query_type == "general"
      - clarifying_message: str — guidance if data question was invalid
      - keyword_names: list[str] — detected keywords (data path only)
      - kpi_names: list[str] — matched KPI names (data path only)
      - qb_questions: list[str] — similar reference questions (data path only)
      - node_timestamps: per-node timing breakdown
    """
    initial_state: HITLState = {
        "user_query": user_query,
        "is_follow_up": is_follow_up,
        "previous_user_query": previous_user_query,
        "previous_clarifying_message": previous_clarifying_message,
        "query_type": "",
        "general_response": "",
        "keyword_results": keyword_results or [],
        "kpi_results": kpi_results or [],
        "qb_results": qb_results or [],
        "keyword_names": keyword_names or [],
        "kpi_names": kpi_names or [],
        "qb_questions": qb_questions or [],
        "is_valid": False,
        "clarifying_message": "",
        "ready_for_sql": False,
        "node_timestamps": {},
    }

    final = await hitl_graph.ainvoke(initial_state)

    return {
        "query": user_query,
        "query_type": final["query_type"],
        "ready_for_sql": final["ready_for_sql"],
        "general_response": final.get("general_response", ""),
        "clarifying_message": final.get("clarifying_message", ""),
        "keyword_names": final.get("keyword_names", []),
        "kpi_names": final.get("kpi_names", []),
        "qb_questions": final.get("qb_questions", []),
        "node_timestamps": final.get("node_timestamps", {}),
    }
