"""
HITL Agent – State definition for the LangGraph flow.
"""

from typing import TypedDict


class HITLState(TypedDict):
    user_query: str
    # follow-up context (for handling clarification follow-ups)
    is_follow_up: bool
    previous_user_query: str
    previous_clarifying_message: str
    # classification
    query_type: str                # "data" | "general"
    # general-query response
    general_response: str
    # parallel search results (pre-fetched by the endpoint, passed in)
    keyword_results: list[dict]    # full objects from API (name + score)
    kpi_results: list[dict]
    qb_results: list[dict]
    keyword_names: list[str]
    kpi_names: list[str]
    qb_questions: list[str]
    # validation
    is_valid: bool
    clarifying_message: str
    # passthrough flag
    ready_for_sql: bool
    # per-node timing
    node_timestamps: dict
