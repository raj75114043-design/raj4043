"""
HITL Agent – Configuration sourced from app.core.config.settings.
"""

from langchain_openai import ChatOpenAI

from app.core.config import settings


# ── Search API endpoints ──────────────────────────────────────────

KEYWORD_SEARCH_API = settings.keyword_search_api
KPI_SEARCH_API = settings.kpi_search_api
QB_SEARCH_API = settings.qb_search_api

# ── Validation thresholds ─────────────────────────────────────────

MIN_KPI_MATCHES = 1
MIN_TOTAL_MATCHES = 1  # at least 1 hit across KPI + keyword + QB combined

# ── LLM ───────────────────────────────────────────────────────────

llm = ChatOpenAI(
    api_key="NONE",
    model="gpt-5-mini",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
)
