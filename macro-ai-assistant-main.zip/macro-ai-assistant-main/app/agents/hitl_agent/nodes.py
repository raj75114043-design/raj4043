"""
HITL Agent – LangGraph node functions.
Each function receives HITLState and returns a partial state update dict.
"""

import time
from datetime import datetime, timezone

from langchain_core.output_parsers import JsonOutputParser, StrOutputParser
from langchain_core.prompts import PromptTemplate

from .config import llm, MIN_TOTAL_MATCHES
from .prompts import (
    CLASSIFY_PROMPT,
    GENERAL_RESPONSE_PROMPT,
    VALIDATE_PROMPT,
    QueryClassification,
    ValidationResult,
)
from .state import HITLState


# ── Timestamp helpers ─────────────────────────────────────────────

def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def _merge_ts(existing: dict, node: str, start: str, end: str, dur: float) -> dict:
    """Return a new dict with the node entry added (avoids mutating state)."""
    updated = {**existing}
    updated[node] = {"start": start, "end": end, "duration_s": round(dur, 3)}
    return updated


# ── Helper: build previous context string ────────────────────────

def _build_previous_context(state: HITLState) -> str:
    """
    Build a formatted context block for follow-up questions.
    Returns empty string if not a follow-up or fields are empty.
    """
    if not state.get("is_follow_up"):
        return ""

    prev_query = state.get("previous_user_query", "").strip()
    prev_msg = state.get("previous_clarifying_message", "").strip()

    if not prev_query or not prev_msg:
        return ""

    return f"""\
## Previous Conversation Context
**Previous question:** {prev_query}
**Guidance provided:** {prev_msg}
**User's follow-up question below.**

"""


# ── Node: classify_query ──────────────────────────────────────────

async def classify_query(state: HITLState) -> dict:
    """Use the LLM to decide if this is a data question or general chitchat."""
    t_start, iso_start = time.perf_counter(), _now_iso()

    parser = JsonOutputParser(pydantic_object=QueryClassification)
    format_instructions = parser.get_format_instructions()

    # Build context summary for the LLM
    kpi_summary = []
    for r in state.get("kpi_results", []):
        content = r.get("content", {})
        name = content.get("kpi_name", "")
        desc = content.get("description", "")
        score = r.get("score", "")
        kpi_summary.append(f"- {name} (score: {score}): {desc}")

    kpi_text = "\n".join(kpi_summary) if kpi_summary else "None found."

    keyword_summary = []
    for kw in state.get("keyword_results", []):
        name = kw.get("keyword_name", "")
        desc = kw.get("description", "")
        keyword_summary.append(f"- {name}: {desc}")

    keyword_text = "\n".join(keyword_summary) if keyword_summary else "None found."

    qb_summary = []
    for r in state.get("qb_results", []):
        content = r.get("content", {})
        question = content.get("question", "")
        score = r.get("score", "")
        qb_summary.append(f"- \"{question}\" (score: {score})")

    qb_text = "\n".join(qb_summary) if qb_summary else "None found."

    prompt = PromptTemplate(
        template=CLASSIFY_PROMPT,
        input_variables=["user_query", 
                         "previous_context",
                         "kpi_summary",
                         "keyword_summary",
                         "qb_summary"],
        partial_variables={"format": format_instructions},
    )
    chain = prompt | llm | StrOutputParser() | parser
    result = await chain.ainvoke({
        "user_query": state["user_query"],
        "previous_context": _build_previous_context(state),
        "kpi_summary":kpi_text,
        "keyword_summary":keyword_text,
        "qb_summary":qb_text
    })

    query_type = result["query_type"].lower().strip()
    if query_type not in ("data", "general"):
        query_type = "data"  # default to data if unclear

    duration = time.perf_counter() - t_start
    return {
        "query_type": query_type,
        "node_timestamps": _merge_ts(
            state.get("node_timestamps", {}), "classify_query", iso_start, _now_iso(), duration
        ),
    }


# ── Node: handle_general ─────────────────────────────────────────

async def handle_general(state: HITLState) -> dict:
    """Respond to general / chitchat queries directly."""
    t_start, iso_start = time.perf_counter(), _now_iso()

    # Build context summary for the LLM
    kpi_summary = []
    for r in state.get("kpi_results", []):
        content = r.get("content", {})
        name = content.get("kpi_name", "")
        desc = content.get("description", "")
        score = r.get("score", "")
        kpi_summary.append(f"- {name} (score: {score}): {desc}")

    kpi_text = "\n".join(kpi_summary) if kpi_summary else "None found."

    keyword_summary = []
    for kw in state.get("keyword_results", []):
        name = kw.get("keyword_name", "")
        desc = kw.get("description", "")
        keyword_summary.append(f"- {name}: {desc}")

    keyword_text = "\n".join(keyword_summary) if keyword_summary else "None found."

    qb_summary = []
    for r in state.get("qb_results", []):
        content = r.get("content", {})
        question = content.get("question", "")
        score = r.get("score", "")
        qb_summary.append(f"- \"{question}\" (score: {score})")

    qb_text = "\n".join(qb_summary) if qb_summary else "None found."


    prompt = PromptTemplate(
        template=GENERAL_RESPONSE_PROMPT,
        input_variables=["user_query", 
                         "previous_context",
                         "kpi_summary",
                         "keyword_summary",
                         "qb_summary"],)
    
    chain = prompt | llm | StrOutputParser()
    response = await chain.ainvoke({
        "user_query": state["user_query"],
        "previous_context": _build_previous_context(state),
        "kpi_summary":kpi_text,
        "keyword_summary":keyword_text,
        "qb_summary":qb_text
    })

    duration = time.perf_counter() - t_start
    return {
        "general_response": response.strip(),
        "ready_for_sql": False,
        "is_valid": False,
        "node_timestamps": _merge_ts(
            state.get("node_timestamps", {}), "handle_general", iso_start, _now_iso(), duration
        ),
    }


# ── Node: validate_question ──────────────────────────────────────

async def validate_question(state: HITLState) -> dict:
    """Check if the data question is answerable given the search context."""
    t_start, iso_start = time.perf_counter(), _now_iso()

    # Build context summary for the LLM
    kpi_summary = []
    for r in state.get("kpi_results", []):
        content = r.get("content", {})
        name = content.get("kpi_name", "")
        desc = content.get("description", "")
        score = r.get("score", "")
        kpi_summary.append(f"- {name} (score: {score}): {desc}")

    kpi_text = "\n".join(kpi_summary) if kpi_summary else "None found."

    keyword_summary = []
    for kw in state.get("keyword_results", []):
        name = kw.get("keyword_name", "")
        desc = kw.get("description", "")
        keyword_summary.append(f"- {name}: {desc}")

    keyword_text = "\n".join(keyword_summary) if keyword_summary else "None found."

    qb_summary = []
    for r in state.get("qb_results", []):
        content = r.get("content", {})
        question = content.get("question", "")
        score = r.get("score", "")
        qb_summary.append(f"- \"{question}\" (score: {score})")

    qb_text = "\n".join(qb_summary) if qb_summary else "None found."

    parser = JsonOutputParser(pydantic_object=ValidationResult)
    format_instructions = parser.get_format_instructions()

    prompt = PromptTemplate(
        template=VALIDATE_PROMPT,
        input_variables=[
            "user_query",
            "kpi_summary",
            "keyword_summary",
            "qb_summary",
            "previous_context",
        ],
        partial_variables={"format": format_instructions},
    )
    chain = prompt | llm | StrOutputParser() | parser
    result = await chain.ainvoke({
        "user_query": state["user_query"],
        "kpi_summary": kpi_text,
        "keyword_summary": keyword_text,
        "qb_summary": qb_text,
        "previous_context": _build_previous_context(state),
    })

    is_valid = result.get("is_valid", False)
    clarifying_message = result.get("clarifying_message", "")

    # Enforce a hard minimum: if zero results came back, it's invalid
    total_matches = (
        len(state.get("kpi_names", []))
        + len(state.get("keyword_names", []))
        + len(state.get("qb_questions", []))
    )
    if total_matches < MIN_TOTAL_MATCHES:
        is_valid = False
        if not clarifying_message:
            clarifying_message = (
                "I couldn't find any matching KPIs, keywords, or reference questions "
                "for your query. Could you rephrase your question? For example, you "
                "could ask about specific telecom KPIs, project rollout status, "
                "site counts by region, or milestone progress."
            )

    duration = time.perf_counter() - t_start
    return {
        "is_valid": is_valid,
        "clarifying_message": clarifying_message,
        "ready_for_sql": is_valid,
        "node_timestamps": _merge_ts(
            state.get("node_timestamps", {}), "validate_question", iso_start, _now_iso(), duration
        ),
    }


# ── Terminal node: passthrough ────────────────────────────────────

async def passthrough(state: HITLState) -> dict:
    """Terminal node for valid data questions — ready for text-to-SQL."""
    iso_now = _now_iso()
    return {
        "ready_for_sql": True,
        "node_timestamps": _merge_ts(
            state.get("node_timestamps", {}), "passthrough", iso_now, iso_now, 0.0
        ),
    }


# ── Terminal node: return_clarification ───────────────────────────

async def return_clarification(state: HITLState) -> dict:
    """Terminal node for invalid data questions — return clarifying message."""
    iso_now = _now_iso()
    return {
        "ready_for_sql": False,
        "node_timestamps": _merge_ts(
            state.get("node_timestamps", {}), "return_clarification", iso_now, iso_now, 0.0
        ),
    }


# ── Conditional edge functions ────────────────────────────────────

def route_query_type(state: HITLState) -> str:
    """After classification, route to general handler or data pipeline."""
    if state.get("query_type") == "general":
        return "general"
    return "data"


def route_validation(state: HITLState) -> str:
    """After validation, either pass through or return clarification."""
    if state.get("is_valid"):
        return "valid"
    return "clarify"
