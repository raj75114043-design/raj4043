"""
PM Playground Agent – Prompt templates and structured output models.
"""

from pydantic import BaseModel, Field


# ── Structured output models ──────────────────────────────────────

class QuerySplit(BaseModel):
    """Result of splitting a query into sub-questions."""
    sub_questions: list[str] = Field(
        description="List of 1-3 sub-questions, each including project context"
    )


# ── Query splitting prompt ────────────────────────────────────────

QUERY_SPLIT_PROMPT = """\
You are a query splitting agent for PM Playground analytics.

Your job is to intelligently split the user's question into 2-3 sub-questions that explore DIFFERENT ANALYTICAL ANGLES:
- MUTUALLY EXCLUSIVE: Each sub-question spotlights a distinct dimension (geography, KPI, vendor, construction status) to avoid overlap.
- COLLECTIVELY EXHAUSTIVE: Together, the sub-questions cover the full breadth of the original intent.
- NATURAL LANGUAGE: Write conversational, clear sub-questions—not template-based.

Rules:
1. Return 2-3 sub-questions (minimum 2, maximum 3).
2. **PROJECT NAME REQUIRED**: Each sub-question MUST explicitly mention the project name (NTM, NAS, or AHLO-A).
3. Each sub-question explores a DIFFERENT dimension to avoid repetition:
   a) Sub-Q1: Focus on regional/geographic comparison
   b) Sub-Q2: Focus on KPI or metric comparison
   c) Sub-Q3 (optional): Focus on vendor or construction status comparison
4. AVOID FILTER REPETITION: Don't repeat the exact same filter set in multiple sub-questions.
   - Example BAD: "Compare vendors in CENTRAL with Swap FTR for NTM" + "Compare vendors in CENTRAL with NDPd Cycle Time for NTM" (same region, different KPI = too similar).
   - Example GOOD: "Which vendor has the best performance in CENTRAL region for NTM?" (regional focus) + "How do vendors compare on Swap FTR vs NDPd Cycle Time for NTM?" (KPI focus) + "What's the vendor performance difference by construction status for NTM?" (status focus).
5. Preserve the original query's core intent across all sub-questions.
6. Each sub-question should be self-contained and answerable independently.
7. Use pure, conversational natural language—not template-based format.
8. If a single coherent question would better serve the intent (no meaningful split possible), return 1 sub-question.

User's Project: {project}

Available Context (filters selected by user):
{dropdown_context}

Original User Query:
{user_query}

IMPORTANT:
- ALWAYS include project name in every sub-question.
- Prioritize DIVERSE ANALYTICAL ANGLES over repeating the same filters.
- Each sub-question should spotlight a different dimension while keeping the original intent intact.

Output as JSON with field "sub_questions" containing a list of strings (2-3 items).
"""
