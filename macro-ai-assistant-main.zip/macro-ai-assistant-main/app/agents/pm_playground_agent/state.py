"""
PM Playground Agent – State definition for the LangGraph flow.

Handles query splitting for multi-part analysis in the PM Playground context.
"""

from typing import TypedDict


class PlaygroundAgentState(TypedDict):
    """State for PM Playground query splitting agent."""

    user_query: str
    """Original user query"""

    project: str
    """Selected project: NTM, NAS, or AHLO-A"""

    market: list[str]
    """Selected markets (max 3)"""

    region: list[str]
    """Selected regions (max 3)"""

    area: list[str]
    """Selected areas (max 3)"""

    vendors: list[str]
    """Selected vendors/construction status (max 3)"""

    kpis: list[str]
    """Selected KPIs (max 3)"""

    dropdown_context: str
    """Human-readable summary of selected filters"""

    sub_questions: list[str]
    """Output: 1-3 sub-questions split from the original query"""

    node_timestamps: dict
    """Per-node execution timing"""
