"""
PM Playground Agent – Configuration
"""

from langchain_openai import ChatOpenAI
from app.core.config import settings

# Initialize LLM
llm = ChatOpenAI(
    api_key="NONE",
    model="gpt-5-mini",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    verbose=True,
    timeout= 360,  
)
