"""
GenericSQL Agent – State definition.
"""

from typing import TypedDict, Any


class GenericSQLState(TypedDict):
    """State for generic SQL agent processing."""
    step_id: str
    user_query: str
    table_schema: str         # raw DDL/schema text passed from request (may be just schema name)
    table_name: str           # target table name
    fetched_table_schema: str # actual table structure fetched from PostgreSQL
    is_valid: bool | None     # None before validation, True/False after
    invalid_reason: str       # populated when is_valid = False
    text_response: str        # populated when is_valid = False
    generated_sql: str
    sql_error: str
    retry_count: int
    result_df: Any            # pandas DataFrame or None
    final_status: str         # "success" | "invalid" | "error"
    node_timestamps: dict
