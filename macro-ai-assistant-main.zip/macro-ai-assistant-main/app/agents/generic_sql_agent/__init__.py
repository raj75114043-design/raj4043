"""
Generic SQL Agent – Text-to-SQL agent for direct schema input.
"""

from app.agents.generic_sql_agent.graph import run_generic_sql_agent

__all__ = ["run_generic_sql_agent"]
