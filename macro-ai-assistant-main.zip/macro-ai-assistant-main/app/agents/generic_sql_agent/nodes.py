"""
Generic SQL Agent – LangGraph nodes.
"""

import asyncio
import json
import logging
import time
from datetime import datetime, timezone
from typing import Any

import asyncpg
import pandas as pd
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import JsonOutputParser

from app.agents.generic_sql_agent.state import GenericSQLState
from app.agents.generic_sql_agent.config import llm, DB_CONFIG, MAX_SQL_RETRIES
from app.agents.generic_sql_agent.prompts import (
    VALIDATION_PROMPT,
    SQL_GENERATION_PROMPT,
    SQL_RETRY_PROMPT,
)

logger = logging.getLogger(__name__)


# ── Schema Fetching Node ───────────────────────────────────────────

async def fetch_table_schema(state: GenericSQLState) -> dict:
    """Fetch actual table structure from PostgreSQL information_schema."""
    logger.info(f"[{state['step_id']}] Fetching table schema for {state['table_schema']}.{state['table_name']}")
    t_start, iso_start = time.perf_counter(), _now_iso()

    try:
        conn = await asyncpg.connect(**DB_CONFIG)
        try:
            # Query information_schema for column details
            query = """
                SELECT column_name, data_type, is_nullable
                FROM information_schema.columns
                WHERE table_schema = $1 AND table_name = $2
                ORDER BY ordinal_position
            """
            rows = await conn.fetch(query, state["table_schema"], state["table_name"])

            if not rows:
                logger.warning(f"[{state['step_id']}] Table {state['table_schema']}.{state['table_name']} not found")
                duration = time.perf_counter() - t_start
                return {
                    "fetched_table_schema": f"Table '{state['table_schema']}.{state['table_name']}' not found in database.",
                    "node_timestamps": _merge_timestamps(
                        state.get("node_timestamps", {}), "fetch_table_schema", iso_start, _now_iso(), duration
                    ),
                }

            # Build readable schema description
            schema_lines = [f"Table: {state['table_schema']}.{state['table_name']}"]
            schema_lines.append("\nColumns:")
            for row in rows:
                col_name = row["column_name"]
                col_type = row["data_type"]
                nullable = "NOT NULL" if row["is_nullable"] == "NO" else "NULL"
                schema_lines.append(f"  - {col_name}: {col_type} ({nullable})")

            fetched_schema = "\n".join(schema_lines)
            logger.info(f"[{state['step_id']}] Successfully fetched {len(rows)} columns")

            duration = time.perf_counter() - t_start
            return {
                "fetched_table_schema": fetched_schema,
                "node_timestamps": _merge_timestamps(
                    state.get("node_timestamps", {}), "fetch_table_schema", iso_start, _now_iso(), duration
                ),
            }
        finally:
            await conn.close()
    except Exception as e:
        logger.exception(f"[{state['step_id']}] Error fetching table schema")
        duration = time.perf_counter() - t_start
        return {
            "fetched_table_schema": f"Error fetching schema: {str(e)}",
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), "fetch_table_schema", iso_start, _now_iso(), duration
            ),
        }


# ── Timestamp helpers ─────────────────────────────────────────────

def _now_iso() -> str:
    """Return current time in ISO format."""
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def _merge_timestamps(existing: dict, node_name: str, start: str, end: str, duration: float) -> dict:
    """Return a new dict with the node entry added (avoids mutating state)."""
    updated = {**existing}
    updated[node_name] = {"start": start, "end": end, "duration_s": round(duration, 3)}
    return updated


# ── Validation Node ───────────────────────────────────────────────

async def validate_question(state: GenericSQLState) -> dict:
    """Validate if user question is answerable by the schema."""
    logger.info(f"[{state['step_id']}] Validating question")
    t_start, iso_start = time.perf_counter(), _now_iso()

    try:
        prompt = PromptTemplate.from_template(VALIDATION_PROMPT)
        chain = prompt | llm | JsonOutputParser()

        result = await chain.ainvoke({
            "user_query": state["user_query"],
            "table_schema": state.get("fetched_table_schema", state["table_schema"]),
            "table_name": state["table_name"],
        })

        logger.info(f"[{state['step_id']}] Validation result: {result}")

        duration = time.perf_counter() - t_start
        return {
            "is_valid": result.get("is_valid", False),
            "invalid_reason": result.get("reason", ""),
            "text_response": result.get("text_response", ""),
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), "validate_question", iso_start, _now_iso(), duration
            ),
        }
    except Exception as e:
        logger.exception(f"[{state['step_id']}] Error validating question")
        duration = time.perf_counter() - t_start
        return {
            "is_valid": False,
            "invalid_reason": f"Validation error: {str(e)}",
            "text_response": "Unable to validate your question. Please try rephrasing it.",
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), "validate_question", iso_start, _now_iso(), duration
            ),
        }


# ── Text Response Node ───────────────────────────────────────────

def generate_text_response(state: GenericSQLState) -> dict:
    """Terminal node for invalid questions."""
    logger.info(f"[{state['step_id']}] Generating text response for invalid question")
    t_start, iso_start = time.perf_counter(), _now_iso()
    duration = time.perf_counter() - t_start
    return {
        "final_status": "invalid",
        "text_response": state.get("text_response", ""),
        "node_timestamps": _merge_timestamps(
            state.get("node_timestamps", {}), "generate_text_response", iso_start, _now_iso(), duration
        ),
    }


# ── SQL Generation Node ────────────────────────────────────────────

async def generate_sql(state: GenericSQLState) -> dict:
    """Generate SQL query from user question and schema."""
    logger.info(f"[{state['step_id']}] Generating SQL (attempt {state['retry_count'] + 1})")
    t_start, iso_start = time.perf_counter(), _now_iso()

    try:
        # Build fully qualified table name (schema.table_name)
        # If table_schema looks like a column definition, use just table_name
        # If table_schema is a schema name (no spaces, no colons), use schema.table_name
        table_ref = state["table_name"]
        if state["table_schema"] and not (":" in state["table_schema"] or "\n" in state["table_schema"]):
            table_ref = f"{state['table_schema']}.{state['table_name']}"

        # Choose prompt based on retry status
        fetched_schema = state.get("fetched_table_schema", state["table_schema"])
        if state["retry_count"] == 0:
            prompt_template = SQL_GENERATION_PROMPT
            prompt = PromptTemplate.from_template(prompt_template)
            input_data = {
                "user_query": state["user_query"],
                "table_schema": fetched_schema,
                "table_name": state["table_name"],
                "table_ref": table_ref,
            }
        else:
            prompt_template = SQL_RETRY_PROMPT
            prompt = PromptTemplate.from_template(prompt_template)
            input_data = {
                "user_query": state["user_query"],
                "table_schema": fetched_schema,
                "table_name": state["table_name"],
                "table_ref": table_ref,
                "previous_sql": state["generated_sql"],
                "sql_error": state["sql_error"],
            }

        chain = prompt | llm
        result = await chain.ainvoke(input_data)

        # Extract SQL from result
        sql = result.content.strip()
        # Remove markdown fences if present
        if sql.startswith("```"):
            sql = sql.split("```")[1]
            if sql.startswith("sql"):
                sql = sql[3:]
            sql = sql.strip()
        if sql.endswith("```"):
            sql = sql[:-3].strip()

        logger.info(f"[{state['step_id']}] Generated SQL: {sql[:100]}...")

        duration = time.perf_counter() - t_start
        return {
            "generated_sql": sql,
            "sql_error": "",
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), "generate_sql", iso_start, _now_iso(), duration
            ),
        }
    except Exception as e:
        logger.exception(f"[{state['step_id']}] Error generating SQL")
        duration = time.perf_counter() - t_start
        return {
            "sql_error": str(e),
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), "generate_sql", iso_start, _now_iso(), duration
            ),
        }


# ── SQL Execution Node ─────────────────────────────────────────────

async def execute_sql(state: GenericSQLState) -> dict:
    """Execute SQL query and return results as DataFrame."""
    logger.info(f"[{state['step_id']}] Executing SQL")
    t_start, iso_start = time.perf_counter(), _now_iso()

    if not state["generated_sql"]:
        logger.error(f"[{state['step_id']}] Empty SQL query")
        duration = time.perf_counter() - t_start
        return {
            "sql_error": "Generated SQL is empty",
            "result_df": None,
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), "execute_sql", iso_start, _now_iso(), duration
            ),
        }

    try:
        conn = await asyncpg.connect(**DB_CONFIG)
        try:
            rows = await conn.fetch(state["generated_sql"])
            logger.info(f"[{state['step_id']}] SQL execution successful: {len(rows)} rows")

            # Convert to DataFrame
            if rows:
                df = pd.DataFrame([dict(row) for row in rows])
            else:
                df = pd.DataFrame()

            duration = time.perf_counter() - t_start
            return {
                "result_df": df,
                "sql_error": "",
                "node_timestamps": _merge_timestamps(
                    state.get("node_timestamps", {}), "execute_sql", iso_start, _now_iso(), duration
                ),
            }
        finally:
            await conn.close()
    except Exception as e:
        logger.exception(f"[{state['step_id']}] SQL execution failed")
        duration = time.perf_counter() - t_start
        # Increment retry count for next attempt
        new_retry_count = state["retry_count"] + 1
        return {
            "sql_error": str(e),
            "result_df": None,
            "retry_count": new_retry_count,
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), "execute_sql", iso_start, _now_iso(), duration
            ),
        }


# ── Format Output Node ─────────────────────────────────────────────

def format_output(state: GenericSQLState) -> dict:
    """Terminal node for timing."""
    logger.info(f"[{state['step_id']}] Formatting output")
    t_start, iso_start = time.perf_counter(), _now_iso()

    if state["final_status"] == "invalid":
        duration = time.perf_counter() - t_start
        return {
            "text_response": state.get("text_response", ""),
            "node_timestamps": _merge_timestamps(
                state.get("node_timestamps", {}), "format_output", iso_start, _now_iso(), duration
            ),
        }

    # Determine final status
    if state["sql_error"]:
        final_status = "error"
    else:
        final_status = "success"

    duration = time.perf_counter() - t_start
    return {
        "final_status": final_status,
        "text_response": state.get("text_response", ""),
        "node_timestamps": _merge_timestamps(
            state.get("node_timestamps", {}), "format_output", iso_start, _now_iso(), duration
        ),
    }


# ── Routing Functions ──────────────────────────────────────────────

def route_validation(state: GenericSQLState) -> str:
    """Route based on validation result."""
    if state["is_valid"]:
        return "valid"
    else:
        return "invalid"


def should_retry(state: GenericSQLState) -> str:
    """Route based on SQL error and retry count."""
    if not state["sql_error"]:
        return "success"

    if state["retry_count"] < MAX_SQL_RETRIES:
        return "retry"
    else:
        return "max_retries"
