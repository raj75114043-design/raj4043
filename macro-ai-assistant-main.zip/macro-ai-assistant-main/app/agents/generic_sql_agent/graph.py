"""
Generic SQL Agent – LangGraph workflow.
"""

import asyncio
import logging
import time
from decimal import Decimal
from typing import Any

from langgraph.graph import StateGraph, START, END
from langgraph.errors import GraphRecursionError

from app.agents.generic_sql_agent.state import GenericSQLState
from app.agents.generic_sql_agent.nodes import (
    fetch_table_schema,
    validate_question,
    generate_text_response,
    generate_sql,
    execute_sql,
    format_output,
    route_validation,
    should_retry,
)

logger = logging.getLogger(__name__)


def _convert_decimals_in_dict(data):
    """Recursively convert Decimal objects to float in dict/list structures."""
    if isinstance(data, dict):
        return {k: _convert_decimals_in_dict(v) for k, v in data.items()}
    elif isinstance(data, list):
        return [_convert_decimals_in_dict(item) for item in data]
    elif isinstance(data, Decimal):
        return float(data)
    return data


def build_graph():
    """Build and compile the LangGraph workflow."""
    graph = StateGraph(GenericSQLState)

    # Add nodes
    graph.add_node("fetch_table_schema", fetch_table_schema)
    graph.add_node("validate_question", validate_question)
    graph.add_node("generate_text_response", generate_text_response)
    graph.add_node("generate_sql", generate_sql)
    graph.add_node("execute_sql", execute_sql)
    graph.add_node("format_output", format_output)

    # Add edges
    graph.add_edge(START, "fetch_table_schema")
    graph.add_edge("fetch_table_schema", "validate_question")

    # Conditional routing after validation
    graph.add_conditional_edges(
        "validate_question",
        route_validation,
        {
            "invalid": "generate_text_response",
            "valid": "generate_sql",
        }
    )

    # Invalid path → text response → end
    graph.add_edge("generate_text_response", END)

    # Valid path → SQL generation → execution
    graph.add_edge("generate_sql", "execute_sql")

    # Conditional routing after SQL execution
    graph.add_conditional_edges(
        "execute_sql",
        should_retry,
        {
            "success": "format_output",
            "retry": "generate_sql",
            "max_retries": "format_output",
        }
    )

    # Format output → end
    graph.add_edge("format_output", END)

    return graph.compile()


async def run_generic_sql_agent(
    step_id: str,
    user_query: str,
    table_schema: str,
    table_name: str,
) -> dict:
    """Run the generic SQL agent."""
    logger.info(f"[{step_id}] Starting generic SQL agent")

    # Initialize state
    initial_state: GenericSQLState = {
        "step_id": step_id,
        "user_query": user_query,
        "table_schema": table_schema,
        "table_name": table_name,
        "fetched_table_schema": "",  # Will be populated by fetch_table_schema node
        "is_valid": None,
        "invalid_reason": "",
        "text_response": "",
        "generated_sql": "",
        "sql_error": "",
        "retry_count": 0,
        "result_df": None,
        "final_status": "",
        "node_timestamps": {},
    }

    try:
        # Build and run graph
        compiled_graph = build_graph()
        final_state = None

        # Run the graph (streaming_mode="values" returns full accumulated state)
        async for output in compiled_graph.astream(initial_state, stream_mode="values"):
            final_state = output

        if final_state is None:
            final_state = initial_state

        # Prepare response
        result_df = final_state.get("result_df")
        table_json = None
        if result_df is not None:
            try:
                table_json = result_df.to_dict(orient="records")
                # Convert Decimal objects to float for JSON serialization
                table_json = _convert_decimals_in_dict(table_json)
            except Exception as e:
                logger.exception(f"[{step_id}] Error converting DataFrame to JSON")
                table_json = None

        response = {
            "success": final_state.get("final_status", "") == "success",
            "is_valid": final_state.get("is_valid", False),
            "text_response": final_state.get("text_response", ""),
            "generated_sql": final_state.get("generated_sql", ""),
            "table_json": table_json,
            "error": final_state.get("sql_error", ""),
            "final_status": final_state.get("final_status", ""),
            "node_timestamps": final_state.get("node_timestamps", {}),
        }

        logger.info(f"[{step_id}] Generic SQL agent completed: {response['final_status']}")
        return response

    except Exception as e:
        logger.exception(f"[{step_id}] Generic SQL agent failed")
        return {
            "success": False,
            "is_valid": False,
            "text_response": "An error occurred while processing your query.",
            "generated_sql": "",
            "table_json": None,
            "error": str(e),
            "final_status": "error",
            "node_timestamps": {},
        }
