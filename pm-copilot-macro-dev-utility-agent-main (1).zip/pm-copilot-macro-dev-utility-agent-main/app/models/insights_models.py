from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class WorkflowStepInsight(BaseModel):
    """A workflow step where the site was actually processed."""

    step_id: int
    step_name: str
    step_description: Optional[str] = None
    phase_name: Optional[str] = None
    status: str  # "completed" | "held"
    is_main_path: bool = True  # True = main workflow, False = parallel branch
    error_message: Optional[str] = None


class WorkflowInsight(BaseModel):
    """Insights for a single workflow/pipeline — only steps the site touched."""

    workflow_name: str
    total_steps: int = 0
    completed_steps: int = 0
    held_steps: int = 0
    completion_pct: float = 0.0
    current_position: Optional[WorkflowStepInsight] = None  # last step the site reached
    recent_completed: List[WorkflowStepInsight] = []  # last 3-4 passed steps
    held_step_details: List[WorkflowStepInsight] = []  # steps where site is held


class PMCommentEntry(BaseModel):
    """A single PM comment column value for a site."""

    column_name: str
    column_label: str
    raw_text: Optional[str] = None
    is_empty: bool = True


class LLMInsight(BaseModel):
    """LLM-generated insight with title, short summary, and detailed bullets."""

    title: str = ""
    summary: str = ""
    details: List[str] = []
    recommendations: List[str] = []  # populated in KG mode; empty in workflow mode


class InsightsJobStageEntry(BaseModel):
    """One stage transition recorded for an insights job."""
    stage: str
    label: str = ""
    progress_pct: int = 0
    at: str  # ISO-8601 timestamp


class InsightsJobStatus(BaseModel):
    """Polling response for a site-insights background job."""
    job_id: str
    project_id: str
    smp_id: str
    source: str
    status: str  # 'pending' | 'running' | 'done' | 'failed'
    stage: Optional[str] = None
    stage_label: Optional[str] = None
    progress_pct: int = 0
    stages_completed: List[InsightsJobStageEntry] = []
    partial: Optional[Dict[str, Any]] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    created_at: datetime
    updated_at: datetime


class SiteInsightsResponse(BaseModel):
    """Top-level response for the site insights endpoint."""

    smp_id: str
    project_id: str
    source: str = "workflow"  # 'workflow' or 'kg'
    insight_id: Optional[str] = None  # UUID minted at generation; pass back as feedback's generation_id
    workflows: List[WorkflowInsight] = []
    pm_comments: List[PMCommentEntry] = []
    insight: LLMInsight = Field(default_factory=LLMInsight)
    structured_summary: Dict[str, Any] = {}
    kg_snapshot: Optional[Dict[str, Any]] = None  # raw KG payload when source='kg'
    generated_at: datetime = Field(default_factory=datetime.utcnow)
    cached: bool = False
    cache_age_seconds: Optional[int] = None


class InsightFeedbackRequest(BaseModel):
    """Body for POSTing thumbs up/down + optional comment on an insight."""
    user_id: str = Field(..., min_length=1, max_length=200,
                         description="Opaque user identifier (email or any unique tag).")
    rating: str = Field(..., pattern="^(up|down)$",
                        description="'up' or 'down'.")
    generation_id: str = Field(..., min_length=1, max_length=200,
                               description=("Identifier of the specific insight output the user is "
                                            "rating. For /insights/site this is the response's "
                                            "generated_at (ISO). For /data-browser insights, same."))
    comment: Optional[str] = Field(None, max_length=4000,
                                   description="Optional free-text comment.")


class InsightFeedbackEntry(BaseModel):
    """One feedback row returned by the listing endpoints."""
    feedback_id: str
    surface: str
    project_id: str
    site_key: str
    source: Optional[str] = None
    generation_id: str
    user_id: str
    rating: str
    comment: Optional[str] = None
    insight_snapshot: Optional[Dict[str, Any]] = None  # {title, summary, details, recommendations} captured at submit time
    created_at: str
    updated_at: str


class InsightFeedbackSummary(BaseModel):
    """Aggregate counts for a site/generation."""
    up: int = 0
    down: int = 0
    comments: int = 0
    last_at: Optional[str] = None


class InsightFeedbackListResponse(BaseModel):
    """List endpoint response: summary tile + the individual entries."""
    summary: InsightFeedbackSummary
    entries: List[InsightFeedbackEntry] = []


class DataBrowserProcessSnapshot(BaseModel):
    """One process's slice of data for a single site (passed to the LLM)."""

    table_alias: str
    label: Optional[str] = None
    description: Optional[str] = None
    row_count: int = 0
    rows: List[Dict[str, Any]] = []


class DataBrowserSiteInsightsResponse(BaseModel):
    """Top-level response for the data-browser site insights endpoint."""

    project_id: str
    site_id: str
    insight_id: Optional[str] = None  # UUID minted at generation; pass back as feedback's generation_id
    region_code: Optional[str] = None
    market_code: Optional[str] = None
    processes: List[DataBrowserProcessSnapshot] = []
    insight: LLMInsight = Field(default_factory=LLMInsight)
    generated_at: datetime = Field(default_factory=datetime.utcnow)
    cached: bool = False
    cache_age_seconds: Optional[int] = None
