from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any
from datetime import date, datetime
from enum import Enum

class GeoLevel(str, Enum):
    OVERALL = "OVERALL"
    REGION = "REGION"
    AREA = "AREA"
    MARKET = "MARKET"

class KPICategory(str, Enum):
    HEALTH = "HEALTH"
    PERFORMANCE = "PERFORMANCE"

class KPITag(str, Enum):
    TOTAL      = "TOTAL"       # Big aggregate number (revenue, sites, radios)
    TREND      = "TREND"       # Time-series / sparkline metric
    RATE       = "RATE"        # Speed or throughput metric
    PERCENTAGE = "PERCENTAGE"  # Ratio / percentage-based metric
    COUNT      = "COUNT"       # Simple integer count
    TARGET     = "TARGET"      # Goal / target tracking
    GAUGE      = "GAUGE"       # Gauge or dial-style display
    AVERAGE    = "AVERAGE"     # Mean / average value
    COMPARISON = "COMPARISON"  # Side-by-side comparison metric

class DisplayFormat(str, Enum):
    NUMBER = "NUMBER"
    PERCENTAGE = "PERCENTAGE"
    CURRENCY = "CURRENCY"
    DAYS = "DAYS"

class AggregationMethod(str, Enum):
    SUM = "SUM"
    AVG = "AVG"
    COUNT = "COUNT"
    MIN = "MIN"
    MAX = "MAX"
    WEIGHTED_AVG = "WEIGHTED_AVG"
    CUSTOM = "CUSTOM"

# KPI Definition Models
class KPIDefinitionBase(BaseModel):
    kpi_code: str = Field(..., max_length=50)
    kpi_name: str = Field(..., max_length=200)
    kpi_description: Optional[str] = None
    kpi_category: str
    
    project_ids: Optional[List[str]] = None
    level_ids: Optional[List[str]] = None
    function_ids: Optional[List[str]] = None
    
    applicable_geo_levels: List[GeoLevel]
    sql_query_template: str
    query_parameters: Optional[Dict[str, Any]] = None
    
    aggregation_method: AggregationMethod
    aggregation_column: Optional[str] = None
    
    display_format: DisplayFormat = DisplayFormat.NUMBER
    decimal_places: int = Field(default=2, ge=0, le=6)
    unit_symbol: Optional[str] = None
    
    source_tables: List[str]
    refresh_frequency: str = "DAILY"
    
    is_active: bool = True
    priority: int = Field(default=100, ge=1, le=1000)

class KPIDefinitionCreate(KPIDefinitionBase):
    kpi_id: str = Field(..., max_length=50)

class KPIDefinitionResponse(KPIDefinitionBase):
    kpi_id: str
    created_at: datetime
    updated_at: datetime
    last_calculated_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True

# KPI Value Models
class KPIValueBase(BaseModel):
    kpi_id: str
    geo_id: str
    geo_level: GeoLevel
    calculation_date: date
    period_start_date: date
    period_end_date: date
    kpi_value: Optional[float] = None
    record_count: Optional[int] = 0

class KPIValueResponse(KPIValueBase):
    value_id: int
    kpi_value_formatted: Optional[str] = None
    
    previous_period_value: Optional[float] = None
    previous_year_value: Optional[float] = None
    
    period_on_period_change: Optional[float] = None
    period_on_period_change_pct: Optional[float] = None
    year_on_year_change: Optional[float] = None
    year_on_year_change_pct: Optional[float] = None
    
    data_quality_score: Optional[float] = None
    calculated_at: datetime
    
    class Config:
        from_attributes = True

# Calculation Job Models
class JobType(str, Enum):
    FULL_REFRESH         = "FULL_REFRESH"
    INCREMENTAL          = "INCREMENTAL"
    SINGLE_KPI           = "SINGLE_KPI"
    SINGLE_GEO           = "SINGLE_GEO"
    BATCH_MARKET_REFRESH = "BATCH_MARKET_REFRESH"
    BATCH_AREA_REFRESH   = "BATCH_AREA_REFRESH"
    SITE_REFRESH         = "SITE_REFRESH"

class JobStatus(str, Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"

class CalculationJobCreate(BaseModel):
    job_type: JobType = JobType.INCREMENTAL
    kpi_ids: Optional[List[str]] = None
    geo_ids: Optional[List[str]] = None
    calculation_date: date = Field(default_factory=date.today)
    triggered_by_user_id: Optional[str] = None
    prev_period_days_back: Optional[int] = Field(
        default=None,
        ge=1,
        le=365,
        description=(
            "How many days back to look for the previous-period comparison value. "
            "1 = yesterday (default), 7 = last week, 30 = last month. "
            "Overrides PREV_PERIOD_DAYS_BACK from config for this job only."
        ),
    )

class CalculationJobResponse(BaseModel):
    job_id: str
    job_type: JobType
    status: JobStatus
    
    kpi_ids: Optional[List[str]] = None
    geo_ids: Optional[List[str]] = None
    calculation_date: date
    
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    duration_seconds: Optional[int] = None
    
    total_calculations_planned: Optional[int] = None
    calculations_completed: int = 0
    calculations_failed: int = 0
    
    error_message: Optional[str] = None
    triggered_by: str
    
    created_at: datetime
    
    class Config:
        from_attributes = True

# Dashboard Query Models
class DashboardQueryParams(BaseModel):
    user_id: Optional[str] = None
    project_ids: Optional[List[str]] = None
    level_ids: Optional[List[str]] = None
    function_ids: Optional[List[str]] = None
    geo_codes: Optional[List[str]] = None   # natural keys e.g. ["US_WEST", "APAC"]
    geo_level: Optional[GeoLevel] = None
    kpi_ids: Optional[List[str]] = None
    kpi_category: Optional[str] = None
    dimension_key: str = "ALL"              # filter dimension combo, e.g. "scope_of_work:NEW_BUILD"
    date_from: Optional[date] = None
    date_to: Optional[date] = None
    
    @validator('date_from', 'date_to', pre=True)
    def parse_date(cls, v):
        if isinstance(v, str):
            return datetime.strptime(v, '%Y-%m-%d').date()
        return v

class SubMetricData(BaseModel):
    """A companion KPI value displayed alongside a parent KPI card."""
    kpi_id: str
    kpi_name: str
    display_format: str
    unit_symbol: Optional[str] = None
    current_value: Optional[float] = None
    current_value_formatted: str
    period_change_pct: Optional[float] = None
    trend: str  # 'UP', 'DOWN', 'NEUTRAL'


class DashboardKPIData(BaseModel):
    kpi_id: str
    kpi_name: str
    kpi_category: str
    kpi_tag: Optional[str] = None   # icon/widget hint for the frontend
    display_format: str
    unit_symbol: Optional[str] = None
    project_ids: Optional[List[str]] = None
    level_ids: Optional[List[str]] = None
    function_ids: Optional[List[str]] = None
    has_drilldown: bool = False      # True if a detail table is available

    geo_id: str
    geo_code: str
    geo_name: str
    geo_level: str

    current_value: Optional[float] = None
    current_value_formatted: str

    previous_period_value: Optional[float] = None
    previous_year_value: Optional[float] = None
    period_change_pct: Optional[float] = None
    year_change_pct: Optional[float] = None
    trend: str  # 'UP', 'DOWN', 'NEUTRAL'

    time_series: List[Dict[str, Any]] = []

    # Companion KPIs displayed below this card (e.g. "Total Radios" under "Total Sites")
    sub_metrics: List[SubMetricData] = []
    
class DashboardResponse(BaseModel):
    query_params: DashboardQueryParams
    total_kpis: int
    kpis: List[DashboardKPIData]
    query_timestamp: datetime = Field(default_factory=datetime.now)


class AggregatedKPIData(BaseModel):
    """KPI value aggregated across multiple geographies into a single result."""
    kpi_id: str
    kpi_name: str
    kpi_category: str
    kpi_tag: Optional[str] = None
    display_format: str
    unit_symbol: Optional[str] = None
    aggregation_method: str

    # Which geos were combined
    geo_codes_included: List[str]
    geo_count: int

    current_value: Optional[float] = None
    current_value_formatted: str

    previous_period_value: Optional[float] = None
    previous_year_value: Optional[float] = None
    period_change_pct: Optional[float] = None
    year_change_pct: Optional[float] = None
    trend: str

    total_record_count: int = 0

    # Companion KPIs aggregated alongside this parent
    sub_metrics: List[SubMetricData] = []


class AggregatedKPIResponse(BaseModel):
    kpi_ids: List[str]
    geo_codes: List[str]
    aggregation_method_override: Optional[str] = None
    total_kpis: int
    kpis: List[AggregatedKPIData]
    query_timestamp: datetime = Field(default_factory=datetime.now)


class GeoLevelAggregation(BaseModel):
    """Aggregated KPI results for one geo level (e.g. all selected MARKETs combined)."""
    geo_level: str
    geo_codes_included: List[str]  # which geos at this level were found and combined
    total_kpis: int
    kpis: List[AggregatedKPIData]


class ProjectAggregationResponse(BaseModel):
    """
    Project-wide KPI aggregation grouped by geo level.
    Each level entry contains results for only the geos at that level —
    MARKET values are never mixed with AREA or REGION values.
    """
    project_id: str
    geo_codes_requested: List[str]
    aggregation_method_override: Optional[str] = None
    # geo_codes that were not found in dim_geography
    geo_codes_unresolved: List[str] = []
    by_level: List[GeoLevelAggregation]
    query_timestamp: datetime = Field(default_factory=datetime.now)


# ------------------------------------------------------------------ #
# Project Config Models                                               #
# ------------------------------------------------------------------ #

class ProjectConfigBase(BaseModel):
    project_name: str = Field(..., max_length=200)
    functions: List[str] = []
    geo_codes: List[str] = []
    filter_dimensions: Dict[str, List[str]] = {}
    cross_filters: bool = False
    is_active: bool = True
    # Site data configuration
    site_source_query: Optional[str] = Field(
        None,
        description=(
            "SQL query to pull raw site rows from source tables. "
            "Must return site_id at minimum. Optional columns auto-detected: "
            "site_name, geo_code, region_code, area_code, status, phase, progress_pct. "
            "Any extra columns listed in site_columns are stored in the attributes JSONB."
        ),
    )
    site_columns: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            'Project-specific column definitions for attributes JSONB. '
            'Format: {"col_name": {"type": "string|integer|numeric|boolean|date", '
            '"label": "Display Label", "filterable": true|false}}'
        ),
    )
    column_labels: Dict[str, str] = Field(
        default_factory=dict,
        description=(
            'UI display labels for fixed site columns. '
            'Format: {"region_code": "Region", "area_code": "Area", "market_code": "Market", '
            '"phase": "Build Phase", "progress_pct": "% Complete", "status": "Site Status", '
            '"site_id": "Site ID"}'
        ),
    )
    # Workflow-based site progress configuration
    workflow_pipeline_name: Optional[str] = Field(
        None,
        max_length=200,
        description="Pipeline name from the workflow API. Set to enable workflow-based site progress.",
    )
    workflow_join_key: Optional[str] = Field(
        "smp_id",
        max_length=100,
        description="Column name for joining site_source_query to workflow step output tables.",
    )
    workflow_selected_steps: Optional[List[Dict[str, Any]]] = Field(
        None,
        description=(
            'Selected workflow steps for progress tracking. '
            'Format: [{"step_id": 0, "step_name": "...", "phase_name": "..."}]'
        ),
    )
    workflow_pipeline_names: Optional[List[str]] = Field(
        None,
        description="List of pipeline names from the workflow API. Supports multiple workflows per project.",
    )
    # Insights source switch
    insights_source: Optional[str] = Field(
        "workflow",
        description="Source feeding site insights: 'workflow' (default) or 'kg' (Knowledge Graph status API).",
    )
    kg_url_template: Optional[str] = Field(
        None,
        description=(
            "Full KG status URL with a literal '{site_id}' placeholder. "
            "Required when insights_source='kg'. "
            "Example: https://host/api/v1/status/ahloa/site/{site_id}"
        ),
    )
    site_sort_by: Optional[str] = Field(
        None,
        max_length=100,
        description=(
            "Column to sort the site list by. Can be any fixed column "
            "(site_id, region_code, area_code, market_code, phase, status, progress_pct) "
            "or an attribute key stored in the attributes JSONB. Defaults to site_id."
        ),
    )
    site_sort_order: Optional[str] = Field(
        "asc",
        description="Sort direction for site_sort_by. 'asc' or 'desc'. Defaults to 'asc'.",
    )
    data_browser_tables: Optional[List[Dict[str, Any]]] = Field(
        None,
        description=(
            'Tables available in the data browser for this project. '
            'Format: [{"table_alias": "vendor_tracker", "source_query": "SELECT ...", '
            '"filterable_columns": ["col1", "col2"], "label": "Vendor Tracker", '
            '"site_id_column": "site_id", "region_column": "region_code", '
            '"market_column": "market_code", "description": "..."}]. '
            '`site_id_column` names the column in the SELECT that identifies a '
            'site — required for the table to participate in the unified site '
            'index (GET /api/v1/data-browser/{project_id}/sites). '
            '`region_column` and `market_column` are optional; when set, the '
            'unified site index resolves region/market by table priority order '
            '(first table in this list with a non-null value wins). '
            '`description` is optional free-text passed to the LLM as context '
            'when generating cross-process site insights '
            '(GET /api/v1/data-browser/{project_id}/sites/{site_id}/insights). '
            '`derived_fields` is an optional {name: sql_expression} map. Each '
            'expression is evaluated per site against the aggregated rows in '
            'this table (vocabulary: `row_count` int, `rows` jsonb_agg of '
            'row_data ordered by display_order) and stored on the unified '
            'sites endpoint under derived.<table_alias>.<name>. Values land '
            'verbatim — numbers, strings, dates, nulls all allowed. Field '
            'names must match [A-Za-z_][A-Za-z0-9_]{0,63}.'
        ),
    )

class ProjectConfigCreate(ProjectConfigBase):
    project_id: str = Field(..., max_length=50)

class ProjectConfigResponse(ProjectConfigBase):
    project_id: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ------------------------------------------------------------------ #
# Site Models                                                          #
# ------------------------------------------------------------------ #

class SiteResponse(BaseModel):
    site_id: str
    project_id: str
    region_code: Optional[str] = None
    area_code: Optional[str] = None
    market_code: Optional[str] = None
    phase: Optional[str] = None
    progress_pct: Optional[float] = None
    status: Optional[str] = None
    attributes: Dict[str, Any] = {}
    last_refreshed: Optional[datetime] = None

    class Config:
        from_attributes = True


class SiteListResponse(BaseModel):
    total: int
    page: int
    page_size: int
    pages: int
    project_id: str
    last_refreshed: Optional[datetime] = None
    hidden_columns: List[str] = []  # attribute keys the UI should not render
    data: List[SiteResponse]


class SiteSummaryResponse(BaseModel):
    project_id: str
    total_sites: int
    last_refreshed: Optional[datetime] = None
    by_progress: Dict[str, Any] = {}
    by_phase: Dict[str, int] = {}
    by_status: Dict[str, int] = {}


class SiteRefreshJobResponse(BaseModel):
    job_id: str
    project_id: str
    status: str
    message: str
    started_at: datetime


class WorkflowPipelineInfo(BaseModel):
    pipeline_name: str
    enabled_steps: List[Dict[str, Any]] = []


# ------------------------------------------------------------------ #
# Site Comment Models                                                  #
# ------------------------------------------------------------------ #

class SiteCommentBase(BaseModel):
    user_id: str = Field(..., max_length=200, description="Unique identifier for the commenting user (email, username, or SSO id).")
    user_name: Optional[str] = Field(None, max_length=200, description="Display name of the commenting user.")
    comment_text: str = Field(..., min_length=1, description="Free-text comment body.")


class SiteCommentCreate(SiteCommentBase):
    pass


class SiteCommentUpdate(BaseModel):
    comment_text: str = Field(..., min_length=1)
    user_id: str = Field(..., max_length=200, description="Must match the original author — enforced server-side.")


class SiteCommentResponse(SiteCommentBase):
    comment_id: int
    project_id: str
    site_id: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class SiteCommentListResponse(BaseModel):
    total: int
    page: int
    page_size: int
    pages: int
    project_id: str
    site_id: Optional[str] = None
    user_id: Optional[str] = None
    data: List[SiteCommentResponse]