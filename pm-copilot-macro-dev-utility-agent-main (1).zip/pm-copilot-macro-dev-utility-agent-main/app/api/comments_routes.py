import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import verify_api_key
from app.models.kpi_models import (
    SiteCommentCreate,
    SiteCommentListResponse,
    SiteCommentResponse,
    SiteCommentUpdate,
)
from app.services.comments_service import CommentsService

router = APIRouter(prefix="/api/v1/sites", tags=["Site Comments"])
logger = logging.getLogger(__name__)


# ------------------------------------------------------------------ #
# Create                                                               #
# ------------------------------------------------------------------ #

@router.post(
    "/{project_id}/sites/{site_id}/comments",
    response_model=SiteCommentResponse,
    status_code=201,
)
async def create_site_comment(
    project_id: str,
    site_id: str,
    payload: SiteCommentCreate,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Post a new comment on a site.**

    Multiple users may comment on the same site, and the same user may post
    multiple comments. The site must exist in `dim_sites` for this project.
    """
    svc = CommentsService(db)
    if not await svc._site_exists(project_id, site_id):
        raise HTTPException(
            status_code=404,
            detail=f"Site '{site_id}' not found in project '{project_id}'.",
        )
    return await svc.create_comment(
        project_id=project_id,
        site_id=site_id,
        user_id=payload.user_id,
        user_name=payload.user_name,
        comment_text=payload.comment_text,
    )


# ------------------------------------------------------------------ #
# Read (list + single)                                                 #
# ------------------------------------------------------------------ #

@router.get(
    "/{project_id}/sites/{site_id}/comments",
    response_model=SiteCommentListResponse,
)
async def list_site_comments(
    project_id: str,
    site_id: str,
    user_id: Optional[str] = Query(
        None,
        description="Filter to a single user's comments on this site.",
    ),
    page: int = Query(1, ge=1),
    page_size: int = Query(100, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **List comments for a site.**

    - Omit `user_id` to get all comments from all users (newest first).
    - Pass `user_id` to get comments from a specific user on this site.
    """
    svc = CommentsService(db)
    return await svc.list_comments_for_site(
        project_id=project_id,
        site_id=site_id,
        user_id=user_id,
        page=page,
        page_size=page_size,
    )


@router.get(
    "/{project_id}/sites/{site_id}/comments/{comment_id}",
    response_model=SiteCommentResponse,
)
async def get_site_comment(
    project_id: str,
    site_id: str,
    comment_id: int,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """**Get a single comment by its ID.**"""
    svc = CommentsService(db)
    comment = await svc.get_comment(project_id, site_id, comment_id)
    if not comment:
        raise HTTPException(status_code=404, detail=f"Comment '{comment_id}' not found.")
    return comment


# ------------------------------------------------------------------ #
# Project-wide feed                                                    #
# ------------------------------------------------------------------ #

@router.get(
    "/{project_id}/comments",
    response_model=SiteCommentListResponse,
)
async def list_project_comments(
    project_id: str,
    user_id: Optional[str] = Query(None, description="Filter by user."),
    site_id: Optional[str] = Query(None, description="Filter by site."),
    page: int = Query(1, ge=1),
    page_size: int = Query(100, ge=1, le=500),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **List comments across all sites in a project.**

    Useful for activity feeds. Both `user_id` and `site_id` filters are optional.
    """
    svc = CommentsService(db)
    return await svc.list_comments_for_project(
        project_id=project_id,
        user_id=user_id,
        site_id=site_id,
        page=page,
        page_size=page_size,
    )


# ------------------------------------------------------------------ #
# Update / Delete                                                      #
# ------------------------------------------------------------------ #

@router.patch(
    "/{project_id}/sites/{site_id}/comments/{comment_id}",
    response_model=SiteCommentResponse,
)
async def update_site_comment(
    project_id: str,
    site_id: str,
    comment_id: int,
    payload: SiteCommentUpdate,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Edit a comment.**

    Only the original author (matching `user_id`) may edit the comment.
    Returns 404 if the comment is missing or the user_id does not match.
    """
    svc = CommentsService(db)
    updated = await svc.update_comment(
        project_id=project_id,
        site_id=site_id,
        comment_id=comment_id,
        user_id=payload.user_id,
        comment_text=payload.comment_text,
    )
    if not updated:
        raise HTTPException(
            status_code=404,
            detail=(
                f"Comment '{comment_id}' not found for user '{payload.user_id}' "
                f"on site '{site_id}' in project '{project_id}'."
            ),
        )
    return updated


@router.delete(
    "/{project_id}/sites/{site_id}/comments/{comment_id}",
    status_code=204,
)
async def delete_site_comment(
    project_id: str,
    site_id: str,
    comment_id: int,
    user_id: str = Query(..., description="The author of the comment — must match to authorize delete."),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Delete a comment.**

    Only the original author (matching `user_id`) may delete.
    """
    svc = CommentsService(db)
    deleted = await svc.delete_comment(
        project_id=project_id,
        site_id=site_id,
        comment_id=comment_id,
        user_id=user_id,
    )
    if not deleted:
        raise HTTPException(
            status_code=404,
            detail=(
                f"Comment '{comment_id}' not found for user '{user_id}' "
                f"on site '{site_id}' in project '{project_id}'."
            ),
        )
    return None
