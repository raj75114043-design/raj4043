import json
import logging
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import HTMLResponse
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.core.database import get_db
from app.core.security import verify_api_key
from app.models.kpi_models import ProjectConfigCreate, ProjectConfigResponse
from app.services.project_config_service import ProjectConfigService

router = APIRouter(prefix="/api/v1/project-config", tags=["Project Config"])
logger = logging.getLogger(__name__)


# ------------------------------------------------------------------ #
# Project Config Manager UI                                            #
# ------------------------------------------------------------------ #

_MANAGER_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dynamic Dashboard Builder — Project Config</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Inter',-apple-system,BlinkMacSystemFont,sans-serif;background:#f0f2f5;color:#1a1a2e;font-size:.9rem}
  .layout{display:grid;grid-template-columns:320px 1fr;gap:0;min-height:calc(100vh - 44px);transition:grid-template-columns .2s}
  .layout.collapsed{grid-template-columns:48px 1fr}
  .sidebar{background:#fff;border-right:1px solid #e2e8f0;padding:16px;overflow-y:auto;box-shadow:1px 0 4px rgba(0,0,0,.04);position:relative;transition:padding .2s}
  .layout.collapsed .sidebar{padding:12px 8px;overflow:hidden}
  .layout.collapsed .sidebar-content{display:none}
  .sidebar-toggle{position:absolute;top:12px;right:10px;background:none;border:1px solid #e2e8f0;border-radius:4px;cursor:pointer;padding:2px 6px;font-size:.8rem;color:#64748b;transition:all .15s}
  .sidebar-toggle:hover{background:#f1f5f9;color:#1e293b}
  .layout.collapsed .sidebar-toggle{position:static;display:block;margin:0 auto}
  .main{padding:28px;overflow-y:auto}
  .main-header{margin-bottom:24px}
  .main-header h1{font-size:1.6rem;font-weight:700;margin-bottom:4px}
  .main-header p{color:#666;font-size:.9rem}
  .sidebar-title{font-size:.75rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#64748b;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center}
  .project-item{padding:10px 12px;border-radius:7px;cursor:pointer;margin-bottom:4px;border:1px solid transparent;transition:all .15s}
  .project-item:hover{background:#f8fafc;border-color:#e2e8f0}
  .project-item.active{background:#ede9fe;border-color:#a5b4fc}
  .project-item .pid{font-weight:600;font-size:.85rem}
  .project-item .pname{font-size:.78rem;color:#64748b;margin-top:2px}
  .project-item .pbadge{font-size:.7rem;padding:1px 6px;border-radius:10px;display:inline-block;margin-top:4px}
  .badge-active{background:#dcfce7;color:#166534}
  .badge-inactive{background:#fee2e2;color:#991b1b}
  .card{background:#fff;border-radius:10px;padding:24px;margin-bottom:16px;box-shadow:0 1px 4px rgba(0,0,0,.08)}
  .card-title{font-size:1rem;font-weight:700;margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;align-items:center}
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
  .grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px}
  label{display:block;font-size:.82rem;font-weight:600;color:#444;margin-bottom:5px}
  input[type=text],textarea,select{width:100%;padding:9px 12px;border:1px solid #d1d5db;border-radius:6px;font-size:.9rem;font-family:inherit;background:#fff;color:#1a1a2e;transition:border .15s}
  input[type=text]:focus,textarea:focus,select:focus{outline:none;border-color:#4f46e5;box-shadow:0 0 0 3px rgba(79,70,229,.12)}
  textarea{resize:vertical;font-family:'Courier New',monospace;font-size:.82rem}
  .btn{display:inline-flex;align-items:center;gap:6px;padding:10px 20px;border-radius:7px;font-size:.9rem;font-weight:600;cursor:pointer;border:none;transition:all .15s}
  .btn:active{transform:scale(.98)}
  .btn:disabled{opacity:.45;cursor:not-allowed}
  .btn-primary{background:#4f46e5;color:#fff}.btn-primary:hover:not(:disabled){background:#4338ca}
  .btn-success{background:#16a34a;color:#fff}.btn-success:hover:not(:disabled){background:#15803d}
  .btn-danger{background:#dc2626;color:#fff}.btn-danger:hover:not(:disabled){background:#b91c1c}
  .btn-outline{background:#fff;color:#4f46e5;border:1.5px solid #4f46e5}.btn-outline:hover{background:#ede9fe}
  .btn-sm{padding:6px 14px;font-size:.82rem}
  .btn-refresh{background:#0284c7;color:#fff}.btn-refresh:hover{background:#0369a1}
  .row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
  .section-label{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:#4f46e5;margin-bottom:10px;margin-top:4px}
  .divider{border:none;border-top:1px solid #e5e7eb;margin:20px 0}
  .error{background:#fef2f2;border:1px solid #fca5a5;color:#b91c1c;padding:12px 16px;border-radius:8px;font-size:.88rem}
  .success-box{background:#f0fdf4;border:1px solid #86efac;color:#166534;padding:12px 16px;border-radius:8px;font-size:.88rem}
  .info-box{background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;padding:12px 16px;border-radius:8px;font-size:.84rem;line-height:1.5}
  .hidden{display:none!important}
  .spinner{display:inline-block;width:14px;height:14px;border:2px solid rgba(255,255,255,.4);border-top-color:#fff;border-radius:50%;animation:spin .6s linear infinite}
  @keyframes spin{to{transform:rotate(360deg)}}
  .opt{font-weight:400;color:#888;font-size:.75rem}
  .tag-row{display:flex;flex-wrap:wrap;gap:6px;margin-top:4px}
  .tag{display:inline-flex;align-items:center;gap:4px;background:#ede9fe;border:1px solid #a5b4fc;color:#4338ca;border-radius:4px;padding:2px 8px;font-size:.78rem}
  .tag button{background:none;border:none;cursor:pointer;color:#6b7280;font-size:.9rem;line-height:1;padding:0 2px}
  .tag button:hover{color:#dc2626}
  .add-tag-row{display:flex;gap:6px;margin-top:6px}
  .add-tag-row input{flex:1;padding:5px 8px;font-size:.8rem}
  .dim-block{border:1px solid #e2e8f0;border-radius:7px;padding:12px;margin-bottom:8px;background:#f8f9ff}
  .dim-block-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;font-weight:600;font-size:.82rem}
  .col-def-block{border:1px solid #e2e8f0;border-radius:6px;padding:10px;margin-bottom:6px;background:#f8f9ff}
  .col-def-grid{display:grid;grid-template-columns:1fr 1fr 80px 80px;gap:6px;align-items:end}
  .toggle{display:flex;align-items:center;gap:8px;cursor:pointer;font-size:.85rem}
  .toggle input[type=checkbox]{width:16px;height:16px;cursor:pointer;accent-color:#4f46e5}
  #authModal{position:fixed;inset:0;background:rgba(0,0,0,.45);display:flex;align-items:center;justify-content:center;z-index:1000;padding:24px}
  #authModal.hidden{display:none!important}
  .auth-card{background:#fff;border-radius:14px;padding:36px 32px;width:380px;box-shadow:0 20px 60px rgba(0,0,0,.15);text-align:center}
  .auth-card h2{font-size:1.1rem;font-weight:700;margin-bottom:6px}
  .auth-card p{font-size:.84rem;color:#64748b;margin-bottom:16px}
  .empty-state{text-align:center;padding:60px 20px;color:#94a3b8}
  .empty-state h3{font-size:1rem;margin-bottom:6px;color:#64748b}
  code{background:#f3f4f6;padding:1px 5px;border-radius:4px;font-family:monospace;font-size:.85em}
  /* Tabs */
  .form-header{background:#fff;border-radius:10px;padding:14px 20px;margin-bottom:12px;box-shadow:0 1px 4px rgba(0,0,0,.08);display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
  .form-header-title{font-size:1rem;font-weight:700}
  .form-header-actions{display:flex;gap:8px;flex-wrap:wrap}
  .stats-strip{display:flex;gap:14px;flex-wrap:wrap;background:#fff;border-radius:10px;padding:12px 20px;margin-bottom:12px;box-shadow:0 1px 4px rgba(0,0,0,.08);font-size:.82rem}
  .stat{display:flex;flex-direction:column;gap:2px;min-width:90px}
  .stat .stat-label{font-size:.68rem;text-transform:uppercase;letter-spacing:.05em;color:#94a3b8;font-weight:600}
  .stat .stat-value{font-size:1rem;font-weight:700;color:#1e293b}
  .stat.total .stat-value{color:#4f46e5}
  .stat-sep{width:1px;background:#e2e8f0;align-self:stretch}
  .pcount{display:inline-block;font-size:.7rem;color:#475569;background:#f1f5f9;border-radius:10px;padding:1px 8px;margin-left:6px;font-weight:600}
  .tabs{display:flex;gap:2px;background:#fff;border-radius:10px 10px 0 0;padding:6px 6px 0;margin-bottom:0;box-shadow:0 1px 4px rgba(0,0,0,.08);overflow-x:auto}
  .tab{padding:10px 18px;font-size:.85rem;font-weight:600;color:#64748b;cursor:pointer;border:none;background:transparent;border-radius:6px 6px 0 0;border-bottom:3px solid transparent;transition:all .15s;white-space:nowrap}
  .tab:hover{color:#1e293b;background:#f8fafc}
  .tab.active{color:#4f46e5;border-bottom-color:#4f46e5;background:#fff}
  .tab-badge{display:inline-block;margin-left:6px;font-size:.7rem;background:#e2e8f0;color:#64748b;border-radius:10px;padding:1px 7px;font-weight:600}
  .tab.active .tab-badge{background:#ede9fe;color:#4338ca}
  .tab-panels{background:#fff;border-radius:0 0 10px 10px;padding:18px;box-shadow:0 1px 4px rgba(0,0,0,.08);margin-bottom:84px}
  .tab-panel{display:none}
  .tab-panel.active{display:block}
  .tab-panel .card{box-shadow:none;border:1px solid #eef2f7;padding:18px;margin-bottom:14px}
  .tab-panel .card:last-child{margin-bottom:0}
  /* Sticky action bar */
  .sticky-actions{position:fixed;bottom:0;left:320px;right:0;background:#fff;border-top:1px solid #e2e8f0;padding:12px 28px;display:flex;align-items:center;gap:12px;box-shadow:0 -2px 10px rgba(0,0,0,.06);z-index:50;transition:left .2s}
  .sticky-actions.collapsed{left:48px}
  .sticky-actions .status-slot{flex:1;min-width:0}
  .sticky-actions .status-slot > div{margin:0;padding:8px 12px;font-size:.82rem}
</style>
</head>
<body>

<nav style="background:#0f172a;padding:0 24px;display:flex;align-items:center;gap:4px;height:44px;position:sticky;top:0;z-index:100;box-shadow:0 1px 3px rgba(0,0,0,.3)">
  <span style="color:#94a3b8;font-size:.75rem;font-weight:700;letter-spacing:.08em;margin-right:12px">DYNAMIC DASHBOARD BUILDER</span>
  <a href="/api/v1/project-config/manage" style="color:#fff;text-decoration:none;font-size:.82rem;padding:6px 12px;border-radius:4px;background:#1e40af">Project Config</a>
  <a href="/api/v1/kpi-builder/form" style="color:#cbd5e1;text-decoration:none;font-size:.82rem;padding:6px 12px;border-radius:4px;transition:background .15s" onmouseover="this.style.background='#1e293b'" onmouseout="this.style.background='transparent'">KPI Builder</a>
  <a href="/api/v1/kpi-builder/manage" style="color:#cbd5e1;text-decoration:none;font-size:.82rem;padding:6px 12px;border-radius:4px;transition:background .15s" onmouseover="this.style.background='#1e293b'" onmouseout="this.style.background='transparent'">KPI Manager</a>
  <a href="/api/v1/guide" style="color:#cbd5e1;text-decoration:none;font-size:.82rem;padding:6px 12px;border-radius:4px;transition:background .15s" onmouseover="this.style.background='#1e293b'" onmouseout="this.style.background='transparent'">Guide</a>
  <span style="flex:1"></span>
  <a href="/docs" target="_blank" style="color:#64748b;text-decoration:none;font-size:.75rem;padding:4px 8px">API Docs ↗</a>
  <div id="authStatusBar" style="display:flex;align-items:center;gap:10px;margin-left:8px"></div>
</nav>

<!-- Auth modal -->
<div id="authModal">
  <div class="auth-card">
    <div style="font-size:2.2rem;margin-bottom:12px">&#128272;</div>
    <h2>Authentication Required</h2>
    <p>Enter your API key to continue.<br>Stored for this session only.</p>
    <input type="password" id="authKey" placeholder="Paste your X-API-Key here" style="margin-bottom:10px;text-align:left"
           onkeydown="if(event.key==='Enter') authenticate()">
    <div id="authError" class="error hidden" style="margin-bottom:10px;text-align:left"></div>
    <div class="row" style="justify-content:center">
      <button class="btn btn-primary" id="authBtn" onclick="authenticate()">Authenticate</button>
    </div>
  </div>
</div>

<div class="layout">
  <!-- Sidebar: project list -->
  <div class="sidebar" id="sidebar">
    <button class="sidebar-toggle" onclick="toggleSidebar()" title="Toggle sidebar">&#9776;</button>
    <div class="sidebar-content">
      <div class="sidebar-title" style="margin-top:8px">
        Projects
        <button class="btn btn-primary btn-sm" onclick="openNewForm()">+ New</button>
      </div>
      <div id="projectList"><div class="empty-state"><h3>Loading…</h3></div></div>
    </div>
  </div>

  <!-- Main: edit form -->
  <div class="main">
    <div class="main-header">
      <h1>Project Config Manager</h1>
      <p>Define projects, functions, geo scope, filter dimensions, and site data sources.</p>
    </div>

    <!-- Empty state -->
    <div id="emptyState" class="empty-state">
      <h3>Select a project to edit</h3>
      <p>Or click <strong>+ New</strong> to create a project configuration.</p>
    </div>

    <!-- Edit / Create form -->
    <div id="editForm" class="hidden">

      <!-- ── Form header (title + global actions) ──────── -->
      <div class="form-header">
        <div class="form-header-title" id="formTitle">Project Configuration</div>
        <div class="form-header-actions">
          <button class="btn btn-refresh btn-sm hidden" id="refreshBtn" onclick="triggerSiteRefresh()">↻ Refresh Sites</button>
          <button class="btn btn-refresh btn-sm hidden" id="refreshDbBtn" onclick="triggerDataBrowserRefresh()">↻ Refresh Data Browser</button>
          <button class="btn btn-danger btn-sm hidden" id="deleteBtn" onclick="deleteProject()">Delete</button>
        </div>
      </div>

      <!-- ── Stats strip (populated for existing projects) ── -->
      <div class="stats-strip hidden" id="statsStrip"></div>

      <!-- ── Tab bar ───────────────────────────────────── -->
      <div class="tabs" role="tablist">
        <button type="button" class="tab active" data-tab="general" onclick="switchTab('general')">General</button>
        <button type="button" class="tab" data-tab="filters" onclick="switchTab('filters')">Filters &amp; Geo</button>
        <button type="button" class="tab" data-tab="sites" onclick="switchTab('sites')">Sites &amp; Workflow</button>
        <button type="button" class="tab" data-tab="browser" onclick="switchTab('browser')">Data Browser</button>
      </div>

      <div class="tab-panels">

      <!-- ───────────────────────── TAB: GENERAL ───────────────────────── -->
      <div class="tab-panel active" data-panel="general">

      <!-- ── Basic Info ─────────────────────────────────── -->
      <div class="card">
        <div class="section-label">Basic Info</div>

        <div class="grid2" style="margin-bottom:14px">
          <div>
            <label>Project ID <span style="color:red">*</span></label>
            <input type="text" id="fProjectId" placeholder="e.g. NTM" style="font-family:monospace;font-weight:600">
          </div>
          <div>
            <label>Project Name <span style="color:red">*</span></label>
            <input type="text" id="fProjectName" placeholder="e.g. Nokia T-Mobile">
          </div>
        </div>

        <div class="grid2" style="margin-bottom:4px">
          <div>
            <label class="toggle">
              <input type="checkbox" id="fIsActive" checked>
              Active
            </label>
          </div>
          <div>
            <label class="toggle">
              <input type="checkbox" id="fCrossFilters">
              Cross-filter dimensions (cartesian product)
            </label>
          </div>
        </div>
      </div>

      <!-- ── Functions ──────────────────────────────────── -->
      <div class="card">
        <div class="section-label">Functions</div>
        <div id="fFunctionsDisplay" class="tag-row"></div>
        <div class="add-tag-row">
          <input type="text" id="fFunctionInput" placeholder="Add function e.g. PDM"
                 onkeydown="if(event.key==='Enter'){event.preventDefault();addTag('fFunctions','fFunctionInput')}">
          <button class="btn btn-outline btn-sm" onclick="addTag('fFunctions','fFunctionInput')">Add</button>
        </div>
        <input type="hidden" id="fFunctions">
      </div>

      </div><!-- /panel general -->

      <!-- ───────────────────────── TAB: FILTERS & GEO ─────────────────── -->
      <div class="tab-panel" data-panel="filters">

      <!-- ── Geo Codes ──────────────────────────────────── -->
      <div class="card">
        <div class="section-label">Applicable Geo Codes <span class="opt">— leave empty to use all geographies</span></div>
        <div id="fGeoCodesDisplay" class="tag-row"></div>
        <div class="add-tag-row">
          <input type="text" id="fGeoCodeInput" placeholder="Add geo_code e.g. US_WEST (UPPER CASE)"
                 onkeydown="if(event.key==='Enter'){event.preventDefault();addTag('fGeoCodes','fGeoCodeInput',true)}">
          <button class="btn btn-outline btn-sm" onclick="addTag('fGeoCodes','fGeoCodeInput',true)">Add</button>
        </div>
        <input type="hidden" id="fGeoCodes">
      </div>

      <!-- ── Filter Dimensions ──────────────────────────── -->
      <div class="card">
        <div class="section-label">Filter Dimensions <span class="opt">— for dimension-aware KPI calculations</span></div>
        <div class="info-box" style="margin-bottom:12px">
          Each dimension defines filter values injected into KPI SQL templates as bind parameters.
          E.g. dimension <code>scope_of_work</code> with values <code>NEW_BUILD, MODIFICATION</code>
          lets KPIs filter by scope. In your KPI SQL use:<br><br>
          <code>AND (:scope_of_work = 'ALL' OR col = :scope_of_work)</code><br><br>
          <strong>Different column name per table?</strong> The dimension param name is fixed (e.g. <code>:scope_of_work</code>)
          but the actual column in each table may differ — e.g. <code>project_category</code> in one table,
          <code>nas_project_category</code> in another. Reference the correct column directly in each KPI SQL,
          and always use <code>UPPER()</code> on both sides to make the filter case-insensitive:<br><br>
          <code>AND (:scope_of_work = 'ALL' OR UPPER(nas_project_category) = UPPER(:scope_of_work))</code><br><br>
          No engine changes needed — each KPI SQL owns its own column mapping. The AI generator applies this pattern automatically.
        </div>
        <div id="fDimensionsContainer"></div>
        <button class="btn btn-outline btn-sm" style="margin-top:8px" onclick="addDimensionBlock()">+ Add Dimension</button>
      </div>

      </div><!-- /panel filters -->

      <!-- ───────────────────────── TAB: SITES & WORKFLOW ──────────────── -->
      <div class="tab-panel" data-panel="sites">

      <!-- ── Site Data Config ───────────────────────────── -->
      <div class="card">
        <div class="section-label">Site Data Configuration</div>
        <div class="info-box" style="margin-bottom:12px">
          Configure how site data is loaded for this project.
          The source query runs daily and populates <code>dim_sites</code>.
          Include <code>phase</code> and <code>progress_pct</code> directly in your SELECT if needed — no separate expressions required.
        </div>

        <div style="margin-bottom:14px">
          <label>Site Source Query <span class="opt">optional — SQL to pull raw site rows</span></label>
          <textarea id="fSiteSourceQuery" rows="7"
            placeholder="SELECT site_id, site_name, geo_code, region_code, area_code, status,&#10;       ROUND(completed * 100.0 / NULLIF(total, 0), 2) AS progress_pct,&#10;       CASE WHEN completed=0 THEN 'PLANNING' ELSE 'ACTIVE' END AS phase&#10;FROM source_schema.project_sites&#10;WHERE is_active = TRUE"></textarea>
          <div style="font-size:.75rem;color:#6b7280;margin-top:4px">
            Required: <code>site_id</code>. Auto-detected if present: <code>site_name</code>, <code>geo_code</code>, <code>region_code</code>, <code>area_code</code>, <code>status</code>, <code>phase</code>, <code>progress_pct</code>.
            <br><strong>If using workflow:</strong> also include the join key column (e.g. <code>smp_id</code>) — progress/status/phase will be computed from workflow steps instead.
          </div>
        </div>

        <hr class="divider">
        <div class="section-label" style="margin-bottom:10px;cursor:pointer;user-select:none;display:flex;justify-content:space-between;align-items:center" onclick="toggleSection('colLabelsBody', 'colLabelsArrow')">
          Column Display Labels <span class="opt">— UI rename for fixed columns</span>
          <span id="colLabelsArrow" style="font-size:.8rem;color:#94a3b8">▼</span>
        </div>
        <div id="colLabelsBody">
          <div class="info-box" style="margin-bottom:10px">
            Override column names shown in the UI. Leave blank to use the default name.
          </div>
          <div class="grid3" style="margin-bottom:8px">
            <div><label>site_id</label><input type="text" id="lbl_site_id" placeholder="Site ID"></div>
            <div><label>region_code</label><input type="text" id="lbl_region_code" placeholder="Region"></div>
            <div><label>area_code</label><input type="text" id="lbl_area_code" placeholder="Area"></div>
            <div><label>market_code</label><input type="text" id="lbl_market_code" placeholder="Market"></div>
            <div><label>phase</label><input type="text" id="lbl_phase" placeholder="Phase"></div>
            <div><label>progress_pct</label><input type="text" id="lbl_progress_pct" placeholder="Progress %"></div>
            <div><label>status</label><input type="text" id="lbl_status" placeholder="Status"></div>
          </div>
        </div>

        <hr class="divider">
        <div class="section-label" style="margin-bottom:10px">Site Column Definitions <span class="opt">— project-specific attributes</span></div>
        <div class="info-box" style="margin-bottom:10px">
          Define which columns from your source query become queryable attributes.
          Filterable columns get dropdown options in the site list API.
        </div>
        <div id="fSiteColsContainer"></div>
        <button class="btn btn-outline btn-sm" style="margin-top:8px" onclick="addSiteColDef()">+ Add Column</button>
      </div>

      <!-- ── Workflow Settings ──────────────────────────── -->
      <div class="card">
        <div class="section-label">Site Insights Source <span class="opt">— which backend feeds the /insights/site endpoint</span></div>
        <div class="info-box" style="margin-bottom:12px">
          Choose <strong>Workflow</strong> to derive insights from workflow pipeline step status (current behavior),
          or <strong>Knowledge Graph</strong> to fetch a per-site status record from the KG API and generate proactive,
          recommendation-bearing insights. Switching invalidates cached insights for this project.
        </div>

        <div style="margin-bottom:14px">
          <label>Insights Source</label>
          <div style="display:flex;gap:16px;align-items:center;margin-top:4px">
            <label style="display:flex;align-items:center;gap:6px;font-weight:400">
              <input type="radio" name="fInsightsSource" value="workflow" checked onchange="onInsightsSourceChange()"> Workflow
            </label>
            <label style="display:flex;align-items:center;gap:6px;font-weight:400">
              <input type="radio" name="fInsightsSource" value="kg" onchange="onInsightsSourceChange()"> Knowledge Graph
            </label>
          </div>
        </div>

        <div id="kgFieldsSection" class="hidden">
          <div style="margin-bottom:14px">
            <label>KG URL Template <span style="color:#dc2626">*</span></label>
            <input type="text" id="fKgUrlTemplate"
                   placeholder="https://host/api/v1/status/&lt;project_slug&gt;/site/{site_id}"
                   style="width:100%">
            <div style="font-size:.75rem;color:#6b7280;margin-top:4px">
              Full URL with a literal <code>{site_id}</code> placeholder. The placeholder is replaced verbatim
              with the site id passed to <code>/api/v1/insights/site/&#123;project_id&#125;/&#123;site_id&#125;</code>.
              Host must end in an allowed suffix (see <code>KG_ALLOWED_HOST_SUFFIXES</code>). Example:
              <code>https://pm-copilot-kg-consume-osdp-gsd-gsd-delivery-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/status/ahloa/site/{site_id}</code>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="section-label">Workflow Settings <span class="opt">— compute progress/status/phase from workflow pipeline</span></div>
        <div class="info-box" style="margin-bottom:12px">
          Select a workflow pipeline and choose which enabled steps to use for progress tracking.
          Each site's progress is calculated based on how many selected steps it has completed.
        </div>

        <div style="margin-bottom:14px">
          <label>Pipeline</label>
          <div style="display:flex;gap:8px;align-items:center">
            <select id="fWorkflowPipeline" style="flex:1">
              <option value="">— None (workflow disabled) —</option>
            </select>
            <button class="btn btn-outline btn-sm" onclick="loadPipelines()" id="loadPipelinesBtn" title="Fetch pipeline list from workflow API">Load Pipelines</button>
            <button class="btn btn-outline btn-sm" onclick="loadPipelineSteps()" id="loadStepsBtn" title="Load enabled steps for the selected pipeline">Load Steps</button>
          </div>
        </div>

        <div style="margin-bottom:14px">
          <label>Join Key <span class="opt">— column in your source query that maps to workflow tables</span></label>
          <input type="text" id="fWorkflowJoinKey" value="smp_id" placeholder="smp_id" style="max-width:260px">
          <div style="font-size:.75rem;color:#6b7280;margin-top:4px">
            Your <strong>Site Source Query</strong> above must include this column in its SELECT
            (e.g. <code>SELECT site_id, smp_id, region_code, ...</code>).
            This is used to join with workflow step output tables.
          </div>
        </div>

        <div id="wfStepsSection" class="hidden">
          <div class="section-label" style="margin-bottom:8px;font-size:.8rem">
            Select Steps for Progress Tracking
            <span id="wfStepCount" style="margin-left:12px;color:#6b7280;font-weight:400"></span>
          </div>
          <div id="wfStepsContainer" style="max-height:320px;overflow-y:auto;border:1px solid #e2e8f0;border-radius:6px;padding:8px;background:#fafafa"></div>
          <div style="margin-top:8px;display:flex;gap:8px">
            <button class="btn btn-outline btn-sm" onclick="wfSelectAll()">Select All</button>
            <button class="btn btn-outline btn-sm" onclick="wfClearAll()">Clear All</button>
          </div>
        </div>

        <div style="margin-top:12px">
          <button class="btn btn-outline btn-sm" style="color:#dc2626;border-color:#dc2626" onclick="clearWorkflowConfig()">Clear Workflow Config</button>
        </div>
      </div>

      <!-- ── Site List Sort ─────────────────────────────── -->
      <div class="card">
        <div class="section-label">Site List Ordering <span class="opt">— default sort for the site list</span></div>
        <div style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap">
          <div>
            <label style="font-size:.8rem">Sort By Column</label>
            <input type="text" id="fSiteSortBy" placeholder="e.g. progress_pct, region_code, or attribute key" style="min-width:280px">
            <div style="font-size:.75rem;color:#6b7280;margin-top:3px">
              Fixed columns: <code>site_id</code>, <code>region_code</code>, <code>area_code</code>, <code>market_code</code>, <code>phase</code>, <code>status</code>, <code>progress_pct</code>.
              Or any key from your site_columns attributes. Leave blank to default to <code>site_id</code>.
            </div>
          </div>
          <div>
            <label style="font-size:.8rem">Sort Order</label>
            <select id="fSiteSortOrder" style="max-width:120px">
              <option value="asc">Ascending</option>
              <option value="desc">Descending</option>
            </select>
          </div>
        </div>
      </div>

      </div><!-- /panel sites -->

      <!-- ───────────────────────── TAB: DATA BROWSER ──────────────────── -->
      <div class="tab-panel" data-panel="browser">

      <!-- ── Data Browser Tables ────────────────────────── -->
      <div class="card">
        <div class="section-label">Data Browser Tables <span class="opt">— source tables for the data browser</span></div>
        <div style="font-size:.78rem;color:#6b7280;margin-bottom:8px">
          Configure tables that users can browse, search, and filter.
          Each table needs an alias (short name), a display label, and a source SQL query.
          Filterable columns are auto-detected if left blank (columns with &le;50 distinct values).
        </div>
        <div id="fDataBrowserContainer"></div>
        <button class="btn btn-outline btn-sm" style="margin-top:8px" onclick="addDataBrowserTable()">+ Add Table</button>
      </div>

      </div><!-- /panel browser -->

      </div><!-- /tab-panels -->

    </div><!-- /editForm -->
  </div><!-- /main -->
</div>

<!-- ── Sticky action bar (visible only when editing) ── -->
<div id="stickyActions" class="sticky-actions hidden">
  <div class="status-slot">
    <div id="basicError" class="error hidden"></div>
    <div id="basicSuccess" class="success-box hidden"></div>
    <div id="refreshStatus" class="info-box hidden"></div>
  </div>
  <button class="btn btn-outline" onclick="cancelEdit()">Cancel</button>
  <button class="btn btn-success" onclick="saveProject()" id="saveBtn">Save Configuration</button>
</div>

<script>
const BASE = window.location.origin;
const SESSION_KEY = 'ddb_api_key';
let _projects = [];
let _stats = {};         // { project_id: {kpi_count, dim_combos, geo_count, total_calcs} }
let _editingId = null;   // null = new project

// ── Auth ──────────────────────────────────────────────────── //

function toggleSidebar() {
  const collapsed = document.querySelector('.layout').classList.toggle('collapsed');
  document.getElementById('stickyActions').classList.toggle('collapsed', collapsed);
}

function switchTab(name) {
  document.querySelectorAll('.tab').forEach(t => {
    t.classList.toggle('active', t.dataset.tab === name);
  });
  document.querySelectorAll('.tab-panel').forEach(p => {
    p.classList.toggle('active', p.dataset.panel === name);
  });
}

function toggleSection(bodyId, arrowId) {
  const body = document.getElementById(bodyId);
  const arrow = document.getElementById(arrowId);
  const hidden = body.style.display === 'none';
  body.style.display = hidden ? '' : 'none';
  arrow.textContent = hidden ? '▼' : '▶';
}

function updateAuthStatusBar() {
  const bar = document.getElementById('authStatusBar');
  const key = sessionStorage.getItem(SESSION_KEY);
  bar.innerHTML = key
    ? '<span style="color:#94a3b8;font-size:.8rem">🔒 Authenticated</span>' +
      '<button onclick="logout()" style="background:none;border:1px solid #475569;color:#94a3b8;border-radius:4px;padding:3px 8px;font-size:.75rem;cursor:pointer">Sign out</button>'
    : '';
}

async function authenticate() {
  const btn = document.getElementById('authBtn');
  const err = document.getElementById('authError');
  const key = document.getElementById('authKey').value.trim();
  err.classList.add('hidden');
  if (!key) { err.textContent = 'Please enter your API key.'; err.classList.remove('hidden'); return; }
  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Verifying…';
  try {
    const res = await fetch(BASE + '/api/v1/project-config/', { headers: { 'X-API-Key': key } });
    if (!res.ok) throw new Error(res.status === 401 || res.status === 403 ? 'Invalid API key.' : 'Server error');
    sessionStorage.setItem(SESSION_KEY, key);
    document.getElementById('authModal').classList.add('hidden');
    updateAuthStatusBar();
    loadProjects();
  } catch(e) { err.textContent = e.message; err.classList.remove('hidden'); }
  finally { btn.disabled = false; btn.textContent = 'Authenticate'; }
}

function logout() {
  sessionStorage.removeItem(SESSION_KEY);
  updateAuthStatusBar();
  document.getElementById('authModal').classList.remove('hidden');
}

// ── API ───────────────────────────────────────────────────── //

async function apiFetch(path, method = 'GET', body) {
  const key = sessionStorage.getItem(SESSION_KEY) || '';
  const opts = { method, headers: { 'Content-Type': 'application/json', 'X-API-Key': key } };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const res = await fetch(BASE + path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || JSON.stringify(data));
  return data;
}

// ── Load project list ─────────────────────────────────────── //

async function loadProjects() {
  try {
    _projects = await apiFetch('/api/v1/project-config/');
    loadStats();  // fire and forget — sidebar re-renders when it returns
    renderSidebar();
  } catch(e) {
    document.getElementById('projectList').innerHTML =
      '<div class="error">' + e.message + '</div>';
  }
}

async function loadStats() {
  try {
    _stats = await apiFetch('/api/v1/project-config/stats');
    renderSidebar();
    if (_editingId) renderStatsStrip(_editingId);
  } catch(e) {
    // Stats are best-effort — keep the UI working without them
    _stats = {};
  }
}

function _fmt(n) {
  if (n == null) return '—';
  if (n < 1000) return String(n);
  if (n < 1000000) return (n / 1000).toFixed(n < 10000 ? 1 : 0).replace(/\\.0$/, '') + 'k';
  return (n / 1000000).toFixed(1).replace(/\\.0$/, '') + 'M';
}

function renderStatsStrip(projectId) {
  const strip = document.getElementById('statsStrip');
  const s = _stats[projectId];
  if (!s) { strip.classList.add('hidden'); strip.innerHTML = ''; return; }
  strip.innerHTML =
    '<div class="stat"><span class="stat-label">KPIs</span><span class="stat-value">' + _fmt(s.kpi_count) + '</span></div>' +
    '<div class="stat-sep"></div>' +
    '<div class="stat"><span class="stat-label">Dim Combos</span><span class="stat-value">' + _fmt(s.dim_combos) + '</span></div>' +
    '<div class="stat-sep"></div>' +
    '<div class="stat"><span class="stat-label">Geographies</span><span class="stat-value">' + _fmt(s.geo_count) + '</span></div>' +
    '<div class="stat-sep"></div>' +
    '<div class="stat total" title="KPIs × dim combos × geographies"><span class="stat-label">Calcs / Refresh</span><span class="stat-value">' + _fmt(s.total_calcs) + '</span></div>';
  strip.classList.remove('hidden');
}

function renderSidebar() {
  const el = document.getElementById('projectList');
  if (!_projects.length) {
    el.innerHTML = '<div class="empty-state"><h3>No projects yet</h3><p>Click + New to create one.</p></div>';
    return;
  }
  el.innerHTML = _projects.map(p => {
    const isActive = _editingId === p.project_id;
    const pid = p.project_id.replace(/"/g, '&quot;');
    const s = _stats[p.project_id];
    const kpiBadge = s ? `<span class="pcount" title="${s.kpi_count} KPIs · ${s.total_calcs} calcs/refresh">${_fmt(s.kpi_count)} KPIs</span>` : '';
    return `<div class="project-item${isActive ? ' active' : ''}" data-pid="${pid}">
      <div class="pid">${p.project_id}</div>
      <div class="pname">${p.project_name || ''}</div>
      <span class="pbadge ${p.is_active ? 'badge-active' : 'badge-inactive'}">
        ${p.is_active ? 'Active' : 'Inactive'}
      </span>${kpiBadge}</div>`;
  }).join('');
}

// ── Form helpers ──────────────────────────────────────────── //

function setTags(hiddenId, displayId, values, upper = false) {
  const arr = (values || []).map(v => upper ? v.toUpperCase() : v);
  document.getElementById(hiddenId).value = JSON.stringify(arr);
  renderTags(hiddenId, displayId, upper);
}

function renderTags(hiddenId, displayId, upper = false) {
  const arr = JSON.parse(document.getElementById(hiddenId).value || '[]');
  document.getElementById(displayId).innerHTML = arr.map((v, i) =>
    `<span class="tag">${v}<button onclick="removeTag('${hiddenId}','${displayId}',${i},${upper})" title="Remove">×</button></span>`
  ).join('');
}

function addTag(hiddenId, inputId, upper = false) {
  const inp = document.getElementById(inputId);
  let val = inp.value.trim();
  if (!val) return;
  if (upper) val = val.toUpperCase();
  const arr = JSON.parse(document.getElementById(hiddenId).value || '[]');
  if (!arr.includes(val)) { arr.push(val); document.getElementById(hiddenId).value = JSON.stringify(arr); }
  const displayId = hiddenId + 'Display';
  renderTags(hiddenId, displayId, upper);
  inp.value = '';
}

function removeTag(hiddenId, displayId, idx, upper = false) {
  const arr = JSON.parse(document.getElementById(hiddenId).value || '[]');
  arr.splice(idx, 1);
  document.getElementById(hiddenId).value = JSON.stringify(arr);
  renderTags(hiddenId, displayId, upper);
}

// ── Dimension blocks ──────────────────────────────────────── //

let _dimCounter = 0;

function addDimensionBlock(name = '', values = []) {
  const id = ++_dimCounter;
  const container = document.getElementById('fDimensionsContainer');
  const div = document.createElement('div');
  div.className = 'dim-block';
  div.id = 'dim_' + id;
  div.innerHTML = `
    <div class="dim-block-header">
      <input type="text" placeholder="Dimension name e.g. scope_of_work"
             id="dimName_${id}" style="flex:1;margin-right:8px;font-family:monospace">
      <button class="btn btn-danger btn-sm" onclick="document.getElementById('dim_${id}').remove()">Remove</button>
    </div>
    <div id="dimTagsDisplay_${id}" class="tag-row" style="margin-bottom:6px"></div>
    <div class="add-tag-row">
      <input type="text" id="dimValInput_${id}" placeholder="Add value e.g. NEW_BUILD"
             onkeydown="if(event.key==='Enter'){event.preventDefault();addDimValue(${id})}">
      <button class="btn btn-outline btn-sm" onclick="addDimValue(${id})">Add</button>
    </div>
    <input type="hidden" id="dimVals_${id}">
  `;
  container.appendChild(div);
  // Set values via DOM after appending to avoid HTML attribute quote-escaping issues
  document.getElementById('dimName_' + id).value = name;
  document.getElementById('dimVals_' + id).value = JSON.stringify(values);
  renderDimTags(id);
}

function renderDimTags(id) {
  const arr = JSON.parse(document.getElementById('dimVals_' + id).value || '[]');
  document.getElementById('dimTagsDisplay_' + id).innerHTML = arr.map((v, i) =>
    `<span class="tag">${v}<button onclick="removeDimValue(${id},${i})" title="Remove">×</button></span>`
  ).join('');
}

function addDimValue(id) {
  const inp = document.getElementById('dimValInput_' + id);
  const val = inp.value.trim().toUpperCase();
  if (!val) return;
  const arr = JSON.parse(document.getElementById('dimVals_' + id).value || '[]');
  if (!arr.includes(val)) { arr.push(val); document.getElementById('dimVals_' + id).value = JSON.stringify(arr); }
  renderDimTags(id);
  inp.value = '';
}

function removeDimValue(id, idx) {
  const arr = JSON.parse(document.getElementById('dimVals_' + id).value || '[]');
  arr.splice(idx, 1);
  document.getElementById('dimVals_' + id).value = JSON.stringify(arr);
  renderDimTags(id);
}

function collectDimensions() {
  const result = {};
  document.querySelectorAll('[id^="dim_"]').forEach(block => {
    const id = block.id.replace('dim_', '');
    const name = document.getElementById('dimName_' + id)?.value.trim();
    const vals = JSON.parse(document.getElementById('dimVals_' + id)?.value || '[]');
    if (name && vals.length) result[name] = vals;
  });
  return result;
}

// ── Site column definitions ───────────────────────────────── //

let _colCounter = 0;

function addSiteColDef(name = '', type = 'string', label = '', filterable = false, hidden = false) {
  const id = ++_colCounter;
  const container = document.getElementById('fSiteColsContainer');
  const div = document.createElement('div');
  div.className = 'col-def-block';
  div.id = 'col_' + id;
  div.innerHTML = `
    <div class="col-def-grid">
      <div>
        <label style="font-size:.72rem">Column Name</label>
        <input type="text" id="colName_${id}" value="${name}" placeholder="e.g. tower_type" style="font-family:monospace;font-size:.8rem">
      </div>
      <div>
        <label style="font-size:.72rem">Display Label</label>
        <input type="text" id="colLabel_${id}" value="${label}" placeholder="e.g. Tower Type">
      </div>
      <div>
        <label style="font-size:.72rem">Type</label>
        <select id="colType_${id}">
          <option value="string"${type==='string'?' selected':''}>string</option>
          <option value="integer"${type==='integer'?' selected':''}>integer</option>
          <option value="numeric"${type==='numeric'?' selected':''}>numeric</option>
          <option value="boolean"${type==='boolean'?' selected':''}>boolean</option>
          <option value="date"${type==='date'?' selected':''}>date</option>
        </select>
      </div>
      <div style="display:flex;flex-direction:column;gap:4px">
        <label style="font-size:.72rem">Filterable</label>
        <label class="toggle"><input type="checkbox" id="colFilter_${id}"${filterable?' checked':''}> Yes</label>
      </div>
      <div style="display:flex;flex-direction:column;gap:4px">
        <label style="font-size:.72rem" title="Hide this column in the site list UI">Hidden</label>
        <label class="toggle"><input type="checkbox" id="colHidden_${id}"${hidden?' checked':''}> Yes</label>
      </div>
    </div>
    <div style="text-align:right;margin-top:6px">
      <button class="btn btn-outline btn-sm" style="color:#dc2626;border-color:#fca5a5"
              onclick="document.getElementById('col_${id}').remove()">Remove</button>
    </div>
  `;
  container.appendChild(div);
}

function collectColumnLabels() {
  const result = {};
  ['site_id','region_code','area_code','market_code','phase','progress_pct','status'].forEach(col => {
    const val = document.getElementById('lbl_' + col)?.value.trim();
    if (val) result[col] = val;
  });
  return result;
}

function collectSiteColumns() {
  const result = {};
  document.querySelectorAll('[id^="col_"]').forEach(block => {
    const id = block.id.replace('col_', '');
    const name = document.getElementById('colName_' + id)?.value.trim();
    if (!name) return;
    result[name] = {
      type:       document.getElementById('colType_' + id)?.value || 'string',
      label:      document.getElementById('colLabel_' + id)?.value.trim() || name,
      filterable: document.getElementById('colFilter_' + id)?.checked || false,
      hidden:     document.getElementById('colHidden_' + id)?.checked || false,
    };
  });
  return result;
}

// ── Open forms ────────────────────────────────────────────── //

function openNewForm() {
  _editingId = null;
  clearForm();
  document.getElementById('formTitle').textContent = 'New Project Configuration';
  document.getElementById('fProjectId').removeAttribute('readonly');
  document.getElementById('fProjectId').style.background = '';
  document.getElementById('deleteBtn').classList.add('hidden');
  document.getElementById('refreshBtn').classList.add('hidden');
  document.getElementById('refreshDbBtn').classList.add('hidden');
  document.getElementById('editForm').classList.remove('hidden');
  document.getElementById('emptyState').classList.add('hidden');
  document.getElementById('stickyActions').classList.remove('hidden');
  document.getElementById('statsStrip').classList.add('hidden');
  switchTab('general');
  renderSidebar();
}

function openEditForm(projectId) {
  const p = _projects.find(x => x.project_id === projectId);
  if (!p) return;
  _editingId = projectId;
  clearForm();

  document.getElementById('formTitle').textContent = 'Edit: ' + p.project_id;
  document.getElementById('fProjectId').value = p.project_id;
  document.getElementById('fProjectId').setAttribute('readonly', 'true');
  document.getElementById('fProjectId').style.background = '#f3f4f6';
  document.getElementById('fProjectName').value = p.project_name || '';
  document.getElementById('fIsActive').checked = p.is_active !== false;
  document.getElementById('fCrossFilters').checked = p.cross_filters === true;

  // Functions
  setTags('fFunctions', 'fFunctionsDisplay', p.functions || []);
  // Geo codes
  setTags('fGeoCodes', 'fGeoCodesDisplay', p.geo_codes || [], true);

  // Dimensions — handle both parsed object and JSON string
  const filterDims = typeof p.filter_dimensions === 'string'
    ? JSON.parse(p.filter_dimensions || '{}')
    : (p.filter_dimensions || {});
  for (const [dimName, vals] of Object.entries(filterDims)) {
    addDimensionBlock(dimName, vals);
  }

  // Column labels — handle both parsed object and JSON string
  const lbls = typeof p.column_labels === 'string'
    ? JSON.parse(p.column_labels || '{}')
    : (p.column_labels || {});
  ['site_id','region_code','area_code','market_code','phase','progress_pct','status'].forEach(col => {
    document.getElementById('lbl_' + col).value = lbls[col] || '';
  });

  // Site config
  document.getElementById('fSiteSourceQuery').value = p.site_source_query || '';

  // Site columns — handle both parsed object and JSON string
  const siteCols = typeof p.site_columns === 'string'
    ? JSON.parse(p.site_columns || '{}')
    : (p.site_columns || {});
  for (const [colName, def] of Object.entries(siteCols)) {
    addSiteColDef(colName, def.type || 'string', def.label || colName, def.filterable || false, def.hidden || false);
  }

  // Workflow settings
  if (p.workflow_pipeline_name) {
    const sel = document.getElementById('fWorkflowPipeline');
    // Ensure the option exists
    let found = false;
    for (let i = 0; i < sel.options.length; i++) {
      if (sel.options[i].value === p.workflow_pipeline_name) { found = true; break; }
    }
    if (!found) {
      const opt = document.createElement('option');
      opt.value = p.workflow_pipeline_name;
      opt.textContent = p.workflow_pipeline_name;
      sel.appendChild(opt);
    }
    sel.value = p.workflow_pipeline_name;
  }
  document.getElementById('fWorkflowJoinKey').value = p.workflow_join_key || 'smp_id';
  document.getElementById('fSiteSortBy').value    = p.site_sort_by    || '';
  document.getElementById('fSiteSortOrder').value = p.site_sort_order || 'asc';

  // Insights source
  const srcVal = (p.insights_source || 'workflow').toLowerCase();
  const srcRadio = document.querySelector(`input[name="fInsightsSource"][value="${srcVal === 'kg' ? 'kg' : 'workflow'}"]`);
  if (srcRadio) srcRadio.checked = true;
  document.getElementById('fKgUrlTemplate').value = p.kg_url_template || '';
  onInsightsSourceChange();
  // Restore selected steps
  const wfSteps = typeof p.workflow_selected_steps === 'string'
    ? JSON.parse(p.workflow_selected_steps || '[]')
    : (p.workflow_selected_steps || []);
  if (wfSteps && wfSteps.length) {
    _wfAllSteps = wfSteps;  // use saved steps as the available list
    renderWfSteps(wfSteps.map(s => s.step_id));
  }

  // Restore data browser tables
  document.getElementById('fDataBrowserContainer').innerHTML = '';
  const dbTables = typeof p.data_browser_tables === 'string'
    ? JSON.parse(p.data_browser_tables || '[]')
    : (p.data_browser_tables || []);
  (dbTables || []).forEach(t => {
    addDataBrowserTable(
      t.table_alias || '',
      t.label || '',
      t.source_query || '',
      t.filterable_columns || [],
      t.site_id_column || '',
      t.region_column || '',
      t.market_column || '',
      t.description || '',
      t.derived_fields || {}
    );
  });

  document.getElementById('deleteBtn').classList.remove('hidden');
  // Show refresh buttons based on config
  if (p.site_source_query) document.getElementById('refreshBtn').classList.remove('hidden');
  else document.getElementById('refreshBtn').classList.add('hidden');
  if (dbTables && dbTables.length) document.getElementById('refreshDbBtn').classList.remove('hidden');
  else document.getElementById('refreshDbBtn').classList.add('hidden');

  document.getElementById('editForm').classList.remove('hidden');
  document.getElementById('emptyState').classList.add('hidden');
  document.getElementById('stickyActions').classList.remove('hidden');
  renderStatsStrip(projectId);
  switchTab('general');
  renderSidebar();
}

function cancelEdit() {
  _editingId = null;
  document.getElementById('editForm').classList.add('hidden');
  document.getElementById('emptyState').classList.remove('hidden');
  document.getElementById('stickyActions').classList.add('hidden');
  renderSidebar();
}

function clearForm() {
  document.getElementById('fProjectId').value = '';
  document.getElementById('fProjectName').value = '';
  document.getElementById('fIsActive').checked = true;
  document.getElementById('fCrossFilters').checked = false;
  document.getElementById('fFunctions').value = '[]';
  document.getElementById('fGeoCodes').value = '[]';
  document.getElementById('fFunctionsDisplay').innerHTML = '';
  document.getElementById('fGeoCodesDisplay').innerHTML = '';
  document.getElementById('fDimensionsContainer').innerHTML = '';
  ['site_id','region_code','area_code','market_code','phase','progress_pct','status'].forEach(col => {
    document.getElementById('lbl_' + col).value = '';
  });
  document.getElementById('fSiteSourceQuery').value = '';
  document.getElementById('fSiteColsContainer').innerHTML = '';
  document.getElementById('fSiteSortBy').value = '';
  document.getElementById('fSiteSortOrder').value = 'asc';
  // Workflow
  clearWorkflowConfig();
  // Insights source
  const wfRadio = document.querySelector('input[name="fInsightsSource"][value="workflow"]');
  if (wfRadio) wfRadio.checked = true;
  document.getElementById('fKgUrlTemplate').value = '';
  onInsightsSourceChange();
  document.getElementById('basicError').classList.add('hidden');
  document.getElementById('basicSuccess').classList.add('hidden');
  document.getElementById('refreshStatus').classList.add('hidden');
  document.getElementById('fDataBrowserContainer').innerHTML = '';
  _dimCounter = 0;
  _colCounter = 0;
  _dbCounter = 0;
}

// ── Workflow helpers ──────────────────────────────────────── //

let _wfAllSteps = [];  // all enabled steps fetched from API

async function loadPipelines() {
  const btn = document.getElementById('loadPipelinesBtn');
  const sel = document.getElementById('fWorkflowPipeline');
  const prev = sel.value;
  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>';
  try {
    const list = await apiFetch('/api/v1/sites/workflows/pipelines', 'GET');
    // Keep the first "None" option, clear rest
    while (sel.options.length > 1) sel.remove(1);
    list.forEach(name => {
      const opt = document.createElement('option');
      opt.value = name; opt.textContent = name;
      sel.appendChild(opt);
    });
    sel.value = prev || '';
  } catch(e) {
    const err = document.getElementById('basicError');
    err.textContent = 'Failed to load pipelines: ' + e.message;
    err.classList.remove('hidden');
  } finally {
    btn.disabled = false; btn.textContent = 'Load Pipelines';
  }
}

async function loadPipelineSteps() {
  const pipeline = document.getElementById('fWorkflowPipeline').value;
  if (!pipeline) { alert('Select a pipeline first.'); return; }
  const btn = document.getElementById('loadStepsBtn');
  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>';
  try {
    const data = await apiFetch('/api/v1/sites/workflows/pipelines/' + encodeURIComponent(pipeline) + '/steps', 'GET');
    _wfAllSteps = data.enabled_steps || [];
    renderWfSteps();
  } catch(e) {
    const err = document.getElementById('basicError');
    err.textContent = 'Failed to load steps: ' + e.message;
    err.classList.remove('hidden');
  } finally {
    btn.disabled = false; btn.textContent = 'Load Steps';
  }
}

function renderWfSteps(selectedIds) {
  const container = document.getElementById('wfStepsContainer');
  const section = document.getElementById('wfStepsSection');
  if (!_wfAllSteps.length) {
    section.classList.add('hidden');
    container.innerHTML = '';
    return;
  }
  section.classList.remove('hidden');
  const selSet = new Set((selectedIds || []).map(Number));
  container.innerHTML = _wfAllSteps.map(s => {
    const checked = selSet.size ? (selSet.has(s.step_id) ? 'checked' : '') : '';
    return '<label style="display:flex;align-items:center;gap:8px;padding:5px 4px;border-bottom:1px solid #f1f5f9;cursor:pointer">'
      + '<input type="checkbox" class="wf-step-cb" data-step-id="' + s.step_id + '" '
      + 'data-step-name="' + (s.step_name||'').replace(/"/g,'&quot;') + '" '
      + 'data-phase-name="' + (s.phase_name||'').replace(/"/g,'&quot;') + '" '
      + checked + '>'
      + '<span><strong>Step ' + s.step_id + ':</strong> ' + (s.step_name||'Unnamed')
      + ' <span style="color:#6b7280;font-size:.78rem">(Phase: ' + (s.phase_name||'—') + ')</span></span>'
      + '</label>';
  }).join('');
  updateWfStepCount();
}

function updateWfStepCount() {
  const total = document.querySelectorAll('.wf-step-cb').length;
  const checked = document.querySelectorAll('.wf-step-cb:checked').length;
  document.getElementById('wfStepCount').textContent = checked + ' of ' + total + ' selected';
}

// Delegate change events for step checkboxes
document.addEventListener('change', function(e) {
  if (e.target.classList.contains('wf-step-cb')) updateWfStepCount();
});

function wfSelectAll() {
  document.querySelectorAll('.wf-step-cb').forEach(cb => cb.checked = true);
  updateWfStepCount();
}
function wfClearAll() {
  document.querySelectorAll('.wf-step-cb').forEach(cb => cb.checked = false);
  updateWfStepCount();
}

function collectWorkflowSelectedSteps() {
  const cbs = document.querySelectorAll('.wf-step-cb:checked');
  if (!cbs.length) return null;
  return Array.from(cbs).map(cb => ({
    step_id: parseInt(cb.dataset.stepId, 10),
    step_name: cb.dataset.stepName,
    phase_name: cb.dataset.phaseName,
  }));
}

function clearWorkflowConfig() {
  document.getElementById('fWorkflowPipeline').value = '';
  document.getElementById('fWorkflowJoinKey').value = 'smp_id';
  _wfAllSteps = [];
  document.getElementById('wfStepsContainer').innerHTML = '';
  document.getElementById('wfStepsSection').classList.add('hidden');
  document.getElementById('wfStepCount').textContent = '';
}

function onInsightsSourceChange() {
  const checked = document.querySelector('input[name="fInsightsSource"]:checked');
  const isKg = checked && checked.value === 'kg';
  document.getElementById('kgFieldsSection').classList.toggle('hidden', !isKg);
}

// ── Data Browser Table blocks ─────────────────────────────── //

let _dbCounter = 0;

function addDataBrowserTable(alias = '', label = '', sourceQuery = '', filterableCols = [], siteIdColumn = '', regionColumn = '', marketColumn = '', description = '', derivedFields = {}) {
  _dbCounter++;
  const container = document.getElementById('fDataBrowserContainer');
  const div = document.createElement('div');
  div.className = 'db-table-block';
  div.style.cssText = 'border:1px solid #e2e8f0;border-radius:6px;padding:10px;margin-bottom:10px;background:#fafafa';
  div.innerHTML = `
    <div style="display:flex;gap:8px;margin-bottom:6px;align-items:flex-end;flex-wrap:wrap">
      <div style="flex:1;min-width:140px">
        <label style="font-size:.75rem">Table Alias</label>
        <input type="text" class="db-alias" value="${alias}" placeholder="e.g. vendor_tracker" style="font-size:.85rem">
      </div>
      <div style="flex:1;min-width:140px">
        <label style="font-size:.75rem">Display Label</label>
        <input type="text" class="db-label" value="${label}" placeholder="e.g. Vendor Tracker" style="font-size:.85rem">
      </div>
      <button class="btn btn-outline btn-sm" style="color:#dc2626;border-color:#dc2626;height:32px" onclick="this.closest('.db-table-block').remove()">Remove</button>
    </div>
    <div style="margin-bottom:6px">
      <label style="font-size:.75rem">Source SQL Query</label>
      <textarea class="db-source-query" rows="3" placeholder="SELECT * FROM schema.table_name" style="font-size:.82rem;font-family:monospace">${sourceQuery}</textarea>
    </div>
    <div style="margin-bottom:6px">
      <label style="font-size:.75rem">Filterable Columns <span style="color:#6b7280">(comma-separated, leave blank for auto-detect)</span></label>
      <input type="text" class="db-filterable" value="${filterableCols.join(', ')}" placeholder="e.g. vendor_name, region, status" style="font-size:.85rem">
    </div>
    <div style="margin-bottom:6px">
      <label style="font-size:.75rem">Site ID Column <span style="color:#6b7280">(column from the SELECT that identifies a site — leave blank to exclude this table from the unified site index)</span></label>
      <input type="text" class="db-site-id-column" value="${siteIdColumn}" placeholder="e.g. site_id, smp_id, tower_id" style="font-size:.85rem">
    </div>
    <div style="display:flex;gap:8px;margin-bottom:6px">
      <div style="flex:1;min-width:140px">
        <label style="font-size:.75rem">Region Column <span style="color:#6b7280">(optional)</span></label>
        <input type="text" class="db-region-column" value="${regionColumn}" placeholder="e.g. region_code" style="font-size:.85rem">
      </div>
      <div style="flex:1;min-width:140px">
        <label style="font-size:.75rem">Market Column <span style="color:#6b7280">(optional)</span></label>
        <input type="text" class="db-market-column" value="${marketColumn}" placeholder="e.g. market_code" style="font-size:.85rem">
      </div>
    </div>
    <div>
      <label style="font-size:.75rem">Process Description <span style="color:#6b7280">(optional — passed to the LLM as context for cross-process site insights)</span></label>
      <textarea class="db-description" rows="2" placeholder="What does this process do? E.g. 'E911 readiness validation — confirms emergency-call routing before integration.'" style="font-size:.82rem">${description}</textarea>
    </div>
    <div style="margin-top:6px">
      <label style="font-size:.75rem">Derived Fields <span style="color:#6b7280">(optional — per-site computed values stored on the unified sites endpoint under derived.&lt;table_alias&gt;)</span></label>
      <div style="font-size:.72rem;color:#6b7280;margin-bottom:4px">
        Each row is one field. SQL vocabulary: <code>row_count</code> (int), <code>rows</code> (jsonb_agg of row_data, ordered by display_order).
        Examples: <code>rows-&gt;0-&gt;&gt;'status'</code>, <code>row_count</code>, <code>CASE WHEN row_count &gt; 0 THEN 'active' ELSE 'inactive' END</code>.
      </div>
      <div class="db-derived-list"></div>
      <button class="btn btn-outline btn-sm" style="margin-top:6px" type="button" onclick="addDerivedFieldRow(this)">+ Add Derived Field</button>
    </div>
  `;
  container.appendChild(div);
  // Hydrate any existing derived fields for this table block
  const listEl = div.querySelector('.db-derived-list');
  Object.entries(derivedFields || {}).forEach(([name, sql]) => {
    _appendDerivedFieldRow(listEl, name, sql);
  });
}

function _appendDerivedFieldRow(listEl, name = '', sql = '') {
  const row = document.createElement('div');
  row.className = 'db-derived-row';
  row.style.cssText = 'display:flex;gap:6px;margin-bottom:4px;align-items:flex-start';
  row.innerHTML = `
    <input type="text" class="db-derived-name" value="${name}" placeholder="field_name"
           style="flex:0 0 180px;font-family:monospace;font-size:.82rem">
    <textarea class="db-derived-sql" rows="1" placeholder="SQL expression"
              style="flex:1;font-family:monospace;font-size:.82rem">${sql}</textarea>
    <button class="btn btn-outline btn-sm" type="button"
            style="color:#dc2626;border-color:#fca5a5;height:32px;flex:0 0 auto"
            onclick="this.closest('.db-derived-row').remove()">Remove</button>
  `;
  listEl.appendChild(row);
}

function addDerivedFieldRow(btn) {
  const listEl = btn.parentElement.querySelector('.db-derived-list');
  if (listEl) _appendDerivedFieldRow(listEl);
}

function collectDataBrowserTables() {
  const blocks = document.querySelectorAll('.db-table-block');
  if (!blocks.length) return null;
  const tables = [];
  blocks.forEach(block => {
    const alias = block.querySelector('.db-alias').value.trim();
    const label = block.querySelector('.db-label').value.trim();
    const sourceQuery = block.querySelector('.db-source-query').value.trim();
    const filterableRaw = block.querySelector('.db-filterable').value.trim();
    const siteIdColumn = block.querySelector('.db-site-id-column').value.trim();
    const regionColumn = block.querySelector('.db-region-column').value.trim();
    const marketColumn = block.querySelector('.db-market-column').value.trim();
    const description = block.querySelector('.db-description').value.trim();
    const derivedFields = {};
    block.querySelectorAll('.db-derived-row').forEach(row => {
      const name = row.querySelector('.db-derived-name')?.value.trim();
      const sql  = row.querySelector('.db-derived-sql')?.value.trim();
      if (name && sql) derivedFields[name] = sql;
    });
    if (!alias || !sourceQuery) return;
    const filterable = filterableRaw
      ? filterableRaw.split(',').map(s => s.trim()).filter(Boolean)
      : [];
    tables.push({
      table_alias: alias,
      label: label || alias,
      source_query: sourceQuery,
      filterable_columns: filterable.length ? filterable : null,
      site_id_column: siteIdColumn || null,
      region_column: regionColumn || null,
      market_column: marketColumn || null,
      description: description || null,
      derived_fields: Object.keys(derivedFields).length ? derivedFields : null,
    });
  });
  return tables.length ? tables : null;
}

// ── Save ──────────────────────────────────────────────────── //

async function saveProject() {
  const btn = document.getElementById('saveBtn');
  const err = document.getElementById('basicError');
  const suc = document.getElementById('basicSuccess');
  err.classList.add('hidden'); suc.classList.add('hidden');

  const projectId   = document.getElementById('fProjectId').value.trim();
  const projectName = document.getElementById('fProjectName').value.trim();
  if (!projectId)   { err.textContent = 'Project ID is required.'; err.classList.remove('hidden'); return; }
  if (!projectName) { err.textContent = 'Project Name is required.'; err.classList.remove('hidden'); return; }

  const body = {
    project_id:         projectId,
    project_name:       projectName,
    is_active:          document.getElementById('fIsActive').checked,
    cross_filters:      document.getElementById('fCrossFilters').checked,
    functions:          JSON.parse(document.getElementById('fFunctions').value || '[]'),
    geo_codes:          JSON.parse(document.getElementById('fGeoCodes').value || '[]'),
    filter_dimensions:  collectDimensions(),
    site_source_query:  document.getElementById('fSiteSourceQuery').value.trim() || null,
    column_labels:      collectColumnLabels(),
    site_columns:       collectSiteColumns(),
    workflow_pipeline_name:  document.getElementById('fWorkflowPipeline').value || null,
    workflow_join_key:       document.getElementById('fWorkflowJoinKey').value.trim() || 'smp_id',
    workflow_selected_steps: collectWorkflowSelectedSteps(),
    site_sort_by:    document.getElementById('fSiteSortBy').value.trim() || null,
    site_sort_order: document.getElementById('fSiteSortOrder').value || 'asc',
    data_browser_tables: collectDataBrowserTables(),
    insights_source:  (document.querySelector('input[name="fInsightsSource"]:checked')?.value || 'workflow'),
    kg_url_template:  document.getElementById('fKgUrlTemplate').value.trim() || null,
  };

  // Validate KG fields when KG is selected
  if (body.insights_source === 'kg') {
    if (!body.kg_url_template) {
      err.textContent = 'KG URL Template is required when Insights Source is Knowledge Graph.';
      err.classList.remove('hidden');
      return;
    }
    if (!body.kg_url_template.includes('{site_id}')) {
      err.textContent = 'KG URL Template must contain the literal placeholder {site_id}.';
      err.classList.remove('hidden');
      return;
    }
  }

  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Saving…';
  try {
    await apiFetch('/api/v1/project-config/', 'POST', body);
    suc.textContent = `Project '${projectId}' saved successfully.`;
    suc.classList.remove('hidden');
    _editingId = projectId;
    await loadProjects();
    await loadStats();
    openEditForm(projectId);
  } catch(e) {
    err.textContent = e.message;
    err.classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Save Configuration';
  }
}

// ── Delete ────────────────────────────────────────────────── //

async function deleteProject() {
  const pid = document.getElementById('fProjectId').value.trim();
  if (!confirm(`Delete project '${pid}'? This also removes all site data for this project.`)) return;
  const btn = document.getElementById('deleteBtn');
  btn.disabled = true;
  try {
    await apiFetch('/api/v1/project-config/' + encodeURIComponent(pid), 'DELETE');
    _projects = _projects.filter(p => p.project_id !== pid);
    cancelEdit();
    renderSidebar();
  } catch(e) {
    const err = document.getElementById('basicError');
    err.textContent = e.message; err.classList.remove('hidden');
  } finally { btn.disabled = false; }
}

// ── Refresh sites ─────────────────────────────────────────── //

async function triggerSiteRefresh() {
  const pid = document.getElementById('fProjectId').value.trim();
  const btn = document.getElementById('refreshBtn');
  const status = document.getElementById('refreshStatus');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Starting…';
  status.classList.add('hidden');
  try {
    const res = await apiFetch('/api/v1/sites/' + encodeURIComponent(pid) + '/refresh', 'POST');
    status.textContent = `✓ Site refresh started (job: ${res.job_id}). ${res.message}`;
    status.classList.remove('hidden');
  } catch(e) {
    const err = document.getElementById('basicError');
    err.textContent = 'Refresh failed: ' + e.message; err.classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '↻ Refresh Sites';
  }
}

// ── Refresh data browser ─────────────────────────────────── //

async function triggerDataBrowserRefresh() {
  const pid = document.getElementById('fProjectId').value.trim();
  const btn = document.getElementById('refreshDbBtn');
  const status = document.getElementById('refreshStatus');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Refreshing…';
  status.classList.add('hidden');
  try {
    const res = await apiFetch('/api/v1/data-browser/' + encodeURIComponent(pid) + '/refresh', 'POST');
    status.textContent = '✓ Data browser refresh started. Tables will be updated in the background.';
    status.classList.remove('hidden');
  } catch(e) {
    const err = document.getElementById('basicError');
    err.textContent = 'Data browser refresh failed: ' + e.message; err.classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.innerHTML = '↻ Refresh Data Browser';
  }
}

// ── Boot ──────────────────────────────────────────────────── //
(function() {
  // Single delegated click listener on the sidebar list — survives innerHTML re-renders
  document.getElementById('projectList').addEventListener('click', function(e) {
    const item = e.target.closest('.project-item');
    if (item && item.dataset.pid) openEditForm(item.dataset.pid);
  });

  const key = sessionStorage.getItem(SESSION_KEY);
  if (key) {
    document.getElementById('authModal').classList.add('hidden');
    updateAuthStatusBar();
    loadProjects();
  }
})();
</script>
</body>
</html>
"""


@router.get("/manage", response_class=HTMLResponse, include_in_schema=False)
async def project_config_manager_page():
    """Serves the Project Config Manager UI."""
    return HTMLResponse(content=_MANAGER_HTML)


@router.get("/", response_model=List[ProjectConfigResponse])
async def list_projects(
    is_active: Optional[bool] = None,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """List all project configurations."""
    svc = ProjectConfigService(db)
    rows = await svc.list_projects(is_active=is_active)
    return rows


@router.get("/stats")
async def list_project_stats(
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    Per-project workload stats: KPI count, dimension combos, geo count, and
    total calculations per full refresh (kpis × combos × geos).
    Used by the manager UI to surface project size at a glance.
    """
    pc_table = settings.TABLES["project_config"]
    kpi_table = settings.TABLES["kpi_master"]
    geo_table = settings.TABLES["dim_geography"]

    projects = (await db.execute(text(
        f"SELECT project_id, filter_dimensions, cross_filters, geo_codes "
        f"FROM {pc_table}"
    ))).fetchall()

    kpi_counts_rows = (await db.execute(text(
        f"SELECT unnest(project_ids) AS project_id, COUNT(*) AS kpi_count "
        f"FROM {kpi_table} WHERE is_active = TRUE GROUP BY 1"
    ))).fetchall()
    kpi_count_by_pid = {r.project_id: r.kpi_count for r in kpi_counts_rows}

    total_active_geos = (await db.execute(text(
        f"SELECT COUNT(*) AS n FROM {geo_table} WHERE is_active = TRUE"
    ))).scalar() or 0

    stats: Dict[str, Dict[str, Any]] = {}
    for p in projects:
        fd_raw = p.filter_dimensions
        filter_dims = json.loads(fd_raw) if isinstance(fd_raw, str) else (fd_raw or {})
        combos = ProjectConfigService.build_dimension_combos(
            filter_dimensions=filter_dims,
            cross_filters=bool(p.cross_filters),
        )
        geo_count = len(p.geo_codes) if p.geo_codes else total_active_geos
        kpi_count = int(kpi_count_by_pid.get(p.project_id, 0))
        dim_combos = len(combos)
        stats[p.project_id] = {
            "kpi_count": kpi_count,
            "dim_combos": dim_combos,
            "geo_count": geo_count,
            "total_calcs": kpi_count * dim_combos * geo_count,
        }
    return stats


@router.get("/{project_id}", response_model=ProjectConfigResponse)
async def get_project(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """Get a single project configuration."""
    svc = ProjectConfigService(db)
    row = await svc.get_project(project_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"Project '{project_id}' not found")
    return row


@router.post("/", response_model=ProjectConfigResponse, status_code=201)
async def create_or_update_project(
    config: ProjectConfigCreate,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    Create or update a project configuration (upsert).

    **filter_dimensions** defines the dynamic filter dimensions for this project.
    Each key is a dimension name, and the value is the list of allowed values:
    ```json
    {
        "scope_of_work": ["NEW_BUILD", "MODIFICATION", "DECOMMISSION"],
        "smp_name": ["SMP_ALPHA", "SMP_BETA"]
    }
    ```

    **cross_filters** controls whether the calculation engine produces the
    cartesian product of all dimension values (TRUE) or only independent
    per-dimension combos (FALSE, default).

    **geo_codes** restricts which geographies this project uses.
    Leave empty to use all active geographies.
    """
    svc = ProjectConfigService(db)
    row = await svc.upsert_project(config.model_dump())
    return row


@router.delete("/{project_id}")
async def delete_project(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """Delete a project configuration."""
    svc = ProjectConfigService(db)
    deleted = await svc.delete_project(project_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Project '{project_id}' not found")
    return {"status": "deleted", "project_id": project_id}


@router.get("/{project_id}/dimension-combos")
async def preview_dimension_combos(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    Preview the dimension combinations that will be calculated for a project.

    Useful for understanding the row multiplier before triggering a calculation.
    """
    svc = ProjectConfigService(db)
    row = await svc.get_project(project_id)
    if not row:
        raise HTTPException(status_code=404, detail=f"Project '{project_id}' not found")

    combos = ProjectConfigService.build_dimension_combos(
        filter_dimensions=row["filter_dimensions"],
        cross_filters=row["cross_filters"],
    )
    dimension_keys = [ProjectConfigService.dimension_key_from_params(c) for c in combos]

    return {
        "project_id": project_id,
        "cross_filters": row["cross_filters"],
        "filter_dimensions": row["filter_dimensions"],
        "total_combos": len(combos),
        "dimension_keys": dimension_keys,
        "combos": combos,
    }
