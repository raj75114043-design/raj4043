import io
import logging
from datetime import date
from typing import Any, Dict, List, Optional

import yaml
from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from fastapi.responses import HTMLResponse, StreamingResponse
from pydantic import BaseModel, Field, model_validator
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.security import verify_api_key
from app.models.kpi_models import AggregationMethod, DisplayFormat, GeoLevel, KPICategory, KPITag
from app.services.kpi_builder_service import KPIBuilderService

router = APIRouter(prefix="/api/v1/kpi-builder", tags=["KPI Builder"])
logger = logging.getLogger(__name__)


# ------------------------------------------------------------------ #
# Request / Response models                                            #
# ------------------------------------------------------------------ #

class KPIGenerateRequest(BaseModel):
    """
    Everything the developer provides so the LLM can build a proper KPI template.

    Specify a dedicated source-table column for each geography level your KPI
    applies to. The LLM uses these to replace literal filter values with the
    correct bind parameters (:geo_code, :area_code, :region_code).
    """
    raw_sql: str = Field(
        ...,
        description=(
            "Your SQL query with literal filter values — the LLM will replace them "
            "with the correct bind parameters (:geo_code, :start_date, etc.)."
        ),
        examples=["SELECT SUM(revenue) AS val, COUNT(*) AS cnt FROM sales_fact "
                  "WHERE market_code = 'US_WEST' AND txn_date BETWEEN '2024-01-01' AND '2024-01-31'"],
    )
    time_column: Optional[str] = Field(
        None,
        description="Column used for the date/time filter in raw_sql (e.g. 'txn_date'). Omit if the KPI has no date filter.",
    )

    # Per-level geography column names
    market_column: Optional[str] = Field(
        None,
        description="Source column that holds the MARKET-level geo code (e.g. 'market_code'). Maps to :geo_code.",
    )
    area_column: Optional[str] = Field(
        None,
        description="Source column that holds the AREA-level geo code (e.g. 'area_name'). Maps to :area_code.",
    )
    region_column: Optional[str] = Field(
        None,
        description="Source column that holds the REGION-level geo code (e.g. 'region'). Maps to :region_code.",
    )

    kpi_name: str = Field(..., max_length=200, description="Human-readable KPI name.")
    kpi_category: str = Field(..., description="Any category string, e.g. HEALTH, PERFORMANCE, Site_Count, etc.")
    applicable_geo_levels: List[GeoLevel] = Field(
        ...,
        min_length=1,
        description="Geography levels this KPI should be calculated at.",
    )
    display_format: DisplayFormat = DisplayFormat.NUMBER
    unit_symbol: Optional[str] = Field(None, description="e.g. '$', '%', 'days'")
    decimal_places: int = Field(default=2, ge=0, le=6)
    aggregation_method: AggregationMethod = AggregationMethod.SUM
    aggregation_column: Optional[str] = None
    source_tables: List[str] = Field(
        default_factory=list,
        description="Source table names referenced in raw_sql (informational).",
    )
    filter_dimensions: Optional[Dict[str, List[str]]] = Field(
        None,
        description=(
            "Dimension filters for this project (from project config). "
            "Passed to the LLM so it generates case-insensitive dimension WHERE clauses. "
            "E.g. {'scope_of_work': ['PDM', 'SECOE', 'ALL']}"
        ),
    )
    project_ids: Optional[List[str]] = Field(None, description="Restrict KPI to these projects.")
    level_ids: Optional[List[str]] = Field(None, description="Restrict KPI to these levels (HOME, PHASE, SITE).")
    function_ids: Optional[List[str]] = Field(None, description="Restrict KPI to these functions.")
    priority: int = Field(default=100, ge=1, le=1000)
    refresh_frequency: str = "DAILY"
    parent_kpi_id: Optional[str] = Field(None, description="If this KPI is a sub-metric, set the parent KPI ID here.")
    kpi_tag: Optional[str] = Field(
        None,
        description="Frontend icon/widget hint: TOTAL | TREND | RATE | PERCENTAGE | COUNT | TARGET | GAUGE | AVERAGE | COMPARISON",
    )

    @model_validator(mode="after")
    def at_least_one_geo_column(self) -> "KPIGenerateRequest":
        levels = {lvl.value for lvl in self.applicable_geo_levels}
        missing = []
        if "MARKET" in levels and not self.market_column:
            missing.append("market_column (required when MARKET is in applicable_geo_levels)")
        if "AREA" in levels and not self.area_column:
            missing.append("area_column (required when AREA is in applicable_geo_levels)")
        if "REGION" in levels and not self.region_column:
            missing.append("region_column (required when REGION is in applicable_geo_levels)")
        if missing:
            raise ValueError("Missing geo columns: " + "; ".join(missing))
        return self


class KPIRegisterRequest(BaseModel):
    """
    Full KPI definition ready to be saved to kpi_master.

    Typically populated from the `proposed_kpi` returned by POST /generate,
    after the developer has reviewed / adjusted it.
    """
    kpi_id: str = Field(..., max_length=50, description="Unique ID, e.g. KPI_TOTAL_REVENUE")
    kpi_code: str = Field(..., max_length=50, description="Short code, e.g. TOTAL_REVENUE")
    kpi_name: str = Field(..., max_length=200)
    kpi_description: Optional[str] = None
    kpi_category: str = Field(..., description="FINANCIAL | OPERATIONAL | QUALITY | DELIVERY")
    applicable_geo_levels: List[str] = Field(..., description="OVERALL | REGION | AREA | MARKET")
    sql_query_template: str = Field(
        ...,
        description=(
            "Parameterised SQL using :geo_code, :region_code, :area_code, "
            ":geo_level, :start_date, :end_date. Must return kpi_value and record_count."
        ),
    )
    aggregation_method: str = "SUM"
    aggregation_column: Optional[str] = None
    display_format: str = "NUMBER"
    decimal_places: int = Field(default=2, ge=0, le=6)
    unit_symbol: Optional[str] = None
    source_tables: List[str] = Field(default_factory=list)
    project_ids: Optional[List[str]] = None
    level_ids: Optional[List[str]] = None
    function_ids: Optional[List[str]] = None
    priority: int = Field(default=100, ge=1, le=1000)
    refresh_frequency: str = "DAILY"
    is_active: bool = True
    parent_kpi_id: Optional[str] = Field(
        None,
        description=(
            "If set, this KPI is a sub-metric displayed beneath the parent KPI card. "
            "Must be the kpi_id of an already-registered top-level KPI."
        ),
    )
    kpi_tag: Optional[str] = Field(
        None,
        description="Frontend icon/widget hint (TOTAL, TREND, RATE, PERCENTAGE, COUNT, TARGET, GAUGE, AVERAGE, COMPARISON).",
    )
    drilldown_sql: Optional[str] = Field(
        None,
        description=(
            "Optional SQL returning detail rows; executed server-side by GET /kpi/{kpi_id}/detail. "
            "One drill-down table per KPI (no geography filtering). "
            "Available params: :start_date, :end_date"
        ),
    )


# ------------------------------------------------------------------ #
# HTML Form UI                                                         #
# ------------------------------------------------------------------ #

_FORM_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Dynamic Dashboard Builder</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; }
  body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
         background: #f0f2f5; margin: 0; padding: 24px; color: #1a1a2e; }
  .container { max-width: 880px; margin: 0 auto; }
  h1 { font-size: 1.6rem; font-weight: 700; margin: 0 0 4px; }
  .subtitle { color: #666; margin: 0 0 24px; font-size: .9rem; }
  .card { background: #fff; border-radius: 10px; padding: 28px;
          margin-bottom: 20px; box-shadow: 0 1px 4px rgba(0,0,0,.08); }
  .card-title { font-size: 1rem; font-weight: 700; margin: 0 0 18px;
                display: flex; align-items: center; gap: 8px; }
  .badge { background: #4f46e5; color: #fff; border-radius: 50%;
           width: 22px; height: 22px; display: inline-flex;
           align-items: center; justify-content: center; font-size: .75rem; }
  .badge.done { background: #16a34a; }
  .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  .grid3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; }
  .span2 { grid-column: span 2; }
  label { display: block; font-size: .82rem; font-weight: 600;
          color: #444; margin-bottom: 5px; }
  label .opt { font-weight: 400; color: #888; margin-left: 4px; }
  input[type=text], input[type=password], select, textarea {
    width: 100%; padding: 9px 12px; border: 1px solid #d1d5db;
    border-radius: 6px; font-size: .9rem; font-family: inherit;
    transition: border-color .15s; background: #fff; }
  input:focus, select:focus, textarea:focus {
    outline: none; border-color: #4f46e5; box-shadow: 0 0 0 3px rgba(79,70,229,.12); }
  textarea { resize: vertical; font-family: 'Courier New', monospace; font-size: .82rem; }
  .checkbox-group { display: flex; flex-wrap: wrap; gap: 10px; }
  .checkbox-group label { display: flex; align-items: center; gap: 6px;
    font-weight: 400; font-size: .88rem; cursor: pointer;
    background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 6px;
    padding: 7px 12px; transition: background .12s; }
  .checkbox-group label:hover { background: #ede9fe; border-color: #a5b4fc; }
  .checkbox-group input[type=checkbox] { width: 15px; height: 15px; accent-color: #4f46e5; }
  .geo-col-section { margin-top: 16px; padding: 16px;
    background: #f8f9ff; border-radius: 8px; border: 1px solid #e0e7ff; }
  .geo-col-title { font-size: .82rem; font-weight: 600; color: #4f46e5; margin-bottom: 12px; }
  .btn { padding: 10px 22px; border-radius: 7px; border: none; font-size: .9rem;
         font-weight: 600; cursor: pointer; transition: opacity .15s, transform .1s; }
  .btn:active { transform: scale(.98); }
  .btn:disabled { opacity: .45; cursor: not-allowed; }
  .btn-primary { background: #4f46e5; color: #fff; }
  .btn-primary:hover:not(:disabled) { background: #4338ca; }
  .btn-success { background: #16a34a; color: #fff; }
  .btn-success:hover:not(:disabled) { background: #15803d; }
  .btn-outline { background: #fff; color: #4f46e5; border: 1.5px solid #4f46e5; }
  .btn-outline:hover { background: #ede9fe; }
  .btn-sm { padding: 6px 14px; font-size: .82rem; }
  .btn-danger-sm { background: #fff; color: #b91c1c; border: 1.5px solid #fca5a5;
                   padding: 6px 14px; font-size: .82rem; border-radius: 6px;
                   cursor: pointer; font-weight: 600; }
  .btn-danger-sm:hover { background: #fef2f2; }
  .row { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
  .hint { font-size: .78rem; color: #6b7280; margin-top: 4px; }
  .error { background: #fef2f2; border: 1px solid #fca5a5;
           color: #b91c1c; padding: 12px 16px; border-radius: 8px;
           font-size: .88rem; margin-top: 12px; }
  .success-box { background: #f0fdf4; border: 1px solid #86efac;
                 color: #166534; padding: 16px; border-radius: 8px; font-size: .88rem; }
  .notes-box { background: #fffbeb; border: 1px solid #fcd34d;
               color: #92400e; padding: 12px 16px; border-radius: 8px;
               font-size: .84rem; margin-bottom: 16px; }
  .notes-box strong { display: block; margin-bottom: 4px; }
  .info-box { background: #eff6ff; border: 1px solid #bfdbfe;
              color: #1e40af; padding: 12px 16px; border-radius: 8px; font-size: .84rem; }
  .divider { border: none; border-top: 1px solid #e5e7eb; margin: 20px 0; }
  .hidden { display: none !important; }
  .spinner { display: inline-block; width: 14px; height: 14px;
             border: 2px solid rgba(255,255,255,.4); border-top-color: #fff;
             border-radius: 50%; animation: spin .6s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
  .step-done .badge { background: #16a34a; }
  code { background: #f3f4f6; padding: 1px 5px; border-radius: 4px;
         font-family: monospace; font-size: .85em; }
  /* Auth modal */
  .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.45);
                   display: flex; align-items: center; justify-content: center;
                   z-index: 1000; padding: 24px; }
  .auth-card { background: #fff; border-radius: 14px; padding: 36px 32px;
               max-width: 400px; width: 100%;
               box-shadow: 0 8px 32px rgba(0,0,0,.18); text-align: center; }
  .auth-icon { font-size: 2.2rem; margin-bottom: 12px; }
  .auth-card h2 { font-size: 1.2rem; font-weight: 700; margin: 0 0 6px; color: #1a1a2e; }
  .auth-card p  { font-size: .86rem; color: #666; margin: 0 0 20px; }
  .auth-card input { text-align: center; letter-spacing: .05em; margin-bottom: 12px; }
  /* Top bar */
  .top-bar { display: flex; align-items: center; justify-content: space-between;
             margin-bottom: 8px; }
  .top-bar h1 { margin: 0; }
  .auth-badge { display: flex; align-items: center; gap: 8px; font-size: .82rem;
                color: #16a34a; font-weight: 600; }
  .auth-badge span { background: #f0fdf4; border: 1px solid #86efac;
                     padding: 4px 10px; border-radius: 20px; }
  /* Collapsible info panel */
  .info-toggle { width: 100%; text-align: left; background: #eff6ff;
                 border: 1px solid #bfdbfe; border-radius: 8px;
                 padding: 10px 14px; cursor: pointer; font-size: .85rem;
                 font-weight: 600; color: #1e40af; display: flex;
                 justify-content: space-between; align-items: center; margin-bottom: 4px; }
  .info-toggle:hover { background: #dbeafe; }
  .info-panel { background: #eff6ff; border: 1px solid #bfdbfe; border-top: none;
                border-radius: 0 0 8px 8px; padding: 16px; font-size: .83rem;
                color: #1e3a8a; margin-bottom: 20px; }
  .steps-row { display: flex; gap: 12px; margin-bottom: 14px; flex-wrap: wrap; }
  .step-pill { background: #fff; border: 1px solid #bfdbfe; border-radius: 8px;
               padding: 10px 14px; flex: 1; min-width: 140px; }
  .step-pill strong { display: block; margin-bottom: 4px; color: #4f46e5; font-size: .8rem; }
  /* Param table */
  .param-table { width: 100%; border-collapse: collapse; font-size: .8rem; margin-top: 10px; }
  .param-table th { background: #dbeafe; padding: 6px 10px; text-align: left; font-weight: 700; }
  .param-table td { padding: 5px 10px; border-bottom: 1px solid #bfdbfe; vertical-align: top; }
  .param-table tr:last-child td { border-bottom: none; }
  .param-table code { background: #fff; border: 1px solid #bfdbfe; }
  /* Section separator */
  .section-label { font-size: .72rem; font-weight: 700; text-transform: uppercase;
                   letter-spacing: .06em; color: #9ca3af; margin: 20px 0 12px; }
  /* Info icon tooltip */
  .info-icon { display: inline-flex; align-items: center; justify-content: center;
               width: 15px; height: 15px; border-radius: 50%;
               background: #e0e7ff; color: #4f46e5; font-size: .68rem; font-weight: 700;
               cursor: help; margin-left: 5px; font-style: normal;
               position: relative; vertical-align: middle; line-height: 1;
               flex-shrink: 0; user-select: none; }
  .info-icon::after { content: attr(data-tip);
               position: absolute; bottom: calc(100% + 8px); left: 50%;
               transform: translateX(-50%);
               background: #1e293b; color: #f1f5f9; padding: 9px 12px;
               border-radius: 7px; font-size: .76rem; font-weight: 400;
               white-space: normal; width: 260px; line-height: 1.5;
               pointer-events: none; opacity: 0; transition: opacity .15s;
               z-index: 200; text-align: left;
               box-shadow: 0 4px 16px rgba(0,0,0,.22); }
  .info-icon:hover::after { opacity: 1; }
  /* Keep icon from overflowing left edge on first column */
  .info-icon.tip-right::after { left: 0; transform: none; }
</style>
</head>
<body>

<!-- ── Auth Modal (shown on demand) ──────────────────────────── -->
<div class="modal-overlay hidden" id="authModal">
  <div class="auth-card">
    <div class="auth-icon">🔐</div>
    <h2>Authentication required</h2>
    <p>Enter your API key to continue.<br>It is validated against the server and stored for this session only.</p>
    <input type="password" id="authKey" placeholder="Paste your X-API-Key here"
           onkeydown="if(event.key==='Enter') authenticate()">
    <div id="authError" class="error hidden" style="text-align:left;margin-bottom:12px"></div>
    <div class="row" style="justify-content:center;gap:10px">
      <button class="btn btn-primary" style="flex:1" onclick="authenticate()" id="authBtn">Authenticate</button>
      <button class="btn btn-outline" onclick="closeAuthModal()">Cancel</button>
    </div>
  </div>
</div>

<!-- ── Shared Nav ─────────────────────────────────────────────── -->
<nav style="background:#0f172a;padding:0 24px;display:flex;align-items:center;gap:4px;height:44px;position:sticky;top:0;z-index:100;box-shadow:0 1px 3px rgba(0,0,0,.3)">
  <span style="color:#94a3b8;font-size:.75rem;font-weight:700;letter-spacing:.08em;margin-right:12px">DYNAMIC DASHBOARD BUILDER</span>
  <a href="/api/v1/project-config/manage" style="color:#cbd5e1;text-decoration:none;font-size:.82rem;padding:6px 12px;border-radius:4px;transition:background .15s" onmouseover="this.style.background='#1e293b'" onmouseout="this.style.background='transparent'">Project Config</a>
  <a href="/api/v1/kpi-builder/form" style="color:#fff;text-decoration:none;font-size:.82rem;padding:6px 12px;border-radius:4px;background:#1e40af">KPI Builder</a>
  <a href="/api/v1/kpi-builder/manage" style="color:#cbd5e1;text-decoration:none;font-size:.82rem;padding:6px 12px;border-radius:4px;transition:background .15s" onmouseover="this.style.background='#1e293b'" onmouseout="this.style.background='transparent'">KPI Manager</a>
  <a href="/api/v1/guide" style="color:#cbd5e1;text-decoration:none;font-size:.82rem;padding:6px 12px;border-radius:4px;transition:background .15s" onmouseover="this.style.background='#1e293b'" onmouseout="this.style.background='transparent'">Guide</a>
  <span style="flex:1"></span>
  <a href="/docs" target="_blank" style="color:#64748b;text-decoration:none;font-size:.75rem;padding:4px 8px">API Docs ↗</a>
</nav>

<!-- ── Main App ───────────────────────────────────────────────── -->
<div class="container" id="appContainer">
  <div class="top-bar">
    <div>
      <h1>Dynamic Dashboard Builder</h1>
      <p class="subtitle" style="margin-bottom:0">Register new KPIs in minutes — paste your SQL, let the AI parameterise it, and it appears on the live dashboard after the next calculation run.</p>
    </div>
    <div style="text-align:right;flex-shrink:0;margin-left:16px" id="authStatusBar">
      <!-- populated by JS once authenticated -->
    </div>
  </div>
  <br>

  <!-- ── How it works (collapsible) ───────────────────────────── -->
  <button class="info-toggle" onclick="toggleInfo()">
    ℹ️ &nbsp;How it works &amp; SQL parameter reference
    <span id="infoArrow">▼</span>
  </button>
  <div class="info-panel hidden" id="infoPanel">
    <div class="steps-row">
      <div class="step-pill">
        <strong>① Fill in the form</strong>
        Describe your KPI — name, category, geography levels, and paste your raw SQL with real filter values.
      </div>
      <div class="step-pill">
        <strong>② AI generates the template</strong>
        The LLM replaces literal values with bind params (<code>:geo_code</code>, <code>:start_date</code>, etc.) so the engine can execute it for any geo and date range.
      </div>
      <div class="step-pill">
        <strong>③ Review &amp; register</strong>
        Check the generated SQL, optionally add a drill-down query, then click Register. The KPI is live after the next calculation run.
      </div>
    </div>
    <strong style="display:block;margin-bottom:6px">Available SQL bind parameters</strong>
    <table class="param-table">
      <tr><th>Parameter</th><th>Type</th><th>Description</th></tr>
      <tr><td><code>:start_date</code></td><td>date</td><td>Period start date (inclusive) — injected from the calculation schedule</td></tr>
      <tr><td><code>:end_date</code></td><td>date</td><td>Period end date (inclusive)</td></tr>
      <tr><td><code>:geo_code</code></td><td>string</td><td>Natural key of the <em>current</em> geography, e.g. <code>US_WEST</code> — use in source-data filters</td></tr>
      <tr><td><code>:geo_level</code></td><td>string</td><td><code>OVERALL | REGION | AREA | MARKET</code> — useful for CASE WHEN branching</td></tr>
      <tr><td><code>:region_code</code></td><td>string</td><td>Parent region's geo_code — NULL at OVERALL level</td></tr>
      <tr><td><code>:area_code</code></td><td>string</td><td>Parent area's geo_code — NULL at OVERALL/REGION level</td></tr>
      <tr><td><code>:geo_id</code> / <code>:region_id</code> / <code>:area_id</code></td><td>string</td><td>Surrogate FKs — prefer geo_code variants for source-data filters</td></tr>
    </table>
    <div style="margin-top:10px;padding:8px 10px;background:#fff;border-radius:6px;border:1px solid #bfdbfe">
      <strong>Required output columns:</strong>&nbsp;
      <code>kpi_value</code> (NUMERIC) &nbsp;·&nbsp; <code>record_count</code> (INTEGER) &nbsp;·&nbsp; Query must return exactly <strong>one row</strong>.
    </div>
  </div>

  <!-- ── Step 1: KPI Details ───────────────────────────────────── -->
  <div class="card" id="step1Card">
    <div class="card-title"><span class="badge" id="b1">1</span> KPI Details</div>

    <div class="grid2" style="margin-bottom:16px">
      <div>
        <label>KPI Name <span style="color:red">*</span> <i class="info-icon" data-tip="Short, descriptive name shown on the dashboard card.">i</i></label>
        <input type="text" id="kpiName" placeholder="e.g. Total Revenue">
      </div>
      <div>
        <label>Parent KPI ID <span class="opt">optional</span> <i class="info-icon" data-tip="Set only if this is a sub-metric shown below another KPI card. Leave blank for a standalone card.">i</i></label>
        <input type="text" id="parentKpiId" placeholder="e.g. KPI_TOTAL_SITES">
      </div>
    </div>

    <div class="grid3" style="margin-bottom:16px">
      <div>
        <label>KPI Category <span style="color:red">*</span> <i class="info-icon" data-tip="Free text — any category that makes sense for your project, e.g. HEALTH, PERFORMANCE, MILESTONE, SITE_COUNT, DELIVERY, QUALITY.">i</i></label>
        <input type="text" id="kpiCategory" placeholder="e.g. HEALTH, PERFORMANCE, MILESTONE, SITE_COUNT">
      </div>
      <div>
        <label>KPI Tag <span class="opt">optional</span> <i class="info-icon" data-tip="Tells the frontend which widget or icon to render for this KPI card. TOTAL = big aggregate number · TREND = sparkline · RATE = throughput · GAUGE = dial-style.">i</i></label>
        <select id="kpiTag">
          <option value="">— none —</option>
          <option value="TOTAL">TOTAL — big aggregate number</option>
          <option value="TREND">TREND — time-series / sparkline</option>
          <option value="RATE">RATE — speed or throughput</option>
          <option value="PERCENTAGE">PERCENTAGE — ratio or share</option>
          <option value="COUNT">COUNT — integer count</option>
          <option value="TARGET">TARGET — goal tracking</option>
          <option value="GAUGE">GAUGE — dial-style display</option>
          <option value="AVERAGE">AVERAGE — mean value</option>
          <option value="COMPARISON">COMPARISON — side-by-side</option>
        </select>
      </div>
      <div>
        <label>Display Format <i class="info-icon" data-tip="Controls how the value is rendered on the dashboard. Combine with Unit Symbol for custom labels (e.g. CURRENCY + $ prefix).">i</i></label>
        <select id="displayFormat">
          <option value="NUMBER">NUMBER — plain number</option>
          <option value="CURRENCY">CURRENCY — with $ symbol</option>
          <option value="PERCENTAGE">PERCENTAGE — appends %</option>
          <option value="DAYS">DAYS — appends "days"</option>
        </select>
      </div>
    </div>

    <div class="grid3" style="margin-bottom:16px">
      <div>
        <label>Unit Symbol <span class="opt">optional</span> <i class="info-icon" data-tip="Appended or prepended to the formatted value, e.g. '$', '%', 'days', 'sites'.">i</i></label>
        <input type="text" id="unitSymbol" placeholder="$, %, days, sites …">
      </div>
      <div>
        <label>Decimal Places <i class="info-icon" data-tip="0–6 decimal places. Use 0 for whole-number counts (e.g. site counts), 2 for most financial metrics.">i</i></label>
        <input type="text" id="decimalPlaces" value="2">
      </div>
      <div>
        <label>Priority <span class="opt">1–1000</span> <i class="info-icon" data-tip="Lower number = higher position on the dashboard. Use 1–10 for headline metrics, 100+ for secondary metrics.">i</i></label>
        <input type="text" id="priority" value="100">
      </div>
    </div>

    <div style="margin-bottom:8px">
      <label>Applicable Geography Levels <span style="color:red">*</span> <i class="info-icon" data-tip="Select every level at which this KPI should be calculated. Hierarchy: OVERALL → REGION (~3) → AREA (~20) → MARKET (~40). Most KPIs apply at MARKET level; roll-ups are auto-aggregated.">i</i></label>
      <div class="checkbox-group" id="geoLevelCheckboxes">
        <label><input type="checkbox" value="OVERALL"  onchange="updateGeoColumns()"> OVERALL (global)</label>
        <label><input type="checkbox" value="REGION"   onchange="updateGeoColumns()"> REGION (~3)</label>
        <label><input type="checkbox" value="AREA"     onchange="updateGeoColumns()"> AREA (~20)</label>
        <label><input type="checkbox" value="MARKET"   onchange="updateGeoColumns()" checked> MARKET (~40)</label>
      </div>
    </div>

    <!-- Dynamic per-level geography column inputs -->
    <div class="geo-col-section" id="geoColSection">
      <div class="geo-col-title">Geography Source Columns</div>
      <div class="hint" style="margin-bottom:10px;color:#4f46e5;font-size:.8rem">
        Tell the AI which column holds each geography code so it maps it to the correct bind parameter.
      </div>
      <div class="grid3" id="geoColGrid">
        <div id="colMarket">
          <label>MARKET column → <code>:geo_code</code></label>
          <input type="text" id="marketColumn" placeholder="e.g. market_code">
        </div>
      </div>
    </div>

    <hr class="divider">
    <div class="section-label">SQL Configuration</div>

    <div style="margin-bottom:16px">
      <label>Time / Date Column <span class="opt">optional</span> <i class="info-icon" data-tip="The date column the AI should replace with BETWEEN :start_date AND :end_date. Leave blank if the KPI has no date filter (e.g. a live row-count from a status table).">i</i></label>
      <input type="text" id="timeColumn" placeholder="e.g. txn_date, created_at">
    </div>

    <div style="margin-bottom:16px">
      <label>Raw SQL <span style="color:red">*</span> <i class="info-icon" data-tip="Paste working SQL with real literal filter values (a specific market code, a real date range). The AI replaces them with bind parameters and aliases your aggregate columns to kpi_value / record_count.">i</i></label>
      <textarea id="rawSql" rows="7"
        placeholder="SELECT SUM(revenue) AS kpi_value, COUNT(*) AS record_count&#10;FROM sales_fact&#10;WHERE market_code = 'US_WEST'&#10;  AND txn_date BETWEEN '2024-01-01' AND '2024-01-31'"></textarea>
      <div id="dimensionHint" style="display:none;margin-top:8px;background:#f0f9ff;border:1px solid #bae6fd;border-radius:6px;padding:10px 12px;font-size:.78rem;color:#0c4a6e">
        <div style="font-weight:600;margin-bottom:6px">Dimension filters for selected project(s) — add these WHERE clauses to your SQL:</div>
        <div id="dimensionHintBody" style="font-family:monospace;line-height:1.8"></div>
        <div style="margin-top:10px;padding-top:8px;border-top:1px solid #bae6fd;color:#0369a1;font-family:inherit">
          <strong>Column name differs in your table?</strong> The bind param name is fixed but the column on the left can be anything in your table:<br>
          <span style="font-family:monospace;display:block;margin-top:4px;color:#0c4a6e">
            AND (:scope_of_work = 'ALL' OR UPPER(<em>nas_project_category</em>) = UPPER(:scope_of_work))
          </span>
          Always use <strong>UPPER()</strong> on both sides so filter values are case-insensitive — the LLM will do this automatically when you use AI generation.
        </div>
      </div>
    </div>

    <div class="grid2" style="margin-bottom:16px">
      <div>
        <label>Source Tables <span class="opt">comma-separated, informational</span> <i class="info-icon" data-tip="Table names referenced in your SQL, stored as metadata for data lineage documentation. Does not affect query execution.">i</i></label>
        <input type="text" id="sourceTables" placeholder="sales_fact, dim_market">
      </div>
      <div>
        <label>Aggregation Method <i class="info-icon" data-tip="Informational metadata — the actual aggregation is defined in your SQL. Used by the engine for documentation and future automation.">i</i></label>
        <select id="aggMethod" onchange="toggleAggColumn()">
          <option value="SUM">SUM — add all values</option>
          <option value="AVG">AVG — arithmetic mean</option>
          <option value="COUNT">COUNT — row count</option>
          <option value="MAX">MAX — highest value</option>
          <option value="MIN">MIN — lowest value</option>
          <option value="WEIGHTED_AVG">WEIGHTED_AVG — requires weight column</option>
        </select>
      </div>
    </div>

    <div id="aggColumnRow" class="hidden" style="margin-bottom:16px">
      <label>Weight Column <span style="color:red">*</span> <i class="info-icon" data-tip="Column used as the weight denominator for WEIGHTED_AVG calculations, e.g. 'volume' or 'headcount'.">i</i></label>
      <input type="text" id="aggColumn" placeholder="e.g. volume, headcount">
    </div>

    <div class="grid2" style="margin-bottom:16px">
      <div>
        <label>Refresh Frequency <i class="info-icon" data-tip="How often the calculation engine should run this KPI. DAILY is recommended for operational metrics. Does not auto-schedule — your orchestration layer must trigger calculations.">i</i></label>
        <select id="refreshFreq">
          <option value="DAILY">DAILY — recalculated every day</option>
          <option value="WEEKLY">WEEKLY — recalculated every week</option>
          <option value="MONTHLY">MONTHLY — recalculated every month</option>
        </select>
      </div>
      <div></div>
    </div>

    <hr class="divider">
    <div class="section-label">Visibility Filters <span style="font-weight:400;text-transform:none;letter-spacing:0;color:#9ca3af">— leave all blank to show this KPI to all users</span></div>

    <div style="margin-bottom:16px">
      <label>Projects <span class="opt">optional — KPI shown only to users belonging to selected projects</span></label>
      <div class="checkbox-group" id="projectCheckboxes">
        <span class="opt">Loading…</span>
      </div>
    </div>

    <div style="margin-bottom:16px">
      <label>Functions <span class="opt">optional — per-project functions loaded dynamically</span></label>
      <div class="checkbox-group" id="functionCheckboxes">
        <span class="opt">Select a project first</span>
      </div>
    </div>

    <div style="margin-bottom:16px">
      <label>Levels <span class="opt">optional</span></label>
      <div class="checkbox-group" id="levelCheckboxes">
        <span class="opt">Loading…</span>
      </div>
    </div>

    <div id="genError" class="error hidden"></div>
    <div class="row">
      <button class="btn btn-primary" onclick="generateKPI()" id="genBtn">
        Generate Template
      </button>
      <span class="hint" style="font-style:italic">Sends your SQL to the AI — usually takes 5–10 seconds.</span>
    </div>
  </div>

  <!-- ── Step 2: Review & register ─────────────────────────────── -->
  <div class="card hidden" id="step2Card">
    <div class="card-title"><span class="badge" id="b2">2</span> Review &amp; Register</div>

    <div class="info-box" style="margin-bottom:16px">
      The AI has parameterised your SQL. Review carefully — especially the WHERE clause — then click <strong>Register KPI</strong>.
      You can edit any field. The KPI ID and Code are auto-generated but can be changed.
    </div>

    <div class="notes-box hidden" id="llmNotes">
      <strong>AI notes:</strong>
      <span id="llmNotesText"></span>
    </div>

    <div class="hidden" id="previewQueryBox" style="margin-bottom:16px">
      <label>Preview Query <i class="info-icon" data-tip="Runnable SQL with all bind params replaced by sample literals. Paste this into pgAdmin to verify the generated logic before registering the KPI.">i</i>
        <button type="button" onclick="copyPreview()" style="margin-left:8px;padding:2px 10px;font-size:.75rem;border:1px solid #6366f1;border-radius:4px;background:#eef2ff;color:#4f46e5;cursor:pointer">Copy</button>
      </label>
      <textarea id="outPreviewQuery" rows="8" readonly style="background:#f8fafc;font-family:monospace;font-size:.8rem;color:#334155"></textarea>
    </div>

    <div class="grid2" style="margin-bottom:16px">
      <div>
        <label>KPI ID <i class="info-icon" data-tip="Unique identifier stored in kpi_master. Convention: KPI_VERB_NOUN e.g. KPI_TOTAL_REVENUE. Must be unique across all registered KPIs.">i</i></label>
        <input type="text" id="outKpiId">
      </div>
      <div>
        <label>KPI Code <i class="info-icon" data-tip="Short reference code used in API filters, e.g. TOTAL_REVENUE. Typically the KPI ID without the KPI_ prefix.">i</i></label>
        <input type="text" id="outKpiCode">
      </div>
    </div>

    <div style="margin-bottom:16px">
      <label>KPI Description <i class="info-icon" data-tip="Displayed as a tooltip on the dashboard card. Be specific about what the metric measures, its data source, and any caveats.">i</i></label>
      <input type="text" id="outKpiDesc">
    </div>

    <div style="margin-bottom:16px">
      <label>SQL Template <i class="info-icon" data-tip="Verify geo filters use :geo_code / :region_code / :area_code, the date filter uses :start_date / :end_date, and the query returns exactly one row with columns kpi_value (NUMERIC) and record_count (INTEGER).">i</i></label>
      <textarea id="outSqlTemplate" rows="10"></textarea>
    </div>

    <div style="margin-bottom:16px">
      <label>Drill-down SQL <span class="opt">optional</span> <i class="info-icon" data-tip="Detail rows returned by GET /kpi/{kpi_id}/detail. Write one SQL covering all geo levels using :geo_level branching — the engine resolves all params at runtime. Raw SQL is never exposed to the browser.">i</i></label>
      <textarea id="outDrilldownSql" rows="9"
        placeholder="-- One query handles all geo levels via :geo_level branching&#10;SELECT site_id, site_name, status, txn_date, revenue&#10;FROM source_table&#10;WHERE txn_date BETWEEN :start_date AND :end_date&#10;  AND CASE :geo_level&#10;        WHEN 'MARKET'  THEN market_col  = :geo_code&#10;        WHEN 'AREA'    THEN area_col    = :area_code&#10;        WHEN 'REGION'  THEN region_col  = :region_code&#10;        ELSE TRUE  -- OVERALL: return all rows&#10;      END&#10;ORDER BY txn_date DESC&#10;&#10;-- All bind params available: :geo_code :geo_level :region_code :area_code&#10;--                             :geo_id :region_id :area_id :start_date :end_date"></textarea>
    </div>

    <div id="regError" class="error hidden"></div>
    <div class="row">
      <button class="btn btn-success" onclick="registerKPI()" id="regBtn">Register KPI</button>
      <button class="btn btn-outline" onclick="resetForm()">Start Over</button>
    </div>
  </div>

  <!-- ── Step 3: Done ───────────────────────────────────────────── -->
  <div class="card hidden" id="step3Card">
    <div class="card-title"><span class="badge done">✓</span> KPI Registered Successfully</div>
    <div class="success-box" id="successMsg"></div>
    <br>
    <div class="row">
      <button class="btn btn-primary" onclick="resetForm()">Register Another KPI</button>
    </div>
  </div>
</div><!-- /appContainer -->

<script>
  const BASE = window.location.origin;
  const SESSION_KEY = 'ddb_api_key';
  let _pendingAction = null;   // function to call after successful auth

  // ── Auth modal ──────────────────────────────────────────────── //

  function requireAuth(action) {
    if (sessionStorage.getItem(SESSION_KEY)) {
      action();          // already authenticated — proceed immediately
      return;
    }
    _pendingAction = action;
    document.getElementById('authError').classList.add('hidden');
    document.getElementById('authKey').value = '';
    document.getElementById('authModal').classList.remove('hidden');
    setTimeout(() => document.getElementById('authKey').focus(), 50);
  }

  function closeAuthModal() {
    document.getElementById('authModal').classList.add('hidden');
    _pendingAction = null;
  }

  async function authenticate() {
    const btn = document.getElementById('authBtn');
    const errBox = document.getElementById('authError');
    const key = document.getElementById('authKey').value.trim();
    errBox.classList.add('hidden');

    if (!key) {
      errBox.textContent = 'Please enter your API key.';
      errBox.classList.remove('hidden');
      return;
    }

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Verifying…';

    try {
      const res = await fetch(BASE + '/api/v1/kpi-builder/template-params', {
        headers: { 'X-API-Key': key }
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(res.status === 401 || res.status === 403
          ? 'Invalid API key. Please check and try again.'
          : (data.detail || `Server error ${res.status}`));
      }
      sessionStorage.setItem(SESSION_KEY, key);
      document.getElementById('authModal').classList.add('hidden');
      updateAuthStatusBar();
      loadReferenceData();
      const action = _pendingAction;
      _pendingAction = null;
      if (action) action();
    } catch(e) {
      errBox.textContent = e.message;
      errBox.classList.remove('hidden');
    } finally {
      btn.disabled = false;
      btn.textContent = 'Authenticate';
    }
  }

  function logout() {
    sessionStorage.removeItem(SESSION_KEY);
    updateAuthStatusBar();
  }

  function updateAuthStatusBar() {
    const bar = document.getElementById('authStatusBar');
    const key = sessionStorage.getItem(SESSION_KEY);
    if (key) {
      bar.innerHTML = `
        <div class="auth-badge"><span>🔒 Authenticated</span></div>
        <button class="btn-danger-sm" style="margin-top:6px" onclick="logout()">Sign out</button>`;
    } else {
      bar.innerHTML = '';
    }
  }

  // ── Reference data (projects / functions / levels) ──────── //

  let _refData = null;  // cached reference-data response

  async function loadReferenceData() {
    const key = sessionStorage.getItem(SESSION_KEY);
    if (!key) return;  // not authenticated yet
    try {
      const res = await fetch(BASE + '/api/v1/dashboard/reference-data', {
        headers: { 'X-API-Key': key }
      });
      if (!res.ok) return;
      _refData = await res.json();

      // Projects
      const projBox = document.getElementById('projectCheckboxes');
      const projectIds = Object.keys(_refData.projects || {}).sort();
      projBox.innerHTML = projectIds.map(pid =>
        `<label><input type="checkbox" value="${pid}" onchange="onProjectSelectionChange()"> ${pid}</label>`
      ).join('') || '<span class="opt">No projects configured</span>';

      // Levels
      const lvlBox = document.getElementById('levelCheckboxes');
      const levels = _refData.levels || [];
      lvlBox.innerHTML = levels.map(l =>
        `<label><input type="checkbox" value="${l.id}"> ${l.name}</label>`
      ).join('') || '<span class="opt">No levels configured</span>';

      // Functions — show union of all projects initially
      updateFunctionCheckboxes();
    } catch(e) {
      console.warn('Failed to load reference data:', e);
    }
  }

  function onProjectSelectionChange() {
    updateFunctionCheckboxes();
    updateDimensionHint();
  }

  function updateDimensionHint() {
    const hintBox  = document.getElementById('dimensionHint');
    const hintBody = document.getElementById('dimensionHintBody');
    if (!_refData) { hintBox.style.display = 'none'; return; }

    const selectedProjects = [...document.querySelectorAll('#projectCheckboxes input:checked')].map(c => c.value);
    if (selectedProjects.length === 0) { hintBox.style.display = 'none'; return; }

    // Merge filter_dimensions across selected projects
    const allDims = {};
    for (const pid of selectedProjects) {
      const dims = ((_refData.projects || {})[pid] || {}).filter_dimensions || {};
      for (const [dim, vals] of Object.entries(dims)) {
        if (!allDims[dim]) allDims[dim] = new Set();
        for (const v of vals) allDims[dim].add(v);
      }
    }

    if (Object.keys(allDims).length === 0) { hintBox.style.display = 'none'; return; }

    hintBody.innerHTML = Object.entries(allDims).map(([dim, vals]) => {
      const valList = [...vals].map(v => `'${v}'`).join(', ');
      return `<div style="margin-bottom:6px">
        <span style="color:#0369a1">-- ${dim} &nbsp;<span style="font-size:.72rem;color:#64748b">values: ${valList}</span></span><br>
        AND (:<span style="color:#7c3aed">${dim}</span> = 'ALL' OR UPPER(your_col) = UPPER(:<span style="color:#7c3aed">${dim}</span>))
      </div>`;
    }).join('');

    hintBox.style.display = 'block';
  }

  function updateFunctionCheckboxes() {
    const funcBox = document.getElementById('functionCheckboxes');
    if (!_refData) { funcBox.innerHTML = '<span class="opt">Loading…</span>'; return; }

    const selectedProjects = [...document.querySelectorAll('#projectCheckboxes input:checked')].map(c => c.value);
    const funcSet = new Set();

    if (selectedProjects.length === 0) {
      // No project selected — show all functions from all projects
      for (const pid of Object.keys(_refData.projects || {})) {
        for (const f of (_refData.projects[pid].functions || [])) funcSet.add(f.id);
      }
    } else {
      // Show union of functions from selected projects
      for (const pid of selectedProjects) {
        const proj = (_refData.projects || {})[pid];
        if (proj) for (const f of (proj.functions || [])) funcSet.add(f.id);
      }
    }

    const funcs = [...funcSet].sort();
    funcBox.innerHTML = funcs.map(fid =>
      `<label><input type="checkbox" value="${fid}"> ${fid}</label>`
    ).join('') || '<span class="opt">No functions for selected project(s)</span>';
  }

  // Restore session silently on page load
  (function() {
    const stored = sessionStorage.getItem(SESSION_KEY);
    if (stored) {
      updateAuthStatusBar();
      loadReferenceData();
    }
  })();

  // ── Info panel ──────────────────────────────────────────────── //

  function toggleInfo() {
    const panel = document.getElementById('infoPanel');
    const arrow = document.getElementById('infoArrow');
    const hidden = panel.classList.toggle('hidden');
    arrow.textContent = hidden ? '▼' : '▲';
  }

  // ── Geo columns ─────────────────────────────────────────────── //

  function getSelectedLevels() {
    return [...document.querySelectorAll('#geoLevelCheckboxes input:checked')].map(c => c.value);
  }

  function updateGeoColumns() {
    const levels = getSelectedLevels();
    const grid = document.getElementById('geoColGrid');
    grid.innerHTML = '';
    const map = {
      REGION: { id: 'regionColumn', label: 'REGION column', param: ':region_code', ph: 'e.g. region_name' },
      AREA:   { id: 'areaColumn',   label: 'AREA column',   param: ':area_code',   ph: 'e.g. area_name' },
      MARKET: { id: 'marketColumn', label: 'MARKET column', param: ':geo_code',    ph: 'e.g. market_code' },
    };
    for (const lvl of ['REGION', 'AREA', 'MARKET']) {
      if (!levels.includes(lvl)) continue;
      const m = map[lvl];
      const div = document.createElement('div');
      div.innerHTML = `
        <label>${m.label} → <code>${m.param}</code></label>
        <input type="text" id="${m.id}" placeholder="${m.ph}">`;
      grid.appendChild(div);
    }
    if (levels.length === 0 || (levels.length === 1 && levels[0] === 'OVERALL')) {
      grid.innerHTML = '<span style="color:#888;font-size:.85rem">No geo column needed for OVERALL-only KPIs — the engine uses no geography filter.</span>';
    }
  }

  // ── Helpers ─────────────────────────────────────────────────── //

  function val(id) { return document.getElementById(id)?.value.trim() || ''; }

  function toggleAggColumn() {
    const isWeighted = val('aggMethod') === 'WEIGHTED_AVG';
    document.getElementById('aggColumnRow').classList.toggle('hidden', !isWeighted);
  }

  function splitIds(id) {
    const v = val(id);
    return v ? v.split(',').map(s => s.trim()).filter(Boolean) : null;
  }

  function getChecked(groupId) {
    const vals = [...document.querySelectorAll(`#${groupId} input[type=checkbox]:checked`)].map(c => c.value);
    return vals.length ? vals : null;
  }

  // ── Generate ────────────────────────────────────────────────── //

  async function generateKPI() {
    const btn = document.getElementById('genBtn');
    const errBox = document.getElementById('genError');
    errBox.classList.add('hidden');

    const levels = getSelectedLevels();
    if (!val('kpiName'))     return showError(errBox, 'KPI Name is required.');
    if (!val('rawSql'))      return showError(errBox, 'Raw SQL is required.');
    if (!levels.length)      return showError(errBox, 'Select at least one geography level.');

    requireAuth(() => _doGenerateKPI(btn, errBox, levels));
  }

  async function _doGenerateKPI(btn, errBox, levels) {

    const body = {
      raw_sql:               val('rawSql'),
      time_column:           val('timeColumn') || null,
      kpi_name:              val('kpiName'),
      kpi_category:          val('kpiCategory'),
      applicable_geo_levels: levels,
      display_format:        val('displayFormat').split(' ')[0],
      unit_symbol:           val('unitSymbol') || null,
      decimal_places:        parseInt(val('decimalPlaces')) ?? 2,
      aggregation_method:    val('aggMethod').split(' ')[0],
      priority:              parseInt(val('priority')) ?? 100,
      source_tables:         val('sourceTables') ? val('sourceTables').split(',').map(s=>s.trim()) : [],
      parent_kpi_id:         val('parentKpiId') || null,
      aggregation_column:    val('aggColumn') || null,
      refresh_frequency:     val('refreshFreq').split(' ')[0],
      project_ids:           getChecked('projectCheckboxes'),
      level_ids:              getChecked('levelCheckboxes'),
      function_ids:          getChecked('functionCheckboxes'),
      kpi_tag:               val('kpiTag').split(' ')[0] || null,
    };
    if (levels.includes('MARKET') && val('marketColumn')) body.market_column = val('marketColumn');
    if (levels.includes('AREA')   && val('areaColumn'))   body.area_column   = val('areaColumn');
    if (levels.includes('REGION') && val('regionColumn')) body.region_column = val('regionColumn');

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Generating…';

    try {
      const res = await apiFetch('/api/v1/kpi-builder/generate', 'POST', body);
      const p = res.proposed_kpi;
      document.getElementById('outKpiId').value       = p.kpi_id || '';
      document.getElementById('outKpiCode').value     = p.kpi_code || '';
      document.getElementById('outKpiDesc').value     = p.kpi_description || '';
      document.getElementById('outSqlTemplate').value = p.sql_query_template || '';
      if (res.preview_query) {
        document.getElementById('outPreviewQuery').value = res.preview_query;
        document.getElementById('previewQueryBox').classList.remove('hidden');
      }
      if (res.llm_notes) {
        document.getElementById('llmNotesText').textContent = res.llm_notes;
        document.getElementById('llmNotes').classList.remove('hidden');
      }
      window._proposedKpi = p;
      document.getElementById('step2Card').classList.remove('hidden');
      document.getElementById('step2Card').scrollIntoView({ behavior: 'smooth' });
      document.getElementById('b1').classList.add('done');
    } catch(e) {
      showError(errBox, e.message);
    } finally {
      btn.disabled = false;
      btn.textContent = 'Generate Template';
    }
  }

  // ── Register ────────────────────────────────────────────────── //

  async function registerKPI() {
    requireAuth(() => _doRegisterKPI());
  }

  async function _doRegisterKPI() {
    const btn = document.getElementById('regBtn');
    const errBox = document.getElementById('regError');
    errBox.classList.add('hidden');

    const p = window._proposedKpi || {};
    const levels = getSelectedLevels();

    const body = {
      kpi_id:                val('outKpiId'),
      kpi_code:              val('outKpiCode'),
      kpi_description:       val('outKpiDesc') || null,
      sql_query_template:    val('outSqlTemplate'),
      kpi_name:              val('kpiName'),
      kpi_category:          val('kpiCategory'),
      applicable_geo_levels: levels.length ? levels : (p.applicable_geo_levels || []),
      display_format:        val('displayFormat').split(' ')[0],
      unit_symbol:           val('unitSymbol') || null,
      decimal_places:        parseInt(val('decimalPlaces')) ?? 2,
      aggregation_method:    val('aggMethod').split(' ')[0],
      priority:              parseInt(val('priority')) ?? 100,
      source_tables:         val('sourceTables') ? val('sourceTables').split(',').map(s => s.trim()) : [],
      parent_kpi_id:         val('parentKpiId') || null,
      aggregation_column:    val('aggColumn') || null,
      refresh_frequency:     val('refreshFreq').split(' ')[0],
      project_ids:           getChecked('projectCheckboxes'),
      level_ids:              getChecked('levelCheckboxes'),
      function_ids:          getChecked('functionCheckboxes'),
      is_active:             true,
      kpi_tag:               val('kpiTag').split(' ')[0] || null,
      drilldown_sql:         val('outDrilldownSql') || null,
    };

    if (!body.kpi_id)             return showError(errBox, 'KPI ID is required.');
    if (!body.sql_query_template) return showError(errBox, 'SQL Template is required.');

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner"></span> Saving…';

    try {
      const res = await apiFetch('/api/v1/kpi-builder/register', 'POST', body);
      document.getElementById('successMsg').innerHTML =
        `<strong>✓ KPI <code>${body.kpi_id}</code> registered successfully!</strong><br><br>` +
        `<strong>Next step — trigger the first calculation:</strong><br>` +
        `<code>POST /api/v1/calculation/trigger</code><br>` +
        `Body: <code>{"job_type":"SINGLE_KPI","kpi_ids":["${body.kpi_id}"]}</code><br><br>` +
        `Once the calculation job completes the KPI will appear on the dashboard at all applicable geography levels.`;
      document.getElementById('step3Card').classList.remove('hidden');
      document.getElementById('step3Card').scrollIntoView({ behavior: 'smooth' });
      document.getElementById('b2').classList.add('done');
    } catch(e) {
      showError(errBox, e.message);
    } finally {
      btn.disabled = false;
      btn.textContent = 'Register KPI';
    }
  }

  // ── API helper ──────────────────────────────────────────────── //

  async function apiFetch(path, method, body) {
    const key = sessionStorage.getItem(SESSION_KEY) || '';
    const res = await fetch(BASE + path, {
      method,
      headers: { 'Content-Type': 'application/json', 'X-API-Key': key },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || JSON.stringify(data));
    return data;
  }

  function showError(box, msg) {
    box.textContent = msg;
    box.classList.remove('hidden');
    box.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  function copyPreview() {
    const ta = document.getElementById('outPreviewQuery');
    navigator.clipboard.writeText(ta.value).then(() => {
      const btn = event.target;
      btn.textContent = 'Copied!';
      setTimeout(() => btn.textContent = 'Copy', 1500);
    });
  }

  function resetForm() {
    ['step2Card','step3Card'].forEach(id => document.getElementById(id).classList.add('hidden'));
    ['genError','regError','llmNotes','previewQueryBox'].forEach(id => document.getElementById(id).classList.add('hidden'));
    ['b1','b2'].forEach(id => document.getElementById(id).classList.remove('done'));
    window._proposedKpi = null;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
</script>
</body>
</html>
"""


# ------------------------------------------------------------------ #
# Endpoints                                                            #
# ------------------------------------------------------------------ #

@router.get("/form", response_class=HTMLResponse, include_in_schema=False)
async def kpi_builder_form():
    """Serves the interactive KPI Builder UI (no auth required for the page itself)."""
    return HTMLResponse(content=_FORM_HTML)


@router.post("/generate")
async def generate_kpi(
    request: KPIGenerateRequest,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Generate KPI Template from Raw SQL** *(LLM-assisted)*

    Provide your raw SQL with real filter values and specify which source-table
    column maps to each geography level. The LLM will:

    - Replace each geo filter with the correct bind param (`market_column` → `:geo_code`,
      `area_column` → `:area_code`, `region_column` → `:region_code`)
    - Replace the date filter with `:start_date` / `:end_date`
    - Rename aggregate columns to `kpi_value` and `record_count`
    - Suggest `kpi_id`, `kpi_code`, and `kpi_description`

    **Workflow:**
    1. Call this endpoint → inspect `proposed_kpi` and `llm_notes`
    2. Edit `proposed_kpi` fields if needed (especially `sql_query_template`)
    3. Call `POST /register` with the final definition
    4. Trigger calculation: `POST /api/v1/calculation/trigger`

    Or use the interactive form at `GET /api/v1/kpi-builder/form`.
    """
    try:
        service = KPIBuilderService(db)
        llm_result = await service.generate_template(
            raw_sql=request.raw_sql,
            kpi_name=request.kpi_name,
            applicable_geo_levels=[lvl.value for lvl in request.applicable_geo_levels],
            time_column=request.time_column,
            market_column=request.market_column,
            area_column=request.area_column,
            region_column=request.region_column,
            filter_dimensions=request.filter_dimensions,
        )

        proposed_kpi: Dict[str, Any] = {
            "kpi_id":                llm_result.get("kpi_id", "KPI_NEW"),
            "kpi_code":              llm_result.get("kpi_code", "NEW_KPI"),
            "kpi_name":              request.kpi_name,
            "kpi_description":       llm_result.get("kpi_description"),
            "kpi_category":          request.kpi_category,
            "applicable_geo_levels": [lvl.value for lvl in request.applicable_geo_levels],
            "sql_query_template":    llm_result.get("sql_template", request.raw_sql),
            "aggregation_method":    request.aggregation_method.value,
            "aggregation_column":    request.aggregation_column,
            "display_format":        request.display_format.value,
            "decimal_places":        request.decimal_places,
            "unit_symbol":           request.unit_symbol,
            "source_tables":         request.source_tables,
            "project_ids":           request.project_ids,
            "level_ids":              request.level_ids,
            "function_ids":          request.function_ids,
            "priority":              request.priority,
            "refresh_frequency":     request.refresh_frequency,
            "is_active":             True,
            "parent_kpi_id":         request.parent_kpi_id,
            "kpi_tag":               request.kpi_tag,
        }

        return {
            "proposed_kpi": proposed_kpi,
            "preview_query": llm_result.get("preview_query", ""),
            "llm_notes": llm_result.get("notes", ""),
            "next_step": (
                "Review proposed_kpi (especially sql_query_template) and run "
                "preview_query in pgAdmin to verify the logic, "
                "then POST /api/v1/kpi-builder/register"
            ),
        }

    except ValueError as e:
        raise HTTPException(status_code=502, detail=f"LLM error: {str(e)}")
    except Exception as e:
        logger.error(f"KPI generation failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"KPI generation failed: {str(e)}")


@router.post("/register", status_code=201)
async def register_kpi(
    kpi: KPIRegisterRequest,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Register KPI in Master Table**

    Saves the KPI definition to `kpi_master`. Safe to re-run — if `kpi_id` already
    exists the record is updated (`ON CONFLICT DO UPDATE`).

    After registering, trigger the first calculation:
    ```
    POST /api/v1/calculation/trigger
    { "job_type": "SINGLE_KPI", "kpi_ids": ["<kpi_id>"] }
    ```
    """
    try:
        service = KPIBuilderService(db)
        saved = await service.register_kpi(kpi.model_dump())
        return {
            "message": f"KPI '{kpi.kpi_id}' registered successfully",
            "kpi": saved,
            "next_step": (
                f"Trigger first calculation: POST /api/v1/calculation/trigger "
                f"with body {{\"job_type\": \"SINGLE_KPI\", \"kpi_ids\": [\"{kpi.kpi_id}\"]}}"
            ),
        }
    except Exception as e:
        logger.error(f"KPI registration failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"KPI registration failed: {str(e)}")


@router.get("/bulk-template")
async def download_bulk_template(
    format: str = Query("excel", description="Output format: 'excel' (default) or 'yaml'"),
    _: str = Depends(verify_api_key),
):
    """
    **Download a bulk-upload template.**

    Returns a pre-filled template file you can populate with KPI definitions and
    then upload to `POST /api/v1/kpi-builder/bulk-upload`.

    - `format=excel` → `.xlsx` workbook with one header row + one example row
    - `format=yaml`  → `.yaml` file with a list containing one example KPI
    """
    # ------------------------------------------------------------------
    # Column definitions — order matters for Excel
    # ------------------------------------------------------------------
    COLUMNS = [
        ("kpi_id",                "KPI_REVENUE_TOTAL",          "REQUIRED. Unique ID, e.g. KPI_REVENUE_TOTAL"),
        ("kpi_code",              "REVENUE_TOTAL",               "REQUIRED. Short code, SCREAMING_SNAKE"),
        ("kpi_name",              "Total Revenue",               "REQUIRED. Human-readable name"),
        ("kpi_description",       "Sum of all revenue transactions in the period", "Optional. One sentence."),
        ("kpi_category",          "PERFORMANCE",                 "REQUIRED. Any string, e.g. HEALTH, PERFORMANCE, Site_Count, Milestone, etc."),
        ("kpi_tag",               "TOTAL",                       "Optional. TOTAL|TREND|RATE|PERCENTAGE|COUNT|TARGET|GAUGE|AVERAGE|COMPARISON"),
        ("project_ids",           "PROJ001,PROJ002",             "Optional. Comma-separated project IDs"),
        ("level_ids",              "HOME,PHASE",                  "Optional. Comma-separated levels: HOME, PHASE, SITE"),
        ("function_ids",          "PDM",                         "Optional. Comma-separated function IDs"),
        ("applicable_geo_levels", "OVERALL,REGION,AREA,MARKET", "REQUIRED. Comma-separated: OVERALL|REGION|AREA|MARKET"),
        ("sql_query_template",    "SELECT SUM(revenue) AS kpi_value, COUNT(*) AS record_count FROM sales WHERE UPPER(market_code) = :geo_code AND txn_date BETWEEN :start_date AND :end_date", "REQUIRED. SQL with bind params. Must return exactly 1 row with kpi_value + record_count."),
        ("aggregation_method",    "SUM",                         "REQUIRED. SUM|AVG|COUNT|MIN|MAX|WEIGHTED_AVG"),
        ("aggregation_column",    "",                            "Optional. Column used in aggregation."),
        ("display_format",        "CURRENCY",                    "Optional. NUMBER|PERCENTAGE|CURRENCY|DAYS (default NUMBER)"),
        ("decimal_places",        "2",                           "Optional. 0-6 (default 2)"),
        ("unit_symbol",           "$",                           "Optional. E.g. '$', '%', 'days'"),
        ("source_tables",         "sales",                       "Optional. Comma-separated source table names"),
        ("refresh_frequency",     "DAILY",                       "Optional. DAILY|WEEKLY|MONTHLY (default DAILY)"),
        ("is_active",             "TRUE",                        "Optional. TRUE or FALSE (default TRUE)"),
        ("priority",              "10",                          "Optional. 1–1000, lower = higher priority (default 100)"),
        ("parent_kpi_id",         "",                            "Optional. Set to make this a sub-metric of another KPI"),
        ("drilldown_sql",         "",                            "Optional. SQL for drilldown detail table"),
    ]

    if format.lower() == "yaml":
        sample = {col: example for col, example, _ in COLUMNS if example}
        output = yaml.dump(
            {"kpis": [sample]},
            default_flow_style=False,
            allow_unicode=True,
            sort_keys=False,
        )
        return StreamingResponse(
            io.BytesIO(output.encode("utf-8")),
            media_type="application/x-yaml",
            headers={"Content-Disposition": "attachment; filename=kpi_bulk_template.yaml"},
        )

    # Excel format
    try:
        import openpyxl
        from openpyxl.styles import Alignment, Font, PatternFill
    except ImportError:
        raise HTTPException(
            status_code=501,
            detail="openpyxl is not installed. Run: pip install openpyxl>=3.1.0",
        )

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "KPI Bulk Upload"

    header_font   = Font(bold=True, color="FFFFFF")
    header_fill   = PatternFill("solid", fgColor="1F4E79")
    example_fill  = PatternFill("solid", fgColor="D9E1F2")
    note_font     = Font(italic=True, color="595959", size=9)
    wrap          = Alignment(wrap_text=True, vertical="top")

    # Row 1: column names (header)
    # Row 2: instructions / notes
    # Row 3: example row
    for col_idx, (col_name, example, note) in enumerate(COLUMNS, start=1):
        header_cell = ws.cell(row=1, column=col_idx, value=col_name)
        header_cell.font  = header_font
        header_cell.fill  = header_fill
        header_cell.alignment = wrap

        note_cell = ws.cell(row=2, column=col_idx, value=note)
        note_cell.font      = note_font
        note_cell.alignment = wrap

        example_cell = ws.cell(row=3, column=col_idx, value=example)
        example_cell.fill      = example_fill
        example_cell.alignment = wrap

    # Freeze header row and set column widths
    ws.freeze_panes = "A3"
    ws.row_dimensions[1].height = 22
    ws.row_dimensions[2].height = 40
    ws.row_dimensions[3].height = 80

    col_widths = {
        "kpi_id": 25, "kpi_code": 22, "kpi_name": 28, "kpi_description": 40,
        "kpi_category": 14, "kpi_tag": 14, "project_ids": 20, "level_ids": 20,
        "function_ids": 20, "applicable_geo_levels": 30, "sql_query_template": 70,
        "aggregation_method": 18, "aggregation_column": 20, "display_format": 16,
        "decimal_places": 14, "unit_symbol": 12, "source_tables": 22,
        "refresh_frequency": 18, "is_active": 10, "priority": 10,
        "parent_kpi_id": 20, "drilldown_sql": 50,
    }
    for col_idx, (col_name, _, _) in enumerate(COLUMNS, start=1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(col_idx)].width = col_widths.get(col_name, 18)

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return StreamingResponse(
        buf,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=kpi_bulk_template.xlsx"},
    )


@router.post("/bulk-upload")
async def bulk_upload_kpis(
    file: UploadFile = File(..., description="Excel (.xlsx) or YAML (.yaml / .yml) file with KPI definitions"),
    validation_geo_code: str = Query(..., description="A geo_code to test each SQL template against (e.g. 'US_WEST')"),
    validation_date: Optional[date] = Query(None, description="Date used as :end_date when testing SQL. Defaults to today."),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Bulk upload KPI definitions.**

    Accepts an Excel (`.xlsx`) or YAML (`.yaml` / `.yml`) file generated from
    `GET /api/v1/kpi-builder/bulk-template`.

    For each row / entry:
    1. Validates required fields and enum values.
    2. Dry-runs the `sql_query_template` against `validation_geo_code` to confirm
       it returns exactly **one row** with `kpi_value` and `record_count` columns.
    3. Saves KPIs that pass validation (upsert on `kpi_id`).

    Returns a detailed report showing which KPIs were saved and which failed with reasons.
    """
    filename = file.filename or ""
    content  = await file.read()

    kpi_rows: List[Dict[str, Any]] = []

    if filename.endswith(".yaml") or filename.endswith(".yml"):
        try:
            data = yaml.safe_load(content.decode("utf-8"))
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"Invalid YAML: {exc}")
        if not isinstance(data, dict) or "kpis" not in data:
            raise HTTPException(status_code=400, detail="YAML must have a top-level 'kpis' list.")
        kpi_rows = data["kpis"]

    elif filename.endswith(".xlsx"):
        try:
            import openpyxl
        except ImportError:
            raise HTTPException(
                status_code=501,
                detail="openpyxl is not installed. Run: pip install openpyxl>=3.1.0",
            )
        try:
            wb   = openpyxl.load_workbook(io.BytesIO(content), read_only=True, data_only=True)
            ws   = wb.active
            rows = list(ws.iter_rows(values_only=True))
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"Could not read Excel file: {exc}")

        if len(rows) < 3:
            raise HTTPException(status_code=400, detail="Excel file must have a header row, a notes row, and at least one data row.")

        headers = [str(c).strip() if c else "" for c in rows[0]]
        # rows[1] = notes/instructions — skip; rows[2+] = data
        for excel_row in rows[2:]:
            if all(c is None or str(c).strip() == "" for c in excel_row):
                continue  # skip blank rows
            kpi_rows.append({headers[i]: (str(v).strip() if v is not None else "") for i, v in enumerate(excel_row)})

    else:
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Upload a .xlsx or .yaml / .yml file.",
        )

    if not kpi_rows:
        raise HTTPException(status_code=400, detail="No KPI rows found in the uploaded file.")

    service = KPIBuilderService(db)
    try:
        report = await service.bulk_validate_and_register(
            kpi_rows=kpi_rows,
            validation_geo_code=validation_geo_code,
            validation_date=validation_date,
        )
    except Exception as exc:
        logger.error(f"Bulk upload failed: {exc}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Bulk upload failed: {exc}")

    return report


@router.get("/template-params")
async def get_template_params(_: str = Depends(verify_api_key)):
    """
    **KPI Template Parameter Reference**

    Returns the full list of bind parameters available in every `sql_query_template`.
    """
    return {
        "params": [
            {"name": ":start_date",   "type": "date",   "description": "Period start date (inclusive)"},
            {"name": ":end_date",     "type": "date",   "description": "Period end date (inclusive)"},
            {"name": ":geo_code",     "type": "string", "description": "Natural key of the MARKET geography (UPPER-CASE). Set by market_column."},
            {"name": ":area_code",    "type": "string", "description": "geo_code of the parent AREA. Set by area_column. NULL at OVERALL/REGION level."},
            {"name": ":region_code",  "type": "string", "description": "geo_code of the parent REGION. Set by region_column. NULL at OVERALL/REGION level."},
            {"name": ":geo_level",    "type": "string", "description": "Current geography level: OVERALL | REGION | AREA | MARKET"},
            {"name": ":geo_id",       "type": "string", "description": "Surrogate FK of the current geography (prefer :geo_code)."},
            {"name": ":region_id",    "type": "string", "description": "Surrogate FK of the parent region."},
            {"name": ":area_id",      "type": "string", "description": "Surrogate FK of the parent area."},
        ],
        "required_output_columns": [
            {"name": "kpi_value",    "type": "NUMERIC",  "description": "The calculated KPI value"},
            {"name": "record_count", "type": "INTEGER",  "description": "Number of source rows aggregated"},
        ],
        "note": "The template must return exactly one row.",
    }


# ------------------------------------------------------------------ #
# KPI list / get / delete  (used by the Manage page)                   #
# ------------------------------------------------------------------ #

@router.get("/kpis")
async def list_kpis(
    project_id: Optional[str] = Query(None),
    is_active: Optional[bool] = Query(None),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """List all KPI definitions from kpi_master."""
    service = KPIBuilderService(db)
    return await service.list_kpis(project_id=project_id, is_active=is_active)


@router.get("/kpis/{kpi_id}")
async def get_kpi(
    kpi_id: str,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """Fetch a single KPI definition by ID."""
    service = KPIBuilderService(db)
    kpi = await service.get_kpi(kpi_id)
    if not kpi:
        raise HTTPException(status_code=404, detail=f"KPI '{kpi_id}' not found")
    return kpi


@router.delete("/kpis/{kpi_id}")
async def delete_kpi(
    kpi_id: str,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """Delete a KPI definition from kpi_master."""
    service = KPIBuilderService(db)
    deleted = await service.delete_kpi(kpi_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"KPI '{kpi_id}' not found")
    return {"message": f"KPI '{kpi_id}' deleted successfully"}


# ------------------------------------------------------------------ #
# KPI Manager UI                                                       #
# ------------------------------------------------------------------ #

_MANAGE_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>KPI Manager</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  *, *::before, *::after { box-sizing: border-box; }
  body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
         background: #f0f2f5; margin: 0; padding: 24px; color: #1a1a2e; }
  .container { max-width: 1100px; margin: 0 auto; }
  h1 { font-size: 1.6rem; font-weight: 700; margin: 0 0 4px; }
  .subtitle { color: #666; margin: 0 0 24px; font-size: .9rem; }
  .card { background: #fff; border-radius: 10px; padding: 28px;
          margin-bottom: 20px; box-shadow: 0 1px 4px rgba(0,0,0,.08); }
  .card-title { font-size: 1rem; font-weight: 700; margin: 0 0 18px; }
  label { display: block; font-size: .82rem; font-weight: 600;
          color: #444; margin-bottom: 5px; }
  label .opt { font-weight: 400; color: #888; margin-left: 4px; }
  input[type=text], input[type=password], select, textarea {
    width: 100%; padding: 9px 12px; border: 1px solid #d1d5db;
    border-radius: 6px; font-size: .9rem; font-family: inherit;
    transition: border-color .15s; background: #fff; }
  input:focus, select:focus, textarea:focus {
    outline: none; border-color: #4f46e5; box-shadow: 0 0 0 3px rgba(79,70,229,.12); }
  textarea { resize: vertical; font-family: 'Courier New', monospace; font-size: .82rem; }
  .grid2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  .grid3 { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; }
  .btn { padding: 10px 22px; border-radius: 7px; border: none; font-size: .9rem;
         font-weight: 600; cursor: pointer; transition: opacity .15s, transform .1s; }
  .btn:active { transform: scale(.98); }
  .btn:disabled { opacity: .45; cursor: not-allowed; }
  .btn-primary { background: #4f46e5; color: #fff; }
  .btn-primary:hover:not(:disabled) { background: #4338ca; }
  .btn-success { background: #16a34a; color: #fff; }
  .btn-success:hover:not(:disabled) { background: #15803d; }
  .btn-outline { background: #fff; color: #4f46e5; border: 1.5px solid #4f46e5; }
  .btn-outline:hover { background: #ede9fe; }
  .btn-danger { background: #dc2626; color: #fff; }
  .btn-danger:hover:not(:disabled) { background: #b91c1c; }
  .btn-sm { padding: 6px 14px; font-size: .82rem; }
  .row { display: flex; gap: 10px; align-items: center; flex-wrap: wrap; }
  .error { background: #fef2f2; border: 1px solid #fca5a5;
           color: #b91c1c; padding: 12px 16px; border-radius: 8px;
           font-size: .88rem; margin-top: 12px; }
  .success-box { background: #f0fdf4; border: 1px solid #86efac;
                 color: #166534; padding: 12px 16px; border-radius: 8px;
                 font-size: .88rem; margin-top: 12px; }
  .hidden { display: none !important; }
  .spinner { display: inline-block; width: 14px; height: 14px;
             border: 2px solid rgba(255,255,255,.4); border-top-color: #fff;
             border-radius: 50%; animation: spin .6s linear infinite; }
  @keyframes spin { to { transform: rotate(360deg); } }
  code { background: #f3f4f6; padding: 1px 5px; border-radius: 4px;
         font-family: monospace; font-size: .85em; }
  .checkbox-group { display: flex; flex-wrap: wrap; gap: 10px; }
  .checkbox-group label { display: flex; align-items: center; gap: 6px;
    font-weight: 400; font-size: .88rem; cursor: pointer;
    background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 6px;
    padding: 7px 12px; }
  .checkbox-group input[type=checkbox] { width: 15px; height: 15px; accent-color: #4f46e5; }
  /* Auth modal */
  .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,.45);
                   display: flex; align-items: center; justify-content: center;
                   z-index: 1000; padding: 24px; }
  .auth-card { background: #fff; border-radius: 14px; padding: 36px 32px;
               max-width: 400px; width: 100%;
               box-shadow: 0 8px 32px rgba(0,0,0,.18); text-align: center; }
  .auth-card h2 { font-size: 1.2rem; font-weight: 700; margin: 0 0 6px; }
  .auth-card p  { font-size: .86rem; color: #666; margin: 0 0 20px; }
  .auth-card input { text-align: center; letter-spacing: .05em; margin-bottom: 12px; }
  .top-bar { display: flex; align-items: center; justify-content: space-between;
             margin-bottom: 8px; }
  .auth-badge { display: flex; align-items: center; gap: 8px; font-size: .82rem;
                color: #16a34a; font-weight: 600; }
  .auth-badge span { background: #f0fdf4; border: 1px solid #86efac;
                     padding: 4px 10px; border-radius: 20px; }
  /* KPI Table */
  .kpi-table { width: 100%; border-collapse: collapse; font-size: .85rem; }
  .kpi-table th { background: #f8f9fa; padding: 10px 12px; text-align: left;
                  font-weight: 600; color: #555; border-bottom: 2px solid #e5e7eb;
                  white-space: nowrap; }
  .kpi-table td { padding: 10px 12px; border-bottom: 1px solid #f0f0f0;
                  vertical-align: middle; }
  .kpi-table tr:hover { background: #f8f9ff; cursor: pointer; }
  .kpi-table tr.selected { background: #ede9fe; }
  .status-active { color: #16a34a; font-weight: 600; }
  .status-inactive { color: #9ca3af; font-weight: 600; }
  .filter-bar { display: flex; gap: 12px; align-items: center; margin-bottom: 16px; flex-wrap: wrap; }
  .filter-bar input, .filter-bar select { width: auto; min-width: 180px; }
  .badge-cat { display: inline-block; padding: 2px 8px; border-radius: 4px;
               font-size: .75rem; font-weight: 600; background: #e0e7ff; color: #3730a3; }
  .kpi-count { font-size: .82rem; color: #888; font-weight: 400; margin-left: 12px; }
  .divider { border: none; border-top: 1px solid #e5e7eb; margin: 20px 0; }
  .section-label { font-size: .72rem; font-weight: 700; text-transform: uppercase;
                   letter-spacing: .06em; color: #9ca3af; margin: 20px 0 12px; }
  .back-link { color: #4f46e5; text-decoration: none; font-size: .85rem; font-weight: 600; }
  .back-link:hover { text-decoration: underline; }
</style>
</head>
<body>

<!-- Auth Modal -->
<div class="modal-overlay hidden" id="authModal">
  <div class="auth-card">
    <div style="font-size:2.2rem;margin-bottom:12px">&#128272;</div>
    <h2>Authentication required</h2>
    <p>Enter your API key to continue.</p>
    <input type="password" id="authKey" placeholder="Paste your X-API-Key here"
           onkeydown="if(event.key==='Enter') authenticate()">
    <div id="authError" class="error hidden" style="text-align:left;margin-bottom:12px"></div>
    <div class="row" style="justify-content:center;gap:10px">
      <button class="btn btn-primary" style="flex:1" onclick="authenticate()" id="authBtn">Authenticate</button>
      <button class="btn btn-outline" onclick="document.getElementById('authModal').classList.add('hidden')">Cancel</button>
    </div>
  </div>
</div>

<nav style="background:#0f172a;padding:0 24px;display:flex;align-items:center;gap:4px;height:44px;position:sticky;top:0;z-index:100;box-shadow:0 1px 3px rgba(0,0,0,.3)">
  <span style="color:#94a3b8;font-size:.75rem;font-weight:700;letter-spacing:.08em;margin-right:12px">DYNAMIC DASHBOARD BUILDER</span>
  <a href="/api/v1/project-config/manage" style="color:#cbd5e1;text-decoration:none;font-size:.82rem;padding:6px 12px;border-radius:4px;transition:background .15s" onmouseover="this.style.background='#1e293b'" onmouseout="this.style.background='transparent'">Project Config</a>
  <a href="/api/v1/kpi-builder/form" style="color:#cbd5e1;text-decoration:none;font-size:.82rem;padding:6px 12px;border-radius:4px;transition:background .15s" onmouseover="this.style.background='#1e293b'" onmouseout="this.style.background='transparent'">KPI Builder</a>
  <a href="/api/v1/kpi-builder/manage" style="color:#fff;text-decoration:none;font-size:.82rem;padding:6px 12px;border-radius:4px;background:#1e40af">KPI Manager</a>
  <a href="/api/v1/guide" style="color:#cbd5e1;text-decoration:none;font-size:.82rem;padding:6px 12px;border-radius:4px;transition:background .15s" onmouseover="this.style.background='#1e293b'" onmouseout="this.style.background='transparent'">Guide</a>
  <span style="flex:1"></span>
  <a href="/docs" target="_blank" style="color:#64748b;text-decoration:none;font-size:.75rem;padding:4px 8px">API Docs ↗</a>
</nav>

<div class="container">
  <div class="top-bar">
    <div>
      <h1>KPI Manager</h1>
      <p class="subtitle" style="margin-bottom:0">View, edit, and manage existing KPI definitions.</p>
    </div>
    <div style="text-align:right;flex-shrink:0;margin-left:16px" id="authStatusBar"></div>
  </div>
  <br>

  <!-- KPI List -->
  <div class="card" id="listCard">
    <div class="card-title">
      All KPIs <span class="kpi-count" id="kpiCount"></span>
    </div>
    <div class="filter-bar">
      <input type="text" id="searchBox" placeholder="Search by name, ID, or category..." oninput="filterTable()">
      <select id="filterProject" onchange="filterTable()">
        <option value="">All projects</option>
      </select>
      <select id="filterActive" onchange="filterTable()">
        <option value="">All statuses</option>
        <option value="true">Active only</option>
        <option value="false">Inactive only</option>
      </select>
    </div>
    <div style="overflow-x:auto">
      <table class="kpi-table" id="kpiTable">
        <thead>
          <tr>
            <th>KPI ID</th>
            <th>Name</th>
            <th>Category</th>
            <th>Projects</th>
            <th>Geo Levels</th>
            <th>Priority</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody id="kpiTableBody">
          <tr><td colspan="8" style="text-align:center;color:#999;padding:40px">Loading...</td></tr>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Edit Form (hidden until a KPI is selected) -->
  <div class="card hidden" id="editCard">
    <div class="card-title" id="editTitle">Edit KPI</div>

    <div class="grid2" style="margin-bottom:16px">
      <div>
        <label>KPI ID</label>
        <input type="text" id="eKpiId" readonly style="background:#f3f4f6;color:#888">
      </div>
      <div>
        <label>KPI Code</label>
        <input type="text" id="eKpiCode">
      </div>
    </div>

    <div class="grid2" style="margin-bottom:16px">
      <div>
        <label>KPI Name</label>
        <input type="text" id="eKpiName">
      </div>
      <div>
        <label>KPI Category</label>
        <input type="text" id="eKpiCategory">
      </div>
    </div>

    <div style="margin-bottom:16px">
      <label>Description <span class="opt">optional</span></label>
      <input type="text" id="eKpiDesc">
    </div>

    <div class="grid3" style="margin-bottom:16px">
      <div>
        <label>Display Format</label>
        <select id="eDisplayFormat">
          <option value="NUMBER">NUMBER</option>
          <option value="CURRENCY">CURRENCY</option>
          <option value="PERCENTAGE">PERCENTAGE</option>
          <option value="DAYS">DAYS</option>
        </select>
      </div>
      <div>
        <label>Unit Symbol <span class="opt">optional</span></label>
        <input type="text" id="eUnitSymbol">
      </div>
      <div>
        <label>Decimal Places</label>
        <input type="text" id="eDecimalPlaces" value="2">
      </div>
    </div>

    <div class="grid3" style="margin-bottom:16px">
      <div>
        <label>Aggregation Method</label>
        <select id="eAggMethod">
          <option value="SUM">SUM</option>
          <option value="AVG">AVG</option>
          <option value="COUNT">COUNT</option>
          <option value="MAX">MAX</option>
          <option value="MIN">MIN</option>
          <option value="WEIGHTED_AVG">WEIGHTED_AVG</option>
        </select>
      </div>
      <div>
        <label>Weight Column <span class="opt">optional</span></label>
        <input type="text" id="eAggColumn" placeholder="e.g. volume (for WEIGHTED_AVG)">
      </div>
      <div>
        <label>Refresh Frequency</label>
        <select id="eRefreshFreq">
          <option value="DAILY">DAILY</option>
          <option value="WEEKLY">WEEKLY</option>
          <option value="MONTHLY">MONTHLY</option>
        </select>
      </div>
    </div>

    <div class="grid2" style="margin-bottom:16px">
      <div>
        <label>Priority <span class="opt">1-1000</span></label>
        <input type="text" id="ePriority">
      </div>
      <div></div>
    </div>

    <div class="grid2" style="margin-bottom:16px">
      <div>
        <label>KPI Tag <span class="opt">optional</span></label>
        <select id="eKpiTag">
          <option value="">-- none --</option>
          <option value="TOTAL">TOTAL</option>
          <option value="TREND">TREND</option>
          <option value="RATE">RATE</option>
          <option value="PERCENTAGE">PERCENTAGE</option>
          <option value="COUNT">COUNT</option>
          <option value="TARGET">TARGET</option>
          <option value="GAUGE">GAUGE</option>
          <option value="AVERAGE">AVERAGE</option>
          <option value="COMPARISON">COMPARISON</option>
        </select>
      </div>
      <div>
        <label>Parent KPI ID <span class="opt">optional</span></label>
        <input type="text" id="eParentKpiId">
      </div>
    </div>

    <div style="margin-bottom:16px">
      <label>Applicable Geo Levels</label>
      <div class="checkbox-group" id="eGeoLevels">
        <label><input type="checkbox" value="OVERALL"> OVERALL</label>
        <label><input type="checkbox" value="REGION"> REGION</label>
        <label><input type="checkbox" value="AREA"> AREA</label>
        <label><input type="checkbox" value="MARKET"> MARKET</label>
      </div>
    </div>

    <hr class="divider">
    <div class="section-label">Visibility Filters</div>

    <div style="margin-bottom:16px">
      <label>Projects <span class="opt">optional</span></label>
      <div class="checkbox-group" id="eProjects">
        <span class="opt">Loading...</span>
      </div>
    </div>

    <div style="margin-bottom:16px">
      <label>Functions <span class="opt">optional</span></label>
      <div class="checkbox-group" id="eFunctions">
        <span class="opt">Select a project first</span>
      </div>
    </div>

    <div style="margin-bottom:16px">
      <label>Levels <span class="opt">optional</span></label>
      <div class="checkbox-group" id="eLevels">
        <span class="opt">Loading...</span>
      </div>
    </div>

    <hr class="divider">
    <div class="section-label">SQL</div>

    <div style="margin-bottom:16px">
      <label>SQL Query Template</label>
      <textarea id="eSqlTemplate" rows="10"></textarea>
    </div>

    <div style="margin-bottom:16px">
      <label>Drilldown SQL <span class="opt">optional</span></label>
      <textarea id="eDrilldownSql" rows="8"></textarea>
    </div>

    <div style="margin-bottom:16px">
      <label>Source Tables <span class="opt">comma-separated</span></label>
      <input type="text" id="eSourceTables">
    </div>

    <div style="margin-bottom:16px">
      <label>Active</label>
      <select id="eIsActive">
        <option value="true">Active</option>
        <option value="false">Inactive</option>
      </select>
    </div>

    <div id="editError" class="error hidden"></div>
    <div id="editSuccess" class="success-box hidden"></div>
    <div class="row" style="margin-top:16px">
      <button class="btn btn-success" onclick="saveKPI()" id="saveBtn">Save Changes</button>
      <button class="btn btn-outline" onclick="cancelEdit()">Cancel</button>
      <div style="flex:1"></div>
      <button class="btn btn-danger btn-sm" onclick="deleteKPI()" id="deleteBtn">Delete KPI</button>
    </div>
  </div>
</div>

<script>
const BASE = window.location.origin;
const SESSION_KEY = 'ddb_api_key';

let _allKpis = [];
let _pendingAction = null;
let _refData = null;
let _editingKpi = null;  // last KPI opened for editing; re-used to populate checkboxes once refData loads

// ── Reference data (dynamic checkboxes) ─────────────────── //

async function loadReferenceData() {
  const key = sessionStorage.getItem(SESSION_KEY);
  if (!key) return;
  try {
    const res = await fetch(BASE + '/api/v1/dashboard/reference-data', {
      headers: { 'X-API-Key': key }
    });
    if (!res.ok) return;
    _refData = await res.json();
    // If an edit form is already open, populate its checkboxes now that data arrived
    if (_editingKpi) renderEditCheckboxes(_editingKpi);
  } catch(e) { console.warn('Failed to load reference data:', e); }
}

function renderEditCheckboxes(selectedKpi) {
  if (!_refData) return;

  // Projects
  const projBox = document.getElementById('eProjects');
  const projectIds = Object.keys(_refData.projects || {}).sort();
  const selProjects = selectedKpi ? (selectedKpi.project_ids || []) : [];
  projBox.innerHTML = projectIds.map(pid =>
    `<label><input type="checkbox" value="${pid}" onchange="onEditProjectChange()"${selProjects.includes(pid) ? ' checked' : ''}> ${pid}</label>`
  ).join('') || '<span class="opt">No projects configured</span>';

  // Levels
  const lvlBox = document.getElementById('eLevels');
  const levels = _refData.levels || [];
  const selLevels = selectedKpi ? (selectedKpi.level_ids || []) : [];
  lvlBox.innerHTML = levels.map(l =>
    `<label><input type="checkbox" value="${l.id}"${selLevels.includes(l.id) ? ' checked' : ''}> ${l.name}</label>`
  ).join('') || '<span class="opt">No levels configured</span>';

  // Functions — based on selected projects
  updateEditFunctions(selectedKpi);
}

function onEditProjectChange() {
  updateEditFunctions();
}

function updateEditFunctions(selectedKpi) {
  const funcBox = document.getElementById('eFunctions');
  if (!_refData) { funcBox.innerHTML = '<span class="opt">Loading...</span>'; return; }

  const checkedProjects = [...document.querySelectorAll('#eProjects input:checked')].map(c => c.value);
  const funcSet = new Set();

  if (checkedProjects.length === 0) {
    for (const pid of Object.keys(_refData.projects || {})) {
      for (const f of (_refData.projects[pid].functions || [])) funcSet.add(f.id);
    }
  } else {
    for (const pid of checkedProjects) {
      const proj = (_refData.projects || {})[pid];
      if (proj) for (const f of (proj.functions || [])) funcSet.add(f.id);
    }
  }

  const funcs = [...funcSet].sort();
  const selFuncs = selectedKpi ? (selectedKpi.function_ids || []) : [];
  // Preserve already-checked values when changing projects
  const prevChecked = selectedKpi ? selFuncs : [...document.querySelectorAll('#eFunctions input:checked')].map(c => c.value);

  funcBox.innerHTML = funcs.map(fid =>
    `<label><input type="checkbox" value="${fid}"${prevChecked.includes(fid) ? ' checked' : ''}> ${fid}</label>`
  ).join('') || '<span class="opt">No functions for selected project(s)</span>';
}

// ── Auth ───────────────────────────────────────────────── //

function requireAuth(action) {
  if (sessionStorage.getItem(SESSION_KEY)) { action(); return; }
  _pendingAction = action;
  document.getElementById('authError').classList.add('hidden');
  document.getElementById('authKey').value = '';
  document.getElementById('authModal').classList.remove('hidden');
  setTimeout(() => document.getElementById('authKey').focus(), 50);
}

async function authenticate() {
  const btn = document.getElementById('authBtn');
  const errBox = document.getElementById('authError');
  const key = document.getElementById('authKey').value.trim();
  errBox.classList.add('hidden');
  if (!key) { errBox.textContent = 'Please enter your API key.'; errBox.classList.remove('hidden'); return; }
  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Verifying...';
  try {
    const res = await fetch(BASE + '/api/v1/kpi-builder/template-params', { headers: { 'X-API-Key': key } });
    if (!res.ok) throw new Error(res.status === 401 || res.status === 403 ? 'Invalid API key.' : 'Server error');
    sessionStorage.setItem(SESSION_KEY, key);
    document.getElementById('authModal').classList.add('hidden');
    updateAuthBar();
    loadReferenceData();
    const action = _pendingAction; _pendingAction = null;
    if (action) action();
  } catch(e) { errBox.textContent = e.message; errBox.classList.remove('hidden'); }
  finally { btn.disabled = false; btn.textContent = 'Authenticate'; }
}

function logout() { sessionStorage.removeItem(SESSION_KEY); updateAuthBar(); }

function updateAuthBar() {
  const bar = document.getElementById('authStatusBar');
  const key = sessionStorage.getItem(SESSION_KEY);
  bar.innerHTML = key
    ? '<div class="auth-badge"><span>&#128274; Authenticated</span></div>' +
      '<button class="btn-sm btn-outline" style="margin-top:6px;border:1px solid #fca5a5;color:#b91c1c" onclick="logout()">Sign out</button>'
    : '';
}
(function(){ if (sessionStorage.getItem(SESSION_KEY)) updateAuthBar(); })();

async function apiFetch(path, method, body) {
  const key = sessionStorage.getItem(SESSION_KEY) || '';
  const opts = { method, headers: { 'Content-Type': 'application/json', 'X-API-Key': key } };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const res = await fetch(BASE + path, opts);
  const data = await res.json();
  if (!res.ok) throw new Error(data.detail || JSON.stringify(data));
  return data;
}

// ── Load KPIs ──────────────────────────────────────────── //

async function loadKPIs() {
  requireAuth(async () => {
    try {
      _allKpis = await apiFetch('/api/v1/kpi-builder/kpis', 'GET');
      populateProjectFilter();
      renderTable(_allKpis);
    } catch(e) {
      document.getElementById('kpiTableBody').innerHTML =
        '<tr><td colspan="8" style="text-align:center;color:#b91c1c;padding:40px">' + e.message + '</td></tr>';
    }
  });
}

function populateProjectFilter() {
  const sel = document.getElementById('filterProject');
  const projects = new Set();
  _allKpis.forEach(k => (k.project_ids || []).forEach(p => projects.add(p)));
  [...projects].sort().forEach(p => {
    const opt = document.createElement('option');
    opt.value = p; opt.textContent = p;
    sel.appendChild(opt);
  });
}

function renderTable(kpis) {
  const tbody = document.getElementById('kpiTableBody');
  document.getElementById('kpiCount').textContent = '(' + kpis.length + ' KPIs)';
  if (!kpis.length) {
    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#999;padding:40px">No KPIs found</td></tr>';
    return;
  }
  tbody.innerHTML = kpis.map(k => `
    <tr onclick="selectKPI('${k.kpi_id}')" data-id="${k.kpi_id}"
        data-name="${(k.kpi_name||'').toLowerCase()}"
        data-cat="${(k.kpi_category||'').toLowerCase()}"
        data-projects="${(k.project_ids||[]).join(',')}"
        data-active="${k.is_active}">
      <td><code>${k.kpi_id}</code></td>
      <td>${k.kpi_name || ''}</td>
      <td><span class="badge-cat">${k.kpi_category || ''}</span></td>
      <td>${(k.project_ids||[]).join(', ') || '-'}</td>
      <td style="font-size:.78rem">${(k.applicable_geo_levels||[]).join(', ')}</td>
      <td>${k.priority || 100}</td>
      <td class="${k.is_active ? 'status-active' : 'status-inactive'}">${k.is_active ? 'Active' : 'Inactive'}</td>
      <td><button class="btn btn-outline btn-sm" onclick="event.stopPropagation();selectKPI('${k.kpi_id}')">Edit</button></td>
    </tr>
  `).join('');
}

function filterTable() {
  const q = document.getElementById('searchBox').value.toLowerCase();
  const proj = document.getElementById('filterProject').value;
  const active = document.getElementById('filterActive').value;
  const filtered = _allKpis.filter(k => {
    if (q && !(k.kpi_id||'').toLowerCase().includes(q)
         && !(k.kpi_name||'').toLowerCase().includes(q)
         && !(k.kpi_category||'').toLowerCase().includes(q)) return false;
    if (proj && !(k.project_ids||[]).includes(proj)) return false;
    if (active !== '' && String(k.is_active) !== active) return false;
    return true;
  });
  renderTable(filtered);
}

// ── Select & edit ──────────────────────────────────────── //

function selectKPI(kpiId) {
  const kpi = _allKpis.find(k => k.kpi_id === kpiId);
  if (!kpi) return;
  _editingKpi = kpi;

  document.getElementById('editTitle').textContent = 'Edit: ' + kpi.kpi_name;
  document.getElementById('eKpiId').value         = kpi.kpi_id || '';
  document.getElementById('eKpiCode').value       = kpi.kpi_code || '';
  document.getElementById('eKpiName').value       = kpi.kpi_name || '';
  document.getElementById('eKpiCategory').value   = kpi.kpi_category || '';
  document.getElementById('eKpiDesc').value       = kpi.kpi_description || '';
  document.getElementById('eDisplayFormat').value  = kpi.display_format || 'NUMBER';
  document.getElementById('eUnitSymbol').value     = kpi.unit_symbol || '';
  document.getElementById('eDecimalPlaces').value  = kpi.decimal_places ?? 2;
  document.getElementById('eAggMethod').value      = kpi.aggregation_method || 'SUM';
  document.getElementById('eAggColumn').value      = kpi.aggregation_column || '';
  document.getElementById('ePriority').value       = kpi.priority ?? 100;
  document.getElementById('eRefreshFreq').value    = kpi.refresh_frequency || 'DAILY';
  document.getElementById('eKpiTag').value         = kpi.kpi_tag || '';
  document.getElementById('eParentKpiId').value    = kpi.parent_kpi_id || '';
  document.getElementById('eSqlTemplate').value    = kpi.sql_query_template || '';
  document.getElementById('eDrilldownSql').value   = kpi.drilldown_sql || '';
  document.getElementById('eSourceTables').value   = (kpi.source_tables || []).join(', ');
  document.getElementById('eIsActive').value       = String(kpi.is_active !== false);

  // Geo levels (static — always OVERALL/REGION/AREA/MARKET)
  document.querySelectorAll('#eGeoLevels input').forEach(cb => {
    cb.checked = (kpi.applicable_geo_levels || []).includes(cb.value);
  });

  // Projects, Functions, Levels — dynamic from reference data
  renderEditCheckboxes(kpi);

  // Highlight row
  document.querySelectorAll('.kpi-table tr.selected').forEach(r => r.classList.remove('selected'));
  const row = document.querySelector(`tr[data-id="${kpiId}"]`);
  if (row) row.classList.add('selected');

  document.getElementById('editError').classList.add('hidden');
  document.getElementById('editSuccess').classList.add('hidden');
  document.getElementById('editCard').classList.remove('hidden');
  document.getElementById('editCard').scrollIntoView({ behavior: 'smooth' });
}

function cancelEdit() {
  _editingKpi = null;
  document.getElementById('editCard').classList.add('hidden');
  document.querySelectorAll('.kpi-table tr.selected').forEach(r => r.classList.remove('selected'));
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function getChecked(groupId) {
  return [...document.querySelectorAll('#' + groupId + ' input:checked')].map(c => c.value);
}

function splitTrim(id) {
  const v = document.getElementById(id).value.trim();
  return v ? v.split(',').map(s => s.trim()).filter(Boolean) : [];
}

// ── Save ───────────────────────────────────────────────── //

async function saveKPI() {
  const btn = document.getElementById('saveBtn');
  const errBox = document.getElementById('editError');
  const sucBox = document.getElementById('editSuccess');
  errBox.classList.add('hidden');
  sucBox.classList.add('hidden');

  const geoLevels = getChecked('eGeoLevels');
  if (!geoLevels.length) { errBox.textContent = 'Select at least one geo level.'; errBox.classList.remove('hidden'); return; }

  const body = {
    kpi_id:                document.getElementById('eKpiId').value.trim(),
    kpi_code:              document.getElementById('eKpiCode').value.trim(),
    kpi_name:              document.getElementById('eKpiName').value.trim(),
    kpi_description:       document.getElementById('eKpiDesc').value.trim() || null,
    kpi_category:          document.getElementById('eKpiCategory').value.trim(),
    kpi_tag:               document.getElementById('eKpiTag').value || null,
    applicable_geo_levels: geoLevels,
    sql_query_template:    document.getElementById('eSqlTemplate').value.trim(),
    drilldown_sql:         document.getElementById('eDrilldownSql').value.trim() || null,
    aggregation_method:    document.getElementById('eAggMethod').value,
    aggregation_column:    document.getElementById('eAggColumn').value.trim() || null,
    display_format:        document.getElementById('eDisplayFormat').value,
    decimal_places:        parseInt(document.getElementById('eDecimalPlaces').value, 10),
    unit_symbol:           document.getElementById('eUnitSymbol').value.trim() || null,
    source_tables:         splitTrim('eSourceTables'),
    project_ids:           getChecked('eProjects').length ? getChecked('eProjects') : null,
    level_ids:              getChecked('eLevels').length ? getChecked('eLevels') : null,
    function_ids:          getChecked('eFunctions').length ? getChecked('eFunctions') : null,
    priority:              parseInt(document.getElementById('ePriority').value, 10) ?? 100,
    refresh_frequency:     document.getElementById('eRefreshFreq').value,
    is_active:             document.getElementById('eIsActive').value === 'true',
    parent_kpi_id:         document.getElementById('eParentKpiId').value.trim() || null,
  };

  if (!body.kpi_id || !body.sql_query_template) {
    errBox.textContent = 'KPI ID and SQL Template are required.';
    errBox.classList.remove('hidden'); return;
  }

  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Saving...';
  try {
    await apiFetch('/api/v1/kpi-builder/register', 'POST', body);
    // Refresh list and reload edit form with DB-confirmed values
    _allKpis = await apiFetch('/api/v1/kpi-builder/kpis', 'GET');
    filterTable();
    selectKPI(body.kpi_id);
    sucBox.textContent = 'KPI updated successfully.';
    sucBox.classList.remove('hidden');
  } catch(e) {
    errBox.textContent = e.message;
    errBox.classList.remove('hidden');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Save Changes';
  }
}

// ── Delete ─────────────────────────────────────────────── //

async function deleteKPI() {
  const kpiId = document.getElementById('eKpiId').value.trim();
  if (!confirm('Delete KPI "' + kpiId + '"? This cannot be undone.')) return;
  const btn = document.getElementById('deleteBtn');
  const errBox = document.getElementById('editError');
  errBox.classList.add('hidden');
  btn.disabled = true;
  try {
    await apiFetch('/api/v1/kpi-builder/kpis/' + encodeURIComponent(kpiId), 'DELETE');
    _allKpis = _allKpis.filter(k => k.kpi_id !== kpiId);
    filterTable();
    cancelEdit();
  } catch(e) {
    errBox.textContent = e.message;
    errBox.classList.remove('hidden');
  } finally {
    btn.disabled = false;
  }
}

// ── Boot ───────────────────────────────────────────────── //
loadKPIs();
// Load reference data independently so a slow reference-data response
// never blocks or interferes with the KPI table load or the edit form.
if (sessionStorage.getItem(SESSION_KEY)) loadReferenceData();
</script>
</body>
</html>
"""


@router.get("/manage", response_class=HTMLResponse, include_in_schema=False)
async def kpi_manager_page():
    """Serves the KPI Manager UI for editing existing KPIs."""
    return HTMLResponse(content=_MANAGE_HTML)
