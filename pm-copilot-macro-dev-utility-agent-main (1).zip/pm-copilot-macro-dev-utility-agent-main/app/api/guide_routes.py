from fastapi import APIRouter
from fastapi.responses import HTMLResponse

router = APIRouter(prefix="/api/v1", tags=["Guide"])

_GUIDE_HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>KPI Dashboard — User Guide</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#f8fafc;color:#1e293b;font-size:.92rem;line-height:1.6}
  nav{background:#0f172a;padding:0 24px;display:flex;align-items:center;gap:4px;height:44px;position:sticky;top:0;z-index:100;box-shadow:0 1px 3px rgba(0,0,0,.3)}
  nav span.brand{color:#94a3b8;font-size:.75rem;font-weight:700;letter-spacing:.08em;margin-right:12px}
  nav a{color:#cbd5e1;text-decoration:none;font-size:.82rem;padding:6px 12px;border-radius:4px;transition:background .15s}
  nav a:hover{background:#1e293b}
  nav a.active{color:#fff;background:#1e40af}
  nav .spacer{flex:1}
  nav a.small{color:#64748b;font-size:.75rem;padding:4px 8px}
  .hero{background:linear-gradient(135deg,#1e3a8a 0%,#1e40af 50%,#2563eb 100%);color:#fff;padding:48px 40px 40px}
  .hero h1{font-size:2rem;font-weight:700;margin-bottom:8px}
  .hero p{font-size:1rem;color:#bfdbfe;max-width:640px}
  .layout{display:grid;grid-template-columns:240px 1fr;gap:0;max-width:1200px;margin:0 auto;padding:32px 24px}
  .toc{position:sticky;top:60px;height:fit-content;padding-right:24px}
  .toc-title{font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.07em;color:#64748b;margin-bottom:10px}
  .toc a{display:block;font-size:.82rem;color:#475569;text-decoration:none;padding:4px 8px;border-radius:4px;margin-bottom:2px;border-left:2px solid transparent}
  .toc a:hover{background:#f1f5f9;color:#1e293b}
  .toc a.sub{padding-left:20px;font-size:.78rem;color:#64748b}
  .toc a.active{border-left-color:#2563eb;color:#1e40af;background:#eff6ff}
  .content{min-width:0}
  .section{margin-bottom:48px;scroll-margin-top:72px}
  h2{font-size:1.3rem;font-weight:700;color:#0f172a;margin-bottom:16px;padding-bottom:8px;border-bottom:2px solid #e2e8f0;display:flex;align-items:center;gap:10px}
  h2 .badge{font-size:.72rem;font-weight:600;padding:2px 8px;border-radius:10px;background:#dbeafe;color:#1d4ed8;vertical-align:middle}
  h3{font-size:1rem;font-weight:600;color:#1e293b;margin:20px 0 8px}
  p{margin-bottom:12px;color:#374151}
  .card{background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:20px;margin-bottom:16px}
  .step-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;margin-bottom:16px}
  .step{background:#fff;border:1px solid #e2e8f0;border-radius:8px;padding:16px;position:relative}
  .step-num{width:28px;height:28px;background:#2563eb;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.78rem;font-weight:700;margin-bottom:10px}
  .step h4{font-size:.88rem;font-weight:600;margin-bottom:6px}
  .step p{font-size:.8rem;color:#6b7280;margin:0}
  .step .arrow{position:absolute;right:-8px;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:1.2rem;z-index:1}
  code{background:#f1f5f9;padding:2px 6px;border-radius:4px;font-size:.82rem;font-family:'Courier New',monospace;color:#be185d}
  pre{background:#fff;color:#1e293b;border:1px solid #e2e8f0;padding:16px;border-radius:8px;overflow-x:auto;font-size:.8rem;line-height:1.7;margin-bottom:12px}
  pre .k{color:#1d4ed8;font-weight:600} pre .s{color:#166534} pre .c{color:#94a3b8;font-style:italic} pre .p{color:#7c3aed}
  .table-wrap{overflow-x:auto;margin-bottom:16px}
  table{width:100%;border-collapse:collapse;font-size:.83rem}
  th{background:#f8fafc;font-weight:600;text-align:left;padding:8px 12px;border-bottom:2px solid #e2e8f0;color:#374151}
  td{padding:8px 12px;border-bottom:1px solid #f1f5f9;vertical-align:top}
  tr:hover td{background:#f8fafc}
  .tag{display:inline-block;font-size:.72rem;padding:2px 7px;border-radius:10px;font-weight:600;margin:1px}
  .tag-blue{background:#dbeafe;color:#1d4ed8}
  .tag-green{background:#dcfce7;color:#166534}
  .tag-orange{background:#ffedd5;color:#9a3412}
  .tag-purple{background:#f3e8ff;color:#7e22ce}
  .info-box{background:#eff6ff;border:1px solid #bfdbfe;border-radius:6px;padding:12px 16px;margin-bottom:12px;font-size:.83rem;color:#1e40af}
  .warn-box{background:#fffbeb;border:1px solid #fde68a;border-radius:6px;padding:12px 16px;margin-bottom:12px;font-size:.83rem;color:#92400e}
  .tip-box{background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px;padding:12px 16px;margin-bottom:12px;font-size:.83rem;color:#166534}
  .flow{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:16px}
  .flow-node{background:#fff;border:1px solid #e2e8f0;border-radius:6px;padding:8px 14px;font-size:.82rem;font-weight:600;color:#1e293b}
  .flow-node.blue{background:#dbeafe;border-color:#93c5fd;color:#1d4ed8}
  .flow-node.green{background:#dcfce7;border-color:#86efac;color:#166534}
  .flow-arrow{color:#94a3b8;font-size:1rem}
  .page-link{display:inline-flex;align-items:center;gap:6px;background:#2563eb;color:#fff;text-decoration:none;padding:8px 16px;border-radius:6px;font-size:.82rem;font-weight:600;margin:4px;transition:background .15s}
  .page-link:hover{background:#1d4ed8}
  .page-link.outline{background:#fff;color:#2563eb;border:1px solid #2563eb}
  .page-link.outline:hover{background:#eff6ff}
</style>
</head>
<body>

<nav>
  <span class="brand">DYNAMIC DASHBOARD BUILDER</span>
  <a href="/api/v1/project-config/manage">Project Config</a>
  <a href="/api/v1/kpi-builder/form">KPI Builder</a>
  <a href="/api/v1/kpi-builder/manage">KPI Manager</a>
  <a href="/api/v1/guide" class="active">Guide</a>
  <span class="spacer"></span>
  <a href="/docs" target="_blank" class="small">API Docs ↗</a>
</nav>

<div class="hero">
  <h1>User Guide</h1>
  <p>Everything you need to onboard a new project, define KPIs, manage site data, and keep your dashboard running.</p>
</div>

<div class="layout">

  <!-- Table of Contents -->
  <aside class="toc">
    <div class="toc-title">Contents</div>
    <a href="#overview">Overview</a>
    <a href="#step1">1. Project Config</a>
    <a href="#step1-dims" class="sub">↳ Dimensions</a>
    <a href="#step1-sites" class="sub">↳ Site Data</a>
    <a href="#step2">2. KPI Builder</a>
    <a href="#step2-sql" class="sub">↳ Writing SQL</a>
    <a href="#step2-params" class="sub">↳ Bind Parameters</a>
    <a href="#step2-dims" class="sub">↳ Dimensions in SQL</a>
    <a href="#step2-bulk" class="sub">↳ Bulk Upload</a>
    <a href="#step3">3. KPI Manager</a>
    <a href="#step4">4. Calculations</a>
    <a href="#step5">5. Sites API</a>
    <a href="#ui-integration">6. UI Integration Guide</a>
    <a href="#ui-page-load" class="sub">↳ Page Load</a>
    <a href="#ui-filters" class="sub">↳ Filters</a>
    <a href="#ui-table" class="sub">↳ Table & Pagination</a>
    <a href="#ui-summary" class="sub">↳ Summary Cards</a>
    <a href="#ui-search" class="sub">↳ Search</a>
    <a href="#ui-labels" class="sub">↳ Column Labels</a>
    <a href="#faq">FAQ</a>
  </aside>

  <!-- Content -->
  <div class="content">

    <!-- Overview -->
    <section class="section" id="overview">
      <h2>Overview</h2>
      <p>The KPI Dashboard system has three configuration pages and a REST API. The typical onboarding flow is:</p>

      <div class="flow">
        <div class="flow-node blue">1. Project Config</div>
        <span class="flow-arrow">→</span>
        <div class="flow-node">2. KPI Builder</div>
        <span class="flow-arrow">→</span>
        <div class="flow-node">3. Trigger Calculation</div>
        <span class="flow-arrow">→</span>
        <div class="flow-node green">Dashboard Live</div>
      </div>

      <div class="step-grid">
        <div class="step">
          <div class="step-num">1</div>
          <h4>Project Config</h4>
          <p>Define the project, its functions, geo scope, filter dimensions, and site data source.</p>
        </div>
        <div class="step">
          <div class="step-num">2</div>
          <h4>KPI Builder</h4>
          <p>Write or AI-generate SQL templates for each KPI. Register them to the project.</p>
        </div>
        <div class="step">
          <div class="step-num">3</div>
          <h4>Calculate</h4>
          <p>Trigger a batch calculation via the API. Results are stored and served to the dashboard.</p>
        </div>
        <div class="step">
          <div class="step-num">4</div>
          <h4>Dashboard</h4>
          <p>The frontend queries pre-calculated values — fast reads, no live SQL on every load.</p>
        </div>
      </div>

      <div style="margin-top:8px">
        <a class="page-link" href="/api/v1/project-config/manage">Project Config →</a>
        <a class="page-link" href="/api/v1/kpi-builder/form">KPI Builder →</a>
        <a class="page-link" href="/api/v1/kpi-builder/manage">KPI Manager →</a>
      </div>
    </section>

    <!-- Step 1: Project Config -->
    <section class="section" id="step1">
      <h2>1. Project Config <span class="badge">START HERE</span></h2>
      <p>Every project must be registered before any KPIs can be created. The project config drives the entire calculation engine — which functions to calculate, which geographies to cover, and how to split results by dimensions.</p>

      <div class="card">
        <h3>Required fields</h3>
        <div class="table-wrap">
          <table>
            <tr><th>Field</th><th>Description</th><th>Example</th></tr>
            <tr><td><code>project_id</code></td><td>Unique short identifier. Cannot be changed after creation.</td><td><code>AHLOA</code></td></tr>
            <tr><td><code>project_name</code></td><td>Display name shown in the dashboard.</td><td><code>AHLOB Modernization</code></td></tr>
            <tr><td>Functions</td><td>One or more function tags (e.g. PDM, HSE, SECOE). Controls which KPIs appear for this project.</td><td><code>PDM</code>, <code>HSE</code></td></tr>
            <tr><td>Geo Codes</td><td>The geography natural keys this project covers. Must match values in <code>dim_geography</code>.</td><td><code>US_WEST</code>, <code>US_EAST</code></td></tr>
          </table>
        </div>
      </div>

      <section id="step1-dims">
        <h3>Filter Dimensions</h3>
        <p>Dimensions allow the engine to calculate every KPI broken down by a column in your source data — e.g. by <code>scope_of_work</code> or <code>smp_name</code>. Results are stored per dimension value alongside the ALL (undivided) result.</p>

        <div class="info-box">
          <strong>How it works:</strong> For each dimension you define (e.g. <code>scope_of_work: [NEW_BUILD, MODIFICATION]</code>), the engine runs every KPI SQL once with <code>:scope_of_work = 'ALL'</code> and once per value. Your SQL must handle the <code>= 'ALL'</code> case to return unfiltered results.
        </div>

        <pre><code><span class="c">-- Dimension-aware SQL pattern:</span>
<span class="k">WHERE</span> (:<span class="p">scope_of_work</span> = <span class="s">'ALL'</span> <span class="k">OR</span> scope_of_work = :<span class="p">scope_of_work</span>)
  <span class="k">AND</span> (:<span class="p">smp_name</span>      = <span class="s">'ALL'</span> <span class="k">OR</span> smp_name      = :<span class="p">smp_name</span>)</code></pre>

        <p>Enable <strong>Cross Filters</strong> to also calculate every combination (cartesian product) of dimension values. Warning: this multiplies the number of rows stored — use only when the UI needs crossed breakdowns.</p>
      </section>

      <section id="step1-sites">
        <h3>Site Data Configuration</h3>
        <p>If your project has a site list (e.g. tower sites, store locations), configure a <strong>Site Source Query</strong> to load and refresh it daily into <code>dim_sites</code>.</p>

        <div class="card">
          <h3>Site Source Query rules</h3>
          <ul style="padding-left:18px;font-size:.83rem;color:#374151;line-height:2">
            <li>Must return <code>site_id</code> (required — must be unique per project)</li>
            <li>Auto-detected fixed columns: <code>region_code</code>, <code>area_code</code>, <code>market_code</code>, <code>status</code>, <code>phase</code>, <code>progress_pct</code></li>
            <li>Any extra columns defined in <strong>Site Columns</strong> are stored in the <code>attributes</code> JSONB</li>
            <li>Do <strong>not</strong> include a trailing semicolon</li>
            <li>All computed values (phase, progress_pct) should be calculated in the SQL itself — no separate expression config needed</li>
          </ul>
        </div>

        <pre><code><span class="c">-- Example site source query</span>
<span class="k">SELECT</span>
    s_site_id                                           <span class="k">AS</span> site_id,
    rgn_region                                          <span class="k">AS</span> region_code,
    area_code,
    mkt_code                                            <span class="k">AS</span> market_code,
    site_status                                         <span class="k">AS</span> status,
    <span class="k">CASE</span> <span class="k">WHEN</span> pct_complete = 100 <span class="k">THEN</span> <span class="s">'COMPLETE'</span>
         <span class="k">WHEN</span> pct_complete > 0   <span class="k">THEN</span> <span class="s">'IN PROGRESS'</span>
         <span class="k">ELSE</span> <span class="s">'NOT STARTED'</span> <span class="k">END</span>  <span class="k">AS</span> phase,
    <span class="k">ROUND</span>(pct_complete, 2)                              <span class="k">AS</span> progress_pct,
    smp_name,
    contractor_name
<span class="k">FROM</span> staging_schema.sites_table
<span class="k">WHERE</span> project_name = <span class="s">'My Project'</span></code></pre>

        <p>After saving, click <strong>↻ Refresh Sites</strong> to do an immediate load. The refresh runs in the background — check the site count via <code>GET /api/v1/sites/{project_id}/summary</code>.</p>

        <div class="tip-box">
          <strong>Site Columns</strong> define which extra columns from your query are stored as filterable attributes. Mark <code>filterable: true</code> for columns that should appear in filter dropdowns (e.g. <code>smp_name</code>, <code>contractor_name</code>).
        </div>
      </section>
    </section>

    <!-- Step 2: KPI Builder -->
    <section class="section" id="step2">
      <h2>2. KPI Builder</h2>
      <p>Use the KPI Builder to register new KPI SQL templates. Each KPI is a parameterised SQL query that the engine runs on a schedule for every geography × dimension combination.</p>

      <div class="tip-box" style="margin-bottom:16px">
        <strong>AI SQL Generation:</strong> Don't want to write SQL from scratch? Paste your raw query idea or plain-English description into the <strong>Raw SQL / Description</strong> field and click <strong>Generate with AI</strong>. The AI will parameterise it correctly — adding <code>:start_date</code>, <code>:end_date</code>, <code>:geo_code</code>, and any dimension params — and populate the SQL Template field automatically. You can then review and edit before saving.
      </div>

      <section id="step2-sql">
        <h3>Writing the KPI SQL</h3>
        <p>Your SQL must return <strong>exactly one row</strong> with two columns:</p>
        <div class="table-wrap">
          <table>
            <tr><th>Column</th><th>Type</th><th>Description</th></tr>
            <tr><td><code>kpi_value</code></td><td>NUMERIC</td><td>The calculated metric value</td></tr>
            <tr><td><code>record_count</code></td><td>INTEGER</td><td>Number of source rows used in the calculation</td></tr>
          </table>
        </div>
        <pre><code><span class="k">SELECT</span>
    <span class="k">SUM</span>(revenue)    <span class="k">AS</span> kpi_value,
    <span class="k">COUNT</span>(*)        <span class="k">AS</span> record_count
<span class="k">FROM</span> sales_fact
<span class="k">WHERE</span> txn_date <span class="k">BETWEEN</span> :<span class="p">start_date</span> <span class="k">AND</span> :<span class="p">end_date</span>
  <span class="k">AND</span> geo_code = :<span class="p">geo_code</span></code></pre>
      </section>

      <section id="step2-params">
        <h3>Bind Parameters — always available</h3>
        <div class="table-wrap">
          <table>
            <tr><th>Parameter</th><th>Type</th><th>Description</th></tr>
            <tr><td><code>:start_date</code></td><td>date</td><td>Period start (inclusive) — <em>optional, only use if your KPI is date-filtered</em></td></tr>
            <tr><td><code>:end_date</code></td><td>date</td><td>Period end (inclusive) — <em>optional, only use if your KPI is date-filtered</em></td></tr>
            <tr><td><code>:geo_level</code></td><td>str</td><td>OVERALL / REGION / AREA / MARKET</td></tr>
            <tr><td><code>:geo_code</code></td><td>str</td><td>Natural key of the current geography (e.g. <code>US_WEST</code>)</td></tr>
            <tr><td><code>:region_code</code></td><td>str|NULL</td><td>Parent region's geo_code</td></tr>
            <tr><td><code>:area_code</code></td><td>str|NULL</td><td>Parent area's geo_code</td></tr>
            <tr><td><code>:geo_id</code></td><td>str</td><td>Surrogate key (rarely needed)</td></tr>
            <tr><td><code>:region_id</code></td><td>str|NULL</td><td>Parent region surrogate key</td></tr>
            <tr><td><code>:area_id</code></td><td>str|NULL</td><td>Parent area surrogate key</td></tr>
          </table>
        </div>

        <div class="warn-box">
          <strong>Geography levels:</strong> At <code>OVERALL</code> level, <code>:geo_code</code> is <code>'OVERALL'</code> and <code>:region_code</code>/<code>:area_code</code> are <code>NULL</code>. Your SQL must handle all levels or use <code>:geo_level</code> branching.
        </div>

        <pre><code><span class="c">-- Multi-level geography pattern</span>
<span class="k">WHERE</span> <span class="k">CASE</span> :<span class="p">geo_level</span>
    <span class="k">WHEN</span> <span class="s">'MARKET'</span>  <span class="k">THEN</span> market_col  = :<span class="p">geo_code</span>
    <span class="k">WHEN</span> <span class="s">'AREA'</span>    <span class="k">THEN</span> area_col    = :<span class="p">area_code</span>
    <span class="k">WHEN</span> <span class="s">'REGION'</span>  <span class="k">THEN</span> region_col  = :<span class="p">region_code</span>
    <span class="k">ELSE</span> TRUE  <span class="c">-- OVERALL: no filter</span>
<span class="k">END</span></code></pre>
      </section>

      <section id="step2-dims">
        <h3>Dimensions in SQL</h3>
        <p>When a project has <strong>filter dimensions</strong> configured, the engine passes each dimension as a bind parameter. The KPI Builder form shows a hint box with the exact WHERE clauses to add when you select a project.</p>

        <pre><code><span class="c">-- Add one clause per dimension defined on the project</span>
<span class="k">AND</span> (:<span class="p">scope_of_work</span> = <span class="s">'ALL'</span> <span class="k">OR</span> scope_of_work = :<span class="p">scope_of_work</span>)
<span class="k">AND</span> (:<span class="p">smp_name</span>      = <span class="s">'ALL'</span> <span class="k">OR</span> smp_name      = :<span class="p">smp_name</span>)</code></pre>

        <div class="tip-box">
          The <code>= 'ALL'</code> check is essential — when the engine calculates the unfiltered result it passes <code>'ALL'</code> as the dimension value. Without this check, the ALL result will return zero rows.
        </div>
      </section>

      <section id="step2-bulk">
        <h3>Bulk Upload</h3>
        <p>Use the <strong>Download Template</strong> button to get an Excel file pre-filled with column headers. Fill it in with multiple KPIs and use <strong>Bulk Upload</strong> to register them all at once. A dry-run validation runs before any rows are committed.</p>

        <div class="info-box">
          The dry-run executes each SQL against a test geography with <code>LIMIT 0</code>. It catches syntax errors and missing bind params but does not validate business logic. Dimension params not in the standard set are automatically defaulted to <code>'ALL'</code> during validation.
        </div>
      </section>
    </section>

    <!-- Step 3: KPI Manager -->
    <section class="section" id="step3">
      <h2>3. KPI Manager</h2>
      <p>The KPI Manager lets you view, search, edit, and delete existing KPI definitions. Changes take effect on the next calculation run.</p>

      <div class="card">
        <h3>Editing a KPI</h3>
        <ol style="padding-left:18px;font-size:.83rem;color:#374151;line-height:2.2">
          <li>Click a KPI row in the table to open the edit panel on the right</li>
          <li>Modify any fields — SQL template, display settings, thresholds</li>
          <li>Click <strong>Save Changes</strong> — the form reloads with DB-confirmed values</li>
          <li>Use <strong>Delete KPI</strong> to permanently remove it (cannot be undone)</li>
        </ol>
      </div>

      <div class="warn-box">
        <strong>Note:</strong> Editing a KPI's SQL does not retroactively recalculate historical values. Only future calculation runs will use the new SQL.
      </div>
    </section>

    <!-- Step 4: Calculations -->
    <section class="section" id="step4">
      <h2>4. Triggering Calculations</h2>
      <p>Calculations are triggered via the API (not from the UI pages). They run asynchronously and store results in <code>kpi_values_live</code>.</p>

      <div class="table-wrap">
        <table>
          <tr><th>Endpoint</th><th>Description</th></tr>
          <tr><td><code>POST /api/v1/calculation/trigger</code></td><td>Trigger a single KPI for a specific geo + period</td></tr>
          <tr><td><code>POST /api/v1/calculation/batch-refresh/markets</code></td><td>Recalculate all KPIs for all markets</td></tr>
          <tr><td><code>POST /api/v1/calculation/batch-refresh/areas</code></td><td>Recalculate all KPIs for all areas</td></tr>
          <tr><td><code>GET /api/v1/calculation/jobs/{job_id}</code></td><td>Poll job status and progress</td></tr>
        </table>
      </div>

      <div class="info-box">
        Calculation jobs run with a concurrency limit (default 10 parallel KPI queries). Large projects with many dimensions may take several minutes. Monitor via the jobs endpoint.
      </div>
    </section>

    <!-- Step 5: Sites API -->
    <section class="section" id="step5">
      <h2>5. Sites API</h2>
      <p>Once a project has <code>site_source_query</code> configured, the sites API provides paginated access to the site list.</p>

      <div class="table-wrap">
        <table>
          <tr><th>Endpoint</th><th>Description</th></tr>
          <tr><td><code>POST /api/v1/sites/{project_id}/refresh</code></td><td>Trigger a site data refresh (background, returns 202)</td></tr>
          <tr><td><code>GET /api/v1/sites/{project_id}/summary</code></td><td>Total count, progress brackets, phase/status distribution</td></tr>
          <tr><td><code>GET /api/v1/sites/{project_id}</code></td><td>Paginated site list with filters</td></tr>
          <tr><td><code>GET /api/v1/sites/{project_id}/filter-options</code></td><td>Distinct values for all filterable columns</td></tr>
          <tr><td><code>GET /api/v1/sites/{project_id}/sites/{site_id}</code></td><td>Single site detail</td></tr>
        </table>
      </div>

      <h3>List endpoint filters</h3>
      <div class="table-wrap">
        <table>
          <tr><th>Query Param</th><th>Description</th></tr>
          <tr><td><code>region_code</code></td><td>Filter by region</td></tr>
          <tr><td><code>area_code</code></td><td>Filter by area</td></tr>
          <tr><td><code>market_code</code></td><td>Filter by market</td></tr>
          <tr><td><code>phase</code></td><td>Filter by phase value</td></tr>
          <tr><td><code>status</code></td><td>Filter by status value</td></tr>
          <tr><td><code>search</code></td><td>Keyword search across site_id, all geography codes, phase, status, and all attribute values</td></tr>
          <tr><td><code>page</code></td><td>Page number (default 1)</td></tr>
          <tr><td><code>page_size</code></td><td>Rows per page (default 500, max 2000)</td></tr>
        </table>
      </div>

      <h3>Summary progress brackets</h3>
      <p>The summary endpoint returns site counts grouped into progress brackets:</p>
      <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px">
        <span class="tag tag-green">81-100</span>
        <span class="tag tag-blue">61-80</span>
        <span class="tag tag-orange">41-60</span>
        <span class="tag tag-orange">21-40</span>
        <span class="tag tag-orange">1-20</span>
        <span class="tag" style="background:#f1f5f9;color:#64748b">0</span>
        <span class="tag" style="background:#f1f5f9;color:#64748b">N/A</span>
      </div>
      <p>Each bracket returns <code>count</code> (number of sites) and <code>pct_of_total</code> (percentage of total sites in that bracket).</p>
    </section>

    <!-- UI Integration Guide -->
    <section class="section" id="ui-integration">
      <h2>6. UI Integration Guide <span class="badge">Sites Page</span></h2>
      <p>This section walks a frontend developer through integrating the Sites API into a site list page. All requests require the <code>X-API-Key</code> header.</p>

      <div class="step-grid">
        <div class="step">
          <div class="step-num">1</div>
          <h4>Load config &amp; filter options</h4>
          <p>On page mount, fetch project config for column labels and filter-options for dropdown data.</p>
        </div>
        <div class="step">
          <div class="step-num">2</div>
          <h4>Populate filters</h4>
          <p>Use filter-options response to fill region/area/market/phase/status dropdowns and progress brackets.</p>
        </div>
        <div class="step">
          <div class="step-num">3</div>
          <h4>Fetch summary cards</h4>
          <p>Call the summary endpoint to show total count and progress distribution at page load.</p>
        </div>
        <div class="step">
          <div class="step-num">4</div>
          <h4>Fetch site list</h4>
          <p>Call the list endpoint with active filters, page, and page_size. Render table and pagination controls from the response.</p>
        </div>
      </div>

      <!-- Step 1 -->
      <h3 id="ui-page-load">Step 1 — Page Load: Config &amp; Filter Options</h3>
      <p>Make two parallel calls on page mount:</p>
      <pre><span class="c">// 1a. Project config — needed for column_labels</span>
<span class="k">const</span> config = <span class="k">await</span> fetch(
  <span class="s">'/api/v1/project-config/{project_id}'</span>,
  { headers: { <span class="s">'X-API-Key'</span>: apiKey } }
).<span class="k">then</span>(r => r.json());

<span class="c">// 1b. Filter options — dropdowns + progress brackets</span>
<span class="k">const</span> opts = <span class="k">await</span> fetch(
  <span class="s">'/api/v1/sites/{project_id}/filter-options'</span>,
  { headers: { <span class="s">'X-API-Key'</span>: apiKey } }
).<span class="k">then</span>(r => r.json());</pre>

      <p>The <code>filter-options</code> response shape:</p>
      <pre>{
  <span class="s">"project_id"</span>:        <span class="s">"NTM"</span>,
  <span class="s">"region_codes"</span>:      [<span class="s">"CENTRAL"</span>, <span class="s">"SOUTH"</span>],
  <span class="s">"area_codes"</span>:        [<span class="s">"AREA_01"</span>, <span class="s">"AREA_02"</span>],
  <span class="s">"market_codes"</span>:      [<span class="s">"MKT_01"</span>, <span class="s">"MKT_02"</span>],
  <span class="s">"phases"</span>:            [<span class="s">"Design"</span>, <span class="s">"Build"</span>, <span class="s">"Live"</span>],
  <span class="s">"statuses"</span>:          [<span class="s">"Active"</span>, <span class="s">"On Hold"</span>],
  <span class="s">"progress_brackets"</span>: [<span class="s">"81-100"</span>, <span class="s">"61-80"</span>, <span class="s">"41-60"</span>, ...],
  <span class="s">"attributes"</span>:        { <span class="s">"vendor"</span>: [<span class="s">"Ericsson"</span>, <span class="s">"Nokia"</span>] }
}</pre>

      <!-- Step 2 -->
      <h3 id="ui-filters">Step 2 — Filters</h3>
      <p>All filter parameters are optional query strings on the list endpoint. Multi-select values are passed as a <strong>single comma-separated string</strong>:</p>
      <div class="table-wrap">
        <table>
          <tr><th>Filter</th><th>Query param</th><th>Example value</th><th>Notes</th></tr>
          <tr><td>Region</td><td><code>region_code</code></td><td><code>CENTRAL,SOUTH</code></td><td>Case-insensitive; uppercased server-side</td></tr>
          <tr><td>Area</td><td><code>area_code</code></td><td><code>AREA_01</code></td><td>Single or comma-separated</td></tr>
          <tr><td>Market</td><td><code>market_code</code></td><td><code>MKT_01,MKT_02</code></td><td>Single or comma-separated</td></tr>
          <tr><td>Phase</td><td><code>phase</code></td><td><code>Build,Live</code></td><td>Exact match, case-sensitive</td></tr>
          <tr><td>Status</td><td><code>status</code></td><td><code>Active</code></td><td>Exact match</td></tr>
          <tr><td>Progress bracket</td><td><code>progress_bracket</code></td><td><code>81-100</code></td><td>One bracket at a time; values from filter-options</td></tr>
          <tr><td>Keyword search</td><td><code>search</code></td><td><code>Nokia</code></td><td>Searches site_id, region/area/market, phase, status, all attributes</td></tr>
        </table>
      </div>

      <p>Build the query string from active filter state:</p>
      <pre><span class="k">function</span> buildQuery(filters, page, pageSize) {
  <span class="k">const</span> p = <span class="k">new</span> URLSearchParams();
  <span class="k">if</span> (filters.region?.length)   p.set(<span class="s">'region_code'</span>,      filters.region.join(<span class="s">','</span>));
  <span class="k">if</span> (filters.area?.length)     p.set(<span class="s">'area_code'</span>,        filters.area.join(<span class="s">','</span>));
  <span class="k">if</span> (filters.market?.length)   p.set(<span class="s">'market_code'</span>,      filters.market.join(<span class="s">','</span>));
  <span class="k">if</span> (filters.phase?.length)    p.set(<span class="s">'phase'</span>,            filters.phase.join(<span class="s">','</span>));
  <span class="k">if</span> (filters.status?.length)   p.set(<span class="s">'status'</span>,           filters.status.join(<span class="s">','</span>));
  <span class="k">if</span> (filters.bracket)          p.set(<span class="s">'progress_bracket'</span>, filters.bracket);
  <span class="k">if</span> (filters.search)           p.set(<span class="s">'search'</span>,           filters.search);
  p.set(<span class="s">'page'</span>, page);
  p.set(<span class="s">'page_size'</span>, pageSize);
  <span class="k">return</span> p.toString();
}</pre>

      <!-- Step 3 -->
      <h3 id="ui-summary">Step 3 — Summary Cards</h3>
      <p>Call the summary endpoint to populate dashboard cards. Optionally pass region/area/market to scope the summary to the active filters:</p>
      <pre><span class="k">const</span> summary = <span class="k">await</span> fetch(
  <span class="s">`/api/v1/sites/{project_id}/summary?${new URLSearchParams({
    region_code: filters.region?.[0] ?? '',
    area_code:   filters.area?.[0]   ?? '',
  })}`</span>,
  { headers: { <span class="s">'X-API-Key'</span>: apiKey } }
).<span class="k">then</span>(r => r.json());</pre>

      <p>Summary response shape:</p>
      <pre>{
  <span class="s">"project_id"</span>:     <span class="s">"NTM"</span>,
  <span class="s">"total_sites"</span>:    412,
  <span class="s">"last_refreshed"</span>: <span class="s">"2026-04-01T04:00:00"</span>,
  <span class="s">"by_progress"</span>: {
    <span class="s">"81-100"</span>: { <span class="s">"count"</span>: 180, <span class="s">"pct_of_total"</span>: 43.7 },
    <span class="s">"61-80"</span>:  { <span class="s">"count"</span>: 130, <span class="s">"pct_of_total"</span>: 31.6 }
  },
  <span class="s">"by_phase"</span>:    { <span class="s">"Design"</span>: 80, <span class="s">"Build"</span>: 200, <span class="s">"Live"</span>: 132 },
  <span class="s">"by_status"</span>:   { <span class="s">"Active"</span>: 380, <span class="s">"On Hold"</span>: 32 }
}</pre>

      <p>Tip: clicking a progress bracket bar/chip in the UI should set <code>filters.bracket</code> to that bracket key (e.g. <code>"81-100"</code>) and re-fetch the site list — the <code>progress_bracket</code> filter matches exactly these bracket names.</p>

      <!-- Step 4 -->
      <h3 id="ui-table">Step 4 — Table &amp; Pagination</h3>
      <p>Fetch sites with active filters and render the table. Re-fetch on every filter/page change:</p>
      <pre><span class="k">async function</span> loadSites(page = 1) {
  <span class="k">const</span> qs = buildQuery(activeFilters, page, PAGE_SIZE);
  <span class="k">const</span> res = <span class="k">await</span> fetch(
    <span class="s">`/api/v1/sites/{project_id}?${qs}`</span>,
    { headers: { <span class="s">'X-API-Key'</span>: apiKey } }
  ).<span class="k">then</span>(r => r.json());

  renderTable(res.data);           <span class="c">// res.data = array of site objects</span>
  renderPagination(res.page, res.pages, res.total);
}</pre>

      <p>Site list response shape:</p>
      <pre>{
  <span class="s">"total"</span>:          412,
  <span class="s">"page"</span>:           1,
  <span class="s">"page_size"</span>:      500,
  <span class="s">"pages"</span>:          1,
  <span class="s">"project_id"</span>:     <span class="s">"NTM"</span>,
  <span class="s">"last_refreshed"</span>: <span class="s">"2026-04-01T04:00:00"</span>,
  <span class="s">"data"</span>: [
    {
      <span class="s">"site_id"</span>:      <span class="s">"S0001"</span>,
      <span class="s">"project_id"</span>:  <span class="s">"NTM"</span>,
      <span class="s">"region_code"</span>: <span class="s">"CENTRAL"</span>,
      <span class="s">"area_code"</span>:   <span class="s">"AREA_01"</span>,
      <span class="s">"market_code"</span>: <span class="s">"MKT_01"</span>,
      <span class="s">"phase"</span>:       <span class="s">"Build"</span>,
      <span class="s">"progress_pct"</span>: 82.5,
      <span class="s">"status"</span>:      <span class="s">"Active"</span>,
      <span class="s">"attributes"</span>:  { <span class="s">"vendor"</span>: <span class="s">"Ericsson"</span>, <span class="s">"tower_type"</span>: <span class="s">"Macro"</span> }
    }
  ]
}</pre>

      <p>The <code>attributes</code> field is a JSON object containing all project-specific columns configured in Project Config. The keys present depend on the project's <code>site_columns</code> configuration.</p>

      <!-- Step 5 -->
      <h3 id="ui-search">Step 5 — Search</h3>
      <p>Pass the search bar value as the <code>search</code> query param. It performs a case-insensitive substring match across <em>all</em> columns — site_id, region/area/market codes, phase, status, and all attribute key-values:</p>
      <pre><span class="c">// Debounce the input by 300ms, then re-fetch page 1</span>
searchInput.addEventListener(<span class="s">'input'</span>, debounce(() => {
  activeFilters.search = searchInput.value.trim() || <span class="k">undefined</span>;
  loadSites(1);
}, 300));</pre>
      <p>Clear <code>search</code> from the filters object (or omit the param) to remove the keyword filter. All other active filters remain in effect alongside the search.</p>

      <!-- Step 6 -->
      <h3 id="ui-labels">Step 6 — Column Labels</h3>
      <p>The <code>column_labels</code> map in the project config lets admins rename the fixed columns for display. Always use the label when rendering table headers:</p>
      <pre><span class="k">const</span> labels = config.column_labels || {};

<span class="k">const</span> FIXED_COLS = [
  <span class="s">'site_id'</span>, <span class="s">'region_code'</span>, <span class="s">'area_code'</span>, <span class="s">'market_code'</span>,
  <span class="s">'phase'</span>, <span class="s">'progress_pct'</span>, <span class="s">'status'</span>
];

<span class="c">// Render header cell — use label if set, otherwise prettify the key</span>
<span class="k">function</span> colHeader(key) {
  <span class="k">return</span> labels[key] || key.replace(/_/g, <span class="s">' '</span>)
    .replace(/\b\w/g, c => c.toUpperCase());
}

<span class="c">// For attribute columns, use site_columns config from project config</span>
<span class="k">const</span> attrCols = Object.keys(config.site_columns || {});
<span class="k">const</span> allHeaders = [...FIXED_COLS, ...attrCols].map(colHeader);</pre>

      <p>The <code>site_columns</code> map (from project config) also carries a <code>filterable</code> flag per attribute column. Use this to decide whether to show a filter control for that column:</p>
      <pre><span class="k">const</span> siteColumns = config.site_columns || {};
Object.entries(siteColumns).forEach(([col, def]) => {
  <span class="k">if</span> (def.filterable) {
    <span class="c">// opts.attributes[col] has the distinct values for this column</span>
    renderAttributeFilter(col, colHeader(col), opts.attributes[col] || []);
  }
});</pre>

      <div class="card" style="background:#eff6ff;border-color:#bfdbfe">
        <h3 style="color:#1d4ed8">Quick-reference: full site list URL</h3>
        <pre style="background:#fff"><span class="k">GET</span> /api/v1/sites/{project_id}
  ?region_code=CENTRAL,SOUTH   <span class="c"># comma-sep multi-select</span>
  &amp;market_code=MKT_01
  &amp;phase=Build,Live
  &amp;progress_bracket=81-100
  &amp;search=Nokia
  &amp;page=1
  &amp;page_size=500</pre>
        <p style="margin:0;font-size:.82rem;color:#1e40af">All filter params are optional and combinable. The <code>total</code> and <code>pages</code> fields in the response drive pagination controls.</p>
      </div>
    </section>

    <!-- FAQ -->
    <section class="section" id="faq">
      <h2>FAQ</h2>

      <div class="card">
        <h3>My KPI saved but the dashboard shows old values</h3>
        <p>Editing a KPI only updates the definition. You need to trigger a new calculation run via the API for the new SQL to be executed and results updated.</p>
      </div>

      <div class="card">
        <h3>The site refresh succeeds but shows 0 rows</h3>
        <p>Check that your <code>site_source_query</code> actually returns rows when run directly in your DB client. Also verify the project exists in <code>dim_project_config</code> and the query does not end with a semicolon.</p>
      </div>

      <div class="card">
        <h3>Bulk upload dry-run fails with "bind parameter not found"</h3>
        <p>Your SQL has a dimension parameter (e.g. <code>:scope_of_work</code>) that isn't in the standard parameter set. This is normal — dimension params are automatically defaulted to <code>'ALL'</code> during validation. If the error persists, check for typos in parameter names.</p>
      </div>

      <div class="card">
        <h3>I changed a dimension value in Project Config but old values remain in kpi_values</h3>
        <p>Old dimension keys are not automatically deleted. Trigger a full batch recalculation after changing dimensions. Old keys will be superseded by new ones but won't be removed until archival runs.</p>
      </div>

      <div class="card">
        <h3>What's the difference between geo_code and region/area/market codes?</h3>
        <p>In the KPI engine, <code>:geo_code</code> is the natural key of the <em>current</em> geography being calculated — it could be a market, area, or region depending on <code>:geo_level</code>. In the sites table, <code>region_code</code>, <code>area_code</code>, and <code>market_code</code> are three separate fixed columns representing the full hierarchy of each site.</p>
      </div>
    </section>

  </div><!-- end content -->
</div><!-- end layout -->

<script>
  // Highlight active TOC link on scroll
  const sections = document.querySelectorAll('.section');
  const tocLinks = document.querySelectorAll('.toc a');
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        tocLinks.forEach(a => a.classList.remove('active'));
        const link = document.querySelector(`.toc a[href="#${e.target.id}"]`);
        if (link) link.classList.add('active');
      }
    });
  }, { rootMargin: '-20% 0px -70% 0px' });
  sections.forEach(s => observer.observe(s));
</script>
</body>
</html>"""


@router.get("/guide", response_class=HTMLResponse, include_in_schema=False)
async def guide_page():
    """Serves the user guide."""
    return HTMLResponse(content=_GUIDE_HTML)
