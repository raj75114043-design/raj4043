import logging
from typing import Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import AsyncSessionLocal, get_db
from app.core.exceptions import KGAPIError, SiteInsightsError, WorkflowAPIError
from app.core.security import verify_api_key
from app.models.insights_models import (
    InsightFeedbackEntry,
    InsightFeedbackListResponse,
    InsightFeedbackRequest,
    InsightFeedbackSummary,
    InsightsJobStatus,
    SiteInsightsResponse,
)
from app.services.insight_feedback_service import InsightFeedbackService
from app.services.insights_job_service import InsightsJobService
from app.services.site_insights_service import SiteInsightsService

router = APIRouter(prefix="/api/v1/insights", tags=["Site Insights"])
logger = logging.getLogger(__name__)


# ------------------------------------------------------------------ #
# Synchronous endpoint (unchanged)                                    #
# ------------------------------------------------------------------ #

@router.get(
    "/site/{project_id}/{smp_id}",
    response_model=SiteInsightsResponse,
    summary="Get deep insights for a specific site (synchronous, ~30s)",
    description=(
        "Returns an LLM-generated narrative insight along with structured "
        "phase/workflow analysis and PM comments for a single site.\n\n"
        "Source is driven by project_config.insights_source ('workflow' or 'kg'). "
        "Pass `source=workflow|kg` to override the configured source for this call.\n\n"
        "This endpoint blocks until generation is complete (~30s on a cache miss). "
        "For a UI-friendly polling pattern, use POST /jobs + GET /jobs/{job_id} instead.\n\n"
        "Results are cached per (project_id, smp_id) within `INSIGHTS_CACHE_TTL_HOURS`. "
        "Pass `refresh=true` to bypass the cache."
    ),
)
async def get_site_insights(
    project_id: str,
    smp_id: str,
    refresh: bool = Query(
        False,
        description="Bypass the cache and force LLM regeneration. Use sparingly — LLM calls are slow.",
    ),
    source: Optional[str] = Query(
        None,
        regex="^(workflow|kg)$",
        description="Override the configured insights_source for this call. 'workflow' or 'kg'.",
    ),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    try:
        svc = SiteInsightsService(db)
        return await svc.get_insights(
            project_id, smp_id, refresh=refresh, source_override=source
        )
    except SiteInsightsError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except WorkflowAPIError as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Workflow API error: {exc}",
        )
    except KGAPIError as exc:
        if exc.status_code == 404:
            raise HTTPException(
                status_code=404,
                detail=f"Site '{smp_id}' not found in KG for project '{project_id}'.",
            )
        raise HTTPException(
            status_code=502,
            detail=f"KG API error: {exc}",
        )


# ------------------------------------------------------------------ #
# Polling endpoints                                                   #
# ------------------------------------------------------------------ #

@router.post(
    "/site/{project_id}/{smp_id}/jobs",
    response_model=InsightsJobStatus,
    status_code=202,
    summary="Start (or reuse) a background insights job",
    description=(
        "Kicks off site-insight generation in the background and returns a job "
        "handle the UI can poll via GET /api/v1/insights/jobs/{job_id}.\n\n"
        "If a fresh cached result is available, the job is created with "
        "status='done' and result populated immediately — no polling needed.\n\n"
        "If a pending/running job already exists for the same (project, site, source), "
        "its job_id is returned instead of starting a new one (prevents duplicate LLM calls). "
        "Pass `refresh=true` to force a new job."
    ),
)
async def start_insights_job(
    project_id: str,
    smp_id: str,
    background_tasks: BackgroundTasks,
    refresh: bool = Query(False),
    source: Optional[str] = Query(
        None,
        regex="^(workflow|kg)$",
        description="Override the configured insights_source for this call.",
    ),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    # Determine effective source so dedupe is per-source
    config_svc = SiteInsightsService(db)
    config = await config_svc._get_project_config(project_id)
    if not config:
        raise HTTPException(status_code=404, detail=f"Project '{project_id}' not found.")
    effective_source = (
        (source or config.get("insights_source") or "workflow")
    ).lower()
    if effective_source not in ("workflow", "kg"):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid source '{effective_source}'. Must be 'workflow' or 'kg'.",
        )

    job_svc = InsightsJobService(db)
    job = await job_svc.create_or_reuse(
        project_id=project_id,
        smp_id=smp_id,
        source=effective_source,
        refresh=refresh,
    )

    # Reused job that is still running OR already finished — nothing to enqueue.
    if job["status"] in ("running", "done", "failed") and not refresh:
        return _job_to_response(job)

    # Fast path: cache hit. Avoid spawning a background task entirely.
    if not refresh:
        cached = await config_svc._read_cache(
            project_id, smp_id, expected_source=effective_source
        )
        if cached is not None:
            await job_svc.complete(job["job_id"], cached.model_dump(mode="json"))
            job = await job_svc.get(job["job_id"])
            return _job_to_response(job)

    # Cache miss — run generation in the background and return the pending job.
    background_tasks.add_task(
        _run_insights_job,
        job_id=job["job_id"],
        project_id=project_id,
        smp_id=smp_id,
        refresh=refresh,
        source_override=source,
    )
    return _job_to_response(job)


@router.get(
    "/jobs/{job_id}",
    response_model=InsightsJobStatus,
    summary="Poll a background insights job",
    description=(
        "Returns the current status, stage, progress percentage, partial data "
        "(once available), and final result (when status='done'). Poll every "
        "1-2 seconds while status is 'pending' or 'running'."
    ),
)
async def get_insights_job(
    job_id: str,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    job_svc = InsightsJobService(db)
    job = await job_svc.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found.")
    return _job_to_response(job)


# ------------------------------------------------------------------ #
# Background runner                                                   #
# ------------------------------------------------------------------ #

async def _run_insights_job(
    job_id: str,
    project_id: str,
    smp_id: str,
    refresh: bool,
    source_override: Optional[str],
) -> None:
    """Run insight generation against its own DB session; report stages back to the job row."""
    # Use a dedicated session for stage updates so each UPDATE commits independently
    # and is visible to pollers while the main session is still busy.
    async with AsyncSessionLocal() as report_session:
        job_svc = InsightsJobService(report_session)

        async def report_stage(stage_name: str) -> None:
            await job_svc.update_stage(job_id, stage_name)

        async def report_partial(partial_data: dict) -> None:
            await job_svc.set_partial(job_id, partial_data)

        async with AsyncSessionLocal() as work_session:
            insights_svc = SiteInsightsService(work_session)
            try:
                response = await insights_svc.get_insights(
                    project_id=project_id,
                    smp_id=smp_id,
                    refresh=refresh,
                    source_override=source_override,
                    report_stage=report_stage,
                    report_partial=report_partial,
                )
                await job_svc.complete(job_id, response.model_dump(mode="json"))
            except SiteInsightsError as exc:
                await job_svc.fail(job_id, str(exc))
            except KGAPIError as exc:
                msg = (
                    f"Site '{smp_id}' not found in KG for project '{project_id}'."
                    if exc.status_code == 404 else f"KG API error: {exc}"
                )
                await job_svc.fail(job_id, msg)
            except WorkflowAPIError as exc:
                await job_svc.fail(job_id, f"Workflow API error: {exc}")
            except Exception as exc:  # pragma: no cover — last-resort safety
                logger.exception("Unexpected error in insights job %s", job_id)
                await job_svc.fail(job_id, f"Unexpected error: {exc}")


# ------------------------------------------------------------------ #
# Helpers                                                              #
# ------------------------------------------------------------------ #

def _job_to_response(job: dict) -> InsightsJobStatus:
    """Project a DB row dict onto the polling response model."""
    stages = job.get("stages_completed") or []
    stage_label = None
    if stages and isinstance(stages, list):
        last = stages[-1]
        if isinstance(last, dict):
            stage_label = last.get("label")
    return InsightsJobStatus(
        job_id=job["job_id"],
        project_id=job["project_id"],
        smp_id=job["smp_id"],
        source=job["source"],
        status=job["status"],
        stage=job.get("stage"),
        stage_label=stage_label,
        progress_pct=job.get("progress_pct") or 0,
        stages_completed=stages,
        partial=job.get("partial"),
        result=job.get("result"),
        error=job.get("error"),
        created_at=job["created_at"],
        updated_at=job["updated_at"],
    )


# ------------------------------------------------------------------ #
# Feedback (thumbs up/down + optional comment)                        #
# ------------------------------------------------------------------ #

@router.post(
    "/site/{project_id}/{smp_id}/feedback",
    response_model=InsightFeedbackEntry,
    status_code=201,
    summary="Submit thumbs up/down + optional comment for a site insight",
    description=(
        "Records a like/dislike (and optional comment) against a specific "
        "insight generation. `generation_id` should be the `generated_at` "
        "string returned in the insight response. Submitting again with the "
        "same (user_id, generation_id) updates the existing row instead of "
        "creating a duplicate."
    ),
)
async def submit_site_insight_feedback(
    project_id: str,
    smp_id: str,
    body: InsightFeedbackRequest,
    source: Optional[str] = Query(
        None,
        regex="^(workflow|kg)$",
        description="Insight source the user is rating ('workflow' or 'kg'). Optional but useful for analytics.",
    ),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    svc = InsightFeedbackService(db)
    try:
        row = await svc.submit(
            surface="site",
            project_id=project_id,
            site_key=smp_id,
            generation_id=body.generation_id,
            user_id=body.user_id,
            rating=body.rating,
            comment=body.comment,
            source=source,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    return row


@router.get(
    "/site/{project_id}/{smp_id}/feedback",
    response_model=InsightFeedbackListResponse,
    summary="List feedback for a site insight",
    description=(
        "Returns the per-generation feedback rows plus an aggregate summary "
        "(up/down/comments counts). Pass `?generation_id=...` to scope to "
        "one insight version."
    ),
)
async def list_site_insight_feedback(
    project_id: str,
    smp_id: str,
    generation_id: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    svc = InsightFeedbackService(db)
    entries = await svc.list_for_target(
        surface="site",
        project_id=project_id,
        site_key=smp_id,
        generation_id=generation_id,
    )
    summary = await svc.summary_for_target(
        surface="site",
        project_id=project_id,
        site_key=smp_id,
        generation_id=generation_id,
    )
    return InsightFeedbackListResponse(
        summary=InsightFeedbackSummary(**summary),
        entries=entries,
    )


@router.delete(
    "/site/{project_id}/{smp_id}/feedback/{feedback_id}",
    summary="Delete a feedback row (owner only)",
    description=(
        "Removes a feedback row. Only the original submitter (matched by "
        "`user_id` query param) can delete. Returns 404 if not found or owned."
    ),
)
async def delete_site_insight_feedback(
    project_id: str,
    smp_id: str,
    feedback_id: str,
    user_id: str = Query(..., description="Must match the submitter's user_id."),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    svc = InsightFeedbackService(db)
    deleted = await svc.delete(feedback_id, user_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Feedback not found or not owned by user.")
    return {"deleted": True, "feedback_id": feedback_id}
