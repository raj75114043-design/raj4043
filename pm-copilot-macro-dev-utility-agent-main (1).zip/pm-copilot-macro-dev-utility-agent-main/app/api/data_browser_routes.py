import logging
from typing import Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, Request
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import AsyncSessionLocal, get_db
from app.core.exceptions import SiteInsightsError
from app.core.security import verify_api_key
from app.models.insights_models import (
    InsightFeedbackEntry,
    InsightFeedbackListResponse,
    InsightFeedbackRequest,
    InsightFeedbackSummary,
)
from app.services.data_browser_insights_service import DataBrowserInsightsService
from app.services.data_browser_service import DataBrowserService
from app.services.insight_feedback_service import InsightFeedbackService

router = APIRouter(prefix="/api/v1/data-browser", tags=["Data Browser"])
logger = logging.getLogger(__name__)


# ------------------------------------------------------------------ #
# List available tables                                                #
# ------------------------------------------------------------------ #

@router.get("/{project_id}/tables")
async def list_tables(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """List all data browser tables configured for a project."""
    try:
        svc = DataBrowserService(db)
        return await svc.list_tables(project_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


# ------------------------------------------------------------------ #
# Browse a single table                                                #
# ------------------------------------------------------------------ #

@router.get("/{project_id}/tables/{table_alias}")
async def browse_table(
    request: Request,
    project_id: str,
    table_alias: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
    search: Optional[str] = Query(None, description="Search across all columns"),
    sort_by: Optional[str] = Query(None, description="Column to sort by"),
    sort_order: str = Query("asc", description="asc or desc"),
    site_id: Optional[str] = Query(None, description="Indexed point lookup — return only rows matching this site_id"),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    Paginated browse of a data browser table.

    Supports:
    - `search`: global text search across all columns
    - `sort_by` / `sort_order`: sort by any column
    - `site_id`: indexed lookup of all rows for one site in this table
    - Dynamic column filters via query params prefixed with `f_`
      e.g. `?f_vendor_name=Nokia&f_region=EAST`
    """
    filters = {}
    for key, val in request.query_params.items():
        if key.startswith("f_") and val:
            filters[key[2:]] = val

    try:
        svc = DataBrowserService(db)
        return await svc.browse_table(
            project_id=project_id,
            table_alias=table_alias,
            page=page,
            page_size=page_size,
            search=search,
            filters=filters or None,
            sort_by=sort_by,
            sort_order=sort_order,
            site_id=site_id,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


# ------------------------------------------------------------------ #
# Unified site index across all tables                                 #
# ------------------------------------------------------------------ #

@router.get("/{project_id}/sites")
async def list_unique_sites(
    project_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
    search: Optional[str] = Query(None, description="ILIKE match on site_id"),
    present_in: Optional[str] = Query(None, description="Comma-separated table aliases the site MUST appear in"),
    absent_from: Optional[str] = Query(None, description="Comma-separated table aliases the site must NOT appear in"),
    region_code: Optional[str] = Query(None, description="Exact match on resolved region_code"),
    market_code: Optional[str] = Query(None, description="Exact match on resolved market_code"),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    Unified list of unique sites across every data browser table.

    Each row carries a `presence` map of {table_alias: row_count} for every
    indexed table — 0 means the site is absent from that table — plus the
    resolved `region_code` and `market_code` (first non-null wins, by table
    priority order in `data_browser_tables` config). Use the `site_id`
    query param on the table-browse endpoint to pull the actual rows for a
    site in a specific table.
    """
    try:
        present = [s.strip() for s in present_in.split(",") if s.strip()] if present_in else None
        absent = [s.strip() for s in absent_from.split(",") if s.strip()] if absent_from else None
        svc = DataBrowserService(db)
        return await svc.list_unique_sites(
            project_id=project_id,
            page=page,
            page_size=page_size,
            search=search,
            present_in=present,
            absent_from=absent,
            region_code=region_code,
            market_code=market_code,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


# ------------------------------------------------------------------ #
# Filter options for the unified sites list                            #
# ------------------------------------------------------------------ #

@router.get("/{project_id}/sites/filter-options")
async def get_unique_sites_filter_options(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    Distinct filter values for the unified sites list.

    Returns region_codes, market_codes, a region→market hierarchy for
    cascading dropdowns, and the list of indexed table aliases (use these
    with `present_in` / `absent_from` on the /sites endpoint).
    """
    try:
        svc = DataBrowserService(db)
        return await svc.get_unique_sites_filter_options(project_id)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


# ------------------------------------------------------------------ #
# Cross-process LLM insights for a single site                         #
# ------------------------------------------------------------------ #

@router.get("/{project_id}/sites/{site_id}/insights")
async def get_site_insights(
    project_id: str,
    site_id: str,
    refresh: bool = Query(False, description="Bypass cache and regenerate"),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    Generate a cross-process insight for a site using the LLM.

    Pulls this site's rows from every indexed data browser table (capped at
    DATA_BROWSER_INSIGHTS_MAX_ROWS_PER_TABLE per process), passes them to
    the LLM along with each process's user-supplied `description`, and
    returns a structured PM-style status update. Cached per (project_id,
    site_id) for INSIGHTS_CACHE_TTL_HOURS; pass `?refresh=true` to bypass.
    """
    try:
        svc = DataBrowserInsightsService(db)
        return await svc.get_insights(project_id, site_id, refresh=refresh)
    except SiteInsightsError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


# ------------------------------------------------------------------ #
# Feedback on cross-process insights                                   #
# ------------------------------------------------------------------ #

@router.post(
    "/{project_id}/sites/{site_id}/insights/feedback",
    response_model=InsightFeedbackEntry,
    status_code=201,
    summary="Submit thumbs up/down + optional comment for a data-browser insight",
    description=(
        "Records a like/dislike (and optional comment) against a specific "
        "cross-process insight generation. `generation_id` should be the "
        "`generated_at` string returned in the insight response. Re-submitting "
        "with the same (user_id, generation_id) updates the existing row."
    ),
)
async def submit_browser_insight_feedback(
    project_id: str,
    site_id: str,
    body: InsightFeedbackRequest,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    svc = InsightFeedbackService(db)
    try:
        return await svc.submit(
            surface="data_browser",
            project_id=project_id,
            site_key=site_id,
            generation_id=body.generation_id,
            user_id=body.user_id,
            rating=body.rating,
            comment=body.comment,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))


@router.get(
    "/{project_id}/sites/{site_id}/insights/feedback",
    response_model=InsightFeedbackListResponse,
    summary="List feedback for a data-browser insight",
)
async def list_browser_insight_feedback(
    project_id: str,
    site_id: str,
    generation_id: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    svc = InsightFeedbackService(db)
    entries = await svc.list_for_target(
        surface="data_browser",
        project_id=project_id,
        site_key=site_id,
        generation_id=generation_id,
    )
    summary = await svc.summary_for_target(
        surface="data_browser",
        project_id=project_id,
        site_key=site_id,
        generation_id=generation_id,
    )
    return InsightFeedbackListResponse(
        summary=InsightFeedbackSummary(**summary),
        entries=entries,
    )


@router.delete(
    "/{project_id}/sites/{site_id}/insights/feedback/{feedback_id}",
    summary="Delete a feedback row (owner only)",
)
async def delete_browser_insight_feedback(
    project_id: str,
    site_id: str,
    feedback_id: str,
    user_id: str = Query(..., description="Must match the submitter's user_id."),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    svc = InsightFeedbackService(db)
    deleted = await svc.delete(feedback_id, user_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Feedback not found or not owned by user.")
    return {"deleted": True, "feedback_id": feedback_id}


# ------------------------------------------------------------------ #
# Search across all tables                                             #
# ------------------------------------------------------------------ #

@router.get("/{project_id}/search")
async def search_all_tables(
    project_id: str,
    q: str = Query(..., description="Search term"),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """Search across all data browser tables for a project."""
    try:
        svc = DataBrowserService(db)
        return await svc.search_all_tables(
            project_id=project_id,
            search=q,
            page_size=page_size,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))


# ------------------------------------------------------------------ #
# Filter options for a table                                           #
# ------------------------------------------------------------------ #

@router.get("/{project_id}/tables/{table_alias}/filter-options")
async def get_filter_options(
    project_id: str,
    table_alias: str,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """Get distinct values for filterable columns of a table."""
    try:
        svc = DataBrowserService(db)
        return await svc.get_filter_options(project_id, table_alias)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


# ------------------------------------------------------------------ #
# Refresh                                                              #
# ------------------------------------------------------------------ #

async def _run_refresh_background(project_id: str) -> None:
    async with AsyncSessionLocal() as db:
        try:
            svc = DataBrowserService(db)
            result = await svc.refresh_project_tables(project_id)
            logger.info(
                "Data browser refresh complete for '%s': %s",
                project_id, result,
            )
        except Exception as exc:
            logger.error(
                "Data browser refresh failed for '%s': %s",
                project_id, exc, exc_info=True,
            )


@router.post("/{project_id}/refresh")
async def refresh_tables(
    project_id: str,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """Trigger a refresh of all data browser tables for a project."""
    # Validate project exists and has tables configured
    svc = DataBrowserService(db)
    config = await svc._get_project_config(project_id)
    if not config:
        raise HTTPException(status_code=404, detail=f"Project '{project_id}' not found.")

    background_tasks.add_task(_run_refresh_background, project_id)
    return {"status": "refresh_started", "project_id": project_id}
