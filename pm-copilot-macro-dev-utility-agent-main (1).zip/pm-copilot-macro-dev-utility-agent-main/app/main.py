from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from contextlib import asynccontextmanager
import logging
import time

from app.config import settings
from app.core.database import AsyncSessionLocal, init_db, close_db
from app.core.logging import setup_logging
from app.core.scheduler import start_scheduler, stop_scheduler
from app.middleware.cors import setup_cors
from app.middleware.rate_limit import rate_limiter
from scalar_fastapi import get_scalar_api_reference
# Import routers
from app.api import calculation_routes, comments_routes, dashboard_routes, data_browser_routes, guide_routes, health_routes, insights_routes, kpi_builder_routes, project_config_routes, sites_routes
from app.services.kpi_calculator import KPICalculator
from app.staging.api import router as staging_router

# Setup logging
setup_logging()
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan events for startup and shutdown"""

    # Startup
    logger.info(f"Starting {settings.APP_NAME} v{settings.APP_VERSION}")
    await init_db()
    logger.info("Database initialized")

    # Mark any jobs left in RUNNING state from a previous crash as FAILED
    async with AsyncSessionLocal() as db:
        stale = await KPICalculator.mark_stale_jobs_failed(db)
        if stale:
            logger.warning(f"Marked {stale} stale RUNNING job(s) as FAILED on startup")

    start_scheduler()

    yield

    # Shutdown
    logger.info("Shutting down application")
    stop_scheduler()
    await close_db()
    logger.info("Database connections closed")


# Create FastAPI application
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="""
    **Production-Grade KPI Dashboard API**

    This API provides endpoints for:
    - Triggering KPI calculations across geography hierarchy
    - Querying pre-calculated KPI data for dashboards
    - Managing data archival and job monitoring

    ## Authentication
    All endpoints require an API key in the `X-API-Key` header.

    ## Rate Limiting
    Requests are limited to 100 per minute per API key.

    ## Geography Hierarchy
    - **OVERALL**: Global level
    - **REGION**: 3 regions (South, Central, etc.)
    - **AREA**: ~20 areas under regions
    - **MARKET**: ~40 markets under areas
    """,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan
)

# Setup CORS
setup_cors(app)


# Global middleware
@app.middleware("http")
async def add_process_time_header(request: Request, call_next):
    """Add request processing time to response headers"""
    start_time = time.time()
    response = await call_next(request)
    process_time = time.time() - start_time
    response.headers["X-Process-Time"] = str(process_time)
    return response


@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    """Apply rate limiting to all requests"""

    # Skip rate limiting for health check endpoint
    if request.url.path == "/health":
        return await call_next(request)

    await rate_limiter.check_rate_limit(request)
    return await call_next(request)


# Exception handlers
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """Handle validation errors"""
    return JSONResponse(
        status_code=422,
        content={
            "detail": exc.errors(),
            "message": "Request validation failed"
        }
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle uncaught exceptions"""
    logger.error(f"Unhandled exception: {str(exc)}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Internal server error",
            "message": str(exc) if settings.DEBUG else "An error occurred"
        }
    )


# Include routers
app.include_router(calculation_routes.router)
app.include_router(dashboard_routes.router)
app.include_router(guide_routes.router)
app.include_router(health_routes.router)
app.include_router(kpi_builder_routes.router)
app.include_router(project_config_routes.router)
app.include_router(sites_routes.router)
app.include_router(comments_routes.router)
app.include_router(insights_routes.router)
app.include_router(data_browser_routes.router)
app.include_router(staging_router)


# Root endpoint
@app.get("/")
async def root():
    """API root endpoint"""
    return {
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "running",
        "docs": "/docs",
        "redoc": "/redoc"
    }

@app.get("/scalar", include_in_schema=False)
async def scalar_html():
    return get_scalar_api_reference(
        # Your OpenAPI document
        openapi_url=app.openapi_url,
        # Avoid CORS issues (optional)
        scalar_proxy_url="https://proxy.scalar.com",
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8010,
        reload=settings.DEBUG,
        log_level=settings.LOG_LEVEL.lower()
    )
