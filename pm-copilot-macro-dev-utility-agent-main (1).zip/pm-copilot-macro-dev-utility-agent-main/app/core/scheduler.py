import logging
import uuid
from datetime import date
from typing import List

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from app.config import settings
from app.core.database import AsyncSessionLocal
from app.models.kpi_models import JobType
from app.services.sites_service import SitesService

logger = logging.getLogger(__name__)

scheduler = AsyncIOScheduler(timezone="UTC")


# ------------------------------------------------------------------ #
# Job functions                                                        #
# ------------------------------------------------------------------ #

async def _refresh_all_kpis() -> None:
    """Full KPI refresh — all KPIs across all geographies."""
    from app.api.calculation_routes import _run_generic_job_background
    job_id = f"SCHED_FULL_{uuid.uuid4().hex[:10].upper()}"
    logger.info("Scheduler: starting full KPI refresh — job %s", job_id)
    try:
        await _run_generic_job_background(
            job_id=job_id,
            job_type=JobType.FULL_REFRESH,
            kpi_ids=None,
            geo_ids=None,
            calculation_date=date.today(),
        )
        logger.info("Scheduler: full KPI refresh complete — job %s", job_id)
    except Exception as exc:
        logger.error("Scheduler: full KPI refresh failed — job %s: %s", job_id, exc, exc_info=True)


async def _refresh_all_sites() -> None:
    """Daily site data refresh for all active projects that have a source query configured.

    Uses the same smart dispatch as the API:
    - Projects with workflow_pipeline_name → WorkflowSitesService
    - All others → SitesService
    """
    from sqlalchemy import text
    from app.services.workflow_sites_service import WorkflowSitesService

    logger.info("Scheduler: starting site refresh for all active projects")
    async with AsyncSessionLocal() as db:
        try:
            rows = (await db.execute(text(f"""
                SELECT project_id FROM {settings.TABLES['project_config']}
                WHERE is_active = true
                  AND site_source_query IS NOT NULL
                  AND TRIM(site_source_query) != ''
            """))).fetchall()
            project_ids: List[str] = [r[0] for r in rows]
        except Exception as exc:
            logger.error("Scheduler: failed to fetch active projects: %s", exc, exc_info=True)
            return

    logger.info("Scheduler: refreshing sites for %d project(s): %s", len(project_ids), project_ids)

    for pid in project_ids:
        job_id = f"SCHED_SITES_{uuid.uuid4().hex[:10].upper()}"
        async with AsyncSessionLocal() as db:
            try:
                config = await SitesService(db)._get_project_config(pid)
                if config and config.get("workflow_pipeline_name"):
                    svc = WorkflowSitesService(db)
                    result = await svc.refresh_project_sites_from_workflow(pid)
                    logger.info(
                        "Scheduler: workflow site refresh complete for '%s' — %d rows "
                        "(pipeline=%s, steps=%d/%d)",
                        pid, result["rows_inserted"],
                        result["pipeline_name"],
                        result["steps_verified"], result["steps_total"],
                    )
                else:
                    result = await SitesService(db).refresh_project_sites(pid)
                    logger.info(
                        "Scheduler: site refresh complete for '%s' — %d rows",
                        pid, result["rows_inserted"],
                    )
            except Exception as exc:
                logger.error(
                    "Scheduler: site refresh failed for '%s' (job %s): %s",
                    pid, job_id, exc, exc_info=True,
                )


async def _refresh_all_data_browser() -> None:
    """Daily data browser refresh for all projects with data_browser_tables configured."""
    import json
    from app.services.data_browser_service import DataBrowserService

    logger.info("Scheduler: starting data browser refresh for all projects")
    async with AsyncSessionLocal() as db:
        try:
            from sqlalchemy import text as sa_text
            rows = (await db.execute(sa_text(f"""
                SELECT project_id FROM {settings.TABLES['project_config']}
                WHERE is_active = true
                  AND data_browser_tables IS NOT NULL
            """))).fetchall()
            project_ids: List[str] = [r[0] for r in rows]
        except Exception as exc:
            logger.error("Scheduler: failed to fetch projects for data browser: %s", exc, exc_info=True)
            return

    logger.info("Scheduler: data browser refresh for %d project(s)", len(project_ids))

    for pid in project_ids:
        async with AsyncSessionLocal() as db:
            try:
                svc = DataBrowserService(db)
                result = await svc.refresh_project_tables(pid)
                logger.info(
                    "Scheduler: data browser refresh complete for '%s': %s",
                    pid, {k: v.get("rows_inserted", v) for k, v in result.get("tables", {}).items()},
                )
            except Exception as exc:
                logger.error(
                    "Scheduler: data browser refresh failed for '%s': %s",
                    pid, exc, exc_info=True,
                )


# ------------------------------------------------------------------ #
# Setup / teardown                                                     #
# ------------------------------------------------------------------ #

def _parse_cron(expr: str) -> CronTrigger:
    parts = expr.strip().split()
    if len(parts) != 5:
        raise ValueError(f"Invalid cron expression (need 5 fields): {expr!r}")
    minute, hour, day, month, day_of_week = parts
    return CronTrigger(
        minute=minute, hour=hour, day=day,
        month=month, day_of_week=day_of_week,
        timezone="UTC",
    )


def start_scheduler() -> None:
    if not settings.SCHEDULER_ENABLED:
        logger.info("Scheduler disabled (SCHEDULER_ENABLED=false)")
        return

    scheduler.add_job(
        _refresh_all_kpis,
        trigger=_parse_cron(settings.SCHEDULER_KPI_CRON),
        id="kpi_full_refresh",
        name="Daily full KPI refresh",
        replace_existing=True,
        misfire_grace_time=3600,
    )
    scheduler.add_job(
        _refresh_all_sites,
        trigger=_parse_cron(settings.SCHEDULER_SITES_CRON),
        id="sites_refresh",
        name="Daily site data refresh — all projects",
        replace_existing=True,
        misfire_grace_time=3600,
    )

    scheduler.add_job(
        _refresh_all_data_browser,
        trigger=_parse_cron(settings.SCHEDULER_DATA_BROWSER_CRON),
        id="data_browser_refresh",
        name="Daily data browser refresh — all projects",
        replace_existing=True,
        misfire_grace_time=3600,
    )

    scheduler.start()
    logger.info(
        "Scheduler started — Sites: %s | KPI: %s | Data Browser: %s",
        settings.SCHEDULER_SITES_CRON,
        settings.SCHEDULER_KPI_CRON,
        settings.SCHEDULER_DATA_BROWSER_CRON,
    )


def stop_scheduler() -> None:
    if scheduler.running:
        scheduler.shutdown(wait=False)
        logger.info("Scheduler stopped")
