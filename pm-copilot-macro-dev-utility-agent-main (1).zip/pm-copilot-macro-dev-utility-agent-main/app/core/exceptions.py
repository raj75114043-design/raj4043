class KPIDashboardException(Exception):
    """Base exception for KPI Dashboard"""
    pass

class CalculationError(KPIDashboardException):
    """Raised when KPI calculation fails"""
    pass

class QueryExecutionError(KPIDashboardException):
    """Raised when SQL query execution fails"""
    pass

class DataValidationError(KPIDashboardException):
    """Raised when data validation fails"""
    pass

class GeographyNotFoundError(KPIDashboardException):
    """Raised when geography is not found"""
    pass

class KPINotFoundError(KPIDashboardException):
    """Raised when KPI is not found"""
    pass

class WorkflowAPIError(KPIDashboardException):
    """Raised when the external workflow API call fails"""
    pass

class WorkflowConfigError(KPIDashboardException):
    """Raised when workflow configuration is missing or invalid"""
    pass

class SiteInsightsError(KPIDashboardException):
    """Raised when site insights generation fails"""
    pass

class KGAPIError(KPIDashboardException):
    """Raised when the external Knowledge Graph status API call fails.

    `status_code` carries the upstream HTTP status when applicable (None for
    network errors / non-HTTP failures).
    """
    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code