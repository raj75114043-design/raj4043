import json
import logging
import uuid
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings

logger = logging.getLogger(__name__)


# Stage ordering and the progress_pct each stage represents on entry.
# The UI uses these for the progress bar; labels are shown verbatim.
STAGE_PROGRESS: List[tuple[str, int, str]] = [
    ("queued",                 0,  "Queued"),
    ("loading_project_config", 5,  "Loading project configuration"),
    ("fetching_kg",            15, "Querying Knowledge Graph"),
    ("fetching_workflow",      15, "Querying workflow pipeline"),
    ("reading_pm_comments",    35, "Reading PM comments"),
    ("preparing_context",      55, "Preparing context for analysis"),
    ("generating_insight",     70, "Generating proactive insight"),
    ("finalizing",             95, "Finalizing"),
    ("done",                  100, "Complete"),
]
_STAGE_INDEX = {name: (pct, label) for name, pct, label in STAGE_PROGRESS}

# How long a 'pending' or 'running' job is considered reusable for dedupe.
_REUSE_WINDOW = timedelta(minutes=2)


class InsightsJobService:
    """CRUD + stage transitions for the site_insights_jobs table.

    The service is intentionally narrow: it owns the row lifecycle. The actual
    work (KG fetch, LLM call, etc.) lives in SiteInsightsService, which calls
    `update_stage` / `set_partial` / `complete` / `fail` as it progresses.
    """

    def __init__(self, db: AsyncSession):
        self.db = db

    @property
    def _table(self) -> str:
        return settings.TABLES["site_insights_jobs"]

    # ------------------------------------------------------------------ #
    # Dedupe + create                                                     #
    # ------------------------------------------------------------------ #

    async def create_or_reuse(
        self,
        project_id: str,
        smp_id: str,
        source: str,
        refresh: bool,
    ) -> Dict[str, Any]:
        """Return an existing pending/running job for this (project, site, source),
        or create a new one. `refresh=True` always creates a new job."""
        if not refresh:
            existing = await self._find_active_job(project_id, smp_id, source)
            if existing is not None:
                return existing

        job_id = str(uuid.uuid4())
        now = datetime.utcnow()
        first_pct, first_label = _STAGE_INDEX["queued"]
        await self.db.execute(
            text(f"""
                INSERT INTO {self._table} (
                    job_id, project_id, smp_id, source, status,
                    stage, progress_pct, stages_completed,
                    refresh_requested, created_at, updated_at
                ) VALUES (
                    :job_id, :project_id, :smp_id, :source, 'pending',
                    :stage, :pct, CAST(:stages AS jsonb),
                    :refresh, :created_at, :updated_at
                )
            """),
            {
                "job_id": job_id,
                "project_id": project_id,
                "smp_id": smp_id,
                "source": source,
                "stage": "queued",
                "pct": first_pct,
                "stages": json.dumps([
                    {"stage": "queued", "label": first_label,
                     "progress_pct": first_pct, "at": now.isoformat()}
                ]),
                "refresh": refresh,
                "created_at": now,
                "updated_at": now,
            },
        )
        await self.db.commit()
        return await self.get(job_id)

    async def _find_active_job(
        self, project_id: str, smp_id: str, source: str
    ) -> Optional[Dict[str, Any]]:
        cutoff = datetime.utcnow() - _REUSE_WINDOW
        row = (await self.db.execute(
            text(f"""
                SELECT * FROM {self._table}
                WHERE project_id = :project_id
                  AND smp_id = :smp_id
                  AND source = :source
                  AND status IN ('pending', 'running')
                  AND created_at >= :cutoff
                ORDER BY created_at DESC
                LIMIT 1
            """),
            {
                "project_id": project_id,
                "smp_id": smp_id,
                "source": source,
                "cutoff": cutoff,
            },
        )).fetchone()
        return self._row_to_dict(row) if row else None

    # ------------------------------------------------------------------ #
    # Read                                                                #
    # ------------------------------------------------------------------ #

    async def get(self, job_id: str) -> Optional[Dict[str, Any]]:
        row = (await self.db.execute(
            text(f"SELECT * FROM {self._table} WHERE job_id = :job_id"),
            {"job_id": job_id},
        )).fetchone()
        return self._row_to_dict(row) if row else None

    # ------------------------------------------------------------------ #
    # Stage transitions                                                    #
    # ------------------------------------------------------------------ #

    async def update_stage(self, job_id: str, stage: str) -> None:
        """Move a job to a new stage. Sets status='running' on the first move."""
        if stage not in _STAGE_INDEX:
            logger.warning("Unknown stage '%s' for job %s — ignoring.", stage, job_id)
            return

        pct, label = _STAGE_INDEX[stage]
        now = datetime.utcnow()
        entry = {
            "stage": stage,
            "label": label,
            "progress_pct": pct,
            "at": now.isoformat(),
        }
        try:
            await self.db.execute(
                text(f"""
                    UPDATE {self._table}
                    SET status = CASE WHEN status = 'pending' THEN 'running' ELSE status END,
                        stage = :stage,
                        progress_pct = :pct,
                        stages_completed = stages_completed || CAST(:entry AS jsonb),
                        updated_at = :now
                    WHERE job_id = :job_id
                """),
                {
                    "stage": stage,
                    "pct": pct,
                    "entry": json.dumps([entry]),
                    "now": now,
                    "job_id": job_id,
                },
            )
            await self.db.commit()
        except Exception as exc:
            logger.warning("Failed to update job %s to stage '%s': %s", job_id, stage, exc)
            await self.db.rollback()

    async def set_partial(self, job_id: str, partial: Dict[str, Any]) -> None:
        """Persist early data (kg_snapshot, pm_comments) so the UI can render
        skeleton cards before the LLM finishes."""
        try:
            await self.db.execute(
                text(f"""
                    UPDATE {self._table}
                    SET partial = CAST(:partial AS jsonb),
                        updated_at = :now
                    WHERE job_id = :job_id
                """),
                {
                    "partial": json.dumps(partial, default=str),
                    "now": datetime.utcnow(),
                    "job_id": job_id,
                },
            )
            await self.db.commit()
        except Exception as exc:
            logger.warning("Failed to set partial for job %s: %s", job_id, exc)
            await self.db.rollback()

    async def complete(self, job_id: str, result: Dict[str, Any]) -> None:
        now = datetime.utcnow()
        done_pct, done_label = _STAGE_INDEX["done"]
        entry = {
            "stage": "done",
            "label": done_label,
            "progress_pct": done_pct,
            "at": now.isoformat(),
        }
        try:
            await self.db.execute(
                text(f"""
                    UPDATE {self._table}
                    SET status = 'done',
                        stage = 'done',
                        progress_pct = :pct,
                        stages_completed = stages_completed || CAST(:entry AS jsonb),
                        result = CAST(:result AS jsonb),
                        updated_at = :now
                    WHERE job_id = :job_id
                """),
                {
                    "pct": done_pct,
                    "entry": json.dumps([entry]),
                    "result": json.dumps(result, default=str),
                    "now": now,
                    "job_id": job_id,
                },
            )
            await self.db.commit()
        except Exception as exc:
            logger.error("Failed to mark job %s done: %s", job_id, exc)
            await self.db.rollback()

    async def fail(self, job_id: str, error_message: str) -> None:
        try:
            await self.db.execute(
                text(f"""
                    UPDATE {self._table}
                    SET status = 'failed',
                        error = :err,
                        updated_at = :now
                    WHERE job_id = :job_id
                """),
                {
                    "err": error_message[:2000],
                    "now": datetime.utcnow(),
                    "job_id": job_id,
                },
            )
            await self.db.commit()
        except Exception as exc:
            logger.error("Failed to mark job %s failed: %s", job_id, exc)
            await self.db.rollback()

    # ------------------------------------------------------------------ #
    # Helpers                                                              #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _row_to_dict(row) -> Dict[str, Any]:
        d = dict(row._mapping)
        # Normalize JSONB columns that may come back as strings depending on the driver
        for key in ("stages_completed", "partial", "result"):
            val = d.get(key)
            if isinstance(val, str):
                try:
                    d[key] = json.loads(val)
                except (json.JSONDecodeError, TypeError):
                    pass
        d["job_id"] = str(d["job_id"])
        return d
