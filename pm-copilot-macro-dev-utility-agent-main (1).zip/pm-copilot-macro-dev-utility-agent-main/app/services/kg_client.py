import logging
from typing import Any, Dict
from urllib.parse import quote, urlparse

import httpx

from app.config import settings
from app.core.exceptions import KGAPIError

logger = logging.getLogger(__name__)

_PLACEHOLDER = "{site_id}"


class KGClient:
    """Async HTTP client for the per-project Knowledge Graph status API.

    Each project supplies its own full URL template (kg_url_template) containing
    a `{site_id}` placeholder. The client validates the template against an
    allowlist of host suffixes, substitutes the URL-encoded site id, and GETs
    the resulting URL, returning the parsed JSON.
    """

    def __init__(self, timeout: int | None = None):
        self.timeout = timeout or settings.KG_API_TIMEOUT

    async def get_site_status(self, url_template: str, site_id: str) -> Dict[str, Any]:
        url = self._build_url(url_template, site_id)
        try:
            async with httpx.AsyncClient(timeout=self.timeout, verify=False) as client:
                resp = await client.get(url, headers={"accept": "application/json"})
                resp.raise_for_status()
                return resp.json()
        except httpx.HTTPStatusError as exc:
            raise KGAPIError(
                f"KG API returned {exc.response.status_code} for site '{site_id}' "
                f"(url={url})",
                status_code=exc.response.status_code,
            ) from exc
        except httpx.RequestError as exc:
            raise KGAPIError(
                f"Failed to reach KG API for site '{site_id}': {exc}"
            ) from exc
        except ValueError as exc:
            raise KGAPIError(
                f"KG API returned non-JSON response for site '{site_id}': {exc}"
            ) from exc

    @staticmethod
    def _build_url(url_template: str, site_id: str) -> str:
        if not url_template or _PLACEHOLDER not in url_template:
            raise KGAPIError(
                f"kg_url_template missing required '{_PLACEHOLDER}' placeholder."
            )

        # Substitute before parsing so the placeholder doesn't confuse urlparse.
        candidate = url_template.replace(_PLACEHOLDER, quote(str(site_id), safe=""))

        parsed = urlparse(candidate)
        if parsed.scheme != "https":
            raise KGAPIError(
                f"kg_url_template must use https (got scheme '{parsed.scheme}')."
            )
        if not parsed.hostname:
            raise KGAPIError("kg_url_template has no host.")

        host = parsed.hostname.lower()
        allowed = settings.KG_ALLOWED_HOST_SUFFIXES or []
        if allowed and not any(host.endswith(suffix.lower()) for suffix in allowed):
            raise KGAPIError(
                f"KG host '{host}' is not in KG_ALLOWED_HOST_SUFFIXES."
            )

        return candidate
