import asyncio
import json
import logging
import re
import uuid
from datetime import datetime, timedelta
from typing import Any, Awaitable, Callable, Dict, List, Optional, Tuple

StageReporter = Optional[Callable[[str], Awaitable[None]]]
PartialReporter = Optional[Callable[[Dict[str, Any]], Awaitable[None]]]


async def _noop_stage(_: str) -> None:
    pass


async def _noop_partial(_: Dict[str, Any]) -> None:
    pass

from langchain_core.messages import HumanMessage, SystemMessage
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.core.exceptions import SiteInsightsError
from app.core.llm import get_llm
from app.models.insights_models import (
    LLMInsight,
    PMCommentEntry,
    SiteInsightsResponse,
    WorkflowInsight,
    WorkflowStepInsight,
)
from app.services.kg_client import KGClient
from app.services.workflow_client import WorkflowClient
from app.services.workflow_dag import get_main_path_step_ids

logger = logging.getLogger(__name__)

_SAFE_IDENTIFIER_RE = re.compile(r"^[a-zA-Z0-9_]+$")

# Matches an ISO-ish datetime string and captures the date portion.
# Accepts "2025-09-13T00:00:00", "2025-09-13 00:00:00.000", "2025-09-13T14:22:01Z", etc.
_DATETIME_DATE_RE = re.compile(
    r"^(\d{4}-\d{2}-\d{2})[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?$"
)

# ------------------------------------------------------------------ #
# LLM System Prompt                                                    #
# ------------------------------------------------------------------ #

_INSIGHTS_SYSTEM_PROMPT = """\
You are a telecom deployment project assistant writing a site status update for a Project Manager.

You will receive workflow step data and PM comments for a single site.
- "completed" steps = the site has already passed through these steps successfully.
- "held" steps = the site is currently held at these steps and needs attention.
- PM comments are running commentary added by PMs over time. Timestamps like "9/13" mean September 13. Focus on the most recent entries only.

PM COMMENTS ARE THE PRIMARY SIGNAL.
Workflow step data tells you WHERE the site is. PM comments tell you WHY it's there and what's actually happening on the ground — they are the source of truth for context, blockers, and next steps. Whenever a PM comment exists that explains the current state, lead with it and quote the relevant phrase. Treat workflow-step data as the skeleton and PM commentary as the meat. Only fall back to step data alone when PM comments are absent or empty.

Respond in valid JSON with exactly this structure:
{
  "title": "<short status headline, max 10 words, e.g. 'Integration phase - pending vendor approval'>",
  "summary": "<1 sentence — current position + the one thing that matters most>",
  "details": [
    "<bullet 1>",
    "<bullet 2>",
    "..."
  ]
}

Rules:
- title: Short, factual headline about where the site stands. No dramatic words.
- summary: ONE sentence (two only if absolutely necessary). State where the site is and what — if anything — needs attention. No restating what's already in the title. No filler ("currently", "as of today"). If nothing needs attention, just state the position.
- details: 3-5 bullets, terse. Each bullet must add information not already in summary. Include:
  - Current position with progress %.
  - Held steps and the reason (if error info or matching PM comment exists).
  - PM comments only when they add context (delay reason, upcoming event, blocker). Skip PM comments that just confirm what the workflow data already shows.
  - A recent completed milestone only if it explains current position.
- Reader-friendly names: Do NOT drop raw column or technical step identifiers into prose. Use a human-readable label and put the raw name in parentheses if helpful for traceability, e.g. "Held at RAN Entitlement (wf_step_42)" or "PM noted in vendor update (pj_vendor_notes) that approval is delayed". Never write a bullet that reads like a field dump.
- Tone: Calm status email between colleagues. No urgency language, no exclamation marks, no words like "critical", "alarming", "urgent", "stuck".
- Do not mention steps the site has not reached yet.
- Do not invent information not present in the data.
- Return ONLY the JSON object, no other text."""


_KG_INSIGHTS_SYSTEM_PROMPT = """\
You are a senior telecom deployment program advisor analyzing a single site for a Project Manager.

INPUT
You will receive:
1. `now_utc` — the current UTC timestamp. Treat this as "today" for all slippage and date math.
   A planned date is overdue ONLY if it is strictly before `now_utc`.
2. `kg_site_record` — phase-prefixed fields (p1_*, p2_*, ..., p11_*). Each phase tracks
   vendor assignments, planned dates ("*_planned"), and actual completion dates ("*_actual").
   Status fields (p2_precon_status, p3_scoping_status, p6_material_status, …) show current state.
3. `pm_comments` — running commentary added by Project Managers over time. These often
   explain WHY something looks stuck and are the most reliable signal for context.

PM COMMENTS ARE THE PRIMARY SIGNAL.
The KG record tells you WHAT the dates and statuses are. PM comments tell you WHY — the
real-world reason behind a slip, a stall, or an unassigned vendor. Whenever a PM comment
addresses a situation, it OVERRIDES the naive read of the KG fields:
  - If a milestone looks late but a PM comment explains it's waiting on a known approval,
    lead with the PM's explanation, not the date slip.
  - If a PM comment says something is resolved or in progress, do NOT raise it as a risk
    or recommend an action — even if the KG field still looks open.
  - Quote the relevant phrase from the PM comment so the PM recognizes their own words.
Only fall back to KG-field-only analysis when PM comments are absent, empty, or silent on
the issue at hand.

YOUR JOB
Be PROACTIVE and INTELLIGENT, not a reporter. Specifically:

- Compare planned vs actual dates against `now_utc` to identify SLIPPAGE and DOWNSTREAM RISK.
- Identify UNASSIGNED VENDORS or PARTIES (e.g. p1_gc is null, p1_sc_assigned_status = "Not Assigned")
  that gate later phases.
- Cross-reference every apparent issue with `pm_comments` before flagging it. PM commentary
  often explains a gap that would otherwise look like a problem.
- Predict the next likely blocker, given current state, planned-date sequence, and `now_utc`.

CRITICAL — HANDLING DATA GAPS (READ CAREFULLY)
A null "*_actual" does NOT automatically mean the milestone is incomplete. The KG often has
data-entry gaps where an early milestone is null but multiple LATER milestones in the same
phase or in downstream phases have populated actuals. In that case the early milestone is
almost certainly complete in reality and the null is a data-quality issue, NOT a blocker.

Decision rule:
  - If a milestone's actual is null AND one or more strictly later milestones (by planned date
    or by phase number) have populated actuals → treat the null as a likely data gap.
    Mention it briefly under details as a data-quality note, NOT as a risk or recommendation.
  - Only flag a null actual as a real concern when it has NO downstream completions AND
    its planned date is past `now_utc`, or no PM comment explains it.
  - When PM comments explicitly address a stalled milestone, lead with that explanation
    rather than reporting the stall in isolation.

OUTPUT
Respond in valid JSON with exactly this structure:
{
  "title": "<short headline naming the dominant risk or current phase, max 12 words>",
  "summary": "<1-2 sentences: where the site stands and the single most consequential risk or next move>",
  "details": [
    "<bullet 1 — specific observation tied to fields/dates, with pm_comment linkage if applicable>",
    "<bullet 2>",
    "..."
  ],
  "recommendations": [
    "<concrete action the PM should take, in priority order>",
    "..."
  ]
}

Rules:
- title: factual, no dramatic words. Name the phase or risk, not the site.
- summary: 1-2 sentences MAX. Lead with the current position relative to `now_utc` and the one risk or next action that matters most. Do not pile on every concern — that belongs in details. No filler phrases ("the site is currently", "as of now"). If the situation is clean, just say so plainly.
- details: 3-6 bullets, terse. Each bullet must add new information beyond the summary and reference a specific field, date, or PM comment. When you tie a gap to a PM comment, quote the relevant phrase. When you note a data gap, say so explicitly.
- Reader-friendly names: Do NOT drop raw field names into prose. Use a human-readable label and put the raw field in parentheses for traceability, e.g. "Pre-construction completion (p2_pre_ntp_actual) is missing, but RAN EC completion (p2_ran_ec_actual) is populated — likely a data gap" or "PM noted in the vendor update column (pj_vendor_notes) that approval is delayed". Never write a bullet that reads like a field dump such as "p3_scoping_status = Not Started".
- recommendations: Include ONLY when a concrete, non-obvious action is genuinely needed. 0-3 bullets. Quality over quantity:
  - SKIP recommendations entirely (return `"recommendations": []`) when the site is on track, all risks are already addressed by PM comments, or the only "actions" would be generic ("monitor progress", "keep stakeholders informed", "follow up regularly"). Generic advice is worse than no advice.
  - Each recommendation must be specific to THIS site's situation — name the field, vendor, phase, or person involved.
  - Do NOT recommend actions that PM comments already indicate are in progress or resolved.
  - Order by urgency.
- Tone: direct, factual, advisory. No exclamation marks. No words like "critical", "urgent", "alarming".
- Do not invent fields or dates. Only reference what is present in the data.
- Return ONLY the JSON object, no other text."""


class SiteInsightsService:
    """Generates deep, actionable insights for a single site."""

    def __init__(self, db: AsyncSession):
        self.db = db

    # ------------------------------------------------------------------ #
    # Public API                                                           #
    # ------------------------------------------------------------------ #

    async def get_insights(
        self,
        project_id: str,
        smp_id: str,
        refresh: bool = False,
        source_override: Optional[str] = None,
        report_stage: StageReporter = None,
        report_partial: PartialReporter = None,
    ) -> SiteInsightsResponse:
        """Orchestrate data gathering, analysis, and LLM narrative generation.

        Branches on project_config.insights_source:
          - 'workflow' (default): existing workflow-step path
          - 'kg':                 new Knowledge Graph status path

        Pass `source_override='workflow'|'kg'` to force one source for this call
        without touching project config (used by ?source= query param).

        `report_stage` and `report_partial` are optional async callbacks invoked
        as the pipeline progresses (used by the background-job/polling endpoint).
        Both default to no-ops, so the synchronous endpoint is unaffected.

        Uses a read-through / write-through cache keyed by (project_id, smp_id).
        Cached payloads carry their source — a source switch auto-invalidates.
        """
        stage = report_stage or _noop_stage
        partial = report_partial or _noop_partial

        await stage("loading_project_config")
        config = await self._get_project_config(project_id)
        if not config:
            raise SiteInsightsError(f"Project '{project_id}' not found.")

        source = (source_override or config.get("insights_source") or "workflow").lower()
        if source not in ("workflow", "kg"):
            raise SiteInsightsError(
                f"Invalid insights_source '{source}'. Must be 'workflow' or 'kg'."
            )

        if settings.INSIGHTS_CACHE_ENABLED and not refresh:
            cached = await self._read_cache(project_id, smp_id, expected_source=source)
            if cached is not None:
                return cached

        if source == "kg":
            response = await self._build_kg_response(
                project_id, smp_id, config, stage, partial
            )
        else:
            response = await self._build_workflow_response(
                project_id, smp_id, config, stage, partial
            )

        await stage("finalizing")
        if settings.INSIGHTS_CACHE_ENABLED:
            await self._write_cache(project_id, smp_id, response)

        return response

    # ------------------------------------------------------------------ #
    # Workflow-source response (existing path)                            #
    # ------------------------------------------------------------------ #

    async def _build_workflow_response(
        self,
        project_id: str,
        smp_id: str,
        config: Dict[str, Any],
        stage: Callable[[str], Awaitable[None]],
        partial: Callable[[Dict[str, Any]], Awaitable[None]],
    ) -> SiteInsightsResponse:
        pipeline_names = self._resolve_pipeline_names(config)

        await stage("fetching_workflow")
        workflow_coro = self._get_all_workflow_insights(
            smp_id, pipeline_names, config
        )
        await stage("reading_pm_comments")
        comments_coro = self._get_pm_comments(smp_id)
        workflows, pm_comments = await asyncio.gather(
            workflow_coro, comments_coro
        )

        await partial({
            "workflows": [w.model_dump() for w in workflows],
            "pm_comments": [c.model_dump() for c in pm_comments],
        })

        await stage("preparing_context")
        await stage("generating_insight")
        insight = await self._generate_insight(
            smp_id, project_id, workflows, pm_comments
        )

        structured_summary = self._build_structured_summary(workflows)

        return SiteInsightsResponse(
            smp_id=smp_id,
            project_id=project_id,
            source="workflow",
            insight_id=str(uuid.uuid4()),
            workflows=workflows,
            pm_comments=pm_comments,
            insight=insight,
            structured_summary=structured_summary,
            generated_at=datetime.utcnow(),
            cached=False,
            cache_age_seconds=0,
        )

    # ------------------------------------------------------------------ #
    # KG-source response (new path)                                        #
    # ------------------------------------------------------------------ #

    async def _build_kg_response(
        self,
        project_id: str,
        smp_id: str,
        config: Dict[str, Any],
        stage: Callable[[str], Awaitable[None]],
        partial: Callable[[Dict[str, Any]], Awaitable[None]],
    ) -> SiteInsightsResponse:
        url_template = config.get("kg_url_template")
        if not url_template:
            raise SiteInsightsError(
                f"Project '{project_id}' has insights_source='kg' but no kg_url_template configured."
            )

        # The path parameter named `smp_id` is whatever site identifier the caller
        # supplied — we pass it straight to the KG URL with no translation.
        await stage("fetching_kg")
        kg_client = KGClient()
        kg_coro = kg_client.get_site_status(url_template, smp_id)
        await stage("reading_pm_comments")
        comments_coro = self._get_pm_comments(smp_id)
        kg_payload, pm_comments = await asyncio.gather(kg_coro, comments_coro)
        kg_payload = self._normalize_kg_dates(kg_payload)
        # Keep raw keys on kg_payload — the LLM, structured_summary, and
        # fallback path all read p<N>_* keys directly. Only the externally
        # shipped snapshot gets refined key names.
        snapshot_for_response = self._humanize_kg_keys(kg_payload)

        # Surface early data so the UI can render skeleton cards while the LLM works.
        await partial({
            "kg_snapshot": snapshot_for_response,
            "pm_comments": [c.model_dump() for c in pm_comments],
            "structured_summary": self._build_kg_structured_summary(kg_payload),
        })

        await stage("preparing_context")
        await stage("generating_insight")
        insight = await self._generate_kg_insight(
            smp_id, project_id, kg_payload, pm_comments
        )

        structured_summary = self._build_kg_structured_summary(kg_payload)

        return SiteInsightsResponse(
            smp_id=smp_id,
            project_id=project_id,
            source="kg",
            insight_id=str(uuid.uuid4()),
            workflows=[],  # KG mode does not produce per-step workflow analysis
            pm_comments=pm_comments,
            insight=insight,
            structured_summary=structured_summary,
            kg_snapshot=snapshot_for_response,
            generated_at=datetime.utcnow(),
            cached=False,
            cache_age_seconds=0,
        )

    # ------------------------------------------------------------------ #
    # Cache                                                                #
    # ------------------------------------------------------------------ #

    async def _read_cache(
        self,
        project_id: str,
        smp_id: str,
        expected_source: Optional[str] = None,
    ) -> Optional[SiteInsightsResponse]:
        """Return the cached response if present, within TTL, and matching source."""
        table = settings.TABLES["site_insights_cache"]
        try:
            row = (await self.db.execute(
                text(f"""
                    SELECT payload, generated_at
                    FROM {table}
                    WHERE project_id = :project_id AND smp_id = :smp_id
                """),
                {"project_id": project_id, "smp_id": smp_id},
            )).fetchone()
        except Exception as exc:
            logger.warning("Insights cache read failed for %s/%s: %s", project_id, smp_id, exc)
            return None

        if not row:
            return None

        generated_at: datetime = row._mapping["generated_at"]
        age = datetime.utcnow() - generated_at
        ttl = timedelta(hours=settings.INSIGHTS_CACHE_TTL_HOURS)
        if age > ttl:
            return None

        payload = row._mapping["payload"]
        if isinstance(payload, str):
            payload = json.loads(payload)

        # Treat source mismatch as a cache miss so flipping insights_source
        # auto-refreshes on the next call.
        cached_source = (payload.get("source") or "workflow").lower()
        if expected_source and cached_source != expected_source.lower():
            return None

        # Overlay cache metadata on top of stored payload
        payload["cached"] = True
        payload["cache_age_seconds"] = int(age.total_seconds())
        payload["generated_at"] = generated_at.isoformat()

        # Lazy-mint insight_id for legacy cache rows that pre-date migration 020.
        # Once written back, subsequent reads return the stable id and feedback
        # snapshots can find the payload.
        if not payload.get("insight_id"):
            new_id = str(uuid.uuid4())
            payload["insight_id"] = new_id
            try:
                await self.db.execute(
                    text(f"""
                        UPDATE {table}
                        SET insight_id = CAST(:insight_id AS uuid),
                            payload    = CAST(:payload AS jsonb)
                        WHERE project_id = :project_id AND smp_id = :smp_id
                          AND insight_id IS NULL
                    """),
                    {
                        "insight_id": new_id,
                        "payload": json.dumps(
                            {k: v for k, v in payload.items() if k not in ("cached", "cache_age_seconds")},
                            default=str,
                        ),
                        "project_id": project_id,
                        "smp_id": smp_id,
                    },
                )
                await self.db.commit()
            except Exception as exc:
                logger.warning(
                    "Insights cache lazy-mint failed for %s/%s: %s",
                    project_id, smp_id, exc,
                )
                await self.db.rollback()

        try:
            return SiteInsightsResponse.model_validate(payload)
        except Exception as exc:
            logger.warning(
                "Insights cache payload invalid for %s/%s — ignoring: %s",
                project_id, smp_id, exc,
            )
            return None

    async def _write_cache(
        self, project_id: str, smp_id: str, response: SiteInsightsResponse
    ) -> None:
        """Upsert the freshly-generated response into the cache.

        insight_id is persisted in its own column so the feedback service can
        look up the cached payload by id at submit time (and snapshot it onto
        the feedback row).
        """
        table = settings.TABLES["site_insights_cache"]
        # Strip cache-only fields before persisting so they don't double-up on read
        payload = response.model_dump(exclude={"cached", "cache_age_seconds"}, mode="json")
        try:
            await self.db.execute(
                text(f"""
                    INSERT INTO {table} (project_id, smp_id, payload, generated_at, insight_id)
                    VALUES (:project_id, :smp_id, CAST(:payload AS jsonb), :generated_at, CAST(:insight_id AS uuid))
                    ON CONFLICT (project_id, smp_id) DO UPDATE SET
                        payload      = EXCLUDED.payload,
                        generated_at = EXCLUDED.generated_at,
                        insight_id   = EXCLUDED.insight_id
                """),
                {
                    "project_id": project_id,
                    "smp_id": smp_id,
                    "payload": json.dumps(payload, default=str),
                    "generated_at": response.generated_at,
                    "insight_id": response.insight_id,
                },
            )
            await self.db.commit()
        except Exception as exc:
            logger.warning(
                "Insights cache write failed for %s/%s: %s",
                project_id, smp_id, exc,
            )
            await self.db.rollback()

    # ------------------------------------------------------------------ #
    # Project Config                                                       #
    # ------------------------------------------------------------------ #

    async def _get_project_config(self, project_id: str) -> Optional[Dict[str, Any]]:
        table = settings.TABLES["project_config"]
        row = (
            await self.db.execute(
                text(f"SELECT * FROM {table} WHERE project_id = :pid"),
                {"pid": project_id},
            )
        ).fetchone()
        return dict(row._mapping) if row else None

    @staticmethod
    def _resolve_pipeline_names(config: Dict[str, Any]) -> List[str]:
        """Get pipeline name list from config, supporting both singular and list fields."""
        names_raw = config.get("workflow_pipeline_names")
        if isinstance(names_raw, str):
            try:
                names_raw = json.loads(names_raw)
            except (json.JSONDecodeError, TypeError):
                names_raw = None

        if names_raw and isinstance(names_raw, list):
            return [n for n in names_raw if n]

        singular = config.get("workflow_pipeline_name")
        if singular:
            return [singular]

        return []

    # ------------------------------------------------------------------ #
    # Workflow Insights                                                    #
    # ------------------------------------------------------------------ #

    async def _get_all_workflow_insights(
        self,
        smp_id: str,
        pipeline_names: List[str],
        config: Dict[str, Any],
    ) -> List[WorkflowInsight]:
        """Fetch and analyze workflow data for all pipelines concurrently."""
        if not pipeline_names:
            return []

        tasks = [
            self._get_single_workflow_insight(smp_id, name, config)
            for name in pipeline_names
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        insights = []
        for name, result in zip(pipeline_names, results):
            if isinstance(result, Exception):
                logger.error(
                    "Failed to get workflow insight for pipeline '%s': %s",
                    name, result,
                )
                continue
            insights.append(result)
        return insights

    async def _get_single_workflow_insight(
        self,
        smp_id: str,
        pipeline_name: str,
        config: Dict[str, Any],
    ) -> WorkflowInsight:
        """Analyze a single pipeline for a specific site.

        Only returns steps where the site was actually processed (completed
        or failed). Future/pending steps are excluded.
        Steps are classified as main-path or branch using DAG analysis.
        Current position is derived from the last main-path step.

        Uses selected steps from project config as the source of truth
        for total step count (same denominator as the site list).
        Falls back to all enabled steps from the API if no selection is configured.
        """
        client = WorkflowClient()
        pipeline_data = await client.get_pipeline_steps(pipeline_name)

        step_results = pipeline_data.get("step_results", [])
        enabled_steps = [s for s in step_results if s.get("enabled", False)]

        # Use selected steps from project config as source of truth
        # (aligns with site list denominator in WorkflowSitesService)
        raw_selected = config.get("workflow_selected_steps")
        if isinstance(raw_selected, str):
            raw_selected = json.loads(raw_selected)
        selected_steps: List[Dict[str, Any]] = raw_selected or []

        if selected_steps:
            selected_ids = {int(s["step_id"]) for s in selected_steps}
            # Build a merged list: use API data for step metadata but
            # restrict to only the selected step IDs
            selected_api_steps = [
                s for s in enabled_steps if s["step_id"] in selected_ids
            ]
            # For selected steps missing from API (unlikely), use config data
            api_step_ids = {s["step_id"] for s in selected_api_steps}
            for s in selected_steps:
                if int(s["step_id"]) not in api_step_ids:
                    selected_api_steps.append(s)
            steps_to_analyze = selected_api_steps
        else:
            steps_to_analyze = enabled_steps

        steps_to_analyze.sort(key=lambda s: int(s["step_id"]))

        join_key = config.get("workflow_join_key") or "smp_id"

        # DAG classification: main-path vs branch
        # Enrich with depends_on from API if not already present
        api_steps_map = {
            s["step_id"]: s.get("depends_on", []) for s in enabled_steps
        }
        for step in steps_to_analyze:
            if "depends_on" not in step or not step["depends_on"]:
                step["depends_on"] = api_steps_map.get(step["step_id"], [])

        main_path_ids = get_main_path_step_ids(steps_to_analyze)

        # Check table existence + site presence in one pass
        wf_schema = settings.WORKFLOW_SCHEMA
        step_table_map = self._build_step_table_map(pipeline_name, steps_to_analyze)
        existing_tables = await self._check_tables_exist(
            wf_schema, list(step_table_map.values())
        )

        site_statuses = await self._check_site_in_steps_bulk(
            smp_id, join_key, wf_schema, step_table_map, existing_tables
        )

        # Build insights only for steps where the site is present
        completed_steps: List[WorkflowStepInsight] = []
        held_steps: List[WorkflowStepInsight] = []

        for step in steps_to_analyze:
            sid = int(step["step_id"])
            final_status = site_statuses.get(sid)
            if final_status is None:
                continue  # site not in this step — skip entirely

            is_held = final_status == "fail"
            is_main = sid in main_path_ids
            insight = WorkflowStepInsight(
                step_id=sid,
                step_name=step.get("step_name", f"Step {sid}"),
                step_description=step.get("step_description"),
                phase_name=step.get("phase_name"),
                status="held" if is_held else "completed",
                is_main_path=is_main,
                error_message=step.get("error_message") if is_held else None,
            )

            if is_held:
                held_steps.append(insight)
            else:
                completed_steps.append(insight)

        # Current position: last MAIN-PATH step the site reached
        all_site_steps = completed_steps + held_steps
        all_site_steps.sort(key=lambda s: s.step_id)
        main_site_steps = [s for s in all_site_steps if s.is_main_path]
        current_position = (
            main_site_steps[-1] if main_site_steps
            else (all_site_steps[-1] if all_site_steps else None)
        )

        # Recent completed: last N passed main-path steps
        max_recent = settings.INSIGHTS_MAX_RECENT_STEPS
        main_completed = [s for s in completed_steps if s.is_main_path]
        recent_completed = main_completed[-max_recent:] if main_completed else []

        # Progress: passed steps / total selected steps
        # (same denominator as site list in WorkflowSitesService)
        total = len(steps_to_analyze)
        completed_count = len(completed_steps)
        completion_pct = round(completed_count / total * 100, 2) if total else 0.0

        return WorkflowInsight(
            workflow_name=pipeline_data.get("workflow_name", pipeline_name),
            total_steps=total,
            completed_steps=len(completed_steps),
            held_steps=len(held_steps),
            completion_pct=completion_pct,
            current_position=current_position,
            recent_completed=recent_completed,
            held_step_details=held_steps,
        )

    @staticmethod
    def _build_step_table_map(
        pipeline_name: str, steps: List[Dict[str, Any]]
    ) -> Dict[int, str]:
        """Map step_id -> expected output table name."""
        prefix = pipeline_name.strip().lower().replace(" ", "_")
        prefix = re.sub(r"[^a-zA-Z0-9_]", "", prefix)
        return {
            int(s["step_id"]): f"{prefix}_wf_step_{s['step_id']}_output"
            for s in steps
        }

    async def _check_tables_exist(
        self, schema: str, table_names: List[str]
    ) -> set:
        """Return the subset of table_names that exist in the given schema."""
        if not table_names:
            return set()
        result = await self.db.execute(
            text("""
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = :schema
                  AND table_name = ANY(:names)
            """),
            {"schema": schema, "names": table_names},
        )
        return {r[0] for r in result.fetchall()}

    async def _check_site_in_steps_bulk(
        self,
        smp_id: str,
        join_key: str,
        wf_schema: str,
        step_table_map: Dict[int, str],
        existing_tables: set,
    ) -> Dict[int, str]:
        """Check site presence across all step tables in a single UNION ALL query.

        Returns dict of step_id -> final_status ('pass'/'fail') for steps
        where the site is present.
        """
        if not _SAFE_IDENTIFIER_RE.match(join_key):
            raise SiteInsightsError(
                f"Invalid join key '{join_key}': only alphanumeric and underscore allowed."
            )

        # Build one UNION ALL instead of N separate queries
        # Each branch wrapped in parentheses so LIMIT 1 scopes correctly
        branches = []
        for step_id, table_name in step_table_map.items():
            if table_name not in existing_tables:
                continue
            fq_table = f"{wf_schema}.{table_name}"
            branches.append(
                f"(SELECT {step_id} AS step_id, "
                f"COALESCE(LOWER(final_status), 'pass') AS fs "
                f"FROM {fq_table} WHERE {join_key} = :smp_id LIMIT 1)"
            )

        if not branches:
            return {}

        union_sql = "\nUNION ALL\n".join(branches)
        try:
            rows = (
                await self.db.execute(text(union_sql), {"smp_id": smp_id})
            ).fetchall()
            return {r[0]: r[1] for r in rows}
        except Exception as exc:
            logger.warning(
                "Bulk step query failed for smp_id=%s: %s", smp_id, exc,
            )
            return {}

    # ------------------------------------------------------------------ #
    # PM Comments                                                          #
    # ------------------------------------------------------------------ #

    async def _get_pm_comments(self, smp_id: str) -> List[PMCommentEntry]:
        """Fetch PM comment columns from the staging table."""
        columns = settings.PM_COMMENT_COLUMNS
        table = settings.PM_COMMENTS_TABLE
        site_key = settings.PM_COMMENTS_SITE_KEY

        safe_columns = []
        for col in columns:
            if _SAFE_IDENTIFIER_RE.match(col):
                safe_columns.append(col)
            else:
                logger.warning("Skipping unsafe PM comment column name: %s", col)

        if not safe_columns:
            return []

        select_cols = ", ".join(safe_columns)
        query = f"SELECT {select_cols} FROM {table} WHERE {site_key} = :smp_id LIMIT 1"

        try:
            row = (await self.db.execute(text(query), {"smp_id": smp_id})).fetchone()
        except Exception as exc:
            logger.warning("Failed to fetch PM comments for smp_id=%s: %s", smp_id, exc)
            return []

        entries = []
        for col in safe_columns:
            label = col.replace("pj_", "").replace("_", " ").title()
            raw_text = None
            is_empty = True
            if row:
                val = dict(row._mapping).get(col)
                if val is not None and str(val).strip():
                    raw_text = str(val).strip()
                    is_empty = False
            entries.append(
                PMCommentEntry(
                    column_name=col,
                    column_label=label,
                    raw_text=raw_text,
                    is_empty=is_empty,
                )
            )
        return entries

    # ------------------------------------------------------------------ #
    # LLM Insight                                                          #
    # ------------------------------------------------------------------ #

    async def _generate_insight(
        self,
        smp_id: str,
        project_id: str,
        workflows: List[WorkflowInsight],
        pm_comments: List[PMCommentEntry],
    ) -> LLMInsight:
        """Use the LLM to generate a structured insight (title + summary + details)."""
        workflow_data = [w.model_dump() for w in workflows]
        comments_data = [
            {"column": c.column_label, "text": c.raw_text}
            for c in pm_comments
            if not c.is_empty
        ]

        user_content = json.dumps(
            {
                "smp_id": smp_id,
                "project_id": project_id,
                "workflows": workflow_data,
                "pm_comments": comments_data,
            },
            indent=2,
            default=str,
        )

        try:
            llm = get_llm()
            response = await llm.ainvoke(
                [
                    SystemMessage(content=_INSIGHTS_SYSTEM_PROMPT),
                    HumanMessage(content=user_content),
                ]
            )
            return self._parse_llm_response(response.content.strip())
        except Exception as exc:
            logger.error("LLM insight generation failed: %s", exc)
            return self._fallback_insight(smp_id, workflows, pm_comments)

    @staticmethod
    def _parse_llm_response(raw: str) -> LLMInsight:
        """Parse the LLM JSON response into an LLMInsight object."""
        # Strip markdown code fences if present
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[-1]
            if cleaned.endswith("```"):
                cleaned = cleaned[:-3].strip()

        try:
            data = json.loads(cleaned)
            return LLMInsight(
                title=data.get("title", ""),
                summary=data.get("summary", ""),
                details=data.get("details", []) or [],
                recommendations=data.get("recommendations", []) or [],
            )
        except (json.JSONDecodeError, TypeError):
            # LLM didn't return valid JSON — treat entire response as summary
            logger.warning("LLM returned non-JSON response, using as plain summary")
            return LLMInsight(title="Site Status", summary=raw, details=[])

    @staticmethod
    def _fallback_insight(
        smp_id: str,
        workflows: List[WorkflowInsight],
        pm_comments: List[PMCommentEntry],
    ) -> LLMInsight:
        """Generate a basic insight when the LLM gateway is unavailable."""
        if not workflows:
            return LLMInsight(
                title="No Workflow Data",
                summary=f"Site {smp_id}: No workflow data available.",
                details=[],
            )

        title_parts = []
        summary_parts = []
        details = []

        for wf in workflows:
            summary_parts.append(
                f"{wf.workflow_name} — {wf.completed_steps}/{wf.total_steps} "
                f"steps done ({wf.completion_pct}%)"
            )
            details.append(
                f"{wf.workflow_name}: {wf.completed_steps}/{wf.total_steps} "
                f"steps completed ({wf.completion_pct}%)"
            )
            if wf.held_step_details:
                names = ", ".join(s.step_name for s in wf.held_step_details)
                details.append(f"Held at: {names}")
                title_parts.append("Held")
            if wf.current_position:
                details.append(f"Current position: {wf.current_position.step_name}")

        non_empty = [c for c in pm_comments if not c.is_empty]
        for c in non_empty:
            details.append(f"PM ({c.column_label}): {c.raw_text}")

        title = " | ".join(title_parts) if title_parts else f"Site {smp_id} Progress"

        return LLMInsight(
            title=title,
            summary=". ".join(summary_parts) + ".",
            details=details,
        )

    # ------------------------------------------------------------------ #
    # Structured Summary                                                   #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _build_structured_summary(
        workflows: List[WorkflowInsight],
    ) -> Dict[str, Any]:
        """Compute key metrics for UI summary cards."""
        total_steps = sum(w.total_steps for w in workflows)
        completed = sum(w.completed_steps for w in workflows)
        held = sum(w.held_steps for w in workflows)
        overall_pct = round(completed / total_steps * 100, 2) if total_steps else 0.0

        held_names = []
        current_phases = []
        for wf in workflows:
            held_names.extend(s.step_name for s in wf.held_step_details)
            if wf.current_position and wf.current_position.phase_name:
                current_phases.append(wf.current_position.phase_name)

        return {
            "total_workflows": len(workflows),
            "total_steps": total_steps,
            "completed_steps": completed,
            "held_steps": held,
            "overall_completion_pct": overall_pct,
            "held_step_names": held_names,
            "current_phases": current_phases,
        }

    # ------------------------------------------------------------------ #
    # KG Insight (LLM)                                                     #
    # ------------------------------------------------------------------ #

    async def _generate_kg_insight(
        self,
        smp_id: str,
        project_id: str,
        kg_payload: Dict[str, Any],
        pm_comments: List[PMCommentEntry],
    ) -> LLMInsight:
        """LLM call for KG-mode: predictive, recommendation-bearing insight."""
        trimmed = self._trim_kg_payload(kg_payload)
        comments_data = [
            {"column": c.column_label, "text": c.raw_text}
            for c in pm_comments
            if not c.is_empty
        ]

        now = datetime.utcnow()
        user_content = json.dumps(
            {
                "now_utc": now.isoformat(timespec="seconds") + "Z",
                "today": now.date().isoformat(),
                "smp_id": smp_id,
                "project_id": project_id,
                "kg_site_record": trimmed,
                "pm_comments": comments_data,
            },
            indent=2,
            default=str,
        )

        try:
            llm = get_llm()
            response = await llm.ainvoke(
                [
                    SystemMessage(content=_KG_INSIGHTS_SYSTEM_PROMPT),
                    HumanMessage(content=user_content),
                ]
            )
            return self._parse_llm_response(response.content.strip())
        except Exception as exc:
            logger.error("KG insight LLM generation failed: %s", exc)
            return self._kg_fallback_insight(smp_id, kg_payload, pm_comments)

    # Known abbreviation expansions for KG field names. Anything not in this
    # map gets title-cased. Add more as the domain glossary evolves.
    _KG_ABBREVIATIONS = {
        "ec": "EC",
        "ntp": "NTP",
        "ran": "RAN",
        "bom": "BOM",
        "bat": "BAT",
        "ca": "CA",
        "ia": "IA",
        "gr": "GR",
        "hse": "HSE",
        "spo": "SPO",
        "sc": "SC",
        "gc": "GC",
        "dec": "DEC",
        "smp": "SMP",
        "id": "ID",
    }

    @classmethod
    def _humanize_key(cls, key: str) -> str:
        """Convert a KG field key into a reader-friendly label.

        Examples:
          p2_ran_ec_actual      -> "RAN EC Actual"
          p6_bom_bat_actual     -> "BOM/BAT Actual"   (when adjacent abbrs)
          hse_visits            -> "HSE Visits"
          p1_smp_status         -> "SMP Status"
          site_name             -> "Site Name"
        """
        # Drop p<N>_ phase prefix — phase grouping is conveyed elsewhere.
        body = re.sub(r"^p\d+_", "", key)
        parts = body.split("_")
        return " ".join(cls._KG_ABBREVIATIONS.get(p, p.title()) for p in parts if p)

    @classmethod
    def _humanize_kg_keys(cls, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Return a copy of the payload with top-level keys renamed to friendly labels.

        Used ONLY for the snapshot shipped in the API response. The LLM, the
        structured-summary computation, and the fallback path all continue to
        read the raw p<N>_* keys on the original payload.
        """
        return {cls._humanize_key(k): v for k, v in payload.items()}

    @staticmethod
    def _normalize_kg_dates(payload: Any) -> Any:
        """Recursively strip the time portion from ISO datetime strings.

        Milestone fields (`*_planned`, `*_actual`) arrive as full timestamps like
        "2025-09-17T00:00:00.000000000", but the time component is meaningless —
        these are date-granular events. Stripping it keeps the LLM payload lean
        AND keeps the raw kg_snapshot the UI renders human-readable.
        """
        if isinstance(payload, dict):
            return {
                k: SiteInsightsService._normalize_kg_dates(v)
                for k, v in payload.items()
            }
        if isinstance(payload, list):
            return [SiteInsightsService._normalize_kg_dates(v) for v in payload]
        if isinstance(payload, str):
            m = _DATETIME_DATE_RE.match(payload.strip())
            if m:
                return m.group(1)
        return payload

    @staticmethod
    def _trim_kg_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
        """Drop null/empty/'nan' values and group fields by phase prefix.

        Keeps top-level identity fields (site_id, region, state, …) unchanged.
        Phase-prefixed fields (p1_*, p2_*, …) are bucketed into nested objects
        so the LLM sees structured phase blocks instead of a flat 150-field dump.
        """
        def is_empty(v: Any) -> bool:
            if v is None:
                return True
            if isinstance(v, str) and (not v.strip() or v.strip().lower() == "nan"):
                return True
            if isinstance(v, list) and not v:
                return True
            return False

        identity: Dict[str, Any] = {}
        phases: Dict[str, Dict[str, Any]] = {}
        other: Dict[str, Any] = {}

        for key, val in payload.items():
            if is_empty(val):
                continue
            # Filter out all-null list rows (e.g. hse_visits with every field None)
            if isinstance(val, list):
                cleaned_list = [
                    {k: v for k, v in item.items() if not is_empty(v)}
                    if isinstance(item, dict) else item
                    for item in val
                ]
                cleaned_list = [c for c in cleaned_list if c]
                if not cleaned_list:
                    continue
                val = cleaned_list

            m = re.match(r"^(p\d+)_(.+)$", key)
            if m:
                phase, field = m.group(1), m.group(2)
                phases.setdefault(phase, {})[field] = val
            elif key.startswith("dec_"):
                other.setdefault("dec", {})[key[4:]] = val
            elif key.startswith("hse_") or key == "hse_visits":
                other.setdefault("hse", {})[key.removeprefix("hse_") or "visits"] = val
            else:
                identity[key] = val

        # Drop phases that became empty after cleaning
        phases = {k: v for k, v in phases.items() if v}

        result: Dict[str, Any] = {"identity": identity, "phases": phases}
        if other:
            result["other"] = other
        return result

    @staticmethod
    def _kg_fallback_insight(
        smp_id: str,
        kg_payload: Dict[str, Any],
        pm_comments: List[PMCommentEntry],
    ) -> LLMInsight:
        """Minimal narrative when the LLM gateway is unavailable in KG mode."""
        details: List[str] = []

        site_name = kg_payload.get("site_name")
        if site_name:
            details.append(f"Site: {site_name} ({kg_payload.get('site_id', smp_id)})")

        # Surface a few high-signal status fields if present
        for field, label in (
            ("p1_assigned_status", "Project assignment"),
            ("p2_precon_status", "Pre-construction"),
            ("p3_scoping_status", "Scoping"),
            ("p4_quoting_status", "Quoting"),
            ("p6_material_status", "Material"),
        ):
            val = kg_payload.get(field)
            if val and str(val).strip().lower() != "nan":
                details.append(f"{label}: {val}")

        non_empty_comments = [c for c in pm_comments if not c.is_empty]
        for c in non_empty_comments[:3]:
            details.append(f"PM ({c.column_label}): {c.raw_text}")

        return LLMInsight(
            title=f"Site {kg_payload.get('site_id', smp_id)} — status snapshot",
            summary="LLM insight unavailable; showing key status fields from the KG record.",
            details=details,
            recommendations=[],
        )

    @staticmethod
    def _build_kg_structured_summary(payload: Dict[str, Any]) -> Dict[str, Any]:
        """Compute lightweight summary tiles for the UI in KG mode."""
        # Count phases that have at least one '*_actual' populated as a rough
        # completion signal. This is a heuristic, not authoritative.
        phase_progress: Dict[str, Dict[str, int]] = {}
        for key, val in payload.items():
            m = re.match(r"^(p\d+)_(.+)_(actual|planned)$", key)
            if not m:
                continue
            phase = m.group(1)
            kind = m.group(3)
            bucket = phase_progress.setdefault(phase, {"actual": 0, "planned": 0})
            if val is not None and str(val).strip() and str(val).strip().lower() != "nan":
                bucket[kind] += 1

        completed_phases = sum(1 for p in phase_progress.values() if p["actual"] > 0)
        total_phases = len(phase_progress)
        overall_pct = round(completed_phases / total_phases * 100, 2) if total_phases else 0.0

        return {
            "site_id": payload.get("site_id"),
            "site_name": payload.get("site_name"),
            "region": payload.get("region"),
            "market": payload.get("market"),
            "project_type": payload.get("p1_project_type"),
            "smp_status": payload.get("p1_smp_status"),
            "total_phases": total_phases,
            "phases_with_activity": completed_phases,
            "overall_completion_pct": overall_pct,
        }
