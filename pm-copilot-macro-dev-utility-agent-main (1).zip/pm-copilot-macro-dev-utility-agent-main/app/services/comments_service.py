import logging
import math
from datetime import datetime
from typing import Any, Dict, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings

logger = logging.getLogger(__name__)


class CommentsService:
    """
    CRUD for site_comments.

    A comment is always scoped to (project_id, site_id). Any number of users
    can comment on the same site, and one user can post multiple comments.
    """

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    # ------------------------------------------------------------------ #
    # Helpers                                                              #
    # ------------------------------------------------------------------ #

    async def _site_exists(self, project_id: str, site_id: str) -> bool:
        sites_table = settings.TABLES["dim_sites"]
        q = text(
            f"SELECT 1 FROM {sites_table} "
            f"WHERE project_id = :project_id AND site_id = :site_id LIMIT 1"
        )
        row = (await self.db.execute(q, {"project_id": project_id, "site_id": site_id})).fetchone()
        return row is not None

    # ------------------------------------------------------------------ #
    # Create                                                               #
    # ------------------------------------------------------------------ #

    async def create_comment(
        self,
        project_id: str,
        site_id: str,
        user_id: str,
        user_name: Optional[str],
        comment_text: str,
    ) -> Dict[str, Any]:
        table = settings.TABLES["site_comments"]
        now = datetime.utcnow()
        q = text(f"""
            INSERT INTO {table} (
                project_id, site_id, user_id, user_name, comment_text,
                created_at, updated_at
            ) VALUES (
                :project_id, :site_id, :user_id, :user_name, :comment_text,
                :created_at, :updated_at
            )
            RETURNING comment_id, project_id, site_id, user_id, user_name,
                      comment_text, created_at, updated_at
        """)
        row = (await self.db.execute(q, {
            "project_id": project_id,
            "site_id": site_id,
            "user_id": user_id,
            "user_name": user_name,
            "comment_text": comment_text,
            "created_at": now,
            "updated_at": now,
        })).fetchone()
        await self.db.commit()
        return dict(row._mapping)

    # ------------------------------------------------------------------ #
    # Read                                                                 #
    # ------------------------------------------------------------------ #

    async def get_comment(self, project_id: str, site_id: str, comment_id: int) -> Optional[Dict[str, Any]]:
        table = settings.TABLES["site_comments"]
        q = text(f"""
            SELECT * FROM {table}
            WHERE comment_id = :comment_id
              AND project_id = :project_id
              AND site_id    = :site_id
        """)
        row = (await self.db.execute(q, {
            "comment_id": comment_id,
            "project_id": project_id,
            "site_id": site_id,
        })).fetchone()
        return dict(row._mapping) if row else None

    async def list_comments_for_site(
        self,
        project_id: str,
        site_id: str,
        user_id: Optional[str] = None,
        page: int = 1,
        page_size: int = 100,
    ) -> Dict[str, Any]:
        table = settings.TABLES["site_comments"]
        clauses = ["project_id = :project_id", "site_id = :site_id"]
        params: Dict[str, Any] = {"project_id": project_id, "site_id": site_id}
        if user_id:
            clauses.append("user_id = :user_id")
            params["user_id"] = user_id

        where = " AND ".join(clauses)
        params["limit"] = page_size
        params["offset"] = (page - 1) * page_size

        sql = f"""
            SELECT *, COUNT(*) OVER() AS _total_count
            FROM {table}
            WHERE {where}
            ORDER BY created_at DESC, comment_id DESC
            LIMIT :limit OFFSET :offset
        """
        rows = (await self.db.execute(text(sql), params)).fetchall()
        total = int(rows[0]._mapping["_total_count"]) if rows else 0
        data = [{k: v for k, v in r._mapping.items() if k != "_total_count"} for r in rows]
        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "pages": math.ceil(total / page_size) if page_size else 0,
            "project_id": project_id,
            "site_id": site_id,
            "user_id": user_id,
            "data": data,
        }

    async def list_comments_for_project(
        self,
        project_id: str,
        user_id: Optional[str] = None,
        site_id: Optional[str] = None,
        page: int = 1,
        page_size: int = 100,
    ) -> Dict[str, Any]:
        table = settings.TABLES["site_comments"]
        clauses = ["project_id = :project_id"]
        params: Dict[str, Any] = {"project_id": project_id}
        if user_id:
            clauses.append("user_id = :user_id")
            params["user_id"] = user_id
        if site_id:
            clauses.append("site_id = :site_id")
            params["site_id"] = site_id

        where = " AND ".join(clauses)
        params["limit"] = page_size
        params["offset"] = (page - 1) * page_size

        sql = f"""
            SELECT *, COUNT(*) OVER() AS _total_count
            FROM {table}
            WHERE {where}
            ORDER BY created_at DESC, comment_id DESC
            LIMIT :limit OFFSET :offset
        """
        rows = (await self.db.execute(text(sql), params)).fetchall()
        total = int(rows[0]._mapping["_total_count"]) if rows else 0
        data = [{k: v for k, v in r._mapping.items() if k != "_total_count"} for r in rows]
        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "pages": math.ceil(total / page_size) if page_size else 0,
            "project_id": project_id,
            "site_id": site_id,
            "user_id": user_id,
            "data": data,
        }

    # ------------------------------------------------------------------ #
    # Update / Delete                                                      #
    # ------------------------------------------------------------------ #

    async def update_comment(
        self,
        project_id: str,
        site_id: str,
        comment_id: int,
        user_id: str,
        comment_text: str,
    ) -> Optional[Dict[str, Any]]:
        """
        Update a comment. Only the original author (matching user_id) may edit.
        Returns None if the comment does not exist or the user_id does not match.
        """
        table = settings.TABLES["site_comments"]
        q = text(f"""
            UPDATE {table}
            SET comment_text = :comment_text,
                updated_at   = :updated_at
            WHERE comment_id = :comment_id
              AND project_id = :project_id
              AND site_id    = :site_id
              AND user_id    = :user_id
            RETURNING comment_id, project_id, site_id, user_id, user_name,
                      comment_text, created_at, updated_at
        """)
        row = (await self.db.execute(q, {
            "comment_text": comment_text,
            "updated_at": datetime.utcnow(),
            "comment_id": comment_id,
            "project_id": project_id,
            "site_id": site_id,
            "user_id": user_id,
        })).fetchone()
        await self.db.commit()
        return dict(row._mapping) if row else None

    async def delete_comment(
        self,
        project_id: str,
        site_id: str,
        comment_id: int,
        user_id: str,
    ) -> bool:
        """
        Delete a comment. Only the original author (matching user_id) may delete.
        Returns True if a row was deleted.
        """
        table = settings.TABLES["site_comments"]
        q = text(f"""
            DELETE FROM {table}
            WHERE comment_id = :comment_id
              AND project_id = :project_id
              AND site_id    = :site_id
              AND user_id    = :user_id
        """)
        result = await self.db.execute(q, {
            "comment_id": comment_id,
            "project_id": project_id,
            "site_id": site_id,
            "user_id": user_id,
        })
        await self.db.commit()
        return (result.rowcount or 0) > 0
