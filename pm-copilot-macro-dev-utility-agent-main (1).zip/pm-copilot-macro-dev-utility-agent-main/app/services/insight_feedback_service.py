import json
import logging
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings


_SNAPSHOT_FIELDS = ("title", "summary", "details", "recommendations")

logger = logging.getLogger(__name__)


class InsightFeedbackService:
    """Thumbs up/down + optional comment per LLM-generated insight, per user,
    per generation. Shared by site insights and data-browser insights via the
    `surface` discriminator.
    """

    SURFACES = {"site", "data_browser"}
    RATINGS = {"up", "down"}

    def __init__(self, db: AsyncSession):
        self.db = db

    @property
    def _table(self) -> str:
        return settings.TABLES["insight_feedback"]

    # ------------------------------------------------------------------ #
    # Submit (upsert)                                                      #
    # ------------------------------------------------------------------ #

    async def submit(
        self,
        *,
        surface: str,
        project_id: str,
        site_key: str,
        generation_id: str,
        user_id: str,
        rating: str,
        comment: Optional[str] = None,
        source: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Insert a feedback row, or update the existing row when the same
        (surface, project, site, generation, user) tuple resubmits."""
        if surface not in self.SURFACES:
            raise ValueError(f"surface must be one of {sorted(self.SURFACES)}")
        if rating not in self.RATINGS:
            raise ValueError(f"rating must be one of {sorted(self.RATINGS)}")
        if not user_id or not user_id.strip():
            raise ValueError("user_id is required")
        if not generation_id or not generation_id.strip():
            raise ValueError("generation_id is required")

        feedback_id = str(uuid.uuid4())
        now = datetime.utcnow()

        # Snapshot the insight payload by insight_id so the feedback row is
        # self-contained even after the cache rolls. NULL if the cache no
        # longer has a row matching this id.
        snapshot = await self._snapshot_for_generation(
            surface=surface,
            project_id=project_id,
            site_key=site_key,
            generation_id=generation_id.strip(),
        )

        params = {
            "feedback_id": feedback_id,
            "surface": surface,
            "project_id": project_id,
            "site_key": site_key,
            "source": source,
            "generation_id": generation_id.strip(),
            "user_id": user_id.strip(),
            "rating": rating,
            "comment": (comment or "").strip() or None,
            "snapshot": json.dumps(snapshot) if snapshot is not None else None,
            "now": now,
        }

        # Upsert on the unique tuple so a user re-submitting on the same
        # generation flips their thumb / edits their comment without creating
        # a duplicate row.
        row = (await self.db.execute(
            text(f"""
                INSERT INTO {self._table} (
                    feedback_id, surface, project_id, site_key, source,
                    generation_id, user_id, rating, comment, insight_snapshot,
                    created_at, updated_at
                ) VALUES (
                    :feedback_id, :surface, :project_id, :site_key, :source,
                    :generation_id, :user_id, :rating, :comment,
                    CAST(:snapshot AS jsonb),
                    :now, :now
                )
                ON CONFLICT (surface, project_id, site_key, generation_id, user_id)
                DO UPDATE SET
                    rating           = EXCLUDED.rating,
                    comment          = EXCLUDED.comment,
                    source           = COALESCE(EXCLUDED.source, {self._table}.source),
                    insight_snapshot = COALESCE(EXCLUDED.insight_snapshot, {self._table}.insight_snapshot),
                    updated_at       = EXCLUDED.updated_at
                RETURNING *
            """),
            params,
        )).fetchone()
        await self.db.commit()
        return self._row_to_dict(row)

    # ------------------------------------------------------------------ #
    # Read                                                                #
    # ------------------------------------------------------------------ #

    async def list_for_target(
        self,
        *,
        surface: str,
        project_id: str,
        site_key: str,
        generation_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Return all feedback rows for one site (optionally one generation)."""
        clauses = [
            "surface = :surface",
            "project_id = :project_id",
            "site_key = :site_key",
        ]
        params: Dict[str, Any] = {
            "surface": surface,
            "project_id": project_id,
            "site_key": site_key,
        }
        if generation_id:
            clauses.append("generation_id = :generation_id")
            params["generation_id"] = generation_id

        rows = (await self.db.execute(
            text(f"""
                SELECT *
                FROM {self._table}
                WHERE {" AND ".join(clauses)}
                ORDER BY updated_at DESC
            """),
            params,
        )).fetchall()
        return [self._row_to_dict(r) for r in rows]

    async def summary_for_target(
        self,
        *,
        surface: str,
        project_id: str,
        site_key: str,
        generation_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Aggregated counts for a site/generation: up, down, total, last_at.
        Cheap to call alongside the insight response so the UI can render
        the current thumb-state without fetching every row."""
        clauses = [
            "surface = :surface",
            "project_id = :project_id",
            "site_key = :site_key",
        ]
        params: Dict[str, Any] = {
            "surface": surface,
            "project_id": project_id,
            "site_key": site_key,
        }
        if generation_id:
            clauses.append("generation_id = :generation_id")
            params["generation_id"] = generation_id

        row = (await self.db.execute(
            text(f"""
                SELECT
                    COUNT(*) FILTER (WHERE rating = 'up')   AS up_count,
                    COUNT(*) FILTER (WHERE rating = 'down') AS down_count,
                    COUNT(*) FILTER (WHERE comment IS NOT NULL) AS comment_count,
                    MAX(updated_at) AS last_at
                FROM {self._table}
                WHERE {" AND ".join(clauses)}
            """),
            params,
        )).fetchone()
        return {
            "up": int(row.up_count or 0),
            "down": int(row.down_count or 0),
            "comments": int(row.comment_count or 0),
            "last_at": row.last_at.isoformat() if row.last_at else None,
        }

    # ------------------------------------------------------------------ #
    # Delete                                                              #
    # ------------------------------------------------------------------ #

    async def delete(self, feedback_id: str, user_id: str) -> bool:
        """Delete a single feedback row. Only the original submitter can remove."""
        result = await self.db.execute(
            text(f"""
                DELETE FROM {self._table}
                WHERE feedback_id = :feedback_id AND user_id = :user_id
            """),
            {"feedback_id": feedback_id, "user_id": user_id.strip()},
        )
        await self.db.commit()
        return result.rowcount > 0

    # ------------------------------------------------------------------ #
    # Snapshot lookup                                                      #
    # ------------------------------------------------------------------ #

    async def _snapshot_for_generation(
        self,
        *,
        surface: str,
        project_id: str,
        site_key: str,
        generation_id: str,
    ) -> Optional[Dict[str, Any]]:
        """Look up the cached insight by insight_id and extract the user-visible
        narrative fields. Returns None when the cache row has already rolled or
        the id doesn't match what's cached."""
        cache_table, key_col = self._cache_target(surface)
        if not cache_table:
            return None

        try:
            row = (await self.db.execute(
                text(f"""
                    SELECT payload
                    FROM {cache_table}
                    WHERE project_id = :project_id
                      AND {key_col}  = :site_key
                      AND insight_id = CAST(:insight_id AS uuid)
                """),
                {
                    "project_id": project_id,
                    "site_key": site_key,
                    "insight_id": generation_id,
                },
            )).fetchone()
        except Exception as exc:
            logger.warning(
                "Snapshot lookup failed (surface=%s project=%s key=%s id=%s): %s",
                surface, project_id, site_key, generation_id, exc,
            )
            return None

        if not row:
            return None

        payload = row._mapping["payload"]
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except (json.JSONDecodeError, TypeError):
                return None
        if not isinstance(payload, dict):
            return None

        insight = payload.get("insight") or {}
        if not isinstance(insight, dict):
            return None

        return {k: insight.get(k) for k in _SNAPSHOT_FIELDS}

    @staticmethod
    def _cache_target(surface: str) -> tuple[Optional[str], str]:
        """Return (cache_table, site_key_column) for the given surface."""
        if surface == "site":
            return settings.TABLES["site_insights_cache"], "smp_id"
        if surface == "data_browser":
            return settings.TABLES["data_browser_insights_cache"], "site_id"
        return None, "site_id"

    # ------------------------------------------------------------------ #
    # Helpers                                                              #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _row_to_dict(row) -> Dict[str, Any]:
        d = dict(row._mapping)
        d["feedback_id"] = str(d["feedback_id"])
        # insight_snapshot lands as a dict already on jsonb columns; normalize
        # the rare str case (driver-dependent) so the response is uniform.
        snap = d.get("insight_snapshot")
        if isinstance(snap, str):
            try:
                d["insight_snapshot"] = json.loads(snap)
            except (json.JSONDecodeError, TypeError):
                d["insight_snapshot"] = None
        for key in ("created_at", "updated_at"):
            if d.get(key):
                d[key] = d[key].isoformat() if hasattr(d[key], "isoformat") else d[key]
        return d