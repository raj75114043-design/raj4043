import json
import logging
from datetime import datetime
from itertools import product as cartesian_product
from typing import Any, Dict, List, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings

logger = logging.getLogger(__name__)

TABLE = f"{settings.DB_SCHEMA}.dim_project_config"


class ProjectConfigService:
    """CRUD + dimension-combo generation for per-project configuration."""

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    # ------------------------------------------------------------------ #
    # Read                                                                #
    # ------------------------------------------------------------------ #

    async def list_projects(self, is_active: Optional[bool] = None) -> List[Dict]:
        sql = f"SELECT * FROM {TABLE}"
        params: Dict[str, Any] = {}
        if is_active is not None:
            sql += " WHERE is_active = :is_active"
            params["is_active"] = is_active
        sql += " ORDER BY project_id"
        rows = (await self.db.execute(text(sql), params)).fetchall()
        return [dict(r._mapping) for r in rows]

    async def get_project(self, project_id: str) -> Optional[Dict]:
        q = text(f"SELECT * FROM {TABLE} WHERE project_id = :project_id")
        row = (await self.db.execute(q, {"project_id": project_id})).fetchone()
        return dict(row._mapping) if row else None

    # ------------------------------------------------------------------ #
    # Create / Update (upsert)                                           #
    # ------------------------------------------------------------------ #

    async def upsert_project(self, data: Dict[str, Any]) -> Dict:
        now = datetime.now()
        q = text(f"""
            INSERT INTO {TABLE} (
                project_id, project_name, functions, geo_codes,
                filter_dimensions, cross_filters, is_active,
                site_source_query, site_columns, column_labels,
                workflow_pipeline_name, workflow_join_key, workflow_selected_steps,
                site_sort_by, site_sort_order,
                data_browser_tables,
                insights_source, kg_url_template,
                created_at, updated_at
            ) VALUES (
                :project_id, :project_name, :functions, :geo_codes,
                :filter_dimensions, :cross_filters, :is_active,
                :site_source_query, :site_columns, :column_labels,
                :workflow_pipeline_name, :workflow_join_key, :workflow_selected_steps,
                :site_sort_by, :site_sort_order,
                :data_browser_tables,
                :insights_source, :kg_url_template,
                :created_at, :updated_at
            )
            ON CONFLICT (project_id) DO UPDATE SET
                project_name              = EXCLUDED.project_name,
                functions                 = EXCLUDED.functions,
                geo_codes                 = EXCLUDED.geo_codes,
                filter_dimensions         = EXCLUDED.filter_dimensions,
                cross_filters             = EXCLUDED.cross_filters,
                is_active                 = EXCLUDED.is_active,
                site_source_query         = EXCLUDED.site_source_query,
                site_columns              = EXCLUDED.site_columns,
                column_labels             = EXCLUDED.column_labels,
                workflow_pipeline_name    = EXCLUDED.workflow_pipeline_name,
                workflow_join_key         = EXCLUDED.workflow_join_key,
                workflow_selected_steps   = EXCLUDED.workflow_selected_steps,
                site_sort_by              = EXCLUDED.site_sort_by,
                site_sort_order           = EXCLUDED.site_sort_order,
                data_browser_tables       = EXCLUDED.data_browser_tables,
                insights_source           = EXCLUDED.insights_source,
                kg_url_template           = EXCLUDED.kg_url_template,
                updated_at                = EXCLUDED.updated_at
            RETURNING *
        """)
        wf_steps = data.get("workflow_selected_steps")
        insights_source = (data.get("insights_source") or "workflow").lower()
        if insights_source not in ("workflow", "kg"):
            insights_source = "workflow"
        row = (await self.db.execute(q, {
            "project_id":               data["project_id"],
            "project_name":             data["project_name"],
            "functions":                data.get("functions", []),
            "geo_codes":                data.get("geo_codes", []),
            "filter_dimensions":        json.dumps(data.get("filter_dimensions", {})),
            "cross_filters":            data.get("cross_filters", False),
            "is_active":                data.get("is_active", True),
            "site_source_query":        data.get("site_source_query") or None,
            "site_columns":             json.dumps(data.get("site_columns") or {}),
            "column_labels":            json.dumps(data.get("column_labels") or {}),
            "workflow_pipeline_name":   data.get("workflow_pipeline_name") or None,
            "workflow_join_key":        data.get("workflow_join_key") or "smp_id",
            "workflow_selected_steps":  json.dumps(wf_steps) if wf_steps else None,
            "site_sort_by":             data.get("site_sort_by") or None,
            "site_sort_order":          data.get("site_sort_order") or "asc",
            "data_browser_tables":      json.dumps(data.get("data_browser_tables") or []),
            "insights_source":          insights_source,
            "kg_url_template":          (data.get("kg_url_template") or None),
            "created_at":               now,
            "updated_at":               now,
        })).fetchone()
        await self.db.commit()
        return dict(row._mapping)

    # ------------------------------------------------------------------ #
    # Delete                                                              #
    # ------------------------------------------------------------------ #

    async def delete_project(self, project_id: str) -> bool:
        q = text(f"DELETE FROM {TABLE} WHERE project_id = :project_id")
        result = await self.db.execute(q, {"project_id": project_id})
        await self.db.commit()
        return result.rowcount > 0

    # ------------------------------------------------------------------ #
    # Dimension combo generator (used by calculator)                     #
    # ------------------------------------------------------------------ #

    @staticmethod
    def build_dimension_combos(
        filter_dimensions: Dict[str, List[str]],
        cross_filters: bool = False,
    ) -> List[Dict[str, str]]:
        """
        Generate dimension parameter dicts for calculation.

        Always includes an 'ALL' combo (no dimension filtering).
        Then per-dimension combos, and optionally the cartesian product.

        Returns a list of dicts like:
          [
            {},                                          # ALL
            {"scope_of_work": "NEW_BUILD"},              # independent
            {"scope_of_work": "MODIFICATION"},
            {"smp_name": "SMP_ALPHA"},
            {"scope_of_work": "NEW_BUILD", "smp_name": "SMP_ALPHA"},  # crossed
            ...
          ]
        """
        if not filter_dimensions:
            return [{}]  # just the ALL combo

        combos: List[Dict[str, str]] = [{}]  # ALL is always first

        # Independent: one dimension at a time, others = ALL
        for dim_name, dim_values in filter_dimensions.items():
            for val in dim_values:
                combos.append({dim_name: val})

        # Crossed: cartesian product of all dimensions
        if cross_filters and len(filter_dimensions) > 1:
            dim_names = list(filter_dimensions.keys())
            dim_value_lists = [filter_dimensions[k] for k in dim_names]
            for combo_vals in cartesian_product(*dim_value_lists):
                combo = dict(zip(dim_names, combo_vals))
                # Skip if already covered by independent (single dim)
                if len(combo) > 1:
                    combos.append(combo)

        return combos

    @staticmethod
    def dimension_key_from_params(dim_params: Dict[str, str]) -> str:
        """
        Convert a dimension parameter dict to a canonical dimension_key string.

        {} -> 'ALL'
        {"scope_of_work": "NEW_BUILD"} -> 'scope_of_work:NEW_BUILD'
        {"scope_of_work": "NEW_BUILD", "smp_name": "SMP_ALPHA"} -> 'scope_of_work:NEW_BUILD|smp_name:SMP_ALPHA'
        """
        if not dim_params:
            return "ALL"
        parts = sorted(f"{k}:{v}" for k, v in dim_params.items())
        return "|".join(parts)

    @staticmethod
    def parse_dimension_key(dimension_key: str) -> Dict[str, str]:
        """Reverse of dimension_key_from_params."""
        if dimension_key == "ALL":
            return {}
        result = {}
        for part in dimension_key.split("|"):
            k, v = part.split(":", 1)
            result[k] = v
        return result
