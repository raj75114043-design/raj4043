import json
import logging
import math
import re
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings

logger = logging.getLogger(__name__)

_SAFE_IDENT = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


def _sanitize(name: str) -> str:
    """Validate that a name is a safe SQL identifier."""
    if not _SAFE_IDENT.match(name):
        raise ValueError(f"Invalid identifier: {name!r}")
    return name


class DataBrowserService:
    """
    Generic data browser — materializes project source queries into a
    JSONB-backed table and serves them with pagination, search, and filtering.
    """

    def __init__(self, db: AsyncSession):
        self.db = db

    # ------------------------------------------------------------------ #
    # Refresh                                                              #
    # ------------------------------------------------------------------ #

    async def refresh_project_tables(
        self, project_id: str
    ) -> Dict[str, Any]:
        """
        Refresh all data browser tables for a project.

        Reads data_browser_tables from project config, executes each
        source_query, and stores rows as JSONB in dim_data_browser.
        """
        config = await self._get_project_config(project_id)
        if not config:
            raise ValueError(f"Project '{project_id}' not found.")

        raw_tables = config.get("data_browser_tables")
        if isinstance(raw_tables, str):
            raw_tables = json.loads(raw_tables)
        tables: List[Dict] = raw_tables or []

        if not tables:
            raise ValueError(
                f"Project '{project_id}' has no data_browser_tables configured."
            )

        browser_table = settings.TABLES["data_browser"]
        now = datetime.utcnow()
        results = {}

        for tbl in tables:
            alias = tbl.get("table_alias", "").strip()
            source_query = (tbl.get("source_query") or "").strip().rstrip(";")
            site_id_column = (tbl.get("site_id_column") or "").strip() or None
            region_column = (tbl.get("region_column") or "").strip() or None
            market_column = (tbl.get("market_column") or "").strip() or None
            if not alias or not source_query:
                continue

            try:
                rows = (await self.db.execute(text(source_query))).fetchall()
                columns = list(rows[0]._mapping.keys()) if rows else []
                for col_name, col_label in (
                    (site_id_column, "site_id_column"),
                    (region_column, "region_column"),
                    (market_column, "market_column"),
                ):
                    if col_name and col_name not in columns and rows:
                        logger.warning(
                            "%s '%s' not found in source_query for %s/%s; "
                            "value will be NULL",
                            col_label, col_name, project_id, alias,
                        )

                logger.info(
                    "data_browser refresh %s/%s: site_id_column=%r region_column=%r "
                    "market_column=%r columns=%s",
                    project_id, alias, site_id_column, region_column,
                    market_column, columns,
                )

                # Persist column order captured from the SELECT list so browse
                # responses preserve it (JSONB key order is non-deterministic).
                meta_table = settings.TABLES["data_browser_meta"]
                await self.db.execute(
                    text(f"""
                        INSERT INTO {meta_table}
                            (project_id, table_alias, columns, last_refreshed)
                        VALUES
                            (:pid, :alias, CAST(:cols AS jsonb), :now)
                        ON CONFLICT (project_id, table_alias) DO UPDATE
                            SET columns = EXCLUDED.columns,
                                last_refreshed = EXCLUDED.last_refreshed
                    """),
                    {
                        "pid": project_id,
                        "alias": alias,
                        "cols": json.dumps(columns),
                        "now": now,
                    },
                )

                # Delete old rows for this project + table_alias
                await self.db.execute(
                    text(f"""
                        DELETE FROM {browser_table}
                        WHERE project_id = :pid AND table_alias = :alias
                    """),
                    {"pid": project_id, "alias": alias},
                )

                # Batch insert
                batch_size = 2_000
                inserted = 0
                for i in range(0, len(rows), batch_size):
                    batch = rows[i : i + batch_size]
                    params = []
                    for idx, r in enumerate(batch, start=i):
                        row_dict = {
                            str(k): self._serialize_value(v)
                            for k, v in dict(r._mapping).items()
                        }
                        def _extract(col):
                            if not col:
                                return None
                            raw = row_dict.get(col)
                            return str(raw) if raw is not None else None

                        params.append({
                            "project_id": project_id,
                            "table_alias": alias,
                            "row_data": json.dumps(row_dict),
                            "site_id": _extract(site_id_column),
                            "region_code": _extract(region_column),
                            "market_code": _extract(market_column),
                            "display_order": idx,
                            "last_refreshed": now,
                        })
                    await self.db.execute(
                        text(f"""
                            INSERT INTO {browser_table}
                                (project_id, table_alias, row_data, site_id,
                                 region_code, market_code,
                                 display_order, last_refreshed)
                            VALUES
                                (:project_id, :table_alias, CAST(:row_data AS jsonb),
                                 :site_id, :region_code, :market_code,
                                 :display_order, :last_refreshed)
                        """),
                        params,
                    )
                    inserted += len(batch)

                results[alias] = {
                    "rows_inserted": inserted,
                    "columns": list(columns),
                }
                logger.info(
                    "Data browser refresh: project=%s table=%s rows=%d",
                    project_id, alias, inserted,
                )

            except Exception as exc:
                logger.error(
                    "Data browser refresh failed: project=%s table=%s: %s",
                    project_id, alias, exc, exc_info=True,
                )
                results[alias] = {"error": str(exc)}

        # Compute per-site, per-table derived fields. Each table can declare a
        # `derived_fields` map of {name: sql_expression}. Each expression is
        # evaluated against an aggregated view of the site's rows in the table.
        # Failures are isolated to the offending table — the rest continues.
        derived_rows = await self._compute_table_derived_fields(project_id, tables)

        # Rebuild unified site index for this project. Single SQL pass over
        # the rows we just wrote — fast, and keeps /sites endpoint loads cheap.
        # Region/market conflicts resolved by table priority (config order).
        sites_table = settings.TABLES["data_browser_sites"]

        priority_aliases = [
            (t.get("table_alias") or "").strip()
            for t in tables
            if (t.get("table_alias") or "").strip()
        ]
        priority_params: Dict[str, Any] = {}
        priority_clauses = []
        for i, a in enumerate(priority_aliases):
            pkey = f"prio_{i}"
            priority_clauses.append(f"WHEN :{pkey} THEN {i + 1}")
            priority_params[pkey] = a
        priority_case = (
            f"CASE table_alias {' '.join(priority_clauses)} ELSE 999 END"
            if priority_clauses else "999"
        )

        await self.db.execute(
            text(f"DELETE FROM {sites_table} WHERE project_id = :pid"),
            {"pid": project_id},
        )

        # derived_rows: List[{"site_id": str, "table_alias": str, "fields": {...}}]
        # We pass it as a JSON array bind and unfold it into a CTE that
        # aggregates per-table maps into one derived object per site.
        derived_payload = json.dumps(derived_rows)

        await self.db.execute(
            text(f"""
                WITH derived_input AS (
                    SELECT
                        (elem->>'site_id')      AS site_id,
                        (elem->>'table_alias')  AS table_alias,
                        (elem->'fields')        AS fields
                    FROM jsonb_array_elements(CAST(:derived_payload AS jsonb)) elem
                ),
                site_derived AS (
                    SELECT site_id,
                           jsonb_object_agg(table_alias, fields) AS derived
                    FROM derived_input
                    WHERE fields IS NOT NULL
                    GROUP BY site_id
                ),
                site_presence AS (
                    SELECT project_id, site_id,
                           (array_agg(region_code ORDER BY priority)
                              FILTER (WHERE region_code IS NOT NULL))[1] AS region_code,
                           (array_agg(market_code ORDER BY priority)
                              FILTER (WHERE market_code IS NOT NULL))[1] AS market_code,
                           jsonb_object_agg(table_alias, cnt) AS presence
                    FROM (
                        SELECT project_id, site_id, table_alias,
                               COUNT(*) AS cnt,
                               MAX(region_code) AS region_code,
                               MAX(market_code) AS market_code,
                               {priority_case} AS priority
                        FROM {browser_table}
                        WHERE project_id = :pid AND site_id IS NOT NULL
                        GROUP BY project_id, site_id, table_alias
                    ) t
                    GROUP BY project_id, site_id
                )
                INSERT INTO {sites_table}
                    (project_id, site_id, region_code, market_code,
                     presence, presence_count, derived, last_refreshed)
                SELECT sp.project_id, sp.site_id,
                       sp.region_code, sp.market_code,
                       sp.presence,
                       (
                           SELECT COUNT(*)
                           FROM jsonb_each(sp.presence)
                           WHERE (value)::int > 0
                       ) AS presence_count,
                       COALESCE(sd.derived, '{{}}'::jsonb) AS derived,
                       :now
                FROM site_presence sp
                LEFT JOIN site_derived sd ON sd.site_id = sp.site_id
            """),
            {
                **priority_params,
                "pid": project_id,
                "now": now,
                "derived_payload": derived_payload,
            },
        )

        await self.db.commit()
        return {
            "project_id": project_id,
            "tables": results,
            "refreshed_at": now.isoformat(),
        }

    # ------------------------------------------------------------------ #
    # Derived-field computation                                            #
    # ------------------------------------------------------------------ #

    # Field names accepted in derived_fields config. Same rule as elsewhere:
    # plain identifier so we can safely interpolate as a JSON object key.
    _DERIVED_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]{0,63}$")

    async def _compute_table_derived_fields(
        self, project_id: str, tables: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Evaluate each table's `derived_fields` map and return flat
        [{site_id, table_alias, fields: {name: value, ...}}] rows.

        derived_fields is a {name: sql_expression} dict per table. Each
        expression is wrapped in a controlled aggregate subquery that exposes
        `row_count` (int) and `rows` (jsonb_agg of row_data, ordered by
        display_order). Values land in the JSONB verbatim — numbers stay
        numbers, dates stay dates (as text), nulls become JSON null.
        Per-table failures are isolated (the table contributes no fields).
        """
        if not tables:
            return []

        browser_table = settings.TABLES["data_browser"]
        out: List[Dict[str, Any]] = []

        for tbl in tables:
            alias = (tbl.get("table_alias") or "").strip()
            raw_fields = tbl.get("derived_fields")
            if isinstance(raw_fields, str):
                try:
                    raw_fields = json.loads(raw_fields)
                except (json.JSONDecodeError, TypeError):
                    raw_fields = None
            if not alias or not isinstance(raw_fields, dict) or not raw_fields:
                continue

            # Validate field names. Skip the table entirely on a bad name
            # rather than silently dropping fields.
            bad = [k for k in raw_fields.keys() if not self._DERIVED_NAME_RE.match(k or "")]
            if bad:
                logger.warning(
                    "Skipping derived_fields for project=%s table=%s — "
                    "invalid field names: %s", project_id, alias, bad,
                )
                continue

            # Build jsonb_build_object('k1', (<expr1>), 'k2', (<expr2>), ...)
            select_parts = []
            for name, expr in raw_fields.items():
                expr_str = (str(expr) if expr is not None else "").strip()
                if not expr_str:
                    continue
                # Quote the JSON key literal; the expression itself is the
                # PM-provided SQL and runs as-is in the aggregate scope.
                select_parts.append(f"'{name}', ({expr_str})")

            if not select_parts:
                continue

            obj_expr = "jsonb_build_object(" + ", ".join(select_parts) + ")"

            # Evaluate the derived expressions for EVERY site in the project,
            # not just sites that have rows in this table. Sites with no rows
            # in this table see row_count=0 and rows='[]'::jsonb, so a PM
            # expression like `CASE WHEN row_count = 0 THEN 'missing' ...`
            # works as expected.
            sql = f"""
                SELECT site_id, ({obj_expr}) AS fields
                FROM (
                    SELECT u.site_id,
                           COUNT(d.site_id) AS row_count,
                           COALESCE(
                               jsonb_agg(d.row_data ORDER BY d.display_order)
                                   FILTER (WHERE d.site_id IS NOT NULL),
                               '[]'::jsonb
                           ) AS rows
                    FROM (
                        SELECT DISTINCT site_id
                        FROM {browser_table}
                        WHERE project_id = :pid AND site_id IS NOT NULL
                    ) u
                    LEFT JOIN {browser_table} d
                      ON  d.project_id  = :pid
                      AND d.table_alias = :alias
                      AND d.site_id     = u.site_id
                    GROUP BY u.site_id
                ) s
            """
            try:
                rows = (await self.db.execute(
                    text(sql),
                    {"pid": project_id, "alias": alias},
                )).fetchall()
            except Exception as exc:
                logger.warning(
                    "derived_fields SQL failed for project=%s table=%s — "
                    "this table contributes no derived values: %s",
                    project_id, alias, exc,
                )
                # Postgres aborts the surrounding txn on error; reset it so
                # the remaining tables and the unified-sites rebuild proceed.
                await self.db.rollback()
                continue

            for r in rows:
                fields = r._mapping["fields"]
                if isinstance(fields, str):
                    try:
                        fields = json.loads(fields)
                    except (json.JSONDecodeError, TypeError):
                        fields = None
                if not isinstance(fields, dict):
                    continue
                out.append({
                    "site_id": r._mapping["site_id"],
                    "table_alias": alias,
                    "fields": fields,
                })

        return out

    # ------------------------------------------------------------------ #
    # List available tables                                                #
    # ------------------------------------------------------------------ #

    async def list_tables(self, project_id: str) -> List[Dict[str, Any]]:
        """Return configured tables with row counts and column info."""
        config = await self._get_project_config(project_id)
        if not config:
            raise ValueError(f"Project '{project_id}' not found.")

        raw_tables = config.get("data_browser_tables")
        if isinstance(raw_tables, str):
            raw_tables = json.loads(raw_tables)
        tables: List[Dict] = raw_tables or []

        browser_table = settings.TABLES["data_browser"]

        result = []
        for tbl in tables:
            alias = tbl.get("table_alias", "")
            label = tbl.get("label", alias)
            filterable = tbl.get("filterable_columns", [])

            # Get row count and columns from materialized data
            count_row = (await self.db.execute(
                text(f"""
                    SELECT COUNT(*) AS cnt
                    FROM {browser_table}
                    WHERE project_id = :pid AND table_alias = :alias
                """),
                {"pid": project_id, "alias": alias},
            )).fetchone()

            # Prefer captured column order from meta; fall back to JSONB keys
            columns = await self._get_column_order(project_id, alias)
            if not columns:
                sample = (await self.db.execute(
                    text(f"""
                        SELECT row_data FROM {browser_table}
                        WHERE project_id = :pid AND table_alias = :alias
                        LIMIT 1
                    """),
                    {"pid": project_id, "alias": alias},
                )).fetchone()
                if sample and sample.row_data:
                    rd = sample.row_data if isinstance(sample.row_data, dict) else json.loads(sample.row_data)
                    columns = list(rd.keys())

            result.append({
                "table_alias": alias,
                "label": label,
                "row_count": count_row.cnt if count_row else 0,
                "columns": columns,
                "filterable_columns": filterable,
            })

        return result

    # ------------------------------------------------------------------ #
    # Browse / query                                                       #
    # ------------------------------------------------------------------ #

    async def browse_table(
        self,
        project_id: str,
        table_alias: str,
        page: int = 1,
        page_size: int = 50,
        search: Optional[str] = None,
        filters: Optional[Dict[str, str]] = None,
        sort_by: Optional[str] = None,
        sort_order: str = "asc",
        site_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Paginated browse of a single materialized table with search and filters.

        When `site_id` is provided, returns all rows in this table matching
        that site — point lookup using the (project_id, site_id, table_alias)
        index, so it's fast even for tables with many rows per site.
        """
        browser_table = settings.TABLES["data_browser"]

        clauses = [
            "project_id = :pid",
            "table_alias = :alias",
        ]
        params: Dict[str, Any] = {
            "pid": project_id,
            "alias": table_alias,
        }

        if site_id:
            clauses.append("site_id = :site_id")
            params["site_id"] = site_id

        # Global text search across all JSONB values
        if search:
            clauses.append("row_data::text ILIKE :search")
            params["search"] = f"%{search}%"

        # Column-level filters
        if filters:
            for i, (col, val) in enumerate(filters.items()):
                safe_col = _sanitize(col)
                pkey = f"fv_{i}"
                clauses.append(f"row_data->>'{safe_col}' ILIKE :{pkey}")
                params[pkey] = f"%{val}%"

        where = " AND ".join(clauses)

        # Sort
        if sort_by:
            safe_sort = _sanitize(sort_by)
            direction = "DESC" if sort_order.lower() == "desc" else "ASC"
            order_clause = f"row_data->>'{safe_sort}' {direction}, display_order"
        else:
            order_clause = "display_order"

        params["limit"] = page_size
        params["offset"] = (page - 1) * page_size

        sql = f"""
            SELECT row_data, display_order,
                   COUNT(*) OVER() AS _total_count
            FROM {browser_table}
            WHERE {where}
            ORDER BY {order_clause}
            LIMIT :limit OFFSET :offset
        """

        rows = (await self.db.execute(text(sql), params)).fetchall()

        column_order = await self._get_column_order(project_id, table_alias)

        total = rows[0]._total_count if rows else 0
        data = []
        for r in rows:
            rd = r.row_data if isinstance(r.row_data, dict) else json.loads(r.row_data)
            data.append(self._reorder_row(rd, column_order))

        columns = column_order or (list(data[0].keys()) if data else [])

        return {
            "project_id": project_id,
            "table_alias": table_alias,
            "total": total,
            "page": page,
            "page_size": page_size,
            "pages": math.ceil(total / page_size) if total else 0,
            "columns": columns,
            "data": data,
        }

    # ------------------------------------------------------------------ #
    # Unified site index                                                   #
    # ------------------------------------------------------------------ #

    async def list_unique_sites(
        self,
        project_id: str,
        page: int = 1,
        page_size: int = 50,
        search: Optional[str] = None,
        present_in: Optional[List[str]] = None,
        absent_from: Optional[List[str]] = None,
        region_code: Optional[str] = None,
        market_code: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Paginated unique-site list across all data browser tables.

        Reads the materialized dim_data_browser_sites — a plain indexed
        SELECT, fast regardless of dataset size. Each site carries a
        per-table row-count map; tables not present have count 0.
        Region/market are denormalized by table priority order.
        """
        sites_table = settings.TABLES["data_browser_sites"]

        clauses = ["project_id = :pid"]
        params: Dict[str, Any] = {"pid": project_id}

        if search:
            clauses.append("site_id ILIKE :search")
            params["search"] = f"%{search}%"
        if region_code:
            clauses.append("region_code = :region_code")
            params["region_code"] = region_code
        if market_code:
            clauses.append("market_code = :market_code")
            params["market_code"] = market_code

        # JSONB key-existence via (presence -> :alias) IS NOT NULL — works
        # for any alias string (spaces, mixed case, etc.) via bind params.
        for i, alias in enumerate(present_in or []):
            pkey = f"present_{i}"
            clauses.append(f"(presence -> :{pkey}) IS NOT NULL")
            params[pkey] = alias
        for i, alias in enumerate(absent_from or []):
            pkey = f"absent_{i}"
            clauses.append(f"(presence -> :{pkey}) IS NULL")
            params[pkey] = alias

        where = " AND ".join(clauses)
        params["limit"] = page_size
        params["offset"] = (page - 1) * page_size

        # Sort by breadth of presence: sites appearing in the most tables
        # come first (all configured tables -> N-1 -> ...). site_id is the
        # stable tiebreaker so pagination is deterministic. presence_count
        # is materialized on the table (migration 021) — the index on
        # (project_id, presence_count DESC, site_id) serves the ORDER BY
        # directly.
        rows = (await self.db.execute(
            text(f"""
                SELECT site_id, region_code, market_code, presence, derived,
                       COUNT(*) OVER() AS _total_count
                FROM {sites_table}
                WHERE {where}
                ORDER BY presence_count DESC, site_id
                LIMIT :limit OFFSET :offset
            """),
            params,
        )).fetchall()

        total = rows[0]._total_count if rows else 0

        # Determine the full set of indexed table aliases so the response
        # always carries every table (with 0 for absent ones).
        config = await self._get_project_config(project_id)
        raw_tables = (config or {}).get("data_browser_tables")
        if isinstance(raw_tables, str):
            raw_tables = json.loads(raw_tables)
        all_aliases = [
            t.get("table_alias") for t in (raw_tables or [])
            if t.get("table_alias") and t.get("site_id_column")
        ]

        data = []
        for r in rows:
            presence_raw = r.presence if isinstance(r.presence, dict) else json.loads(r.presence)
            derived_raw = r.derived if isinstance(r.derived, dict) else (
                json.loads(r.derived) if r.derived else {}
            )
            # Always emit a key per configured alias so the UI doesn't have to
            # special-case missing entries. Absent (or no rows for the site
            # in that table) = empty object.
            derived = {a: derived_raw.get(a, {}) for a in all_aliases}
            data.append({
                "site_id": r.site_id,
                "region_code": r.region_code,
                "market_code": r.market_code,
                "presence": {a: int(presence_raw.get(a, 0)) for a in all_aliases},
                "derived": derived,
            })

        return {
            "project_id": project_id,
            "total": total,
            "page": page,
            "page_size": page_size,
            "pages": math.ceil(total / page_size) if total else 0,
            "tables": all_aliases,
            "data": data,
        }

    async def get_unique_sites_filter_options(
        self, project_id: str
    ) -> Dict[str, Any]:
        """
        Filter-option payload for the unified sites endpoint.

        Returns:
          - region_codes / market_codes: distinct sorted values
          - geo_hierarchy: [{region_code, market_codes: [...]}]
          - tables: indexed table aliases (drives present_in / absent_from)
        """
        sites_table = settings.TABLES["data_browser_sites"]

        rows = (await self.db.execute(
            text(f"""
                SELECT DISTINCT region_code, market_code
                FROM {sites_table}
                WHERE project_id = :pid
                ORDER BY region_code, market_code
            """),
            {"pid": project_id},
        )).fetchall()

        nested: Dict[str, List[str]] = {}
        region_set = set()
        market_set = set()
        for region, market in rows:
            if region:
                region_set.add(region)
                bucket = nested.setdefault(region, [])
                if market and market not in bucket:
                    bucket.append(market)
            if market:
                market_set.add(market)

        geo_hierarchy = [
            {"region_code": region, "market_codes": sorted(markets)}
            for region, markets in sorted(nested.items())
        ]

        config = await self._get_project_config(project_id)
        raw_tables = (config or {}).get("data_browser_tables")
        if isinstance(raw_tables, str):
            raw_tables = json.loads(raw_tables)
        tables_meta = [
            {"table_alias": t.get("table_alias"), "label": t.get("label") or t.get("table_alias")}
            for t in (raw_tables or [])
            if t.get("table_alias") and t.get("site_id_column")
        ]

        return {
            "project_id":    project_id,
            "region_codes":  sorted(region_set),
            "market_codes":  sorted(market_set),
            "geo_hierarchy": geo_hierarchy,
            "tables":        tables_meta,
        }

    # ------------------------------------------------------------------ #
    # Search across all tables                                             #
    # ------------------------------------------------------------------ #

    async def search_all_tables(
        self,
        project_id: str,
        search: str,
        page_size: int = 20,
    ) -> Dict[str, Any]:
        """
        Search across all tables for a project, returning top matches per table.
        """
        config = await self._get_project_config(project_id)
        if not config:
            raise ValueError(f"Project '{project_id}' not found.")

        raw_tables = config.get("data_browser_tables")
        if isinstance(raw_tables, str):
            raw_tables = json.loads(raw_tables)
        tables: List[Dict] = raw_tables or []

        browser_table = settings.TABLES["data_browser"]
        results = {}

        for tbl in tables:
            alias = tbl.get("table_alias", "")
            label = tbl.get("label", alias)
            if not alias:
                continue

            rows = (await self.db.execute(
                text(f"""
                    SELECT row_data, COUNT(*) OVER() AS _total_count
                    FROM {browser_table}
                    WHERE project_id = :pid
                      AND table_alias = :alias
                      AND row_data::text ILIKE :search
                    ORDER BY display_order
                    LIMIT :limit
                """),
                {
                    "pid": project_id,
                    "alias": alias,
                    "search": f"%{search}%",
                    "limit": page_size,
                },
            )).fetchall()

            column_order = await self._get_column_order(project_id, alias)
            total_matches = rows[0]._total_count if rows else 0
            data = []
            for r in rows:
                rd = r.row_data if isinstance(r.row_data, dict) else json.loads(r.row_data)
                data.append(self._reorder_row(rd, column_order))

            results[alias] = {
                "label": label,
                "total_matches": total_matches,
                "data": data,
            }

        return {
            "project_id": project_id,
            "search_term": search,
            "tables": results,
        }

    # ------------------------------------------------------------------ #
    # Filter options                                                       #
    # ------------------------------------------------------------------ #

    # Max distinct values for a column to be considered filterable
    FILTER_AUTO_DETECT_THRESHOLD = 50

    async def get_filter_options(
        self,
        project_id: str,
        table_alias: str,
    ) -> Dict[str, List[str]]:
        """
        Return distinct values for each filterable column of a table.

        If filterable_columns is configured in project config, uses that list.
        Otherwise auto-detects: scans all columns and includes those with
        <= FILTER_AUTO_DETECT_THRESHOLD distinct non-null values.
        """
        browser_table = settings.TABLES["data_browser"]

        config = await self._get_project_config(project_id)
        raw_tables = config.get("data_browser_tables") if config else None
        if isinstance(raw_tables, str):
            raw_tables = json.loads(raw_tables)

        tbl_config = None
        for t in (raw_tables or []):
            if t.get("table_alias") == table_alias:
                tbl_config = t
                break

        filterable = (tbl_config or {}).get("filterable_columns") or []

        # Auto-detect if no filterable columns configured
        if not filterable:
            filterable = await self._auto_detect_filterable_columns(
                project_id, table_alias
            )

        options: Dict[str, List[str]] = {}
        for col in filterable:
            safe_col = _sanitize(col)
            rows = (await self.db.execute(
                text(f"""
                    SELECT DISTINCT row_data->>'{safe_col}' AS val
                    FROM {browser_table}
                    WHERE project_id = :pid
                      AND table_alias = :alias
                      AND row_data->>'{safe_col}' IS NOT NULL
                    ORDER BY val
                """),
                {"pid": project_id, "alias": table_alias},
            )).fetchall()
            options[col] = [r.val for r in rows]

        return options

    async def _auto_detect_filterable_columns(
        self,
        project_id: str,
        table_alias: str,
    ) -> List[str]:
        """
        Discover columns that have low cardinality (<=threshold distinct values).
        Returns column names suitable for dropdown filters.
        """
        browser_table = settings.TABLES["data_browser"]

        # Get all column names from a sample row
        sample = (await self.db.execute(
            text(f"""
                SELECT row_data FROM {browser_table}
                WHERE project_id = :pid AND table_alias = :alias
                LIMIT 1
            """),
            {"pid": project_id, "alias": table_alias},
        )).fetchone()

        if not sample or not sample.row_data:
            return []

        rd = sample.row_data if isinstance(sample.row_data, dict) else json.loads(sample.row_data)
        all_columns = list(rd.keys())

        filterable = []
        for col in all_columns:
            safe_col = _sanitize(col)
            # Count distinct values, capped at threshold + 1
            row = (await self.db.execute(
                text(f"""
                    SELECT COUNT(*) AS cnt FROM (
                        SELECT DISTINCT row_data->>'{safe_col}' AS val
                        FROM {browser_table}
                        WHERE project_id = :pid
                          AND table_alias = :alias
                          AND row_data->>'{safe_col}' IS NOT NULL
                        LIMIT :cap
                    ) sub
                """),
                {
                    "pid": project_id,
                    "alias": table_alias,
                    "cap": self.FILTER_AUTO_DETECT_THRESHOLD + 1,
                },
            )).fetchone()

            if row and row.cnt <= self.FILTER_AUTO_DETECT_THRESHOLD:
                filterable.append(col)

        logger.info(
            "Auto-detected %d filterable columns for %s/%s: %s",
            len(filterable), project_id, table_alias, filterable,
        )
        return filterable

    # ------------------------------------------------------------------ #
    # Helpers                                                              #
    # ------------------------------------------------------------------ #

    async def _get_column_order(
        self, project_id: str, table_alias: str
    ) -> List[str]:
        """Fetch the captured column order for a table; [] if not yet refreshed."""
        meta_table = settings.TABLES["data_browser_meta"]
        row = (await self.db.execute(
            text(f"""
                SELECT columns FROM {meta_table}
                WHERE project_id = :pid AND table_alias = :alias
            """),
            {"pid": project_id, "alias": table_alias},
        )).fetchone()
        if not row or not row.columns:
            return []
        cols = row.columns if isinstance(row.columns, list) else json.loads(row.columns)
        return list(cols)

    @staticmethod
    def _reorder_row(rd: Dict[str, Any], order: List[str]) -> Dict[str, Any]:
        """Return a new dict with keys in `order`, then any remaining keys."""
        if not order:
            return rd
        ordered = {k: rd[k] for k in order if k in rd}
        for k, v in rd.items():
            if k not in ordered:
                ordered[k] = v
        return ordered

    async def _get_project_config(self, project_id: str) -> Optional[Dict]:
        table = settings.TABLES["project_config"]
        row = (await self.db.execute(
            text(f"SELECT * FROM {table} WHERE project_id = :pid"),
            {"pid": project_id},
        )).fetchone()
        return dict(row._mapping) if row else None

    @staticmethod
    def _serialize_value(v: Any) -> Any:
        """Convert non-JSON-serializable values to strings."""
        if v is None:
            return None
        if isinstance(v, (int, float, bool, str)):
            return v
        if isinstance(v, datetime):
            return v.isoformat()
        from datetime import date
        if isinstance(v, date):
            return v.isoformat()
        return str(v)
