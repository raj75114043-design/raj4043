import json
import logging
import math
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings

logger = logging.getLogger(__name__)


class SitesService:
    """
    Manages the dim_sites materialized table.

    Responsibilities:
    - config-driven daily refresh (one project at a time, independent)
    - paginated + filtered site queries
    - summary / distribution stats
    - filter-options for dropdown population
    """

    def __init__(self, db: AsyncSession):
        self.db = db

    # ------------------------------------------------------------------ #
    # Refresh                                                              #
    # ------------------------------------------------------------------ #

    async def refresh_project_sites(self, project_id: str) -> Dict[str, Any]:
        """
        Refresh dim_sites for one project using its site_source_query config.

        Flow:
          1. Load project config (source query, column defs, computed expressions)
          2. Build a full SELECT that wraps the source query and injects computed columns
          3. DELETE existing rows for this project
          4. Bulk INSERT new rows in batches of 5 000
          5. Return a result summary

        Raises ValueError if the project has no site_source_query configured.
        """
        config = await self._get_project_config(project_id)
        if not config:
            raise ValueError(f"Project '{project_id}' not found.")

        source_query = (config.get("site_source_query") or "").strip().rstrip(";")
        if not source_query:
            raise ValueError(
                f"Project '{project_id}' has no site_source_query configured. "
                "Set it via POST /api/v1/project-config before refreshing."
            )

        _raw_cols = config.get("site_columns") or {}
        col_config: Dict[str, Any] = json.loads(_raw_cols) if isinstance(_raw_cols, str) else _raw_cols

        # -------------------------------------------------------------- #
        # Probe source query to discover which columns are present        #
        # -------------------------------------------------------------- #
        probe_sql = f"SELECT * FROM ({source_query}) src WHERE false"
        try:
            probe_result = await self.db.execute(text(probe_sql))
            source_cols = set(probe_result.keys())
            logger.info("source_cols for project '%s': %s", project_id, sorted(source_cols))
            logger.info("display_order in source_cols: %s", "display_order" in source_cols)

        except Exception as exc:
            raise ValueError(f"site_source_query failed: {exc}") from exc

        def _col(name: str) -> str:
            if name in source_cols:
                return f"src.{name}::VARCHAR"
            return "NULL::VARCHAR"

        # -------------------------------------------------------------- #
        # Build the enriched SELECT from the source query                 #
        # -------------------------------------------------------------- #
        # phase, progress_pct, display_order come from source query if present, else NULL
        phase_expr         = "src.phase::VARCHAR"             if "phase"         in source_cols else "NULL::VARCHAR"
        progress_expr      = "src.progress_pct::NUMERIC"      if "progress_pct"  in source_cols else "NULL::NUMERIC"
        display_order_expr = "src.display_order::INTEGER"     if "display_order" in source_cols else "NULL::INTEGER"

        # Collect project-specific attribute columns. display_order is a
        # top-level column now — never duplicate it into attributes JSONB.
        attr_cols = [c for c in col_config.keys() if c != "display_order"]

        # Build JSONB object expression: jsonb_build_object('k1', src.k1, 'k2', src.k2, ...)
        if attr_cols:
            pairs = ", ".join(f"'{c}', src.{c}" for c in attr_cols)
            attributes_expr = f"jsonb_build_object({pairs})"
        else:
            attributes_expr = "'{}'::jsonb"

        enriched_sql = f"""
            SELECT
                src.site_id::VARCHAR   AS site_id,
                {_col('region_code')}  AS region_code,
                {_col('area_code')}    AS area_code,
                {_col('market_code')}  AS market_code,
                {_col('status')}       AS status,
                {phase_expr}           AS phase,
                {progress_expr}        AS progress_pct,
                {display_order_expr}   AS display_order,
                {attributes_expr}      AS attributes
            FROM ({source_query}) src
            WHERE src.site_id IS NOT NULL
        """

        logger.info("Fetching source sites for project '%s'", project_id)
        try:
            rows = (await self.db.execute(text(enriched_sql))).fetchall()
        except Exception as exc:
            raise ValueError(f"site_source_query failed: {exc}") from exc

        total_fetched = len(rows)
        logger.info("Fetched %d source rows for project '%s'", total_fetched, project_id)

        # -------------------------------------------------------------- #
        # Swap: delete old rows, bulk insert new ones                     #
        # -------------------------------------------------------------- #
        sites_table = settings.TABLES["dim_sites"]
        now = datetime.utcnow()

        await self.db.execute(
            text(f"DELETE FROM {sites_table} WHERE project_id = :pid"),
            {"pid": project_id},
        )

        batch_size = 5_000
        inserted = 0
        for i in range(0, total_fetched, batch_size):
            batch = rows[i : i + batch_size]
            params = []
            for r in batch:
                rd = dict(r._mapping)
                attrs = rd.get("attributes")
                params.append({
                    "site_id":       str(rd["site_id"]),
                    "project_id":    project_id,
                    "region_code":   rd.get("region_code"),
                    "area_code":     rd.get("area_code"),
                    "market_code":   rd.get("market_code"),
                    "phase":         rd.get("phase"),
                    "progress_pct":  rd.get("progress_pct"),
                    "status":        rd.get("status"),
                    "display_order": rd.get("display_order"),
                    "attributes":    json.dumps(attrs) if isinstance(attrs, dict) else (attrs or "{}"),
                    "last_refreshed": now,
                })

            await self.db.execute(
                text(f"""
                    INSERT INTO {sites_table} (
                        site_id, project_id,
                        region_code, area_code, market_code,
                        phase, progress_pct, status,
                        display_order, attributes, last_refreshed
                    ) VALUES (
                        :site_id, :project_id,
                        :region_code, :area_code, :market_code,
                        :phase, :progress_pct, :status,
                        :display_order, CAST(:attributes AS jsonb), :last_refreshed
                    )
                    ON CONFLICT (project_id, site_id) DO UPDATE SET
                        region_code    = EXCLUDED.region_code,
                        area_code      = EXCLUDED.area_code,
                        market_code    = EXCLUDED.market_code,
                        phase          = EXCLUDED.phase,
                        progress_pct   = EXCLUDED.progress_pct,
                        status         = EXCLUDED.status,
                        display_order  = EXCLUDED.display_order,
                        attributes     = EXCLUDED.attributes,
                        last_refreshed = EXCLUDED.last_refreshed
                """),
                params,
            )
            inserted += len(batch)

        await self.db.commit()
        logger.info(
            "Site refresh complete for '%s': %d rows inserted", project_id, inserted
        )

        # Refresh per-project attribute cardinality so auto-grouped search can
        # route terms correctly. Failure here must not break the refresh itself.
        try:
            await self.refresh_attribute_cardinality(project_id)
        except Exception as exc:
            logger.warning(
                "Attribute cardinality refresh failed for '%s' (continuing): %s",
                project_id, exc,
            )

        return {
            "project_id":    project_id,
            "rows_fetched":  total_fetched,
            "rows_inserted": inserted,
            "refreshed_at":  now.isoformat(),
        }

    # ------------------------------------------------------------------ #
    # Attribute cardinality                                                #
    # ------------------------------------------------------------------ #

    # Searchable fixed columns. Order is not significant; cardinality decides
    # which wins when a term value appears in more than one place.
    _CARDINALITY_FIXED_COLUMNS: List[str] = [
        "site_id",
        "region_code",
        "area_code",
        "market_code",
        "phase",
        "status",
    ]

    async def refresh_attribute_cardinality(self, project_id: str) -> Dict[str, int]:
        """Recompute (project_id, attribute_key) -> distinct_count for one project.

        Wipes existing rows for the project and inserts fresh ones in a single
        transaction. Counts fixed columns and every key found inside the
        attributes JSONB. NULL/blank values are excluded from the distinct count
        so a half-populated column doesn't claim '' as a value.
        """
        cardinality_table = settings.TABLES["site_attr_cardinality"]
        sites_table = settings.TABLES["dim_sites"]

        await self.db.execute(
            text(f"DELETE FROM {cardinality_table} WHERE project_id = :p"),
            {"p": project_id},
        )

        # 1. Fixed columns
        fixed_select = " UNION ALL ".join(
            f"""
            SELECT :p AS project_id,
                   '{col}' AS attribute_key,
                   TRUE   AS is_fixed_column,
                   COUNT(DISTINCT NULLIF(TRIM({col}::TEXT), ''))::INT AS distinct_count
            FROM {sites_table}
            WHERE project_id = :p
            """
            for col in self._CARDINALITY_FIXED_COLUMNS
        )

        # 2. Attribute keys inside the JSONB
        attr_select = f"""
            SELECT :p AS project_id,
                   attr.key AS attribute_key,
                   FALSE    AS is_fixed_column,
                   COUNT(DISTINCT NULLIF(TRIM(attr.value), ''))::INT AS distinct_count
            FROM {sites_table}, jsonb_each_text(attributes) AS attr
            WHERE project_id = :p
            GROUP BY attr.key
        """

        await self.db.execute(
            text(f"""
                INSERT INTO {cardinality_table}
                    (project_id, attribute_key, is_fixed_column, distinct_count, refreshed_at)
                SELECT project_id, attribute_key, is_fixed_column, distinct_count, NOW()
                FROM (
                    {fixed_select}
                    UNION ALL
                    {attr_select}
                ) all_keys
                WHERE distinct_count > 0
            """),
            {"p": project_id},
        )
        await self.db.commit()

        row = (await self.db.execute(
            text(f"SELECT COUNT(*) AS n FROM {cardinality_table} WHERE project_id = :p"),
            {"p": project_id},
        )).fetchone()
        n = int(row._mapping["n"]) if row else 0
        logger.info("Cardinality refresh complete for '%s': %d attribute keys", project_id, n)
        return {"project_id": project_id, "attribute_keys": n}

    async def _apply_search_clauses(
        self,
        project_id: str,
        search: Optional[str],
        clauses: List[str],
        params: Dict[str, Any],
    ) -> None:
        """Append search-derived WHERE clauses to `clauses` and binds to `params`.

        Whole-value, case-insensitive match. Comma-separated terms are
        auto-grouped by attribute (lowest distinct_count wins), OR within
        each group, AND across groups. Unmatched terms drop silently. No-op
        when `search` is empty or every term is unmatched.
        """
        if not search:
            return
        terms = [t.strip().lower() for t in search.split(",") if t.strip()]
        if not terms:
            return
        groups = await self._group_search_terms(project_id, terms)
        for i, (attr_key, is_fixed, values) in enumerate(groups):
            bind = f"search_{i}"
            if is_fixed:
                clauses.append(f"LOWER({attr_key}) = ANY(:{bind})")
            else:
                clauses.append(f"LOWER(attributes ->> :{bind}_key) = ANY(:{bind})")
                params[f"{bind}_key"] = attr_key
            params[bind] = values

    async def _group_search_terms(
        self, project_id: str, terms: List[str]
    ) -> List[tuple]:
        """Classify search terms by which attribute they belong to.

        Returns a list of (attribute_key, is_fixed_column, [matched_values]).
        Each value appears in exactly one group; terms matching nothing are
        dropped. Ties (term matches multiple attributes) are broken by lowest
        distinct_count on dim_site_attribute_cardinality.
        """
        if not terms:
            return []

        sites_table = settings.TABLES["dim_sites"]
        card_table  = settings.TABLES["site_attr_cardinality"]

        # For each (term, attribute) pair where the term actually appears in
        # this project, return the attribute's distinct_count. ROW_NUMBER picks
        # the lowest-cardinality attribute per term.
        sql = f"""
            WITH probes AS (
                {self._build_term_probes_sql()}
            ),
            ranked AS (
                SELECT
                    p.term,
                    p.attribute_key,
                    p.is_fixed_column,
                    c.distinct_count,
                    ROW_NUMBER() OVER (
                        PARTITION BY p.term
                        ORDER BY c.distinct_count NULLS LAST, p.attribute_key
                    ) AS rn
                FROM probes p
                LEFT JOIN {card_table} c
                  ON c.project_id    = :project_id
                 AND c.attribute_key = p.attribute_key
            )
            SELECT term, attribute_key, is_fixed_column
            FROM ranked
            WHERE rn = 1
        """

        params: Dict[str, Any] = {
            "project_id": project_id,
            "terms": terms,
            "sites_table_project_id": project_id,
        }
        # The probes need the project_id bound separately because they live in a CTE;
        # easier to inline via f-string for the table name but use a bind for the value.
        rows = (await self.db.execute(text(sql), params)).fetchall()

        # Group: attribute_key -> {is_fixed: bool, values: [str]}
        groups: Dict[str, Dict[str, Any]] = {}
        for r in rows:
            key  = r._mapping["attribute_key"]
            term = r._mapping["term"]
            is_fixed = bool(r._mapping["is_fixed_column"])
            slot = groups.setdefault(key, {"is_fixed": is_fixed, "values": []})
            slot["values"].append(term)

        if not groups:
            return []

        # Stable sort by attribute key so the generated SQL is deterministic
        return [
            (key, slot["is_fixed"], slot["values"])
            for key, slot in sorted(groups.items())
        ]

    def _build_term_probes_sql(self) -> str:
        """SQL fragment yielding (term, attribute_key, is_fixed_column) rows for
        every term-attribute pair that actually has at least one row in
        dim_sites for this project. Used by _group_search_terms."""
        sites_table = settings.TABLES["dim_sites"]
        fixed_probes = " UNION ALL ".join(
            f"""
            SELECT t.term, '{col}' AS attribute_key, TRUE AS is_fixed_column
            FROM unnest(CAST(:terms AS TEXT[])) AS t(term)
            WHERE EXISTS (
                SELECT 1 FROM {sites_table}
                WHERE project_id = :sites_table_project_id
                  AND LOWER({col}) = t.term
            )
            """
            for col in self._CARDINALITY_FIXED_COLUMNS
        )
        attr_probe = f"""
            SELECT DISTINCT t.term, attr.key AS attribute_key, FALSE AS is_fixed_column
            FROM unnest(CAST(:terms AS TEXT[])) AS t(term)
            JOIN {sites_table} s ON s.project_id = :sites_table_project_id
            CROSS JOIN LATERAL jsonb_each_text(s.attributes) AS attr
            WHERE LOWER(attr.value) = t.term
        """
        return f"{fixed_probes} UNION ALL {attr_probe}"

    # ------------------------------------------------------------------ #
    # Query                                                                #
    # ------------------------------------------------------------------ #

    # Fixed columns that can be used directly in ORDER BY
    _FIXED_SORT_COLUMNS = {
        "site_id", "region_code", "area_code", "market_code",
        "phase", "status", "progress_pct", "last_refreshed", "display_order"
    }

    def _build_order_by(self, project_id: str, config: Optional[Dict]) -> str:
        """
        Build the ORDER BY clause from project config.

        - site_sort_by: a fixed column or an attributes JSONB key
        - site_sort_order: 'asc' or 'desc' (default 'asc')
        - Always appends site_id as a stable tiebreaker
        """
        sort_by    = (config or {}).get("site_sort_by") or ""
        sort_order = (config or {}).get("site_sort_order") or "asc"
        direction  = "DESC" if str(sort_order).lower() == "desc" else "ASC"

        if not sort_by:
            return "site_id"

        # Sanitize: only allow alphanumeric + underscore
        safe = "".join(c for c in sort_by if c.isalnum() or c == "_")
        if not safe:
            return "site_id"

        if safe in self._FIXED_SORT_COLUMNS:
            return f"{safe} {direction}, site_id"
        else:
            # Treat as an attributes JSONB key
            return f"attributes->>{safe!r} {direction}, site_id"

    _BRACKET_CONDITIONS: Dict[str, str] = {
        "81-100": "progress_pct > 80  AND progress_pct <= 100",
        "61-80":  "progress_pct > 60  AND progress_pct <= 80",
        "41-60":  "progress_pct > 40  AND progress_pct <= 60",
        "21-40":  "progress_pct > 20  AND progress_pct <= 40",
        "1-20":   "progress_pct >= 1  AND progress_pct <= 20",
        "0":      "progress_pct = 0",
        "n/a":    "progress_pct IS NULL",
    }

    async def list_sites(
        self,
        project_id: str,
        region_code: Optional[str] = None,
        area_code: Optional[str] = None,
        market_code: Optional[str] = None,
        phase: Optional[str] = None,
        status: Optional[str] = None,
        progress_bracket: Optional[str] = None,
        search: Optional[str] = None,
        page: int = 1,
        page_size: int = 500,
    ) -> Dict[str, Any]:
        """
        Return a paginated, filtered page of sites for a project.
        Uses COUNT(*) OVER() window function to avoid a separate count query.
        """
        table = settings.TABLES["dim_sites"]

        clauses = ["project_id = :project_id"]
        params: Dict[str, Any] = {"project_id": project_id}

        def _multi(col: str, val: Optional[str], upper: bool = False) -> None:
            if not val:
                return
            values = [v.strip().upper() if upper else v.strip() for v in val.split(",") if v.strip()]
            if not values:
                return
            if len(values) == 1:
                clauses.append(f"{col} = :{col}")
                params[col] = values[0]
            else:
                clauses.append(f"{col} = ANY(:{col})")
                params[col] = values

        _multi("region_code",  region_code,  upper=True)
        _multi("area_code",    area_code,    upper=True)
        _multi("market_code",  market_code,  upper=True)
        _multi("phase",        phase)
        _multi("status",       status)
        if progress_bracket:
            condition = self._BRACKET_CONDITIONS.get(progress_bracket.lower())
            if condition:
                clauses.append(f"({condition})")
        await self._apply_search_clauses(project_id, search, clauses, params)

        where = " AND ".join(clauses)
        params["limit"]  = page_size
        params["offset"] = (page - 1) * page_size

        # Resolve sort column + direction from project config
        config = await self._get_project_config(project_id)
        order_by = self._build_order_by(project_id, config)

        sql = f"""
            SELECT *, COUNT(*) OVER() AS _total_count
            FROM {table}
            WHERE {where}
            ORDER BY {order_by}
            LIMIT :limit OFFSET :offset
        """

        rows = (await self.db.execute(text(sql), params)).fetchall()

        total      = rows[0]._total_count if rows else 0
        last_ref   = rows[0].last_refreshed if rows else None
        data       = [self._row_to_dict(r) for r in rows]
        hidden     = self._extract_hidden_columns(config)

        return {
            "total":          total,
            "page":           page,
            "page_size":      page_size,
            "pages":          math.ceil(total / page_size) if total else 0,
            "project_id":     project_id,
            "last_refreshed": last_ref,
            "hidden_columns": hidden,
            "data":           data,
        }

    @staticmethod
    def _extract_hidden_columns(config: Optional[Dict[str, Any]]) -> List[str]:
        """Return attribute keys whose site_columns entry has `hidden: true`."""
        if not config:
            return []
        raw = config.get("site_columns") or {}
        if isinstance(raw, str):
            try:
                raw = json.loads(raw)
            except (json.JSONDecodeError, TypeError):
                return []
        if not isinstance(raw, dict):
            return []
        return [key for key, meta in raw.items()
                if isinstance(meta, dict) and meta.get("hidden") is True]

    async def get_site(self, project_id: str, site_id: str) -> Optional[Dict[str, Any]]:
        table = settings.TABLES["dim_sites"]
        row = (await self.db.execute(
            text(f"SELECT * FROM {table} WHERE project_id = :pid AND site_id = :sid"),
            {"pid": project_id, "sid": site_id},
        )).fetchone()
        return self._row_to_dict(row) if row else None

    async def get_summary(
        self,
        project_id: str,
        region_code: Optional[str] = None,
        area_code: Optional[str] = None,
        market_code: Optional[str] = None,
        phase: Optional[str] = None,
        status: Optional[str] = None,
        progress_bracket: Optional[str] = None,
        search: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Aggregate stats for dashboard cards: total count, avg progress,
        distribution by phase and by status.
        All filters support comma-separated multi-values.
        """
        table = settings.TABLES["dim_sites"]

        clauses = ["project_id = :project_id"]
        params: Dict[str, Any] = {"project_id": project_id}

        def _multi(col: str, val: Optional[str], upper: bool = False) -> None:
            if not val:
                return
            values = [v.strip().upper() if upper else v.strip() for v in val.split(",") if v.strip()]
            if not values:
                return
            if len(values) == 1:
                clauses.append(f"{col} = :{col}")
                params[col] = values[0]
            else:
                clauses.append(f"{col} = ANY(:{col})")
                params[col] = values

        _multi("region_code",  region_code,  upper=True)
        _multi("area_code",    area_code,    upper=True)
        _multi("market_code",  market_code,  upper=True)
        _multi("phase",        phase)
        _multi("status",       status)
        if progress_bracket:
            condition = self._BRACKET_CONDITIONS.get(progress_bracket.lower())
            if condition:
                clauses.append(f"({condition})")
        await self._apply_search_clauses(project_id, search, clauses, params)

        where = " AND ".join(clauses)

        totals_row = (await self.db.execute(text(f"""
            SELECT
                COUNT(*)                    AS total_sites,
                MAX(last_refreshed)         AS last_refreshed
            FROM {table}
            WHERE {where}
        """), params)).fetchone()

        total = totals_row.total_sites if totals_row else 0

        progress_rows = (await self.db.execute(text(f"""
            SELECT
                CASE
                    WHEN progress_pct > 80  AND progress_pct <= 100 THEN '81-100'
                    WHEN progress_pct > 60  AND progress_pct <= 80  THEN '61-80'
                    WHEN progress_pct > 40  AND progress_pct <= 60  THEN '41-60'
                    WHEN progress_pct > 20  AND progress_pct <= 40  THEN '21-40'
                    WHEN progress_pct >= 1  AND progress_pct <= 20  THEN '1-20'
                    WHEN progress_pct = 0                            THEN '0'
                    ELSE 'N/A'
                END AS bracket,
                COUNT(*) AS cnt
            FROM {table}
            WHERE {where}
            GROUP BY bracket
            ORDER BY MIN(COALESCE(progress_pct, -1)) DESC
        """), params)).fetchall()

        phase_rows = (await self.db.execute(text(f"""
            SELECT phase, COUNT(*) AS cnt
            FROM {table}
            WHERE {where}
            GROUP BY phase
            ORDER BY phase
        """), params)).fetchall()

        status_rows = (await self.db.execute(text(f"""
            SELECT status, COUNT(*) AS cnt
            FROM {table}
            WHERE {where}
            GROUP BY status
            ORDER BY status
        """), params)).fetchall()

        by_progress = {
            r.bracket: {
                "count": r.cnt,
                "pct_of_total": round(r.cnt * 100.0 / total, 1) if total else 0.0,
            }
            for r in progress_rows
        }

        return {
            "project_id":     project_id,
            "total_sites":    total,
            "last_refreshed": totals_row.last_refreshed if totals_row else None,
            "by_progress":    by_progress,
            "by_phase":       {r.phase:  r.cnt for r in phase_rows  if r.phase},
            "by_status":      {r.status: r.cnt for r in status_rows if r.status},
        }

    async def get_filter_options(self, project_id: str) -> Dict[str, Any]:
        """
        Distinct values for each filterable column — used to populate dropdowns.

        Order: every list is sorted by MIN(display_order) of the rows that
        carry each value. Sites without a display_order sort last, with
        an alphabetical tiebreak.
        """
        table = settings.TABLES["dim_sites"]
        params = {"project_id": project_id}

        async def distinct(col: str) -> List[str]:
            rows = (await self.db.execute(text(f"""
                SELECT {col} AS val, MIN(display_order) AS ord
                FROM {table}
                WHERE project_id = :project_id AND {col} IS NOT NULL
                GROUP BY {col}
                ORDER BY ord NULLS LAST, val
            """), params)).fetchall()
            return [r[0] for r in rows]

        # Load column config to know which attribute fields are filterable
        config     = await self._get_project_config(project_id)
        col_config = (config or {}).get("site_columns") or {}
        filterable = [k for k, v in col_config.items() if v.get("filterable")]

        attr_options: Dict[str, List] = {}
        for col in filterable:
            rows = (await self.db.execute(text(f"""
                SELECT attributes->>:col AS val, MIN(display_order) AS ord
                FROM {table}
                WHERE project_id = :project_id
                  AND attributes->>:col IS NOT NULL
                GROUP BY attributes->>:col
                ORDER BY ord NULLS LAST, val
            """), {"project_id": project_id, "col": col})).fetchall()
            attr_options[col] = [r[0] for r in rows]

        # Progress brackets that actually have sites
        bracket_rows = (await self.db.execute(text(f"""
            SELECT bracket, MIN(display_order) AS ord
            FROM (
                SELECT
                    CASE
                        WHEN progress_pct > 80  AND progress_pct <= 100 THEN '81-100'
                        WHEN progress_pct > 60  AND progress_pct <= 80  THEN '61-80'
                        WHEN progress_pct > 40  AND progress_pct <= 60  THEN '41-60'
                        WHEN progress_pct > 20  AND progress_pct <= 40  THEN '21-40'
                        WHEN progress_pct >= 1  AND progress_pct <= 20  THEN '1-20'
                        WHEN progress_pct = 0                            THEN '0'
                        ELSE 'N/A'
                    END AS bracket,
                    display_order
                FROM {table}
                WHERE project_id = :project_id
            ) sub
            GROUP BY bracket
            ORDER BY ord NULLS LAST, bracket
        """), params)).fetchall()
        progress_brackets = [r[0] for r in bracket_rows]

        # Region → Area → Market hierarchy. Rows arrive ordered by display_order,
        # so insertion-order dedup gives each level's order without sorted().
        hierarchy_rows = (await self.db.execute(text(f"""
            SELECT region_code, area_code, market_code, MIN(display_order) AS ord
            FROM {table}
            WHERE project_id = :project_id
              AND region_code IS NOT NULL
            GROUP BY region_code, area_code, market_code
            ORDER BY ord NULLS LAST, region_code, area_code, market_code
        """), params)).fetchall()

        nested: Dict[str, Dict[str, List[str]]] = {}
        for region, area, market, _ord in hierarchy_rows:
            areas = nested.setdefault(region, {})
            if area is None:
                continue
            markets = areas.setdefault(area, [])
            if market is not None and market not in markets:
                markets.append(market)

        geo_hierarchy = [
            {
                "region_code": region,
                "areas": [
                    {"area_code": area, "market_codes": markets}
                    for area, markets in areas.items()
                ],
            }
            for region, areas in nested.items()
        ]

        return {
            "project_id":       project_id,
            "region_codes":     await distinct("region_code"),
            "area_codes":       await distinct("area_code"),
            "market_codes":     await distinct("market_code"),
            "geo_hierarchy":    geo_hierarchy,
            "phases":           await distinct("phase"),
            "statuses":         await distinct("status"),
            "progress_brackets": progress_brackets,
            "attributes":       attr_options,
        }

    # ------------------------------------------------------------------ #
    # Helpers                                                              #
    # ------------------------------------------------------------------ #

    async def _get_project_config(self, project_id: str) -> Optional[Dict[str, Any]]:
        table = settings.TABLES["project_config"]
        row = (await self.db.execute(
            text(f"SELECT * FROM {table} WHERE project_id = :pid"),
            {"pid": project_id},
        )).fetchone()
        return dict(row._mapping) if row else None

    @staticmethod
    def _row_to_dict(row) -> Dict[str, Any]:
        d = dict(row._mapping)
        # Drop the window-function helper column if present
        d.pop("_total_count", None)
        return d

    @staticmethod
    def make_job_id() -> str:
        return f"SITE_REFRESH_{uuid.uuid4().hex[:12].upper()}"
