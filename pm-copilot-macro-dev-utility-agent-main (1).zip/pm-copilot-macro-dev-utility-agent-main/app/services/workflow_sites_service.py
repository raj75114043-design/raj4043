import json
import logging
import re
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.core.exceptions import WorkflowConfigError
from app.services.workflow_client import WorkflowClient
from app.services.workflow_dag import get_main_path_step_ids

logger = logging.getLogger(__name__)

_SAFE_IDENTIFIER_RE = re.compile(r"^[a-zA-Z0-9_ ]+$")


def _sanitize_identifier(name: str) -> str:
    """Validate and normalize a name used in dynamic SQL identifiers."""
    if not _SAFE_IDENTIFIER_RE.match(name):
        raise WorkflowConfigError(
            f"Invalid identifier '{name}': only alphanumeric, underscore, and space allowed."
        )
    return name.strip().lower().replace(" ", "_")


def _escape_literal(value: str) -> str:
    """Escape a string for use as a SQL string literal (single-quote doubling)."""
    return value.replace("'", "''")


class WorkflowSitesService:
    """
    Computes site progress/status/phase from workflow step output tables
    and upserts results into dim_sites.
    """

    def __init__(self, db: AsyncSession):
        self.db = db

    async def refresh_project_sites_from_workflow(self, project_id: str) -> Dict[str, Any]:
        """
        Main entry point.

        1. Load project config  (pipeline name, join key, selected steps, source query)
        2. Verify which step output tables exist in the database
        3. Classify steps as main-path vs branch using DAG analysis
        4. Build a dynamic SQL that computes progress / status / phase per site
        5. Bulk upsert into dim_sites
        """
        config = await self._get_project_config(project_id)
        if not config:
            raise ValueError(f"Project '{project_id}' not found.")

        pipeline_name = config.get("workflow_pipeline_name")
        if not pipeline_name:
            raise WorkflowConfigError(
                f"Project '{project_id}' has no workflow_pipeline_name configured."
            )

        join_key = config.get("workflow_join_key") or "smp_id"
        _sanitize_identifier(join_key)

        raw_steps = config.get("workflow_selected_steps")
        if isinstance(raw_steps, str):
            raw_steps = json.loads(raw_steps)
        selected_steps: List[Dict[str, Any]] = raw_steps or []
        if not selected_steps:
            raise WorkflowConfigError(
                f"Project '{project_id}' has no workflow steps selected."
            )

        source_query = (config.get("site_source_query") or "").strip().rstrip(";")
        if not source_query:
            raise ValueError(
                f"Project '{project_id}' has no site_source_query configured. "
                "It is required as the base site list for workflow refresh."
            )

        # ---------------------------------------------------------- #
        # Probe source query to verify the join key column exists     #
        # ---------------------------------------------------------- #
        probe_sql = f"SELECT * FROM ({source_query}) _probe WHERE false"
        try:
            probe_result = await self.db.execute(text(probe_sql))
            source_cols = set(probe_result.keys())
        except Exception as exc:
            raise ValueError(f"site_source_query failed: {exc}") from exc

        if join_key not in source_cols:
            raise WorkflowConfigError(
                f"Workflow join key '{join_key}' not found in site_source_query output. "
                f"Available columns: {sorted(source_cols)}. "
                f"Your source query must SELECT '{join_key}' so it can be joined "
                f"with workflow step output tables."
            )
        if "site_id" not in source_cols:
            raise ValueError(
                "site_source_query must return a 'site_id' column."
            )

        # Collect project-specific attribute columns (same logic as SitesService).
        # display_order is a top-level column — never duplicate it into attributes JSONB.
        _raw_cols = config.get("site_columns") or {}
        col_config = json.loads(_raw_cols) if isinstance(_raw_cols, str) else _raw_cols
        attr_cols = [c for c in col_config.keys() if c in source_cols and c != "display_order"]

        if attr_cols:
            pairs = ", ".join(f"'{c}', b.{c}" for c in attr_cols)
            attributes_expr = f"jsonb_build_object({pairs})"
        else:
            attributes_expr = "'{}'::jsonb"

        display_order_expr = (
            "b.display_order::INTEGER" if "display_order" in source_cols else "NULL::INTEGER"
        )

        # Sort steps by step_id to ensure consistent ordinal assignment
        selected_steps.sort(key=lambda s: s["step_id"])

        # ---------------------------------------------------------- #
        # Fetch depends_on from Workflow API for DAG analysis         #
        # ---------------------------------------------------------- #
        try:
            client = WorkflowClient()
            pipeline_data = await client.get_pipeline_steps(pipeline_name)
            api_steps = {
                s["step_id"]: s.get("depends_on", [])
                for s in pipeline_data.get("step_results", [])
            }
            for step in selected_steps:
                if "depends_on" not in step or not step["depends_on"]:
                    step["depends_on"] = api_steps.get(step["step_id"], [])
        except Exception as exc:
            logger.warning(
                "Could not fetch depends_on from Workflow API for '%s': %s. "
                "Falling back to all steps as main-path.",
                pipeline_name, exc,
            )

        # ---------------------------------------------------------- #
        # DAG analysis: classify main-path vs branch                  #
        # ---------------------------------------------------------- #
        main_path_ids = get_main_path_step_ids(selected_steps)
        logger.info(
            "DAG analysis for '%s': %d main-path steps, %d branch steps",
            project_id, len(main_path_ids),
            len(selected_steps) - len(main_path_ids),
        )

        # ---------------------------------------------------------- #
        # Resolve table names and verify existence                    #
        # ---------------------------------------------------------- #
        wf_schema = settings.WORKFLOW_SCHEMA
        pipeline_prefix = _sanitize_identifier(pipeline_name)

        step_tables: List[Dict[str, Any]] = []
        expected_names = []
        for step in selected_steps:
            sid = int(step["step_id"])
            table_name = f"{pipeline_prefix}_wf_step_{sid}_output"
            expected_names.append(table_name)
            step_tables.append({
                **step,
                "table_name": table_name,
                "fq_table": f"{wf_schema}.{table_name}",
                "is_main": sid in main_path_ids,
            })

        existing = await self._check_tables_exist(wf_schema, expected_names)

        verified_steps = [s for s in step_tables if s["table_name"] in existing]
        skipped = [s for s in step_tables if s["table_name"] not in existing]
        for s in skipped:
            logger.warning(
                "Workflow step table %s does not exist — skipping step %s",
                s["fq_table"], s["step_id"],
            )
        if not verified_steps:
            raise WorkflowConfigError(
                f"None of the {len(step_tables)} expected workflow step tables exist "
                f"in schema '{wf_schema}'. Cannot compute site progress."
            )

        total_selected = len(selected_steps)

        # ---------------------------------------------------------- #
        # Build dynamic SQL                                           #
        # ---------------------------------------------------------- #
        query = self._build_progress_sql(
            source_query=source_query,
            join_key=join_key,
            verified_steps=verified_steps,
            total_steps=total_selected,
            attributes_expr=attributes_expr,
            display_order_expr=display_order_expr,
        )

        logger.info(
            "Running workflow progress query for project '%s' — "
            "%d steps (%d verified, %d skipped)",
            project_id, len(selected_steps), len(verified_steps), len(skipped),
        )
        logger.debug("Generated SQL:\n%s", query)

        try:
            rows = (await self.db.execute(text(query))).fetchall()
        except Exception as exc:
            raise ValueError(
                f"Workflow progress query failed for project '{project_id}': {exc}"
            ) from exc

        total_fetched = len(rows)
        logger.info("Fetched %d rows from workflow progress query", total_fetched)

        # ---------------------------------------------------------- #
        # Bulk upsert into dim_sites                                  #
        # ---------------------------------------------------------- #
        sites_table = settings.TABLES["dim_sites"]
        now = datetime.utcnow()

        await self.db.execute(
            text(f"DELETE FROM {sites_table} WHERE project_id = :pid"),
            {"pid": project_id},
        )

        batch_size = 5_000
        inserted = 0
        for i in range(0, total_fetched, batch_size):
            batch = rows[i : i + batch_size]
            params = []
            for r in batch:
                rd = dict(r._mapping)
                params.append({
                    "site_id":       str(rd["site_id"]),
                    "project_id":    project_id,
                    "region_code":   rd.get("region_code"),
                    "area_code":     rd.get("area_code"),
                    "market_code":   rd.get("market_code"),
                    "phase":         rd.get("phase"),
                    "progress_pct":  rd.get("progress_pct", 0),
                    "status":        rd.get("status", "Not Started"),
                    "display_order": rd.get("display_order"),
                    "attributes":    json.dumps(rd["attributes"]) if isinstance(rd.get("attributes"), dict) else (rd.get("attributes") or "{}"),
                    "last_refreshed": now,
                })

            await self.db.execute(
                text(f"""
                    INSERT INTO {sites_table} (
                        site_id, project_id,
                        region_code, area_code, market_code,
                        phase, progress_pct, status,
                        display_order, attributes, last_refreshed
                    ) VALUES (
                        :site_id, :project_id,
                        :region_code, :area_code, :market_code,
                        :phase, :progress_pct, :status,
                        :display_order, CAST(:attributes AS jsonb), :last_refreshed
                    )
                    ON CONFLICT (project_id, site_id) DO UPDATE SET
                        region_code    = EXCLUDED.region_code,
                        area_code      = EXCLUDED.area_code,
                        market_code    = EXCLUDED.market_code,
                        phase          = EXCLUDED.phase,
                        progress_pct   = EXCLUDED.progress_pct,
                        status         = EXCLUDED.status,
                        display_order  = EXCLUDED.display_order,
                        attributes     = EXCLUDED.attributes,
                        last_refreshed = EXCLUDED.last_refreshed
                """),
                params,
            )
            inserted += len(batch)

        await self.db.commit()
        logger.info(
            "Workflow site refresh complete for '%s': %d rows inserted "
            "(pipeline=%s, steps=%d/%d verified)",
            project_id, inserted, pipeline_name,
            len(verified_steps), len(selected_steps),
        )

        # Refresh per-project attribute cardinality so auto-grouped search can
        # route terms correctly. Failure here must not break the refresh itself.
        try:
            from app.services.sites_service import SitesService
            await SitesService(self.db).refresh_attribute_cardinality(project_id)
        except Exception as exc:
            logger.warning(
                "Attribute cardinality refresh failed for '%s' (continuing): %s",
                project_id, exc,
            )

        return {
            "project_id":      project_id,
            "pipeline_name":   pipeline_name,
            "rows_fetched":    total_fetched,
            "rows_inserted":   inserted,
            "steps_total":     len(selected_steps),
            "steps_verified":  len(verified_steps),
            "steps_skipped":   len(skipped),
            "refreshed_at":    now.isoformat(),
        }

    # ------------------------------------------------------------------ #
    # SQL Builder                                                          #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _build_progress_sql(
        source_query: str,
        join_key: str,
        verified_steps: List[Dict[str, Any]],
        total_steps: int,
        attributes_expr: str = "'{}'::jsonb",
        display_order_expr: str = "NULL::INTEGER",
    ) -> str:
        """
        Build a dynamic SQL query that computes progress/status/phase
        for each site using main-path vs branch step classification.

        Each UNION ALL branch carries an ``is_main`` flag (TRUE/FALSE).
        - **Status**: derived from the last MAIN-PATH step the site reached.
          Branch failures don't override the main-path status.
        - **Progress**: all passed steps / total steps (unchanged from original).
        """
        union_branches = []
        for ordinal, step in enumerate(verified_steps, start=1):
            fq_table = step["fq_table"]
            step_name = _escape_literal(step.get("step_name", f"Step {step['step_id']}"))
            phase_name = _escape_literal(step.get("phase_name", ""))
            is_main = "TRUE" if step.get("is_main", False) else "FALSE"
            union_branches.append(
                f"SELECT b.site_id, {ordinal} AS step_ordinal, "
                f"'{step_name}' AS step_name, '{phase_name}' AS phase_name, "
                f"COALESCE(LOWER(s.final_status), 'pass') AS final_status, "
                f"{is_main} AS is_main "
                f"FROM base b "
                f"JOIN {fq_table} s ON b.{join_key} = s.{join_key}"
            )

        union_sql = "\nUNION ALL\n".join(union_branches)

        return f"""
WITH base AS (
    SELECT *
    FROM ({source_query}) bq
    WHERE bq.site_id IS NOT NULL
),
step_hits AS (
    {union_sql}
),
-- Progress: count distinct passed steps / total steps
site_passed AS (
    SELECT site_id, COUNT(DISTINCT step_ordinal) AS pass_count
    FROM step_hits
    WHERE final_status != 'fail'
    GROUP BY site_id
),
-- Last MAIN-PATH step per site (used for status)
last_main AS (
    SELECT site_id, MAX(step_ordinal) AS last_main_ordinal
    FROM step_hits
    WHERE is_main
    GROUP BY site_id
),
last_main_detail AS (
    SELECT DISTINCT ON (sh.site_id)
        sh.site_id,
        sh.step_name,
        sh.phase_name,
        sh.final_status,
        sh.step_ordinal
    FROM step_hits sh
    JOIN last_main lm
        ON sh.site_id = lm.site_id
       AND sh.step_ordinal = lm.last_main_ordinal
       AND sh.is_main
),
-- Fallback: last step of any kind (only if no main-path steps)
last_any AS (
    SELECT site_id, MAX(step_ordinal) AS last_ordinal
    FROM step_hits
    GROUP BY site_id
),
last_any_detail AS (
    SELECT DISTINCT ON (sh.site_id)
        sh.site_id,
        sh.step_name,
        sh.phase_name,
        sh.final_status,
        sh.step_ordinal
    FROM step_hits sh
    JOIN last_any la
        ON sh.site_id = la.site_id
       AND sh.step_ordinal = la.last_ordinal
)
SELECT
    b.site_id,
    b.region_code,
    b.area_code,
    b.market_code,
    CASE
        WHEN sp.site_id IS NULL THEN 0
        ELSE ROUND(sp.pass_count::NUMERIC / {total_steps} * 100, 2)
    END AS progress_pct,
    CASE
        WHEN lmd.site_id IS NOT NULL THEN lmd.step_name
        WHEN lad.site_id IS NOT NULL THEN lad.step_name
        ELSE 'Not Started'
    END AS status,
    COALESCE(lmd.phase_name, lad.phase_name) AS phase,
    {display_order_expr} AS display_order,
    {attributes_expr} AS attributes
FROM base b
LEFT JOIN site_passed      sp  ON b.site_id = sp.site_id
LEFT JOIN last_main_detail lmd ON b.site_id = lmd.site_id
LEFT JOIN last_any_detail  lad ON b.site_id = lad.site_id
"""

    # ------------------------------------------------------------------ #
    # Helpers                                                              #
    # ------------------------------------------------------------------ #

    async def _get_project_config(self, project_id: str) -> Optional[Dict[str, Any]]:
        table = settings.TABLES["project_config"]
        row = (await self.db.execute(
            text(f"SELECT * FROM {table} WHERE project_id = :pid"),
            {"pid": project_id},
        )).fetchone()
        return dict(row._mapping) if row else None

    async def _check_tables_exist(
        self, schema: str, table_names: List[str]
    ) -> set:
        """Return the subset of table_names that actually exist in the given schema."""
        if not table_names:
            return set()
        result = await self.db.execute(
            text("""
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = :schema
                  AND table_name = ANY(:names)
            """),
            {"schema": schema, "names": table_names},
        )
        return {r[0] for r in result.fetchall()}
