import json
import logging
import uuid
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from langchain_core.messages import HumanMessage, SystemMessage
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.core.exceptions import SiteInsightsError
from app.core.llm import get_llm
from app.models.insights_models import (
    DataBrowserProcessSnapshot,
    DataBrowserSiteInsightsResponse,
    LLMInsight,
)

logger = logging.getLogger(__name__)


# ------------------------------------------------------------------ #
# LLM System Prompt                                                    #
# ------------------------------------------------------------------ #

_INSIGHTS_SYSTEM_PROMPT = """\
You are a telecom deployment project assistant writing a site status update for a Project Manager.

You will receive a single site's data slices from one or more deployment processes.
- Each process has a `description` written by the PM that explains what the process does.
- Each process has a list of `rows` taken from that process's tracker — each row is one record about this site in that process.
- Use the descriptions to understand what each process represents. Cross-reference fields across processes to build a coherent picture.

Respond in valid JSON with exactly this structure:
{
  "title": "<short status headline, max 10 words, e.g. 'E911 validated, integration pending'>",
  "summary": "<1-2 sentence plain-language status a PM can glance at>",
  "details": [
    "<bullet 1>",
    "<bullet 2>",
    "..."
  ]
}

Rules:
- title: Short, factual headline about where the site stands across all processes. No dramatic words.
- summary: 1-2 sentences. State the overall position and what needs attention, if anything. Keep it calm and factual.
- details: 3-6 bullet points. Include:
  - Per-process status, naming the process and its current state on this site.
  - Any flagged issues, validation reasons, alarms, or held statuses that appear in the rows.
  - Cross-process observations (e.g. "E911 validated on 9/12 but call-test still pending").
  - Recent activity dates if present in the rows.
- Tone: Write like a calm status email between colleagues. Simple, direct, no urgency language, no exclamation marks, no words like "critical", "alarming", "urgent", or "stuck". Just state what is happening.
- Do not invent processes the site is not in.
- Do not invent column values not present in the data.
- Return ONLY the JSON object, no other text."""


class DataBrowserInsightsService:
    """Generates cross-process insights for a single data-browser site."""

    def __init__(self, db: AsyncSession):
        self.db = db

    # ------------------------------------------------------------------ #
    # Public API                                                           #
    # ------------------------------------------------------------------ #

    async def get_insights(
        self, project_id: str, site_id: str, refresh: bool = False
    ) -> DataBrowserSiteInsightsResponse:
        """Read-through cached, LLM-backed insight for one site across all processes."""
        if settings.INSIGHTS_CACHE_ENABLED and not refresh:
            cached = await self._read_cache(project_id, site_id)
            if cached is not None:
                return cached

        config = await self._get_project_config(project_id)
        if not config:
            raise SiteInsightsError(f"Project '{project_id}' not found.")

        table_configs = self._extract_table_configs(config)
        if not table_configs:
            raise SiteInsightsError(
                f"Project '{project_id}' has no data_browser_tables with site_id_column configured."
            )

        site_meta = await self._get_site_meta(project_id, site_id)
        processes = await self._get_process_snapshots(
            project_id, site_id, table_configs
        )

        if not processes:
            raise SiteInsightsError(
                f"Site '{site_id}' has no rows in any indexed data browser table."
            )

        insight = await self._generate_insight(
            project_id, site_id, site_meta, processes
        )

        response = DataBrowserSiteInsightsResponse(
            project_id=project_id,
            site_id=site_id,
            insight_id=str(uuid.uuid4()),
            region_code=site_meta.get("region_code"),
            market_code=site_meta.get("market_code"),
            processes=processes,
            insight=insight,
            generated_at=datetime.utcnow(),
            cached=False,
            cache_age_seconds=0,
        )

        if settings.INSIGHTS_CACHE_ENABLED:
            await self._write_cache(project_id, site_id, response)

        return response

    # ------------------------------------------------------------------ #
    # Cache                                                                #
    # ------------------------------------------------------------------ #

    async def _read_cache(
        self, project_id: str, site_id: str
    ) -> Optional[DataBrowserSiteInsightsResponse]:
        table = settings.TABLES["data_browser_insights_cache"]
        try:
            row = (await self.db.execute(
                text(f"""
                    SELECT payload, generated_at
                    FROM {table}
                    WHERE project_id = :project_id AND site_id = :site_id
                """),
                {"project_id": project_id, "site_id": site_id},
            )).fetchone()
        except Exception as exc:
            logger.warning(
                "Data-browser insights cache read failed for %s/%s: %s",
                project_id, site_id, exc,
            )
            return None

        if not row:
            return None

        generated_at: datetime = row._mapping["generated_at"]
        age = datetime.utcnow() - generated_at
        ttl = timedelta(hours=settings.INSIGHTS_CACHE_TTL_HOURS)
        if age > ttl:
            return None

        payload = row._mapping["payload"]
        if isinstance(payload, str):
            payload = json.loads(payload)

        payload["cached"] = True
        payload["cache_age_seconds"] = int(age.total_seconds())
        payload["generated_at"] = generated_at.isoformat()

        # Lazy-mint insight_id for legacy rows that predate migration 020.
        if not payload.get("insight_id"):
            new_id = str(uuid.uuid4())
            payload["insight_id"] = new_id
            try:
                await self.db.execute(
                    text(f"""
                        UPDATE {table}
                        SET insight_id = CAST(:insight_id AS uuid),
                            payload    = CAST(:payload AS jsonb)
                        WHERE project_id = :project_id AND site_id = :site_id
                          AND insight_id IS NULL
                    """),
                    {
                        "insight_id": new_id,
                        "payload": json.dumps(
                            {k: v for k, v in payload.items() if k not in ("cached", "cache_age_seconds")},
                            default=str,
                        ),
                        "project_id": project_id,
                        "site_id": site_id,
                    },
                )
                await self.db.commit()
            except Exception as exc:
                logger.warning(
                    "Data-browser insights cache lazy-mint failed for %s/%s: %s",
                    project_id, site_id, exc,
                )
                await self.db.rollback()

        try:
            return DataBrowserSiteInsightsResponse.model_validate(payload)
        except Exception as exc:
            logger.warning(
                "Data-browser insights cache payload invalid for %s/%s — ignoring: %s",
                project_id, site_id, exc,
            )
            return None

    async def _write_cache(
        self,
        project_id: str,
        site_id: str,
        response: DataBrowserSiteInsightsResponse,
    ) -> None:
        table = settings.TABLES["data_browser_insights_cache"]
        payload = response.model_dump(
            exclude={"cached", "cache_age_seconds"}, mode="json"
        )
        try:
            await self.db.execute(
                text(f"""
                    INSERT INTO {table} (project_id, site_id, payload, generated_at, insight_id)
                    VALUES (:project_id, :site_id, CAST(:payload AS jsonb), :generated_at, CAST(:insight_id AS uuid))
                    ON CONFLICT (project_id, site_id) DO UPDATE SET
                        payload      = EXCLUDED.payload,
                        generated_at = EXCLUDED.generated_at,
                        insight_id   = EXCLUDED.insight_id
                """),
                {
                    "project_id": project_id,
                    "site_id": site_id,
                    "payload": json.dumps(payload, default=str),
                    "generated_at": response.generated_at,
                    "insight_id": response.insight_id,
                },
            )
            await self.db.commit()
        except Exception as exc:
            logger.warning(
                "Data-browser insights cache write failed for %s/%s: %s",
                project_id, site_id, exc,
            )
            await self.db.rollback()

    # ------------------------------------------------------------------ #
    # Project config / data fetch                                          #
    # ------------------------------------------------------------------ #

    async def _get_project_config(self, project_id: str) -> Optional[Dict[str, Any]]:
        table = settings.TABLES["project_config"]
        row = (await self.db.execute(
            text(f"SELECT * FROM {table} WHERE project_id = :pid"),
            {"pid": project_id},
        )).fetchone()
        return dict(row._mapping) if row else None

    @staticmethod
    def _extract_table_configs(config: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Return data_browser_tables entries that have a site_id_column set."""
        raw = config.get("data_browser_tables")
        if isinstance(raw, str):
            try:
                raw = json.loads(raw)
            except (json.JSONDecodeError, TypeError):
                raw = None
        return [
            t for t in (raw or [])
            if t.get("table_alias") and t.get("site_id_column")
        ]

    async def _get_site_meta(
        self, project_id: str, site_id: str
    ) -> Dict[str, Any]:
        """Fetch region/market for the site from the unified site index."""
        sites_table = settings.TABLES["data_browser_sites"]
        row = (await self.db.execute(
            text(f"""
                SELECT region_code, market_code, presence
                FROM {sites_table}
                WHERE project_id = :pid AND site_id = :sid
            """),
            {"pid": project_id, "sid": site_id},
        )).fetchone()
        if not row:
            return {}
        presence = row._mapping["presence"]
        if isinstance(presence, str):
            presence = json.loads(presence)
        return {
            "region_code": row._mapping["region_code"],
            "market_code": row._mapping["market_code"],
            "presence": presence or {},
        }

    async def _get_process_snapshots(
        self,
        project_id: str,
        site_id: str,
        table_configs: List[Dict[str, Any]],
    ) -> List[DataBrowserProcessSnapshot]:
        """Fetch this site's rows from each indexed table, capped per token budget."""
        browser_table = settings.TABLES["data_browser"]
        cap = settings.DATA_BROWSER_INSIGHTS_MAX_ROWS_PER_TABLE

        snapshots: List[DataBrowserProcessSnapshot] = []
        for tbl in table_configs:
            alias = tbl["table_alias"]
            label = tbl.get("label") or alias
            description = tbl.get("description") or None

            rows = (await self.db.execute(
                text(f"""
                    SELECT row_data, COUNT(*) OVER() AS _total_count
                    FROM {browser_table}
                    WHERE project_id = :pid
                      AND site_id = :sid
                      AND table_alias = :alias
                    ORDER BY display_order
                    LIMIT :cap
                """),
                {"pid": project_id, "sid": site_id, "alias": alias, "cap": cap},
            )).fetchall()

            if not rows:
                continue

            total = rows[0]._total_count
            row_data: List[Dict[str, Any]] = []
            for r in rows:
                rd = r.row_data if isinstance(r.row_data, dict) else json.loads(r.row_data)
                row_data.append(rd)

            snapshots.append(DataBrowserProcessSnapshot(
                table_alias=alias,
                label=label,
                description=description,
                row_count=int(total),
                rows=row_data,
            ))

        return snapshots

    # ------------------------------------------------------------------ #
    # LLM                                                                  #
    # ------------------------------------------------------------------ #

    async def _generate_insight(
        self,
        project_id: str,
        site_id: str,
        site_meta: Dict[str, Any],
        processes: List[DataBrowserProcessSnapshot],
    ) -> LLMInsight:
        """Build the LLM prompt and parse its JSON response."""
        user_payload = {
            "site_id": site_id,
            "project_id": project_id,
            "region_code": site_meta.get("region_code"),
            "market_code": site_meta.get("market_code"),
            "processes": [
                {
                    "process_name": p.label or p.table_alias,
                    "description": p.description,
                    "row_count": p.row_count,
                    "rows": p.rows,
                }
                for p in processes
            ],
        }
        user_content = json.dumps(user_payload, indent=2, default=str)

        try:
            llm = get_llm()
            response = await llm.ainvoke([
                SystemMessage(content=_INSIGHTS_SYSTEM_PROMPT),
                HumanMessage(content=user_content),
            ])
            return self._parse_llm_response(response.content.strip())
        except Exception as exc:
            logger.error(
                "LLM data-browser insight generation failed for %s/%s: %s",
                project_id, site_id, exc,
            )
            return self._fallback_insight(site_id, processes)

    @staticmethod
    def _parse_llm_response(raw: str) -> LLMInsight:
        cleaned = raw.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("\n", 1)[-1]
            if cleaned.endswith("```"):
                cleaned = cleaned[:-3].strip()
        try:
            data = json.loads(cleaned)
            return LLMInsight(
                title=data.get("title", ""),
                summary=data.get("summary", ""),
                details=data.get("details", []),
            )
        except (json.JSONDecodeError, TypeError):
            logger.warning(
                "LLM returned non-JSON for data-browser insight; using as plain summary"
            )
            return LLMInsight(title="Site Status", summary=raw, details=[])

    @staticmethod
    def _fallback_insight(
        site_id: str, processes: List[DataBrowserProcessSnapshot]
    ) -> LLMInsight:
        if not processes:
            return LLMInsight(
                title="No process data",
                summary=f"Site {site_id}: no rows across configured processes.",
                details=[],
            )
        details = [
            f"{p.label or p.table_alias}: {p.row_count} record(s)"
            for p in processes
        ]
        return LLMInsight(
            title=f"Site {site_id} — {len(processes)} process(es)",
            summary=(
                f"Site {site_id} appears in {len(processes)} process(es). "
                "LLM gateway unavailable; counts shown."
            ),
            details=details,
        )
