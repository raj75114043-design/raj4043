-- ============================================================
-- Migration 010: unified site index for data browser
-- ============================================================
-- Adds:
--   1. dim_data_browser.site_id — extracted from a per-table
--      configured column at refresh time. Enables fast point
--      lookups for "all rows for site X in table Y".
--   2. dim_data_browser_sites — materialized list of unique
--      sites per project with per-table presence counts.
--      Rebuilt at the end of every refresh.
--
-- Existing rows will have site_id = NULL until the next refresh
-- runs. Re-run /api/v1/data-browser/{project_id}/refresh after
-- applying this migration.
-- ============================================================

BEGIN;

ALTER TABLE pwc_derived_tables_schema.dim_data_browser
    ADD COLUMN IF NOT EXISTS site_id VARCHAR(100);

CREATE INDEX IF NOT EXISTS idx_dim_data_browser_site
    ON pwc_derived_tables_schema.dim_data_browser
       (project_id, site_id, table_alias);

CREATE TABLE IF NOT EXISTS pwc_derived_tables_schema.dim_data_browser_sites (
    project_id      VARCHAR(50)     NOT NULL,
    site_id         VARCHAR(100)    NOT NULL,
    presence        JSONB           NOT NULL,
    last_refreshed  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (project_id, site_id)
);

CREATE INDEX IF NOT EXISTS idx_dim_data_browser_sites_site_id
    ON pwc_derived_tables_schema.dim_data_browser_sites (project_id, site_id);

COMMENT ON TABLE pwc_derived_tables_schema.dim_data_browser_sites IS
    'Materialized unique-sites index across all data browser tables. '
    'presence is a JSON object {table_alias: row_count}. Rebuilt at '
    'the end of every refresh_project_tables run.';

COMMIT;
