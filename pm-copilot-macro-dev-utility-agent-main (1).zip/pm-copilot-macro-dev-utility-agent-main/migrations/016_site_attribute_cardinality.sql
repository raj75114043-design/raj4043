-- Migration 016: Per-project attribute cardinality table + GIN index on attributes.
-- Powers the auto-grouped multi-term search on /api/v1/sites/{project_id}: each
-- search term is routed to the most-specific attribute (lowest distinct_count),
-- terms hitting the same attribute OR together, different attributes AND.

-- ------------------------------------------------------------------ --
-- 1. Cardinality table — one row per (project, attribute_key)         --
-- ------------------------------------------------------------------ --
CREATE TABLE IF NOT EXISTS pwc_derived_tables_schema.dim_site_attribute_cardinality (
    project_id      TEXT      NOT NULL,
    attribute_key   TEXT      NOT NULL,
    is_fixed_column BOOLEAN   NOT NULL,           -- TRUE for site_id/region_code/..., FALSE for keys inside attributes JSONB
    distinct_count  INTEGER   NOT NULL,
    refreshed_at    TIMESTAMP NOT NULL DEFAULT NOW(),
    PRIMARY KEY (project_id, attribute_key)
);

CREATE INDEX IF NOT EXISTS idx_site_attr_cardinality_project
    ON pwc_derived_tables_schema.dim_site_attribute_cardinality (project_id, distinct_count);

COMMENT ON TABLE pwc_derived_tables_schema.dim_site_attribute_cardinality
    IS 'Distinct-value count per searchable attribute, per project. Refreshed at the end of each project site refresh job. Used to auto-group multi-term search.';

-- ------------------------------------------------------------------ --
-- 2. GIN index on dim_sites.attributes — speeds up attribute lookups  --
-- ------------------------------------------------------------------ --
-- jsonb_path_ops is smaller and faster for our containment / each_text scans
-- than the default jsonb_ops. Both work; jsonb_path_ops chosen for size.
CREATE INDEX IF NOT EXISTS idx_dim_sites_attributes_gin
    ON pwc_derived_tables_schema.dim_sites
    USING GIN (attributes jsonb_path_ops);

COMMENT ON INDEX pwc_derived_tables_schema.idx_dim_sites_attributes_gin
    IS 'GIN index on the attributes JSONB. Accelerates whole-value lookups against attribute values during site search.';
