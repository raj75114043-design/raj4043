-- Migration 017: Widen dim_sites.status and dim_sites.phase to fit workflow step / phase names.
-- In workflow-mode projects these columns hold step names like 'RAN Entitlement Complete'
-- which can exceed the original 50/100 char limits. 200 matches workflow_pipeline_name.

ALTER TABLE pwc_derived_tables_schema.dim_sites
    ALTER COLUMN status TYPE VARCHAR(200),
    ALTER COLUMN phase  TYPE VARCHAR(200);
