-- ============================================================
-- Migration 012: cache for data-browser site insights
-- ============================================================
-- Caches the last LLM-generated insight for each (project_id, site_id)
-- pair, where site_id is the unified site key from the data browser.
-- Freshness is controlled by INSIGHTS_CACHE_TTL_HOURS at the application
-- layer (same TTL knob as site_insights_cache); rows older than TTL are
-- regenerated on demand.
-- ============================================================

BEGIN;

CREATE TABLE IF NOT EXISTS pwc_derived_tables_schema.dim_data_browser_insights_cache (
    project_id      VARCHAR(50)     NOT NULL,
    site_id         VARCHAR(100)    NOT NULL,
    payload         JSONB           NOT NULL,
    generated_at    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (project_id, site_id)
);

CREATE INDEX IF NOT EXISTS idx_dim_data_browser_insights_cache_generated_at
    ON pwc_derived_tables_schema.dim_data_browser_insights_cache (generated_at);

COMMIT;
