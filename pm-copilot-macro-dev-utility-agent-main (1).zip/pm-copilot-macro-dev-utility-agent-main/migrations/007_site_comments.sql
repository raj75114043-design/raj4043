-- ============================================================
-- Migration 007: site_comments table
-- ============================================================
-- Stores user comments on individual sites within a project.
-- Multiple users can comment on the same site.
-- ============================================================

BEGIN;

CREATE TABLE IF NOT EXISTS pwc_derived_tables_schema.site_comments (
    comment_id      BIGSERIAL       PRIMARY KEY,
    project_id      VARCHAR(50)     NOT NULL,
    site_id         VARCHAR(100)    NOT NULL,
    user_id         VARCHAR(200)    NOT NULL,
    user_name       VARCHAR(200),
    comment_text    TEXT            NOT NULL,
    created_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_site_comments_site
        FOREIGN KEY (project_id, site_id)
        REFERENCES pwc_derived_tables_schema.dim_sites(project_id, site_id)
        ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_site_comments_project_site
    ON pwc_derived_tables_schema.site_comments (project_id, site_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_site_comments_project_user
    ON pwc_derived_tables_schema.site_comments (project_id, user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_site_comments_site_user
    ON pwc_derived_tables_schema.site_comments (project_id, site_id, user_id, created_at DESC);

COMMENT ON TABLE pwc_derived_tables_schema.site_comments IS
    'User comments on sites. Multiple users can comment on the same site; a user can post multiple comments.';

COMMIT;
