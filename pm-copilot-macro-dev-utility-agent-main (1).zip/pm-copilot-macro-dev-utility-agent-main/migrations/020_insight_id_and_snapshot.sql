-- Migration 020: Stable per-generation insight_id + snapshot column on feedback.
--
-- Problem: today feedback rows reference a generation by ISO timestamp, which
-- can collide and which doesn't survive the next regenerate. There is also no
-- record of WHAT the user actually rated — the cache rolls over and the original
-- insight content is lost.
--
-- This migration introduces:
--   1. insight_id (UUID) on the two insight caches and on site_insights_jobs.
--      Minted by the service on cache miss and persisted; cache hits return
--      the original id so feedback aggregates correctly.
--   2. insight_snapshot (JSONB) on insight_feedback. At submit time the service
--      looks the cache row up by insight_id and snapshots {title, summary,
--      details, recommendations} into the feedback row. If the cache row has
--      already rolled, the snapshot is NULL (honestly absent rather than wrong).
--
-- Backfill strategy: NULL is allowed everywhere. Existing cached rows will
-- self-heal on next regenerate (the service will mint an id and write it back).
-- Existing feedback rows stay snapshot-less.

ALTER TABLE pwc_derived_tables_schema.site_insights_cache
    ADD COLUMN IF NOT EXISTS insight_id UUID;

ALTER TABLE pwc_derived_tables_schema.site_insights_jobs
    ADD COLUMN IF NOT EXISTS insight_id UUID;

ALTER TABLE pwc_derived_tables_schema.dim_data_browser_insights_cache
    ADD COLUMN IF NOT EXISTS insight_id UUID;

ALTER TABLE pwc_derived_tables_schema.insight_feedback
    ADD COLUMN IF NOT EXISTS insight_snapshot JSONB;

CREATE INDEX IF NOT EXISTS idx_site_insights_cache_insight_id
    ON pwc_derived_tables_schema.site_insights_cache (insight_id);

CREATE INDEX IF NOT EXISTS idx_data_browser_insights_cache_insight_id
    ON pwc_derived_tables_schema.dim_data_browser_insights_cache (insight_id);

COMMENT ON COLUMN pwc_derived_tables_schema.site_insights_cache.insight_id
    IS 'UUID minted when this insight was generated. Stable across cache hits — feedback rows reference this id, not generated_at.';
COMMENT ON COLUMN pwc_derived_tables_schema.dim_data_browser_insights_cache.insight_id
    IS 'UUID minted when this insight was generated. Stable across cache hits — feedback rows reference this id.';
COMMENT ON COLUMN pwc_derived_tables_schema.site_insights_jobs.insight_id
    IS 'Set when the job''s insight is produced. Same value as the cached payload''s insight_id. Lets you join jobs to insights and to feedback.';
COMMENT ON COLUMN pwc_derived_tables_schema.insight_feedback.insight_snapshot
    IS 'JSONB snapshot of {title, summary, details, recommendations} taken at feedback submit time, looked up from the cache by insight_id. NULL when the cache row had already rolled.';
