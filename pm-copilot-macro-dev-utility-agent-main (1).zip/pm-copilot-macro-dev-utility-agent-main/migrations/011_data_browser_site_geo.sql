-- ============================================================
-- Migration 011: region/market on the unified site index
-- ============================================================
-- Adds region_code and market_code to:
--   1. dim_data_browser — extracted from per-table configured
--      columns (region_column, market_column) at refresh time.
--   2. dim_data_browser_sites — denormalized per site for the
--      unified-sites endpoint. Conflict resolution is by table
--      priority order from data_browser_tables config (first
--      table with a non-null value wins).
--
-- Re-run /api/v1/data-browser/{project_id}/refresh after applying.
-- ============================================================

BEGIN;

ALTER TABLE pwc_derived_tables_schema.dim_data_browser
    ADD COLUMN IF NOT EXISTS region_code VARCHAR(50),
    ADD COLUMN IF NOT EXISTS market_code VARCHAR(50);

ALTER TABLE pwc_derived_tables_schema.dim_data_browser_sites
    ADD COLUMN IF NOT EXISTS region_code VARCHAR(50),
    ADD COLUMN IF NOT EXISTS market_code VARCHAR(50);

CREATE INDEX IF NOT EXISTS idx_dim_data_browser_sites_region
    ON pwc_derived_tables_schema.dim_data_browser_sites (project_id, region_code);

CREATE INDEX IF NOT EXISTS idx_dim_data_browser_sites_market
    ON pwc_derived_tables_schema.dim_data_browser_sites (project_id, market_code);

COMMIT;
