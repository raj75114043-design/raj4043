-- ============================================================
-- Migration 008: site_insights_cache table
-- ============================================================
-- Caches the last LLM-generated insight for each (project_id, smp_id)
-- pair. Freshness is controlled by INSIGHTS_CACHE_TTL_HOURS at the
-- application layer; rows older than TTL are regenerated on demand.
-- ============================================================

BEGIN;

CREATE TABLE IF NOT EXISTS pwc_derived_tables_schema.site_insights_cache (
    project_id      VARCHAR(50)     NOT NULL,
    smp_id          VARCHAR(100)    NOT NULL,
    payload         JSONB           NOT NULL,
    generated_at    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (project_id, smp_id)
);

CREATE INDEX IF NOT EXISTS idx_site_insights_cache_generated_at
    ON pwc_derived_tables_schema.site_insights_cache (generated_at);

COMMENT ON TABLE pwc_derived_tables_schema.site_insights_cache IS
    'Cached LLM-generated site insights. One row per (project_id, smp_id). '
    'Application-level TTL: see settings.INSIGHTS_CACHE_TTL_HOURS.';

COMMIT;
