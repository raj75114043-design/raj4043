-- Migration 019: Per-generation thumbs-up/down + optional comment for LLM insights.
-- Covers both surfaces:
--   surface = 'site'           → /api/v1/insights/site/{project_id}/{smp_id}
--   surface = 'data_browser'   → /api/v1/data-browser/{project_id}/sites/{site_id}/insights
--
-- generation_id is the identifier of the specific insight output the feedback
-- references — site_insights_cache.generated_at (as ISO) or a hash of the
-- result, supplied by the caller. Per-generation feedback so regeneration
-- doesn't silently invalidate prior thumbs.

CREATE TABLE IF NOT EXISTS pwc_derived_tables_schema.insight_feedback (
    feedback_id     UUID         PRIMARY KEY,
    surface         TEXT         NOT NULL,
    project_id      TEXT         NOT NULL,
    site_key        TEXT         NOT NULL,    -- smp_id for 'site', site_id for 'data_browser'
    source          TEXT,                     -- 'workflow' | 'kg' for site surface; NULL for data_browser
    generation_id   TEXT         NOT NULL,    -- identifies the specific insight output the user is rating
    user_id         TEXT         NOT NULL,    -- opaque, supplied by the UI (email or any user identifier)
    rating          TEXT         NOT NULL,
    comment         TEXT,
    created_at      TIMESTAMP    NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP    NOT NULL DEFAULT NOW(),
    UNIQUE (surface, project_id, site_key, generation_id, user_id)
);

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'chk_insight_feedback_surface'
    ) THEN
        ALTER TABLE pwc_derived_tables_schema.insight_feedback
            ADD CONSTRAINT chk_insight_feedback_surface
            CHECK (surface IN ('site', 'data_browser'));
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'chk_insight_feedback_rating'
    ) THEN
        ALTER TABLE pwc_derived_tables_schema.insight_feedback
            ADD CONSTRAINT chk_insight_feedback_rating
            CHECK (rating IN ('up', 'down'));
    END IF;
END$$;

CREATE INDEX IF NOT EXISTS idx_insight_feedback_lookup
    ON pwc_derived_tables_schema.insight_feedback
       (surface, project_id, site_key, generation_id);

CREATE INDEX IF NOT EXISTS idx_insight_feedback_user
    ON pwc_derived_tables_schema.insight_feedback (user_id, created_at DESC);

COMMENT ON TABLE pwc_derived_tables_schema.insight_feedback
    IS 'Thumbs up/down + optional comment per LLM-generated insight, per user, per generation. Used to score prompt quality and surface high/low value insights over time.';
COMMENT ON COLUMN pwc_derived_tables_schema.insight_feedback.generation_id
    IS 'Identifier of the specific insight output (e.g. ISO generated_at from the response). Feedback is tied to this version so regeneration doesn''t silently invalidate prior thumbs.';