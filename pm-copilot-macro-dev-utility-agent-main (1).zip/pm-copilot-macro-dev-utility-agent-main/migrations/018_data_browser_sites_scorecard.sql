-- Migration 018: Per-site, per-table derived fields on dim_data_browser_sites.
-- Generalizes the "scorecard" idea: each project's data_browser_tables entry can
-- declare a `derived_fields` map of {name: sql_expression}. At refresh time we
-- evaluate every expression against an aggregated view of the site's rows in
-- that table and store the resulting values verbatim. The unified-sites
-- endpoint exposes them as:
--   derived: { <table_alias>: { <field_name>: <value>, ... }, ... }
-- 'scorecard' is just one possible field name a PM might choose.

ALTER TABLE pwc_derived_tables_schema.dim_data_browser_sites
    ADD COLUMN IF NOT EXISTS derived JSONB NOT NULL DEFAULT '{}'::jsonb;

COMMENT ON COLUMN pwc_derived_tables_schema.dim_data_browser_sites.derived
    IS 'JSONB keyed by table_alias, each value an object of {field_name: value} produced by the table''s derived_fields config. Free-form: numbers, strings, dates, nulls, all allowed. Missing table_alias key = site has no rows in that table.';