-- Migration 021: Materialize presence_count on dim_data_browser_sites.
-- The unique-site list sorts by "breadth of presence" (sites appearing in
-- the most tables first). Computing it inline from the JSONB on every read
-- forces Postgres to evaluate jsonb_each(presence) for every filtered row
-- before LIMIT/OFFSET. Materializing it as a column keeps the sort cheap
-- and makes pagination O(1) per page regardless of dataset size.

BEGIN;

ALTER TABLE pwc_derived_tables_schema.dim_data_browser_sites
    ADD COLUMN IF NOT EXISTS presence_count INT NOT NULL DEFAULT 0;

-- Backfill from existing presence JSONB. Counts table aliases with cnt > 0.
UPDATE pwc_derived_tables_schema.dim_data_browser_sites
SET presence_count = (
    SELECT COUNT(*)
    FROM jsonb_each(presence)
    WHERE (value)::int > 0
);

CREATE INDEX IF NOT EXISTS idx_dim_data_browser_sites_presence_count
    ON pwc_derived_tables_schema.dim_data_browser_sites
       (project_id, presence_count DESC, site_id);

COMMIT;
