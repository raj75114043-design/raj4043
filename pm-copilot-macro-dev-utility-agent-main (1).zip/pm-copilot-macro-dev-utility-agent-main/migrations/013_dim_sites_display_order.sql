-- ============================================================
-- Migration 013: dim_sites.display_order top-level column
-- ============================================================
-- Promotes display_order from the attributes JSONB to a real
-- column. Drives filter-options ordering with a single
-- per-project sort key that stays indexable.
--
-- Existing rows get NULL until the next refresh runs.
-- Re-run /api/v1/sites/{project_id}/refresh after applying.
-- ============================================================

BEGIN;

ALTER TABLE pwc_derived_tables_schema.dim_sites
    ADD COLUMN IF NOT EXISTS display_order INTEGER;

CREATE INDEX IF NOT EXISTS idx_dim_sites_project_display_order
    ON pwc_derived_tables_schema.dim_sites (project_id, display_order);

COMMENT ON COLUMN pwc_derived_tables_schema.dim_sites.display_order IS
    'Project-defined sort key for filter-options dropdowns. NULL sorts '
    'last. Populated from the site_source_query column of the same name '
    'when present, otherwise NULL.';

COMMIT;
