-- Migration 015: Background-job table for /api/v1/insights/site/* polling pattern.
-- The insights endpoint can take ~30s (KG fetch + LLM call); the UI starts a job,
-- polls for stage updates, and renders partial results as they become available.

CREATE TABLE IF NOT EXISTS pwc_derived_tables_schema.site_insights_jobs (
    job_id            UUID         PRIMARY KEY,
    project_id        TEXT         NOT NULL,
    smp_id            TEXT         NOT NULL,
    source            TEXT         NOT NULL,
    status            TEXT         NOT NULL DEFAULT 'pending',
    stage             TEXT,
    progress_pct      INTEGER      NOT NULL DEFAULT 0,
    stages_completed  JSONB        NOT NULL DEFAULT '[]'::jsonb,
    partial           JSONB,
    result            JSONB,
    error             TEXT,
    refresh_requested BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at        TIMESTAMP    NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMP    NOT NULL DEFAULT NOW()
);

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'chk_insights_jobs_status'
    ) THEN
        ALTER TABLE pwc_derived_tables_schema.site_insights_jobs
            ADD CONSTRAINT chk_insights_jobs_status
            CHECK (status IN ('pending', 'running', 'done', 'failed'));
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'chk_insights_jobs_source'
    ) THEN
        ALTER TABLE pwc_derived_tables_schema.site_insights_jobs
            ADD CONSTRAINT chk_insights_jobs_source
            CHECK (source IN ('workflow', 'kg'));
    END IF;
END$$;

CREATE INDEX IF NOT EXISTS idx_insights_jobs_lookup
    ON pwc_derived_tables_schema.site_insights_jobs (project_id, smp_id, status, created_at DESC);

COMMENT ON TABLE pwc_derived_tables_schema.site_insights_jobs
    IS 'In-flight and recently-completed background jobs for the site insights polling API.';
COMMENT ON COLUMN pwc_derived_tables_schema.site_insights_jobs.stage
    IS 'Current pipeline stage: fetching_kg, reading_pm_comments, generating_insight, etc.';
COMMENT ON COLUMN pwc_derived_tables_schema.site_insights_jobs.partial
    IS 'Early data the UI can render before the LLM finishes (kg_snapshot, pm_comments).';
COMMENT ON COLUMN pwc_derived_tables_schema.site_insights_jobs.stages_completed
    IS 'Append-only history of completed stages: [{"stage": "...", "at": "...", "progress_pct": N}, ...].';
