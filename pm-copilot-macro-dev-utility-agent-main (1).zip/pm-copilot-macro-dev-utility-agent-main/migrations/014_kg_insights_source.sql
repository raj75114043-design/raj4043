-- Migration 014: Add Knowledge Graph (KG) insights source columns to dim_project_config
-- Lets each project choose between 'workflow' (existing) or 'kg' (new) as the source
-- for site-level insights. Defaults preserve current behavior for existing projects.

ALTER TABLE pwc_derived_tables_schema.dim_project_config
    ADD COLUMN IF NOT EXISTS insights_source   VARCHAR(20)  NOT NULL DEFAULT 'workflow',
    ADD COLUMN IF NOT EXISTS kg_url_template   TEXT         DEFAULT NULL;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'chk_project_config_insights_source'
    ) THEN
        ALTER TABLE pwc_derived_tables_schema.dim_project_config
            ADD CONSTRAINT chk_project_config_insights_source
            CHECK (insights_source IN ('workflow', 'kg'));
    END IF;
END$$;

COMMENT ON COLUMN pwc_derived_tables_schema.dim_project_config.insights_source
    IS 'Which source feeds site insights: ''workflow'' (default) or ''kg''.';
COMMENT ON COLUMN pwc_derived_tables_schema.dim_project_config.kg_url_template
    IS 'Full KG status URL with {site_id} placeholder, e.g. https://host/api/v1/status/ahloa/site/{site_id}. The {site_id} placeholder is replaced verbatim with the site id supplied by the caller. Required when insights_source = ''kg''.';
