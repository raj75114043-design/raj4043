-- ============================================================
-- Migration 009: dim_data_browser_meta table
-- ============================================================
-- Stores per-(project_id, table_alias) metadata for the data
-- browser. Currently captures the column order from the source
-- query at refresh time so browse responses preserve the SELECT
-- list order (JSONB key order is non-deterministic).
-- ============================================================

BEGIN;

CREATE TABLE IF NOT EXISTS pwc_derived_tables_schema.dim_data_browser_meta (
    project_id      VARCHAR(50)     NOT NULL,
    table_alias     VARCHAR(100)    NOT NULL,
    columns         JSONB           NOT NULL,
    last_refreshed  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (project_id, table_alias)
);

COMMENT ON TABLE pwc_derived_tables_schema.dim_data_browser_meta IS
    'Per-table metadata for the data browser. columns is an ordered '
    'JSON array of column names captured from the source_query SELECT '
    'list at refresh time.';

COMMIT;
