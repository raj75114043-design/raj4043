import asyncio
from datetime import datetime, timedelta
from app.utils.timezone import INDIA_TIME_ZONE
from app.services.update_staging_table import updated_staging_tables_cron

TARGET_TIMES = ["09:00", "21:00"]  # dynamic list

def parse_time_str(time_str: str):
    hour, minute = map(int, time_str.split(":"))
    return hour, minute

def get_next_run_time():

    DATE_TIME_WITHOUT_ZONE = datetime.now(INDIA_TIME_ZONE).replace(tzinfo=None)
    # now = datetime.now(INDIA_TIME_ZONE)

    today_runs = []
    
    for t in TARGET_TIMES:
        hour, minute = parse_time_str(t)

        run_time = DATE_TIME_WITHOUT_ZONE.replace(
            hour=hour,
            minute=minute,
            second=0,
            microsecond=0
        )

        today_runs.append(run_time)

    # future runs today
    future_runs = [t for t in today_runs if t > DATE_TIME_WITHOUT_ZONE]

    if future_runs:
        return min(future_runs)

    # else → tomorrow first time
    sorted_times = sorted(TARGET_TIMES)
    first_hour, first_minute = parse_time_str(sorted_times[0])

    return (DATE_TIME_WITHOUT_ZONE + timedelta(days=1)).replace(
        hour=first_hour,
        minute=first_minute,
        second=0,
        microsecond=0
    )

async def run_staging_scheduler():

    while True:

        next_run = get_next_run_time()
        DATE_TIME_WITHOUT_ZONE = datetime.now(INDIA_TIME_ZONE).replace(tzinfo=None)
        wait_seconds = max(0, (next_run - DATE_TIME_WITHOUT_ZONE).total_seconds())
        print(f"[STAGING] Next run at {next_run.strftime('%H:%M')} (in {wait_seconds:.2f}s)")
        await asyncio.sleep(wait_seconds)

        try:
            DATE_TIME_WITHOUT_ZONE = datetime.now(INDIA_TIME_ZONE).replace(tzinfo=None)
            print(f"[STAGING] Running at {DATE_TIME_WITHOUT_ZONE.strftime('%H:%M')}")

            # you can pass dynamic job_id if needed
            await asyncio.to_thread(
                updated_staging_tables_cron,
                "daily_staging_job"
            )

            print("[STAGING] Completed")

        except Exception as e:
            print(f"[STAGING ERROR] {e}")