import asyncio

from app.db.pool import get_connection
from app.services.workflow_schedule_service import (
    workflow_scheduled_finder,
)
from app.services.workflow_executor_service import (
    execute_scheduled_workflow,
)

SCHEDULER_INTERVAL_SECONDS = 5 * 60

async def run_workflow_scheduler():
    """
    Background workflow scheduler.

    Flow:
    1. Find workflows to run
    2. Execute sequentially
    3. Continue even if one fails
    4. Sleep after full batch completes
    """

    print("[SCHEDULER] Workflow scheduler started")

    while True:

        try:
            async with get_connection() as db:

                workflows = await workflow_scheduled_finder(db)

                if workflows:
                    print(
                        f"[SCHEDULER] Found {len(workflows)} "
                        f"workflow(s): {workflows}"
                    )
                else:
                    print("[SCHEDULER] No Workflows Found! for execution")    

                for workflow_name in workflows:
                    try:
                        await execute_scheduled_workflow(db, workflow_name)
                    except Exception as e:
                        print(
                            f"[SCHEDULER] Failed executing "
                            f"{workflow_name}: {str(e)}"
                        )

        except Exception as e:
            print(f"[SCHEDULER] Scheduler error: {str(e)}")

        print(
            f"[SCHEDULER] Sleeping for "
            f"{SCHEDULER_INTERVAL_SECONDS // 60} minutes..."
        )

        await asyncio.sleep(SCHEDULER_INTERVAL_SECONDS)