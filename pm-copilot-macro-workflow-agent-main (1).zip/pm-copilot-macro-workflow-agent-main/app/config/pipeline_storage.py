import re
import yaml
from asyncpg import Connection
from datetime import datetime
from typing import Dict, Any, Optional, List
from datetime import datetime
from app.utils.timezone import get_datetime_now_without_zone
from fastapi import HTTPException

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _serialize(pipeline_config: Dict[str, Any]) -> str:
    """Serialize a pipeline config dict to a YAML string."""
    payload = {
        "name": pipeline_config.get("name"),
        "version": pipeline_config.get("version", "Latest"),
        "generated_at": datetime.now().isoformat(),
        "steps": pipeline_config.get("steps", []),
    }
    return yaml.safe_dump(payload, default_flow_style=False, sort_keys=False, allow_unicode=True)


def _deserialize(raw: str) -> Optional[Dict[str, Any]]:
    """Deserialize a YAML string back to a pipeline config dict."""
    if raw is None:
        return None
    return yaml.load(raw, Loader=yaml.UnsafeLoader)


# ---------------------------------------------------------------------------
# Public API  (signatures unchanged from file-based version)
# ---------------------------------------------------------------------------



async def list_pipelines(db: Connection, user_id: str) -> List[str]:

    if user_id:
        rows = await db.fetch(
            """
            SELECT DISTINCT w.workflow_name
            FROM pwc_workflow_agent_schema.workflow_yaml_pipelines w
            WHERE
                EXISTS (
                    SELECT 1
                    FROM pwc_workflow_agent_schema.workflow_admin_users_list a
                    WHERE a.email_id = $1
                    AND a.admin_access = TRUE
                )

                OR w.created_by = $1

                OR w.view_to_all = TRUE

                OR (
                    w.view_to_all = FALSE
                    AND $1 = ANY(view_only_to)
                )

            ORDER BY w.workflow_name;
            """,
            user_id
        )

    return [row["workflow_name"] for row in rows]


async def list_all_pipelines_for_dev(db: Connection) -> List[str]:

    rows = await db.fetch(
        """
        SELECT DISTINCT workflow_name
        FROM pwc_workflow_agent_schema.workflow_yaml_pipelines
        ORDER BY workflow_name
        """
    )

    return [row["workflow_name"] for row in rows]

async def pipeline_exists(
    db: Connection,
    workflow_name: str,
) -> bool:
    """
    Check if a pipeline exists in the active table.

    Args:
        db:            asyncpg connection
        workflow_name: Name of the pipeline

    Returns:
        True if exists, False otherwise
    """
    row = await db.fetchrow(
        "SELECT 1 FROM pwc_workflow_agent_schema.workflow_yaml_pipelines WHERE workflow_name = $1",
        workflow_name,
    )
    return row is not None



async def save_pipeline(
    db: Connection,
    workflow_name: str,
    pipeline_config: Dict[str, Any],
    user_id: str,
    update_info: str = None,
) -> None:

    yaml_text = _serialize(pipeline_config)

    # Check whether an active pipeline already exists
    existing = await db.fetchrow(
        "SELECT id, pipeline FROM pwc_workflow_agent_schema.workflow_yaml_pipelines WHERE workflow_name = $1",
        workflow_name,
    )

    if existing:
        # Archive the current version before overwriting
        await db.execute(
            """
            INSERT INTO pwc_workflow_agent_schema.workflow_yaml_dump (workflow_name, pipeline, updated_by, update_info, old_pipeline)
            VALUES ($1, $2, $3, $4, $5)
            """,
            workflow_name,
            yaml_text,
            user_id,
            update_info,
            existing["pipeline"]
        )

        # Update the active row
        await db.execute(
            """
            UPDATE pwc_workflow_agent_schema.workflow_yaml_pipelines
               SET pipeline = $1,
                   updated_at = NOW(),
                   updated_by = $2
             WHERE workflow_name = $3
            """,
            yaml_text,
            user_id,
            workflow_name,
        )
    else:
        # Insert brand-new pipeline
        await db.execute(
            """
            INSERT INTO pwc_workflow_agent_schema.workflow_yaml_pipelines
                (workflow_name, pipeline, created_by)
            VALUES ($1, $2, $3)
            """,
            workflow_name,
            yaml_text,
            user_id
        )


async def load_pipeline(
    db: Connection,
    workflow_name: str,
) -> Optional[Dict[str, Any]]:
    """
    Load a pipeline configuration from the database.

    Args:
        db:            asyncpg connection
        workflow_name: Name of the pipeline

    Returns:
        Pipeline configuration dictionary, or None if not found
    """
    row = await db.fetchrow(
        "SELECT pipeline FROM pwc_workflow_agent_schema.workflow_yaml_pipelines WHERE workflow_name = $1",
        workflow_name,
    )
    if row is None:
        return None
    return _deserialize(row["pipeline"])


async def copy_pipeline(
    db: Connection,
    workflow_name: str,
    user_id: str,
    view_to_all: bool,
    allow_modification_to_all: bool,
    view_only_to: Optional[List[str]] = None,
    allow_modification_only_to: Optional[List[str]] = None,
    new_name: Optional[str] = None,
) -> Optional[str]:
    """
    Copy an existing workflow pipeline and create the next available version.
    Example:
        input  : workflow_v3
        output : workflow_v7 (if v6 is highest)

    Uses the pipeline of the provided workflow.
    """

    result = {
        "status": "FAILED",
        "workflow_name": workflow_name,
        "message": "",
    }

    try:
        base_name = re.sub(r"_v\d+$", "", workflow_name)

        rows = await db.fetch(
            """
            SELECT workflow_name, pipeline
            FROM pwc_workflow_agent_schema.workflow_yaml_pipelines
            WHERE workflow_name = $1
               OR workflow_name LIKE $2
            """,
            workflow_name,
            f"{base_name}_v%",
        )

        source_pipeline = None
        versions = []
        existing_names = set()

        for row in rows:
            name = row["workflow_name"]
            existing_names.add(name)

            if name == workflow_name:
                source_pipeline = row["pipeline"]

            match = re.search(r"_v(\d+)$", name)
            if match:
                versions.append(int(match.group(1)))

        if source_pipeline is None:
            result["message"] = "Source pipeline not found."
            return result

        #CASE 1: User provided name
        if new_name and new_name.strip():
            new_workflow_name = new_name.strip()

            if new_workflow_name in existing_names:
                result["message"] = f"Workflow '{new_workflow_name}' already exists."
                return result

        #CASE 2: Auto-generate version
        else:
            next_version = max(versions, default=0) + 1
            new_workflow_name = f"{base_name}_v{next_version}"

        pipeline_dict = yaml.safe_load(source_pipeline) or {}
        pipeline_dict["name"] = new_workflow_name
        pipeline_dict["generated_at"] = datetime.now().isoformat()

        updated_yaml = yaml.safe_dump(pipeline_dict, sort_keys=False)

        await db.execute(
            """
            INSERT INTO pwc_workflow_agent_schema.workflow_yaml_pipelines
            (workflow_name, pipeline, created_by, view_to_all, allow_modification_to_all, view_only_to, allow_modification_only_to)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            """,
            new_workflow_name,
            updated_yaml,
            user_id,
            view_to_all,
            allow_modification_to_all,
            view_only_to,
            allow_modification_only_to,
        )

        result["status"] = "CREATED"
        result["workflow_name"] = new_workflow_name
        result["message"] = f"Pipeline '{workflow_name}' copied successfully."

    except Exception as e:
        result["message"] = f"Pipeline copy failed: {str(e)}"

    return result


async def rename_pipeline(
    db: Connection,
    workflow_name: str,
    user_id: str,
    new_name: Optional[str] = None,
) -> Optional[str]:

    result = {
        "status": "FAILED",
        "workflow_name": workflow_name,
        "message": "",
    }

    try:
        rows = await db.fetch(
            """
            SELECT workflow_name, pipeline
            FROM pwc_workflow_agent_schema.workflow_yaml_pipelines
            WHERE workflow_name = $1
               OR workflow_name = $2
            """,
            workflow_name,
            new_name
        )

        existing = None
        duplicate = False
        pipeline_data = None

        for row in rows:
            if row["workflow_name"] == workflow_name:
                existing = True
                pipeline_data = row["pipeline"]

            if row["workflow_name"] == new_name:
                duplicate = True

        if not existing:
            result["message"] = f"Workflow '{workflow_name}' not found."
            return result

        if duplicate:
            result["message"] = f"Workflow '{new_name}' already exists."
            return result

        pipeline_dict = yaml.safe_load(pipeline_data) or {}
        pipeline_dict["name"] = new_name
        updated_yaml = yaml.safe_dump(pipeline_dict, sort_keys=False)

        TIME_NOW = get_datetime_now_without_zone()

        await db.execute(
            """
            UPDATE pwc_workflow_agent_schema.workflow_yaml_pipelines
            SET workflow_name = $1,
                pipeline = $2,
                updated_at = $3,
                updated_by = $4
            WHERE workflow_name = $5
            """,
            new_name,
            updated_yaml,
            TIME_NOW,
            user_id,
            workflow_name,
        )

        updated_info = f"Workflow Name Change From {workflow_name} to {new_name}"

        await db.execute(
            """
            INSERT INTO pwc_workflow_agent_schema.workflow_yaml_dump (workflow_name, pipeline, updated_by, update_info, old_pipeline)
            VALUES ($1, $2, $3, $4, $5)
            """,
            workflow_name,
            updated_yaml,
            user_id,
            updated_info,
            pipeline_data
        )

        result["status"] = "RENAMED"
        result["workflow_name"] = new_name
        result["message"] = f"Workflow renamed to '{new_name}'."

    except Exception as e:
        result["message"] = f"Rename failed: {str(e)}"

    return result


async def delete_pipeline(
    db: Connection,
    workflow_name: str,
    user_id: str
) -> bool:

    try:
        async with db.transaction():

            result = await db.fetchrow(
                """
                WITH existing AS (
                    SELECT id, pipeline
                    FROM pwc_workflow_agent_schema.workflow_yaml_pipelines
                    WHERE workflow_name = $1
                ),
                archived AS (
                    INSERT INTO pwc_workflow_agent_schema.workflow_yaml_dump
                    (workflow_name, pipeline, deleted_by)
                    SELECT $1, pipeline, $2
                    FROM existing
                    RETURNING 1
                )
                DELETE FROM pwc_workflow_agent_schema.workflow_yaml_pipelines
                WHERE workflow_name = $1
                  AND is_locked = FALSE
                RETURNING 1
                """,
                workflow_name,
                user_id
            )

            if not result:
                return False

            normalized_name = workflow_name.lower().replace(" ", "_")

            tables = await db.fetch(
                """
                SELECT tablename
                FROM pg_tables
                WHERE schemaname = 'pwc_workflow_agent_schema'
                  AND tablename LIKE $1
                """,
                f"{normalized_name}_wf_step_%_output"
            )

            if tables:
                table_names = [
                    f'"{row["tablename"]}"' for row in tables
                ]

                drop_query = f"""
                    DROP TABLE IF EXISTS 
                    pwc_workflow_agent_schema.{', pwc_workflow_agent_schema.'.join(table_names)}
                    CASCADE
                """

                await db.execute(drop_query)

        return True

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to delete workflow '{workflow_name}': {str(e)}"
        )
    

# ---------------------------------------------------------------------------
# Bonus helpers
# ---------------------------------------------------------------------------

async def get_pipeline_history(
    db: Connection,
    workflow_name: str,
) -> List[Dict[str, Any]]:
    """
    Return all archived versions of a pipeline from workflow_yaml_dump,
    newest first.
    """
    rows = await db.fetch(
        """
        SELECT id, workflow_name, pipeline, created_at
          FROM pwc_workflow_agent_schema.workflow_yaml_dump
         WHERE workflow_name = $1
         ORDER BY created_at DESC
        """,
        workflow_name,
    )
    return [
        {
            "id": row["id"],
            "workflow_name": row["workflow_name"],
            "config": _deserialize(row["pipeline"]),
            "created_at": row["created_at"],
        }
        for row in rows
    ]