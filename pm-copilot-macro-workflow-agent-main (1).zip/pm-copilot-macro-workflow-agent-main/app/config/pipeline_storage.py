import re
import yaml
from asyncpg import Connection
from datetime import datetime
from typing import Dict, Any, Optional, List
from datetime import datetime

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _serialize(pipeline_config: Dict[str, Any]) -> str:
    """Serialize a pipeline config dict to a YAML string."""
    payload = {
        "name": pipeline_config.get("name"),
        "version": pipeline_config.get("version", "Latest"),
        "generated_at": datetime.now().isoformat(),
        "steps": pipeline_config.get("steps", []),
    }
    return yaml.safe_dump(payload, default_flow_style=False, sort_keys=False, allow_unicode=True)


def _deserialize(raw: str) -> Optional[Dict[str, Any]]:
    """Deserialize a YAML string back to a pipeline config dict."""
    if raw is None:
        return None
    return yaml.load(raw, Loader=yaml.UnsafeLoader)


# ---------------------------------------------------------------------------
# Public API  (signatures unchanged from file-based version)
# ---------------------------------------------------------------------------



async def list_pipelines(db: Connection) -> List[str]:
    """
    List all active pipeline names.

    Args:
        db: asyncpg connection

    Returns:
        Sorted list of pipeline names
    """
    rows = await db.fetch(
        "SELECT DISTINCT workflow_name FROM pwc_workflow_agent_schema.workflow_yaml_pipelines ORDER BY workflow_name"
    )
    return [row["workflow_name"] for row in rows]


async def pipeline_exists(
    db: Connection,
    workflow_name: str,
) -> bool:
    """
    Check if a pipeline exists in the active table.

    Args:
        db:            asyncpg connection
        workflow_name: Name of the pipeline

    Returns:
        True if exists, False otherwise
    """
    row = await db.fetchrow(
        "SELECT 1 FROM pwc_workflow_agent_schema.workflow_yaml_pipelines WHERE workflow_name = $1",
        workflow_name,
    )
    return row is not None



async def save_pipeline(
    db: Connection,
    workflow_name: str,
    pipeline_config: Dict[str, Any],
) -> None:
    """
    Save a pipeline configuration to the database.

    If a pipeline with the same name already exists in workflow_yaml_pipelines,
    the existing row is archived to workflow_yaml_dump (versioning) and then
    the active row is updated with the new content.

    Args:
        db:              asyncpg connection
        workflow_name:   Name of the pipeline
        pipeline_config: Pipeline configuration dictionary
    """
    yaml_text = _serialize(pipeline_config)

    # Check whether an active pipeline already exists
    existing = await db.fetchrow(
        "SELECT id, pipeline FROM pwc_workflow_agent_schema.workflow_yaml_pipelines WHERE workflow_name = $1",
        workflow_name,
    )

    if existing:
        # Archive the current version before overwriting
        await db.execute(
            """
            INSERT INTO pwc_workflow_agent_schema.workflow_yaml_dump (workflow_name, pipeline, created_at)
            VALUES ($1, $2, NOW())
            """,
            workflow_name,
            existing["pipeline"],
        )

        # Update the active row
        await db.execute(
            """
            UPDATE pwc_workflow_agent_schema.workflow_yaml_pipelines
               SET pipeline = $1,
                   updated_at = NOW()
             WHERE workflow_name = $2
            """,
            yaml_text,
            workflow_name,
        )
    else:
        # Insert brand-new pipeline
        await db.execute(
            """
            INSERT INTO pwc_workflow_agent_schema.workflow_yaml_pipelines
                (workflow_name, pipeline, executed_result, last_executed_at, created_at)
            VALUES ($1, $2, NULL, NULL, NOW())
            """,
            workflow_name,
            yaml_text,
        )


async def load_pipeline(
    db: Connection,
    workflow_name: str,
) -> Optional[Dict[str, Any]]:
    """
    Load a pipeline configuration from the database.

    Args:
        db:            asyncpg connection
        workflow_name: Name of the pipeline

    Returns:
        Pipeline configuration dictionary, or None if not found
    """
    row = await db.fetchrow(
        "SELECT pipeline FROM pwc_workflow_agent_schema.workflow_yaml_pipelines WHERE workflow_name = $1",
        workflow_name,
    )
    if row is None:
        return None
    return _deserialize(row["pipeline"])


async def copy_pipeline(
    db: Connection,
    workflow_name: str,
) -> Optional[str]:
    """
    Copy any existing pipeline version and create the next available version.

    Example:
        input  : workflow_v3
        output : workflow_v7 (if v6 is highest)

    Uses the pipeline  of the provided workflow.
    """

    # Determine base workflow name
    base_name = re.sub(r"_v\d+$", "", workflow_name)

    rows = await db.fetch(
        """
        SELECT workflow_name, pipeline
        FROM pwc_workflow_agent_schema.workflow_yaml_pipelines
        WHERE workflow_name = $1
           OR workflow_name LIKE $2
        """,
        workflow_name,
        f"{base_name}_v%",
    )

    if not rows:
        return None

    source_pipeline = None
    source_result = None
    versions = []

    for r in rows:
        name = r["workflow_name"]

        # Source pipeline (exact user input)
        if name == workflow_name:
            source_pipeline = r["pipeline"]
            # source_result = r["executed_result"]

        # Collect versions
        match = re.search(r"_v(\d+)$", name)
        if match:
            versions.append(int(match.group(1)))

    if source_pipeline is None:
        return None

    next_version = max(versions, default=0) + 1
    new_workflow_name = f"{base_name}_v{next_version}"

    try: 
        # -------- Modify YAML --------

        pipeline_dict = yaml.safe_load(source_pipeline)

        pipeline_dict["name"] = new_workflow_name
        pipeline_dict["generated_at"] = datetime.now().isoformat()

        updated_yaml = yaml.safe_dump(pipeline_dict, sort_keys=False)

        # --------------------------------

        await db.execute(
            """
            INSERT INTO pwc_workflow_agent_schema.workflow_yaml_pipelines
            (workflow_name, pipeline, executed_result, last_executed_at, created_at)
            VALUES ($1, $2,NULL, NULL, NOW())
            """,
            new_workflow_name,
            updated_yaml,
        )

        return {
            "status": "CREATED",
            "workflow_name": new_workflow_name,
            "message": f"Pipeline '{workflow_name}' copied successfully."
        }
    
    except Exception as e:

        return {
            "status": "FAILED",
            "workflow_name": None,
            "message": f"Pipeline copy failed: {str(e)}"
        }


async def delete_pipeline(
    db: Connection,
    workflow_name: str,
) -> bool:
    """
    Delete a pipeline from the active table.

    Args:
        db:            asyncpg connection
        workflow_name: Name of the pipeline

    Returns:
        True if deleted, False if not found
    """
    result = await db.execute(
        "DELETE FROM pwc_workflow_agent_schema.workflow_yaml_pipelines WHERE workflow_name = $1",
        workflow_name,
    )
    # asyncpg returns e.g. "DELETE 1" or "DELETE 0"
    return result.endswith("1")


# ---------------------------------------------------------------------------
# Bonus helpers
# ---------------------------------------------------------------------------

async def get_pipeline_history(
    db: Connection,
    workflow_name: str,
) -> List[Dict[str, Any]]:
    """
    Return all archived versions of a pipeline from workflow_yaml_dump,
    newest first.
    """
    rows = await db.fetch(
        """
        SELECT id, workflow_name, pipeline, created_at
          FROM pwc_workflow_agent_schema.workflow_yaml_dump
         WHERE workflow_name = $1
         ORDER BY created_at DESC
        """,
        workflow_name,
    )
    return [
        {
            "id": row["id"],
            "workflow_name": row["workflow_name"],
            "config": _deserialize(row["pipeline"]),
            "created_at": row["created_at"],
        }
        for row in rows
    ]