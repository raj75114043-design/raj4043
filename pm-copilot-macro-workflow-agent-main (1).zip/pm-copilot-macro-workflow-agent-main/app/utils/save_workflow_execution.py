import json
from fastapi.encoders import jsonable_encoder
from typing import Dict, Any
from asyncpg import Connection
from app.utils.timezone import get_datetime_now_without_zone

async def save_workflow_execution(
    db: Connection,
    workflow_name: str,
    execution_payload: Dict[str, Any],
    user_id: str,
) -> None:
    """
    Save (overwrite) workflow execution result in the database.
    Existing executed_result will be replaced with the new payload.

    Args:
        db:                asyncpg connection
        workflow_name:     Name of the workflow / pipeline
        execution_payload: Execution result dict to persist
    """
    DATE_TIME_WITHOUT_ZONE = get_datetime_now_without_zone()

    data = {
        "workflow_name": workflow_name,
        "saved_at": DATE_TIME_WITHOUT_ZONE,
        "executions": [
            {**execution_payload}
        ],
    }

    await db.execute(
        """
        UPDATE pwc_workflow_agent_schema.workflow_yaml_pipelines
           SET executed_result  = $1::jsonb,
               last_executed_at = $2,
               last_executed_by = $4
         WHERE workflow_name = $3
        """,
        json.dumps(jsonable_encoder(data)),
        DATE_TIME_WITHOUT_ZONE,
        workflow_name,
        user_id,
    )