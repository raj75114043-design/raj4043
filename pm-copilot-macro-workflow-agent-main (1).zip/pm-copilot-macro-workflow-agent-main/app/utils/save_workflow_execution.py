import json
from datetime import datetime
from typing import Dict, Any

from asyncpg import Connection


async def save_workflow_execution(
    db: Connection,
    workflow_name: str,
    execution_payload: Dict[str, Any],
) -> None:
    """
    Save (overwrite) workflow execution result in the database.
    Existing executed_result will be replaced with the new payload.

    Args:
        db:                asyncpg connection
        workflow_name:     Name of the workflow / pipeline
        execution_payload: Execution result dict to persist
    """
    now = datetime.now()

    data = {
        "workflow_name": workflow_name,
        "saved_at": now.isoformat(),
        "executions": [
            {**execution_payload}
        ],
    }

    await db.execute(
        """
        UPDATE pwc_workflow_agent_schema.workflow_yaml_pipelines
           SET executed_result  = $1::jsonb,
               last_executed_at = $2
         WHERE workflow_name = $3
        """,
        json.dumps(data),
        now,
        workflow_name,
    )