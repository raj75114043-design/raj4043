from typing import Dict
from typing import List, Dict, Any,  Set

BASE_SCHEMA = "pwc_macro_staging_schema"
WORKFLOW_OUTPUT_SCHEMA = "pwc_workflow_agent_schema"

STAGING_SOURCE_SCHEMA = 'public'
STAGING_TARGET_SCHEMA = 'pwc_macro_staging_schema'
STAGING_PREFIX = 'stg_'

DB_CONFIG = {
    'host': '10.208.241.129',
    'port': 30924,
    'database': 'postgres', 
    'user': 'osdp_pwc_read_role',
    'password': 'Nokia@osdp@pwc@2025'
}

TABLES_TO_STAGING = [
    "ndpd_mbt_tmobile_macro_combined",
    "ndpd_mbt_combine_site_wise_forecast",
    "tmo_rejections_master_file",
    "fast_tracker_copilot",
    "services_ndpc_answers_daily_from_sdb",
    "services_ndpc_sessions_daily_from_sdb",
    "tmo_ndpd_forms",
    "tmo_copilot_se_rcm",
    "ndpd_hse_site_checklist",
    "tmo_hse_daily_tracker_v0_1",
    "nas_e2e_call_test_completion",
    "nas_e911_readiness_riot_validation",
    "nas_log_data",
    "nas_nest_db_sp",
    "nas_nest_ext_raw_by_session",
    "nas_planned_outage_activity",
    "nas_rejection_data_last_30_days",
    "nas_rf010_dashboard",
    "nas_session_level_combined_data",
    "tmo_nas_daily_dashboard",
    "nas_projectid_and_smpid_tracker",
    "tmo_nas_mbt",
    "tmo_macro_copilot_ahloa_reschedule_delay_code"
]
