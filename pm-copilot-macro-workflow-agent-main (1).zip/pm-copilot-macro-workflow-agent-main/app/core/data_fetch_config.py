from typing import Dict

BASE_SCHEMA = "pwc_macro_staging_schema"
BASE_TABLE = "stg_ndpd_mbt_tmobile_macro_combined"

GLOBAL_FILTERS: Dict[str, str] = {
    # "site_code": "s_site_id",
    # "project_id": "pj_project_id",
    "region": "rgn_region",
    "area": "m_area",
    "market": "m_market",
    # "smp_id": "smp_id",
    "spm_name": "smp_name",
}

