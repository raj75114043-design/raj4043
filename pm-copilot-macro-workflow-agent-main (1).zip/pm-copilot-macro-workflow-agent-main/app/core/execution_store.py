from typing import Dict, Any

EXECUTIONS: Dict[str, Dict[str, Any]] = {}
