"""Enumerations for workflow agent domain models."""

from enum import Enum


class ValidationOperator(str, Enum):
    """Operators for validation logic in filter rules."""

    PRIMARY_KEY = "primary_key"
    GLOBAL_FILTER = "global_filter"
    COMMON_IN_ALL = "common_in_all"

    NO_FILTER = "no_filter"
    NOT_NULL = "not_null"
    IS_NULL = "is_null"

    EQUALS = "equals"
    NOT_EQUALS = "not_equals"
    IN_LIST_EQUALS = "in_list_equals"
    NOT_IN_LIST_EQUALS = "not_in_list_equals"

    GREATER_THAN = "greater_than"
    LESS_THAN = "less_than"

    CONTAINS = "contains"
    NOT_CONTAINS = "not_contains"
    IN_LIST_CONTAINS = "in_list_contains"
    NOT_IN_LIST_CONTAINS = "not_in_list_contains"

    CURRENT_DATE = "current_date"
    DATE_PASSED = "date_passed"
    DATE_NOT_PASSED = "date_not_passed"
    DATE_TOMORROW = "date_tomorrow"
    DATE_YESTERDAY = "date_yesterday"

    DATE_EQUALS_TO = "date_equals_to"
    DATE_LOWER_THAN = "date_lower_than"
    DATE_HIGHER_THAN = "date_higher_than"
    DATE_IN_BETWEEN = "date_in_between"
    DATE_OVERDUE_BY_DAYS = "date_overdue_by_days"
    DATE_DUE_WITHIN_NEXT_DAYS = "date_due_within_next_days"


class OnDisabledStrategy(str, Enum):
    """Strategy for handling disabled steps."""

    PASSTHROUGH = "passthrough"  # Pass all input site codes through
    EMPTY = "empty"  # Return empty result


class MergeStrategy(str, Enum):
    """Strategy for merging results from multiple parent steps."""

    UNION = "union"  # A ∪ B (combine all site codes)
    INTERSECTION = "intersection"  # A ∩ B (only common site codes)


class ConditionalLogic(str, Enum):
    """Logic for combining multiple filter rules."""

    AND = "AND"  # All rules must pass
    ANY = "ANY"  # At least one rule must pass


class StepStatus(str, Enum):
    """Status of step execution."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    DISABLED = "disabled"
