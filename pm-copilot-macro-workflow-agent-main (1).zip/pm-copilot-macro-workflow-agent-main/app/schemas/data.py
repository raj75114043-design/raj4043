from pydantic import BaseModel
from typing import Dict, List, Any, Union

class GlobalFiltersResponse(BaseModel):
    workflow: str
    filters: Dict[str, List[str]]

class GlobalFiltersResponseUpdated(BaseModel):
    workflow: str
    filters: List[Dict[str, Any]] 

class WorkflowKeyCountResponse(BaseModel):
    workflow: str
    count: int
    primary_key: str
    table: str
    base_schema: str

class ChatDefaultQueries(BaseModel):
    questions: Dict[int, str]

class AddUsersPMCoPilotRequest(BaseModel):
    user_ids: List[str]
