from pydantic import BaseModel
from typing import Dict, List

class GlobalFiltersResponse(BaseModel):
    workflow: str
    filters: Dict[str, List[str]]