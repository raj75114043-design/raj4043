from datetime import datetime, time
from typing import Optional, List, Dict, Any

from pydantic import BaseModel, Field
from fastapi import APIRouter, Depends, HTTPException
from asyncpg import Connection

from app.db.pool import get_db


router = APIRouter(prefix="/scheduled_email", tags=["Scheduled Email"])


# =========================================================
# UPDATE MODEL
# =========================================================

class WorkflowEmailScheduleUpdate(BaseModel):
    workflow_name: Optional[str] = None
    step_id: Optional[int] = None
    allowed_sites: Optional[str] = None
    to_list: Optional[List[str]] = None
    cc_list: Optional[List[str]] = None
    bcc_list: Optional[List[str]] = None
    is_recurring: Optional[bool] = None
    schedule_time: Optional[time] = None
    is_enabled: Optional[bool] = None
    last_run_time: Optional[datetime] = None
    mail_status: Optional[str] = None
    token_id: Optional[str] = None
    days_of_week: Optional[List[str]] = None
    scheduled_by: Optional[str] = None
    columns_name: Optional[List[str]] = None
    global_filters: Optional[Dict[str, Any]] = None
    schedule_time_zone: Optional[str] = None


# =========================================================
# GET ALL SCHEDULED EMAILS
# =========================================================

@router.get("/workflow/email-schedules")
async def get_workflow_email_schedules(
    db: Connection = Depends(get_db),
):

    try:

        query = """
            SELECT
                id,
                workflow_name,
                step_id,
                allowed_sites,
                to_list,
                cc_list,
                bcc_list,
                is_recurring,
                schedule_time,
                is_enabled,
                last_run_time,
                created_at,
                updated_at,
                mail_status,
                token_id,
                days_of_week,
                scheduled_by,
                columns_name,
                global_filters,
                schedule_time_zone
            FROM pwc_workflow_agent_schema.workflow_email_schedule
            ORDER BY created_at DESC
        """

        rows = await db.fetch(query)

        formatted_rows = []

        for row in rows:

            row_dict = dict(row)

            formatted_data = {}

            for key, value in row_dict.items():

                formatted_data[key] = {
                    "value": value,
                    "data_type": type(value).__name__
                }

            formatted_rows.append(formatted_data)

        return {
            "success": True,
            "total": len(formatted_rows),
            "data": formatted_rows
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch workflow schedules: {str(e)}"
        )


# =========================================================
# UPDATE WORKFLOW EMAIL SCHEDULE
# =========================================================

@router.post("/workflow/email-schedules/{id}")
async def update_workflow_email_schedule(
    id: int,
    payload: WorkflowEmailScheduleUpdate,
    db: Connection = Depends(get_db),
):

    try:

        # =====================================================
        # REMOVE EMPTY FIELDS
        # =====================================================

        update_fields = payload.model_dump(
            exclude_none=True
        )

        if not update_fields:

            raise HTTPException(
                status_code=400,
                detail="No fields provided for update"
            )

        # =====================================================
        # BUILD QUERY
        # =====================================================

        set_clauses = []
        values = []

        idx = 1

        for field, value in update_fields.items():

            set_clauses.append(
                f"{field} = ${idx}"
            )

            values.append(value)

            idx += 1

        # =====================================================
        # UPDATED_AT
        # =====================================================

        set_clauses.append(
            "updated_at = NOW()"
        )

        # =====================================================
        # WHERE CONDITION
        # =====================================================

        values.append(id)

        query = f"""
            UPDATE pwc_workflow_agent_schema.workflow_email_schedule
            SET {", ".join(set_clauses)}
            WHERE id = ${idx}
        """

        result = await db.execute(
            query,
            *values
        )

        return {
            "success": True,
            "message": f"Workflow email schedule updated successfully for id={id}",
            "updated_fields": list(update_fields.keys())
        }

    except HTTPException:
        raise

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to update workflow email schedule: {str(e)}"
        )


# =========================================================
# DELETE WORKFLOW EMAIL SCHEDULE
# =========================================================

@router.delete("/workflow/email-schedules/{id}")
async def delete_workflow_email_schedule(
    id: int,
    db: Connection = Depends(get_db),
):

    try:

        query = """
            DELETE FROM pwc_workflow_agent_schema.workflow_email_schedule
            WHERE id = $1
        """

        result = await db.execute(
            query,
            id
        )

        return {
            "success": True,
            "message": f"Workflow email schedule deleted successfully for id={id}"
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to delete workflow email schedule: {str(e)}"
        )