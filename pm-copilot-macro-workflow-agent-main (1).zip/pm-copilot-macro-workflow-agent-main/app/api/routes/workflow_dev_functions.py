"""
Workflow Development API routes for pipeline creation and management.

WARNING: These endpoints are for DEVELOPERS ONLY.
All endpoints require password authentication.

This module provides REST endpoints for DEVELOPERS to:
- Create new workflow pipelines (saved as YAML files)
- Delete pipelines
- Add/remove steps from pipelines

Note: These endpoints are for development/configuration only.
For runtime operations (execution, step modification), use the workflow_orchestration routes.
"""

import secrets
import copy
import pandas as pd
import yaml
import io

from fastapi import UploadFile, File
from datetime import datetime
from typing import List, Optional
from fastapi import APIRouter, HTTPException, Header, Depends
from fastapi import Security, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from asyncpg import Connection
from fastapi.security import APIKeyHeader
from typing import get_origin, get_args, Union
from dataclasses import fields, is_dataclass, MISSING
from enum import Enum
from app.db.pool import get_db, get_connection

from io import BytesIO
from fastapi.responses import StreamingResponse


from app.schemas.workflow import (
    WorkflowStepCreate,
    WorkflowPipelineCreate,
    DependsOnUpdateRequest,
    MessageResponse,
    PipelineCopyResponse,
    PipelineCopyRequest,
    PipelineRenameRequest,
    PipelineRenameResponse,
    VALUE_REQUIRED_OPERATORS,
    UserInfoRequest,
)

from app.models.workflow import (
    StepMetaData,
    StepExecutionConfig,
    FilterCriteriaConfig,
    ViewOutputConfig,
    ComputationConfig,
    AgentConfig,
)

from app.config.pipeline_storage import (
    save_pipeline,
    load_pipeline,
    delete_pipeline as delete_pipeline_file,
    list_pipelines,
    list_all_pipelines_for_dev,
    copy_pipeline,
    rename_pipeline,
    pipeline_exists,
)

from app.services.smart_remove_step import smart_remove_workflow_step

from app.models.enums import (
    ValidationOperator,
)

security = HTTPBasic()
router = APIRouter(prefix="/workflow_dev", tags=["Workflow Developer Utility (DEV ONLY)"])


# Dev password for protecting endpoints
DEV_PASSWORD = "pwc_macro_team"


def verify_dev_password(credentials: HTTPBasicCredentials = Depends(security)):
    correct = secrets.compare_digest(credentials.password, "pwc_macro_team")
    if not correct:
        raise HTTPException(status_code=401, headers={"WWW-Authenticate": "Basic"})


from dataclasses import fields, is_dataclass, MISSING
from typing import get_origin, get_args, Union
from enum import Enum


def _resolve_type(t, field):

    result = {}

    origin = get_origin(t)

    # Handle List types
    if origin is list:
        arg = get_args(t)[0]

        if is_dataclass(arg):
            result["type"] = "list"
            result["items"] = _extract_schema(arg)
            return result

        result["type"] = f"list[{arg.__name__}]"
        return result

    # Handle Optional / Union
    if origin is Union:
        args = [a for a in get_args(t) if a is not type(None)]
        if args:
            result["type"] = f"Optional[{args[0].__name__}]"
            return result

    # Handle Enums (str enums)
    if isinstance(t, type) and issubclass(t, Enum):

        result["type"] = "str"
        result["allowed_values"] = [e.value for e in t]

        if field.default != MISSING:
            if isinstance(field.default, Enum):
                result["default"] = field.default.value
            else:
                result["default"] = field.default

        return result

    # Handle nested dataclasses
    if is_dataclass(t):
        result["type"] = t.__name__
        result["fields"] = _extract_schema(t)
        return result

    # Handle default values
    if field.default != MISSING:
        result["default"] = field.default

    result["type"] = getattr(t, "__name__", str(t))

    return result


def _extract_schema(dataclass_type):

    schema = {}

    for f in fields(dataclass_type):
        schema[f.name] = _resolve_type(f.type, f)

    return schema

def _has_cycle(steps):

    graph = {
        step["meta"]["step_id"]: step["execution"].get("depends_on", [])
        for step in steps
    }

    visited = set()
    recursion_stack = set()

    def dfs(node):

        visited.add(node)
        recursion_stack.add(node)

        for neighbor in graph.get(node, []):

            if neighbor not in visited:
                if dfs(neighbor):
                    return True

            elif neighbor in recursion_stack:
                return True

        recursion_stack.remove(node)
        return False

    for node in graph:
        if node not in visited:
            if dfs(node):
                return True

    return False

def _step_to_dict(step_data: WorkflowStepCreate) -> dict:
    """Convert a WorkflowStepCreate schema to a dictionary for YAML storage."""
    
    step_dict = {
        "meta": {
            "step_id": step_data.meta.step_id,
            "name": step_data.meta.name,
            "description": step_data.meta.description,
            "phase_id": step_data.meta.phase_id,
            "phase_name": step_data.meta.phase_name,
            "category": step_data.meta.category
        },
        "execution": {
            "is_enabled": step_data.execution.is_enabled,
            "on_disabled": step_data.execution.on_disabled,
            "depends_on": step_data.execution.depends_on,
            "merge_strategy": step_data.execution.merge_strategy,
        },
    }

    if step_data.filter_criteria:
        step_dict["filter_criteria"] = {
            "enabled": step_data.filter_criteria.enabled,
            "conditional_logic": step_data.filter_criteria.conditional_logic,
            "rules": [
                {
                    "source_table": r.source_table,
                    "primary_key_column": r.primary_key_column,
                    "column_name": r.column_name,
                    "operator": r.operator,
                    "expected_value": r.expected_value,
                    "description": r.description,
                }
                for r in step_data.filter_criteria.rules
            ],
        }

    if step_data.view_output:
        step_dict["view_output"] = {
            "is_enabled": step_data.view_output.is_enabled,
        }

    if step_data.computation:
        step_dict["computation"] = {
            "is_enabled": step_data.computation.is_enabled,
            "computations": step_data.computation.computations,
        }

    if step_data.agent:
        step_dict["agent"] = {
            "is_enabled": step_data.agent.is_enabled,
            "agents": step_data.agent.agents,
        }

    return step_dict



@router.get("/existing_operators/{workflow_name}")
async def get_engine_existing_operators(workflow_name: str):
    """Get available validation operators."""    
    return {
        operator.value: {
            "requires_expected_value": operator in VALUE_REQUIRED_OPERATORS,
        }
        for operator in sorted(ValidationOperator, key=lambda op: op.value)
    }

@router.get("/new_step_required_inputs/{workflow_name}")
async def get_required_inputs_for_new_step(workflow_name: str):
    """
    Returns the exact structure required to create a WorkflowStep.
    Derived directly from the dataclass models.
    """
    return {
        "WorkflowStep": {
            "meta": _extract_schema(StepMetaData),
            "execution": _extract_schema(StepExecutionConfig),
            "filter_criteria": _extract_schema(FilterCriteriaConfig),
            "view_output": _extract_schema(ViewOutputConfig),
            "computation": _extract_schema(ComputationConfig),
            "agent": _extract_schema(AgentConfig),
        }
    }

@router.get("/pipelines", response_model=List[str])
async def list_all_pipelines(
    db: Connection = Depends(get_db),
):
    """
    [DEV ONLY] List all available workflow pipelines (from YAML files).

    This endpoint is restricted to developers only and requires the X-Dev-Password header.
    """
    
    return await list_all_pipelines_for_dev(db)

@router.get("/pipelines/{workflow_name}")
async def get_pipeline_detailed_config(
    workflow_name: str,
    db: Connection = Depends(get_db),
):
    """
    [DEV ONLY] Get the raw YAML configuration for a pipeline.

    This endpoint is restricted to developers only and requires the X-Dev-Password header.
    """

    pipeline_config = await load_pipeline(db, workflow_name)

    if not pipeline_config:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{workflow_name}' not found"
        )

    return pipeline_config

    

@router.post("/copy_existing_pipeline/{workflow_name}", response_model=PipelineCopyResponse)
async def copy_existing_pipeline(
    workflow_name: str,
    user_info: UserInfoRequest,
    request: PipelineCopyRequest,
    db: Connection = Depends(get_db),
):
    """
    [DEV ONLY] List all available workflow pipelines (from YAML files).
    This endpoint is restricted to developers only and requires the X-Dev-Password header.
    """
    new_name = request.new_name
    view_to_all = request.view_to_all
    allow_modification_to_all = request.allow_modification_to_all

    user_id = user_info.user_id
    pipeline_config = await load_pipeline(db, workflow_name)

    if not pipeline_config:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{workflow_name}' not found"
        )
    
    result = await copy_pipeline(
        db=db,
        workflow_name=workflow_name,
        user_id=user_id,
        view_to_all=view_to_all,
        allow_modification_to_all=allow_modification_to_all,
        view_only_to = request.view_only_to,
        allow_modification_only_to = request.allow_modification_only_to,
        new_name=new_name
    )

    if result["status"] == "FAILED":
        raise HTTPException(
            status_code=400,
            detail=result["message"]
        )

    return result


@router.post("/rename_existing_pipeline/{workflow_name}", response_model=PipelineRenameResponse)
async def rename_existing_pipeline(
    workflow_name: str,
    user_info: UserInfoRequest,
    request: PipelineRenameRequest,
    db: Connection = Depends(get_db),
):
    """
    [DEV ONLY] List all available workflow pipelines (from YAML files).

    This endpoint is restricted to developers only and requires the X-Dev-Password header.
    """
    
    new_name = request.new_name
    user_id = user_info.user_id
    pipeline_config = await load_pipeline(db, workflow_name)

    if not pipeline_config:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{workflow_name}' not found"
        )
    
    result = await rename_pipeline(db, workflow_name, user_id, new_name)

    if result["status"] == "FAILED":
        raise HTTPException(
            status_code=400,
            detail=result["message"]
        )

    return result


@router.post("/pipelines", response_model=MessageResponse, include_in_schema=False)
async def create_pipeline(
    pipeline: WorkflowPipelineCreate,
    user_info: UserInfoRequest,
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
    db: Connection = Depends(get_db),
):
    """
    [DEV ONLY] Create a new workflow pipeline configuration file.

    This endpoint is restricted to developers only and requires the X-Dev-Password header.
    The pipeline is saved as a YAML file in the config/pipelines directory.
    """

    user_id = user_info.user_id

    if await pipeline_exists(db, pipeline.name):
        raise HTTPException(
            status_code=400, detail=f"Workflow '{pipeline.name}' already exists"
        )
    
    steps = [s.model_dump(mode="json", exclude_none=True) for s in pipeline.steps]

    step_ids = [s["meta"]["step_id"] for s in steps]

    # ----------------------------
    # Validate unique step IDs
    # ----------------------------
    if len(step_ids) != len(set(step_ids)):
        raise HTTPException(
            status_code=400,
            detail="Duplicate step_id values found in pipeline"
        )

    # ----------------------------
    # Validate dependencies
    # ----------------------------
    for step in steps:

        step_id = step["meta"]["step_id"]
        depends_on = step.get("execution", {}).get("depends_on", [])

        # Self dependency check
        if step_id in depends_on:
            raise HTTPException(
                status_code=400,
                detail=f"Step {step_id} cannot depend on itself"
            )

        # Dependency existence check
        invalid_deps = [d for d in depends_on if d not in step_ids]

        if invalid_deps:
            raise HTTPException(
                status_code=400,
                detail=f"Step {step_id} has invalid depends_on values: {invalid_deps}"
            )

    # ----------------------------
    # Circular dependency check
    # ----------------------------
    if _has_cycle(steps):
        raise HTTPException(
            status_code=400,
            detail="Circular dependency detected in pipeline"
        )


    pipeline_config = pipeline.model_dump(
        mode="json",
        exclude_none=True
    )

    updated_info = f"Workflow '{pipeline.name}' created with {len(pipeline.steps)} steps. Saved"
    await save_pipeline(db, pipeline.name, pipeline_config, user_id, updated_info)


    return MessageResponse(
        message=f"Workflow '{pipeline.name}' created with {len(pipeline.steps)} steps. Saved"
    )


@router.delete("/pipelines/{workflow_name}", response_model=MessageResponse)
async def delete_pipeline(
    workflow_name: str,
    user_info: UserInfoRequest,
    db: Connection = Depends(get_db),
):
    """
    [DEV ONLY] Delete a workflow pipeline YAML file.

    This endpoint is restricted to developers only and requires the X-Dev-Password header.
    """

    pipeline_config = await load_pipeline(db, workflow_name)
    user_id = user_info.user_id

    if not pipeline_config:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{workflow_name}' not found"
        )
    
    if not await delete_pipeline_file(db, workflow_name, user_id):
        raise HTTPException(
            status_code=404, detail = f"Workflow '{workflow_name}' cannot be deleted because it is Locked!"
        )

    return MessageResponse(message=f"Workflow '{workflow_name}' deleted")



@router.post("/pipelines/{workflow_name}/new_step", response_model=MessageResponse)
async def add_new_step(
    workflow_name: str,
    user_info: UserInfoRequest,
    step: WorkflowStepCreate,
    db: Connection = Depends(get_db),
):
    """
    [DEV ONLY] Add a step to an existing workflow pipeline.

    This endpoint is restricted to developers only and requires the X-Dev-Password header.
    """
    pipeline_config = await load_pipeline(db, workflow_name)
    user_id = user_info.user_id

    if not pipeline_config:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{workflow_name}' not found"
        )
    
    steps = pipeline_config.get("steps", [])

    # Validate Step ID uniqueness
    existing_ids = [s["meta"]["step_id"] for s in pipeline_config.get("steps", [])]
    if step.meta.step_id in existing_ids:
        raise HTTPException(
            status_code=400, detail=f"Step with ID {step.meta.step_id} already exists"
        )

    depends_on_ids = step.execution.depends_on or []
    
    # Prevent empty depends_on
    if not depends_on_ids:
        raise HTTPException(
            status_code=400,
            detail=f"Step {step.meta.step_id} must have at least one dependency (depends_on cannot be empty)"
        )

    # ----------------------------
    # Prevent self dependency
    # ----------------------------
    if step.meta.step_id in depends_on_ids:
        raise HTTPException(
            status_code=400,
            detail=f"Step {step.meta.step_id} cannot depend on itself"
        )

    # ---------------------------------
    # Guardrail: filter_criteria must have valid rules
    # ---------------------------------
    if step.filter_criteria:

        # Rule list should not be empty
        if not step.filter_criteria.rules:
            raise HTTPException(
                status_code=400,
                detail=f"Step {step.meta.step_id} has filter_criteria but no rules defined"
            )

        # Validate each rule
        for idx, rule in enumerate(step.filter_criteria.rules, start=1):

            if not rule.source_table or not str(rule.source_table).strip():
                raise HTTPException(
                    status_code=400,
                    detail=f"Step {step.meta.step_id} Rule {idx}: source_table cannot be empty"
                )

            if not rule.primary_key_column or not str(rule.primary_key_column).strip():
                raise HTTPException(
                    status_code=400,
                    detail=f"Step {step.meta.step_id} Rule {idx}: Primary Key Column cannot be empty!"
                )

            if not rule.column_name or not str(rule.column_name).strip():
                raise HTTPException(
                    status_code=400,
                    detail=f"Step {step.meta.step_id} Rule {idx}: column_name cannot be empty"
                )

            if not rule.operator:
                raise HTTPException(
                    status_code=400,
                    detail=f"Step {step.meta.step_id} Rule {idx}: operator is required"
                )
            

    # ----------------------
    # Validate depends_on references
    # ---------------------------------
    invalid_dependencies = [
        dep for dep in depends_on_ids if dep not in existing_ids
    ]

    if invalid_dependencies:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid depends_on step IDs: {invalid_dependencies}. Dependency Steps is NOT Available")
    
    step_dict = step.model_dump(
        mode="json",
        exclude_none=True
    )

    new_steps = steps + [step_dict]
    
    # Check circular dependency - But this will never be a case
    if _has_cycle(new_steps):
        raise HTTPException(
            status_code=400,
            detail="Circular dependency detected in workflow"
        )
    
    pipeline_config.setdefault("steps", []).append(step_dict)

    updated_info = f"Step: '{step.meta.name}' with  Step Id: '{step.meta.step_id}' added to workflow"
    await save_pipeline(db, workflow_name, pipeline_config, user_id, updated_info)

    return MessageResponse(
        message=f"Step '{step.meta.name}' added to workflow '{workflow_name}'"
    )


@router.delete(
    "/pipelines/{workflow_name}/remove_step/{step_id}", response_model=MessageResponse
)
async def remove_step(
    workflow_name: str,
    user_info: UserInfoRequest,
    step_id: int,
    db: Connection = Depends(get_db),
):
    """
    [DEV ONLY] Remove a step from a workflow pipeline.

    This endpoint is restricted to developers only and requires the X-Dev-Password header.
    """

    pipeline_config = await load_pipeline(db, workflow_name)
    user_id = user_info.user_id

    if not pipeline_config:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{workflow_name}' not found"
        )

    steps = pipeline_config.get("steps", [])

    # ---------------------------------
    # Validate step exists
    # ---------------------------------
    step_exists = any(
        s.get("meta", {}).get("step_id") == step_id
        for s in steps
    )
    if not step_exists:
        raise HTTPException(
            status_code=404,
            detail=f"Step {step_id} not found"
        )


    # =================================
    target_step = next(
        (s for s in steps if s.get("meta", {}).get("step_id") == step_id),
        None
    )

    depends_on = target_step.get("execution", {}).get("depends_on", [])

    if not depends_on:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Step {step_id} cannot be deleted because it is a starting step "
                f"(no dependencies)."
            )
        )


    # ---------------------------------
    # Check dependency usage
    # ---------------------------------
    dependent_steps = []

    for s in steps:
        depends_on = s.get("execution", {}).get("depends_on", [])
        if step_id in depends_on:
            dependent_steps.append(s["meta"]["step_id"])

    if dependent_steps:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Step {step_id} cannot be deleted because it is used "
                f"as dependency by steps: {dependent_steps}. Please remove the Dependency First!"
            )
        )
    
    # Safe removal
    pipeline_config["steps"] = [
        s for s in steps
        if s.get("meta", {}).get("step_id") != step_id
    ]

    updated_info = f"Step {step_id} removed from workflow"
    await save_pipeline(db, workflow_name, pipeline_config, user_id, updated_info)

    return MessageResponse(
        message=f"Step {step_id} removed from workflow '{workflow_name}'"
    )

@router.delete(
    "/pipelines/{workflow_name}/smart_remove_step/{step_id}",
    response_model=MessageResponse,
)
async def smart_remove_step(
    workflow_name: str,
    user_info: UserInfoRequest,
    step_id: int,
    db: Connection = Depends(get_db),
):

    message = await smart_remove_workflow_step(
        db=db,
        workflow_name=workflow_name,
        step_id=step_id,
        user_id=user_info.user_id,
    )

    return MessageResponse(message=message)

@router.post("/pipelines/{workflow_name}/update/depends_on", response_model=MessageResponse)
async def update_step_dependencies(
    workflow_name: str,
    user_info: UserInfoRequest,
    update_dependency: DependsOnUpdateRequest,
    db: Connection = Depends(get_db),
):
    """
    [DEV ONLY] Update depends_on for a specific step.

    Validations:
    - Step must exist
    - Dependencies must exist
    - No self dependency
    - No circular dependency
    """

    # Extract request data
    user_id = user_info.user_id
    step_id = update_dependency.step_id
    depends_on = update_dependency.depends_on or []

    # Prevent empty dependency list
    if not depends_on:
        raise HTTPException(
            status_code=400,
            detail=f"Dependency cannot be empty for step {step_id}."
        )
    
    pipeline_config = await load_pipeline(db, workflow_name)

    if not pipeline_config:
        raise HTTPException(
            status_code=404,
            detail=f"Workflow '{workflow_name}' not found"
        )

    steps = pipeline_config.get("steps", [])

    # ---------------------------------
    # Validate step exists
    # ---------------------------------
    step_map = {s["meta"]["step_id"]: s for s in steps}

    if step_id not in step_map:
        raise HTTPException(
            status_code=404,
            detail=f"Step {step_id} not found"
        )

    existing_ids = list(step_map.keys())

    # ---------------------------------
    # Self dependency check
    # ---------------------------------
    if step_id in depends_on:
        raise HTTPException(
            status_code=400,
            detail=f"Step {step_id} cannot depend on itself"
        )

    # ---------------------------------
    # Validate dependency existence
    # ---------------------------------
    invalid_deps = [d for d in depends_on if d not in existing_ids]

    if invalid_deps:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid depends_on step IDs: {invalid_deps}. Dependency steps not available"
        )

    # ---------------------------------
    # Simulate update (safe deep copy)
    # ---------------------------------
    updated_steps = copy.deepcopy(steps)

    for s in updated_steps:
        if s["meta"]["step_id"] == step_id:
            s["execution"]["depends_on"] = depends_on

    # ---------------------------------
    # Circular dependency check
    # ---------------------------------
    if _has_cycle(updated_steps):
        raise HTTPException(
            status_code=400,
            detail="Circular dependency detected after update"
        )

    # ---------------------------------
    # Persist change
    # ---------------------------------
    for s in steps:
        if s["meta"]["step_id"] == step_id:
            s["execution"]["depends_on"] = depends_on


    updated_info = f"Changed Step Dependency for Step: {step_id} to {depends_on}"
    await save_pipeline(db, workflow_name, pipeline_config, user_id, updated_info)


    return MessageResponse(
        message=f"Dependencies for step {step_id} updated successfully to {depends_on}"
    )



@router.get(
    "/pipelines/{workflow_name}/download/steps-excel",
    tags=["Workflow Developer Utility (DEV ONLY)"],
)
async def download_workflow_steps_excel(
    workflow_name: str,
    db: Connection = Depends(get_db),
):
    """
    [DEV ONLY]
    Download workflow steps metadata as an Excel file.

    Columns:
    - Step Id
    - Step Name
    - Step Phase Name
    - Step Category
    - Enable Status
    """

    # ---------------------------------
    # Load Pipeline
    # ---------------------------------
    pipeline_config = await load_pipeline(db, workflow_name)

    if not pipeline_config:
        raise HTTPException(
            status_code=404,
            detail=f"Workflow '{workflow_name}' not found"
        )

    steps = pipeline_config.get("steps", [])

    # ---------------------------------
    # Prepare Excel Data
    # ---------------------------------
    rows = []

    for step in steps:

        meta = step.get("meta", {})
        execution = step.get("execution", {})

        category = meta.get("category")

        # Handle list category safely
        if isinstance(category, list):
            category = ", ".join(category)

        rows.append({
            "Step Id": meta.get("step_id"),
            "Step Name": meta.get("name"),
            "Step Phase Name": meta.get("phase_name"),
            "Step Category": category,
            "Enable Status": execution.get("is_enabled", False),
        })

    # ---------------------------------
    # Create DataFrame
    # ---------------------------------
    df = pd.DataFrame(rows)

    # Optional sorting
    df = df.sort_values(by="Step Id")

    # ---------------------------------
    # Write Excel to Memory
    # ---------------------------------
    output = BytesIO()

    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Workflow Steps")

    output.seek(0)

    # ---------------------------------
    # Return Downloadable File
    # ---------------------------------
    filename = f"{workflow_name.replace(' ', '_')}_steps.xlsx"

    return StreamingResponse(
        output,
        media_type=(
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        ),
        headers={
            "Content-Disposition": f"attachment; filename={filename}"
        },
    )


@router.post(
    "/pipelines/{workflow_name}/upload-step-updates",
    tags=["Workflow Developer Utility (DEV ONLY)"],
)
async def upload_step_updates_and_generate_yaml(
    workflow_name: str,
    file: UploadFile = File(...),
    db: Connection = Depends(get_db),
):
    """
    Upload Excel file containing updated step metadata
    and return updated YAML configuration.
    """

    # ---------------------------------
    # Load Existing Pipeline
    # ---------------------------------
    pipeline_config = await load_pipeline(db, workflow_name)

    if not pipeline_config:
        raise HTTPException(
            status_code=404,
            detail=f"Workflow '{workflow_name}' not found"
        )

    # ---------------------------------
    # Read Uploaded Excel
    # ---------------------------------
    try:
        contents = await file.read()

        df = pd.read_excel(BytesIO(contents))

    except Exception as e:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid Excel file: {str(e)}"
        )

    required_columns = [
        "Step Id",
        "New Step Name",
        "New Phase Name",
        "New Category Name",
        "Enable Status",
    ]

    missing_columns = [
        c for c in required_columns
        if c not in df.columns
    ]

    if missing_columns:
        raise HTTPException(
            status_code=400,
            detail=f"Missing required columns: {missing_columns}"
        )

    # ---------------------------------
    # Create Lookup from Excel
    # ---------------------------------
    excel_updates = {}

    for _, row in df.iterrows():

        step_id = row["Step Id"]

        excel_updates[step_id] = {
            "new_step_name": row.get("New Step Name"),
            "new_phase_name": row.get("New Phase Name"),
            "new_category_name": row.get("New Category Name"),
            "enable_status": row.get("Enable Status"),
        }

    # ---------------------------------
    # Update Pipeline Steps
    # ---------------------------------
    updated_steps_count = 0

    for step in pipeline_config.get("steps", []):

        meta = step.get("meta", {})
        execution = step.get("execution", {})

        step_id = meta.get("step_id")

        if step_id not in excel_updates:
            continue

        update_data = excel_updates[step_id]

        # -----------------------------
        # Update Step Name
        # -----------------------------
        if pd.notna(update_data["new_step_name"]):
            meta["name"] = str(update_data["new_step_name"]).strip()

        # -----------------------------
        # Update Phase Name
        # -----------------------------
        if pd.notna(update_data["new_phase_name"]):
            meta["phase_name"] = str(update_data["new_phase_name"]).strip()

        # -----------------------------
        # Update Category
        # -----------------------------
        if pd.notna(update_data["new_category_name"]):

            category_raw = str(
                update_data["new_category_name"]
            ).strip()

            # Convert comma-separated category to list
            categories = [
                c.strip()
                for c in category_raw.split(",")
                if c.strip()
            ]

            meta["category"] = categories

        # -----------------------------
        # Update Enable Status
        # -----------------------------
        enable_status = update_data["enable_status"]

        if pd.notna(enable_status):

            if isinstance(enable_status, str):
                enable_status = enable_status.strip().upper() == "TRUE"

            execution["is_enabled"] = bool(enable_status)

        updated_steps_count += 1

    # ---------------------------------
    # Convert Updated Config to YAML
    # ---------------------------------
    yaml_content = yaml.dump(
        pipeline_config,
        sort_keys=False,
        allow_unicode=True,
    )

    yaml_bytes = io.BytesIO()
    yaml_bytes.write(yaml_content.encode("utf-8"))
    yaml_bytes.seek(0)

    # ---------------------------------
    # Optional Save Updated Pipeline
    # ---------------------------------
    updated_info = (
        f"Bulk step metadata updated using uploaded Excel file. "
        f"Updated Steps: {updated_steps_count}"
    )

    # await save_pipeline(
    #     db,
    #     workflow_name,
    #     pipeline_config,
    #     user_info.user_id,
    #     updated_info,
    # )

    # ---------------------------------
    # Return YAML File
    # ---------------------------------
    filename = f"{workflow_name}_updated.yaml"

    return StreamingResponse(
        yaml_bytes,
        media_type="application/x-yaml",
        headers={
            "Content-Disposition": f"attachment; filename={filename}"
        },
    )