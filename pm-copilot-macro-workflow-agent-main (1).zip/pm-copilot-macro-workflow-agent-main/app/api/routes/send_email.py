"""
Email Router — Async Background Email Sender

Endpoints
---------
POST   /email/send-workflow-step   -> start email job
GET    /email/status/{token_id}    -> check job status
"""

import uuid
import asyncio
from datetime import datetime
from typing import List, Optional, Dict, Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel
from asyncpg import Connection

from app.services.email_service import send_workflow_step_email, AllowedSites, send_simple_email
from app.db.pool import get_db, get_connection


router = APIRouter(prefix="/email", tags=["Email"])


# ---------------------------------------------------------------------------
# In-memory job store
# ---------------------------------------------------------------------------

EMAIL_JOBS: Dict[str, Dict[str, Any]] = {}


def log(message: str):
    print(f"[EMAIL_JOB] {datetime.now().isoformat()} | {message}")


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

class SendWorkflowStepEmailRequest(BaseModel):
    workflow_name: str
    step_id: int
    to_list: List[str]
    cc_list: List[str] = []
    bcc_list: List[str] = []
    allowed_sites: AllowedSites = "ALL"

    # NEW
    is_recurring: bool = False
    schedule_time: Optional[str] = None

class EmailJobStartResponse(BaseModel):
    token_id: str
    status: str


# class EmailJobStatusResponse(BaseModel):
#     token_id: str
#     status: str
#     result: Optional[Dict[str, Any]] = None
#     error: Optional[str] = None

class EmailJobStatusResponse(BaseModel):
    token_id: str
    status: str
    stage: str
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

class SendSimpleEmailRequest(BaseModel):
    to_list: List[str]
    cc_list: List[str] = []
    bcc_list: List[str] = []
    subject: str
    email_body: str

# ---------------------------------------------------------------------------
# Background job runner
# ---------------------------------------------------------------------------

# {
#   "workflow_name": "AHLOA Workflow Updated",
#   "step_id": 11,
#   "to_list": ["talib.raza.ext@nokia.com"],
#   "allowed_sites": "PASS",
#   "is_recurring": true,
#   "schedule_time": "09:30"
# }

async def save_email_schedule(token_id: str, request: SendWorkflowStepEmailRequest):

    query = """
    INSERT INTO pwc_workflow_agent_schema.workflow_email_schedule
    (
        token_id,
        workflow_name,
        step_id,
        allowed_sites,
        to_list,
        cc_list,
        bcc_list,
        is_recurring,
        schedule_time
    )
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
    """

    try:
        schedule_time = None

        if request.schedule_time:
            schedule_time = datetime.strptime(
                request.schedule_time,
                "%H:%M"
            ).time()

        async with get_connection() as db:
            await db.execute(
                query,
                token_id,
                request.workflow_name,
                request.step_id,
                request.allowed_sites,
                request.to_list,
                request.cc_list,
                request.bcc_list,
                request.is_recurring,
                schedule_time,
            )

    except Exception as e:
        raise RuntimeError(f"Email scheduling failed: {str(e)}")
    

async def run_email_job(
    token_id: str,
    request: SendWorkflowStepEmailRequest,
):

    EMAIL_JOBS[token_id]["status"] = "RUNNING"
    EMAIL_JOBS[token_id]["stage"] = "INITIALIZING"

    try:

        # async with get_connection() as db:

        EMAIL_JOBS[token_id]["stage"] = "LOADING_WORKFLOW"

        # call service
        result = await send_workflow_step_email(
            workflow_name=request.workflow_name,
            step_id=request.step_id,
            to_list=request.to_list,
            cc_list=request.cc_list,
            bcc_list=request.bcc_list,
            allowed_sites=request.allowed_sites,
            progress_callback=lambda stage: EMAIL_JOBS[token_id].update(
                {"stage": stage}
            ),
        )

        EMAIL_JOBS[token_id]["status"] = result.get("status", "COMPLETED")
        EMAIL_JOBS[token_id]["stage"] = "COMPLETED"
        EMAIL_JOBS[token_id]["result"] = result

    except Exception as e:

        EMAIL_JOBS[token_id]["status"] = "FAILED"
        EMAIL_JOBS[token_id]["stage"] = "FAILED"
        EMAIL_JOBS[token_id]["error"] = str(e)


# ---------------------------------------------------------------------------
# Start Email Job Endpoint
# ---------------------------------------------------------------------------

@router.post(
    "/send-workflow-step",
    response_model=EmailJobStartResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Start workflow step email job",
)
async def send_workflow_step_email_endpoint(
    request: SendWorkflowStepEmailRequest,
):

    token_id = str(uuid.uuid4())

    if request.is_recurring:

        if not request.schedule_time:
            raise HTTPException(
                status_code=400,
                detail="schedule_time required for recurring emails"
            )

        await save_email_schedule(token_id, request)

        return {
            "token_id": token_id,
            "status": "SCHEDULED"
        }


    # EMAIL_JOBS[token_id] = {
    #     "status": "PENDING",
    #     "result": None,
    #     "error": None,
    # }

    EMAIL_JOBS[token_id] = {
        "status": "PENDING",
        "stage": "JOB_CREATED",
        "result": None,
        "error": None,
    }

    asyncio.create_task(
        run_email_job(
            token_id,
            request,
        )
    )

    return {
        "token_id": token_id,
        "status": "PENDING",
    }

# ---------------------------------------------------------------------------
# Job Status Endpoint
# ---------------------------------------------------------------------------

@router.get(
    "/status/{token_id}",
    response_model=EmailJobStatusResponse,
    summary="Check email job status",
)
async def get_email_job_status(token_id: str):

    job = EMAIL_JOBS.get(token_id)

    if not job:
        raise HTTPException(
            status_code=404,
            detail="Token ID not found",
        )

    # return {
    #     "token_id": token_id,
    #     "status": job["status"],
    #     "result": job.get("result"),
    #     "error": job.get("error"),
    # }

    return {
        "token_id": token_id,
        "status": job["status"],
        "stage": job.get("stage"),
        "result": job.get("result"),
        "error": job.get("error"),
    }

@router.post(
    "/send",
    summary="Send simple email",
)
async def send_simple_email_endpoint(
    request: SendSimpleEmailRequest,
):

    try:

        result = await send_simple_email(
            to_list=request.to_list,
            cc_list=request.cc_list,
            bcc_list=request.bcc_list,
            subject=request.subject,
            email_body=request.email_body,
            attachments=None,
        )

        return result

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Email send failed: {str(e)}",
        )