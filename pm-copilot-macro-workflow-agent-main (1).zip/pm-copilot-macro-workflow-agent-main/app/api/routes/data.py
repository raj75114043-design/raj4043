"""
Data management endpoints for loading and querying site data.
"""

from typing import List, Dict, Any,  Set, Union
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from asyncpg import Connection
import tempfile
import os
import uuid
from datetime import datetime
from uuid import uuid4
from app.db.pool import get_db, get_connection
from app.services.data_sites import get_list_of_primary_key
from app.schemas.workflow import MessageResponse
from app.core.data_fetch_config import BASE_SCHEMA
from app.services.data_sites import(
        get_cached_primary_key,
        get_cached_base_table,
        get_cached_global_filter_columns,
)
from app.config.pipeline_storage import (
    load_pipeline,
    pipeline_exists
)
from app.schemas.data import (
    GlobalFiltersResponse,
    GlobalFiltersResponseUpdated,
    WorkflowKeyCountResponse,
    ChatDefaultQueries,
    AddUsersPMCoPilotRequest,
)

from app.services.update_staging_table import (
    updated_staging_tables,
    JOB_STORE,
)

from app.schemas.workflow import UserInfoRequest

router = APIRouter(prefix="/data", tags=["Data"])


LOG_TABLES = [
    "workflow_dev_chatbot_logs",
    "workflow_email_sent_history",
    "workflow_modification_agent_logs",
    "workflow_yaml_dump",
    "workflow_yaml_pipelines",
    "staging_table_execution_log"
]


def _extract_name_from_email(email: str) -> str:
    local_part = email.split("@")[0]
    parts = [p for p in local_part.split(".") if p.lower() != "ext"]
    return " ".join(p.capitalize() for p in parts)

def _extract_global_filters_from_pipeline(pipeline_config: dict):
    steps = pipeline_config.get("steps", [])

    # Find starting step (depends_on == [])
    start_step = None
    for step in steps:
        depends_on = step.get("execution", {}).get("depends_on", [])
        if not depends_on:
            start_step = step
            break

    if not start_step:
        return None, []

    rules = start_step.get("filter_criteria", {}).get("rules", [])

    if not rules:
        return None, []

    # 2. Find base table from primary_key operator
    base_table = None
    for rule in rules:
        if rule.get("operator") == "primary_key":
            base_table = rule.get("source_table")
            break

    if not base_table:
        return None, []

    # Extract global filter columns from same base table
    global_filter_columns = [
        rule.get("column_name")
        for rule in rules
        if rule.get("operator") == "global_filter"
        and rule.get("source_table") == base_table
    ]

    return base_table, global_filter_columns


@router.get("/workflow_input_flowing_keys/{worklfow_name}", response_model=WorkflowKeyCountResponse)
async def workflow_input_flow_keys(workflow_name: str, db: Connection = Depends(get_db)):
    """Get all site codes from the database."""
    try:
        base_schema = BASE_SCHEMA
        keys = await get_list_of_primary_key(db, workflow_name)
        primary_key_column = get_cached_primary_key(workflow_name)
        base_table = get_cached_base_table(workflow_name)
        return {
            "workflow": workflow_name,
            "count": len(keys),
            "primary_key": primary_key_column,
            "table": base_table,
            "base_schema": base_schema
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get primary keys: {e}")


@router.get("/workflow_table_info/{workflow_name}")
async def get_available_staging_tables_info(
    workflow_name: str,  # kept intentionally (future use: auth, routing, lineage)
    db: Connection = Depends(get_db),
):
    """
    Returns schema, table, column name, and data type
    for all tables available in the backend schema.
    """
    try:
        records = await db.fetch(
            """
            SELECT
                table_schema AS schema_name,
                table_name,
                column_name,
                data_type
            FROM information_schema.columns
            WHERE table_schema = $1
            ORDER BY table_name, ordinal_position
            """,
            BASE_SCHEMA,
        )

        if not records:
            return {
                "workflow": workflow_name,
                "table_count": 0,
                "tables": [],
                "message": "No tables or columns found in schema",
            }

        tables_map: dict[str, dict] = {}

        for row in records:
            table_name = row["table_name"]

            if table_name not in tables_map:
                tables_map[table_name] = {
                    "table_name": table_name,
                    "schema_name": row["schema_name"],
                    "columns": [],
                }

            tables_map[table_name]["columns"].append(
                {
                    "column_name": row["column_name"],
                    "data_type": row["data_type"],
                }
            )

        return {
            "workflow": workflow_name,
            "table_count": len(tables_map),
            "tables": list(tables_map.values()),
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch table metadata: {e}",
        )


@router.post("/update_staging_tables/run")
async def update_postgre_staging_tables(tables_requested: List[str], user_info: UserInfoRequest, background_tasks: BackgroundTasks):
    

    job_id = str(uuid4())
    user_id = user_info.user_id

    JOB_STORE[job_id] = {
        "status": "running",
        "phase": "schema_validation",
        "total_tables": len(tables_requested),
        "tables_requested": tables_requested,
        "processed": 0,
        "success": 0,
        "skipped": 0,
        "schema_mismatched_tables": [],
        "started_at": datetime.now().isoformat(),
        "completed_at": None
    }

    background_tasks.add_task(updated_staging_tables, job_id, tables_requested)

    return {
        "token_id": job_id,
        "status": "started",
        "message": "Schema validation started"
    }


@router.get("/update_staging_tables/status/{token_id}")
async def staging_tables_update_status(token_id: str):

    job = JOB_STORE.get(token_id)

    if not job:
        return {"status": "invalid_token"}

    return job



@router.get("/tables/details")
async def get_details_for_specific_table(
    schema_name: str,
    table_name: str,
    limit: int = 5,
    offset: int = 0,
    db: Connection = Depends(get_db),
):
    """
    Preview table metadata and sample data.
    """

    try:
        #Validate table exists
        table_exists = await db.fetchval(
            """
            SELECT EXISTS (
                SELECT 1
                FROM information_schema.tables
                WHERE table_schema = $1
                  AND table_name = $2
            )
            """,
            schema_name,
            table_name,
        )

        if not table_exists:
            raise HTTPException(
                status_code=404,
                detail=f"Table '{schema_name}.{table_name}' not found",
            )

        #Total row count
        total_rows = await db.fetchval(
            f'''
            SELECT COUNT(*)
            FROM "{schema_name}"."{table_name}"
            '''
        )

        #Column metadata
        columns = await db.fetch(
            """
            SELECT
                column_name,
                data_type
            FROM information_schema.columns
            WHERE table_schema = $1
              AND table_name = $2
            ORDER BY ordinal_position
            """,
            schema_name,
            table_name,
        )

        column_info = [
            {"column_name": c["column_name"], "data_type": c["data_type"]}
            for c in columns
        ]

        #Top rows preview
        rows = await db.fetch(
            f'''
            SELECT *
            FROM "{schema_name}"."{table_name}"
            LIMIT $1 OFFSET $2
            ''',
            limit,
            offset,
        )

        preview_data = [dict(r) for r in rows]

        return {
            "schema": schema_name,
            "table": table_name,
            "total_rows": total_rows,
            "total_columns": len(column_info),
            "columns": column_info,
            "preview_rows_count": len(preview_data),
            "preview_data": preview_data,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch table preview: {e}",
        )


@router.get("/workflow_used_tables/{workflow_name}")
async def get_workflow_used_tables(
    workflow_name: str,
    db: Connection = Depends(get_db),  # db kept for consistency / future use
):
    """
    Returns only the table names and schema names used in a workflow.
    """
    try:
        pipeline_config = await load_pipeline(db, workflow_name)
        
        if not pipeline_config:
            raise HTTPException(
                status_code=404,
                detail=f"Workflow '{workflow_name}' not found",
            )

        used_tables: Set[tuple[str, str]] = set()

        for step in pipeline_config.get("steps", []):
            filter_criteria = step.get("filter_criteria", {})
            for rule in filter_criteria.get("rules", []):
                table_name = rule.get("source_table")
                # schema_name = rule.get("schema_name", DEFAULT_SCHEMA)

                if table_name:
                    used_tables.add((BASE_SCHEMA, table_name))

        return {
            "workflow": workflow_name,
            "table_count": len(used_tables),
            "tables": [
                {
                    "schema_name": schema,
                    "table_name": table,
                }
                for schema, table in sorted(used_tables)
            ],
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch workflow used tables: {e}",
        )



@router.get("/global_filters_updated_new/{workflow_name}", response_model=GlobalFiltersResponseUpdated)
async def get_global_filters_info_updated_new(
    workflow_name: str,
    db: Connection = Depends(get_db),
):
    """
    Returns distinct global filters as flat rows (dataframe-style JSON).
    Fully dynamic based on cached global filter columns.
    """
    try:
        pipeline_config = await load_pipeline(db, workflow_name)
        
        if not pipeline_config:
            raise HTTPException(
                status_code=404,
                detail=f"Workflow '{workflow_name}' not found",
            )
        
        # Fetch from cache
        base_table, global_filter_columns = _extract_global_filters_from_pipeline(pipeline_config)

        if not global_filter_columns:
            return {"workflow": workflow_name, "filters": []}

        # Maintain order of columns
        columns_sql = ", ".join([f'"{col}"' for col in global_filter_columns])

        # Build query dynamically
        query = f"""
        SELECT DISTINCT {columns_sql}
        FROM {BASE_SCHEMA}.{base_table}
        ORDER BY {columns_sql}
        """

        records = await db.fetch(query)

        # Convert records to JSON-friendly dict
        filters = [
            {col: str(row[col]) if row[col] is not None else None for col in global_filter_columns}
            for row in records
        ]

        return {
            "workflow": workflow_name,
            "filters": filters
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch global filter values: {e}",
        )
    


# ====================================
# ----------- OUTPUT TABLE AI ASSISTANT----------------
# ======================================


@router.get(
    "/pipelines/{workflow_name}/output_table/ai_assistant/default_queries", response_model=ChatDefaultQueries
)
async def get_ai_assistant_default_queries(workflow_name: str, db: Connection = Depends(get_db)):
    """Remove a filter rule from a workflow step."""

    if not await pipeline_exists(db, workflow_name):
        raise HTTPException(
            status_code=404,
            detail=f"Pipeline '{workflow_name}' not found"
        )

    Default_question: Dict[int, str] = {
        1: "Show Distribution of sites Market wise.",
        2: "How many sites available in each region ?",
        3: "Distribution of Failed sites market wise.",
        4: "How many sites qualified and show graph region wise.",
    }

    response = Default_question

    return ChatDefaultQueries(
        questions=response
    )



@router.post("/add/user/pm_copilot/users")
async def add_user_pm_copilot(
    user_info: UserInfoRequest, 
    request: AddUsersPMCoPilotRequest,
    db: Connection = Depends(get_db),
):
    try:
        user_id = user_info.user_id
        user_ids = request.user_ids

        if isinstance(user_ids, str):
            user_ids = [user_ids]

        valid_records = []
        skipped_users = []

        for email in user_ids:
            if not email.endswith("@nokia.com"):
                skipped_users.append(email)
                continue

            name = _extract_name_from_email(email)

            # tuple must match query placeholders
            valid_records.append((name, email, "1234", 1))


        if valid_records:
            query = """
                INSERT INTO osdp_pwc_sch.users (name, email, password, role_id)
                VALUES ($1, $2, $3, $4)
                ON CONFLICT (email) DO NOTHING
            """

            await db.executemany(query, valid_records)
        else:
            return {
                "valid_user_ids": len(valid_records),
                "skipped_users": skipped_users,
                "status": "FAILED"
            }

        return {
            "added_count": len(valid_records),
            "added_users": [
                {"email": r[1], "name": r[0]} for r in valid_records
            ],
            "skipped_users": skipped_users,
            "status": "SUCCESS"
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to Add Users: {str(e)}",
        )
    
@router.post("/workflow/modification-access")
async def get_workflow_modification_access(
    user_info: UserInfoRequest,
):
    query = """
        SELECT *
        FROM (
            SELECT
                $1 AS user_id,
                COALESCE(a.admin_access, FALSE) AS admin_access,
                w.workflow_name,

                CASE
                    WHEN COALESCE(a.admin_access, FALSE) = TRUE THEN TRUE
                    WHEN w.created_by = $1 THEN TRUE
                    WHEN w.allow_modification_to_all = TRUE THEN TRUE
                    WHEN w.allow_modification_to_all = FALSE
                        AND $1 = ANY(allow_modification_only_to)
                    THEN TRUE
                    ELSE FALSE
                END AS modification_access

            FROM pwc_workflow_agent_schema.workflow_yaml_pipelines w
            LEFT JOIN pwc_workflow_agent_schema.workflow_admin_users_list a
                ON a.email_id = $1
        ) t
        WHERE modification_access = TRUE;
    """
    async with get_connection() as db:
        rows = await db.fetch(query, user_info.user_id)

    return [
        {
            "user_id": row["user_id"],
            "admin_access": row["admin_access"],
            "workflow_name": row["workflow_name"],
            "modification_access": row["modification_access"],
        }
        for row in rows
    ]


@router.post("/workflow/admin-access")
async def get_workflow_admin_access(
    user_info: UserInfoRequest,
):

    query = """
        SELECT 
            email_id AS user_id,
            COALESCE(admin_access, FALSE) AS admin_access
        FROM pwc_workflow_agent_schema.workflow_admin_users_list
        WHERE email_id = $1
    """
    async with get_connection() as db:

        row = await db.fetchrow(query, user_info.user_id)

    return {
        "user_id": user_info.user_id,
        "admin_access": row["admin_access"] if row else False
    }


@router.get("/workflow/email-schedules")
async def get_workflow_email_schedules(
    db: Connection = Depends(get_db),
):

    try:

        query = """
            SELECT
                id,
                workflow_name,
                step_id,
                allowed_sites,
                to_list,
                cc_list,
                bcc_list,
                is_recurring,
                schedule_time,
                is_enabled,
                last_run_time,
                created_at,
                updated_at,
                mail_status,
                token_id,
                days_of_week,
                scheduled_by,
                columns_name,
                global_filters,
                schedule_time_zone
            FROM pwc_workflow_agent_schema.workflow_email_schedule
            ORDER BY created_at DESC
        """

        rows = await db.fetch(query)

        return {
            "total": len(rows),
            "data": [
                dict(row)
                for row in rows
            ]
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch workflow schedules: {str(e)}"
        )
    


# =========================================================
# DELETE WORKFLOW EMAIL SCHEDULE
# =========================================================

@router.delete("/workflow/email-schedules")
async def delete_workflow_email_schedule(
    id: int,
    db: Connection = Depends(get_db),
):

    try:

        query = """
            DELETE FROM pwc_workflow_agent_schema.workflow_email_schedule
            WHERE id = $1
        """

        result = await db.execute(
            query,
            id
        )

        return {
            "success": True,
            "message": f"Workflow email schedule deleted successfully for id={id}"
        }

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to delete workflow email schedule: {str(e)}"
        )
    


# =========================================================
# GET ALL LOG TABLE NAMES
# =========================================================

@router.get("/workflow/log-tables")
async def get_workflow_log_tables():

    return {
        "total": len(LOG_TABLES),
        "tables": LOG_TABLES
    }


# =========================================================
# GET LOG TABLE DATA
# =========================================================

@router.get("/workflow/log-table-data")
async def get_workflow_log_table_data(
    table_name: str,
    limit: int = 10,
    offset: int = 0,
    db: Connection = Depends(get_db),
):

    try:

        # =====================================================
        # VALIDATE TABLE NAME
        # =====================================================

        if table_name not in LOG_TABLES:

            raise HTTPException(
                status_code=400,
                detail=f"Invalid table name: {table_name}"
            )

        # =====================================================
        # LIMIT VALIDATION
        # =====================================================

        if limit <= 0:
            limit = 10

        if limit > 100:
            limit = 100

        if offset < 0:
            offset = 0

        # =====================================================
        # FULL TABLE NAME
        # =====================================================

        full_table_name = (
            f"pwc_workflow_agent_schema.{table_name}"
        )

        # =====================================================
        # TOTAL COUNT
        # =====================================================

        count_query = f"""
            SELECT COUNT(*) AS total
            FROM {full_table_name}
        """

        total = await db.fetchval(count_query)

        # =====================================================
        # FETCH DATA
        # =====================================================

        query = f"""
            SELECT *
            FROM {full_table_name}
            ORDER BY created_at DESC
            LIMIT $1
            OFFSET $2
        """

        rows = await db.fetch(
            query,
            limit,
            offset
        )

        # =====================================================
        # RESPONSE
        # =====================================================

        return {

            "success": True,

            "table_name": table_name,

            "pagination": {
                "limit": limit,
                "offset": offset,
                "total": total,
                "current_page": (offset // limit) + 1,
                "has_next": (offset + limit) < total
            },

            "data": [
                dict(row)
                for row in rows
            ]
        }

    except HTTPException:
        raise

    except Exception as e:

        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch log table data: {str(e)}"
        )