"""
Workflow Orchestration API routes for runtime operations.

This module provides REST endpoints for:
- Loading and executing workflow pipelines (from YAML config files)
- Step modification (mute/unmute, add/remove rules, change logic)
- LLM-assisted natural language modifications
- Workflow visualization

Note: Pipeline creation/deletion is handled by workflow_dev_functions.
This module handles runtime operations on existing pipelines.
"""

from typing import List, Dict, Any, Union
from fastapi import APIRouter, Depends, HTTPException
from asyncpg import Connection
from app.utils.save_workflow_execution import save_workflow_execution
import uuid
import asyncio
import traceback

from app.db.pool import get_db, get_connection
from app.core.llm_client import get_llm_client
from app.core.execution_store import EXECUTIONS
from pprint import pprint
from datetime import datetime
from app.schemas.workflow import (
    WorkflowStepSummary,
    StepsInfo,
    WorkflowPipelineResponse,
    StepNameChangeRequest,
    StepDescriptionChangeRequest,
    StepMuteRequest,
    StepBulkMuteRequest,
    StepLogicUpdateRequest,
    AddFilterRuleRequest,
    RemoveFilterRuleRequest,
    LLMModifyStepRequest,
    UserInfoRequest,
    WorkflowExecutionResultResponse,
    WorkflowExecuteWithIdResponse,
    WorkflowExecutionStatusEnvelope,
    StepExecutionResultResponse,
    MessageResponse,
)
from app.services.workflow_pipeline import WorkflowPipeline
from app.services.workflow_step import WorkflowStep
from app.services.load_storage_pipeline import load_latest_workflow_execution

from app.models.workflow import (
    StepMetaData,
    StepExecutionConfig,
    FilterCriteriaConfig,
    SitesFilterRule,
    ViewOutputConfig,
    ComputationConfig,
    AgentConfig,
    InputTableConfig,
)
from app.models.enums import (
    OnDisabledStrategy,
    MergeStrategy,
    ConditionalLogic,
    ValidationOperator,
)
from app.config.pipeline_storage import (
    save_pipeline,
    load_pipeline,
    list_pipelines,
    pipeline_exists,
)


# file_path = OUTPUT_DIR / f"{workflow_name.replace(' ', '_')}.json"

router = APIRouter(prefix="/workflow", tags=["Workflow Orchestration"])

# Runtime cache for loaded pipelines (loaded from YAML on demand)
_runtime_pipelines: Dict[str, WorkflowPipeline] = {}


def _create_step_from_config(step_config: dict) -> WorkflowStep:
    """Create a WorkflowStep from YAML configuration dictionary."""
    meta = StepMetaData(
        step_id=step_config["meta"]["step_id"],
        name=step_config["meta"]["name"],
        description=step_config["meta"]["description"],
        phase_id = step_config["meta"]["phase_id"],
        phase_name = step_config["meta"]["phase_name"],
        category = step_config["meta"].get("category", [])
    )

    execution = StepExecutionConfig(
        is_enabled=step_config["execution"].get("is_enabled", True),
        on_disabled=OnDisabledStrategy(step_config["execution"].get("on_disabled", "passthrough")),
        depends_on=step_config["execution"].get("depends_on", []),
        merge_strategy=MergeStrategy(step_config["execution"].get("merge_strategy", "union")),
    )

    filter_criteria = None
    if "filter_criteria" in step_config and step_config["filter_criteria"]:
        fc = step_config["filter_criteria"]
        rules = [
            SitesFilterRule(
                source_table=r["source_table"],
                primary_key_column=r["primary_key_column"],
                column_name=r["column_name"],
                operator=ValidationOperator(r["operator"]),
                expected_value=r.get("expected_value"),
                description=r.get("description", ""),
            )
            for r in fc.get("rules", [])
        ]
        filter_criteria = FilterCriteriaConfig(
            enabled=fc.get("enabled", True),
            conditional_logic=ConditionalLogic(fc.get("conditional_logic", "and")),
            rules=rules,
        )

    view_output = None
    if "view_output" in step_config and step_config["view_output"]:
        vo = step_config["view_output"]
        view_output = ViewOutputConfig(
            is_enabled=vo.get("is_enabled", True)
        )

    computation = None
    if "computation" in step_config and step_config["computation"]:
        comp = step_config["computation"]
        computation = ComputationConfig(
            is_enabled=comp.get("is_enabled", False),
            computations=comp.get("computations", []),
        )

    agent = None
    if "agent" in step_config and step_config["agent"]:
        ag = step_config["agent"]
        agent = AgentConfig(
            is_enabled=ag.get("is_enabled", False),
            agents=ag.get("agents", []),
        )

    return WorkflowStep(
        meta=meta,
        execution=execution,
        filter_criteria=filter_criteria,
        view_output=view_output,
        computation=computation,
        agent=agent,
    )


async def _load_workflow_from_yaml(workflow_name: str) -> WorkflowPipeline:
    """Load a workflow from YAML file and cache it for runtime use."""
    
    async with get_connection() as db:
        pipeline_config = await load_pipeline(db, workflow_name)

    if not pipeline_config:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{workflow_name}' not found"
        )

    llm_client = get_llm_client("medium")
    workflow = WorkflowPipeline(name=pipeline_config["name"], llm_client=llm_client)

    for step_config in pipeline_config.get("steps", []):
        step = _create_step_from_config(step_config)
        workflow.add_step(step)

    return workflow


async def _get_workflow(workflow_name: str) -> WorkflowPipeline:
    """Get a workflow by name, loading from YAML if not cached."""
    # if workflow_name not in _runtime_pipelines:
    #     _runtime_pipelines[workflow_name] = _load_workflow_from_yaml(workflow_name)

    _runtime_pipelines[workflow_name] = await _load_workflow_from_yaml(workflow_name)

    return _runtime_pipelines[workflow_name]


async def _reload_workflow(workflow_name: str) -> WorkflowPipeline:
    """Force reload a workflow from YAML file."""
    if workflow_name in _runtime_pipelines:
        del _runtime_pipelines[workflow_name]
    return await _get_workflow(workflow_name)


async def run_workflow_background(
    execution_id: str,
    workflow_name: str,
    user_id: str
):
    try:
        EXECUTIONS[execution_id]["status"] = "RUNNING"
        async with get_connection() as db:
            workflow = await _get_workflow(workflow_name)
            result = await workflow.execute(workflow_name, db,  execution_id=execution_id)

            # workflow = await _get_workflow(workflow_name)
            # result = await workflow.execute(db)

            response = WorkflowExecutionResultResponse(
                workflow_name=result.workflow_name,
                initial_count=result.initial_count,
                final_count=result.final_count,
                steps_executed=result.steps_executed,
                step_results=[
                    StepExecutionResultResponse.model_validate(r)
                    for r in result.step_results
                ],
                timestamp=result.timestamp,
            )

            await save_workflow_execution(db, workflow_name, response.to_dict(), user_id)

        EXECUTIONS[execution_id].update(
            {
                "status": "COMPLETED",
                "finished_at": datetime.now(),
                "data": response,
            }
        )

    except Exception as e:
        EXECUTIONS[execution_id].update(
            {
                "status": "FAILED",
                "finished_at": datetime.now(),
                "error": str(e),
                "trace": traceback.format_exc(),
            }
        )

# ============================================================================
# Pipeline Management Endpoints
# ============================================================================

@router.get("/pipelines/{user_id}", response_model=List[str])
async def list_all_pipelines(user_id: str):
    """List all available workflow pipelines (from YAML files)."""
    async with get_connection() as db:
        return await list_pipelines(db, user_id)


@router.get("/pipeline_summary/{workflow_name}", response_model=WorkflowPipelineResponse)
async def get_pipeline_summary(workflow_name: str):
    """Get a workflow pipeline Summary."""
    workflow = await _get_workflow(workflow_name)
    config = workflow.get_pipeline_config()

    return WorkflowPipelineResponse(
        name=config["name"],
        total_steps=config["total_steps"],
        steps=[WorkflowStepSummary(**s) for s in config["steps"]],
    )



@router.post("/pipelines/{workflow_name}/reload", response_model=MessageResponse)
async def reload_pipeline(workflow_name: str):

    """Reload a pipeline from its YAML file (discards runtime modifications)."""
    async with get_connection() as db:
        if not await pipeline_exists(db, workflow_name):
            raise HTTPException(
                status_code=404, detail=f"Workflow '{workflow_name}' not found"
            )

    await _reload_workflow(workflow_name)
    return MessageResponse(message=f"Workflow '{workflow_name}' reloaded from configuration")


# ============================================================================
# Step Management Endpoints
# ============================================================================


@router.get(
    "/pipelines/{workflow_name}/steps/{step_id}", response_model=StepsInfo
)
async def get_step_info(workflow_name: str, step_id: int):
    """Get a specific step from a workflow."""
    workflow = await _get_workflow(workflow_name)
    step = workflow.get_step(step_id)

    if not step:
        raise HTTPException(status_code=404, detail=f"Step {step_id} not found")

    summary = step.get_step_detail()
    return StepsInfo(**summary)



@router.post(
    "/pipelines/{workflow_name}/execute_with_id",
    response_model=WorkflowExecuteWithIdResponse,
)
async def execute_workflow(
    workflow_name: str,
    user_info: UserInfoRequest
): 
    user_id = user_info.user_id
    execution_id = str(uuid.uuid4())

    EXECUTIONS[execution_id] = {
        "execution_id": execution_id,
        "workflow_name": workflow_name,
        "status": "PENDING",
        "started_at": datetime.now(),
        "finished_at": None,
        "completed_step_ids": [],
        "running_step_id": None,
        "data": None,
        "error": None,
    }

    asyncio.create_task(
        run_workflow_background(execution_id, workflow_name, user_id)
    )

    return WorkflowExecuteWithIdResponse(
        execution_id=execution_id,
        status= "RUNNING",
    )


@router.get(
    "/pipelines/executions_with_id_status/{execution_id}",
    response_model=WorkflowExecutionStatusEnvelope,
)
async def get_execution_status(execution_id: str):
    execution = EXECUTIONS.get(execution_id)

    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")

    status = execution.get("status", "")

    if "FAILED" in status:
        raise HTTPException(
            status_code=500,
            detail=execution.get("error", "Execution failed"),
        )

    return WorkflowExecutionStatusEnvelope(
        execution_id=execution_id,
        status=execution["status"],
        completed_step_ids=execution["completed_step_ids"],
        running_step_id=execution["running_step_id"],
        data=execution.get("data"), 
    )


@router.post(
    "/pipelines/{workflow_name}/execute", response_model=WorkflowExecutionResultResponse
)
async def execute_workflow(
    workflow_name: str,
    user_info: UserInfoRequest,
    db: Connection = Depends(get_db),
):
    """Execute a workflow pipeline with the given site codes."""

    user_id = user_info.user_id
    workflow = await _get_workflow(workflow_name)

    try:
        result = await workflow.execute(workflow_name, db)
        response = WorkflowExecutionResultResponse(
            workflow_name=result.workflow_name,
            initial_count=result.initial_count,
            final_count=result.final_count,
            steps_executed=result.steps_executed,
            step_results=[
                StepExecutionResultResponse.model_validate(r)
                for r in result.step_results
            ],
            timestamp=result.timestamp,
        )

        await save_workflow_execution(db, workflow_name, response.to_dict(), user_id)
        
        return response

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Workflow execution failed: {str(e)}"
        )
        
@router.get(
    "/workflow_executed_pipeline/{workflow_name}",
    response_model=WorkflowExecutionResultResponse,
)
async def get_executed_pipeline(workflow_name: str):
    """Get the last executed workflow pipeline summary."""

    try:
        async with get_connection() as db:
            execution_data = await load_latest_workflow_execution(db, workflow_name)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))

    #Rehydrate into the SAME response model
    return WorkflowExecutionResultResponse.model_validate(execution_data)

@router.get("/pipelines/{workflow_name}/visualize")
async def visualize_workflow(workflow_name: str):
    """Get a text visualization of the workflow."""
    workflow = await _get_workflow(workflow_name)
    return {"visualization": workflow.visualize_flow()}



# ============================================================================
# Step Modification Endpoints
# ============================================================================


@router.post(
    "/pipelines/{workflow_name}/steps/update-name", response_model=MessageResponse
)
async def update_step_name(workflow_name: str, user_info: UserInfoRequest, request: StepNameChangeRequest, db: Connection = Depends(get_db)):
    """Update the filter logic (AND/ANY) for a step."""
    workflow = await _get_workflow(workflow_name)
    step = workflow.get_step(request.step_id)

    if not step:
        raise HTTPException(status_code=404, detail=f"Step {request.step_id} not found")

    step.meta.name = request.new_name

    workflow_dict = {
        "name": workflow.name,
        "version": "Latest",
        "generated_at": datetime.now().isoformat(),
        "steps": [step.to_dict() for step in workflow.steps],
    }

    user_id = user_info.user_id
    updated_info = f"Step Name Change to ({request.new_name}) for Step: {request.step_id}"
    await save_pipeline(db, workflow.name, workflow_dict, user_id, updated_info)

    return MessageResponse(
        message=f"Step Name Change to {request.new_name} for step '{step.meta.name}'"
    )


@router.post(
    "/pipelines/{workflow_name}/steps/update-description", response_model=MessageResponse
)
async def update_step_description(workflow_name: str, user_info: UserInfoRequest, request: StepDescriptionChangeRequest, db: Connection = Depends(get_db)):
    """Update the filter logic (AND/ANY) for a step."""
    workflow = await _get_workflow(workflow_name)
    step = workflow.get_step(request.step_id)

    if not step:
        raise HTTPException(status_code=404, detail=f"Step {request.step_id} not found")

    step.meta.description = request.new_description

    workflow_dict = {
        "name": workflow.name,
        "version": "Latest",
        "generated_at": datetime.now().isoformat(),
        "steps": [step.to_dict() for step in workflow.steps],
    }

    user_id = user_info.user_id
    updated_info = f"Step Description Change to ({request.new_description}) for Step: {request.step_id}"
    await save_pipeline(db, workflow.name, workflow_dict, user_id, updated_info)

    return MessageResponse(
        message=f"Step Description Change to {request.new_description} for step '{step.meta.name}'"
    )



@router.post(
    "/pipelines/{workflow_name}/steps/bulkmute_unmute",response_model=MessageResponse)
async def bulk_mute_steps(workflow_name: str, user_info: UserInfoRequest, request: StepBulkMuteRequest, db: Connection = Depends(get_db)):
    """Mute/unmute multiple workflow steps with individual flags."""
    workflow = await _get_workflow(workflow_name)

    not_found = []
    muted = []
    unmuted = []

    for item in request.steps:
        step = workflow.get_step(item.step_id)
        if not step:
            not_found.append(item.step_id)
            continue

        if item.mute:
            step.mute()
            muted.append(step.meta.step_id)
        else:
            step.unmute()
            unmuted.append(step.meta.step_id)

    if not muted and not unmuted:
        raise HTTPException(
            status_code=404,
            detail=f"No valid steps found. Missing: {not_found}",
        )

    workflow_dict = {
        "name": workflow.name,
        "version": "Latest",
        "generated_at": datetime.now().isoformat(),
        "steps": [step.to_dict() for step in workflow.steps],
    }
    
    user_id = user_info.user_id
    updated_info = f"Bulk Muted/Action Muted : Muted - [{muted}, Unmuted - [{unmuted}]]"
    await save_pipeline(db, workflow.name, workflow_dict, user_id, updated_info)

    message = (
        f"Muted: {muted}, "
        f"Unmuted: {unmuted}"
    )
    if not_found:
        message += f", Not found: {not_found}"

    return MessageResponse(message=message)



@router.post("/pipelines/{workflow_name}/steps/mute", response_model=MessageResponse)
async def mute_step(workflow_name: str, user_info: UserInfoRequest, request: StepMuteRequest, db: Connection = Depends(get_db)):
    """Mute or unmute a workflow step."""
    workflow = await _get_workflow(workflow_name)
    step = workflow.get_step(request.step_id)

    if not step:
        raise HTTPException(status_code=404, detail=f"Step {request.step_id} not found")

    if request.mute:
        step.mute()
        action = "muted"
    else:
        step.unmute()
        action = "unmuted"

    workflow_dict = {
        "name": workflow.name,
        "version": "Latest",
        "generated_at": datetime.now().isoformat(),
        "steps": [step.to_dict() for step in workflow.steps],
    }
    user_id = user_info.user_id
    updated_info = f"Step: {request.step_id} - {action}"
    await save_pipeline(db, workflow.name, workflow_dict, user_id, updated_info)

    return MessageResponse(message=f"Step '{step.meta.name}' has been {action}")


@router.post(
    "/pipelines/{workflow_name}/steps/update-logic", response_model=MessageResponse
)
async def update_step_logic(workflow_name: str, user_info: UserInfoRequest, request: StepLogicUpdateRequest, db: Connection = Depends(get_db)):
    """Update the filter logic (AND/ANY) for a step."""
    workflow = await _get_workflow(workflow_name)
    step = workflow.get_step(request.step_id)

    if not step:
        raise HTTPException(status_code=404, detail=f"Step {request.step_id} not found")

    step.update_filter_logic(request.require_all)
    logic = "AND" if request.require_all else "ANY"

    workflow_dict = {
        "name": workflow.name,
        "version": "Latest",
        "generated_at": datetime.now().isoformat(),
        "steps": [step.to_dict() for step in workflow.steps],
    }

    user_id = user_info.user_id
    updated_info = f"Updated Step Logic to ({logic}) for Step: {request.step_id}"
    await save_pipeline(db, workflow.name, workflow_dict, user_id, updated_info)

    return MessageResponse(
        message=f"Filter logic updated to {logic} for step '{step.meta.name}'"
    )


@router.post(
    "/pipelines/{workflow_name}/steps/add-rule", response_model=MessageResponse
)
async def add_filter_rule(workflow_name: str, user_info: UserInfoRequest, request: AddFilterRuleRequest, db: Connection = Depends(get_db)):
    """Add a filter rule to a workflow step."""
    workflow = await _get_workflow(workflow_name)
    step = workflow.get_step(request.step_id)
    user_id = user_info.user_id

    if not step:
        raise HTTPException(status_code=404, detail=f"Step {request.step_id} not found")

    rule = SitesFilterRule(
        source_table=request.rule.source_table,
        primary_key_column=request.rule.primary_key_column,
        column_name=request.rule.column_name,
        operator=ValidationOperator(request.rule.operator),
        expected_value=request.rule.expected_value,
        description=request.rule.description,
    )

    step.add_filter_rule(rule)

    workflow_dict = {
        "name": workflow.name,
        "version": "Latest",
        "generated_at": datetime.now().isoformat(),
        "steps": [step.to_dict() for step in workflow.steps],
    }
    updated_info = f"Added a Filter Rule ({rule}) for Step: {request.step_id}"
    await save_pipeline(db, workflow.name, workflow_dict, user_id, updated_info)

    return MessageResponse(message=f"Filter rule added to step '{step.meta.name}'")


@router.post(
    "/pipelines/{workflow_name}/steps/remove-rule", response_model=MessageResponse
)
async def remove_filter_rule(workflow_name: str, user_info: UserInfoRequest, request: RemoveFilterRuleRequest, db: Connection = Depends(get_db)):
    """Remove a filter rule from a workflow step."""
    workflow = await _get_workflow(workflow_name)
    step = workflow.get_step(request.step_id)
    user_id = user_info.user_id

    if not step:
        raise HTTPException(status_code=404, detail=f"Step {request.step_id} not found")

    if not step.remove_filter_rule(request.rule_index):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid rule index {request.rule_index}",
        )

    workflow_dict = {
        "name": workflow.name,
        "version": "Latest",
        "generated_at": datetime.now().isoformat(),
        "steps": [step.to_dict() for step in workflow.steps],
    }
    
    updated_info = f"Removed Filter Rule ({request.rule_index + 1}) for Step: {request.step_id} "
    await save_pipeline(db, workflow.name, workflow_dict, user_id, updated_info)
    
    return MessageResponse(
        message=f"Filter rule {request.rule_index} removed from step '{step.meta.name}'"
    )
