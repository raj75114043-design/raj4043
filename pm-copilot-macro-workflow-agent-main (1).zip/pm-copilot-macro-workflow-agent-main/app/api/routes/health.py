"""Health check endpoints."""

from datetime import datetime
from fastapi import APIRouter
import os
# import psutil

from app.db.pool import DatabasePool
from app.schemas.workflow import HealthCheckResponse

router = APIRouter(tags=["Health"])



@router.get("/health", response_model=HealthCheckResponse)
async def health_check():
    """Check the health of the application and database connection."""
    db_healthy = await DatabasePool.health_check()

    # process = psutil.Process(os.getpid())

    # mem_info = process.memory_info()

    # print(f"RSS (MB): {mem_info.rss / 1024 / 1024:.2f}")
    # print(f"VMS (MB): {mem_info.vms / 1024 / 1024:.2f}")


    return HealthCheckResponse(
        status="healthy" if db_healthy else "degraded",
        database=db_healthy,
        timestamp=datetime.now().isoformat(),
    )


@router.get("/")
async def root():
    """Root endpoint returning API information."""
    return {
        "name": "Workflow Agent API",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/health",
        "since": "06-01-2026"
    }
