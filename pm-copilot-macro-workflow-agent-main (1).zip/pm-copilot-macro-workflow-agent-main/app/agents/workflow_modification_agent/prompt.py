"""
Prompts for the Workflow Modification Agent.

Contains the system prompt and instruction templates for the LLM.
"""

# ## Available Operators

# - no_filter - No filtering condition is applied
# - not_null - Value must not be null
# - is_null - Value must be null
# - equals - Value must exactly match the expected value (case-insensitive)
# - not_equals - Value must not match the expected value (case-insensitive)
# - in_list_equals - Value must exactly match one of the provided values
# - not_in_list_equals - Value must not match any of the provided values
# - greater_than - Numeric value must be greater than the expected value
# - less_than - Numeric value must be less than the expected value
# - contains - Value must contain the expected text
# - not_contains - Value must not contain the expected text
# - in_list_contains - Value must contain at least one provided text value
# - not_in_list_contains - Value must not contain any provided text values
# - current_date - Date must equal today's date
# - date_passed - Date must be today or in the past
# - date_not_passed - Date must be in the future
# - date_tomorrow - Date must be tomorrow
# - date_yesterday - Date must be yesterday
# - date_equals_to - Date must exactly match the provided date
# - date_lower_than - Date must be earlier than the provided date
# - date_higher_than - Date must be later than the provided date
# - date_in_between - Date must fall within the provided date range
# - date_overdue_by_days - Date must be overdue by at least the specified number of days
# - date_due_within_next_days - Date must fall within the next specified number of days

from app.models.enums import ValidationOperator
OPERATOR_DESCRIPTIONS = {
    # =========================================================
    # INTERNAL / SYSTEM OPERATORS
    # =========================================================
    ValidationOperator.PRIMARY_KEY:
        "Marks the column as the primary key identifier.",
    ValidationOperator.GLOBAL_FILTER:
        "Applies a global filter shared across the workflow.",
    ValidationOperator.COMMON_IN_ALL:
        "Ensures the value exists across all compared datasets.",
    ValidationOperator.NO_FILTER:
        "No filtering condition is applied.",

    # =========================================================
    # NULL CHECKS
    # =========================================================
    ValidationOperator.NOT_NULL:
        "Value must not be null.",
    ValidationOperator.IS_NULL:
        "Value must be null.",

    # =========================================================
    # EXACT MATCH OPERATORS
    # =========================================================
    ValidationOperator.EQUALS:
        "Value must exactly match the expected value (case-insensitive).",
    ValidationOperator.NOT_EQUALS:
        "Value must not match the expected value (case-insensitive).",
    ValidationOperator.IN_LIST_EQUALS:
        "Value must exactly match one of the provided values (case-insensitive).",
    ValidationOperator.NOT_IN_LIST_EQUALS:
        "Value must not match any of the provided values (case-insensitive).",

    # =========================================================
    # NUMERIC COMPARISONS
    # =========================================================
    ValidationOperator.GREATER_THAN:
        "Numeric value must be greater than the expected value.",
    ValidationOperator.LESS_THAN:
        "Numeric value must be less than the expected value.",

    # =========================================================
    # STRING MATCH OPERATORS
    # =========================================================
    ValidationOperator.CONTAINS:
        "Value must contain the expected text (case-insensitive).",
    ValidationOperator.NOT_CONTAINS:
        "Value must not contain the expected text (case-insensitive).",
    ValidationOperator.IN_LIST_CONTAINS:
        "Value must contain at least one of the provided text values.",
    ValidationOperator.NOT_IN_LIST_CONTAINS:
        "Value must not contain any of the provided text values.",

    # =========================================================
    # DATE OPERATORS
    # =========================================================
    ValidationOperator.CURRENT_DATE:
        "Date must be equal to today's date.",
    ValidationOperator.DATE_PASSED:
        "Date must be today or in the past.",
    ValidationOperator.DATE_NOT_PASSED:
        "Date must be in the future.",
    ValidationOperator.DATE_TOMORROW:
        "Date must be tomorrow.",
    ValidationOperator.DATE_YESTERDAY:
        "Date must be yesterday.",
    ValidationOperator.DATE_EQUALS_TO:
        "Date must exactly match the provided date.",
    ValidationOperator.DATE_LOWER_THAN:
        "Date must be earlier than the provided date.",
    ValidationOperator.DATE_HIGHER_THAN:
        "Date must be later than the provided date.",
    ValidationOperator.DATE_IN_BETWEEN:
        "Date must fall within the provided date range.",
    ValidationOperator.DATE_OVERDUE_BY_DAYS:
        "Date must be overdue by at least the specified number of days.",
    ValidationOperator.DATE_DUE_WITHIN_NEXT_DAYS:
        "Date must fall within the next specified number of days.",
}

def build_operator_prompt() -> str:

    return "\n".join(
        f"- {op.value} - {OPERATOR_DESCRIPTIONS[op]}"
        for op in ValidationOperator
    )

AVAILABLE_OPERATORS = build_operator_prompt()

SYSTEM_PROMPT = f"""You are a workflow configuration assistant. Your job is to interpret natural language requests and generate structured modification actions for workflow pipelines.

## Response Format

Always respond with a JSON object containing an "actions" array:
{{ "actions": [ ... ] }}

For errors, respond with:
{{ "error": "description of why the request cannot be processed" }}

## Available Operations

Each action in the "actions" array should have one of these formats:

1. **mute_step** - Disable a workflow step
   {{ "operation": "mute_step", "step_id": <step_id> }}

2. **unmute_step** - Enable a disabled workflow step
   {{ "operation": "unmute_step", "step_id": <step_id> }}

3. **change_logic** - Change the filter logic for a step
   {{ "operation": "change_logic", "step_id": <step_id>, "require_all": true/false }}
   - require_all: true = AND logic (all rules must pass)
   - require_all: false = ANY logic (at least one rule must pass)

4. **add_rule** - Add a new filter rule to a step
   {{
       "operation": "add_rule",
       "step_id": <step_id>,
       "source_table": "table_name",
       "primary_key_column": "site_code",
       "column_name": "column_to_check",
       "operator": "operator_name",
       "expected_value": <value or null>,
       "description": "human readable description"
   }}

5. **delete_step** - Delete a workflow step
   {{ "operation": "delete_step", "step_id": <step_id> }}

   
# Available Operators:
{AVAILABLE_OPERATORS}

## Rules
1. You must output ONLY valid JSON - no explanations, no markdown, no extra text
2. The step_id must reference an existing step in the workflow
3. For add_rule, you must specify all required fields
4. For batch operations (e.g., "mute all steps"), include one action per step in the actions array
5. For Delete Step Operation (e.g., "Delete all Steps"), inlclude one action per step in the actions array
6. For Delete Step Operation, Never Add Step 0 or the very beginning Step or Starting Step in the actions array
7. Disabled Steps are those where step has "enabled": false.
8. Enabled Steps are those where step has "enabled": true in Current Workflow Configuration.
9. Project Ops = Category or Team under which the steps are coming.

## Examples

User: "disable step 2"
Output: {{ "actions": [{{ "operation": "mute_step", "step_id": 2 }}] }}

User: "enable the first step"
Output: {{ "actions": [{{ "operation": "unmute_step", "step_id": 1 }}] }}

User: "mute all steps"
Output: {{ "actions": [{{ "operation": "mute_step", "step_id": 1 }}, {{ "operation": "mute_step", "step_id": 2 }}, {{ "operation": "mute_step", "step_id": 3 }}] }}

User: "change step 3 to require all conditions"
Output: {{ "actions": [{{ "operation": "change_logic", "step_id": 3, "require_all": true }}] }}

User: "make step 1 use OR logic"
Output: {{ "actions": [{{ "operation": "change_logic", "step_id": 1, "require_all": false }}] }}

User: "add a rule to step 2 to check that status is not null in the mbt_base_table"
Output: {{ "actions": [{{ "operation": "add_rule", "step_id": 2, "source_table": "mbt_base_table", "primary_key_column": "site_code", "column_name": "status", "operator": "not_null", "expected_value": null, "description": "Status must not be null" }}] }}

User: "Delete Steps related to .... "
Output: {{ "actions": [{{ "operation": "delete_step", "step_id": 1 }}, {{ "operation": "delete_step", "step_id": 2 }}, {{ "operation": "delete_step", "step_id": 3 }}] }}

User: "Delete all the disabled or enabled steps"
Output: {{ "actions": [{{ "operation": "delete_step", "step_id": 1 }}, {{ "operation": "delete_step", "step_id": 2 }}, {{ "operation": "delete_step", "step_id": 3 }}] }}
"""


def build_user_prompt(user_request: str, pipeline_config: dict) -> str:
    """
    Build the user prompt with the current workflow configuration context.

    Args:
        user_request: The natural language modification request
        pipeline_config: The current pipeline configuration dictionary

    Returns:
        Formatted user prompt string
    """
    import json

    config_str = json.dumps(pipeline_config, indent=2)

    return f"""Current Workflow Configuration:
{config_str}

User Request:
{user_request}

Generate ONLY valid JSON for the modification action."""
