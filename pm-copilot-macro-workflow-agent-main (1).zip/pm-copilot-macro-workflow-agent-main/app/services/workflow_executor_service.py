from app.api.routes.workflow_orchestration import _get_workflow
from asyncpg import Connection
from app.utils.save_workflow_execution import save_workflow_execution
from app.schemas.workflow import (
    WorkflowExecutionResultResponse,
    StepExecutionResultResponse,
)

RUNNING_WORKFLOWS = set()


async def execute_scheduled_workflow(db: Connection, workflow_name: str):
    """
    Execute workflow safely.

    - Prevent duplicate execution
    - Continue safely on failure
    """

    if workflow_name in RUNNING_WORKFLOWS:
        print(f"[SCHEDULER] Workflow already running: {workflow_name}")
        return

    RUNNING_WORKFLOWS.add(workflow_name)

    try:
        print(f"\n[SCHEDULER] Starting workflow: {workflow_name}")

        workflow = await _get_workflow(workflow_name)

        result = await workflow.execute(
            workflow_name=workflow_name,
            db=db,
        )
        
        response = WorkflowExecutionResultResponse(
            workflow_name=result.workflow_name,
            initial_count=result.initial_count,
            final_count=result.final_count,
            steps_executed=result.steps_executed,
            step_results=[
                StepExecutionResultResponse.model_validate(r)
                for r in result.step_results
            ],
            timestamp=result.timestamp,
        )

        await save_workflow_execution(
            db=db,
            workflow_name=workflow_name,
            execution_payload=response.to_dict(),
            user_id="Workflow_Scheduler",
        )

        print(f"[SCHEDULER] Completed workflow: {workflow_name}")

    except Exception as e:
        print(
            f"[SCHEDULER] Workflow failed: "
            f"{workflow_name} | Error: {str(e)}"
        )

    finally:
        RUNNING_WORKFLOWS.discard(workflow_name)