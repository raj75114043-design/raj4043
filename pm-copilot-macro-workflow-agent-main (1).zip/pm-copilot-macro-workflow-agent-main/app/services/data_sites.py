from typing import Dict, List
from asyncpg import Connection

from app.config.pipeline_storage import load_pipeline
from app.schemas.workflow import WorkflowPipelineDetail
from app.core.data_fetch_config import BASE_SCHEMA
from app.models.enums import (
    ValidationOperator,
)

PRIMARY_KEY_CACHE: Dict[str, str] = {}
BASE_TABLE_CACHE: Dict[str, str] = {}
GLOBAL_FILTER_COLUMN_CACHE: Dict[str, List[str]] = {}
COMMON_COLUMN_CACHE: Dict[str, List[str]] = {}
PRIMARY_COLUMN_TYPE_CACHE: Dict[str, List[str]] = {}

def get_cached_primary_key(workflow_name: str) -> str:
    if workflow_name not in PRIMARY_KEY_CACHE:
        raise ValueError("Primary key not initialized in cache")
    return PRIMARY_KEY_CACHE[workflow_name]

def get_cached_primary_key_type(workflow_name: str) -> str:
    if workflow_name not in PRIMARY_COLUMN_TYPE_CACHE:
        raise ValueError("Common Column not initialized in cache")
    return PRIMARY_COLUMN_TYPE_CACHE[workflow_name]


def get_cached_base_table(workflow_name: str) -> str:
    if workflow_name not in BASE_TABLE_CACHE:
        raise ValueError("Base Table not initialized in cache")
    return BASE_TABLE_CACHE[workflow_name]

def get_cached_global_filter_columns(workflow_name: str) -> List[str]:
    if workflow_name not in GLOBAL_FILTER_COLUMN_CACHE:
        raise ValueError("Global Filters not initialized in cache")
    return GLOBAL_FILTER_COLUMN_CACHE[workflow_name]

def get_cached_common_columns(workflow_name: str) -> List[str]:
    if workflow_name not in COMMON_COLUMN_CACHE:
        raise ValueError("Common Column not initialized in cache")
    return COMMON_COLUMN_CACHE[workflow_name]


def _map_pg_type_to_array_cast(pg_type: str) -> str:
    mapping = {
        "integer": "int[]",
        "bigint": "bigint[]",
        "smallint": "smallint[]",
        "text": "text[]",
        "character varying": "text[]",
        "varchar": "text[]"
    }
    return mapping.get(pg_type, "text[]")

def _extract_primary_key_info(
    pipeline: WorkflowPipelineDetail,
    workflow_name: str
) -> str:

    starting_step = next(
        (step for step in pipeline.steps if not step.execution.depends_on),
        None
    )

    if not starting_step:
        raise ValueError("No starting step found in workflow")

    print(f"Found Step Id: {starting_step.meta.step_id} as Starting Node.")

    rules = starting_step.filter_criteria.rules or []

    base_table = None
    primary_key_column = None
    global_filter_columns: List[str] = []
    common_columns: List[str] = []

    for rule in rules:
        # Identify Primary Key
        if (
            not primary_key_column
            and rule.operator == ValidationOperator.PRIMARY_KEY
            and rule.column_name == rule.primary_key_column
        ):
            base_table = rule.source_table
            primary_key_column = rule.primary_key_column
            continue

    if not base_table or not primary_key_column:
        raise ValueError("Primary Key not properly defined")

    for rule in rules:
        if (
            rule.source_table == base_table
            and rule.primary_key_column == primary_key_column
        ):
            if rule.operator == ValidationOperator.GLOBAL_FILTER:
                global_filter_columns.append(rule.column_name)

            elif rule.operator == ValidationOperator.COMMON_IN_ALL:
                common_columns.append(rule.column_name)

    PRIMARY_KEY_CACHE[workflow_name] = primary_key_column
    BASE_TABLE_CACHE[workflow_name] = base_table
    GLOBAL_FILTER_COLUMN_CACHE[workflow_name] = global_filter_columns
    COMMON_COLUMN_CACHE[workflow_name] = common_columns

    return primary_key_column


async def get_primary_key_column(
    db: Connection, workflow_name: str
) -> str:

    pipeline_dict = await load_pipeline(db, workflow_name)
    if not pipeline_dict:
        raise ValueError(f"Pipeline not found for workflow: {workflow_name}")

    pipeline = WorkflowPipelineDetail(**pipeline_dict)
    primary_key_column = _extract_primary_key_info(pipeline, workflow_name)

    return primary_key_column


async def get_list_of_primary_key(
    db: Connection, workflow_name: str
) -> List[str]:

    primary_key_column = await get_primary_key_column(db, workflow_name)
    BASE_TABLE = get_cached_base_table(workflow_name)

    type_query = """
        SELECT data_type
        FROM information_schema.columns
        WHERE table_schema = $1
          AND table_name = $2
          AND column_name = $3
    """

    type_row = await db.fetchrow(type_query, BASE_SCHEMA, BASE_TABLE, primary_key_column)
    pk_type = type_row["data_type"] if type_row else "text"
    pk_cast = _map_pg_type_to_array_cast(pk_type)
    PRIMARY_COLUMN_TYPE_CACHE[workflow_name] = pk_cast

    query = f"""
        SELECT DISTINCT {primary_key_column}::text AS site_code
        FROM {BASE_SCHEMA}.{BASE_TABLE}
        WHERE {primary_key_column} IS NOT NULL
    """

    rows = await db.fetch(query)

    return [row["site_code"] for row in rows]