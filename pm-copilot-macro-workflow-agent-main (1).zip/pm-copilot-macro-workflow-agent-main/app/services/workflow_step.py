"""
WorkflowStep service for executing and managing individual workflow steps.

This service handles the core step logic including validation, filtering,
and execution tracking.
"""

from typing import List, Dict, Any, Optional
from datetime import datetime
from asyncpg import Connection
from collections import defaultdict
from app.services.workflow_save_output import save_view_output_table
from app.core.data_fetch_config import BASE_SCHEMA
from app.services.data_sites import get_cached_primary_key_type
from app.models.workflow import (
    StepMetaData,
    StepExecutionConfig,
    FilterCriteriaConfig,
    ViewOutputConfig,
    ComputationConfig,
    AgentConfig,
    SitesFilterRule,
    StepExecutionResult,
)
from app.models.enums import (
    ValidationOperator,
    OnDisabledStrategy,
    MergeStrategy,
    ConditionalLogic,
    StepStatus,
)

def format_sql_debug(sql: str, values: list):
    formatted_values = []

    for v in values:
        if isinstance(v, str):
            formatted_values.append(f"'{v}'")
        else:
            formatted_values.append(str(v))

    return sql.replace("$1", f"ARRAY[{', '.join(formatted_values)}]")

def _parse_expected_values(value) -> List[str]:
    """
    Converts comma-separated string OR list into clean list of values
    """
    if not value:
        return []

    if isinstance(value, list):
        return [str(v).strip() for v in value if str(v).strip()]

    if isinstance(value, str):
        return [v.strip() for v in value.split(",") if v.strip()]

    return [str(value).strip()]

class WorkflowStep:
    """
    Represents a single step in a workflow pipeline.

    A step can:
    - Filter site codes based on validation rules
    - Track execution history and results
    - Be enabled/disabled dynamically
    - Have multiple dependencies with configurable merge strategies
    """

    def __init__(
        self,
        meta: StepMetaData,
        execution: StepExecutionConfig,
        filter_criteria: Optional[FilterCriteriaConfig] = None,
        view_output: Optional[ViewOutputConfig] = None,
        computation: Optional[ComputationConfig] = None,
        agent: Optional[AgentConfig] = None,
    ):
        self.meta = meta
        self.execution = execution
        self.filter_criteria = filter_criteria
        self.view_output = view_output
        self.computation = computation
        self.agent = agent

        # Execution tracking
        self.initial_primary_keys: List[str] = []
        self.passed_primary_keys: List[str] = []
        self.failed_primary_keys: List[str] = []
        self.execution_time: Optional[float] = None
        self.execution_count: int = 0

        # Validate merge strategy for multi-dependency steps
        if self.execution.depends_on and len(self.execution.depends_on) > 1:
            if not self.execution.merge_strategy:
                raise ValueError(
                    f"Step '{self.meta.step_id}' has multiple dependencies "
                    "but no merge strategy defined"
                )
        else:
            self.execution.merge_strategy = MergeStrategy.UNION
    


    @staticmethod
    def _rule_to_sql(rule: SitesFilterRule) -> str:
        col = f'"{rule.column_name}"'
        op = rule.operator


        if op == ValidationOperator.NO_FILTER:
            return "TRUE"
        
        if op == ValidationOperator.NOT_NULL:
            return f"{col} IS NOT NULL"

        if op == ValidationOperator.IS_NULL:
            return f"{col} IS NULL"

        if op == ValidationOperator.EQUALS:
            return f"LOWER({col}) = LOWER('{rule.expected_value}')"

        if op == ValidationOperator.NOT_EQUALS:
            return f"LOWER({col}) <> LOWER('{rule.expected_value}')"

        if op == ValidationOperator.IN_LIST_EQUALS:
            values = _parse_expected_values(rule.expected_value)
            if not values:
                return "FALSE"
            sql_values = ",".join(f"LOWER('{v}')" for v in values)
            return f"LOWER({col}) IN ({sql_values})"

        if op == ValidationOperator.NOT_IN_LIST_EQUALS:
            values = _parse_expected_values(rule.expected_value)
            if not values:
                return "TRUE"
            sql_values = ",".join(f"LOWER('{v}')" for v in values)
            return f"LOWER({col}) NOT IN ({sql_values})"
        
        if op == ValidationOperator.GREATER_THAN:
            return f"{col}::numeric > {rule.expected_value}"

        if op == ValidationOperator.LESS_THAN:
            return f"{col}::numeric < {rule.expected_value}"


        if op == ValidationOperator.CONTAINS:
            return f"LOWER({col}) LIKE LOWER('%{rule.expected_value}%')"

        if op == ValidationOperator.NOT_CONTAINS:
            return f"LOWER({col}) NOT LIKE LOWER('%{rule.expected_value}%')"

        if op == ValidationOperator.IN_LIST_CONTAINS:
            values = _parse_expected_values(rule.expected_value)
            if not values:
                return "FALSE"
            conditions = [
                f"LOWER({col}) LIKE LOWER('%{v}%')" for v in values
            ]
            return "(" + " OR ".join(conditions) + ")"

        if op == ValidationOperator.NOT_IN_LIST_CONTAINS:
            values = _parse_expected_values(rule.expected_value)
            if not values:
                return "TRUE"
            conditions = [
                f"LOWER({col}) NOT LIKE LOWER('%{v}%')" for v in values
            ]
            return "(" + " AND ".join(conditions) + ")"
        
        if op == ValidationOperator.CURRENT_DATE:
            return f"{col}::date = CURRENT_DATE"
        
        if op == ValidationOperator.DATE_PASSED:
            return f"{col}::date <= CURRENT_DATE"

        if op == ValidationOperator.DATE_NOT_PASSED:
            return f"{col}::date > CURRENT_DATE"

        if op == ValidationOperator.DATE_TOMORROW:
            return f"{col}::date = CURRENT_DATE + 1"

        if op == ValidationOperator.DATE_YESTERDAY:
            return f"{col}::date = CURRENT_DATE - 1"

        if op == ValidationOperator.DATE_EQUALS_TO:
            return f"{col}::date = TO_DATE('{rule.expected_value}', 'DD-MM-YYYY')"

        if op == ValidationOperator.DATE_LOWER_THAN:
            return f"{col}::date < TO_DATE('{rule.expected_value}', 'DD-MM-YYYY')"

        if op == ValidationOperator.DATE_HIGHER_THAN:
            return f"{col}::date > TO_DATE('{rule.expected_value}', 'DD-MM-YYYY')"
        
        if op == ValidationOperator.DATE_IN_BETWEEN:
            start_date, end_date = rule.expected_value.split(",")
            return f"""
            {col}::date BETWEEN 
            TO_DATE('{start_date}', 'DD-MM-YYYY') 
            AND 
            TO_DATE('{end_date}', 'DD-MM-YYYY')
            """

        if op == ValidationOperator.DATE_OVERDUE_BY_DAYS:
            days = int(rule.expected_value)
            return f"""
                {col}::date <= CURRENT_DATE
                AND CURRENT_DATE - {col}::date >= {days}
            """
        if op == ValidationOperator.DATE_DUE_WITHIN_NEXT_DAYS:
            days = int(rule.expected_value)
            return f"""
                {col}::date > CURRENT_DATE
                AND {col}::date <= CURRENT_DATE + {days}
            """


    def _build_bulk_step_sql_for_nas(self, primary_key_column_name: str, pk_cast: str) -> str:

        rules = self.filter_criteria.rules or []

        filtered_rules = [
            rule for rule in rules
            if rule.operator not in (
                ValidationOperator.PRIMARY_KEY,
                ValidationOperator.GLOBAL_FILTER,
                ValidationOperator.COMMON_IN_ALL
            )
        ]

        ctes = []
        joins = []
        select_columns = []
        pass_columns = []

        # Base PKs
        ctes.append(f"""
        base_primary_keys AS (
            SELECT UNNEST($1::{pk_cast}) AS primary_key
        )
        """)

        for idx, rule in enumerate(filtered_rules, start=1):

            table = rule.source_table
            if "." not in table:
                table = f"{BASE_SCHEMA}.{table}"

            pk_col = rule.primary_key_column
            value_col = rule.column_name

            rule_expr = self._rule_to_sql(rule)

            # NO aggregation here
            ctes.append(f"""
            rule_{idx} AS (
                SELECT
                    "{pk_col}" AS primary_key,
                    "{value_col}" AS value_{idx},

                    CASE 
                        WHEN {rule_expr} THEN TRUE
                        ELSE FALSE
                    END AS pass_{idx}

                FROM {table}
                WHERE "{pk_col}" = ANY($1::{pk_cast})
            )
            """)

            joins.append(
                f"LEFT JOIN rule_{idx} r{idx} ON b.primary_key = r{idx}.primary_key"
            )

            safe_col = value_col.lower().replace(" ", "_")

            select_columns.append(
                f'r{idx}.value_{idx} AS "{safe_col}_{idx}"'
            )

            pass_columns.append(f"COALESCE(r{idx}.pass_{idx}, FALSE)")

        # Conditional logic
        operator = (
            " AND "
            if self.filter_criteria.conditional_logic == ConditionalLogic.AND
            else " OR "
        )

        final_condition = operator.join(pass_columns) if pass_columns else "TRUE"

        select_clause = []
        select_clause.append(f"b.primary_key AS {primary_key_column_name}")

        if select_columns:
            select_clause.extend(select_columns)

        select_clause.append(f"""
        CASE
            WHEN {final_condition} THEN 'PASS'
            ELSE 'FAIL'
        END AS final_status
        """)

        return f"""
        WITH
        {",".join(ctes)}

        SELECT
        {", ".join(select_clause)}

        FROM base_primary_keys b
        {" ".join(joins)}
        """


    def _build_bulk_step_sql(self, primary_key_column_name:str, pk_cast:str) -> str:
        
        rules = self.filter_criteria.rules or []

        # Skip non-validation rules
        filtered_rules = [
            rule for rule in rules
            if rule.operator
            not in (
                ValidationOperator.PRIMARY_KEY,
                ValidationOperator.GLOBAL_FILTER,
                ValidationOperator.COMMON_IN_ALL
            )
        ]

        ctes = []
        joins = []
        select_columns = []
        pass_columns = []
        # Base input PKs
        ctes.append(f"""
        base_primary_keys AS (
            SELECT UNNEST($1::{pk_cast}) AS primary_key
        )
        """)

        for idx, rule in enumerate(filtered_rules, start=1):

            table = rule.source_table
            if "." not in table:
                table = f"{BASE_SCHEMA}.{table}"

            pk_col = rule.primary_key_column
            value_col = rule.column_name

            rule_expr = self._rule_to_sql(rule)

            # Handle NO_FILTER
            if rule.operator == ValidationOperator.NO_FILTER:
                aggregation = "TRUE"   # Always pass
            else:
                aggregation = f"BOOL_AND({rule_expr})"
                # aggregation = f"BOOL_OR({rule_expr})"

            ctes.append(f"""
            rule_{idx} AS (
                SELECT
                    "{pk_col}" AS primary_key,

                    -- original value (pick any or aggregate)
                    MAX("{value_col}") AS value_{idx},

                    {aggregation} AS pass_{idx}

                FROM {table}
                WHERE "{pk_col}" = ANY($1::{pk_cast})
                GROUP BY "{pk_col}"
            )
            """)

            joins.append(
                f"LEFT JOIN rule_{idx} r{idx} ON b.primary_key = r{idx}.primary_key"
            )

            # Safe column naming
            safe_col = value_col.lower().replace(" ", "_")

            # Always include value column
            select_columns.append(
                f'r{idx}.value_{idx} AS "{safe_col}_{idx}"'
            )

            # Pass column
            if rule.operator != ValidationOperator.NO_FILTER:
                pass_columns.append(f"COALESCE(r{idx}.pass_{idx}, FALSE)")
            else:
                pass_columns.append("TRUE")

        # Conditional logic
        operator = (
            " AND "
            if self.filter_criteria.conditional_logic == ConditionalLogic.AND
            else " OR "
        )

        final_condition = operator.join(pass_columns) if pass_columns else "TRUE"

        select_clause = []

        select_clause.append(f"b.primary_key AS {primary_key_column_name}")

        if select_columns:
            select_clause.extend(select_columns)

        select_clause.append(f"""
        CASE
            WHEN {final_condition} THEN 'PASS'
            ELSE 'FAIL'
        END AS final_status
        """)

        return f"""
        WITH
        {",".join(ctes)}

        SELECT
        {", ".join(select_clause)}

        FROM base_primary_keys b
        {" ".join(joins)}
        """



        # return f"""
        # WITH
        # {",".join(ctes)},

        # final_joined AS (
        #     SELECT
        #     {", ".join(select_clause)}
        #     FROM base_primary_keys b
        #     {" ".join(joins)}
        # ),

        # final_ranked AS (
        #     SELECT *,
        #         ROW_NUMBER() OVER (
        #             PARTITION BY {primary_key_column_name}
        #             ORDER BY {primary_key_column_name}
        #         ) as rank
        #     FROM final_joined
        # )

        # SELECT *
        # FROM final_ranked
        # """


    async def execute(
        self, workflow_name: str, primary_key_column_name: str, primary_keys: List[str], db: Connection
    ) -> StepExecutionResult:
        
        start_time = datetime.now()
        self.execution_count += 1
        print(f"Step {self.meta.step_id} STARTED")

        self.initial_primary_keys = primary_keys
        self.passed_primary_keys = []
        self.failed_primary_keys = []
        pk_cast = get_cached_primary_key_type(workflow_name)

        # Handle disabled step
        if not self.execution.is_enabled:
            if self.execution.on_disabled == OnDisabledStrategy.EMPTY:
                output_keys = []
            else:
                output_keys = primary_keys

            self.execution_time = (datetime.now() - start_time).total_seconds()

            print(f"Step {self.meta.step_id} COMPLETED")

            return StepExecutionResult(
                step_id=self.meta.step_id,
                step_name=self.meta.name,
                step_description=self.meta.description,
                phase_id=self.meta.phase_id,
                phase_name=self.meta.phase_name,
                category=self.meta.category,
                enabled=self.execution.is_enabled,
                depends_on=self.execution.depends_on,
                filter_enabled=self.filter_criteria.enabled,
                status=StepStatus.DISABLED,
                input_count=len(primary_keys),
                passed_count=len(output_keys),
                passed_primary_keys=output_keys,
                execution_time=self.execution_time
            )

        if workflow_name.startswith("NAS"):
            sql = self._build_bulk_step_sql_for_nas(primary_key_column_name, pk_cast)
            is_nas = True
            print("RUNNING NAS Workflow")
        else:
            sql = self._build_bulk_step_sql(primary_key_column_name, pk_cast)
            is_nas = False
            
        # rows = await db.fetch(sql, query_primary_keys)    
        rows = []

        try:
            query_primary_keys = primary_keys

            if "int" in pk_cast:
                query_primary_keys = [int(pk) for pk in primary_keys]
                
            rows = await db.fetch(sql, query_primary_keys)

            # debug_sql = format_sql_debug(sql, query_primary_keys)
            # print(f"Debug SQL: {debug_sql}")

        except Exception as e:
            db_error = str(e)
            print(f"[DB ERROR] Bulk query failed: {db_error}")
            print(f"Step {self.meta.step_id} FAILED")

            raise RuntimeError(
                f"Workflow Step failed at step {self.meta.step_id}"
            )
        

        passed = []
        failed = []
        detailed_results = []

        print("Total Number of rows: ", len(rows))

        if is_nas:
            #  ROW-LEVEL LOGIC (NAS)

            pk_pass_map = {}

            for row in rows:
                record = dict(row)
                pk = record[primary_key_column_name]

                detailed_results.append(record)

                if record["final_status"] == "PASS":
                    passed.append(pk)
                    pk_pass_map[pk] = True
                else:
                    failed.append(pk)

            # unique PKs with at least one PASS
            self.passed_primary_keys = list(pk_pass_map.keys())

            # PKs with NO PASS
            self.failed_primary_keys = [
                pk for pk in set(primary_keys)
                if pk not in pk_pass_map
            ]

            print(f"Total PASS rows = {len(passed)}")
            print(f"Total FAIL rows = {len(failed)}")

            print(f"Unique Passed PKs = {len(self.passed_primary_keys)}")
            print(f"Unique Failed PKs = {len(self.failed_primary_keys)}")

        else:
            # EXISTING LOGIC (UNCHANGED)

            for row in rows:
                record = dict(row)
                pk = record[primary_key_column_name]

                detailed_results.append(record)

                if record["final_status"] == "PASS":
                    passed.append(pk)
                else:
                    failed.append(pk)

            self.passed_primary_keys = passed
            self.failed_primary_keys = failed

            print(f"Passed primary keys = {len(passed)}")
            print(f"Failed primary keys = {len(failed)}")

        output_info = {
            "output_table": None,
            "output_table_status": "SKIPPED"
        }

        if self.view_output and self.view_output.is_enabled:
            output_info = await save_view_output_table(
                workflow_name=workflow_name,
                db=db,
                step_id=self.meta.step_id,
                sql=sql,
                primary_keys=primary_keys,
            )

        self.execution_time = (datetime.now() - start_time).total_seconds()
        print(f"Step {self.meta.step_id} COMPLETED")

        # if is_nas:
        #     passed_count = len(passed)   # total PASS rows
        #     failed_count = len(failed)   # total FAIL rows
        # else:
        passed_count = len(self.passed_primary_keys)
        failed_count = len(self.failed_primary_keys)
        
        return StepExecutionResult(
            step_id=self.meta.step_id,
            step_name=self.meta.name,
            step_description=self.meta.description,
            phase_id=self.meta.phase_id,
            phase_name=self.meta.phase_name,
            category=self.meta.category,
            enabled=self.execution.is_enabled,
            depends_on=self.execution.depends_on,
            filter_enabled=self.filter_criteria.enabled,
            status=StepStatus.COMPLETED,
            input_count=len(primary_keys),
            passed_count=passed_count,
            failed_count=failed_count,
            passed_primary_keys=self.passed_primary_keys,
            failed_primary_keys=self.failed_primary_keys,
            execution_time=self.execution_time,
            output_table=output_info.get("output_table"),
            output_table_status=output_info.get("output_table_status")
        )
    


    # ========================================================================
    # Control Methods
    # ========================================================================

    def mute(self) -> None:
        """Disable the step."""
        self.execution.is_enabled = False

    def unmute(self) -> None:
        """Enable the step."""
        self.execution.is_enabled = True

    # ========================================================================
    # Filter Criteria Management
    # ========================================================================

    def add_filter_rule(self, rule: SitesFilterRule) -> None:
        """Add a filter rule to the step."""
        if self.filter_criteria is None:
            self.filter_criteria = FilterCriteriaConfig()
        self.filter_criteria.rules.append(rule)

    def remove_filter_rule(self, rule_index: int) -> bool:
        """Remove a filter rule by index."""
        if self.filter_criteria is None:
            return False
        if 0 <= rule_index < len(self.filter_criteria.rules):
            self.filter_criteria.rules.pop(rule_index)
            return True
        return False

    def update_filter_logic(self, require_all: bool) -> None:
        """Update the filter conditional logic."""
        if self.filter_criteria is None:
            self.filter_criteria = FilterCriteriaConfig()
        self.filter_criteria.conditional_logic = (
            ConditionalLogic.AND if require_all else ConditionalLogic.ANY
        )

    # ========================================================================
    # Serialization
    # ========================================================================

    def get_summary(self) -> Dict[str, Any]:
        """Get a summary of the step configuration."""
        return {
            "step_id": self.meta.step_id,
            "name": self.meta.name,
            "step_description": self.meta.description,
            "phase_id": self.meta.phase_id,
            "phase_name": self.meta.phase_name,
            "category": self.meta.category,
            "enabled": self.execution.is_enabled,
            "depends_on": self.execution.depends_on,
            "merge_strategy": (
                self.execution.merge_strategy.value
                if self.execution.merge_strategy
                else None
            ),
            "filter_enabled": (
                self.filter_criteria.enabled if self.filter_criteria else False
            ),
            "criteria_count": (
                len(self.filter_criteria.rules) if self.filter_criteria else 0
            )
        }

    def get_step_detail(self) -> Dict[str, Any]:
        """Get a summary of the step configuration."""
        return {
            "step_id": self.meta.step_id,
            "name": self.meta.name,
            "step_description": self.meta.description,
            "phase_id": self.meta.phase_id,
            "phase_name": self.meta.phase_name,
            "category": self.meta.category,
            "enabled": self.execution.is_enabled,
            "depends_on": self.execution.depends_on,
            "merge_strategy": (
                self.execution.merge_strategy.value
                if self.execution.merge_strategy
                else None
            ),
            "filter_enabled": (
                self.filter_criteria.enabled if self.filter_criteria else False
            ),
            "filter_criteria": (
                self.filter_criteria.to_dict() if self.filter_criteria else None
            ),
            # # "execution_count": self.execution_count,
            # "last_execution_time": self.execution_time,
            # "qualified_sites_count": len(self.passed_primary_keys) if self.passed_primary_keys else 0,
            # "failed_sites_count": len(self.failed_primary_keys) if self.failed_primary_keys else 0,
            # "total_sites_count": (
            #     (len(self.passed_primary_keys) if self.passed_primary_keys else 0)
            #     + (len(self.failed_primary_keys) if self.failed_primary_keys else 0)
            # ),
            "computation": self.computation.to_dict() if self.computation else None,
            "agent_integration": self.agent.to_dict() if self.agent else None 
        }
    

    def to_dict(self) -> Dict[str, Any]:
        """Convert step to dictionary representation."""
        return {
            "meta": self.meta.to_dict(),
            "execution": self.execution.to_dict(),
            "filter_criteria": (
                self.filter_criteria.to_dict() if self.filter_criteria else None
            ),
            "view_output": (
                self.view_output.to_dict() if self.view_output else None
            ),
            "computation": (
                self.computation.to_dict() if self.computation else None
            ),
            "agent": self.agent.to_dict() if self.agent else None,
        }
