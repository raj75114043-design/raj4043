from typing import Optional
from datetime import datetime

async def save_dev_util_chat_log(
    db,
    session_id: str,
    workflow_name: Optional[str],
    user_id: str,
    user_query: str,
    response: str,
    status: str,
    error_message: Optional[str] = None,
    query_time: Optional[datetime] = None,
) -> bool:
    try:
        await db.execute(
            """
            INSERT INTO pwc_workflow_agent_schema.workflow_dev_chatbot_logs (
                session_id,
                workflow_name,
                user_id,
                user_query,
                response,
                status,
                error_message,
                query_time
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            """,
            session_id,
            workflow_name,
            user_id,
            user_query,
            response,
            status,
            error_message,
            query_time
        )
        return True

    except Exception as e:
        # You may log this to your logger instead
        print(f"[ERROR] Failed to save chat log: {e}")
        return False