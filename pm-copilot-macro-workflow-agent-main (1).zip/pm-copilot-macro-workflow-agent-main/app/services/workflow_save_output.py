from typing import List, Dict
from asyncpg import Connection
from app.models.workflow import SitesFilterRule
from app.core.data_fetch_config import GLOBAL_FILTERS, BASE_SCHEMA, BASE_TABLE
import re


BASE_SITE_COL = "pj_project_id"

BASE_COLUMNS = [
    col for col in GLOBAL_FILTERS.values()
    if col != BASE_SITE_COL
]


def _safe_identifier(name: str) -> str:
    return (
        name.lower()
        .replace(".", "_")
        .replace(" ", "_")
        .replace("-", "_")
    )

def _qualify_table(table_name: str) -> str:
    if "." in table_name:
        return table_name
    return f"{BASE_SCHEMA}.{table_name}"

def _normalize_identifier(name: str) -> str:
    # Replace one or more whitespace chars with underscore
    return re.sub(r"\s+", "_", name.strip()).lower()

async def save_view_output_table(
    *,
    db: Connection,
    workflow_name: str,
    step_id: str,
    rules: List[SitesFilterRule],
    input_site_codes: List[str],
    passed_site_codes: List[str],
    failed_site_codes: List[str],
) -> dict:
    """
    Creates a backend result table for UI consumption.
    """
    normalized_workflow_name = _normalize_identifier(workflow_name)
    output_schema: str = "pwc_workflow_agent_schema" 
    table_name = _safe_identifier(f"wf_step_{step_id}_output")
    full_table_name = f'{output_schema}."{normalized_workflow_name}_{table_name}"'

    if not input_site_codes:
        return {
            "output_table": full_table_name,
            "output_table_status": "SKIPPED",
        }

    try:
        await db.execute(f"DROP TABLE IF EXISTS {full_table_name}")

        rules_by_table: Dict[str, List[SitesFilterRule]] = {}
        for rule in rules:
            rules_by_table.setdefault(rule.source_table, []).append(rule)

        select_cols = [
            f"b.{BASE_SITE_COL} AS project_id",
            *[f"b.{col}" for col in BASE_COLUMNS],
        ]

        join_clauses = []
        alias_counter = 1

        for source_table, table_rules in rules_by_table.items():
            alias = f"t{alias_counter}"
            alias_counter += 1

            qualified_table = _qualify_table(source_table)
            site_col = table_rules[0].site_code_column

            join_clauses.append(
                f"""
                LEFT JOIN {qualified_table} {alias}
                ON {alias}.{site_col} = b.{BASE_SITE_COL}
                """
            )

            for rule in table_rules:
                col_alias = _safe_identifier(f"{alias}_{rule.column_name}")
                select_cols.append(
                    f"{alias}.{rule.column_name} AS {col_alias}"
                )


        select_cols.append(
            f"""
            CASE
                WHEN b.{BASE_SITE_COL} = ANY($1::text[]) THEN 'PASS'
                WHEN b.{BASE_SITE_COL} = ANY($2::text[]) THEN 'FAIL'
                ELSE 'UNKNOWN'
            END AS final_status
            """
        )


        sql = f"""
        CREATE TABLE {full_table_name} AS
        SELECT DISTINCT ON (b.{BASE_SITE_COL}, b.pj_project_id)
            {', '.join(select_cols)}
        FROM {BASE_SCHEMA}.{BASE_TABLE} b
        {' '.join(join_clauses)}
        WHERE b.{BASE_SITE_COL} = ANY($3::text[]);
        """

        # print("=========== GENERATED SQL ===========")
        # print(sql)
        # print("=====================================")

        await db.execute(
            sql,
            passed_site_codes,
            failed_site_codes,
            input_site_codes,
        )

        return {
            "output_table": full_table_name,
            "output_table_status": "CREATED",
        }

    except Exception as e:
        return {
            "output_table": full_table_name,
            "output_table_status": "FAILED",
            "error": str(e),
        }