import psycopg2
import json
import pytz

from datetime import datetime
from psycopg2 import sql
from typing import List

from app.core.data_fetch_config import (
    TABLES_TO_STAGING,
    DB_CONFIG,
    STAGING_SOURCE_SCHEMA,
    STAGING_TARGET_SCHEMA,
    STAGING_PREFIX
)

IST = pytz.timezone("Asia/Kolkata")

JOB_STORE = {}


# -------------------------------
# Create staging table
# -------------------------------

def _create_staging_table(cur, source_table, staging_table):

    query = sql.SQL(
        "CREATE TABLE IF NOT EXISTS {}.{} (LIKE {}.{} INCLUDING ALL)"
    ).format(
        sql.Identifier(STAGING_TARGET_SCHEMA),
        sql.Identifier(staging_table),
        sql.Identifier(STAGING_SOURCE_SCHEMA),
        sql.Identifier(source_table),
    )

    cur.execute(query)


# -------------------------------
# Compare schemas
# -------------------------------

def _compare_table_schema(cur, source_table, staging_table):

    schema_query = """
    SELECT column_name, data_type
    FROM information_schema.columns
    WHERE table_schema = %s
    AND table_name = %s
    ORDER BY ordinal_position
    """

    cur.execute(schema_query, (STAGING_SOURCE_SCHEMA, source_table))
    source_columns = cur.fetchall()

    cur.execute(schema_query, (STAGING_TARGET_SCHEMA, staging_table))
    staging_columns = cur.fetchall()

    source_dict = {c[0]: c[1] for c in source_columns}
    staging_dict = {c[0]: c[1] for c in staging_columns}

    if len(source_dict) != len(staging_dict):
        return False

    for col, dtype in source_dict.items():

        if col not in staging_dict:
            return False

        if staging_dict[col] != dtype:
            return False

    return True


# -------------------------------
# Guardrail Validation
# -------------------------------

def _validate_guardrails(cur, source_table, staging_table):

    # Apply only for specific table
    if source_table != "ndpd_mbt_tmobile_macro_combined":
        return {
            "status": True,
            "message": "No guardrails applicable"
        }

    allowed_smp_names = (
        "NTM",
        "AHLOB Modernization"
    )

    # ----------------------------------------
    # Count allowed source rows
    # ----------------------------------------

    source_query = sql.SQL("""
        SELECT COUNT(*)
        FROM {}.{}
        WHERE smp_name IN %s
    """).format(
        sql.Identifier(STAGING_SOURCE_SCHEMA),
        sql.Identifier(source_table)
    )

    cur.execute(source_query, (allowed_smp_names,))
    source_count = cur.fetchone()[0]

    # ----------------------------------------
    # Current staging row count
    # ----------------------------------------

    staging_query = sql.SQL("""
        SELECT COUNT(*)
        FROM {}.{}
    """).format(
        sql.Identifier(STAGING_TARGET_SCHEMA),
        sql.Identifier(staging_table)
    )

    cur.execute(staging_query)
    staging_count = cur.fetchone()[0]

    # ----------------------------------------
    # Guardrail : Sudden increase
    # ----------------------------------------

    increase = source_count - staging_count

    if increase > 5000:

        return {
            "status": False,
            "message": (
                f"Row count increase exceeded threshold. "
                f"Source={source_count}, "
                f"Staging={staging_count}, "
                f"Increase={increase}"
            )
        }

    return {
        "status": True,
        "message": "Guardrails passed",
        "source_count": source_count,
        "staging_count": staging_count
    }


# -------------------------------
# Copy table data
# -------------------------------

def _copy_table_data(cur, source_table, staging_table):

    truncate_query = sql.SQL(
        "TRUNCATE TABLE {}.{}"
    ).format(
        sql.Identifier(STAGING_TARGET_SCHEMA),
        sql.Identifier(staging_table),
    )

    cur.execute(truncate_query)

    # ----------------------------------------
    # Filtered copy for guarded table
    # ----------------------------------------

    if source_table == "ndpd_mbt_tmobile_macro_combined":

        copy_query = sql.SQL("""
            INSERT INTO {}.{}
            SELECT *
            FROM {}.{}
            WHERE smp_name IN (
                'NTM',
                'AHLOB Modernization'
            )
        """).format(
            sql.Identifier(STAGING_TARGET_SCHEMA),
            sql.Identifier(staging_table),
            sql.Identifier(STAGING_SOURCE_SCHEMA),
            sql.Identifier(source_table),
        )

    else:

        copy_query = sql.SQL("""
            INSERT INTO {}.{}
            SELECT *
            FROM {}.{}
        """).format(
            sql.Identifier(STAGING_TARGET_SCHEMA),
            sql.Identifier(staging_table),
            sql.Identifier(STAGING_SOURCE_SCHEMA),
            sql.Identifier(source_table),
        )

    cur.execute(copy_query)


# -------------------------------
# Cron pipeline
# -------------------------------

def updated_staging_tables_cron(
    job_id="staging_job"
):

    conn = psycopg2.connect(**DB_CONFIG)
    conn.autocommit = True
    cur = conn.cursor()

    start_time = datetime.now(IST)

    # -------------------------
    # Insert RUNNING entry
    # -------------------------

    cur.execute("""
        INSERT INTO pwc_workflow_agent_schema.staging_table_execution_log (
            job_id,
            start_time,
            status
        )
        VALUES (%s, %s, %s)
        RETURNING id
    """, (
        job_id,
        start_time,
        "RUNNING"
    ))

    execution_id = cur.fetchone()[0]

    mismatched_tables = []

    try:

        # -------------------------
        # Phase 1 : Schema Validation
        # -------------------------

        for table in TABLES_TO_STAGING:

            staging_table = f"{STAGING_PREFIX}{table}"

            _create_staging_table(
                cur,
                table,
                staging_table
            )

            schema_ok = _compare_table_schema(
                cur,
                table,
                staging_table
            )

            if not schema_ok:
                mismatched_tables.append(table)

        # -------------------------
        # Tables eligible for processing
        # -------------------------

        valid_tables = [
            table
            for table in TABLES_TO_STAGING
            if table not in mismatched_tables
        ]

        # -------------------------
        # Phase 1.5 : Guardrail Validation
        # -------------------------

        guardrail_failures = []

        for table in valid_tables:

            staging_table = f"{STAGING_PREFIX}{table}"

            result = _validate_guardrails(
                cur,
                table,
                staging_table
            )

            if not result["status"]:

                guardrail_failures.append({
                    "table": table,
                    "reason": result["message"]
                })

        # -------------------------
        # Abort if guardrail fails
        # -------------------------

        if guardrail_failures:

            cur.execute("""
                UPDATE pwc_workflow_agent_schema.staging_table_execution_log
                SET end_time = %s,
                    status = %s,
                    details = %s
                WHERE id = %s
            """, (
                datetime.now(IST),
                "FAILED",
                json.dumps({
                    "guardrail_failures": guardrail_failures,
                    "skipped_tables": mismatched_tables
                }),
                execution_id
            ))

            return

        # -------------------------
        # Phase 2 : Data Copy
        # -------------------------

        success = 0

        for table in valid_tables:

            staging_table = f"{STAGING_PREFIX}{table}"

            _copy_table_data(
                cur,
                table,
                staging_table
            )

            success += 1

        # -------------------------
        # SUCCESS update
        # -------------------------

        cur.execute("""
            UPDATE pwc_workflow_agent_schema.staging_table_execution_log
            SET end_time = %s,
                status = %s,
                details = %s
            WHERE id = %s
        """, (
            datetime.now(IST),
            "SUCCESS",
            json.dumps({
                "tables_processed": success,
                "skipped_tables": mismatched_tables
            }),
            execution_id
        ))

    except Exception as e:

        # -------------------------
        # FAILURE update
        # -------------------------

        cur.execute("""
            UPDATE pwc_workflow_agent_schema.staging_table_execution_log
            SET end_time = %s,
                status = %s,
                details = %s
            WHERE id = %s
        """, (
            datetime.now(IST),
            "ERROR",
            json.dumps({
                "error": str(e),
                "skipped_tables": mismatched_tables
            }),
            execution_id
        ))

        raise

    finally:

        cur.close()
        conn.close()



# -------------------------------
# Main pipeline
# -------------------------------
def updated_staging_tables(
    job_id: str,
    tables_requested: List[str]
):

    job = JOB_STORE.get(job_id)

    if not job:
        return

    conn = None
    cur = None

    try:

        conn = psycopg2.connect(**DB_CONFIG)
        conn.autocommit = True
        cur = conn.cursor()

        start_time = datetime.now(IST)

        # -------------------------
        # Insert RUNNING entry
        # -------------------------

        cur.execute("""
            INSERT INTO pwc_workflow_agent_schema.staging_table_execution_log (
                job_id,
                start_time,
                status
            )
            VALUES (%s, %s, %s)
            RETURNING id
        """, (
            job_id,
            start_time,
            "RUNNING"
        ))

        execution_id = cur.fetchone()[0]

        mismatched_tables = []

        # -------------------------
        # Phase 0 : Validation
        # -------------------------

        invalid_tables = [
            table for table in tables_requested
            if table not in TABLES_TO_STAGING
        ]

        if invalid_tables:

            cur.execute("""
                UPDATE pwc_workflow_agent_schema.staging_table_execution_log
                SET end_time = %s,
                    status = %s,
                    details = %s
                WHERE id = %s
            """, (
                datetime.now(IST),
                "FAILED",
                json.dumps({
                    "invalid_tables": invalid_tables
                }),
                execution_id
            ))

            raise ValueError(
                f"Invalid tables requested: {invalid_tables}"
            )

        TABLES_REQUESTED = tables_requested

        # -------------------------
        # Phase 1 : Schema Validation
        # -------------------------

        for table in TABLES_REQUESTED:

            staging_table = f"{STAGING_PREFIX}{table}"

            _create_staging_table(
                cur,
                table,
                staging_table
            )

            schema_ok = _compare_table_schema(
                cur,
                table,
                staging_table
            )

            if not schema_ok:
                mismatched_tables.append(table)

        # -------------------------
        # Tables eligible for processing
        # -------------------------

        valid_tables = [
            table
            for table in TABLES_REQUESTED
            if table not in mismatched_tables
        ]

        # -------------------------
        # Phase 1.5 : Guardrail Validation
        # -------------------------

        guardrail_failures = []

        for table in valid_tables:

            staging_table = f"{STAGING_PREFIX}{table}"

            result = _validate_guardrails(
                cur,
                table,
                staging_table
            )

            if not result["status"]:

                guardrail_failures.append({
                    "table": table,
                    "reason": result["message"]
                })

        # -------------------------
        # Abort if guardrail fails
        # -------------------------

        if guardrail_failures:

            job["status"] = "failed"
            job["phase"] = "guardrail_validation"
            job["guardrail_failures"] = guardrail_failures
            job["skipped_tables"] = mismatched_tables
            job["message"] = (
                "Staging update aborted due to guardrail failure"
            )
            job["completed_at"] = datetime.now(IST)

            cur.execute("""
                UPDATE pwc_workflow_agent_schema.staging_table_execution_log
                SET end_time = %s,
                    status = %s,
                    details = %s
                WHERE id = %s
            """, (
                datetime.now(IST),
                "FAILED",
                json.dumps({
                    "guardrail_failures": guardrail_failures,
                    "skipped_tables": mismatched_tables
                }),
                execution_id
            ))

            return

        # -------------------------
        # Phase 2 : Data Copy
        # -------------------------

        job["phase"] = "data_copy"

        success = 0

        for idx, table in enumerate(valid_tables, 1):

            staging_table = f"{STAGING_PREFIX}{table}"

            _copy_table_data(
                cur,
                table,
                staging_table
            )

            success += 1

            job["processed"] = idx
            job["success"] = success
            job["skipped_tables"] = mismatched_tables

        # -------------------------
        # Completed
        # -------------------------

        job["status"] = "completed"
        job["completed_at"] = datetime.now(IST)
        job["processed_tables"] = valid_tables
        job["skipped_tables"] = mismatched_tables

        cur.execute("""
            UPDATE pwc_workflow_agent_schema.staging_table_execution_log
            SET end_time = %s,
                status = %s,
                details = %s
            WHERE id = %s
        """, (
            datetime.now(IST),
            "SUCCESS",
            json.dumps({
                "tables_processed": success,
                "processed_tables": valid_tables,
                "skipped_tables": mismatched_tables
            }),
            execution_id
        ))

    except Exception as e:

        job["status"] = "failed"
        job["error"] = str(e)
        job["completed_at"] = datetime.now(IST)

        if cur:

            cur.execute("""
                UPDATE pwc_workflow_agent_schema.staging_table_execution_log
                SET end_time = %s,
                    status = %s,
                    details = %s
                WHERE id = %s
            """, (
                datetime.now(IST),
                "ERROR",
                json.dumps({
                    "error": str(e)
                }),
                execution_id
            ))

        raise

    finally:

        if cur:
            cur.close()

        if conn:
            conn.close()