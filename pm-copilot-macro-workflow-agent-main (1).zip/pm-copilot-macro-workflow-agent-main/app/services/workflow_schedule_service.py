from zoneinfo import ZoneInfo
from asyncpg import Connection
from typing import List
from datetime import datetime


async def workflow_scheduled_finder(
    db: Connection
) -> List[str]:

    query = """
    SELECT
        workflow_name,
        schedule_time,
        last_executed_at,

        COALESCE(
            CASE
                WHEN schedule_time_zone IN (
                    'Asia/Kolkata',
                    'UTC',
                    'America/Chicago',
                    'America/New_York',
                    'America/Los_Angeles'
                )
                THEN schedule_time_zone
            END,
            'UTC'
        ) AS schedule_time_zone

    FROM pwc_workflow_agent_schema.workflow_yaml_pipelines

    WHERE
        schedule_time IS NOT NULL
        AND array_length(schedule_time, 1) > 0
    """

    rows = await db.fetch(query)

    workflows_to_run = []

    # print(
    #     "Hi Checking Workflow Scheduler!..",
    #     rows
    # )

    for row in rows:

        workflow_name = row["workflow_name"]

        schedule_times = (
            row["schedule_time"] or []
        )

        timezone_name = (
            row["schedule_time_zone"]
        )

        last_executed_at = (
            row["last_executed_at"]
        )

        try:

            workflow_tz = ZoneInfo(
                timezone_name
            )

        except Exception:

            # print(
            #     f"[SCHEDULER] Invalid timezone "
            #     f"'{timezone_name}' "
            #     f"for workflow "
            #     f"'{workflow_name}'"
            # )

            continue

        # ---------------------------------------------
        # Current time in workflow timezone
        # ---------------------------------------------

        local_now = datetime.now(
            workflow_tz
        )

        # print(
        #     f"\n[SCHEDULER] Workflow: "
        #     f"{workflow_name}"
        # )

        # print(
        #     f"[SCHEDULER] Current Time: "
        #     f"{local_now}"
        # )

        should_run = False

        for scheduled_time in schedule_times:

            # ---------------------------------------------
            # Build TODAY'S scheduled occurrence
            # ---------------------------------------------

            scheduled_datetime = (
                local_now.replace(
                    hour=scheduled_time.hour,
                    minute=scheduled_time.minute,
                    second=0,
                    microsecond=0,
                )
            )

            # print(
            #     f"[SCHEDULER] Schedule Time: "
            #     f"{scheduled_datetime}"
            # )

            # ---------------------------------------------
            # Schedule time not reached yet
            # ---------------------------------------------

            if local_now < scheduled_datetime:

                # print(
                #     "[SCHEDULER] Schedule "
                #     "time not reached yet"
                # )

                continue

            # ---------------------------------------------
            # Normalize last_executed_at timezone
            # ---------------------------------------------

            if last_executed_at:

                if last_executed_at.tzinfo is None:

                    last_executed_at = (
                        last_executed_at.replace(
                            tzinfo=workflow_tz
                        )
                    )

                else:

                    last_executed_at = (
                        last_executed_at.astimezone(
                            workflow_tz
                        )
                    )

            # print(
            #     f"[SCHEDULER] Last Executed At: "
            #     f"{last_executed_at}"
            # )

            # ---------------------------------------------
            # CORE LOGIC
            #
            # RUN if:
            #
            # last_executed_at is NULL
            # OR
            # last_executed_at < today's
            # scheduled occurrence
            # ---------------------------------------------

            if (
                last_executed_at is None
                or last_executed_at
                < scheduled_datetime
            ):

                # print(
                #     f"[SCHEDULER] Scheduling "
                #     f"workflow: {workflow_name}"
                # )

                # should_run = True

                break

            # print(
            #     f"[SCHEDULER] Already executed "
            #     f"for this schedule"
            # )

        if should_run:

            workflows_to_run.append(
                workflow_name
            )

    return workflows_to_run