import asyncio
from datetime import datetime
from asyncpg import Connection
from app.db.pool import get_db, get_connection
from app.services.email_service import send_workflow_step_email

CHECK_INTERVAL = 300  #seconds

async def safe_email_task(**kwargs):

    try:
        result = await send_workflow_step_email(**kwargs)
        return result

    except Exception as e:
        print(f"[EMAIL TASK FAILED] {e}")

        return {
            "status": "failed",
            "error": str(e)
        }

async def run_scheduler():

    while True:

        try: 
            print(f"[{datetime.now()}] Checking schedules...")

            # now = datetime.now().replace(second=0, microsecond=0)

            async with get_connection() as db:

                rows = await db.fetch(
                    """
                    SELECT *
                    FROM pwc_workflow_agent_schema.workflow_email_schedule
                    WHERE is_enabled = TRUE
                    AND schedule_time <= (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Kolkata')::time
                    AND (
                        last_run_time IS NULL
                        OR last_run_time::date < CURRENT_DATE
                        OR (
                            lower(mail_status) = 'failed'
                            AND last_run_time::date = CURRENT_DATE
                        )
                    )
                    ORDER BY step_id;
                    """
                )

                print(f"Schedules found: {len(rows)}")

                for r in rows:

                    print(f"Triggering email for workflow={r['workflow_name']} step={r['step_id']} for token_id: {r['token_id']}")

                    result = await safe_email_task(
                        workflow_name=r["workflow_name"],
                        step_id=r["step_id"],
                        to_list=r["to_list"],
                        cc_list=r["cc_list"],
                        bcc_list=r["bcc_list"],
                        allowed_sites=r["allowed_sites"],
                    )

                    status = result.get("status", "failed")
                    print(f"Completed step {r['step_id']} - {status} for token_id: {r['token_id']}")
                    
                    # UPDATE last_run_time
                    await db.execute(
                        """
                        UPDATE pwc_workflow_agent_schema.workflow_email_schedule
                        SET last_run_time = NOW(),
                        mail_status = $2
                        WHERE token_id = $1
                        """,
                        r["token_id"],
                        status
                    )
                    print(f"DB Updated for {r['step_id']}")

        except Exception as e:
            print(f"[SCHEDULER ERROR] {e}")

        await asyncio.sleep(CHECK_INTERVAL)