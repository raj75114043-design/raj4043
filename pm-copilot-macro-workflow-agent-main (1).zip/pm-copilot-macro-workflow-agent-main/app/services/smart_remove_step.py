from fastapi import APIRouter, HTTPException, Header, Depends
from asyncpg import Connection

from app.config.pipeline_storage import (
    save_pipeline,
    load_pipeline,
)

# =========================================================
# SERVICE
# =========================================================

async def smart_remove_workflow_step(
    db: Connection,
    workflow_name: str,
    step_id: int,
    user_id: str,
) -> str:
    """
    Smart remove a workflow step and automatically
    rewire downstream dependencies.

    Rules:
    - Starting nodes cannot be deleted
    - Downstream dependencies are automatically rewired
    - Recursive traversal is used to find nearest valid parent
    """

    pipeline_config = await load_pipeline(db, workflow_name)

    if not pipeline_config:
        raise HTTPException(
            status_code=404,
            detail=f"Workflow '{workflow_name}' not found",
        )

    steps = pipeline_config.get("steps", [])

    # =====================================================
    # STEP MAP
    # =====================================================
    step_map = {
        s.get("meta", {}).get("step_id"): s
        for s in steps
    }

    target_step = step_map.get(step_id)

    if not target_step:
        raise HTTPException(
            status_code=404,
            detail=f"Step {step_id} not found",
        )

    # =====================================================
    # STARTING NODE CHECK
    # =====================================================
    target_dependencies = (
        target_step.get("execution", {}).get("depends_on", [])
    )

    if not target_dependencies:
        raise HTTPException(
            status_code=400,
            detail=(
                f"Step {step_id} cannot be deleted "
                f"because it is a starting node."
            ),
        )

    # =====================================================
    # FIND NEAREST ENABLED PARENT
    # =====================================================
    def find_nearest_enabled_parent(
        current_step_id: int,
        visited: set[int] | None = None,
    ) -> int | None:

        if visited is None:
            visited = set()

        if current_step_id in visited:
            return None

        visited.add(current_step_id)

        current_step = step_map.get(current_step_id)

        if not current_step:
            return None

        dependencies = (
            current_step.get("execution", {})
            .get("depends_on", [])
        )

        if not dependencies:
            return None

        for parent_id in dependencies:

            if parent_id == step_id:
                continue

            parent_step = step_map.get(parent_id)

            if not parent_step:
                continue

            parent_enabled = parent_step.get(
                "enabled",
                True,
            )

            if parent_enabled:
                return parent_id

            found = find_nearest_enabled_parent(
                parent_id,
                visited,
            )

            if found is not None:
                return found

        return None

    # =====================================================
    # REWIRE DEPENDENCIES
    # =====================================================
    rewired_steps = []

    for step in steps:

        execution = step.get("execution", {})
        depends_on = execution.get("depends_on", [])

        if step_id not in depends_on:
            continue

        updated_dependencies = []

        for dependency in depends_on:

            if dependency != step_id:
                updated_dependencies.append(dependency)
                continue

            nearest_parent = find_nearest_enabled_parent(
                step_id
            )

            if nearest_parent is not None:
                updated_dependencies.append(nearest_parent)

        # remove duplicates while preserving order
        updated_dependencies = list(
            dict.fromkeys(updated_dependencies)
        )

        execution["depends_on"] = updated_dependencies

        rewired_steps.append({
            "step_id": step["meta"]["step_id"],
            "depends_on": updated_dependencies,
        })

    # =====================================================
    # REMOVE STEP
    # =====================================================
    pipeline_config["steps"] = [
        s for s in steps
        if s.get("meta", {}).get("step_id") != step_id
    ]

    # =====================================================
    # SAVE
    # =====================================================
    updated_info = (
        f"Smart removed step {step_id}. "
        f"Rewired dependencies: {rewired_steps}"
    )

    await save_pipeline(
        db,
        workflow_name,
        pipeline_config,
        user_id,
        updated_info,
    )

    return (
        f"Step {step_id} removed successfully "
        f"with dependency rewiring."
    )