# Insights Engine — Template Fill Rulebook

> Hand this document to any developer or analyst filling the onboarding template.
> Read it fully before opening the Excel file. Every validation rule here is enforced by the engine.

---

## 1. What the Template Does

The template tells the Insights Engine:
- **Which database tables / views** to query (Data_Sources sheet)
- **Which KPIs to analyse**, how to aggregate them, and how to score their severity (KPI_Definitions sheet)

Once uploaded, the engine:
1. Validates every entry against the live source database
2. Auto-generates a parameterised SQL query per KPI using AI (unless you write your own)
3. Test-runs every query before saving anything
4. Adds the KPIs to the SQL Query Library, ready for daily insight generation

> **Note on date/time filtering:** The engine does **not** apply date range filters at the template level. Queries operate on whatever data is present in the source table as-is. If your table already contains only the relevant period's data (e.g. a materialised view refreshed daily), no further filtering is needed.

---

## 2. Before You Start

| Prerequisite | Why |
|---|---|
| Access to the source database | You need exact table names, schema prefixes, and column names |
| List of KPIs you want to track | One row per KPI — be specific |
| Targets and SLA thresholds per KPI | Without them the LLM cannot score severity accurately |
| Understanding of the geography hierarchy | `overall → region → area → market` |

---

## 3. Sheet 1 — Data_Sources

Each row describes **one table or view** in the source database that the engine is allowed to query.

### Rules

| Column | Required | Rule |
|---|---|---|
| `table_name` | **Yes** | Fully qualified: `schema.table_name` (e.g. `pm_data.network_kpis`). If schema is `public`, still write `public.table_name`. Must match exactly what exists in the database. |
| `description` | No | Plain English. What data does this table contain? Used only for documentation. |
| `market_column` | No* | Name of the column that holds the **market / city** identifier. Required if any KPI in this table uses `geography_level = market`. |
| `area_column` | No* | Name of the column that holds the **area** identifier. Required if any KPI uses `geography_level = area`. |
| `region_column` | No* | Name of the column that holds the **region** identifier. Required if any KPI uses `geography_level = region`. |
| `site_id_column` | No | Name of the column holding the individual site / element / node identifier. Enables per-site drill-down in the UI. |

> **\* Soft requirement:** Not enforced as a hard error but strongly recommended. Missing geo columns reduce insight quality and prevent geo fan-out.

### Common Mistakes

- Writing a short name like `network_kpis` instead of `pm_data.network_kpis` — the schema prefix is mandatory.
- Listing a table that does not yet exist (e.g. a view that hasn't been created). The engine checks.
- Getting column names wrong — copy-paste from the actual DDL or `\d tablename` output, do not guess.

### Example

```
table_name         | pm_data.network_kpis
description        | Daily per-site network KPI snapshot
market_column      | market_name
area_column        | area_name
region_column      | region_name
site_id_column     | site_id
```

---

## 4. Sheet 2 — KPI_Definitions

One row per KPI / analysis. **Blue-shaded columns are mandatory.** Grey-shaded columns are optional but improve output quality.

### 4.1 Identification Columns

| Column | Required | Rule |
|---|---|---|
| `kpi_name` | **Yes** | Machine-readable unique identifier. **No spaces, no special characters except underscore.** Use snake_case. Examples: `volte_drop_rate`, `permit_on_time_pct`, `fibre_build_completion`. Must be unique across all rows. |
| `display_name` | No | Human-readable label shown in the UI. Spaces allowed. Example: `VoLTE Drop Rate`. If blank, `kpi_name` is used. |
| `description` | No | One sentence: what does this KPI measure? Example: `Percentage of VoLTE calls that drop before the caller hangs up.` |
| `purpose` | No | Why does this KPI matter to the team? Example: `Identifies markets with degraded call quality needing RAN investigation.` |

---

### 4.2 Categorisation Columns

| Column | Required | Allowed Values | Rule |
|---|---|---|---|
| `category` | **Yes** | `performance` `capacity` `quality` `reliability` `compliance` `operational` | Pick the **closest** match. See decision guide below. |
| `subcategory` | No | Any string | Finer classification. Examples: `voice`, `data`, `faults`, `milestones`. Free text. |
| `pm_category` | No | `Cost` `Quality` `Schedule` `Other` | Aligns to PM work-stream. Used for filtering in the console. |
| `projects` | No | Comma-separated strings | Which projects this KPI applies to. Example: `Project_Alpha,Project_Beta`. Leave blank if applies to all. |
| `functions` | No | Comma-separated strings | Network / work functions. Example: `RAN,Core` or `Civil,MW`. |
| `team` | No | Any string | Owning team. Example: `Network Quality`, `PMO`, `Rollout`. |
| `tags` | No | Comma-separated strings | Custom labels for search. Example: `volte,critical-kpi,q1-focus`. |

#### Category Decision Guide

| If the KPI measures… | Use |
|---|---|
| Achievement vs a numeric target (%, rate, score) | `performance` |
| Resource utilisation, headroom, near-capacity sites | `capacity` |
| Signal quality, error rates, packet loss, drop rates | `quality` |
| Uptime, availability, MTTR, fault rates | `reliability` |
| SLA adherence, milestone compliance, regulatory targets | `compliance` |
| Work volumes, cycle times, team throughput, general ops | `operational` |

---

### 4.3 Data Source Columns

| Column | Required | Rule |
|---|---|---|
| `source_table` | **Yes** (unless `custom_sql` provided) | Must exactly match a `table_name` from the Data_Sources sheet. |
| `kpi_column` | **Yes** (unless `custom_sql` provided) | The column that contains the metric value. Must exist in `source_table`. Case-sensitive. |
| `filter_conditions` | No | A SQL `WHERE` clause **fragment** — no `WHERE` keyword, just the condition. Example: `technology = 'LTE'` or `project_status != 'Cancelled'`. Leave blank if no filtering needed. Do **not** include geography filters here — the engine adds those automatically. |
| `geography_level` | **Yes** | See section 4.4 below. |

---

### 4.4 Geography Level

This is the **lowest geographic granularity** at which this KPI is meaningful.

| Value | Meaning | When to Use |
|---|---|---|
| `market` | City / cluster level | Most KPIs. If data exists at site level, aggregate to market. |
| `area` | Area / sub-region level | When market-level data doesn't exist or isn't useful. |
| `region` | Top-level regional rollup | High-level executive KPIs. |
| `overall` | National / program-level | Summary/program-health KPIs only. Use sparingly. |

**Rule:** Choose the level where insight is **actionable**. A site-level KPI that averages to market is still `market`. A program-level health score is `overall`.

**What the engine does with this:** It fans out the query across all geographies at the chosen level. If you pick `market`, the engine runs the query for every market and generates one insight per market.

---

### 4.5 Business Context Columns

These columns directly improve the quality and accuracy of LLM-generated insights. **Strongly recommended.**

| Column | Required | Rule |
|---|---|---|
| `unit` | No | Unit of measurement. Examples: `%`, `ms`, `Mbps`, `days`, `count`. Shown in insight text. |
| `target` | No | The desired / goal value as a **number**. Example: `95` (for 95%). Do not include the unit symbol. |
| `sla_threshold` | No | The minimum acceptable value as a **number**. Values below this are considered SLA breaches. Example: `85`. |
| `interpretation` | No | One or two sentences explaining what good and bad looks like. Example: `Lower is better. Values above 3% indicate a call quality problem requiring RAN investigation.` The LLM uses this verbatim. |
| `aggregation_method` | **Yes** | See section 4.6 below. |

#### Target vs SLA Threshold

- `target` = what you're **aiming for**. The stretch goal. Example: 95% on-time.
- `sla_threshold` = the **floor**. Below this is a formal breach. Example: 85% on-time.
- You can provide both, either, or neither. Both improves severity scoring significantly.
- If your KPI is "lower is better" (like error rates), set `target` lower than `sla_threshold`. Example: target = 1%, SLA = 3%.

---

### 4.6 Aggregation Method

Tells the engine how to combine multiple rows into one figure per geography.

| Value | SQL Equivalent | Use When |
|---|---|---|
| `avg` | `AVG(column)` | Rates, percentages, ratios. **Default for most KPIs.** Example: average drop rate across sites. |
| `sum` | `SUM(column)` | Counts, volumes, totals. Example: total delayed permits, total sites built. |
| `max` | `MAX(column)` | Worst-case values. Example: maximum latency observed, peak utilisation. |
| `min` | `MIN(column)` | Best-case values. Rarely used in practice. |
| `count` | `COUNT(*)` | Number of rows / sites matching a condition. Use when `kpi_column` is not a numeric metric. |

**Rule:** When in doubt, use `avg` for rates and percentages, `sum` for counts and volumes.

---

### 4.7 Prompt Template

Controls which LLM prompt structure is used to generate the insight text. Pick the one that best describes the nature of the analysis.

| Template | Best For |
|---|---|
| `performance_insight` | KPI vs target, identifying the worst-performing geography. **Default — use this if unsure.** |
| `trend_insight` | Period-over-period change, identifying improvement or deterioration patterns. |
| `capacity_insight` | Utilisation vs capacity limit, headroom analysis, sites near threshold. |
| `executive_summary_insight` | Program-level or national rollup. Use with `geography_level = overall` or `region`. |
| `vendor_performance` | Vendor / contractor scorecards, ranking vendors against each other. |
| `schedule_adherence` | Milestone compliance, on-time rates, delay analysis, SLA breach counts. |
| `anomaly_detection` | Statistical outliers, deviation from baseline, unusual spikes or drops. |
| `comparative_analysis` | This geography vs a benchmark (peer markets, national average). |
| `multi_kpi_synthesis` | A single query returns multiple KPI columns and you want cross-dimensional insight. |

---

### 4.8 Custom SQL (Advanced)

Leave `custom_sql` **blank** in most cases — the engine will generate SQL automatically via AI.

Provide `custom_sql` **only** when:
- The auto-generated SQL doesn't join correctly (complex multi-table logic)
- You need a subquery or window function
- You are joining multiple KPI columns for `multi_kpi_synthesis`

#### Rules for custom_sql

1. **SELECT only.** No `INSERT`, `UPDATE`, `DELETE`, `DROP`, `CREATE`, `TRUNCATE`. The engine blocks these.
2. **Do not include date or time filters.** No `WHERE date_col = ...`, no date parameters. The engine queries all available data in the table.
3. **Use named placeholders for geography only:**
   - `:market` — market filter (value or NULL)
   - `:area` — area filter (value or NULL)
   - `:region` — region filter (value or NULL)
4. **Always add `::text` casts** on every geo placeholder. Without the cast, asyncpg cannot determine the parameter type when the value is NULL and will throw an `AmbiguousParameterError`:
   ```sql
   AND (:market::text IS NULL OR market_col = :market::text)
   AND (:area::text   IS NULL OR area_col   = :area::text)
   AND (:region::text IS NULL OR region_col = :region::text)
   ```
5. The SELECT must include at minimum:
   - The geography identifier column(s)
   - A `value` alias for the main metric
   - A `site_count` alias (COUNT of distinct site IDs)
6. No trailing semicolon.
7. No markdown fences, no comments — raw SQL only.

#### Minimal custom_sql template

```sql
SELECT
    market_name,
    AVG(volte_drop_rate_pct)              AS value,
    COUNT(DISTINCT site_id)               AS site_count
FROM pm_data.network_kpis
WHERE technology = 'LTE'
  AND (:market::text IS NULL OR market_name = :market::text)
  AND (:area::text   IS NULL OR area_name   = :area::text)
  AND (:region::text IS NULL OR region_name = :region::text)
GROUP BY market_name
ORDER BY value DESC
```

---

## 5. Naming Rules Summary

| What | Rule | Bad Example | Good Example |
|---|---|---|---|
| `kpi_name` | snake_case, no spaces | `VoLTE Drop Rate` | `volte_drop_rate` |
| `table_name` | schema.table | `network_kpis` | `pm_data.network_kpis` |
| Column names | Exact match to DB | `Market_Name` (if DB has `market_name`) | `market_name` |
| `projects` / `functions` / `tags` | Comma-separated, no spaces around commas | `RAN , Core` | `RAN,Core` |
| `target` / `sla_threshold` | Numeric only, no % or units | `95%` | `95` |

---

## 6. Validation Errors vs Warnings

| Type | Meaning | Can You Proceed? |
|---|---|---|
| **Error** (red) | Blocking. Engine will not ingest this KPI. | No — fix before applying. |
| **Warning** (yellow) | Non-blocking. Engine will proceed but result may be suboptimal. | Yes — review and decide. |
| **Info** (blue) | Informational only. | Yes — no action needed. |

### Most Common Errors

| Error | Fix |
|---|---|
| `Table 'x' does not exist in source database` | Check schema prefix and spelling. Ask DBA for correct table name. |
| `Column 'x' not found in table 'y'` | Copy-paste column name from actual table DDL. |
| `custom_sql contains unsafe statements` | Remove any DML/DDL. Use SELECT only. No date filters. |
| `Required field 'kpi_name' is missing` | Fill in the blue-shaded mandatory columns. |
| `kpi_name must be unique` | Each row must have a different `kpi_name`. Add a suffix if needed (`volte_drop_rate_lte`). |

### Most Common Warnings

| Warning | Meaning |
|---|---|
| `source_table not found in Data_Sources sheet` | You referenced a table that isn't listed in the Data_Sources sheet. Add it there. |
| `Neither target nor sla_threshold provided` | Severity scoring will be less precise. Add target/SLA values if known. |

---

## 7. Field-by-Field Checklist

Use this before uploading:

### Data_Sources sheet
- [ ] Every `table_name` includes the schema prefix (`schema.table`)
- [ ] Every column name matches exactly what exists in the database (case-sensitive)
- [ ] At least one data source row exists

### KPI_Definitions sheet
- [ ] Every `kpi_name` is snake_case with no spaces or special characters
- [ ] Every `kpi_name` is unique
- [ ] `source_table` matches a `table_name` in the Data_Sources sheet
- [ ] `kpi_column` is a real column in `source_table`
- [ ] `geography_level` reflects the lowest meaningful level for this KPI
- [ ] `aggregation_method` is `avg` for rates/percentages, `sum` for counts/volumes
- [ ] `target` and `sla_threshold` are plain numbers (no % signs)
- [ ] `prompt_template` makes sense for this KPI type
- [ ] `custom_sql` (if provided) has NO date filters, uses `::text`-cast geo placeholders (`AND (:market::text IS NULL OR col = :market::text)`)
- [ ] No commas inside individual values in comma-separated fields (projects, functions, tags)

---

## 8. Quick Reference Card

```
MANDATORY (blue columns)
  kpi_name          → snake_case unique identifier
  source_table      → schema.table (must exist in DB)
  kpi_column        → column name (must exist in table)
  category          → performance | capacity | quality | reliability | compliance | operational
  geography_level   → market | area | region | overall
  aggregation_method→ avg | sum | max | min | count
  prompt_template   → see section 4.7

STRONGLY RECOMMENDED (grey columns)
  target            → numeric goal value
  sla_threshold     → numeric breach floor
  unit              → %, ms, Mbps, count, days…
  interpretation    → "Lower is better. Above X% = problem."

OPTIONAL
  display_name, description, purpose
  projects, functions, team, tags
  pm_category, subcategory
  filter_conditions (SQL WHERE fragment — geo/business filters only, NO date filters)
  custom_sql        (leave blank to use AI generation)

GEO PLACEHOLDER SYNTAX (mandatory in custom_sql)
  AND (:market::text IS NULL OR market_col = :market::text)
  AND (:area::text   IS NULL OR area_col   = :area::text)
  AND (:region::text IS NULL OR region_col = :region::text)
  ↑ ::text cast is required — asyncpg throws AmbiguousParameterError without it

NOT SUPPORTED
  date_column       → not used; engine queries all data in the table as-is
  :start_date / :end_date → not supported as SQL placeholders
```

---

## 9. Who to Contact

If you are unsure about:
- **Table names / column names** → ask the Data Engineering or DBA team
- **Target and SLA values** → ask the KPI owner or Network Quality team
- **Which prompt template to use** → default to `performance_insight`; the engine lead can advise
- **Custom SQL logic** → write a draft and note it in the `filter_conditions` column; the engine lead can convert it

---

*Template version: 1.0 — Insights Engine onboarding*
