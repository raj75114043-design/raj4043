# SQL Query Bank Enrichment — LLM Prompt Template

Use this prompt to have an LLM generate new SQL queries for the Insights Engine query library. Each query produced must follow the exact specification below or the engine will fail to execute it.

---

## Prompt (copy everything below this line)

---

You are helping populate a SQL query library for an automated **Insights Engine**. The engine runs each query against a PostgreSQL source database, feeds the results to an LLM, and generates operational insights for Project Managers in a telecom network operations context.

Your job: given a derived table's schema (columns, types, sample rows) and business context, produce one or more query library entries as a **JSON array**. Each entry must conform exactly to the specification below.

---

## Output Schema

Return a JSON array. Each element is one query entry:

```json
[
  {
    "name": "...",
    "query_sql": "...",
    "purpose": "...",
    "description": "...",
    "geography_level": "...",
    "projects": [...],
    "functions": [...],
    "tags": [...],
    "prompt_template": "...",
    "business_context": { ... },
    "row_limit": null,
    "group_by_column": null,
    "insight_areas": null,
    "pack_id": null,
    "pm_category": null
  }
]
```

---

## Field-by-Field Specification

### `name` (required, string, max 200 chars, must be unique)
- A short, snake_case identifier for the query.
- Convention: `<domain>_<metric>_by_<geography>` or `<domain>_<analysis_type>`.
- Examples: `nas_rejection_rate_by_market`, `volte_drop_rate_trend`, `punchpoint_ftr_performance`.

### `query_sql` (required, string — the actual SQL)
This is the most critical field. The SQL MUST follow these rules exactly:

#### Parameterisation (MANDATORY)
The engine injects these named bind parameters at runtime. Your SQL MUST use `:name` style placeholders — never `$1`, `?`, or `%s`.

| Parameter      | Type     | Always available | Required in SQL? | Description |
|----------------|----------|------------------|------------------|-------------|
| `:region`      | text     | Yes (may be NULL)| **YES** — with null-safe pattern | Region filter |
| `:area`        | text     | Yes (may be NULL)| **YES** — with null-safe pattern | Area filter |
| `:market`      | text     | Yes (may be NULL)| **YES** — with null-safe pattern | Market filter |
| `:limit`       | integer  | Yes              | No (engine wraps query in LIMIT) | Row limit (default 200) |

**Do NOT use date bind parameters.** Do not use `:start_date`, `:end_date`, or any date bind parameters. Date filtering is not applied as a runtime parameter like geography is. However, if the query intrinsically needs date logic (e.g., filtering to recent records or computing age), use hardcoded SQL expressions like `WHERE created_date > CURRENT_DATE - INTERVAL '30 days'` — just never bind parameters.

#### Null-safe geography filters (MANDATORY)
The engine calls each query at multiple geography levels (overall, region, area, market). At the overall level, `:region`, `:area`, and `:market` are all NULL. The SQL must gracefully handle this using this exact pattern:

```sql
WHERE (CAST(:region AS TEXT) IS NULL OR LOWER(region_column) = LOWER(:region))
  AND (CAST(:area   AS TEXT) IS NULL OR LOWER(area_column)   = LOWER(:area))
  AND (CAST(:market AS TEXT) IS NULL OR LOWER(market_column) = LOWER(:market))
```

Do NOT add date bind parameters (no `:start_date` or `:end_date`). If the query intrinsically needs date logic, use hardcoded SQL expressions (e.g., `WHERE created_date > CURRENT_DATE - INTERVAL '30 days'`).

- `CAST(:param AS TEXT) IS NULL` — this is required because asyncpg needs the cast to properly handle NULL bind parameters.
- `LOWER()` on BOTH sides — data may be stored as 'SOUTH', 'south', or 'South'. All comparisons MUST be case-insensitive.
- Never hardcode geography values.
- Never omit geography filters — even if you think the query is "only for market level", the engine may run it at other levels too.

#### Geography column aliases (MANDATORY)
The engine's aggregation step looks for columns named exactly `region`, `area`, `market`, or `site`/`site_id` in the result set. If your source table uses different column names, you MUST alias them:

```sql
SELECT
    geo.region_name  AS region,
    geo.area_name    AS area,
    geo.market_name  AS market,
    ...
```

If the query joins to a geography/dimension table that has columns like `rgn_name`, `mkt_code`, etc., alias them to the standard names. The engine will NOT find columns named `rgn_name` — it needs `region`, `area`, `market`.

#### Row granularity
- Return **site-level or entity-level rows** (one row per site/element/node).
- The engine aggregates these rows to the appropriate child geography level before passing to the LLM. Do NOT pre-aggregate in SQL to region/area level — that removes the detail the engine needs.

#### PostgreSQL compatibility (STRICTLY ENFORCED)
- `ROUND(value, n)` requires NUMERIC: always use `ROUND(expr::NUMERIC, 2)`, never `ROUND(double_precision, 2)`.
- Use `COALESCE()` for null safety, not `ISNULL()` or `IFNULL()`.
- Do NOT use `TOP N` — use `LIMIT N` or `:limit`.
- Do NOT use `GETDATE()` or `DATEDIFF()` — use PostgreSQL equivalents (`CURRENT_DATE`, `date1 - date2`).
- String concatenation: use `||` operator, not `+`.
- Boolean: use `TRUE`/`FALSE`, not `1`/`0`.

#### Safety
- Only SELECT statements. No DDL (CREATE, ALTER, DROP), no DML (INSERT, UPDATE, DELETE).
- No dynamic SQL or EXECUTE statements.

#### Example: standard query
```sql
SELECT
    s.site_id,
    s.site_name,
    g.region_name  AS region,
    g.area_name    AS area,
    g.market_name  AS market,
    f.rejection_rate,
    f.approval_rate,
    f.total_requests,
    f.ftr_rate
FROM derived_punchpoint_summary f
JOIN dim_sites s       ON s.site_key = f.site_key
JOIN dim_geography g   ON g.geo_key  = s.geo_key
WHERE (CAST(:region AS TEXT) IS NULL OR LOWER(g.region_name) = LOWER(:region))
  AND (CAST(:area   AS TEXT) IS NULL OR LOWER(g.area_name)   = LOWER(:area))
  AND (CAST(:market AS TEXT) IS NULL OR LOWER(g.market_name) = LOWER(:market))
```

#### Example: vendor comparison query (uses `group_by_column`)
When a query is designed to compare across vendors/contractors, include the vendor column in the SELECT and set `group_by_column` in the metadata to that column name. The engine will automatically aggregate by `(geography, vendor)` so the LLM sees a comparison table.

```sql
SELECT
    s.site_id,
    g.region_name       AS region,
    g.area_name         AS area,
    g.market_name       AS market,
    f.nas_company_name,
    f.rejection_rate,
    f.approval_rate,
    f.total_activities
FROM derived_vendor_performance f
JOIN dim_sites s       ON s.site_key = f.site_key
JOIN dim_geography g   ON g.geo_key  = s.geo_key
WHERE (CAST(:region AS TEXT) IS NULL OR LOWER(g.region_name) = LOWER(:region))
  AND (CAST(:area   AS TEXT) IS NULL OR LOWER(g.area_name)   = LOWER(:area))
  AND (CAST(:market AS TEXT) IS NULL OR LOWER(g.market_name) = LOWER(:market))
```
For this query, set `"group_by_column": "nas_company_name"` and `"prompt_template": "vendor_performance"` in the metadata.

### `purpose` (required, string)
- One sentence (max ~100 words) describing what the query analyses.
- This is injected into the LLM prompt as `**Purpose:** $purpose`.
- Be specific: "Identify markets with rejection rates above the 5% SLA threshold" — not "Look at rejections".

### `description` (optional, string)
- A longer description (2-4 sentences) explaining the business context, what the data represents, and what kind of insight the LLM should produce.
- Injected into the prompt as `**Description:** $description`.

### `geography_level` (required, string)
The **lowest** geography level at which this query is meaningful. The engine will also run it at higher levels.

| Value      | Meaning |
|------------|---------|
| `"market"` | Meaningful down to individual market level (most common) |
| `"area"`   | Only meaningful at area level or above |
| `"region"` | Only meaningful at region level or above |
| `"overall"`| Only run at overall/national level (no geo filtering) |

- If unsure, use `"market"` — the engine's aggregation handles rolling up to higher levels.

### `projects` (required, array of strings)
- Which project(s) this query is relevant to. Used to filter queries when generating insights for specific projects.
- Examples: `["NTM"]`, `["AHLOB", "NTM"]`, `["network_quality"]`.
- These values must match what users select in the UI filter bar.

### `functions` (required, array of strings)
- Which business function(s) this query serves. Used for filtering.
- Examples: `["PDM"]`, `["HSE", "Engineering"]`, `["Operations"]`.

### `tags` (required, array of strings)
- Free-form tags for discoverability and filtering.
- Include: the domain, the metric type, the analysis style.
- Examples: `["rejection-rate", "quality", "sla", "punchpoints"]`.

### `prompt_template` (required, string)
Which built-in prompt template to use when generating the insight. Choose the best match:

| Template Name               | Use When |
|-----------------------------|----------|
| `performance_insight`       | KPI vs target, outlier identification (DEFAULT — use when unsure) |
| `capacity_insight`          | Utilisation thresholds, headroom analysis |
| `executive_summary_insight` | Fleet-level roll-ups, overall health |
| `vendor_performance`        | Vendor/contractor scorecards, comparative vendor analysis |
| `schedule_adherence`        | Milestone and SLA compliance tracking |
| `anomaly_detection`         | Statistical outliers vs baseline |
| `comparative_analysis`      | Geography vs sibling/parent benchmark |
| `multi_kpi_synthesis`       | Cross-KPI multi-dimensional analysis |

### `business_context` (required, object)
Structured KPI metadata injected into the LLM prompt so it understands targets, thresholds, and how to interpret each metric. Use the multi-KPI format:

```json
{
  "kpis": [
    {
      "column": "rejection_rate",
      "kpi_name": "Rejection Rate",
      "unit": "%",
      "target": 5.0,
      "sla_threshold": 8.0,
      "lower_is_better": true,
      "aggregation": "avg",
      "interpretation": "Percentage of punchpoints rejected. Values above 5% need review; above 8% is SLA breach."
    },
    {
      "column": "ftr_rate",
      "kpi_name": "First Time Right Rate",
      "unit": "%",
      "target": 90.0,
      "sla_threshold": 85.0,
      "lower_is_better": false,
      "aggregation": "avg",
      "interpretation": "Percentage of punchpoints approved on first submission. Below 85% indicates quality issues."
    }
  ]
}
```

Each KPI object fields:

| Field             | Required | Description |
|-------------------|----------|-------------|
| `column`          | Yes      | Exact column name in the SQL result set (case-sensitive match used for aggregation rules) |
| `kpi_name`        | Yes      | Human-readable name shown in prompts |
| `unit`            | Yes      | Unit of measurement: `%`, `count`, `days`, `ms`, `Mbps`, etc. |
| `target`          | Yes      | Target/goal value. Used by LLM to assess severity. |
| `sla_threshold`   | No       | Hard SLA breach threshold. Deviation beyond this = high severity. |
| `lower_is_better` | Yes      | `true` for error rates, delays. `false` for throughput, success rates. |
| `aggregation`     | Yes      | How the engine should aggregate this column across sites: `"avg"`, `"sum"`, `"max"`, or `"min"`. Use `"avg"` for rates/percentages, `"sum"` for counts/volumes. |
| `interpretation`  | Yes      | 1-2 sentences explaining what this metric means and what values are concerning. The LLM reads this to calibrate severity. |

**Aggregation rules matter.** The engine aggregates site-level rows to geography level before passing to the LLM. If you set `"aggregation": "sum"` for a percentage column, the LLM will see nonsensical summed percentages. Rules:
- Rates, percentages, ratios, scores → `"avg"`
- Counts, volumes, totals, events → `"sum"`
- Worst-case metrics (peak latency, max error) → `"max"`
- Best-case metrics (minimum throughput) → `"min"`

### `row_limit` (optional, integer, 1-2000, default: null → engine default of 200)
- Max rows fetched from the source DB per query execution.
- Increase for queries that need more site-level detail (e.g., 500 for large markets).
- Leave `null` for most queries.

### `group_by_column` (optional, string, default: null)
- Column name for secondary grouping alongside geography (e.g., vendor/company analysis).
- When set, the engine aggregates by `(geography, group_by_column)` instead of just geography. This means the LLM sees rows like:

  | market  | nas_company_name | site_count | rejection_rate_avg | ... |
  |---------|------------------|------------|--------------------|-----|
  | Camden  | Vendor A         | 45         | 3.2                | ... |
  | Camden  | Vendor B         | 38         | 7.8                | ... |

  This lets the LLM compare vendor performance within each geography.
- **The value must exactly match a column name in the SQL SELECT result set.** The engine resolves it using case-insensitive matching and suffix patterns (e.g., `_name`, `_company`), but an exact match is safest.
- Examples: `"nas_company_name"`, `"vendor"`, `"contractor"`, `"company_name"`.
- When using `group_by_column`, also set `"prompt_template": "vendor_performance"` so the LLM prompt is tuned for comparative vendor analysis.
- Only set this if vendor/company/contractor comparison is relevant to the query. Leave `null` otherwise — the engine will aggregate purely by geography.

### `insight_areas` (optional, array of strings, default: null)
- When a single query's data can produce multiple distinct insights covering different analysis angles, list them here.
- Each area produces a separate insight at every geography node. The engine instructs the LLM to focus exclusively on each area and not repeat findings.
- Example: `["Approval & Rejection Rates", "FTR Performance", "Outage Impact"]`
- Leave `null` for queries that naturally produce a single insight.
- Only use when the SQL returns columns spanning genuinely different analytical themes.

### `pack_id` (optional, string, default: null)
- Groups multiple queries into an "Insight Pack" — all queries in the same pack share one feed card on the homepage.
- Use the same `pack_id` string across related queries (e.g., all quality queries for a project).
- Convention: `"PROJECT_DOMAIN"` e.g., `"NTM_QUALITY"`, `"AHLOB_SCHEDULE"`.
- Leave `null` if the query stands alone.

### `pm_category` (optional, string, default: null)
- Project management category for organising insights.
- Common values: `"Cost"`, `"Quality"`, `"Schedule"`, `"Vendor Performance"`, `"Risk"`, `"Safety"`.
- Leave `null` if not applicable.

---

## Common Mistakes to Avoid

1. **Missing CAST(:param AS TEXT)** — Writing `WHERE :region IS NULL OR ...` will fail. asyncpg needs the explicit cast: `CAST(:region AS TEXT) IS NULL`.

2. **Missing LOWER() on geography comparisons** — `WHERE region = :region` will miss rows where data is stored as 'SOUTH' but the parameter is 'South'. Always: `LOWER(col) = LOWER(:param)`.

3. **Pre-aggregating to geography level** — Do NOT write `GROUP BY region`. Return site-level rows; the engine aggregates.

4. **Wrong column aliases** — The engine looks for columns named `region`, `area`, `market`, `site`, `site_id`. If your table has `rgn_name`, alias it: `rgn_name AS region`.

5. **Using ROUND(float, n)** — PostgreSQL requires: `ROUND(expr::NUMERIC, 2)`.

6. **Aggregation mismatch in business_context** — Setting `"aggregation": "sum"` for a percentage column produces garbage. Rates/percentages = `"avg"`, counts = `"sum"`.

7. **Using date bind parameters** — Do NOT use `:start_date` or `:end_date`. Date filtering is not a runtime parameter. If the query needs date logic, hardcode it in SQL (e.g., `WHERE created > CURRENT_DATE - 30`).

8. **Using $1 or ? placeholders** — The engine uses SQLAlchemy `text()` with `:name` style only. `$1`, `?`, `%s` will all fail.

9. **Hardcoded geography values** — Never write `WHERE market = 'London'`. Always use the bind parameters.

10. **Missing `purpose`** — The LLM sees this in its prompt. A vague purpose produces vague insights. Be specific about what the data should reveal.

---

## Input You Will Receive

For each derived table I want queries for, I will provide:

1. **Table name** (fully qualified, e.g., `schema.table_name`)
2. **Column list** with data types
3. **Sample rows** (5-10 rows)
4. **Business context**: what this table tracks, who uses it, what decisions it supports
5. **Geography columns**: which columns map to region/area/market
6. **Vendor/grouping column** (if any): which column represents vendor/contractor for comparative analysis
7. **Projects and functions**: which PM projects and business functions use this data

Generate as many queries as are analytically meaningful for the table. Typical output: 3-8 queries per table covering different analytical angles (performance vs target, outliers, vendor comparison, etc.).

---

## Validation Checklist (apply to every query you generate)

Before outputting each query, verify:

- [ ] Has null-safe geography filters with `CAST(:region AS TEXT) IS NULL OR LOWER(col) = LOWER(:region)` pattern for ALL THREE geo levels (region, area, market)
- [ ] No date bind parameters (no `:start_date` or `:end_date`). Hardcoded date logic like `CURRENT_DATE - 30` is fine.
- [ ] Geography columns are aliased to `region`, `area`, `market`
- [ ] Returns site-level rows (not pre-aggregated to geo level)
- [ ] All `ROUND()` calls use `::NUMERIC` cast
- [ ] `business_context.kpis[].column` values exactly match column aliases in the SELECT
- [ ] `business_context.kpis[].aggregation` is correct (`avg` for rates, `sum` for counts)
- [ ] `prompt_template` matches the analysis type
- [ ] If `group_by_column` is set, the column exists in the SQL SELECT and `prompt_template` is `"vendor_performance"`
- [ ] `name` is unique, descriptive, snake_case
- [ ] Pure SELECT — no DDL/DML
- [ ] No hardcoded geography values
- [ ] PostgreSQL-compatible syntax only (no DATEDIFF, ISNULL, TOP, GETDATE)
