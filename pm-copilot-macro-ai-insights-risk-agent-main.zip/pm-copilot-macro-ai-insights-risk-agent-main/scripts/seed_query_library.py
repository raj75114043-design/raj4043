"""
Seed Script — populates sql_query_library and prompt_templates tables
from the YAML config files.

Usage:
    python scripts/seed_query_library.py
"""
from __future__ import annotations

import asyncio
import uuid
from pathlib import Path

import yaml
from sqlalchemy import select

from app.database import get_insights_session_factory, init_db
from app.models.query_library import PromptTemplate, SqlQueryLibrary
from app.utils.prompt_library import BASE_SYSTEM_PROMPT, BUILT_IN_TEMPLATES


async def seed_prompt_templates(session) -> dict[str, str]:
    """Insert built-in prompt templates. Return name → template_id map."""
    template_map: dict[str, str] = {}

    for name, user_prompt in BUILT_IN_TEMPLATES.items():
        # Check if already exists
        stmt = select(PromptTemplate).where(PromptTemplate.name == name)
        existing = (await session.execute(stmt)).scalar_one_or_none()
        if existing:
            print(f"  [SKIP] Prompt template already exists: {name}")
            template_map[name] = existing.template_id
            continue

        template_id = str(uuid.uuid4())
        template = PromptTemplate(
            template_id=template_id,
            name=name,
            system_prompt=BASE_SYSTEM_PROMPT,
            user_prompt=user_prompt,
        )
        session.add(template)
        template_map[name] = template_id
        print(f"  [ADD] Prompt template: {name}")

    await session.flush()
    return template_map


async def seed_sql_queries(session, template_map: dict[str, str]) -> None:
    """Load queries from YAML and insert into sql_query_library."""
    config_path = Path("config/query_library.yml")
    if not config_path.exists():
        print(f"Query library YAML not found at {config_path} — skipping")
        return

    with config_path.open() as f:
        data = yaml.safe_load(f)

    for q in data.get("queries", []):
        stmt = select(SqlQueryLibrary).where(SqlQueryLibrary.name == q["name"])
        existing = (await session.execute(stmt)).scalar_one_or_none()
        if existing:
            print(f"  [SKIP] SQL query already exists: {q['name']}")
            continue

        template_name = q.get("prompt_template", "performance_insight")
        template_id = template_map.get(template_name)

        query = SqlQueryLibrary(
            query_id=str(uuid.uuid4()),
            name=q["name"],
            query_sql=q["query_sql"],
            purpose=q.get("purpose"),
            description=q.get("description"),
            geography_level=q.get("geography_level"),
            projects=q.get("projects"),
            functions=q.get("functions"),
            team=q.get("team"),
            tags=q.get("tags"),
            parameter_schema=q.get("parameter_schema"),
            prompt_template_id=template_id,
            is_active=True,
        )
        session.add(query)
        print(f"  [ADD] SQL query: {q['name']}")

    await session.flush()


async def main() -> None:
    print("=== Seeding Query Library ===")
    await init_db()

    factory = get_insights_session_factory()
    async with factory() as session:
        print("\n> Seeding prompt templates...")
        template_map = await seed_prompt_templates(session)
        print(f"\n> Seeding SQL queries from config/query_library.yml...")
        await seed_sql_queries(session, template_map)
        await session.commit()

    print("\n=== Seeding complete ===")


if __name__ == "__main__":
    asyncio.run(main())
