"""
Validate and Import SQL Queries from LLM-generated JSON.

Usage:
    # Validate only (dry run):
    python scripts/validate_and_import_queries.py queries.json

    # Validate + import into the database:
    python scripts/validate_and_import_queries.py queries.json --import

    # Validate + test SQL against source DB:
    python scripts/validate_and_import_queries.py queries.json --test-sql

    # All together:
    python scripts/validate_and_import_queries.py queries.json --test-sql --import

Input: a JSON file containing an array of query objects matching the
       sql_query_enrichment_template.md specification.
"""
from __future__ import annotations

import asyncio
import json
import re
import sys
from pathlib import Path

# ── Validation constants ─────────────────────────────────────────────
_VALID_GEO_LEVELS = {"market", "area", "region", "overall"}
_VALID_TEMPLATES = {
    "performance_insight",
    "trend_insight",
    "capacity_insight",
    "executive_summary_insight",
    "vendor_performance",
    "schedule_adherence",
    "anomaly_detection",
    "comparative_analysis",
    "multi_kpi_synthesis",
}
_VALID_AGGREGATIONS = {"avg", "sum", "max", "min"}
_PARAM_RE = re.compile(r":([a-zA-Z_][a-zA-Z0-9_]*)")
_GEO_ALIAS_RE = re.compile(r"\bAS\s+(region|area|market)\b", re.IGNORECASE)
_DANGEROUS_KEYWORDS = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|TRUNCATE|EXECUTE|GRANT|REVOKE)\b",
    re.IGNORECASE,
)


def validate_query(q: dict, idx: int = 0) -> tuple[list[str], list[str]]:  # noqa: ARG001
    """Validate a single query entry. Returns (errors, warnings)."""
    errors: list[str] = []
    warnings: list[str] = []

    name = q.get("name")
    if not name or not isinstance(name, str):
        errors.append("missing or invalid 'name'")
    else:
        if len(name) > 200:
            errors.append(f"name exceeds 200 chars ({len(name)})")
        if not re.match(r"^[a-z0-9_]+$", name):
            errors.append(f"name should be snake_case (got '{name}')")

    # ── query_sql ────────────────────────────────────────────────────
    sql = q.get("query_sql", "")
    if not sql or not isinstance(sql, str):
        errors.append("missing 'query_sql'")
    else:
        sql_upper = sql.upper()

        # Must be a SELECT
        first_word = sql.strip().split()[0].upper() if sql.strip() else ""
        if first_word not in ("SELECT", "WITH"):
            errors.append(f"query_sql must start with SELECT or WITH (got '{first_word}')")

        # No dangerous keywords
        dangerous = _DANGEROUS_KEYWORDS.findall(sql)
        if dangerous:
            errors.append(f"query_sql contains forbidden keywords: {dangerous}")

        # Check for null-safe geo filters
        for param in ("region", "area", "market"):
            cast_pattern = f"CAST(:{param} AS TEXT) IS NULL"
            if cast_pattern.upper() not in sql_upper:
                errors.append(
                    f"missing null-safe filter for :{param} — "
                    f"need: CAST(:{param} AS TEXT) IS NULL OR LOWER(col) = LOWER(:{param})"
                )

        # Check for LOWER() on geo comparisons
        for param in ("region", "area", "market"):
            lower_pattern = f"LOWER(:{param})"
            if f":{param}" in sql and lower_pattern.upper() not in sql_upper:
                errors.append(f":{param} used without LOWER() — geo comparisons must be case-insensitive")

        # Check for date bind params (should not be present)
        used_params = set(_PARAM_RE.findall(sql))
        date_params = used_params & {"start_date", "end_date"}
        if date_params:
            errors.append(f"uses date bind parameters {date_params} — not allowed, hardcode date logic instead")

        # Check for ROUND without ::NUMERIC — find each ROUND( and balance parens
        for m in re.finditer(r"ROUND\s*\(", sql, re.IGNORECASE):
            start = m.start()
            depth = 0
            end = start
            for j in range(m.end() - 1, len(sql)):
                if sql[j] == "(":
                    depth += 1
                elif sql[j] == ")":
                    depth -= 1
                    if depth == 0:
                        end = j + 1
                        break
            round_expr = sql[start:end]
            # Only check ROUND calls with a precision arg (has a comma at depth-1)
            # Find the top-level comma
            d = 0
            has_precision = False
            for ch in round_expr[m.end() - start:]:
                if ch == "(":
                    d += 1
                elif ch == ")":
                    d -= 1
                elif ch == "," and d == 0:
                    has_precision = True
                    break
            if has_precision and "::NUMERIC" not in round_expr.upper():
                snippet = round_expr.replace("\n", " ").strip()
                if len(snippet) > 120:
                    snippet = snippet[:120] + "..."
                errors.append(f"ROUND with precision requires ::NUMERIC cast: {snippet}")

        # Check for geography column aliases in SELECT
        select_part = sql.split("WHERE")[0] if "WHERE" in sql.upper() else sql
        found_aliases = set(a.lower() for a in _GEO_ALIAS_RE.findall(select_part))
        for expected in ("region", "area", "market"):
            if expected not in found_aliases and expected not in select_part.lower().split():
                pass  # Soft check — the column might be named exactly right

    # ── purpose ──────────────────────────────────────────────────────
    if not q.get("purpose"):
        errors.append("missing 'purpose'")

    # ── geography_level ──────────────────────────────────────────────
    geo = q.get("geography_level")
    if not geo:
        errors.append("missing 'geography_level'")
    elif geo.lower() not in _VALID_GEO_LEVELS:
        errors.append(f"invalid geography_level '{geo}' — must be one of {_VALID_GEO_LEVELS}")

    # ── projects ─────────────────────────────────────────────────────
    projects = q.get("projects")
    if not projects or not isinstance(projects, list) or len(projects) == 0:
        errors.append("missing or empty 'projects' (must be a non-empty array)")

    # ── functions ────────────────────────────────────────────────────
    functions = q.get("functions")
    if not functions or not isinstance(functions, list) or len(functions) == 0:
        errors.append("missing or empty 'functions' (must be a non-empty array)")

    # ── tags ─────────────────────────────────────────────────────────
    tags = q.get("tags")
    if not tags or not isinstance(tags, list) or len(tags) == 0:
        errors.append("missing or empty 'tags' (must be a non-empty array)")

    # ── prompt_template ──────────────────────────────────────────────
    template = q.get("prompt_template")
    if not template:
        errors.append("missing 'prompt_template'")
    elif template not in _VALID_TEMPLATES:
        errors.append(f"invalid prompt_template '{template}' — must be one of {sorted(_VALID_TEMPLATES)}")

    # ── business_context ─────────────────────────────────────────────
    bc = q.get("business_context")
    if not bc or not isinstance(bc, dict):
        errors.append("missing or invalid 'business_context' (must be an object)")
    else:
        kpis = bc.get("kpis")
        if not kpis or not isinstance(kpis, list):
            errors.append("business_context must have a 'kpis' array")
        else:
            for ki, kpi in enumerate(kpis):
                kp = f"kpis[{ki}]"
                if not kpi.get("column"):
                    errors.append(f"{kp}: missing 'column'")
                else:
                    col = kpi["column"]
                    if sql and col.lower() not in sql.lower():
                        errors.append(f"{kp}: column '{col}' not found in query_sql")
                if not kpi.get("kpi_name"):
                    errors.append(f"{kp}: missing 'kpi_name'")
                if not kpi.get("unit"):
                    errors.append(f"{kp}: missing 'unit'")
                if kpi.get("target") is None:
                    errors.append(f"{kp}: missing 'target'")
                if kpi.get("lower_is_better") is None:
                    errors.append(f"{kp}: missing 'lower_is_better'")
                agg = kpi.get("aggregation")
                if not agg:
                    errors.append(f"{kp}: missing 'aggregation'")
                elif agg not in _VALID_AGGREGATIONS:
                    errors.append(f"{kp}: invalid aggregation '{agg}' — must be one of {_VALID_AGGREGATIONS}")
                if not kpi.get("interpretation"):
                    errors.append(f"{kp}: missing 'interpretation'")

    # ── group_by_column consistency ──────────────────────────────────
    gbc = q.get("group_by_column")
    if gbc:
        if sql and gbc.lower() not in sql.lower():
            errors.append(f"group_by_column '{gbc}' not found in query_sql")
        if template and template != "vendor_performance":
            warnings.append(
                f"group_by_column is set but prompt_template is '{template}' — consider 'vendor_performance'"
            )

    # ── row_limit ────────────────────────────────────────────────────
    rl = q.get("row_limit")
    if rl is not None:
        if not isinstance(rl, int) or rl < 1 or rl > 2000:
            errors.append(f"row_limit must be 1-2000 (got {rl})")

    # ── insight_areas ────────────────────────────────────────────────
    areas = q.get("insight_areas")
    if areas is not None:
        if not isinstance(areas, list) or not all(isinstance(a, str) for a in areas):
            errors.append("insight_areas must be an array of strings")

    return errors, warnings


def validate_all(queries: list[dict]) -> tuple[int, int, dict[str, list[str]], dict[str, list[str]]]:
    """Validate all queries. Returns (passed, failed, errors_by_query, warnings_by_query)."""
    errors_by_query: dict[str, list[str]] = {}
    warnings_by_query: dict[str, list[str]] = {}
    names_seen: set[str] = set()
    passed = 0
    failed = 0

    for i, q in enumerate(queries):
        errs, warns = validate_query(q, i)

        # Check name uniqueness across the batch
        name = q.get("name", f"[{i}]")
        if name in names_seen:
            errs.append(f"Duplicate name in this batch")
        names_seen.add(name)

        if errs:
            failed += 1
            errors_by_query[name] = errs
        else:
            passed += 1

        if warns:
            warnings_by_query[name] = warns

    return passed, failed, errors_by_query, warnings_by_query


async def test_sql_against_db(queries: list[dict]) -> dict[str, dict]:
    """Test-run each query's SQL against the source DB. Returns per-query results."""
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    import logging
    logging.getLogger("sqlalchemy").setLevel(logging.ERROR)
    logging.getLogger("app").setLevel(logging.ERROR)

    from app.database import get_source_session_factory, init_db
    from sqlalchemy import bindparam, text
    from sqlalchemy.types import String

    await init_db()
    factory = get_source_session_factory()
    results: dict[str, dict] = {}

    async with factory() as db:
        for i, q in enumerate(queries):
            name = q.get("name", f"[{i}]")
            sql = q.get("query_sql", "")
            if not sql:
                continue

            test_params = {"region": None, "area": None, "market": None}
            used = set(_PARAM_RE.findall(sql))
            bound = {k: v for k, v in test_params.items() if k in used}

            try:
                bp_list = [bindparam(k, type_=String) for k in bound]
                stmt = text(f"SELECT * FROM ({sql.rstrip(';')}) _q LIMIT 5").bindparams(*bp_list)
                result = await db.execute(stmt, bound)
                cols = list(result.keys())
                rows = result.fetchall()

                warnings: list[str] = []

                # Check geo aliases
                col_lower = [c.lower() for c in cols]
                missing_geo = [g for g in ("region", "area", "market") if g not in col_lower]
                if missing_geo:
                    warnings.append(f"missing geo column aliases in results: {missing_geo}")

                # Check group_by_column
                gbc = q.get("group_by_column")
                if gbc and gbc.lower() not in col_lower:
                    warnings.append(f"group_by_column '{gbc}' not in result columns: {cols}")

                # Check KPI columns
                bc = q.get("business_context") or {}
                for kpi in bc.get("kpis") or []:
                    kpi_col = kpi.get("column", "")
                    if kpi_col.lower() not in col_lower:
                        warnings.append(f"KPI column '{kpi_col}' not in result columns: {cols}")

                results[name] = {
                    "status": "OK",
                    "row_count": len(rows),
                    "columns": cols,
                    "warnings": warnings,
                    "error": None,
                }

            except Exception as exc:
                # Extract the core error message, strip SQLAlchemy wrapper noise
                err_msg = str(exc)
                # Pull out the PostgreSQL error if present
                if "asyncpg" in err_msg:
                    match = re.search(r"<class '[^']+'>:\s*(.+?)(?:\n|$)", err_msg)
                    if match:
                        err_msg = match.group(1).strip()
                results[name] = {
                    "status": "FAIL",
                    "row_count": 0,
                    "columns": [],
                    "warnings": [],
                    "error": err_msg,
                }
                try:
                    await db.rollback()
                except Exception:
                    pass

    return results


async def import_queries(queries: list[dict]) -> list[str]:
    """Import validated queries into the sql_query_library table."""
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    from app.database import get_insights_session_factory, init_db
    from app.models.query_library import SqlQueryLibrary
    from sqlalchemy import select

    await init_db()
    factory = get_insights_session_factory()
    results: list[str] = []

    async with factory() as db:
        for i, q in enumerate(queries):
            name = q.get("name", f"auto_{i}")

            # Check for duplicate name
            existing = (
                await db.execute(
                    select(SqlQueryLibrary).where(SqlQueryLibrary.name == name)
                )
            ).scalar_one_or_none()
            if existing:
                results.append(f"  SKIP '{name}': already exists (id={existing.query_id})")
                continue

            entry = SqlQueryLibrary(
                name=name,
                query_sql=q["query_sql"].rstrip(";"),
                purpose=q.get("purpose"),
                description=q.get("description"),
                geography_level=q.get("geography_level"),
                projects=q.get("projects"),
                functions=q.get("functions"),
                tags=q.get("tags"),
                team=q.get("team"),
                prompt_template_id=q.get("prompt_template"),
                business_context=q.get("business_context"),
                pack_id=q.get("pack_id"),
                pm_category=q.get("pm_category"),
                row_limit=q.get("row_limit"),
                group_by_column=q.get("group_by_column"),
                insight_areas=q.get("insight_areas"),
                is_active=True,
            )
            db.add(entry)
            results.append(f"  ADD '{name}': saved to query library")

        await db.commit()

    return results


async def main() -> None:
    import os
    os.environ["DEBUG"] = "False"  # suppress SQLAlchemy echo in --test-sql mode

    if len(sys.argv) < 2:
        print("Usage: python scripts/validate_and_import_queries.py <queries.json> [--test-sql] [--import]")
        sys.exit(1)

    json_path = Path(sys.argv[1])
    do_test = "--test-sql" in sys.argv
    do_import = "--import" in sys.argv

    if not json_path.exists():
        print(f"File not found: {json_path}")
        sys.exit(1)

    with json_path.open() as f:
        data = json.load(f)

    if isinstance(data, dict) and "queries" in data:
        queries = data["queries"]
    elif isinstance(data, list):
        queries = data
    else:
        print("JSON must be an array of query objects or an object with a 'queries' key.")
        sys.exit(1)

    print(f"\n{'=' * 60}")
    print(f"  Validating {len(queries)} queries from {json_path.name}")
    if do_test:
        print(f"  (includes SQL execution test against source DB)")
    print(f"{'=' * 60}\n")

    passed, failed, errors_by_query, warnings_by_query = validate_all(queries)

    # If --test-sql, run SQL tests and merge results
    sql_test_results: dict[str, dict] = {}
    if do_test:
        sql_test_results = await test_sql_against_db(queries)
        # Merge SQL test failures into errors_by_query
        for name, result in sql_test_results.items():
            if result["status"] == "FAIL":
                if name not in errors_by_query:
                    errors_by_query[name] = []
                    failed += 1
                    passed -= 1
                errors_by_query[name].append(f"SQL execution error: {result['error']}")
            for w in result.get("warnings", []):
                if name not in errors_by_query:
                    errors_by_query[name] = []
                    failed += 1
                    passed -= 1
                errors_by_query[name].append(w)

    # Print per-query results
    for i, q in enumerate(queries):
        name = q.get("name", f"[{i}]")
        if name in errors_by_query:
            print(f"  FAIL  {name}")
            for e in errors_by_query[name]:
                print(f"          - {e}")
        else:
            info = ""
            if name in sql_test_results and sql_test_results[name]["status"] == "OK":
                r = sql_test_results[name]
                info = f"  ({r['row_count']} rows, {len(r['columns'])} cols)"
            print(f"  OK    {name}{info}")
        if name in warnings_by_query:
            for w in warnings_by_query[name]:
                print(f"          ! WARN: {w}")

    # Summary
    print(f"\n{'-' * 60}")
    print(f"  {passed} passed, {failed} failed out of {len(queries)} queries")
    print(f"{'-' * 60}\n")

    if failed > 0:
        print("Fix the errors above before importing.")
        if not do_import:
            sys.exit(1)

    if do_import:
        if failed > 0:
            print("Cannot import — fix validation errors first.")
            sys.exit(1)
        print("=== Importing into query library ===\n")
        import_results = await import_queries(queries)
        for r in import_results:
            print(r)
        print()
        print("Import complete.")


if __name__ == "__main__":
    asyncio.run(main())
