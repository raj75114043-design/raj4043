-- PostgreSQL initialisation script (runs once on first container start)
-- Creates the pgvector extension in the insights database

CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
