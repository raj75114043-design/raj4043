"""
One-time script to update ahloa_insights_query_bank_v5_final.json:
1. Assign appropriate prompt_template per query (not all vendor_performance)
2. Assign unique pack_id per query
3. Add :start_date/:end_date time filters where relevant date columns exist
4. Normalize functions to PDM / HSE / DEC
"""
import json
import re
import sys

INPUT = "ahloa_insights_query_bank_v5_final.json"
OUTPUT = INPUT  # overwrite in place

# ── Template assignment rules ──────────────────────────────────────
# vendor_performance: queries that compare across GCs with group_by_column
# schedule_adherence: milestone timing, swap scheduling, schedule slips
# performance_insight: KPI vs target, pass/fail rates, compliance rates
# anomaly_detection: outlier detection, unusual patterns
# comparative_analysis: geography vs benchmark
# trend_insight: weekly/period-over-period trends
# multi_kpi_synthesis: queries with multiple KPIs and insight_areas
# capacity_insight: utilisation, headroom

TEMPLATE_MAP = {
    # Schedule-related
    "schedule_site_priority_distribution": "performance_insight",      # classification, no GC comparison
    "schedule_entitlement_ntp_readiness": "schedule_adherence",        # milestone readiness
    "schedule_forecast_deviation_by_market": "schedule_adherence",     # forecast vs actual
    "schedule_prereq_ready_not_scheduled": "schedule_adherence",       # scheduling gaps
    "schedule_swap_readiness_by_market": "schedule_adherence",         # readiness checklist
    "schedule_rescheduling_frequency": "anomaly_detection",            # pattern detection
    "schedule_slip_rate_weekly": "trend_insight",                      # weekly trend
    "schedule_past_due_sites_ageing": "schedule_adherence",            # ageing / overdue
    "schedule_swap_lead_time_outliers": "anomaly_detection",           # outlier detection
    "schedule_run_rate_pace_weekly": "trend_insight",                  # weekly pace trend

    # Ops-related
    "ops_nesting_sites_today": "performance_insight",                  # daily snapshot
    "ops_sites_without_spo": "performance_insight",                    # missing data flag
    "ops_call_test_pass_rate": "performance_insight",                  # pass/fail rate
    "ops_48hr_alarm_clearance_status": "performance_insight",          # clearance performance
    "ops_swap_wip_sites": "schedule_adherence",                        # WIP tracking
    "ops_gc_capacity_utilisation_by_market": "capacity_insight",       # utilisation
    "ops_gc_milestone_update_pending": "performance_insight",          # pending updates
    "ops_site_completion_rate": "performance_insight",                 # completion rate
    "ops_swap_cycle_time_breakdown": "schedule_adherence",             # cycle time breakdown
    "ops_maintenance_window_exceeded": "anomaly_detection",            # exceeded windows
    "ops_missing_prerequisite_inputs": "schedule_adherence",           # prerequisite gaps
    "ops_site_outage_index_monitoring": "anomaly_detection",           # outage monitoring

    # Quality-related
    "quality_post_swap_discrepancy_rate": "performance_insight",       # discrepancy rate
    "quality_rollback_and_fault_rate": "performance_insight",          # fault rate
    "quality_swap_ftr_and_reworks": "performance_insight",             # FTR rate
    "quality_ndpc_punchpoint_rate_by_gc": "vendor_performance",        # GC comparison
    "quality_repeated_punchpoint_patterns": "anomaly_detection",       # pattern detection
    "quality_ndpc_upload_compliance_daily": "performance_insight",     # compliance rate
    "quality_closeout_velocity_3days": "performance_insight",          # velocity metric
    "quality_repeated_fault_incidents_by_gc": "vendor_performance",    # GC comparison
    "quality_vendor_scorecard_pp_ftr": "vendor_performance",           # vendor scorecard
    "quality_closeout_approval_pending_7days": "schedule_adherence",   # pending approvals ageing
    "quality_scop_closeout_timeline": "schedule_adherence",            # closeout timeline

    # HSE-related
    "hse_compliance_rate_by_market": "performance_insight",            # compliance rate
    "hse_site_revisit_frequency": "performance_insight",               # revisit frequency
    "hse_ppe_jsa_completion_rate": "performance_insight",              # completion rate
    "hse_work_stop_and_process_failures": "anomaly_detection",         # incident patterns
    "hse_daily_checkin_compliance": "performance_insight",             # daily compliance
    "hse_ppe_jsa_swap_without_compliance": "performance_insight",      # compliance gap
    "hse_work_stop_incident_frequency": "anomaly_detection",           # incident frequency

    # Material-related
    "material_disposal_doc_compliance": "performance_insight",         # compliance check
    "material_bom_availability_by_market": "schedule_adherence",       # BOM readiness
    "material_idle_stock_ageing": "schedule_adherence",                # ageing
    "material_radio_swap_vs_return_status": "performance_insight",     # swap vs return
    "material_pickup_adherence_by_gc": "vendor_performance",           # GC adherence comparison
    "material_bom_lock_precision_5weeks": "performance_insight",       # precision metric
    "material_pickup_lead_time_by_gc": "vendor_performance",           # GC lead time comparison
    "material_disposal_adherence_ratio": "performance_insight",        # adherence ratio
    "material_idle_stock_over_2weeks": "schedule_adherence",           # ageing
    "material_vendor_pickup_delay_vs_median": "comparative_analysis",  # vs median benchmark
    "material_disposal_certificate_compliance": "performance_insight", # compliance

    # Finance-related
    "finance_payment_trigger_status": "performance_insight",           # trigger status
    "finance_po_validation_status": "performance_insight",             # validation status
    "finance_ca_gr_trigger_delay": "schedule_adherence",               # delay tracking
    "finance_ca_trigger_compliance": "performance_insight",            # compliance
    "finance_po_milestone_completeness": "performance_insight",        # completeness
    "finance_gr_trigger_sla_compliance": "performance_insight",        # compliance rate
}

# ── Function normalization ─────────────────────────────────────────
# Map existing functions to PDM / HSE / DEC
FUNCTION_MAP = {
    "PDM": "PDM",
    "HSE": "HSE",
    "DEC": "DEC",                 # Already mapped — keep stable
    "Operations": "PDM",          # Ops falls under PDM
    "Engineering": "DEC",         # Engineering = DEC (Quality)
    "Quality": "DEC",             # Quality = DEC
    "Finance": "PDM",             # Finance rolls up to PDM
    "Supply Chain": "PDM",        # Supply chain rolls up to PDM
}

# ── Date filter logic ──────────────────────────────────────────────
# Queries that already have hardcoded date logic (CURRENT_DATE, INTERVAL)
# should NOT get :start_date/:end_date added — they're designed for
# specific time windows. We add date filters only to queries that have
# datable columns but no existing time constraint.

# Queries where we should NOT add date filters:
NO_DATE_FILTER = {
    # No date columns at all
    "schedule_site_priority_distribution",
    "hse_site_revisit_frequency",
    "ops_sites_without_spo",
    # Already has CURRENT_DATE / INTERVAL logic baked in
    "ops_nesting_sites_today",              # CURRENT_DATE
    "schedule_prereq_ready_not_scheduled",  # CURRENT_DATE with milestone checks
    "ops_swap_wip_sites",                   # CURRENT_DATE
    "material_bom_lock_precision_5weeks",   # CURRENT_DATE - INTERVAL
    "schedule_past_due_sites_ageing",       # CURRENT_DATE
    "quality_ndpc_upload_compliance_daily",  # CURRENT_DATE - INTERVAL 7 days
    "schedule_run_rate_pace_weekly",         # CURRENT_DATE - INTERVAL 8 weeks
    "quality_closeout_approval_pending_7days",  # CURRENT_DATE
    "material_idle_stock_over_2weeks",      # CURRENT_DATE
    "material_disposal_certificate_compliance", # CURRENT_DATE
    "ops_maintenance_window_exceeded",      # revert_on has its own logic
    "finance_ca_gr_trigger_delay",          # CURRENT_DATE
    "finance_ca_trigger_compliance",        # CURRENT_DATE
    "finance_gr_trigger_sla_compliance",    # CURRENT_DATE
    "material_idle_stock_ageing",           # CURRENT_DATE
    "material_pickup_adherence_by_gc",      # CURRENT_DATE
}

# For queries that should get date filters, specify which column,
# what time window to use, and the interval string.
# Format: query_name -> (table_alias, date_column, interval_string)
#
# Time windows by relevancy:
#   1 week  — daily snapshots, real-time monitoring (HSE check-ins, daily uploads)
#   2 months — operational cycle queries (swap completion, quality checks)
#   3 months — strategic / trend queries (schedule adherence, finance, lead times)
DATE_FILTER_COLUMN = {
    # HSE queries — write_date, last 2 months (recent safety activity)
    "hse_compliance_rate_by_market": ("h", "write_date", "2 months"),
    "hse_ppe_jsa_completion_rate": ("h", "write_date", "2 months"),
    "hse_work_stop_and_process_failures": ("h", "write_date", "2 months"),
    "hse_daily_checkin_compliance": ("h", "write_date", "1 month"),
    "hse_ppe_jsa_swap_without_compliance": ("h", "write_date", "2 months"),
    "hse_work_stop_incident_frequency": ("h", "write_date", "2 months"),

    # Quality queries — construction complete actual, last 2-3 months
    "quality_post_swap_discrepancy_rate": ("base", "pj_a_5175_construction_complete_finish", "3 months"),
    "quality_rollback_and_fault_rate": ("base", "ms_1555_construction_complete_actual", "3 months"),
    "quality_swap_ftr_and_reworks": ("base", "ms_1555_construction_complete_actual", "3 months"),
    "quality_ndpc_punchpoint_rate_by_gc": ("base", "pj_a_4225_construction_start_finish", "3 months"),
    "quality_repeated_punchpoint_patterns": ("base", "pj_a_4225_construction_start_finish", "3 months"),
    "quality_closeout_velocity_3days": ("base", "ms_1555_construction_complete_actual", "2 months"),
    "quality_repeated_fault_incidents_by_gc": ("base", "ms_1555_construction_complete_actual", "3 months"),
    "quality_vendor_scorecard_pp_ftr": ("base", "ms_1555_construction_complete_actual", "3 months"),
    "quality_scop_closeout_timeline": ("base", "ms_1555_construction_complete_actual", "3 months"),

    # Ops queries — last 2-3 months
    "ops_call_test_pass_rate": ("base", "ms_2123_planned_e911_test_calls_actual", "3 months"),
    "ops_48hr_alarm_clearance_status": ("base", "pj_a_5175_construction_complete_finish", "2 months"),
    "ops_gc_milestone_update_pending": ("base", "ms_1555_construction_complete_actual", "2 months"),
    "ops_site_completion_rate": ("base", "ms_1555_construction_complete_actual", "3 months"),
    "ops_swap_cycle_time_breakdown": ("base", "ms_1555_construction_complete_actual", "3 months"),
    "ops_gc_capacity_utilisation_by_market": ("base", "pj_a_5175_construction_complete_finish", "3 months"),
    "ops_site_outage_index_monitoring": ("base", "pj_a_5175_construction_complete_finish", "2 months"),

    # Schedule queries — last 3 months
    "schedule_entitlement_ntp_readiness": ("base", "pj_a_3710_ran_entitlement_complete_finish", "3 months"),
    "schedule_forecast_deviation_by_market": ("base", "pj_a_5175_construction_complete_finish", "3 months"),
    "schedule_swap_readiness_by_market": ("base", "pj_a_5175_construction_complete_finish", "3 months"),
    "schedule_rescheduling_frequency": ("base", "pj_p_4225_construction_start_finish", "3 months"),
    "schedule_slip_rate_weekly": ("base", "pj_a_5175_construction_complete_finish", "3 months"),
    "schedule_swap_lead_time_outliers": ("base", "pj_a_5175_construction_complete_finish", "3 months"),

    # Material queries — last 3 months
    "material_disposal_doc_compliance": ("base", "pj_a_5175_construction_complete_finish", "3 months"),
    "material_bom_availability_by_market": ("base", "pj_a_3875_bom_received_bom_in_aims_finish", "3 months"),
    "material_radio_swap_vs_return_status": ("base", "pj_a_5175_construction_complete_finish", "3 months"),
    "material_pickup_lead_time_by_gc": ("base", "pj_a_3925_msl_pickup_date_finish", "3 months"),
    "material_disposal_adherence_ratio": ("base", "pj_a_5175_construction_complete_finish", "3 months"),
    "material_vendor_pickup_delay_vs_median": ("base", "pj_a_3925_msl_pickup_date_finish", "3 months"),

    # Finance queries — last 3 months
    "finance_payment_trigger_status": ("base", "pj_a_5175_construction_complete_finish", "3 months"),
    "finance_po_validation_status": ("base", "ms_1555_construction_complete_actual", "3 months"),
    "finance_po_milestone_completeness": ("base", "ms_1555_construction_complete_actual", "3 months"),
}


def _col_in_inner_select(sql: str, col: str) -> bool:
    """Check if a column is projected in the inner 'base' subquery SELECT."""
    inner = re.search(r"SELECT DISTINCT ON.*?FROM ndpd_", sql, re.DOTALL | re.IGNORECASE)
    if not inner:
        return False
    select_part = inner.group(0).split("FROM")[0]
    return col in select_part


def add_date_filter(sql: str, table_alias: str, date_col: str, interval: str) -> str:
    """
    Add a hardcoded date filter (CURRENT_DATE - INTERVAL) to the SQL.

    For 'h' alias: inserts into the CTE's WHERE clause.
    For 'base' alias: if the column is in the inner SELECT, adds to outer WHERE.
                       if NOT in inner SELECT, adds to inner subquery WHERE.
    """

    if table_alias == "h":
        # HSE queries: the date column is in a CTE.
        # Insert WHERE before ORDER BY, or add AND if WHERE already exists.
        cte_order = re.search(
            r"(FROM\s+\w+\s+h\s*\n)(\s*ORDER BY)",
            sql, re.IGNORECASE,
        )
        if cte_order:
            insert_pos = cte_order.start(2)
            where_line = f"    WHERE h.{date_col} >= CURRENT_DATE - INTERVAL '{interval}'\n"
            return sql[:insert_pos] + where_line + sql[insert_pos:]

        cte_where = re.search(
            r"(FROM\s+\w+\s+h\s*\n\s*WHERE\s+.*?\n)",
            sql, re.IGNORECASE | re.DOTALL,
        )
        if cte_where:
            insert_pos = cte_where.end()
            and_line = f"      AND h.{date_col} >= CURRENT_DATE - INTERVAL '{interval}'\n"
            return sql[:insert_pos] + and_line + sql[insert_pos:]

    if table_alias == "base":
        if _col_in_inner_select(sql, date_col):
            # Column is projected — add filter in OUTER WHERE after geo filters
            date_line = f"  AND base.{date_col} >= CURRENT_DATE - INTERVAL '{interval}'\n"
            market_pattern = r"(\s*AND\s*\(CAST\(:market\s+AS\s+TEXT\).*?\))\s*\n"
            match = re.search(market_pattern, sql, re.IGNORECASE)
            if match:
                return sql[:match.end()] + date_line + sql[match.end():]
        else:
            # Column NOT projected — add filter in INNER subquery WHERE
            # Find the inner subquery's WHERE clause (inside the base subquery)
            # Pattern: WHERE smp_name = 'AHLOB Modernization' (possibly with more AND lines)
            # We add AND date_col >= ... right after any existing conditions
            # Find last AND or WHERE line in the inner subquery
            inner_where = re.search(
                r"(WHERE\s+smp_name\s*=\s*'AHLOB Modernization'.*?)(\n\s*\)\s*base)",
                sql, re.DOTALL | re.IGNORECASE,
            )
            if inner_where:
                insert_pos = inner_where.end(1)
                and_line = f"\n      AND {date_col} >= CURRENT_DATE - INTERVAL '{interval}'"
                return sql[:insert_pos] + and_line + sql[insert_pos:]

    # Fallback: append after geo market filter
    date_line = f"  AND {table_alias}.{date_col} >= CURRENT_DATE - INTERVAL '{interval}'\n"
    market_pattern = r"(\s*AND\s*\(CAST\(:market\s+AS\s+TEXT\).*?\))\s*\n"
    match = re.search(market_pattern, sql, re.IGNORECASE)
    if match:
        return sql[:match.end()] + date_line + sql[match.end():]

    return sql.rstrip() + "\n" + date_line


def normalize_functions(funcs: list[str] | None) -> list[str]:
    """Map functions to PDM / HSE / DEC."""
    if not funcs:
        return ["PDM"]
    mapped = []
    for f in funcs:
        m = FUNCTION_MAP.get(f, "PDM")
        if m not in mapped:
            mapped.append(m)
    return mapped


def main():
    with open(INPUT, "r", encoding="utf-8") as f:
        queries = json.load(f)

    print(f"Loaded {len(queries)} queries from {INPUT}")

    for i, q in enumerate(queries):
        name = q["name"]

        # 1. Update prompt_template
        old_template = q.get("prompt_template", "vendor_performance")
        new_template = TEMPLATE_MAP.get(name, old_template)
        q["prompt_template"] = new_template
        if old_template != new_template:
            print(f"  #{i+1} {name}: template {old_template} -> {new_template}")

        # 2. Unique pack_id: AHLOA_{pm_category}_{name}
        # Use a shorter, meaningful pack_id based on the query name
        pm_cat = (q.get("pm_category") or "General").upper().replace(" ", "_")
        q["pack_id"] = f"AHLOA_{pm_cat}_{name}"

        # 3. Normalize functions
        old_funcs = q.get("functions", [])
        q["functions"] = normalize_functions(old_funcs)

        # 4. Add date filters where appropriate
        if name in DATE_FILTER_COLUMN and name not in NO_DATE_FILTER:
            table_alias, date_col, interval = DATE_FILTER_COLUMN[name]
            sql = q["query_sql"]
            # Only add if no INTERVAL already present for this column
            if f"INTERVAL" not in sql or date_col not in sql.split("INTERVAL")[0].split("\n")[-1]:
                q["query_sql"] = add_date_filter(sql, table_alias, date_col, interval)
                print(f"  #{i+1} {name}: added {interval} filter on {table_alias}.{date_col}")

        # 5. If template is NOT vendor_performance and group_by_column is set,
        #    keep it — the engine can still group by GC even with other templates
        #    (it just won't use the vendor-comparison prompt framing)

    with open(OUTPUT, "w", encoding="utf-8") as f:
        json.dump(queries, f, indent=2, ensure_ascii=False)
        f.write("\n")

    print(f"\nWrote {len(queries)} queries to {OUTPUT}")
    print("Done.")


if __name__ == "__main__":
    main()
