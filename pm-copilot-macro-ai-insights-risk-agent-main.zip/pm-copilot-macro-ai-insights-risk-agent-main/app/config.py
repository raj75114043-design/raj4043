"""
Application configuration using Pydantic Settings.
All values loaded from environment variables with sensible defaults.
"""
from __future__ import annotations

import json
from functools import lru_cache
from typing import Any, Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Central configuration — loaded once, cached forever."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ------------------------------------------------------------------ #
    # Application
    # ------------------------------------------------------------------ #
    app_name: str = "Insights Engine"
    app_version: str = "1.0.0"
    app_env: Literal["development", "staging", "production"] = "development"
    app_host: str = "0.0.0.0"
    app_port: int = 8000
    app_workers: int = 4
    debug: bool = False
    secret_key: str = "change-this-secret-key"

    # ------------------------------------------------------------------ #
    # Database (Insights store — PostgreSQL + pgvector)
    # ------------------------------------------------------------------ #
    postgres_host: str = "localhost"
    postgres_port: int = 5432
    postgres_db: str = "insights_engine"
    postgres_user: str = "insights_user"
    postgres_password: str = "password"
    database_url: str = Field(
        default="postgresql+asyncpg://insights_user:password@localhost:5432/insights_engine"
    )
    database_pool_size: int = 20
    database_max_overflow: int = 10
    database_pool_timeout: int = 30

    # Source database (derived tables live here)
    source_db_url: str = Field(
        default="postgresql+asyncpg://user:password@localhost:5432/source_db"
    )

    # ------------------------------------------------------------------ #
    # PostgreSQL schema & table name overrides
    # ------------------------------------------------------------------ #
    # All application tables are created inside this schema.
    # Leave empty (or "public") to use the default PostgreSQL search_path.
    db_schema: str = "public"

    # Schema where the pgvector extension is installed.
    # Run: SELECT n.nspname FROM pg_extension e JOIN pg_namespace n ON n.oid=e.extnamespace WHERE e.extname='vector'
    # to find the value for your database. Defaults to "public" (standard install).
    pgvector_schema: str = "public"

    # Override individual table names if your environment uses a different
    # naming convention or you need to co-locate multiple deployments.
    table_insights: str = "insights"
    table_insight_embeddings: str = "insight_embeddings"
    table_insights_historical: str = "insights_historical"
    table_user_interactions: str = "user_interactions"
    table_sql_query_library: str = "sql_query_library"
    table_prompt_templates: str = "prompt_templates"
    table_batch_jobs: str = "batch_jobs"
    table_batch_job_logs: str = "batch_job_logs"
    table_insight_packs: str = "insight_packs"
    table_user_preferences: str = "user_preferences"

    # Source DB — geography dimension table (fully-qualified if needed)
    table_dim_geography: str = "dim_geography"

    @property
    def effective_schema(self) -> str | None:
        """Returns None for 'public' so MetaData doesn't emit schema prefix unnecessarily."""
        s = self.db_schema.strip()
        return s if s and s.lower() != "public" else None

    # ------------------------------------------------------------------ #
    # Redis
    # ------------------------------------------------------------------ #
    redis_enabled: bool = True           # Set false to disable Redis entirely
    redis_host: str = "localhost"
    redis_port: int = 6379
    redis_password: str = ""
    redis_db: int = 0
    redis_url: str = "redis://localhost:6379/0"
    cache_ttl_seconds: int = 3600

    # ------------------------------------------------------------------ #
    # LLM — custom gateway (Azure / enterprise proxy via LangChain)
    # ------------------------------------------------------------------ #
    llm_api_base_url: str = ""           # e.g. https://your-gateway/openai/v1
    llm_gateway_api_key: str = ""        # sent as "api-key" header
    llm_workspace_name: str = ""         # sent as "workspacename" header
    llm_model: str = "gpt-4o"
    llm_max_tokens: int = 2048
    llm_temperature: float = 0.0
    llm_max_retries: int = 3
    llm_timeout_seconds: int = 60

    # ------------------------------------------------------------------ #
    # Embeddings — same custom gateway
    # ------------------------------------------------------------------ #
    embedding_model: str = "text-embedding-ada-002"
    embedding_dimension: int = 1536      # ada-002 is always 1536

    # ------------------------------------------------------------------ #
    # Authentication
    # ------------------------------------------------------------------ #
    jwt_secret_key: str = "change-this-jwt-secret"
    jwt_algorithm: str = "HS256"
    jwt_access_token_expire_minutes: int = 60
    jwt_refresh_token_expire_days: int = 7
    auth_enabled: bool = True

    # ------------------------------------------------------------------ #
    # Celery
    # ------------------------------------------------------------------ #
    celery_broker_url: str = "redis://localhost:6379/1"
    celery_result_backend: str = "redis://localhost:6379/2"
    celery_max_retries: int = 3

    # ------------------------------------------------------------------ #
    # Batch Processing
    # ------------------------------------------------------------------ #
    batch_size: int = 10
    batch_max_parallel: int = 5
    insight_expiry_days: int = 90
    archive_batch_size: int = 500

    # ------------------------------------------------------------------ #
    # Rate Limiting
    # ------------------------------------------------------------------ #
    rate_limit_requests: int = 100
    rate_limit_window_seconds: int = 60

    # ------------------------------------------------------------------ #
    # CORS
    # ------------------------------------------------------------------ #
    cors_origins: list[str] = Field(
        default=["http://localhost:3000", "http://localhost:8080"]
    )
    cors_allow_credentials: bool = True

    @field_validator("cors_origins", mode="before")
    @classmethod
    def parse_cors_origins(cls, v: Any) -> list[str]:
        if isinstance(v, str):
            try:
                return json.loads(v)
            except json.JSONDecodeError:
                return [origin.strip() for origin in v.split(",")]
        return v

    # ------------------------------------------------------------------ #
    # Logging
    # ------------------------------------------------------------------ #
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    log_format: Literal["json", "text"] = "json"
    log_file_path: str = ""

    # ------------------------------------------------------------------ #
    # Monitoring
    # ------------------------------------------------------------------ #
    prometheus_enabled: bool = True
    health_check_db: bool = True
    health_check_redis: bool = True      # automatically ignored when redis_enabled=false

    # ------------------------------------------------------------------ #
    # Email
    # ------------------------------------------------------------------ #
    # Backend: "nokia_gateway" (Nokia internal) or "smtp" (standard SMTP)
    email_backend: Literal["nokia_gateway", "smtp"] = "nokia_gateway"

    # Nokia gateway
    email_gateway_auth_url: str = (
        "https://nokiaosdp-gsd-staging.aibi-americas-002.dyn.nesc.nokia.net"
        "/web/session/authenticate"
    )
    email_gateway_send_url: str = (
        "https://nokiaosdp-gsd-staging.aibi-americas-002.dyn.nesc.nokia.net"
        "/api/v1/send_mail"
    )
    email_gateway_db: str = "postgres"
    email_gateway_login: str = "pwc_osdp_user"
    email_gateway_password: str = "pwc_osdp_user"
    email_gateway_timeout: int = 30   # seconds

    # SMTP (used when email_backend=smtp)
    smtp_host: str = "smtp.gmail.com"
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_use_tls: bool = True
    smtp_from: str = ""              # defaults to smtp_user if empty
    smtp_timeout: int = 30

    # ------------------------------------------------------------------ #
    # Config file paths
    # ------------------------------------------------------------------ #
    geography_config_path: str = "config/geography.yml"
    query_library_config_path: str = "config/query_library.yml"

    # ------------------------------------------------------------------ #
    # Computed helpers
    # ------------------------------------------------------------------ #
    @property
    def is_production(self) -> bool:
        return self.app_env == "production"

    @property
    def is_development(self) -> bool:
        return self.app_env == "development"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return cached Settings singleton."""
    return Settings()
