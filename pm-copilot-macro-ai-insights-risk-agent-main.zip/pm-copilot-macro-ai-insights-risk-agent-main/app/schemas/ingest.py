"""Pydantic schemas for the template-based onboarding / ingest pipeline."""
from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, model_validator


# ------------------------------------------------------------------ #
# Enums
# ------------------------------------------------------------------ #
class IssueSeverity(str, Enum):
    error = "error"       # must be fixed before ingest
    warning = "warning"   # can proceed but user should review
    info = "info"         # informational


class IngestStatus(str, Enum):
    pending = "pending"
    validated = "validated"
    sql_generated = "sql_generated"
    sql_tested = "sql_tested"
    ingested = "ingested"
    failed = "failed"
    skipped = "skipped"


# ------------------------------------------------------------------ #
# Input models (parsed from Excel / YAML)
# ------------------------------------------------------------------ #
class DataSourceEntry(BaseModel):
    """One row from the Data_Sources sheet."""

    table_name: str = Field(..., description="Fully qualified table/view name")
    description: str | None = None
    # Column names that hold geo identifiers
    market_column: str | None = None
    area_column: str | None = None
    region_column: str | None = None
    site_id_column: str | None = None


class KpiEntry(BaseModel):
    """One row from the KPI_Definitions sheet."""

    # Identification
    kpi_name: str = Field(..., description="Short machine-readable KPI name (no spaces)")
    display_name: str | None = None
    description: str | None = None
    purpose: str | None = None

    # Categorisation
    category: str | None = None          # performance|capacity|quality|reliability|compliance|operational
    subcategory: str | None = None
    pm_category: str | None = None       # Cost|Quality|Schedule|…
    projects: str | None = None          # comma-separated
    functions: str | None = None         # comma-separated
    team: str | None = None
    tags: str | None = None              # comma-separated

    # Data source
    source_table: str | None = None      # must match a DataSourceEntry.table_name
    kpi_column: str | None = None        # column that holds the metric value
    filter_conditions: str | None = None # SQL WHERE clause fragment (optional)
    geography_level: str = "market"      # overall|region|area|market

    # Business context
    unit: str | None = None
    target: float | None = None
    sla_threshold: float | None = None
    interpretation: str | None = None
    aggregation_method: str = "avg"      # avg|sum|max|min|count

    # SQL
    prompt_template: str = "performance_insight"
    custom_sql: str | None = None        # overrides auto-generation if provided

    # Runtime (populated by service, not filled by user)
    generated_sql: str | None = None
    status: IngestStatus = IngestStatus.pending
    query_id: str | None = None          # assigned after ingest


class IngestTemplateData(BaseModel):
    """Full parsed template: data sources + KPI definitions."""

    data_sources: list[DataSourceEntry] = Field(default_factory=list)
    kpi_entries: list[KpiEntry] = Field(default_factory=list)

    @model_validator(mode="after")
    def at_least_one_kpi(self) -> "IngestTemplateData":
        if not self.kpi_entries:
            raise ValueError("Template must contain at least one KPI definition.")
        return self


# ------------------------------------------------------------------ #
# Validation / report models
# ------------------------------------------------------------------ #
class ValidationIssue(BaseModel):
    """Single issue found during validation."""

    kpi_name: str | None = None          # None = global issue
    field: str | None = None
    severity: IssueSeverity
    message: str
    suggestion: str | None = None


class KpiValidationResult(BaseModel):
    """Per-KPI summary after validation + SQL generation + test-run."""

    kpi_name: str
    status: IngestStatus
    issues: list[ValidationIssue] = Field(default_factory=list)
    generated_sql: str | None = None
    sql_test_rows: int | None = None     # row count from test run (None = not run)
    sql_test_error: str | None = None
    query_id: str | None = None          # set after successful ingest


class IngestReport(BaseModel):
    """Complete report returned to the caller."""

    total_kpis: int
    valid_count: int
    warning_count: int
    error_count: int
    ingested_count: int = 0

    global_issues: list[ValidationIssue] = Field(default_factory=list)
    kpi_results: list[KpiValidationResult] = Field(default_factory=list)

    # Set to True once /ingest/apply has been called and entries persisted
    applied: bool = False


# ------------------------------------------------------------------ #
# API request/response models
# ------------------------------------------------------------------ #
class IngestApplyRequest(BaseModel):
    """Body for POST /ingest/apply — client submits the validated report
    and optionally overrides which KPIs to ingest."""

    kpi_names_to_ingest: list[str] | None = None  # None = ingest all valid ones
    # The raw template data is re-submitted so the server can re-generate /
    # re-validate rather than cache state between calls.
    template_data: dict[str, Any]
