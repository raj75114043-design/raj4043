"""Pydantic schemas for the Derived Table & SQL Query Builder API."""
from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field


# ------------------------------------------------------------------ #
# Derived Table Builder
# ------------------------------------------------------------------ #

class DerivedTableRequest(BaseModel):
    """
    Specification for creating or previewing a derived table.

    The LLM will turn this into a ``CREATE TABLE AS SELECT`` statement.
    Set ``execute=true`` to actually run the DDL against the source DB.
    """

    table_name: str = Field(
        ..., description="Target table name (without schema), e.g. 'macro_quality_summary'"
    )
    schema_name: str = Field(
        ..., description="Target schema, e.g. 'pwc_derived_tables_schema'"
    )
    description: str | None = Field(None, description="Short human-readable description of the table (auto-generated from business context if omitted)")
    business_context: str = Field(
        ...,
        description=(
            "Business purpose and reasoning — what question does this table answer? "
            "What metrics/KPIs does it support? Include any domain knowledge."
        ),
    )
    source_tables: list[str] = Field(
        ...,
        description="Fully-qualified source tables to join, e.g. ['schema.orders', 'schema.sites']",
    )
    join_logic: str = Field(
        ...,
        description=(
            "How to join the source tables. Plain English or pseudo-SQL. "
            "E.g. 'Join orders to sites on site_id. Left join to vendors on vendor_id.'"
        ),
    )
    filter_logic: str | None = Field(
        None,
        description="WHERE conditions to apply (plain text or SQL fragment). E.g. 'Only active records where status != cancelled'",
    )
    additional_logic: str | None = Field(
        None,
        description="CASE expressions, aggregations, derived columns, or any other logic to include.",
    )
    refresh_mode: Literal["truncate_insert", "create_replace"] = Field(
        "truncate_insert",
        description=(
            "truncate_insert: TRUNCATE + re-insert on refresh (fast, keeps table visible). "
            "create_replace: DROP + recreate on refresh (clean, brief unavailability)."
        ),
    )
    execute: bool = Field(
        False,
        description="Set true to execute the DDL and create the table. False returns only the generated SQL for review.",
    )


class DerivedTablePreviewResponse(BaseModel):
    """Generated DDL returned for review. Table has NOT been created."""

    table_name: str
    schema_name: str
    generated_ddl: str
    message: str


class DerivedTableResponse(BaseModel):
    """Saved derived table definition (table may or may not have been executed)."""

    table_def_id: str
    table_name: str
    schema_name: str
    description: str
    business_context: str = ""
    source_tables: list[str] = []
    join_logic: str = ""
    filter_logic: str | None = None
    additional_logic: str | None = None
    generated_ddl: str
    refresh_mode: str
    status: str
    last_refreshed_at: datetime | None = None
    row_count: int | None = None
    last_error: str | None = None
    created_at: datetime


class DerivedTableUpdateRequest(BaseModel):
    """Fields that can be updated on an existing derived table definition."""

    description: str | None = None
    business_context: str | None = None
    source_tables: list[str] | None = None
    join_logic: str | None = None
    filter_logic: str | None = None
    additional_logic: str | None = None
    refresh_mode: Literal["truncate_insert", "create_replace"] | None = None


class DerivedTableListResponse(BaseModel):
    items: list[DerivedTableResponse]
    total: int


class RefreshResponse(BaseModel):
    table_def_id: str
    table_name: str
    status: str
    row_count: int | None = None
    message: str


# ------------------------------------------------------------------ #
# SQL Query Builder
# ------------------------------------------------------------------ #

class SqlQueryBuilderRequest(BaseModel):
    """
    Specification for generating an analysis SQL query via LLM.

    The LLM produces a SELECT statement with ``:name`` style parameters
    compatible with the insights engine's SqlExecutor.

    POST /builder/sql-queries/preview — generates SQL, does not save.
    POST /builder/sql-queries         — generates SQL and saves to library.
    """

    derived_table: str = Field(
        ...,
        description="Fully-qualified table to query, e.g. 'pwc_derived_tables_schema.macro_quality_summary'",
    )
    analysis_goal: str = Field(
        ...,
        description=(
            "What the query should analyse or answer. "
            "E.g. 'Show punch-point rejection rates broken down by rejection type.'"
        ),
    )
    available_columns: list[str] | None = Field(
        None,
        description="Column names in the table — auto-fetched from source DB if omitted.",
    )
    additional_context: str | None = Field(
        None,
        description="Extra instructions, business rules, or constraints for the LLM.",
    )

    # Library metadata — used when saving to sql_query_library
    query_name: str | None = Field(
        None,
        description="Name for the library entry. Required when saving.",
    )
    query_purpose: str | None = Field(
        None,
        description="One-line purpose stored alongside the query.",
    )
    prompt_template_id: str | None = Field(
        None,
        description="Prompt template to use when this query generates an insight.",
    )
    geography_level: str | None = Field(
        None,
        description="Lowest geo level at which this analysis is meaningful: market | area | region | overall.",
    )
    projects: list[str] | None = Field(
        None, description="Projects this query is relevant to, e.g. ['NTM', 'AHLOB']."
    )
    functions: list[str] | None = Field(
        None, description="Functions this query is relevant to, e.g. ['PDM', 'HSE']."
    )
    tags: list[str] | None = None
    team: str | None = Field(None, description="Owning team, e.g. 'Network Quality'.")

    # Pack & PM category — links this query into the pack system
    pack_id: str | None = Field(
        None,
        description="UUID of the InsightPack this query belongs to. "
                    "All queries in the same pack share one feed card.",
    )
    pm_category: str | None = Field(
        None,
        description="PM management category, e.g. 'Cost', 'Quality', 'Vendor Performance'.",
    )

    # Derived table reference — used to auto-fetch full context (DDL, join logic, etc.)
    table_def_id: str | None = Field(
        None,
        description="UUID of the DerivedTableDefinition this query targets. "
                    "When supplied, the API fetches the full table context (business purpose, "
                    "join logic, filter conditions) and passes it to the LLM for more accurate SQL.",
    )

    # Structured KPI context — passed through to sql_query_library.business_context
    business_context: dict[str, Any] | None = Field(
        None,
        description=(
            "KPI business context. New format uses a 'kpis' key containing a list of per-metric "
            "dicts (column, kpi_name, unit, target, sla_threshold, lower_is_better, aggregation, "
            "interpretation). Legacy flat format (kpi_name, unit, target, …) is also accepted."
        ),
    )

    # Pre-validated SQL — if supplied, skip LLM generation and save this directly
    provided_sql: str | None = Field(
        None,
        description="If set, this SQL is used as-is (no LLM call). Allows saving a previously "
                    "previewed/validated query without re-generating it.",
    )
    # Sample data — helps LLM understand actual value formats when generating SQL
    sample_rows: list[dict] | None = Field(
        None,
        description="A few sample rows from the table (for LLM context). "
                    "Auto-populated by the console from the explore step.",
    )

    # Execution limit — max rows to fetch from source DB during generation
    row_limit: int | None = Field(
        None,
        ge=1,
        le=2000,
        description="Max rows to fetch from source DB during insight generation. "
                    "NULL = no limit (all rows fetched). Set explicitly only when "
                    "a query produces very large result sets and you want a safety cap.",
    )

    # Optional secondary grouping column for vendor-level analysis
    group_by_column: str | None = Field(
        None,
        description="Column name to group by alongside geography (e.g. 'nas_company_name', "
                    "'vendor'). When set, aggregation produces rows per (geo, vendor) "
                    "so the LLM can compare across vendors within each geography.",
    )

    # Multi-insight areas — generate a separate insight for each area from the same data
    insight_areas: list[str] | None = Field(
        None,
        description="Distinct analysis angles to generate from the same query data. "
                    "Each area produces a separate insight at every geography node. "
                    "Example: ['Approval & Rejection Rates', 'FTR Performance', 'Outages']. "
                    "NULL or empty = single insight (default).",
    )


class SqlQueryBuilderResponse(BaseModel):
    """LLM-generated analysis SQL, optionally saved to the library."""

    generated_sql: str
    query_id: str | None = None
    query_name: str | None = None
    saved: bool
    message: str


class SqlQueryListItem(BaseModel):
    """Full query library entry — returned by GET /builder/sql-queries."""

    query_id: str
    name: str
    query_sql: str
    purpose: str | None = None
    description: str | None = None
    geography_level: str | None = None
    prompt_template_id: str | None = None
    pm_category: str | None = None
    pack_id: str | None = None
    projects: list[str] | None = None
    functions: list[str] | None = None
    tags: list[str] | None = None
    team: str | None = None
    is_active: bool
    version: str
    business_context: dict[str, Any] | None = None
    row_limit: int | None = None
    group_by_column: str | None = None
    insight_areas: list[str] | None = None


# ------------------------------------------------------------------ #
# Console — Table Sample
# ------------------------------------------------------------------ #

class ColumnInfo(BaseModel):
    name: str
    data_type: str


class TableSampleResponse(BaseModel):
    table_def_id: str
    qualified_name: str
    row_count: int | None = None
    columns: list[ColumnInfo]
    sample_rows: list[dict[str, Any]]
    error: str | None = None


# ------------------------------------------------------------------ #
# Console — Analysis Ideation
# ------------------------------------------------------------------ #

class IdeateRequest(BaseModel):
    pm_goals: str | None = Field(
        None,
        description="What kinds of insights does the PM regularly need from this table?",
    )
    focus_areas: list[str] | None = Field(
        None,
        description="Optional focus areas, e.g. ['quality', 'efficiency', 'risk']",
    )
    num_ideas: int = Field(6, ge=3, le=12, description="Number of analysis ideas to generate")


class AnalysisIdea(BaseModel):
    name: str
    category: str  # performance | trend | outlier | quality | efficiency | risk
    goal: str
    rationale: str
    suggested_template: str | None = None
    feasibility: str = "full"  # "full" = all columns present; "partial" = some columns missing
    missing_columns: list[str] = []  # columns this idea needs but are absent from the table


class IdeateResponse(BaseModel):
    table_def_id: str
    ideas: list[AnalysisIdea]


# ------------------------------------------------------------------ #
# Console — SQL Validation
# ------------------------------------------------------------------ #

class SqlQueryUpdateRequest(BaseModel):
    """Fields that can be updated on an existing sql_query_library entry."""

    name: str | None = None
    query_sql: str | None = None
    purpose: str | None = None
    description: str | None = None
    geography_level: str | None = None
    prompt_template_id: str | None = None
    projects: list[str] | None = None
    functions: list[str] | None = None
    tags: list[str] | None = None
    team: str | None = None
    pack_id: str | None = None
    pm_category: str | None = None
    is_active: bool | None = None
    # Structured KPI context — new format uses kpis[] array, legacy flat format also accepted.
    business_context: dict[str, Any] | None = None
    row_limit: int | None = Field(None, ge=1, le=2000)
    group_by_column: str | None = None
    insight_areas: list[str] | None = None


class ValidateSqlRequest(BaseModel):
    sql: str = Field(..., description="Parameterised SQL to test-run against source DB")
    test_params: dict[str, Any] | None = Field(
        None,
        description=(
            "Override default test params. Defaults: level='overall', region/area/market=NULL, "
            "start_date='2024-01-01', end_date='2024-12-31', limit=50"
        ),
    )
    row_limit: int = Field(50, ge=1, le=500, description="Max rows to return in preview")

