"""Pydantic schemas for user interaction endpoints."""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field


class InteractionRequest(BaseModel):
    """Minimal body for toggle interactions (like, dislike, acknowledge, mute)."""

    user_id: str = Field(..., min_length=1, max_length=100)


class FlagRequest(BaseModel):
    """Body for flag/unflag — includes optional reason."""

    user_id: str = Field(..., min_length=1, max_length=100)
    reason: str | None = Field(None, max_length=500)


class CommentRequest(BaseModel):
    """Body for add/update comment."""

    user_id: str = Field(..., min_length=1, max_length=100)
    comment: str = Field(..., min_length=1, max_length=2000)


class DeleteCommentRequest(BaseModel):
    """Body for comment deletion."""

    user_id: str = Field(..., min_length=1, max_length=100)


class InteractionResponse(BaseModel):
    """Full interaction state returned after any mutation."""

    model_config = ConfigDict(from_attributes=True)

    interaction_id: str
    insight_id: str
    user_id: str

    liked: bool | None = None
    disliked: bool | None = None
    acknowledged: bool | None = None
    muted: bool | None = None
    flagged: bool | None = None
    flag_reason: str | None = None
    comment: str | None = None

    created_at: datetime
    updated_at: datetime | None = None


class UserInteractionsResponse(BaseModel):
    """All interactions for a specific user."""

    user_id: str
    items: list[InteractionResponse]
    total: int
