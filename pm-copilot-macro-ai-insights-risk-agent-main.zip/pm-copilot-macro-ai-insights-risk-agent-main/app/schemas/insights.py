"""Pydantic schemas for insight retrieval endpoints."""
from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator


class InsightResponse(BaseModel):
    """Full insight payload returned to clients."""

    model_config = ConfigDict(from_attributes=True)

    insight_id: str
    title: str
    insight: str
    insight_detail: list[str] | str | None = None

    market: str | None = None
    area: str | None = None
    region: str | None = None
    team: str | None = None

    severity_score: float | None = None
    category: str | None = None
    subcategory: str | None = None
    type: str | None = None

    site_count: int | None = None
    projects: list[str] | None = None
    functions: list[str] | None = None
    tags: list[str] | None = None
    consecutive_occurrences: int = 1

    llm_model: str | None = None
    query_id: str | None = None
    job_id: str | None = None

    pack_id: str | None = None
    is_pack_summary: bool = False
    geo_level: str | None = None
    insight_area: str | None = None

    created_at: datetime
    updated_at: datetime | None = None
    expires_at: datetime | None = None
    is_active: bool


class InsightListItem(BaseModel):
    """Lightweight insight representation used in list responses.

    Excludes large fields (source_data, drill_down_data, site_ids) — those are
    served via the dedicated drill-down API.
    """

    model_config = ConfigDict(from_attributes=True)

    insight_id: str
    title: str
    insight: str
    insight_detail: list[str] | str | None = None

    market: str | None = None
    area: str | None = None
    region: str | None = None
    team: str | None = None

    severity_score: float | None = None
    category: str | None = None
    subcategory: str | None = None
    type: str | None = None

    site_count: int | None = None
    projects: list[str] | None = None
    functions: list[str] | None = None
    tags: list[str] | None = None
    consecutive_occurrences: int = 1

    llm_model: str | None = None
    query_id: str | None = None
    job_id: str | None = None

    pack_id: str | None = None
    is_pack_summary: bool = False
    geo_level: str | None = None
    insight_area: str | None = None

    created_at: datetime
    updated_at: datetime | None = None
    expires_at: datetime | None = None
    is_active: bool


class InsightListResponse(BaseModel):
    """Paginated list of insights."""

    items: list[InsightListItem]
    total: int
    limit: int
    offset: int
    has_more: bool


class InsightCreate(BaseModel):
    """Internal schema used by the generation engine to persist an insight."""

    title: str
    insight: str
    insight_detail: list[str] | str | None = None

    market: str | None = None
    area: str | None = None
    region: str | None = None
    team: str | None = None

    severity_score: float | None = Field(None, ge=0, le=100)
    category: str | None = None
    subcategory: str | None = None
    type: str | None = None

    site_count: int | None = Field(None, ge=0)
    drill_down_sql: str | None = None
    source_data: list[dict[str, Any]] | None = None
    site_ids: list[str] | None = None
    projects: list[str] | None = None
    functions: list[str] | None = None
    tags: list[str] | None = None
    consecutive_occurrences: int = 1
    generation_context: dict[str, Any] | None = None

    query_id: str | None = None
    prompt_template_id: str | None = None
    llm_model: str | None = None
    job_id: str | None = None
    expires_at: datetime | None = None

    pack_id: str | None = None
    is_pack_summary: bool = False
    geo_level: str | None = None
    insight_area: str | None = None


class DrillDownRow(BaseModel):
    """Single row from drill-down SQL execution."""

    model_config = ConfigDict(extra="allow")


class DrillDownResponse(BaseModel):
    """Result of executing an insight's drill-down SQL."""

    insight_id: str
    columns: list[str]
    rows: list[dict[str, Any]]
    row_count: int
    query_executed: bool
    message: str | None = None


class InsightFilters(BaseModel):
    """Query parameters for GET /insights — validated centrally."""

    market: str | None = None
    region: str | None = None
    area: str | None = None
    team: str | None = None
    category: str | None = None
    subcategory: str | None = None
    type: str | None = None
    severity_min: float | None = Field(None, ge=0, le=100)
    severity_max: float | None = Field(None, ge=0, le=100)
    projects: list[str] | None = None
    functions: list[str] | None = None
    tags: list[str] | None = None
    date_from: datetime | None = None
    date_to: datetime | None = None
    is_active: bool | None = True
    limit: int = Field(50, ge=1, le=500)
    offset: int = Field(0, ge=0)

    @field_validator("severity_max")
    @classmethod
    def max_gte_min(cls, v: float | None, info: Any) -> float | None:
        if v is not None and info.data.get("severity_min") is not None:
            if v < info.data["severity_min"]:
                raise ValueError("severity_max must be >= severity_min")
        return v
