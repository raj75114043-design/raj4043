"""Pydantic schemas — request/response contracts for all API endpoints."""
from app.schemas.insights import (
    InsightCreate,
    InsightResponse,
    InsightListResponse,
    DrillDownResponse,
)
from app.schemas.interactions import (
    InteractionRequest,
    FlagRequest,
    CommentRequest,
    InteractionResponse,
    UserInteractionsResponse,
)
from app.schemas.search import SemanticSearchRequest, SemanticSearchResponse
from app.schemas.admin import (
    GenerateInsightsRequest,
    GenerateInsightsResponse,
    JobStatusResponse,
    ArchiveRequest,
    ArchiveResponse,
)

__all__ = [
    "InsightCreate",
    "InsightResponse",
    "InsightListResponse",
    "DrillDownResponse",
    "InteractionRequest",
    "FlagRequest",
    "CommentRequest",
    "InteractionResponse",
    "UserInteractionsResponse",
    "SemanticSearchRequest",
    "SemanticSearchResponse",
    "GenerateInsightsRequest",
    "GenerateInsightsResponse",
    "JobStatusResponse",
    "ArchiveRequest",
    "ArchiveResponse",
]
