"""Pydantic schemas for semantic search endpoints."""
from __future__ import annotations

from pydantic import BaseModel, Field

from app.schemas.insights import InsightResponse


class SearchFilters(BaseModel):
    """Optional filters to apply alongside vector similarity."""

    market: str | None = None
    region: str | None = None
    area: str | None = None
    category: str | None = None
    severity_min: float | None = Field(None, ge=0, le=100)
    severity_max: float | None = Field(None, ge=0, le=100)
    projects: list[str] | None = None
    functions: list[str] | None = None


class SemanticSearchRequest(BaseModel):
    """Body for POST /search/semantic."""

    query: str = Field(..., min_length=3, max_length=1000)
    filters: SearchFilters | None = None
    limit: int = Field(10, ge=1, le=100)
    similarity_threshold: float = Field(0.3, ge=0.0, le=1.0)


class SemanticSearchResult(BaseModel):
    """Single ranked result with similarity score."""

    insight: InsightResponse
    similarity_score: float


class SemanticSearchResponse(BaseModel):
    """Response from semantic search."""

    query: str
    results: list[SemanticSearchResult]
    total_found: int
    message: str | None = None   # populated when no results to hint at the cause
