"""Pydantic schemas for the SQL-first free-form onboarding flow.

Two-step pipeline:
  POST /ingest/sql/analyse  → LLM infers metadata from SQL + context (for review)
  POST /ingest/sql/apply    → accept reviewed/corrected metadata → persist
"""
from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


# ------------------------------------------------------------------ #
# Per-KPI metric definition (lives inside business_context.kpis[])
# ------------------------------------------------------------------ #

class KpiMetric(BaseModel):
    """One KPI / metric column within a query's business context."""

    column: str = Field(..., description="Exact column alias from the SQL SELECT clause.")
    kpi_name: str = Field(..., description="Human-readable name for this metric.")
    unit: str | None = Field(None, description="Unit of measure: %, ms, Mbps, count, days, etc.")
    target: float | None = Field(None, description="Numeric goal value.")
    sla_threshold: float | None = Field(None, description="Numeric breach / minimum value.")
    lower_is_better: bool = Field(False, description="True when lower values are better (e.g. drop rate).")
    aggregation: str = Field("avg", description="How to aggregate across sites: avg | sum | max | min.")
    interpretation: str | None = Field(
        None,
        description="1-2 sentences: what good looks like, what bad means, thresholds, action.",
    )


# ------------------------------------------------------------------ #
# Step 1 — Analyse request / response
# ------------------------------------------------------------------ #

class SqlContextRequest(BaseModel):
    """Body for POST /ingest/sql/analyse."""

    name: str = Field(..., description="Unique machine-readable identifier (snake_case).")
    sql: str = Field(..., description="Raw SELECT query. No trailing semicolon.")
    context: str = Field(
        ...,
        description=(
            "Free-form description of the KPI(s): what they measure, targets, thresholds, "
            "direction (higher/lower is better), owning team, business impact, etc."
        ),
    )
    date_filterable: bool = Field(
        True,
        description=(
            "Set to False for static/reference data with no time dimension. "
            "When False, the engine will NOT add :start_date/:end_date params to the SQL."
        ),
    )


class InferredKpiMetadata(BaseModel):
    """
    LLM-inferred + enriched metadata for a query.

    Returned for user review in the /analyse response.
    Submitted (with corrections) in the /apply request.
    """

    geography_level: str = Field(
        "market",
        description="Inferred from the SQL GROUP BY. One of: overall | region | area | market.",
    )
    category: str = Field(
        "performance",
        description="performance | capacity | quality | reliability | compliance | operational",
    )
    subcategory: str | None = None
    display_name: str = Field(..., description="Human-readable label for the UI.")
    description: str | None = Field(None, description="One sentence: what this query measures.")
    purpose: str | None = Field(None, description="One sentence: why these KPIs matter.")
    prompt_template: str = Field(
        "performance_insight",
        description=(
            "performance_insight | trend_insight | capacity_insight | "
            "executive_summary_insight | vendor_performance | schedule_adherence | "
            "anomaly_detection | comparative_analysis | multi_kpi_synthesis"
        ),
    )
    team: str | None = None
    functions: list[str] | None = None
    tags: list[str] | None = None
    projects: list[str] | None = None
    pm_category: str | None = Field(None, description="Cost | Quality | Schedule | Other")
    # Structured KPI context stored in the query library.
    # New format uses a "kpis" key containing a list of KpiMetric dicts.
    # Legacy format (flat kpi_name/unit/target/…) is still accepted.
    business_context: dict[str, Any] = Field(default_factory=dict)
    # Engine-parameterized version of the SQL produced by the LLM during analyse.
    # Replaces hardcoded dates with :start_date/:end_date and adds geo IS-NULL filters.
    parameterized_sql: str | None = Field(
        None,
        description=(
            "SQL rewritten with engine bind-params: "
            ":start_date/:end_date for date range and "
            "(:geo::text IS NULL OR col = :geo::text) for geography filtering."
        ),
    )


class SqlAnalyseResponse(BaseModel):
    """Response from POST /ingest/sql/analyse — returned for user review."""

    name: str
    original_sql: str
    inferred: InferredKpiMetadata
    sql_valid: bool
    sql_test_rows: int | None = None
    sql_test_error: str | None = None


# ------------------------------------------------------------------ #
# Step 2 — Apply request / response
# ------------------------------------------------------------------ #

class SqlApplyRequest(BaseModel):
    """
    Body for POST /ingest/sql/apply.

    The client submits the inferred metadata (from /analyse), with any
    corrections the user has made, alongside the original SQL.
    """

    name: str
    sql: str = Field(..., description="The engine-parameterized SQL (from inferred.parameterized_sql, possibly corrected).")
    geography_level: str = "market"
    category: str = "performance"
    subcategory: str | None = None
    display_name: str | None = None
    description: str | None = None
    purpose: str | None = None
    business_context: dict[str, Any] = Field(default_factory=dict)
    prompt_template: str = "performance_insight"
    team: str | None = None
    functions: list[str] | None = None
    tags: list[str] | None = None
    projects: list[str] | None = None
    pm_category: str | None = None
    row_limit: int | None = Field(None, ge=1, le=2000, description="Max rows fetched from source DB during insight generation. NULL = no limit.")
    group_by_column: str | None = Field(None, description="Optional column for secondary grouping (e.g. vendor). Only used when vendor_grouping is enabled at generation time.")


class SqlApplyResponse(BaseModel):
    """Response from POST /ingest/sql/apply."""

    query_id: str
    name: str
    status: str = "ingested"
    sql_test_rows: int | None = None
