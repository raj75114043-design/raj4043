"""Pydantic schemas for admin/orchestration endpoints."""
from __future__ import annotations

from datetime import date, datetime

from pydantic import BaseModel, Field


class GeographyFilter(BaseModel):
    """Geography scope for a generation run."""

    level: str | None = Field(
        None,
        description="One of: overall | region | area | market. None = all levels.",
    )
    market: str | None = None
    region: str | None = None
    area: str | None = None


class TimeframeFilter(BaseModel):
    start_date: date | None = None
    end_date: date | None = None


class GenerateInsightsRequest(BaseModel):
    """Body for POST /admin/generate-insights."""

    geography_filters: GeographyFilter | None = Field(
        None,
        description=(
            "Geography scope to run. level=None expands to all levels in the geo hierarchy. "
            "Set region/area/market to scope down to a specific slice."
        ),
    )
    timeframe: TimeframeFilter | None = None

    # Query selection — filters are AND-combined across dimensions
    projects: list[str] | None = Field(
        None, description="Run only queries tagged with these projects (OR logic)."
    )
    functions: list[str] | None = Field(
        None, description="Run only queries tagged with these functions (OR logic)."
    )
    pack_ids: list[str] | None = Field(
        None, description="Run only queries belonging to these InsightPacks."
    )
    query_ids: list[str] | None = Field(
        None, description="Run only these specific query IDs."
    )

    # Runtime options
    max_parallel: int | None = Field(None, ge=1, le=20)
    vendor_grouping: bool = Field(
        False,
        description="When True, queries with a group_by_column will aggregate by "
                    "(geography, vendor) for cross-vendor comparison.",
    )


class GenerateInsightsResponse(BaseModel):
    """Immediate response — job kicked off asynchronously."""

    job_id: str
    status: str
    message: str
    estimated_queries: int | None = None


class JobStatusResponse(BaseModel):
    """Status of a background generation job."""

    job_id: str
    status: str
    total_queries: int
    completed_queries: int
    failed_queries: int
    total_insights_generated: int
    progress_pct: float

    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None

    error_message: str | None = None
    recent_logs: list[dict] | None = None
    insight_ids: list[str] | None = None


class HierarchicalInsightsRequest(BaseModel):
    """Body for POST /admin/generate-insights-hierarchical."""

    timeframe: TimeframeFilter | None = None

    # Query selection
    projects: list[str] | None = Field(None, description="Run only queries tagged with these projects.")
    functions: list[str] | None = Field(None, description="Run only queries tagged with these functions.")
    pack_ids: list[str] | None = Field(None, description="Run only queries in these packs.")
    query_ids: list[str] | None = Field(None, description="Run only these specific query IDs.")

    # Hierarchical drilling controls
    max_depth: int = Field(
        4,
        ge=1,
        le=4,
        description=(
            "How many levels to drill: 1=overall only, 2=+region, 3=+area, 4=+market (full hierarchy). "
            "The overall level runs queries against the full dataset (no geo filter), "
            "then drills into regions/areas/markets where problems exist. "
            "A synthesis summary is always generated after all levels complete. "
            "Default 4 (full hierarchy)."
        ),
    )
    max_children_per_level: int = Field(
        3,
        ge=1,
        le=10,
        description="Max number of child nodes to drill into per parent node. Keeps compute bounded.",
    )
    severity_floor: float = Field(
        40.0,
        ge=0.0,
        le=100.0,
        description=(
            "Minimum average severity score (0–100) at a node to trigger drilling deeper. "
            "Nodes below this threshold are considered healthy and not investigated further."
        ),
    )

    # Runtime options
    max_parallel: int | None = Field(None, ge=1, le=20)
    vendor_grouping: bool = Field(
        False,
        description="When True, queries with a group_by_column will aggregate by "
                    "(geography, vendor) for cross-vendor comparison.",
    )


class QuickHierarchicalRequest(BaseModel):
    """Body for POST /admin/generate-insights-hierarchical-quick."""

    last_n_queries: int = Field(
        50, ge=1, le=500,
        description="Run hierarchical insights for the N most recently added active queries.",
    )

    # Hierarchical drilling controls — same defaults as HierarchicalInsightsRequest
    max_depth: int = Field(4, ge=1, le=4)
    max_children_per_level: int = Field(3, ge=1, le=10)
    severity_floor: float = Field(40.0, ge=0.0, le=100.0)

    max_parallel: int = Field(3, ge=1, le=20)
    vendor_grouping: bool = False


class ArchiveRequest(BaseModel):
    """Body for POST /admin/archive-old-insights."""

    days_threshold: int = Field(90, ge=0, description="Archive insights older than N days. Use 0 to archive all insights immediately.")
    dry_run: bool = Field(False, description="Count candidates without archiving")


class ArchiveResponse(BaseModel):
    """Result of archival operation."""

    insights_archived: int
    dry_run: bool
    message: str


class BackfillEmbeddingsRequest(BaseModel):
    """Body for POST /admin/backfill-embeddings."""

    limit: int | None = Field(
        None,
        ge=1,
        description="Max number of insights to backfill. None = all pending.",
    )
    dry_run: bool = Field(False, description="Count pending insights without generating embeddings")


class BackfillEmbeddingsResponse(BaseModel):
    """Result of backfill request."""

    pending_count: int
    started: bool
    message: str
