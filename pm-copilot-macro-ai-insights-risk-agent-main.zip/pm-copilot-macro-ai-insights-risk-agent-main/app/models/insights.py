"""
ORM models for the core insights tables.

Table names are driven by settings (configurable per environment).
The PostgreSQL schema is set globally on Base.metadata (see database.py).
"""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, Index, Integer, String, Text, func
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.config import get_settings
from app.database import Base

_s = get_settings()


def _gen_uuid() -> str:
    return str(uuid.uuid4())


class Insight(Base):
    __tablename__ = _s.table_insights

    insight_id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=_gen_uuid)

    title: Mapped[str] = mapped_column(Text, nullable=False)
    insight: Mapped[str] = mapped_column(Text, nullable=False)
    # Detailed analysis as a JSON array of bullet-point strings.
    # Legacy rows may contain a plain text string — the API handles both.
    insight_detail: Mapped[list | str | None] = mapped_column(JSONB)

    market: Mapped[str | None] = mapped_column(String(100))
    area: Mapped[str | None] = mapped_column(String(100))
    region: Mapped[str | None] = mapped_column(String(100))
    team: Mapped[str | None] = mapped_column(String(100))

    severity_score: Mapped[float | None] = mapped_column(Float)
    category: Mapped[str | None] = mapped_column(Text)
    subcategory: Mapped[str | None] = mapped_column(Text)
    type: Mapped[str | None] = mapped_column(Text)

    site_count: Mapped[int | None] = mapped_column(Integer)
    drill_down_sql: Mapped[str | None] = mapped_column(Text)
    # Cached aggregated rows that were fed to the LLM — stored at generation
    # time so the drill-down view is instant (no source DB re-query needed).
    source_data: Mapped[list | None] = mapped_column(JSONB)
    # Full result rows from the drill-down SQL execution, stored at generation
    # time so the drill-down API returns the exact data that was current when
    # the insight was created (not stale/changed data from a later re-run).
    drill_down_data: Mapped[list | None] = mapped_column(JSONB)
    # Flat list of every site identifier from the raw (pre-aggregation) rows.
    site_ids: Mapped[list[str] | None] = mapped_column(ARRAY(String))
    projects: Mapped[list[str] | None] = mapped_column(ARRAY(String))
    functions: Mapped[list[str] | None] = mapped_column(ARRAY(String))
    tags: Mapped[list[str] | None] = mapped_column(ARRAY(String))
    # How many consecutive daily jobs produced an insight for the same
    # (query_id, geo_level, region, area, market). Used to auto-tag recurring issues.
    consecutive_occurrences: Mapped[int] = mapped_column(Integer, default=1, nullable=False)

    # Generation debug context — stores the rendered prompt, data rows fed to
    # the LLM, and the raw LLM JSON response.  Allows post-hoc inspection of
    # exactly what produced this insight.
    generation_context: Mapped[dict | None] = mapped_column(JSONB)

    query_id: Mapped[str | None] = mapped_column(String(100))
    prompt_template_id: Mapped[str | None] = mapped_column(String(100))
    llm_model: Mapped[str | None] = mapped_column(String(100))
    job_id: Mapped[str | None] = mapped_column(String(36))

    # Pack grouping — set when the query belongs to an InsightPack.
    # is_pack_summary=True marks the single "hero" insight shown on the home
    # feed for this pack; all other geo-cuts are drill-down detail rows.
    pack_id: Mapped[str | None] = mapped_column(String(255))
    is_pack_summary: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    # Geo aggregation level at which this insight was generated
    # ('overall' | 'region' | 'area' | 'market').
    geo_level: Mapped[str | None] = mapped_column(String(20))

    # Which analysis area this insight covers (e.g. "Approval & Rejection Rates").
    # NULL for single-area queries (backward compatible).
    insight_area: Mapped[str | None] = mapped_column(String(200))

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), onupdate=func.now())
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))

    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    embedding: Mapped[list["InsightEmbedding"]] = relationship(  # noqa: F821
        "InsightEmbedding", back_populates="insight", cascade="all, delete-orphan", lazy="select"
    )
    interactions: Mapped[list["UserInteraction"]] = relationship(  # noqa: F821
        "UserInteraction", back_populates="insight", cascade="all, delete-orphan", lazy="select"
    )

    __table_args__ = (
        Index("idx_insight_market_region", "market", "region"),
        Index("idx_insight_created_at", "created_at"),
        Index("idx_insight_severity", "severity_score"),
        # Composite covering the default list-query sort (severity DESC, created_at DESC)
        Index("idx_insight_sort", "severity_score", "created_at"),
        Index("idx_insight_category", "category", "subcategory"),
        Index("idx_insight_is_active", "is_active"),
        Index("idx_insight_expires_at", "expires_at"),
        Index("idx_insight_job_id", "job_id"),
        Index("idx_insight_pack_id", "pack_id"),
        Index("idx_insight_pack_summary", "pack_id", "is_pack_summary"),
        Index("idx_insight_geo_level", "geo_level"),
        # GIN indexes for ARRAY overlap filters (?project=, ?function=, ?tags=)
        Index("idx_insight_projects_gin", "projects", postgresql_using="gin"),
        Index("idx_insight_functions_gin", "functions", postgresql_using="gin"),
        Index("idx_insight_tags_gin", "tags", postgresql_using="gin"),
    )

    def __repr__(self) -> str:
        return f"<Insight id={self.insight_id} title={self.title!r}>"


class InsightHistorical(Base):
    """Archived copy — rows moved here after expiry; original insight_id preserved."""

    __tablename__ = _s.table_insights_historical

    archive_id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=_gen_uuid)
    insight_id: Mapped[str] = mapped_column(UUID(as_uuid=False), nullable=False)

    title: Mapped[str] = mapped_column(Text, nullable=False)
    insight: Mapped[str] = mapped_column(Text, nullable=False)
    insight_detail: Mapped[str | None] = mapped_column(Text)

    market: Mapped[str | None] = mapped_column(String(100))
    area: Mapped[str | None] = mapped_column(String(100))
    region: Mapped[str | None] = mapped_column(String(100))
    team: Mapped[str | None] = mapped_column(String(100))

    severity_score: Mapped[float | None] = mapped_column(Float)
    category: Mapped[str | None] = mapped_column(Text)
    subcategory: Mapped[str | None] = mapped_column(Text)
    type: Mapped[str | None] = mapped_column(Text)

    site_count: Mapped[int | None] = mapped_column(Integer)
    drill_down_sql: Mapped[str | None] = mapped_column(Text)
    source_data: Mapped[list | None] = mapped_column(JSONB)
    drill_down_data: Mapped[list | None] = mapped_column(JSONB)
    projects: Mapped[list[str] | None] = mapped_column(ARRAY(String))
    functions: Mapped[list[str] | None] = mapped_column(ARRAY(String))
    tags: Mapped[list[str] | None] = mapped_column(ARRAY(String))

    generation_context: Mapped[dict | None] = mapped_column(JSONB)

    query_id: Mapped[str | None] = mapped_column(String(100))
    prompt_template_id: Mapped[str | None] = mapped_column(String(100))
    llm_model: Mapped[str | None] = mapped_column(String(100))
    job_id: Mapped[str | None] = mapped_column(String(36))

    insight_area: Mapped[str | None] = mapped_column(String(200))

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    is_active: Mapped[bool] = mapped_column(Boolean, default=False)
    archived_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    __table_args__ = (
        Index("idx_hist_insight_id", "insight_id"),
        Index("idx_hist_market_region", "market", "region"),
        Index("idx_hist_archived_at", "archived_at"),
    )
