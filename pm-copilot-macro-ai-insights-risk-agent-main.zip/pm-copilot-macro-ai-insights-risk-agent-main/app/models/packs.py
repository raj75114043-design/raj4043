"""
ORM models for insight packs and user preferences.

InsightPack  — groups related queries across geo levels under one analytical question.
               e.g. "Vendor Rejection Rate WoW" has queries at overall / region / area / market.

UserPreferences — one row per user; stores default filter set (projects, functions,
                  geo scope).  The same values are used as home-screen filter defaults
                  and can be overridden per-session via query-string params.
"""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Float, Index, String, Text, func
from sqlalchemy.dialects.postgresql import ARRAY, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.config import get_settings
from app.database import Base

_s = get_settings()


def _gen_uuid() -> str:
    return str(uuid.uuid4())


class InsightPack(Base):
    """One analytical question with queries at multiple geo levels."""

    __tablename__ = _s.table_insight_packs

    pack_id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=_gen_uuid)

    # Human-readable identifier
    name: Mapped[str] = mapped_column(String(200), nullable=False, unique=True)
    description: Mapped[str | None] = mapped_column(Text)

    # PM hierarchy classification
    category: Mapped[str | None] = mapped_column(String(100))     # e.g. "Vendor Performance"
    subcategory: Mapped[str | None] = mapped_column(String(100))  # e.g. "Rejection Rate"

    # Which projects / functions this pack is relevant for (NULL = all)
    projects: Mapped[list[str] | None] = mapped_column(ARRAY(String))
    functions: Mapped[list[str] | None] = mapped_column(ARRAY(String))

    # Which geo aggregation levels this pack has queries for
    # e.g. ['overall', 'region', 'area', 'market']
    geo_levels: Mapped[list[str] | None] = mapped_column(ARRAY(String))

    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), onupdate=func.now())

    __table_args__ = (
        Index("idx_pack_category", "category", "subcategory"),
        Index("idx_pack_is_active", "is_active"),
    )

    def __repr__(self) -> str:
        return f"<InsightPack id={self.pack_id} name={self.name!r}>"


class UserPreferences(Base):
    """
    One row per user — stores their default filter/subscription set.

    Array fields use OR logic within the same dimension and AND logic
    across dimensions.  Example:
        projects=['NTM','AHLOB'], functions=['PDM','HSE'], geo_level='market',
        geo_markets=['London','Manchester']
    → insights for (NTM OR AHLOB) AND (PDM OR HSE) AND market IN (London, Manchester)

    NULL array  → no filter applied for that dimension (see everything).
    Empty array → treated the same as NULL (no filter).
    """

    __tablename__ = _s.table_user_preferences

    pref_id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=_gen_uuid)

    # One record per user — enforced by unique constraint below
    user_id: Mapped[str] = mapped_column(String(100), nullable=False)

    # Project / function filters (OR within dimension)
    projects: Mapped[list[str] | None] = mapped_column(ARRAY(String))   # ['NTM', 'AHLOB']
    functions: Mapped[list[str] | None] = mapped_column(ARRAY(String))  # ['PDM', 'HSE']

    # PM category filter
    categories: Mapped[list[str] | None] = mapped_column(ARRAY(String))  # ['Cost', 'Quality']

    # Geography — level = granularity, scope = specific slice(s)
    geo_level: Mapped[str | None] = mapped_column(String(20))    # 'overall'|'region'|'area'|'market'
    geo_regions: Mapped[list[str] | None] = mapped_column(ARRAY(String))
    geo_areas: Mapped[list[str] | None] = mapped_column(ARRAY(String))
    geo_markets: Mapped[list[str] | None] = mapped_column(ARRAY(String))

    # Insight significance threshold — only show insights whose severity_score >= this
    threshold_pct: Mapped[float | None] = mapped_column(Float)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), onupdate=func.now())

    __table_args__ = (
        Index("idx_uprefs_user_id", "user_id", unique=True),
    )

    def __repr__(self) -> str:
        return f"<UserPreferences user={self.user_id!r}>"
