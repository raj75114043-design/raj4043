"""
ORM model for user_interactions.

Table name and FK target are both driven by settings for full configurability.
"""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean, DateTime, ForeignKey, Index, String, Text, UniqueConstraint, func,
)
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.config import get_settings
from app.database import Base

_s = get_settings()


def _gen_uuid() -> str:
    return str(uuid.uuid4())


class UserInteraction(Base):
    """
    One row per (insight_id, user_id) pair — all interaction flags on that row.
    previous_state stores the row snapshot before the last mutation.
    """

    __tablename__ = _s.table_user_interactions

    interaction_id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=_gen_uuid)

    # FK references the configurable insights table name.
    # MetaData(schema=...) on Base ensures the generated constraint is
    # fully schema-qualified in the DDL (e.g. pwc_derived_tables_schema.insights).
    insight_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey(f"{_s.table_insights}.insight_id", ondelete="CASCADE"),
        nullable=False,
    )
    user_id: Mapped[str] = mapped_column(String(100), nullable=False)

    liked: Mapped[bool | None] = mapped_column(Boolean)
    disliked: Mapped[bool | None] = mapped_column(Boolean)
    acknowledged: Mapped[bool | None] = mapped_column(Boolean)
    muted: Mapped[bool | None] = mapped_column(Boolean)
    flagged: Mapped[bool | None] = mapped_column(Boolean)
    flag_reason: Mapped[str | None] = mapped_column(Text)
    comment: Mapped[str | None] = mapped_column(Text)

    previous_state: Mapped[dict | None] = mapped_column(JSONB)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), onupdate=func.now())

    insight: Mapped["Insight"] = relationship("Insight", back_populates="interactions")  # noqa: F821

    __table_args__ = (
        UniqueConstraint("insight_id", "user_id", name="uq_insight_user"),
        Index("idx_ui_user_insight", "user_id", "insight_id"),
        Index("idx_ui_insight", "insight_id"),
        Index("idx_ui_user_id", "user_id"),
    )

    def to_state_snapshot(self) -> dict:
        return {
            "liked": self.liked,
            "disliked": self.disliked,
            "acknowledged": self.acknowledged,
            "muted": self.muted,
            "flagged": self.flagged,
            "flag_reason": self.flag_reason,
            "comment": self.comment,
        }

    def __repr__(self) -> str:
        return f"<UserInteraction insight={self.insight_id} user={self.user_id}>"
