"""ORM model for derived table build/refresh metadata (insights DB)."""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import DateTime, Integer, String, Text, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base


def _gen_uuid() -> str:
    return str(uuid.uuid4())


class DerivedTableDefinition(Base):
    """
    Stores the specification and generated DDL for each derived table
    managed by the Builder API.

    The actual table lives in the source DB (schema_name.table_name).
    This record tracks how it was built and when it was last refreshed.
    """

    __tablename__ = "derived_table_definitions"

    table_def_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False), primary_key=True, default=_gen_uuid
    )

    # Target location
    table_name: Mapped[str] = mapped_column(String(200), nullable=False)
    schema_name: Mapped[str] = mapped_column(String(200), nullable=False)

    # User-provided specification
    description: Mapped[str] = mapped_column(Text, nullable=False)
    business_context: Mapped[str] = mapped_column(Text, nullable=False)
    source_tables: Mapped[list] = mapped_column(JSONB, nullable=False, default=list)
    join_logic: Mapped[str] = mapped_column(Text, nullable=False)
    filter_logic: Mapped[str | None] = mapped_column(Text)
    additional_logic: Mapped[str | None] = mapped_column(Text)

    # LLM output
    generated_ddl: Mapped[str] = mapped_column(Text, nullable=False)

    # Refresh strategy: truncate_insert | create_replace
    refresh_mode: Mapped[str] = mapped_column(String(30), default="truncate_insert")

    # Runtime state
    status: Mapped[str] = mapped_column(String(20), default="draft")
    last_refreshed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    last_error: Mapped[str | None] = mapped_column(Text)
    row_count: Mapped[int | None] = mapped_column(Integer)

    created_by: Mapped[str | None] = mapped_column(String(200))
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), onupdate=func.now()
    )

    def __repr__(self) -> str:
        return f"<DerivedTableDefinition {self.schema_name}.{self.table_name} [{self.status}]>"
