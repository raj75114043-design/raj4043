"""
ORM model for insight_embeddings using pgvector.
Table name and FK target driven by settings.
"""
from __future__ import annotations

import uuid
from datetime import datetime

from pgvector.sqlalchemy import Vector
from sqlalchemy import DateTime, ForeignKey, Index, String, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.config import get_settings
from app.database import Base

_s = get_settings()


def _gen_uuid() -> str:
    return str(uuid.uuid4())


class InsightEmbedding(Base):
    __tablename__ = _s.table_insight_embeddings

    embedding_id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=_gen_uuid)

    insight_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey(f"{_s.table_insights}.insight_id", ondelete="CASCADE"),
        nullable=False,
    )

    embedding_vector: Mapped[list[float]] = mapped_column(
        Vector(_s.embedding_dimension), nullable=False
    )
    model_name: Mapped[str] = mapped_column(String(100), nullable=False)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    insight: Mapped["Insight"] = relationship("Insight", back_populates="embedding")  # noqa: F821

    __table_args__ = (
        Index("idx_embedding_insight_id", "insight_id"),
        # IVFFlat ANN index created via Alembic migration after table creation
    )

    def __repr__(self) -> str:
        return f"<InsightEmbedding insight={self.insight_id} model={self.model_name}>"
