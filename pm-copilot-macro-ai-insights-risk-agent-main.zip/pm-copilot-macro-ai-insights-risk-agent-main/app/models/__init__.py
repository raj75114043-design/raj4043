"""ORM models — imported here so Alembic auto-discovery works."""
from app.models.insights import Insight, InsightHistorical
from app.models.interactions import UserInteraction
from app.models.embeddings import InsightEmbedding
from app.models.jobs import BatchJob, BatchJobLog
from app.models.query_library import SqlQueryLibrary, PromptTemplate
from app.models.packs import InsightPack, UserPreferences

__all__ = [
    "Insight",
    "InsightHistorical",
    "UserInteraction",
    "InsightEmbedding",
    "BatchJob",
    "BatchJobLog",
    "SqlQueryLibrary",
    "PromptTemplate",
    "InsightPack",
    "UserPreferences",
]
