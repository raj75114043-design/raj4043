"""
ORM models for the configurable SQL query library and prompt template library.
Table names driven by settings.
"""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Index, Integer, String, Text, func
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.config import get_settings
from app.database import Base

_s = get_settings()


def _gen_uuid() -> str:
    return str(uuid.uuid4())


class SqlQueryLibrary(Base):
    __tablename__ = _s.table_sql_query_library

    query_id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=_gen_uuid)
    name: Mapped[str] = mapped_column(String(200), nullable=False, unique=True)
    query_sql: Mapped[str] = mapped_column(Text, nullable=False)

    purpose: Mapped[str | None] = mapped_column(Text)
    description: Mapped[str | None] = mapped_column(Text)
    geography_level: Mapped[str | None] = mapped_column(String(20))

    projects: Mapped[list[str] | None] = mapped_column(ARRAY(String))
    functions: Mapped[list[str] | None] = mapped_column(ARRAY(String))
    team: Mapped[str | None] = mapped_column(String(100))
    user_type: Mapped[str | None] = mapped_column(String(100))
    tags: Mapped[list[str] | None] = mapped_column(ARRAY(String))

    # Pack association — links this query to an InsightPack (one pack can have
    # multiple queries, one per geo level).
    pack_id: Mapped[str | None] = mapped_column(String(200))         # FK → insight_packs.pack_id
    pm_category: Mapped[str | None] = mapped_column(String(100))     # Cost / Quality / Schedule / …

    parameter_schema: Mapped[dict | None] = mapped_column(JSONB)
    prompt_template_id: Mapped[str | None] = mapped_column(String(36))
    # Structured KPI context injected into LLM prompts at generation time.
    # Expected keys: kpi_name, unit, target, sla_threshold, interpretation,
    #                aggregation_rules (dict: col_name → "sum"|"avg"|"max"|"min")
    business_context: Mapped[dict | None] = mapped_column(JSONB)

    # Max rows to fetch from source DB during insight generation.
    # NULL = no limit (all rows fetched). Set explicitly only when a
    # query is known to produce very large result sets and you want
    # a safety cap.
    row_limit: Mapped[int | None] = mapped_column(Integer)

    # Optional secondary grouping column (e.g. vendor/company name).
    # When set, aggregation groups by (geo_column, group_by_column)
    # so the LLM can compare across vendors within each geography.
    group_by_column: Mapped[str | None] = mapped_column(String(100))

    # Optional list of distinct analysis angles to generate from the same data.
    # Each area produces a separate insight at every geography node.
    # When NULL or empty, a single insight is generated (backward compatible).
    # Example: ["Approval & Rejection Rates", "FTR Performance", "Outages"]
    insight_areas: Mapped[list | None] = mapped_column(JSONB)

    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    version: Mapped[str] = mapped_column(String(20), default="1.0")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    updated_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), onupdate=func.now())

    __table_args__ = (
        Index("idx_sql_geography_level", "geography_level"),
        Index("idx_sql_is_active", "is_active"),
        Index("idx_sql_pack_id", "pack_id"),
        Index("idx_sql_pm_category", "pm_category"),
    )

    def __repr__(self) -> str:
        return f"<SqlQueryLibrary id={self.query_id} name={self.name!r}>"


class PromptTemplate(Base):
    __tablename__ = _s.table_prompt_templates

    template_id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=_gen_uuid)
    name: Mapped[str] = mapped_column(String(200), nullable=False, unique=True)
    system_prompt: Mapped[str] = mapped_column(Text, nullable=False)
    user_prompt: Mapped[str] = mapped_column(Text, nullable=False)

    category: Mapped[str | None] = mapped_column(String(100))
    subcategory: Mapped[str | None] = mapped_column(String(100))
    expected_variables: Mapped[list[str] | None] = mapped_column(ARRAY(String))

    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    version: Mapped[str] = mapped_column(String(20), default="1.0")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    def __repr__(self) -> str:
        return f"<PromptTemplate id={self.template_id} name={self.name!r}>"
