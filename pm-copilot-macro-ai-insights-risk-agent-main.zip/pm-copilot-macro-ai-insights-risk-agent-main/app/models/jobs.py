"""
ORM models for batch job tracking.
Table names driven by settings.
"""
from __future__ import annotations

import uuid
from datetime import datetime

from sqlalchemy import DateTime, Float, ForeignKey, Index, Integer, String, Text, func
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.config import get_settings
from app.database import Base

_s = get_settings()


def _gen_uuid() -> str:
    return str(uuid.uuid4())


class BatchJob(Base):
    __tablename__ = _s.table_batch_jobs

    job_id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=_gen_uuid)

    geography_filters: Mapped[dict | None] = mapped_column(JSONB)
    timeframe: Mapped[dict | None] = mapped_column(JSONB)
    user_segments: Mapped[list | None] = mapped_column(JSONB)
    query_tags: Mapped[dict | None] = mapped_column(JSONB)

    status: Mapped[str] = mapped_column(String(50), default="pending", nullable=False)
    total_queries: Mapped[int] = mapped_column(Integer, default=0)
    completed_queries: Mapped[int] = mapped_column(Integer, default=0)
    failed_queries: Mapped[int] = mapped_column(Integer, default=0)
    total_insights_generated: Mapped[int] = mapped_column(Integer, default=0)
    progress_pct: Mapped[float] = mapped_column(Float, default=0.0)

    error_message: Mapped[str | None] = mapped_column(Text)
    error_details: Mapped[dict | None] = mapped_column(JSONB)
    insight_ids: Mapped[list | None] = mapped_column(JSONB)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    triggered_by: Mapped[str | None] = mapped_column(String(100))

    logs: Mapped[list["BatchJobLog"]] = relationship(
        "BatchJobLog",
        back_populates="job",
        cascade="all, delete-orphan",
        order_by="BatchJobLog.created_at",
    )

    __table_args__ = (
        Index("idx_job_status", "status"),
        Index("idx_job_created_at", "created_at"),
    )

    def __repr__(self) -> str:
        return f"<BatchJob id={self.job_id} status={self.status}>"


class BatchJobLog(Base):
    __tablename__ = _s.table_batch_job_logs

    log_id: Mapped[str] = mapped_column(UUID(as_uuid=False), primary_key=True, default=_gen_uuid)
    job_id: Mapped[str] = mapped_column(
        UUID(as_uuid=False),
        ForeignKey(f"{_s.table_batch_jobs}.job_id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    level: Mapped[str] = mapped_column(String(10), default="INFO")
    step: Mapped[str | None] = mapped_column(String(100))
    query_id: Mapped[str | None] = mapped_column(String(100))
    message: Mapped[str] = mapped_column(Text, nullable=False)
    details: Mapped[dict | None] = mapped_column(JSONB)

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    job: Mapped["BatchJob"] = relationship("BatchJob", back_populates="logs")

    __table_args__ = (Index("idx_joblog_job_id", "job_id"),)
