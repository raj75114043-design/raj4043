"""
Embedding Service — custom gateway via LangChain OpenAIEmbeddings.

Generates vector embeddings for insights and search queries using the
same enterprise gateway as the LLM service.

Embeddings are cached in Redis (24h) to avoid redundant API calls on re-runs.
"""
from __future__ import annotations

import hashlib
import json
import logging
from typing import Any

from langchain_openai import OpenAIEmbeddings
from sqlalchemy.ext.asyncio import AsyncSession
from tenacity import retry, stop_after_attempt, wait_exponential

from app.config import get_settings
from app.database import get_redis
from app.models.embeddings import InsightEmbedding

log = logging.getLogger(__name__)
settings = get_settings()


class EmbeddingServiceError(Exception):
    """Raised on embedding generation failure."""


class EmbeddingService:
    """Generates and stores vector embeddings via the custom gateway."""

    def __init__(self) -> None:
        self._model = OpenAIEmbeddings(
            api_key="NONE",                    # placeholder — real auth via header
            openai_api_base=settings.llm_api_base_url,
            default_headers={
                "api-key": settings.llm_gateway_api_key,
                "workspacename": settings.llm_workspace_name,
            },
            model=settings.embedding_model,    # text-embedding-ada-002
        )

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    async def embed_text(self, text: str) -> list[float]:
        """
        Generate an embedding vector for the given text.
        Results are Redis-cached for 24 hours when Redis is enabled.
        When REDIS_ENABLED=false, caching is skipped entirely.
        """
        if not settings.redis_enabled:
            return await self._generate_embedding(text)

        cache_key = f"emb:{self._text_hash(text)}"
        redis = get_redis()

        try:
            cached = await redis.get(cache_key)
            if cached:
                return json.loads(cached)
        except Exception as exc:
            log.warning("Redis cache read failed (bypassing cache): %s", exc)

        vector = await self._generate_embedding(text)

        try:
            await redis.setex(cache_key, 86400, json.dumps(vector))
        except Exception as exc:
            log.warning("Redis cache write failed (result not cached): %s", exc)

        return vector

    async def embed_and_store(
        self,
        db: AsyncSession,
        insight_id: str,
        text: str,
    ) -> InsightEmbedding:
        """
        Embed an insight and persist it.
        Replaces any existing embedding for the same insight_id.
        """
        from sqlalchemy import delete

        vector = await self.embed_text(text)

        await db.execute(
            delete(InsightEmbedding).where(InsightEmbedding.insight_id == insight_id)
        )

        embedding = InsightEmbedding(
            insight_id=insight_id,
            embedding_vector=vector,
            model_name=settings.embedding_model,
        )
        db.add(embedding)
        await db.flush()
        log.debug("Stored embedding for insight_id=%s", insight_id)
        return embedding

    async def semantic_search(
        self,
        db: AsyncSession,
        query_text: str,
        *,
        limit: int = 10,
        similarity_threshold: float = 0.3,
        filters: dict[str, Any] | None = None,
    ) -> list[tuple[str, float]]:
        """
        Cosine-similarity vector search via pgvector.

        Returns list of (insight_id, similarity_score) sorted descending.
        """
        from sqlalchemy import text

        # Diagnostic: log embedding count and active-insight JOIN count so the
        # exact failure point (empty table vs broken join vs threshold) is visible.
        diag = await db.execute(text(f"""
            SELECT
                (SELECT COUNT(*) FROM {settings.table_insight_embeddings}) AS emb_count,
                (SELECT COUNT(*)
                 FROM {settings.table_insight_embeddings} e
                 JOIN {settings.table_insights} i ON i.insight_id = e.insight_id
                 WHERE i.is_active = TRUE) AS join_count
        """))
        row = diag.one()
        total_embeddings, join_count = row.emb_count, row.join_count
        log.info(
            "semantic_search: total_embeddings=%d active_join_rows=%d query=%r threshold=%s",
            total_embeddings,
            join_count,
            query_text[:80],
            similarity_threshold,
        )
        if total_embeddings == 0:
            log.warning(
                "insight_embeddings table is empty — run POST /admin/backfill-embeddings "
                "to generate embeddings for existing insights."
            )
            return []
        if join_count == 0:
            log.warning(
                "insight_embeddings has %d row(s) but none join to an is_active=TRUE insight. "
                "Check that the insight_ids match and is_active is set correctly.",
                total_embeddings,
            )
            return []

        query_vector = await self.embed_text(query_text)
        vector_literal = json.dumps(query_vector)

        # When threshold <= 0 treat it as "no threshold" — include everything including
        # vectors with slight negative cosine similarity (floating-point edge cases).
        filter_clauses = ["i.is_active = TRUE"]
        if similarity_threshold > 0:
            filter_clauses.append(
                f"1 - (e.embedding_vector <=> '{vector_literal}'::vector) >= {similarity_threshold}"
            )

        if filters:
            for col in ("market", "region", "area", "category"):
                if filters.get(col):
                    filter_clauses.append(f"LOWER(i.{col}) = LOWER(:{col})")
            if filters.get("severity_min") is not None:
                filter_clauses.append("i.severity_score >= :severity_min")
            if filters.get("severity_max") is not None:
                filter_clauses.append("i.severity_score <= :severity_max")
            # Array filters — case-insensitive overlap (insight matches if
            # ANY of its values appear in the filter list).
            if filters.get("projects"):
                filter_clauses.append(
                    "(SELECT array_agg(LOWER(e2)) FROM unnest(i.projects) AS e2)"
                    " && :_arr_projects"
                )
            if filters.get("functions"):
                filter_clauses.append(
                    "(SELECT array_agg(LOWER(e2)) FROM unnest(i.functions) AS e2)"
                    " && :_arr_functions"
                )

        where_clause = " AND ".join(filter_clauses)

        # Note: the vector literal is embedded directly in the SQL to avoid
        # the `:param::type` colon-collision between SQLAlchemy bind-param syntax
        # and PostgreSQL's cast syntax (::vector).  vector_literal is always
        # json.dumps() of a float list so there is no SQL-injection risk.
        sql = text(f"""
            SELECT
                e.insight_id,
                1 - (e.embedding_vector <=> '{vector_literal}'::vector) AS similarity
            FROM {settings.table_insight_embeddings} e
            JOIN {settings.table_insights} i ON i.insight_id = e.insight_id
            WHERE {where_clause}
            ORDER BY similarity DESC
            LIMIT :limit
        """)

        params: dict[str, Any] = {"limit": limit}
        if filters:
            for col in ("market", "region", "area", "category"):
                if filters.get(col):
                    params[col] = filters[col]
            if filters.get("severity_min") is not None:
                params["severity_min"] = filters["severity_min"]
            if filters.get("severity_max") is not None:
                params["severity_max"] = filters["severity_max"]
            if filters.get("projects"):
                params["_arr_projects"] = [p.lower() for p in filters["projects"]]
            if filters.get("functions"):
                params["_arr_functions"] = [f.lower() for f in filters["functions"]]

        result = await db.execute(sql, params)
        rows = result.fetchall()
        log.info(
            "semantic_search: sql_rows_returned=%d top_similarity=%s",
            len(rows),
            round(float(rows[0].similarity), 4) if rows else "n/a",
        )
        # asyncpg returns UUID columns as Python uuid.UUID objects in raw SQL,
        # but the ORM uses UUID(as_uuid=False) which stores/returns plain strings.
        # Stringify here so callers always work with strings.
        return [(str(row.insight_id), float(row.similarity)) for row in rows]

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        reraise=True,
    )
    async def _generate_embedding(self, text: str) -> list[float]:
        """Call the gateway embedding endpoint and return the vector."""
        truncated = text[:8000]   # stay within ada-002 token limit
        try:
            # aembed_query runs the sync call in a thread pool internally
            return await self._model.aembed_query(truncated)
        except Exception as exc:
            log.error("Embedding gateway error: %s", exc)
            raise EmbeddingServiceError(f"Embedding generation failed: {exc}") from exc

    @staticmethod
    def _text_hash(text: str) -> str:
        return hashlib.sha256(text.encode()).hexdigest()[:32]

    @staticmethod
    def build_embedding_text(title: str, insight: str, tags: list[str] | None = None) -> str:
        """Combine insight fields into a single text string for embedding."""
        parts = [title, insight]
        if tags:
            parts.append(" ".join(tags))
        return " ".join(parts)
