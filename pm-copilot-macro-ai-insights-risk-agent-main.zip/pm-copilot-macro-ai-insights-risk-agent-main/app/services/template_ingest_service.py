"""
Template-based onboarding / ingest service.

Pipeline
--------
1. parse_excel() / parse_yaml()  → IngestTemplateData
2. validate()                    → IngestReport  (checks DB tables, columns, SQL safety)
3. generate_sql()                → fills generated_sql for each valid KpiEntry (LLM)
4. test_sql()                    → test-run each SQL against source DB
5. ingest()                      → persist SqlQueryLibrary rows, return updated IngestReport
"""
from __future__ import annotations

import io
import json
import logging
import re
import uuid
from typing import Any

import yaml
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.models.query_library import SqlQueryLibrary
from app.schemas.ingest import (
    DataSourceEntry,
    IngestReport,
    IngestStatus,
    IngestTemplateData,
    IssueSeverity,
    KpiEntry,
    KpiValidationResult,
    ValidationIssue,
)
from app.utils.validators import is_safe_read_query

log = logging.getLogger(__name__)
settings = get_settings()

# ── Allowed values for dropdown validation in the template ──────────
_GEO_LEVELS = ["overall", "region", "area", "market"]
_CATEGORIES = ["performance", "capacity", "quality", "reliability", "compliance", "operational"]
_AGG_METHODS = ["avg", "sum", "max", "min", "count"]
_PROMPT_TEMPLATES = [
    "performance_insight", "trend_insight", "capacity_insight",
    "executive_summary_insight", "vendor_performance", "schedule_adherence",
    "anomaly_detection", "comparative_analysis", "multi_kpi_synthesis",
]


# ================================================================== #
# Excel template builder
# ================================================================== #
def generate_excel_template() -> bytes:
    """Return bytes of a pre-formatted .xlsx onboarding template."""
    wb = Workbook()

    _build_instructions_sheet(wb)
    _build_data_sources_sheet(wb)
    _build_kpi_definitions_sheet(wb)

    # Remove the default empty sheet that openpyxl creates
    if "Sheet" in wb.sheetnames:
        del wb["Sheet"]

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ─── Style helpers ───────────────────────────────────────────────────
def _hdr(ws, row: int, col: int, value: str, *, bold: bool = True, bg: str | None = "1F4E79", fg: str = "FFFFFF") -> None:
    cell = ws.cell(row=row, column=col, value=value)
    cell.font = Font(bold=bold, color=fg)
    if bg:
        cell.fill = PatternFill(fill_type="solid", fgColor=bg)
    cell.alignment = Alignment(wrap_text=True, vertical="center")


def _note(ws, row: int, col: int, value: str, *, italic: bool = True) -> None:
    cell = ws.cell(row=row, column=col, value=value)
    cell.font = Font(italic=italic, color="595959", size=9)
    cell.alignment = Alignment(wrap_text=True, vertical="top")


def _add_dropdown(ws, col_letter: str, start_row: int, end_row: int, options: list[str]) -> None:
    formula = f'"{",".join(options)}"'
    dv = DataValidation(type="list", formula1=formula, allow_blank=True)
    dv.sqref = f"{col_letter}{start_row}:{col_letter}{end_row}"
    ws.add_data_validation(dv)


# ─── Sheet 1: Instructions ───────────────────────────────────────────
def _build_instructions_sheet(wb: Workbook) -> None:
    ws = wb.create_sheet("Instructions", 0)
    ws.column_dimensions["A"].width = 20
    ws.column_dimensions["B"].width = 100

    rows = [
        ("PURPOSE", "This workbook configures the Insights Engine. Fill the two data sheets and upload the file."),
        ("", ""),
        ("SHEETS", ""),
        ("Instructions", "This guidance sheet — do not delete or rename it."),
        ("Data_Sources",
         "List every table/view in your source DB that the engine will query. "
         "Provide geo column names so the engine can fan-out insights across geographies."),
        ("KPI_Definitions",
         "One row per KPI/analysis you want the engine to run. "
         "Mandatory columns are shaded blue. Optional columns are shaded grey."),
        ("", ""),
        ("GEO LEVELS", "overall → region → area → market. Pick the lowest geo level your KPI makes sense at."),
        ("AGGREGATION", "avg = mean of values | sum = total | max = highest | min = lowest | count = row count"),
        ("CUSTOM SQL",
         "Leave empty to let the engine generate SQL automatically via AI. "
         "Geo placeholders: AND (:market::text IS NULL OR col = :market::text). "
         "The ::text cast is required — asyncpg cannot infer types for NULL params without it."),
        ("TARGET vs SLA",
         "target = desired value (e.g. 95%). sla_threshold = minimum acceptable value (e.g. 85%). "
         "Both improve LLM severity scoring."),
        ("PROMPT TEMPLATE",
         "Choose the template that best describes your KPI: "
         + " | ".join(_PROMPT_TEMPLATES)),
        ("", ""),
        ("TIPS", "• You can upload YAML instead of Excel (see /api/v1/ingest/template?format=yaml for sample)."),
        ("", "• Validation runs instantly on upload — fix any ERRORs before clicking Apply."),
        ("", "• WARNINGs are safe to proceed with but worth reviewing."),
        ("", "• The engine test-runs every SQL against your source DB before committing."),
    ]

    for r, (label, detail) in enumerate(rows, start=1):
        ws.cell(row=r, column=1, value=label).font = Font(bold=bool(label), color="1F4E79" if label else "000000")
        ws.cell(row=r, column=2, value=detail).alignment = Alignment(wrap_text=True)
        ws.row_dimensions[r].height = 28 if label else 14

    ws.sheet_view.showGridLines = False


# ─── Sheet 2: Data_Sources ───────────────────────────────────────────
def _build_data_sources_sheet(wb: Workbook) -> None:
    ws = wb.create_sheet("Data_Sources", 1)

    headers = [
        ("table_name", "Table or view name (schema.table)", True),
        ("description", "What does this table contain?", False),
        ("market_column", "Column holding market/city name", False),
        ("area_column", "Column holding area name", False),
        ("region_column", "Column holding region name", False),
        ("site_id_column", "Column holding individual site / element ID", False),
    ]

    for col_idx, (name, hint, required) in enumerate(headers, start=1):
        bg = "1F4E79" if required else "7B96B2"
        _hdr(ws, 1, col_idx, name, bg=bg)
        _note(ws, 2, col_idx, hint)
        ws.column_dimensions[get_column_letter(col_idx)].width = 28

    ws.row_dimensions[1].height = 28
    ws.row_dimensions[2].height = 36

    # Example row
    example = ["pm_data.network_kpis", "Daily KPI snapshot per site", "market", "area", "region", "site_id"]
    for col_idx, val in enumerate(example, start=1):
        cell = ws.cell(row=3, column=col_idx, value=val)
        cell.font = Font(italic=True, color="808080")

    ws.freeze_panes = "A3"


# ─── Sheet 3: KPI_Definitions ────────────────────────────────────────
def _build_kpi_definitions_sheet(wb: Workbook) -> None:
    ws = wb.create_sheet("KPI_Definitions", 2)

    headers = [
        # (column_name, hint, required)
        ("kpi_name",          "Unique short name, no spaces (e.g. volte_drop_rate)",        True),
        ("display_name",      "Human-readable label shown in UI (e.g. VoLTE Drop Rate)",   False),
        ("description",       "What this KPI measures",                                     False),
        ("purpose",           "Why this insight matters to the team",                        False),
        ("category",          " | ".join(_CATEGORIES),                                       True),
        ("subcategory",       "Finer category (e.g. voice, data, faults)",                  False),
        ("pm_category",       "PM work category: Cost | Quality | Schedule | Other",        False),
        ("projects",          "Comma-separated project names (e.g. Project_A, Project_B)",  False),
        ("functions",         "Comma-separated functions (e.g. RAN, Core, Transport)",      False),
        ("team",              "Owning team name",                                            False),
        ("tags",              "Comma-separated custom tags",                                 False),
        ("source_table",      "Must match a table_name in Data_Sources sheet",              True),
        ("kpi_column",        "Column that holds the metric value",                         True),
        ("filter_conditions", "SQL WHERE fragment to filter rows (optional)",               False),
        ("geography_level",   " | ".join(_GEO_LEVELS),                                      True),
        ("unit",              "Unit of measure (e.g. %, ms, Mbps, count)",                 False),
        ("target",            "Target/goal value (numeric)",                                False),
        ("sla_threshold",     "SLA breach threshold (numeric)",                             False),
        ("interpretation",    "Brief plain-English note about what good/bad means",         False),
        ("aggregation_method","avg | sum | max | min | count",                              True),
        ("prompt_template",   " | ".join(_PROMPT_TEMPLATES),                                True),
        ("custom_sql",        "Full SELECT query; leave blank for AI generation",           False),
    ]

    for col_idx, (name, hint, required) in enumerate(headers, start=1):
        bg = "1F4E79" if required else "7B96B2"
        _hdr(ws, 1, col_idx, name, bg=bg)
        _note(ws, 2, col_idx, hint)
        ws.column_dimensions[get_column_letter(col_idx)].width = 26

    ws.row_dimensions[1].height = 28
    ws.row_dimensions[2].height = 40

    # Dropdowns (rows 3-102 = up to 100 KPIs)
    col_map = {h[0]: idx for idx, h in enumerate(headers, start=1)}
    _add_dropdown(ws, get_column_letter(col_map["category"]),         3, 102, _CATEGORIES)
    _add_dropdown(ws, get_column_letter(col_map["geography_level"]),  3, 102, _GEO_LEVELS)
    _add_dropdown(ws, get_column_letter(col_map["aggregation_method"]),3, 102, _AGG_METHODS)
    _add_dropdown(ws, get_column_letter(col_map["prompt_template"]),  3, 102, _PROMPT_TEMPLATES)

    # Example row
    example_values = {
        "kpi_name":           "volte_drop_rate",
        "display_name":       "VoLTE Drop Rate",
        "description":        "% of VoLTE calls that drop in-flight",
        "purpose":            "Identifies markets with elevated call quality issues",
        "category":           "quality",
        "subcategory":        "voice",
        "pm_category":        "Quality",
        "projects":           "",
        "functions":          "RAN",
        "team":               "Network Quality",
        "tags":               "volte,call-quality",
        "source_table":       "pm_data.network_kpis",
        "kpi_column":         "volte_drop_rate_pct",
        "filter_conditions":  "",
        "geography_level":    "market",
        "unit":               "%",
        "target":             "1.5",
        "sla_threshold":      "3.0",
        "interpretation":     "Lower is better. Values above 3% indicate a quality problem.",
        "aggregation_method": "avg",
        "prompt_template":    "performance_insight",
        "custom_sql":         "",
    }
    for col_idx, (name, _, _req) in enumerate(headers, start=1):
        cell = ws.cell(row=3, column=col_idx, value=example_values.get(name, ""))
        cell.font = Font(italic=True, color="808080")

    ws.freeze_panes = "A3"


# ================================================================== #
# Excel / YAML parser
# ================================================================== #
def parse_excel(file_bytes: bytes) -> IngestTemplateData:
    """Parse an uploaded Excel file into IngestTemplateData."""
    wb = load_workbook(io.BytesIO(file_bytes), data_only=True)

    # ── Data_Sources ────────────────────────────────────────────────
    data_sources: list[DataSourceEntry] = []
    if "Data_Sources" in wb.sheetnames:
        ws = wb["Data_Sources"]
        headers = _sheet_headers(ws, row=1)
        for row in ws.iter_rows(min_row=3, values_only=True):
            if not any(row):
                continue
            rd = _row_to_dict(headers, row)
            if not rd.get("table_name"):
                continue
            try:
                data_sources.append(DataSourceEntry(**{k: v for k, v in rd.items() if v is not None}))
            except Exception as exc:
                log.warning("Skipping Data_Sources row (parse error): %s", exc)

    # ── KPI_Definitions ─────────────────────────────────────────────
    kpi_entries: list[KpiEntry] = []
    if "KPI_Definitions" in wb.sheetnames:
        ws = wb["KPI_Definitions"]
        headers = _sheet_headers(ws, row=1)
        for row in ws.iter_rows(min_row=3, values_only=True):
            if not any(row):
                continue
            rd = _row_to_dict(headers, row)
            if not rd.get("kpi_name"):
                continue
            # Coerce numeric cells
            for num_field in ("target", "sla_threshold"):
                if rd.get(num_field) is not None:
                    try:
                        rd[num_field] = float(rd[num_field])
                    except (TypeError, ValueError):
                        rd[num_field] = None
            try:
                kpi_entries.append(KpiEntry(**{k: v for k, v in rd.items() if v not in (None, "")}))
            except Exception as exc:
                log.warning("Skipping KPI row '%s' (parse error): %s", rd.get("kpi_name"), exc)

    return IngestTemplateData(data_sources=data_sources, kpi_entries=kpi_entries)


def parse_yaml(file_bytes: bytes) -> IngestTemplateData:
    """Parse an uploaded YAML file into IngestTemplateData."""
    raw = yaml.safe_load(file_bytes.decode("utf-8"))
    data_sources = [DataSourceEntry(**ds) for ds in raw.get("data_sources", [])]
    kpi_entries = [KpiEntry(**kpi) for kpi in raw.get("kpi_definitions", [])]
    return IngestTemplateData(data_sources=data_sources, kpi_entries=kpi_entries)


def _sheet_headers(ws, row: int = 1) -> list[str]:
    return [str(c.value).strip() if c.value else "" for c in ws[row]]


def _row_to_dict(headers: list[str], row: tuple) -> dict[str, Any]:
    return {h: (str(v).strip() if isinstance(v, str) else v) for h, v in zip(headers, row) if h}


# ================================================================== #
# Validation
# ================================================================== #
async def validate(
    data: IngestTemplateData,
    source_db: AsyncSession,
) -> IngestReport:
    """
    Validate template data against the live source database.

    Checks:
    - Required fields present
    - source_table referenced in Data_Sources
    - source_table actually exists in source DB
    - kpi_column / geo columns exist in the table
    - custom_sql is read-safe (if provided)
    """
    global_issues: list[ValidationIssue] = []
    kpi_results: list[KpiValidationResult] = []

    # Index data sources by table name for quick lookup
    ds_map: dict[str, DataSourceEntry] = {ds.table_name: ds for ds in data.data_sources}

    # Discover all tables that actually exist in source DB
    existing_tables = await _get_existing_tables(source_db)

    for kpi in data.kpi_entries:
        issues: list[ValidationIssue] = []

        # ── Required fields ──────────────────────────────────────────
        for req_field in ("kpi_name", "source_table", "kpi_column", "category", "geography_level"):
            if not getattr(kpi, req_field, None) and not kpi.custom_sql:
                issues.append(ValidationIssue(
                    kpi_name=kpi.kpi_name,
                    field=req_field,
                    severity=IssueSeverity.error,
                    message=f"Required field '{req_field}' is missing.",
                    suggestion=f"Fill in '{req_field}' in the KPI_Definitions sheet.",
                ))

        # ── Source table check ───────────────────────────────────────
        ds = ds_map.get(kpi.source_table or "")
        if kpi.source_table and not ds:
            issues.append(ValidationIssue(
                kpi_name=kpi.kpi_name,
                field="source_table",
                severity=IssueSeverity.warning,
                message=f"source_table '{kpi.source_table}' not found in Data_Sources sheet.",
                suggestion="Add a row for this table in the Data_Sources sheet.",
            ))

        if kpi.source_table:
            table_key = kpi.source_table.lower()
            if not any(t.lower() == table_key for t in existing_tables):
                issues.append(ValidationIssue(
                    kpi_name=kpi.kpi_name,
                    field="source_table",
                    severity=IssueSeverity.error,
                    message=f"Table '{kpi.source_table}' does not exist in source database.",
                    suggestion="Check the table name and schema prefix.",
                ))
            else:
                # Verify kpi_column exists in the table
                if kpi.kpi_column:
                    col_exists = await _column_exists(source_db, kpi.source_table, kpi.kpi_column)
                    if not col_exists:
                        issues.append(ValidationIssue(
                            kpi_name=kpi.kpi_name,
                            field="kpi_column",
                            severity=IssueSeverity.error,
                            message=f"Column '{kpi.kpi_column}' not found in '{kpi.source_table}'.",
                            suggestion="Check column name spelling or choose a different column.",
                        ))

                # Verify geo column exists if data source entry is present
                if ds:
                    geo_col_map = {
                        "market": ds.market_column,
                        "area": ds.area_column,
                        "region": ds.region_column,
                    }
                    required_geo_col = geo_col_map.get(kpi.geography_level)
                    if required_geo_col:
                        col_exists = await _column_exists(source_db, kpi.source_table, required_geo_col)
                        if not col_exists:
                            issues.append(ValidationIssue(
                                kpi_name=kpi.kpi_name,
                                field="geography_level",
                                severity=IssueSeverity.error,
                                message=(
                                    f"Geo column '{required_geo_col}' (for level '{kpi.geography_level}') "
                                    f"not found in '{kpi.source_table}'."
                                ),
                                suggestion="Update market_column / area_column / region_column in Data_Sources.",
                            ))

        # ── custom_sql safety check ──────────────────────────────────
        if kpi.custom_sql:
            if not is_safe_read_query(kpi.custom_sql):
                issues.append(ValidationIssue(
                    kpi_name=kpi.kpi_name,
                    field="custom_sql",
                    severity=IssueSeverity.error,
                    message="custom_sql contains unsafe statements (DML/DDL not allowed).",
                    suggestion="Use SELECT only. Geo params must use ::text casts: AND (:market::text IS NULL OR col = :market::text).",
                ))

        # ── Business context suggestions ─────────────────────────────
        if not kpi.target and not kpi.sla_threshold:
            issues.append(ValidationIssue(
                kpi_name=kpi.kpi_name,
                field="target",
                severity=IssueSeverity.warning,
                message="Neither 'target' nor 'sla_threshold' provided.",
                suggestion="Setting targets improves LLM severity scoring accuracy.",
            ))

        # ── Determine initial status ─────────────────────────────────
        has_errors = any(i.severity == IssueSeverity.error for i in issues)
        status = IngestStatus.failed if has_errors else IngestStatus.validated

        kpi_results.append(KpiValidationResult(
            kpi_name=kpi.kpi_name,
            status=status,
            issues=issues,
            generated_sql=kpi.custom_sql,  # carry through if already provided
        ))

    valid_count = sum(1 for r in kpi_results if r.status == IngestStatus.validated)
    error_count = sum(1 for r in kpi_results if r.status == IngestStatus.failed)
    warning_count = sum(
        1 for r in kpi_results
        if r.status == IngestStatus.validated
        and any(i.severity == IssueSeverity.warning for i in r.issues)
    )

    return IngestReport(
        total_kpis=len(kpi_results),
        valid_count=valid_count,
        warning_count=warning_count,
        error_count=error_count,
        global_issues=global_issues,
        kpi_results=kpi_results,
    )


# ================================================================== #
# SQL generation (LLM)
# ================================================================== #
_SQL_GEN_SYSTEM = """You are an expert SQL engineer. Generate a parameterised PostgreSQL SELECT query.

Rules:
- Use only READ operations (SELECT).
- Do NOT filter by date or time — no date columns, no date parameters.
- Use :market, :area, :region as optional named placeholders for geo filtering.
  CRITICAL: always cast them to ::text to avoid asyncpg type-inference errors:
    AND (:market::text IS NULL OR market_col = :market::text)
    AND (:area::text   IS NULL OR area_col   = :area::text)
    AND (:region::text IS NULL OR region_col = :region::text)
  Include only the geo filter(s) relevant to the geography_level of this KPI.
- Include the geo column(s) appropriate for the geography_level in the SELECT and GROUP BY.
- SELECT the kpi_column using the given aggregation_method (AVG, SUM, MAX, MIN, COUNT).
- Alias the aggregated column as "value".
- Include a "site_count" column: COUNT(DISTINCT site_id_column) if a site_id_column is known.
- Use filter_conditions fragment in the WHERE clause if provided (no date conditions).
- Return ONLY the SQL query — no markdown, no explanation, no semicolon at the end.
"""


async def generate_sql_for_kpi(
    kpi: KpiEntry,
    ds_map: dict[str, DataSourceEntry],
    llm_service: Any,
) -> tuple[str | None, str | None]:
    """
    Ask the LLM to generate a SQL query for a KPI.

    Returns (generated_sql, error_message).
    """
    if kpi.custom_sql:
        return kpi.custom_sql, None

    ds = ds_map.get(kpi.source_table or "")

    user_prompt = f"""Generate a PostgreSQL SELECT query for:

KPI Name: {kpi.kpi_name}
Description: {kpi.description or "N/A"}
Source Table: {kpi.source_table}
KPI Column: {kpi.kpi_column}
Aggregation Method: {kpi.aggregation_method}
Geography Level: {kpi.geography_level}
Filter Conditions: {kpi.filter_conditions or "none"}

Table schema hints:
  market_column:  {ds.market_column if ds else "market"}
  area_column:    {ds.area_column if ds else "area"}
  region_column:  {ds.region_column if ds else "region"}
  site_id_column: {ds.site_id_column if ds else "site_id"}

Required SELECT columns at minimum:
  - {ds.market_column if ds and ds.market_column else "market"} (geography identifier at {kpi.geography_level} level)
  - value ({kpi.aggregation_method.upper()}({kpi.kpi_column}))
  - site_count (COUNT of distinct site identifiers)

IMPORTANT: Do NOT include any date or time filtering — no WHERE date_col = ... clauses.
CRITICAL: geo placeholders MUST use ::text casts to avoid asyncpg parameter type errors:
  AND (:market::text IS NULL OR market_col = :market::text)
  AND (:area::text   IS NULL OR area_col   = :area::text)
  AND (:region::text IS NULL OR region_col = :region::text)

Return ONLY the raw SQL query with no explanation or markdown."""

    try:
        from langchain_core.messages import HumanMessage, SystemMessage
        from app.config import get_settings
        settings = get_settings()
        from langchain_openai import ChatOpenAI

        llm = ChatOpenAI(
            api_key="NONE",
            model=settings.llm_model,
            base_url=settings.llm_api_base_url,
            default_headers={
                "api-key": settings.llm_gateway_api_key,
                "workspacename": settings.llm_workspace_name,
            },
            temperature=0.1,
            max_tokens=800,
            timeout=settings.llm_timeout_seconds,
            max_retries=2,
        )
        messages = [
            SystemMessage(content=_SQL_GEN_SYSTEM),
            HumanMessage(content=user_prompt),
        ]
        response = await llm.ainvoke(messages)
        raw = response.content if isinstance(response.content, str) else ""
        sql = _extract_sql(raw)
        if not sql:
            return None, "LLM returned empty SQL."
        if not is_safe_read_query(sql):
            return None, "LLM-generated SQL failed safety check — contains non-SELECT statements."
        return sql, None
    except Exception as exc:
        log.error("SQL generation failed for KPI '%s': %s", kpi.kpi_name, exc)
        return None, f"LLM error: {exc}"


def _extract_sql(raw: str) -> str:
    """Strip markdown fences and extract raw SQL text."""
    # Remove ```sql ... ``` fences
    raw = re.sub(r"```(?:sql)?\s*", "", raw).replace("```", "").strip()
    # Remove trailing semicolon
    return raw.rstrip(";").strip()


def _add_text_casts(sql: str) -> str:
    """
    Ensure every geo named placeholder uses CAST(:param AS TEXT) so asyncpg can
    infer the parameter type when the value is NULL and SQLAlchemy's text()
    parser correctly identifies the named parameter.

    The older `:param::text` PostgreSQL cast syntax is NOT used because
    SQLAlchemy's named-parameter regex applies a negative lookahead that
    prevents it from recognising ':param' when immediately followed by '::'
    (to avoid false-positives on plain PostgreSQL casts).  As a result the
    parameter is never substituted and asyncpg receives the raw ':' character,
    causing a PostgresSyntaxError.

    CAST(:param AS TEXT) avoids this: ':param' is the last token before a space,
    so SQLAlchemy correctly binds it as $N.

    Handles three cases:
      :param           → CAST(:param AS TEXT)   (bare param, no cast)
      :param::text     → CAST(:param AS TEXT)   (old ::text style — normalise)
      CAST(:param AS TEXT) → unchanged           (already correct)
    """
    for param in ("market", "area", "region"):
        # Single-pass: match all three forms and normalise to CAST(:param AS TEXT).
        #   CAST(:param AS TEXT)  → replaced (idempotent)
        #   :param::text          → replaced (legacy form)
        #   :param                → replaced (bare)
        sql = re.sub(
            rf"CAST\(:{param}\s+AS\s+TEXT\)|:{param}(?:::text\b)?",
            f"CAST(:{param} AS TEXT)",
            sql,
            flags=re.IGNORECASE,
        )
    return sql


# ================================================================== #
# SQL test-run
# ================================================================== #
def _substitute_test_literals(sql: str) -> str:
    """
    Replace engine bind-params with safe literals for a validation-only test run.

    SQLAlchemy's text() parser applies a negative lookahead that prevents it from
    recognising ':param' when immediately followed by '::cast' (e.g. ':area::text').
    This means None-valued geo params are never bound and asyncpg receives the raw
    ':' character, causing a PostgresSyntaxError.  Pre-substituting literals before
    execute() sidesteps the issue entirely — we only need to confirm the SQL is
    structurally valid, not produce real data.

    Substitutions:
      :market / :area / :region  → NULL::text   (IS NULL guard → all rows returned)
      :start_date                → '1970-01-01'
      :end_date                  → '2999-12-31'
    """
    # Geo params — handle all three forms: bare, ::text cast, CAST(... AS TEXT).
    for param in ("market", "area", "region"):
        sql = re.sub(rf"CAST\(:{param}\s+AS\s+TEXT\)", "NULL::text", sql, flags=re.IGNORECASE)
        sql = re.sub(rf":{param}\b(?:::text\b)?", "NULL::text", sql)
    sql = re.sub(r":start_date\b", "'1970-01-01'", sql)
    sql = re.sub(r":end_date\b",   "'2999-12-31'", sql)
    return sql


async def test_sql(
    sql: str,
    source_db: AsyncSession,
    limit: int = 5,
) -> tuple[bool, int, str | None]:
    """
    Test-run a SQL query and return (success, row_count, error_message).
    Uses a LIMIT 5 wrapper so we don't fetch production volumes.
    """
    try:
        # Pre-substitute all engine bind-params with safe literals so the query
        # executes without any parameter binding.  This avoids the asyncpg
        # PostgresSyntaxError that occurs when SQLAlchemy fails to convert
        # ':param::text' named params (the '::cast' suffix fools its regex).
        literal_sql = _substitute_test_literals(sql.rstrip(";"))
        wrapped = f"SELECT * FROM ({literal_sql}) _test LIMIT {limit}"
        result = await source_db.execute(text(wrapped))
        rows = result.fetchall()
        return True, len(rows), None
    except Exception as exc:
        try:
            await source_db.rollback()
        except Exception:
            pass
        return False, 0, str(exc)


# ================================================================== #
# Ingest — persist to sql_query_library
# ================================================================== #
async def ingest_kpi(
    kpi: KpiEntry,
    result: KpiValidationResult,
    insights_db: AsyncSession,
) -> str | None:
    """Persist one KpiEntry as a SqlQueryLibrary row. Returns query_id or None."""
    sql = result.generated_sql or kpi.custom_sql
    if not sql:
        return None

    # Build business_context dict
    business_context: dict[str, Any] = {}
    if kpi.kpi_name:
        business_context["kpi_name"] = kpi.display_name or kpi.kpi_name
    if kpi.unit:
        business_context["unit"] = kpi.unit
    if kpi.target is not None:
        business_context["target"] = kpi.target
    if kpi.sla_threshold is not None:
        business_context["sla_threshold"] = kpi.sla_threshold
    if kpi.interpretation:
        business_context["interpretation"] = kpi.interpretation
    business_context["aggregation_rules"] = {kpi.kpi_column: kpi.aggregation_method} if kpi.kpi_column else {}

    def _csv_to_list(s: str | None) -> list[str] | None:
        if not s:
            return None
        return [x.strip() for x in s.split(",") if x.strip()]

    query_id = str(uuid.uuid4())
    row = SqlQueryLibrary(
        query_id=query_id,
        name=kpi.kpi_name,
        query_sql=sql,
        purpose=kpi.purpose or f"Insight for {kpi.display_name or kpi.kpi_name}",
        description=kpi.description,
        geography_level=kpi.geography_level,
        projects=_csv_to_list(kpi.projects),
        functions=_csv_to_list(kpi.functions),
        team=kpi.team,
        tags=_csv_to_list(kpi.tags),
        pm_category=kpi.pm_category,
        prompt_template_id=kpi.prompt_template,
        business_context=business_context or None,
        is_active=True,
        version="1.0",
    )

    try:
        insights_db.add(row)
        await insights_db.flush()
        return query_id
    except Exception as exc:
        log.error("Failed to ingest KPI '%s': %s", kpi.kpi_name, exc)
        await insights_db.rollback()
        return None


# ================================================================== #
# Source DB inspection helpers
# ================================================================== #
async def _get_existing_tables(source_db: AsyncSession) -> set[str]:
    """Return all table/view names in the source DB as 'schema.table' strings."""
    try:
        result = await source_db.execute(text(
            "SELECT table_schema || '.' || table_name AS full_name "
            "FROM information_schema.tables "
            "WHERE table_type IN ('BASE TABLE', 'VIEW') "
            "  AND table_schema NOT IN ('pg_catalog', 'information_schema')"
        ))
        return {row[0].lower() for row in result.fetchall()}
    except Exception as exc:
        log.warning("Could not list source DB tables: %s", exc)
        return set()


async def _column_exists(source_db: AsyncSession, table: str, column: str) -> bool:
    """Check if a column exists in the given table."""
    try:
        parts = table.rsplit(".", 1)
        schema, table_name = (parts[0], parts[1]) if len(parts) == 2 else ("public", parts[0])
        result = await source_db.execute(
            text(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_schema = :schema AND table_name = :tbl AND column_name = :col LIMIT 1"
            ),
            {"schema": schema, "tbl": table_name, "col": column},
        )
        return result.fetchone() is not None
    except Exception:
        return True  # Assume exists if check fails — not a blocker


# ================================================================== #
# YAML sample generator
# ================================================================== #
def generate_yaml_sample() -> bytes:
    """Return a sample YAML template as bytes."""
    sample = {
        "data_sources": [
            {
                "table_name": "pm_data.network_kpis",
                "description": "Daily KPI snapshot per site",
                "market_column": "market",
                "area_column": "area",
                "region_column": "region",
                "site_id_column": "site_id",
            }
        ],
        "kpi_definitions": [
            {
                "kpi_name": "volte_drop_rate",
                "display_name": "VoLTE Drop Rate",
                "description": "% of VoLTE calls that drop in-flight",
                "purpose": "Identifies markets with elevated call quality issues",
                "category": "quality",
                "subcategory": "voice",
                "pm_category": "Quality",
                "projects": "",
                "functions": "RAN",
                "team": "Network Quality",
                "tags": "volte,call-quality",
                "source_table": "pm_data.network_kpis",
                "kpi_column": "volte_drop_rate_pct",
                "filter_conditions": "",
                "geography_level": "market",
                "unit": "%",
                "target": 1.5,
                "sla_threshold": 3.0,
                "interpretation": "Lower is better. Values above 3% indicate a quality problem.",
                "aggregation_method": "avg",
                "prompt_template": "performance_insight",
                "custom_sql": "",
            }
        ],
    }
    return yaml.dump(sample, default_flow_style=False, sort_keys=False).encode("utf-8")
