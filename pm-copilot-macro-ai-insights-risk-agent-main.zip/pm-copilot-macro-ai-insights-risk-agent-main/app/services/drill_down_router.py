"""
Drill-Down Router

After generating insights at a geography level, this service asks the LLM
which child nodes are worth investigating deeper, so the hierarchical engine
only drills into problem areas rather than every node.
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any

from langchain_openai import ChatOpenAI

from app.config import get_settings
from app.models.insights import Insight

log = logging.getLogger(__name__)
settings = get_settings()

_CHILD_LEVEL = {
    "overall": "region",
    "region": "area",
    "area": "market",
    "market": None,
}

_ROUTER_SYSTEM = """\
You are a business intelligence routing agent. Your job is to review insights \
generated at one geography level and decide which child nodes warrant deeper investigation.

Rules:
- Only flag nodes where the data indicates genuine problems (poor performance, risk, anomaly).
- Do not flag nodes just because they exist — only flag those with actionable concerns.
- Be selective: drilling into too many nodes wastes compute. Prefer quality over quantity.
- Return ONLY a valid JSON array of node names from the provided list, e.g.: ["Texas", "Florida"]
- Return [] if no nodes are severe enough to justify deeper investigation.
- Do not return nodes not present in the available list.
"""

_ROUTER_USER = """\
Current geography level  : {current_level}
Current node             : {current_node}
Child level to consider  : {child_level}

INSIGHTS GENERATED AT THIS LEVEL:
{insight_summaries}

AVAILABLE {child_level_upper} NODES (pick from this list only):
{available_children}

Select which {child_level}(s) (up to {max_children}) need deeper investigation based on the insights above.
Return ONLY a JSON array of names from the available list. Return [] if none are needed.
"""


class DrillDownRouter:
    """
    LLM-driven routing: decides which child geography nodes to explore
    after insights have been generated at a parent level.
    """

    def __init__(self) -> None:
        self._llm = ChatOpenAI(
            api_key="NONE",
            model=settings.llm_model,
            base_url=settings.llm_api_base_url,
            default_headers={
                "api-key": settings.llm_gateway_api_key,
                "workspacename": settings.llm_workspace_name,
            },
            temperature=0.0,
            max_tokens=512,
            timeout=settings.llm_timeout_seconds,
            max_retries=0,
        )

    async def decide(
        self,
        *,
        current_level: str,
        current_node: str,
        insights: list[Insight],
        available_children: list[str],
        max_children: int = 3,
        severity_floor: float = 40.0,
    ) -> list[str]:
        """
        Returns the subset of `available_children` that the LLM decides
        should be investigated at the next level down.

        Returns [] if there are no insights, no children, or nothing is
        severe enough (avg severity below `severity_floor`).
        """
        if not insights or not available_children:
            return []

        child_level = _CHILD_LEVEL.get(current_level)
        if not child_level:
            return []

        # Short-circuit: if average severity is below floor, skip drilling
        avg_severity = sum(
            (i.severity_score or 0) for i in insights
        ) / len(insights)
        if avg_severity < severity_floor:
            log.info(
                "DrillDownRouter: skipping drill at %s=%s (avg_severity=%.1f < floor=%.1f)",
                current_level, current_node, avg_severity, severity_floor,
            )
            return []

        summaries = self._format_insight_summaries(insights)
        user_msg = _ROUTER_USER.format(
            current_level=current_level,
            current_node=current_node,
            child_level=child_level,
            child_level_upper=child_level.upper(),
            insight_summaries=summaries,
            available_children="\n".join(f"  - {c}" for c in available_children),
            max_children=max_children,
        )

        from langchain_core.messages import HumanMessage, SystemMessage
        messages = [SystemMessage(content=_ROUTER_SYSTEM), HumanMessage(content=user_msg)]

        try:
            response = await self._llm.ainvoke(messages)
            raw = response.content.strip()
            selected = self._parse_json_array(raw)
            # Enforce that only valid child names are returned
            valid = [c for c in selected if c in available_children]
            # Enforce max_children cap
            valid = valid[:max_children]
            log.info(
                "DrillDownRouter: %s=%s → drill into %d %s(s): %s",
                current_level, current_node, len(valid), child_level, valid,
            )
            return valid
        except Exception as exc:
            log.warning(
                "DrillDownRouter LLM call failed for %s=%s: %s — skipping drill",
                current_level, current_node, exc,
            )
            return []

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def _format_insight_summaries(insights: list[Insight]) -> str:
        lines = []
        for i, ins in enumerate(insights, 1):
            score = f"{ins.severity_score:.0f}" if ins.severity_score is not None else "?"
            lines.append(
                f"{i}. [{score}/100] {ins.title}: {ins.insight[:200]}"
            )
        return "\n".join(lines) if lines else "(no insights)"

    @staticmethod
    def _parse_json_array(raw: str) -> list[str]:
        """Extract a JSON array from LLM response, return [] on failure."""
        # Try direct parse
        try:
            result = json.loads(raw)
            if isinstance(result, list):
                return [str(x) for x in result]
        except json.JSONDecodeError:
            pass
        # Try finding [...] block
        match = re.search(r"\[.*?\]", raw, re.DOTALL)
        if match:
            try:
                result = json.loads(match.group(0))
                if isinstance(result, list):
                    return [str(x) for x in result]
            except json.JSONDecodeError:
                pass
        return []
