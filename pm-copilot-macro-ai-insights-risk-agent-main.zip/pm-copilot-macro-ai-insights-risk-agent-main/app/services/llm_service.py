"""
LLM Service — custom gateway via LangChain ChatOpenAI.

Handles:
  - Prompt construction using SystemMessage / HumanMessage
  - Async invocation of the custom gateway endpoint
  - JSON response parsing and validation
  - Retry logic with exponential back-off
  - Token usage logging
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from app.config import get_settings
from app.schemas.insights import InsightCreate

log = logging.getLogger(__name__)
settings = get_settings()

LLMInsightDict = dict[str, Any]


class LLMServiceError(Exception):
    """Raised when the LLM call fails after all retries."""


class LLMParseError(Exception):
    """Raised when we cannot extract valid JSON from the LLM response."""


class LLMService:
    """
    Wraps LangChain ChatOpenAI pointed at the custom enterprise gateway.

    The gateway expects:
      base_url     → settings.llm_api_base_url
      api-key      → settings.llm_gateway_api_key  (header)
      workspacename→ settings.llm_workspace_name    (header)
    """

    def __init__(self) -> None:
        self._llm = ChatOpenAI(
            api_key="NONE",                    # placeholder — real auth via header
            model=settings.llm_model,
            base_url=settings.llm_api_base_url,
            default_headers={
                "api-key": settings.llm_gateway_api_key,
                "workspacename": settings.llm_workspace_name,
            },
            temperature=settings.llm_temperature,
            max_tokens=settings.llm_max_tokens,
            timeout=settings.llm_timeout_seconds,
            max_retries=0,                     # retries handled by tenacity below
            verbose=False,
        )

    @retry(
        stop=stop_after_attempt(settings.llm_max_retries),
        wait=wait_exponential(multiplier=2, min=2, max=30),
        retry=retry_if_exception_type(Exception),
        reraise=True,
    )
    async def generate_insight(
        self,
        system_prompt: str,
        user_prompt: str,
        *,
        model: str | None = None,
        max_tokens: int | None = None,
        temperature: float | None = None,
    ) -> LLMInsightDict:
        """
        Call the LLM gateway and return the parsed JSON insight dict.

        If `model`, `max_tokens`, or `temperature` are passed they override
        the instance-level defaults for this single call.

        Raises
        ------
        LLMServiceError : gateway call failed after all retries
        LLMParseError   : response did not contain valid JSON
        """
        # Build a per-call client only when overrides are needed
        llm = self._llm
        if model or max_tokens is not None or temperature is not None:
            llm = self._llm.with_config(
                configurable={
                    "model": model or settings.llm_model,
                    "max_tokens": max_tokens or settings.llm_max_tokens,
                    "temperature": temperature if temperature is not None else settings.llm_temperature,
                }
            )

        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt),
        ]

        try:
            log.debug("Calling LLM model=%s", settings.llm_model)
            response = await llm.ainvoke(messages)
        except Exception as exc:
            log.error("LLM gateway error: %s", exc)
            raise LLMServiceError(f"LLM call failed: {exc}") from exc

        # Log token usage when available
        if hasattr(response, "usage_metadata") and response.usage_metadata:
            usage = response.usage_metadata
            log.info(
                "LLM usage — input_tokens=%s output_tokens=%s",
                usage.get("input_tokens", "?"),
                usage.get("output_tokens", "?"),
            )

        raw_text = response.content if isinstance(response.content, str) else ""
        return self._parse_json_response(raw_text)

    # ------------------------------------------------------------------ #
    # Response parsing
    # ------------------------------------------------------------------ #
    def _parse_json_response(self, raw: str) -> LLMInsightDict:
        """
        Extract and validate JSON from the LLM response.

        Handles three formats:
          1. Raw JSON     : { ... }
          2. Fenced block : ```json\\n{ ... }\\n```
          3. Embedded JSON: some text { ... } more text
        """
        raw = raw.strip()

        # 1. Direct parse
        try:
            return self._validate_insight_dict(json.loads(raw))
        except json.JSONDecodeError:
            pass

        # 2. JSON inside markdown fence
        match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", raw, re.DOTALL)
        if match:
            try:
                return self._validate_insight_dict(json.loads(match.group(1)))
            except json.JSONDecodeError:
                pass

        # 3. First { ... } block found anywhere in the string
        match = re.search(r"\{.*\}", raw, re.DOTALL)
        if match:
            try:
                return self._validate_insight_dict(json.loads(match.group(0)))
            except json.JSONDecodeError:
                pass

        log.error("Could not parse JSON from LLM response: %.500s", raw)
        raise LLMParseError(f"Failed to extract JSON from LLM response: {raw[:200]!r}")

    def _validate_insight_dict(self, data: dict) -> LLMInsightDict:
        """Ensure required keys are present; apply defaults for optional ones."""
        if "title" not in data or "insight" not in data:
            raise LLMParseError(f"LLM response missing required keys: {list(data.keys())}")

        data.setdefault("severity_score", 50.0)
        data.setdefault("category", "operational")
        data.setdefault("subcategory", None)
        data.setdefault("type", "alert")
        data.setdefault("site_count", None)
        data.setdefault("tags", [])
        data.setdefault("drill_down_notes", None)
        data.setdefault("insight_detail", None)

        # Cap insight_detail to 8 bullets max
        if isinstance(data.get("insight_detail"), list) and len(data["insight_detail"]) > 8:
            data["insight_detail"] = data["insight_detail"][:8]

        # Clamp severity to [0, 100]
        data["severity_score"] = max(0.0, min(100.0, float(data["severity_score"])))

        return data

    def llm_dict_to_create_schema(
        self, llm_dict: LLMInsightDict, *, overrides: dict[str, Any] | None = None
    ) -> InsightCreate:
        """Convert parsed LLM dict into an InsightCreate Pydantic model."""
        payload = {
            "title": llm_dict["title"],
            "insight": llm_dict["insight"],
            "insight_detail": llm_dict.get("insight_detail"),
            "severity_score": llm_dict.get("severity_score"),
            "category": llm_dict.get("category"),
            "subcategory": llm_dict.get("subcategory"),
            "type": llm_dict.get("type"),
            "site_count": llm_dict.get("site_count"),
            "tags": llm_dict.get("tags") or [],
        }
        if overrides:
            payload.update(overrides)
        return InsightCreate(**payload)
