"""
Insight Generator Service

Orchestrates the core pipeline for a single (query, geo_params) pair:
  1. Execute SQL against source DB
  2. Build prompt via PromptBuilder
  3. Call LLM for insight text
  4. Parse LLM response → InsightCreate
  5. Persist insight + embedding to insights DB
"""
from __future__ import annotations

import logging
import math
import re
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from typing import Any
from uuid import UUID

from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.models.insights import Insight
from app.models.query_library import SqlQueryLibrary
from app.schemas.insights import InsightCreate
from app.services.embedding_service import EmbeddingService
from app.services.llm_service import LLMService, LLMParseError, LLMServiceError
from app.services.sql_executor import SqlExecutor, SqlExecutionError
from app.utils.filters import GeoParams
from app.utils.prompt_library import BASE_SYSTEM_PROMPT, BUILT_IN_TEMPLATES, prompt_builder

log = logging.getLogger(__name__)
settings = get_settings()

# Geography hierarchy — maps parent level to the child column to aggregate by.
# SQL generation prompt requires these exact column aliases in the SELECT clause.
_CHILD_COL: dict[str, str | None] = {
    "overall": "region",
    "region":  "area",
    "area":    "market",
    "market":  None,   # site-level already — no further aggregation needed
}


def _resolve_geo_column(target: str, columns: list[str]) -> str | None:
    """
    Find the actual column name that represents a geography level.

    Checks (in order):
      1. Exact match (``market``)
      2. Case-insensitive exact match (``Market``, ``AREA``)
      3. Suffix match: column ends with ``_<target>`` (``m_market``, ``rgn_region``)
    Returns None if no match is found.
    """
    if target in columns:
        return target
    target_lower = target.lower()
    for col in columns:
        col_lower = col.lower()
        if col_lower == target_lower:
            return col
    for col in columns:
        col_lower = col.lower()
        if col_lower.endswith(f"_{target_lower}") or col_lower.endswith(f"_{target_lower}s"):
            return col
    return None


def _make_json_safe(obj: Any) -> Any:
    """
    Recursively coerce non-JSON-serializable types produced by the DB driver.

    PostgreSQL drivers (asyncpg / psycopg) return:
      - NUMERIC/DECIMAL  → Python Decimal
      - INTERVAL         → Python timedelta
      - DATE/TIMESTAMP   → datetime / date
      - UUID columns     → uuid.UUID

    PostgreSQL's JSONB codec will raise TypeError for any of these, so we
    convert them to their nearest JSON-native equivalents before storing.
    """
    if isinstance(obj, list):
        return [_make_json_safe(v) for v in obj]
    if isinstance(obj, dict):
        return {k: _make_json_safe(v) for k, v in obj.items()}
    if isinstance(obj, Decimal):
        # Preserve integer appearance where possible; fall back to float.
        f = float(obj)
        return int(f) if f == int(f) and not math.isinf(f) else f
    if isinstance(obj, timedelta):
        return obj.total_seconds()
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    if isinstance(obj, UUID):
        return str(obj)
    # bytes, memoryview, etc. — best-effort string conversion
    if isinstance(obj, (bytes, bytearray, memoryview)):
        return obj.hex() if isinstance(obj, (bytes, bytearray)) else bytes(obj).hex()
    return obj


def _extract_site_ids(rows: list[dict[str, Any]]) -> list[str]:
    """
    Pull site/project identifiers from drill-down rows.

    Checks columns in priority order — exact names first, then a fuzzy scan
    for vendor-like columns (vendor, gc, general_contractor, construction_gc)
    which are treated as entity identifiers when no site column exists.

    Returns a deduplicated, ordered list of string IDs.
    """
    # Priority 1: site / project identifiers (project_id ≡ site_id)
    _SITE_COLS = (
        "site", "site_id", "project_id",
        "element", "element_id", "node", "node_id",
    )
    # Priority 2: vendor / contractor identifiers
    _VENDOR_KEYWORDS = ("vendor", "gc", "general_contractor", "construction_gc")

    if not rows:
        return []

    columns = list(rows[0].keys())

    # Exact match on site-like columns
    col = next((c for c in _SITE_COLS if c in columns), None)

    # Fuzzy match: check if any column name contains a vendor keyword
    if not col:
        col_lower_map = {c.lower(): c for c in columns}
        for kw in _VENDOR_KEYWORDS:
            for cl, original in col_lower_map.items():
                if kw == cl or kw in cl:
                    col = original
                    break
            if col:
                break

    if not col:
        return []

    seen: set[str] = set()
    ids: list[str] = []
    for r in rows:
        v = r.get(col)
        if v is not None:
            s = str(v)
            if s not in seen:
                seen.add(s)
                ids.append(s)
    return ids


def _extract_timeframe(sql: str) -> str | None:
    """
    Extract a human-readable timeframe from hardcoded INTERVAL clauses in SQL.

    Looks for patterns like ``CURRENT_DATE - INTERVAL '3 months'`` and returns
    a string like "last 3 months".  Returns None if no interval is found.
    """
    match = re.search(
        r"CURRENT_DATE\s*-\s*INTERVAL\s*'(\d+\s*\w+)'",
        sql,
        re.IGNORECASE,
    )
    if match:
        return f"last {match.group(1).strip()}"
    return None


class InsightGenerationError(Exception):
    """Raised when insight generation fails for a single item."""


class InsightGenerator:
    """
    Generates one insight from one SQL query + geography parameter set.

    Instantiate once and call `generate()` in a loop / batch.
    """

    def __init__(
        self,
        llm_service: LLMService | None = None,
        embedding_service: EmbeddingService | None = None,
        sql_executor: SqlExecutor | None = None,
    ) -> None:
        self.llm = llm_service or LLMService()
        self.embeddings = embedding_service or EmbeddingService()
        self.executor = sql_executor or SqlExecutor()

    async def generate_all_areas(
        self,
        *,
        query: SqlQueryLibrary,
        geo: GeoParams,
        start_date: str,
        end_date: str,
        insights_db: AsyncSession,
        source_db: AsyncSession,
        job_id: str | None = None,
        vendor_grouping: bool = False,
    ) -> list[Insight]:
        """
        Generate insights for ALL insight_areas defined on the query.

        If query.insight_areas is empty/None, falls back to a single generate() call.
        Returns a list of persisted Insights (may be empty if all skipped).
        """
        areas = query.insight_areas or [None]
        results: list[Insight] = []
        covered: list[str] = []

        for area in areas:
            insight = await self.generate(
                query=query,
                geo=geo,
                start_date=start_date,
                end_date=end_date,
                insights_db=insights_db,
                source_db=source_db,
                job_id=job_id,
                insight_area=area,
                already_covered_areas=covered.copy(),
                vendor_grouping=vendor_grouping,
            )
            if insight:
                results.append(insight)
                if area:
                    covered.append(area)

        return results

    async def generate(
        self,
        *,
        query: SqlQueryLibrary,
        geo: GeoParams,
        start_date: str,
        end_date: str,
        insights_db: AsyncSession,
        source_db: AsyncSession,
        job_id: str | None = None,
        insight_area: str | None = None,
        already_covered_areas: list[str] | None = None,
        vendor_grouping: bool = False,
    ) -> Insight | None:
        """
        Run the full pipeline for one query × geography combination.

        Returns the persisted Insight or None if skipped.
        Raises InsightGenerationError on unrecoverable failures.
        """
        geo_label = geo.label()
        area_suffix = f" area={insight_area!r}" if insight_area else ""
        log.info(
            "Generating insight — query=%s geo=%s dates=%s→%s%s",
            query.name,
            geo_label,
            start_date,
            end_date,
            area_suffix,
        )

        # ---- Step 1: Execute SQL ---- #
        sql_params: dict[str, Any] = {
            **geo.as_sql_params(),
            "start_date": start_date,
            "end_date": end_date,
        }

        # Warn when the query doesn't reference geo params that are set —
        # this means results won't be scoped to the current geography node.
        _geo_keys = ("region", "area", "market")
        missing_filters = [
            k for k in _geo_keys
            if sql_params.get(k) is not None and f":{k}" not in query.query_sql
        ]
        if missing_filters:
            log.warning(
                "Query %r does not reference geo params %s — results will NOT "
                "be filtered to %s. The query must include null-safe filters: "
                "(CAST(:param AS TEXT) IS NULL OR LOWER(col) = LOWER(:param))",
                query.name, missing_filters, geo_label,
            )

        try:
            # Fetch ALL rows for accurate aggregation and site counts.
            # The row_limit only controls the SQL-level cap if explicitly set;
            # otherwise fetch everything (max_rows=None).
            max_rows = query.row_limit if query.row_limit else None
            raw_rows = await self.executor.execute(
                source_db, query.query_sql, sql_params, max_rows=max_rows
            )
        except SqlExecutionError as exc:
            raise InsightGenerationError(f"SQL execution failed: {exc}") from exc

        if not raw_rows:
            log.info("Query %s returned no rows for %s — skipping", query.name, geo_label)
            return None

        total_raw_site_count = len(raw_rows)

        # ---- Step 1b: Aggregate to child level ---- #
        # SQL returns site-level rows with all geo columns.
        # Aggregation uses the FULL dataset for accuracy (no row cap).
        #   overall → aggregate by region   (LLM sees regional summaries)
        #   region  → aggregate by area     (LLM sees areas within the region)
        #   area    → aggregate by market   (LLM sees markets within the area)
        #   market  → no aggregation        (LLM sees individual sites)
        # Only apply vendor/group_by_column when explicitly requested via
        # the vendor_grouping flag.  The query library stores the column name
        # so we know *which* column to group by, but the caller decides
        # *whether* to activate it.
        effective_group_col = (query.group_by_column or None) if vendor_grouping else None
        rows, aggregation_note = self._aggregate_to_child_level(
            raw_rows, geo.level, query.business_context or {},
            group_by_column=effective_group_col,
        )

        # All aggregated rows are sent to the LLM — no cap.  The aggregation
        # step already collapses site-level data to geography groups, keeping
        # the row count manageable.

        # ---- Step 1c: Check for recurring issue ---- #
        # If the same (query, geo) pair produced an insight in a prior job,
        # increment the occurrence counter and add the "recurring-issue" tag.
        consecutive = await self._get_consecutive_occurrences(
            insights_db, str(query.query_id), geo
        )

        # ---- Step 2: Build prompts ---- #
        # Extract the hardcoded time window from the SQL so the LLM knows
        # exactly which period the data covers (e.g. "last 3 months").
        sql_timeframe = _extract_timeframe(query.query_sql)

        results_text = prompt_builder.format_query_results(rows)
        system_prompt, user_prompt = prompt_builder.build(
            template_name=query.prompt_template_id or "performance_insight",
            purpose=query.purpose or "",
            description=query.description or "",
            geography=geo_label,
            start_date=start_date,
            end_date=end_date,
            query_results=results_text,
            extra_context={
                "aggregation_note": aggregation_note,
                "business_context": query.business_context or {},
            },
        )

        # Inject area-specific focus into the user prompt
        if insight_area:
            area_instruction = (
                f"\n\n## Analysis Focus Area\n"
                f"Focus your analysis EXCLUSIVELY on: **{insight_area}**.\n"
                f"Only discuss metrics, patterns, and findings directly related to "
                f"this area. Ignore other aspects of the data even if they are notable."
            )

            # Map relevant KPIs to this area so the LLM knows which metrics matter
            bc = query.business_context or {}
            kpis = bc.get("kpis") or []
            if kpis:
                area_lower = insight_area.lower()
                relevant = []
                for kpi in kpis:
                    kpi_name = (kpi.get("kpi_name") or kpi.get("column") or "").lower()
                    interp = (kpi.get("interpretation") or "").lower()
                    # Match if the KPI name/column/interpretation overlaps with the area name
                    # or if the area name contains part of the KPI name
                    if (any(word in area_lower for word in kpi_name.split() if len(word) > 3)
                            or any(word in kpi_name for word in area_lower.split() if len(word) > 3)
                            or any(word in interp for word in area_lower.split() if len(word) > 3)):
                        relevant.append(kpi.get("kpi_name") or kpi.get("column", "?"))
                if relevant:
                    area_instruction += (
                        f"\n\nRelevant KPIs for this area: {', '.join(relevant)}. "
                        f"Prioritise these metrics in your analysis."
                    )
                else:
                    # No fuzzy match — list all KPIs so the LLM can choose
                    all_kpi_names = [kpi.get("kpi_name") or kpi.get("column", "?") for kpi in kpis]
                    area_instruction += (
                        f"\n\nAvailable KPIs: {', '.join(all_kpi_names)}. "
                        f"Use only those relevant to \"{insight_area}\"."
                    )

            if already_covered_areas:
                covered_list = ", ".join(f'"{a}"' for a in already_covered_areas)
                area_instruction += (
                    f"\n\nThe following areas have already been covered by other insights "
                    f"— do NOT repeat any findings from these: {covered_list}.\n"
                    f"Your analysis must be completely distinct from those areas."
                )
            user_prompt += area_instruction

        # Inject timeframe context so the LLM references the actual period
        if sql_timeframe:
            user_prompt += (
                f"\n\n## Data Timeframe\n"
                f"This data covers the **{sql_timeframe}** "
                f"(relative to today). Mention this in insight_detail, "
                f"not as the opening of the insight text."
            )

        # Inject total site count so the LLM uses accurate numbers
        user_prompt += (
            f"\n\n## Site Count\n"
            f"Total sites/records in scope: **{total_raw_site_count}**. "
            f"Use this exact number when referencing the total count of sites "
            f"or records analysed. Do not estimate or infer a different count."
        )

        # ---- Step 3: Call LLM ---- #
        try:
            llm_dict = await self.llm.generate_insight(system_prompt, user_prompt)
        except (LLMServiceError, LLMParseError) as exc:
            raise InsightGenerationError(f"LLM generation failed: {exc}") from exc

        # ---- Step 4: Build InsightCreate schema ---- #
        # Auto-tag recurring issues so they surface in the feed.
        base_tags: list[str] = list(llm_dict.get("tags") or [])
        if consecutive >= 2 and "recurring-issue" not in base_tags:
            base_tags.append("recurring-issue")
        llm_dict["tags"] = base_tags

        overrides: dict[str, Any] = {
            "market": geo.market,
            "region": geo.region,
            "area": geo.area,
            "query_id": str(query.query_id),
            "prompt_template_id": query.prompt_template_id,
            "llm_model": settings.llm_model,
            "job_id": job_id,
            "projects": query.projects if query.projects else None,
            "functions": query.functions if query.functions else None,
            "expires_at": datetime.now(timezone.utc) + timedelta(days=settings.insight_expiry_days),
            # Pack + geo metadata — populated when the query is part of a pack.
            "pack_id": query.pack_id,
            "geo_level": geo.level,     # 'overall' | 'region' | 'area' | 'market'
            "insight_area": insight_area,  # which analysis area this insight covers (None = single)
            "is_pack_summary": False,   # elected by InsightAgent._score_packs() after batch
            # Snapshot the aggregated rows that were shown to the LLM so the
            # drill-down view can render instantly without hitting the source DB.
            # Coerce any non-JSON-serializable types (Decimal, date, UUID…) first.
            "source_data": _make_json_safe(rows),
            # site_count defaults to the total raw rows from the query.
            # Step 5b may overwrite site_ids and site_count from drill-down
            # results (which reflect only problematic entities).
            "site_ids": None,
            "site_count": total_raw_site_count,
            # Recurrence tracking.
            "consecutive_occurrences": consecutive,
            # Debug context — what the LLM saw and returned.
            "generation_context": {
                "system_prompt": system_prompt,
                "user_prompt": user_prompt,
                "data_row_count": len(rows),
                "data_rows_sample": _make_json_safe(rows[:20]),
                "llm_raw_response": llm_dict,
                "sql_params": _make_json_safe(sql_params),
                "query_sql": query.query_sql,
                "aggregation_note": aggregation_note,
                "insight_area": insight_area,
                "already_covered_areas": already_covered_areas,
            },
        }
        create_schema = self.llm.llm_dict_to_create_schema(llm_dict, overrides=overrides)

        # ---- Step 5: Persist insight ---- #
        insight = await self._persist_insight(insights_db, create_schema)
        # Commit the insight immediately so a subsequent embedding failure
        # cannot roll it back (embedding is non-fatal and stored separately).
        await insights_db.commit()
        log.info("Insight created: id=%s title=%r", insight.insight_id, insight.title)

        # ---- Step 5b: Generate drill-down SQL via LLM, test, retry ---- #
        # Ask the LLM to produce a site-level query that surfaces the
        # problematic entities a PM should investigate.  If execution fails,
        # send the error back to the LLM for a corrected query (up to 2 retries).
        # Non-fatal — if all attempts fail the insight is still valid.
        _MAX_DRILL_ATTEMPTS = 3
        drill_sql: str | None = None
        dd_site_ids: list[str] = []
        dd_rows: list[dict[str, Any]] = []
        last_error: str | None = None

        for attempt in range(1, _MAX_DRILL_ATTEMPTS + 1):
            drill_sql = await self._generate_drill_down_sql(
                query=query,
                geo=geo,
                start_date=start_date,
                end_date=end_date,
                insight=insight,
                previous_sql=drill_sql if last_error else None,
                execution_error=last_error,
            )
            if not drill_sql:
                log.warning(
                    "Drill-down SQL generation returned nothing (attempt %d/%d)",
                    attempt, _MAX_DRILL_ATTEMPTS,
                )
                break

            dd_site_ids, dd_rows, exec_error = await self._execute_drill_down(
                source_db, drill_sql,
            )

            if exec_error:
                # Execution failed — feed error back to LLM for retry
                last_error = exec_error
                log.warning(
                    "Drill-down SQL execution failed (attempt %d/%d): %s",
                    attempt, _MAX_DRILL_ATTEMPTS, exec_error,
                )
                continue

            # Execution succeeded — store results regardless of site_id extraction
            insight.drill_down_sql = drill_sql
            insight.drill_down_data = dd_rows if dd_rows else None
            if dd_site_ids:
                insight.site_ids = dd_site_ids
                insight.site_count = len(dd_site_ids)
            else:
                insight.site_ids = None
                insight.site_count = len(dd_rows) if dd_rows else None
            await insights_db.commit()

            if dd_rows:
                log.info(
                    "Drill-down stored for insight %s — %d rows, %d site_ids (attempt %d)",
                    insight.insight_id, len(dd_rows), len(dd_site_ids), attempt,
                )
            else:
                log.warning(
                    "Drill-down SQL returned 0 rows (attempt %d/%d)",
                    attempt, _MAX_DRILL_ATTEMPTS,
                )
            break
        else:
            # All attempts exhausted with execution errors
            if drill_sql:
                insight.drill_down_sql = drill_sql
                insight.site_ids = None
                insight.site_count = None
                insight.drill_down_data = None
                await insights_db.commit()
                log.warning(
                    "Drill-down SQL stored for insight %s after %d failed attempts",
                    insight.insight_id, _MAX_DRILL_ATTEMPTS,
                )

        # ---- Step 6: Generate & store embedding ---- #
        embedding_text = EmbeddingService.build_embedding_text(
            insight.title, insight.insight, insight.tags
        )
        try:
            await self.embeddings.embed_and_store(insights_db, insight.insight_id, embedding_text)
            await insights_db.commit()
        except Exception as exc:
            # Non-fatal: log and roll back only the embedding write.
            log.warning("Embedding generation failed for insight %s: %s", insight.insight_id, exc)
            try:
                await insights_db.rollback()
            except Exception:
                pass

        return insight

    # ------------------------------------------------------------------ #
    # Private helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    def _aggregate_to_child_level(
        rows: list[dict[str, Any]],
        parent_level: str,
        business_context: dict[str, Any] | None = None,
        group_by_column: str | None = None,
    ) -> tuple[list[dict[str, Any]], str]:
        """
        Aggregate site-level SQL results to the child geography level.

        When ``group_by_column`` is set (e.g. vendor/company), rows are grouped
        by ``(geo, group_by_column)`` so the LLM can compare across vendors
        within each geography.

        Returns (aggregated_rows, aggregation_note) where aggregation_note
        is a human-readable string passed to the LLM prompt describing what
        each row represents.

        Numeric columns are split into _avg, _sum, _min, _max aggregates.
        Non-numeric columns that are constant within a group are preserved as-is.

        If the child column is not present in the results (table uses a
        different alias) the raw rows are returned unchanged with a warning note.
        """
        from collections import defaultdict

        child_col = _CHILD_COL.get(parent_level)

        if child_col is None:
            # market level — no aggregation, site rows are already finest grain
            return rows, "Each row represents one site/element."

        if not rows:
            return rows, "No rows to aggregate."

        # Resolve the actual column name — look for exact match first, then
        # common alias patterns (e.g. m_market, rgn_region, mkt_market).
        actual_child_col = _resolve_geo_column(child_col, list(rows[0].keys()))
        if actual_child_col is None:
            log.warning(
                "_aggregate_to_child_level: child column '%s' not found in results "
                "(columns: %s). Returning raw rows. Ensure SQL aliases geo columns as "
                "region/area/market/site or uses a recognisable prefix.",
                child_col, list(rows[0].keys()),
            )
            note = (
                f"Note: could not aggregate by {child_col} — column not in query results. "
                "Each row may represent a site-level record."
            )
            return rows, note
        child_col = actual_child_col

        # Resolve the optional secondary group-by column (e.g. vendor)
        actual_group_col: str | None = None
        if group_by_column and rows:
            actual_group_col = _resolve_geo_column(group_by_column, list(rows[0].keys()))
            if actual_group_col is None:
                # Try case-insensitive exact match (already handled by resolver)
                # and direct presence check
                if group_by_column in rows[0]:
                    actual_group_col = group_by_column
                else:
                    log.warning(
                        "_aggregate_to_child_level: group_by_column '%s' not found "
                        "in results (columns: %s). Ignoring vendor grouping.",
                        group_by_column, list(rows[0].keys()),
                    )

        # Group rows by (child_col, group_by_col) or just child_col
        groups: dict[str, list[dict]] = defaultdict(list)
        for row in rows:
            geo_key = str(row.get(child_col) or "Unknown")
            if actual_group_col:
                vendor_key = str(row.get(actual_group_col) or "Unknown")
                key = f"{geo_key}||{vendor_key}"
            else:
                key = geo_key
            groups[key].append(row)

        # Explicit aggregation rules from business_context override name heuristics.
        # New format: business_context.kpis[] with per-metric "column" + "aggregation"
        # Legacy format: business_context.aggregation_rules dict {col: method}
        explicit_rules: dict[str, str] = {}
        if business_context:
            kpis_list = business_context.get("kpis")
            if kpis_list and isinstance(kpis_list, list):
                for kpi in kpis_list:
                    col = kpi.get("column", "").lower()
                    agg = kpi.get("aggregation", "avg").lower()
                    if col:
                        explicit_rules[col] = agg
            else:
                explicit_rules = {
                    k.lower(): v.lower()
                    for k, v in (business_context.get("aggregation_rules") or {}).items()
                }

        # Classify columns once using the first row as a schema sample
        _GEO_COLS = {child_col, "region", "area", "market", "site", "site_id"}
        if actual_group_col:
            _GEO_COLS.add(actual_group_col)
        # Identifier suffixes — these columns have high cardinality and their
        # percentage breakdowns are noise (e.g. "site ABC: 0.3%, site DEF: 0.2%").
        _ID_SUFFIXES = (
            "_id", "_key", "_uuid", "_code", "_hash",
            "_name", "_label", "_identifier",
        )
        _ID_EXACT = {
            "id", "uuid", "name", "element", "node", "enodeb", "gnodeb",
            "cell", "sector", "smp", "ne", "equipment",
        }
        sample = rows[0]
        numeric_cols = [
            col for col, val in sample.items()
            if col not in _GEO_COLS and isinstance(val, (int, float))
        ]
        text_cols = [
            col for col, val in sample.items()
            if col not in _GEO_COLS and not isinstance(val, (int, float))
        ]

        aggregated: list[dict[str, Any]] = []
        for key in sorted(groups.keys()):
            group_rows = groups[key]
            if actual_group_col:
                geo_key, vendor_key = key.split("||", 1)
                agg: dict[str, Any] = {
                    child_col: geo_key,
                    actual_group_col: vendor_key,
                    "site_count": len(group_rows),
                }
            else:
                agg: dict[str, Any] = {child_col: key, "site_count": len(group_rows)}

            # Numeric columns — primary value + range for context.
            # Explicit business_context rules take priority, then name heuristics,
            # then default to sum for count-like columns, avg for rate-like columns.
            #
            # Heuristic: columns that represent countable quantities (tickets,
            # sites, events, items) must be SUMMED — averaging a count across
            # groups produces meaningless numbers.  Columns that represent
            # rates / percentages / averages should be averaged.
            _SUM_SUFFIXES = ("_count", "_total", "_num", "_sum", "_volume", "_events",
                             "_quantity", "_qty", "_tickets", "_items", "_sites")
            _SUM_PREFIXES = ("count_", "total_", "num_", "sum_", "n_", "cnt_")
            _SUM_EXACT = {"count", "total", "num", "quantity", "qty", "volume",
                          "events", "tickets", "items", "sites", "records"}
            _RATE_KEYWORDS = ("rate", "pct", "percent", "ratio", "avg", "average",
                              "mean", "score", "index", "efficiency",
                              "utilization", "throughput", "density", "coverage",
                              "headroom", "adherence", "completion", "accuracy")
            _MAX_SUFFIXES = ("_max", "_worst", "_peak")
            _MIN_SUFFIXES = ("_min", "_best", "_floor")

            def _should_sum(col_name: str) -> bool:
                """Return True if the column represents a countable quantity."""
                cl = col_name.lower()
                if cl in _SUM_EXACT:
                    return True
                if any(cl.endswith(s) for s in _SUM_SUFFIXES):
                    return True
                if any(cl.startswith(s) for s in _SUM_PREFIXES):
                    return True
                return False

            def _is_rate(col_name: str) -> bool:
                """Return True if the column looks like a rate/percentage."""
                cl = col_name.lower()
                return any(kw in cl for kw in _RATE_KEYWORDS)

            for col in numeric_cols:
                vals = [
                    float(r[col]) for r in group_rows
                    if r.get(col) is not None
                ]
                if not vals:
                    continue
                col_l = col.lower()
                sum_val = round(sum(vals), 2)
                avg_val = round(sum_val / len(vals), 2)
                min_val = round(min(vals), 2)
                max_val = round(max(vals), 2)

                # 1. Explicit rule from business_context
                if col_l in explicit_rules:
                    rule = explicit_rules[col_l]
                    if rule == "sum":
                        agg[col] = sum_val
                    elif rule == "max":
                        agg[col] = max_val
                    elif rule == "min":
                        agg[col] = min_val
                    else:
                        agg[col] = avg_val
                    # Always add range for explicit rules too
                    if len(vals) > 1 and min_val != max_val and rule != "sum":
                        agg[f"{col}_range"] = f"{min_val}–{max_val}"
                # 2. Name-suffix/prefix/exact heuristics
                elif _should_sum(col):
                    agg[col] = sum_val
                elif any(col_l.endswith(s) for s in _MAX_SUFFIXES):
                    agg[col] = max_val
                elif any(col_l.endswith(s) for s in _MIN_SUFFIXES):
                    agg[col] = min_val
                elif _is_rate(col):
                    # Rates/percentages → average with range
                    agg[col] = avg_val
                    if len(vals) > 1 and min_val != max_val:
                        agg[f"{col}_range"] = f"{min_val}–{max_val}"
                else:
                    # Default: SUM for unrecognised numeric columns.
                    # Summing is the safer default for aggregation — averaging
                    # a count produces nonsense, while summing a rate is at
                    # least visibly wrong and gets caught.
                    agg[col] = sum_val

            # Categorical columns — keep only low-cardinality values that are
            # constant or near-constant within a group. Drop percentage breakdowns
            # as they confuse the LLM into treating them as KPI values.
            from collections import Counter
            for col in text_cols:
                col_l = col.lower()
                # Skip identifier columns
                if col_l in _ID_EXACT or any(col_l.endswith(s) for s in _ID_SUFFIXES):
                    continue
                vals = [str(r.get(col)) for r in group_rows if r.get(col) is not None]
                if not vals:
                    continue
                counts = Counter(vals)
                # High cardinality → skip (likely an identifier)
                if len(counts) > 20 and len(counts) > len(vals) * 0.8:
                    continue
                if len(counts) == 1:
                    agg[col] = vals[0]
                elif len(counts) <= 3:
                    # Very few distinct values → show the dominant one
                    dominant, _ = counts.most_common(1)[0]
                    agg[col] = dominant
                # else: too many categories — omit to avoid noise

            aggregated.append(agg)

        # ---- Build KPI lookup for problem detection ---- #
        kpi_lookup: dict[str, dict] = {}
        if business_context:
            for kpi in (business_context.get("kpis") or []):
                col = (kpi.get("column") or "").lower()
                if col:
                    kpi_lookup[col] = {
                        "target": kpi.get("target"),
                        "sla_threshold": kpi.get("sla_threshold"),
                        "lower_is_better": kpi.get("lower_is_better", False),
                        "kpi_name": kpi.get("kpi_name") or col,
                        "unit": kpi.get("unit", ""),
                    }

        # ---- Flag problem groups based on KPI thresholds ---- #
        def _breaches_threshold(value: float, kpi_info: dict) -> bool:
            """Check if a value breaches either target or SLA threshold."""
            lib = kpi_info.get("lower_is_better", False)
            target = kpi_info.get("target")
            sla = kpi_info.get("sla_threshold")
            if lib:
                # Lower is better: breach if value EXCEEDS threshold
                if sla is not None and value > float(sla):
                    return True
                if target is not None and value > float(target):
                    return True
            else:
                # Higher is better: breach if value FALLS BELOW threshold
                if sla is not None and value < float(sla):
                    return True
                if target is not None and value < float(target):
                    return True
            return False

        # Check each aggregated row for threshold breaches and add problem_flag
        for agg_row in aggregated:
            flagged = False
            for col in numeric_cols:
                col_l = col.lower()
                if col_l in kpi_lookup and col in agg_row:
                    if _breaches_threshold(float(agg_row[col]), kpi_lookup[col_l]):
                        flagged = True
                        break
            agg_row["problem_flag"] = flagged

        # ---- Build the aggregation note ---- #
        child_label = child_col.capitalize()
        if actual_group_col:
            group_label = actual_group_col.replace("_", " ").title()
            note = (
                f"Data is aggregated by {child_label} and {group_label}. "
                f"Each row = one {child_label} × {group_label} combination. "
                f"'site_count' = number of sites in that group. "
                f"Compare vendors/GCs within the same {child_label} to identify "
                f"underperformers — each vendor's metrics are separate. "
                f"Count-like columns (count, total, num, qty, etc.) are summed. "
                f"Rate/percentage columns are averaged. "
                f"Columns ending '_range' show the min–max spread within that group. "
                f"'problem_flag' = True when the group breaches a KPI target or SLA."
            )
        else:
            note = (
                f"Data is aggregated by {child_label}. "
                f"Each row = one {child_label}. "
                f"'site_count' = number of sites in that {child_label}. "
                f"No vendor/contractor breakdown is applied — metrics represent "
                f"the combined performance of all vendors in each {child_label}. "
                f"Count-like columns (count, total, num, qty, etc.) are summed. "
                f"Rate/percentage columns are averaged. "
                f"Columns ending '_range' show the min–max spread within that group. "
                f"'problem_flag' = True when the group breaches a KPI target or SLA."
            )

        # Append KPI thresholds so the LLM knows what good/bad looks like
        if kpi_lookup:
            threshold_lines = ["\n\nKPI Thresholds:"]
            for col_l, info in kpi_lookup.items():
                parts = [info.get("kpi_name", col_l)]
                unit = info.get("unit", "")
                direction = "lower is better" if info.get("lower_is_better") else "higher is better"
                parts.append(f"({direction})")
                if info.get("target") is not None:
                    op = "≤" if info.get("lower_is_better") else "≥"
                    parts.append(f"target {op} {info['target']}{unit}")
                if info.get("sla_threshold") is not None:
                    op = "≤" if info.get("lower_is_better") else "≥"
                    parts.append(f"SLA {op} {info['sla_threshold']}{unit}")
                threshold_lines.append(f"- {' | '.join(parts)}")
            note += "\n".join(threshold_lines)

        log.info(
            "_aggregate_to_child_level: %s → %d %s groups (from %d raw rows)%s",
            parent_level, len(aggregated), child_col, len(rows),
            f" (grouped by {actual_group_col})" if actual_group_col else "",
        )
        return aggregated, note

    async def _get_consecutive_occurrences(
        self,
        db: AsyncSession,
        query_id: str,
        geo: GeoParams,
    ) -> int:
        """
        Return the consecutive_occurrences count from the most recent prior insight
        for this (query_id, geo_level, region, area, market) combination.

        Returns 1 if no prior insight exists (this is the first occurrence),
        or prior.consecutive_occurrences + 1 if one is found.
        """
        stmt = (
            select(Insight.consecutive_occurrences)
            .where(
                and_(
                    Insight.query_id == query_id,
                    Insight.geo_level == geo.level,
                    Insight.region == geo.region,
                    Insight.area == geo.area,
                    Insight.market == geo.market,
                    Insight.is_active.is_(True),
                )
            )
            .order_by(Insight.created_at.desc())
            .limit(1)
        )
        result = await db.execute(stmt)
        prior = result.scalar_one_or_none()
        return (prior or 0) + 1

    async def _generate_drill_down_sql(
        self,
        *,
        query: SqlQueryLibrary,
        geo: GeoParams,
        start_date: str,
        end_date: str,
        insight: Insight,
        previous_sql: str | None = None,
        execution_error: str | None = None,
    ) -> str | None:
        """
        Ask the LLM to produce an entity-level drill-down SQL based on the
        original analysis query and the insight it just generated.

        On retry (when ``previous_sql`` and ``execution_error`` are provided),
        the failing SQL and error message are included so the LLM can fix the
        query.

        Returns the raw SQL string or None if generation fails (non-fatal).
        """
        from string import Template as StrTemplate

        sql_params_text = (
            f"region={geo.region or 'NULL'}, area={geo.area or 'NULL'}, "
            f"market={geo.market or 'NULL'}, "
            f"start_date={start_date}, end_date={end_date}"
        )

        # Build problem criteria from business_context KPI thresholds
        criteria_lines: list[str] = []
        bc = query.business_context or {}
        for kpi in (bc.get("kpis") or []):
            col = kpi.get("column")
            target = kpi.get("target")
            sla = kpi.get("sla_threshold")
            lib = kpi.get("lower_is_better", False)
            if col and (target is not None or sla is not None):
                parts: list[str] = []
                if target is not None:
                    op = ">" if lib else "<"
                    parts.append(f"problem when {col} {op} {target}")
                if sla is not None:
                    op = ">" if lib else "<"
                    parts.append(f"SLA breach when {col} {op} {sla}")
                unit = kpi.get("unit", "")
                criteria_lines.append(f"- {col}{f' ({unit})' if unit else ''}: {', '.join(parts)}")

        problem_criteria = "\n".join(criteria_lines) if criteria_lines else (
            "(No explicit thresholds defined — return the bottom/top 20% performers "
            "based on the key metric described in the insight)"
        )

        template_str = BUILT_IN_TEMPLATES["drill_down_sql"]
        user_prompt = StrTemplate(template_str).safe_substitute(
            original_sql=query.query_sql,
            insight_title=insight.title,
            insight_text=insight.insight,
            severity_score=f"{insight.severity_score:.0f}" if insight.severity_score else "?",
            sql_params=sql_params_text,
            problem_criteria=problem_criteria,
        )

        # On retry, append the failed SQL and error so the LLM can correct it.
        if previous_sql and execution_error:
            user_prompt += (
                "\n\n## PREVIOUS ATTEMPT FAILED — FIX REQUIRED\n"
                "The SQL you generated previously failed to execute against PostgreSQL.\n\n"
                "**Failed SQL:**\n```sql\n"
                f"{previous_sql}\n"
                "```\n\n"
                f"**PostgreSQL error:**\n```\n{execution_error}\n```\n\n"
                "Analyse the error, fix the SQL, and respond with ONLY the corrected "
                "query. Common issues:\n"
                "- ROUND(double precision, int) → must cast to NUMERIC: ROUND(expr::NUMERIC, 2)\n"
                "- DATEDIFF does not exist → use (date1 - date2) for integer days\n"
                "- Column name typos or aliases not matching the source table\n"
                "- Missing or incorrect type casts\n"
            )

        system_prompt = (
            "You are an expert SQL analyst. Given an analysis query and its "
            "findings, generate a drill-down SELECT query that returns the "
            "specific problematic entities for investigation. "
            "Respond with ONLY the raw SQL — no markdown, no explanation."
        )

        try:
            response = await self.llm._llm.ainvoke([
                {"role": "system", "content": system_prompt},
                {"role": "human", "content": user_prompt},
            ])
            raw_sql = response.content.strip() if isinstance(response.content, str) else ""

            # Strip markdown fences if the LLM wrapped it anyway
            if raw_sql.startswith("```"):
                raw_sql = re.sub(r"^```(?:sql)?\s*", "", raw_sql)
                raw_sql = re.sub(r"\s*```$", "", raw_sql)

            # Basic safety: must be a SELECT, not DDL/DML
            first_keyword = raw_sql.lstrip().split()[0].upper() if raw_sql.strip() else ""
            if first_keyword not in ("SELECT", "WITH"):
                log.warning(
                    "Drill-down SQL generation returned non-SELECT (%s) — discarding",
                    first_keyword,
                )
                return None

            return raw_sql

        except Exception as exc:
            log.warning("Drill-down SQL generation failed (non-fatal): %s", exc)
            return None

    async def _execute_drill_down(
        self,
        source_db: AsyncSession,
        drill_down_sql: str,
    ) -> tuple[list[str], list[dict[str, Any]], str | None]:
        """
        Execute the drill-down SQL, extract site identifiers, and return the
        full result rows for storage.

        Returns
        -------
        (site_ids, rows, error)
            site_ids : deduplicated list of site IDs (empty on failure)
            rows     : full result rows from the query (empty on failure)
            error    : the error message string if execution failed, else None
        """
        try:
            rows = await self.executor.execute(source_db, drill_down_sql, params={}, max_rows=None)
        except Exception as exc:
            log.warning("Drill-down SQL execution failed (non-fatal): %s", exc)
            return [], [], str(exc)

        if not rows:
            return [], [], None

        return _extract_site_ids(rows), _make_json_safe(rows), None

    async def _persist_insight(
        self, db: AsyncSession, schema: InsightCreate
    ) -> Insight:
        insight = Insight(**schema.model_dump())
        db.add(insight)
        await db.flush()  # get insight_id without full commit
        return insight
