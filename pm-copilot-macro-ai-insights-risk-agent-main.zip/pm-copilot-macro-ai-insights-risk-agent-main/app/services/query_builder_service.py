"""
SQL Query Builder Service

Uses the LLM to generate parameterized analysis SQL queries (`:name` style)
from a plain-English goal description, then optionally saves them to the
sql_query_library for consumption by the insights engine.
"""
from __future__ import annotations

import logging
import re
import uuid

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.models.query_library import SqlQueryLibrary
from app.services.template_ingest_service import _add_text_casts
from app.schemas.builder import SqlQueryBuilderRequest

log = logging.getLogger(__name__)
settings = get_settings()


_QUERY_SYSTEM_PROMPT = """\
You are a PostgreSQL expert generating parameterized analysis queries for a business intelligence engine.

HOW THE ENGINE WORKS — READ CAREFULLY:
The geography hierarchy is: overall → region → area → market → site.

The engine executes the SAME query at multiple geography scopes by binding different parameter
combinations. The query itself must NOT be written for a specific level — it must work correctly
regardless of which geo params are non-NULL.

HOW GEOGRAPHY FILTERING WORKS (null-safe pass-through pattern):
  Apply ALL three geo filters using null-safe conditions:
    (CAST(:region AS TEXT) IS NULL OR LOWER(region_col) = LOWER(:region))
    (CAST(:area   AS TEXT) IS NULL OR LOWER(area_col)   = LOWER(:area))
    (CAST(:market AS TEXT) IS NULL OR LOWER(market_col) = LOWER(:market))
  When the engine runs at region scope:  :region=South, :area=NULL, :market=NULL
    → filters to South; area/market filters pass through (NULL = no filter)
  When the engine runs at area scope:    :region=South, :area=Texas, :market=NULL
    → filters to Texas within South
  When the engine runs at market scope:  :region=South, :area=Texas, :market=Houston
    → filters to Houston within Texas

HOW GROUPING WORKS:
  GROUP BY the finest granularity column in the table (site_id, site, element_id, or market).
  Do NOT vary the GROUP BY by level — use the same column always.
  The engine will aggregate the results in Python to the appropriate child level before
  passing them to the LLM (e.g., at region scope it aggregates site rows into area summaries).
  Your job is only to return the raw site/market-level rows with all geography columns included.

MANDATORY GEOGRAPHY COLUMN ALIASES IN SELECT:
  You MUST alias your geography columns with these EXACT names so the engine can aggregate correctly:
    AS region    ← the regional grouping column
    AS area      ← the area/cluster grouping column
    AS market    ← the market grouping column
    AS site      ← the site/node/element identifier (finest grain)
  If a column doesn't exist in the table, omit it — do not invent it.

DATE PARAMETERS — OPTIONAL, USE ONLY WHEN NEEDED:
  :start_date and :end_date are OPTIONAL parameters.
  Include them ONLY when the analysis explicitly requires temporal filtering — i.e., the goal
  mentions words like: "trend", "over time", "week-over-week", "monthly", "period", "since",
  "between dates", "last N weeks", "change", "before", "after", or "historical".
  If the goal asks about current state, rankings, ratios, averages, or snapshots without
  a time window — OMIT :start_date and :end_date entirely.
  When included, filter using: date_col BETWEEN :start_date AND :end_date

Parameter conventions — use :name style placeholders (NOT $N positional):
  :level      — geography level string ('overall', 'region', 'area', 'market')  [always include]
  :region     — nullable region name                                             [always include]
  :area       — nullable area name                                               [always include]
  :market     — nullable market name                                             [always include]
  :start_date — ISO date string for period start (e.g. '2025-01-01')            [OPTIONAL — only if time-based]
  :end_date   — ISO date string for period end                                   [OPTIONAL — only if time-based]
  :limit      — integer row limit; the query MUST end with LIMIT :limit         [always include]

Other rules:
- Return ONLY the SQL SELECT statement — no markdown fences, no explanation.
- Use LOWER() on BOTH sides for all case-insensitive text comparisons.
- Use CAST(:param AS TEXT) IS NULL for nullable parameter null-checks.
- The query must be a read-only SELECT.
- Do not include a trailing semicolon.
- Prefer meaningful aliases and clear column names.
- Only reference columns that exist in the schema provided. Do not invent column names.
"""

_QUERY_USER_TEMPLATE = """\
Generate a parameterized PostgreSQL analysis query.

Source table  : {derived_table}
Analysis goal : {analysis_goal}

{table_context_section}\
The query runs at multiple geography scopes using the SAME SQL.
  → ALIAS geography columns as region / area / market / site (exact names — required for aggregation).
  → Apply null-safe filters for :region, :area, :market so unused params pass through.
  → GROUP BY the finest granularity column (site or market level).
  → The engine aggregates in Python to the right level — return raw fine-grained rows.
  → Include :start_date/:end_date ONLY if the analysis goal requires a date range.

{columns_section}
{sample_section}
Additional context / constraints:
{additional_context}

Return only the SQL SELECT statement using :name parameters.
End with LIMIT :limit.
"""


class QueryBuilderService:
    """Generates analysis SQL queries via LLM and optionally saves to library."""

    def __init__(self) -> None:
        self._llm = ChatOpenAI(
            api_key="NONE",
            model=settings.llm_model,
            base_url=settings.llm_api_base_url,
            default_headers={
                "api-key": settings.llm_gateway_api_key,
                "workspacename": settings.llm_workspace_name,
            },
            temperature=0.0,
            max_tokens=2048,
            timeout=settings.llm_timeout_seconds,
            max_retries=0,
        )

    async def generate_query(
        self,
        request: SqlQueryBuilderRequest,
        source_db: AsyncSession | None = None,
        table_context: str | None = None,
    ) -> str:
        """Call LLM and return the generated SELECT SQL string.

        If ``request.provided_sql`` is set, returns it directly (no LLM call).
        If ``request.available_columns`` is not provided and ``source_db`` is
        given, the table schema is fetched from pg_catalog automatically.
        ``table_context`` is optional derived-table context (business purpose,
        join logic, filter conditions) that helps the LLM produce accurate SQL.
        """
        # Fast path: caller already has validated SQL — skip LLM
        if request.provided_sql:
            log.info(
                "Using provided_sql for table=%s (skipping LLM)", request.derived_table
            )
            return _clean_sql(request.provided_sql)

        columns = list(request.available_columns or [])

        if not columns and source_db is not None:
            columns = await _fetch_columns(source_db, request.derived_table)
            if columns:
                log.info(
                    "Auto-fetched %d columns for table=%s",
                    len(columns),
                    request.derived_table,
                )
            else:
                log.warning(
                    "Could not fetch schema for table=%s — LLM will proceed without column list",
                    request.derived_table,
                )

        columns_section = (
            "Available columns (use ONLY these — do not invent others):\n"
            + "\n".join(f"  - {c}" for c in columns)
            if columns
            else "Available columns: unknown — infer from the table name and goal."
        )

        # Include up to 3 sample rows so LLM understands value formats
        sample_section = ""
        if request.sample_rows:
            rows = request.sample_rows[:3]
            lines = [str(r) for r in rows]
            sample_section = "Sample rows (illustrative — shows real value formats):\n" + "\n".join(f"  {l}" for l in lines) + "\n"

        # Table context section (derived table lineage and business purpose)
        table_context_section = ""
        if table_context:
            table_context_section = (
                "Derived table context (how this table was built — use this to understand "
                "data lineage, what each column represents, and what filters were already applied):\n"
                + "\n".join(f"  {line}" for line in table_context.splitlines())
                + "\n\n"
            )

        user_msg = _QUERY_USER_TEMPLATE.format(
            derived_table=request.derived_table,
            analysis_goal=request.analysis_goal,
            table_context_section=table_context_section,
            columns_section=columns_section,
            sample_section=sample_section,
            additional_context=request.additional_context or "None",
        )
        messages = [SystemMessage(content=_QUERY_SYSTEM_PROMPT), HumanMessage(content=user_msg)]
        response = await self._llm.ainvoke(messages)
        raw = response.content if isinstance(response.content, str) else ""
        sql = _clean_sql(raw)
        log.info(
            "Query generated for table=%s goal=%r",
            request.derived_table,
            request.analysis_goal[:100],
        )
        return sql

    async def save_query(
        self,
        db: AsyncSession,
        request: SqlQueryBuilderRequest,
        generated_sql: str,
        table_context: str | None = None,
    ) -> SqlQueryLibrary:
        """Persist the generated query to sql_query_library.

        A secondary LLM call synthesises a well-formed ``purpose`` statement from
        the analysis goal and table context.  This purpose is later consumed by the
        insight-generation prompt so the LLM understands precisely what each query
        measures — beyond the raw SQL.
        """
        synthesized_purpose = await self._synthesize_purpose(
            request.analysis_goal, table_context, request.query_purpose
        )
        entry = SqlQueryLibrary(
            name=request.query_name or f"auto_{uuid.uuid4().hex[:8]}",
            query_sql=_add_text_casts(generated_sql.rstrip(";")),
            purpose=synthesized_purpose,
            description=request.analysis_goal,
            geography_level=request.geography_level or None,
            prompt_template_id=request.prompt_template_id,
            projects=request.projects if request.projects else None,
            functions=request.functions if request.functions else None,
            tags=request.tags if request.tags else None,
            team=request.team or None,
            pack_id=request.pack_id,
            pm_category=request.pm_category,
            business_context=request.business_context or None,
            row_limit=request.row_limit,
            group_by_column=request.group_by_column or None,
            insight_areas=request.insight_areas if request.insight_areas else None,
            is_active=True,
        )
        db.add(entry)
        await db.commit()
        await db.refresh(entry)
        log.info(
            "Saved to query library: id=%s name=%r pack_id=%r pm_category=%r",
            entry.query_id, entry.name, entry.pack_id, entry.pm_category,
        )
        return entry

    async def _synthesize_purpose(
        self,
        analysis_goal: str,
        table_context: str | None,
        user_purpose: str | None,
    ) -> str:
        """
        Generate a precise, well-worded purpose statement for the query.

        If a ``user_purpose`` is provided it is used as a strong hint, but the
        LLM still enriches and completes it.  Falls back to ``analysis_goal``
        if the LLM call fails.
        """
        from app.services.derived_table_service import _PURPOSE_SYSTEM, _PURPOSE_USER
        hint = f"User-supplied purpose hint: {user_purpose}\n" if user_purpose else ""
        user_msg = hint + _PURPOSE_USER.format(
            analysis_goal=analysis_goal,
            table_context=table_context or "N/A",
        )
        try:
            from langchain_core.messages import HumanMessage as HM, SystemMessage as SM
            response = await self._llm.ainvoke([SM(content=_PURPOSE_SYSTEM), HM(content=user_msg)])
            purpose = (response.content or "").strip() if isinstance(response.content, str) else ""
            if purpose:
                log.info("Purpose synthesised (%d chars)", len(purpose))
                return purpose
        except Exception as exc:
            log.warning("Purpose synthesis failed: %s", exc)
        return user_purpose or analysis_goal


_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*$")


async def _fetch_columns(db: AsyncSession, qualified_table: str) -> list[str]:
    """
    Return column names for *qualified_table* ordered by position.

    pg_namespace.nspname and pg_class.relname are PostgreSQL ``name`` type.
    asyncpg cannot bind a SQLAlchemy ``String`` param to a ``name`` column
    (type mismatch → silent exception → empty result → LLM hallucinates).
    We interpolate the identifiers directly after validating they are safe.
    """
    parts = qualified_table.strip().split(".", 1)
    schema_name, table_name = (parts[0], parts[1]) if len(parts) == 2 else ("public", parts[0])

    if not _IDENT_RE.match(schema_name) or not _IDENT_RE.match(table_name):
        log.warning("Unsafe identifier rejected in _fetch_columns: %s", qualified_table)
        return []

    # pg_catalog stores identifiers in lowercase
    schema_lc = schema_name.lower()
    table_lc = table_name.lower()

    sql = (
        f"SELECT a.attname, pg_catalog.format_type(a.atttypid, a.atttypmod) "
        f"FROM pg_catalog.pg_attribute  a "
        f"JOIN pg_catalog.pg_class      c ON c.oid = a.attrelid "
        f"JOIN pg_catalog.pg_namespace  n ON n.oid = c.relnamespace "
        f"WHERE n.nspname = '{schema_lc}' AND c.relname = '{table_lc}' "
        f"  AND a.attnum > 0 AND NOT a.attisdropped "
        f"ORDER BY a.attnum"
    )
    try:
        result = await db.execute(text(sql))
        # Return "colname (data_type)" so LLM knows types too
        columns = [f"{row[0]} ({row[1]})" for row in result.fetchall()]
        if not columns:
            log.warning(
                "No columns found for %s — table may not exist or user lacks access",
                qualified_table,
            )
        return columns
    except Exception as exc:
        log.warning("Failed to fetch columns for %s: %s", qualified_table, exc)
        return []


def _clean_sql(raw: str) -> str:
    """Strip markdown fences and trailing semicolons."""
    raw = raw.strip()
    raw = re.sub(r"^```(?:sql)?\s*", "", raw, flags=re.IGNORECASE)
    raw = re.sub(r"\s*```$", "", raw)
    return raw.strip().rstrip(";")
