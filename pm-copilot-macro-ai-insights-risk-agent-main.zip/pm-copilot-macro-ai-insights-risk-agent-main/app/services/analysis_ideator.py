"""
Analysis Ideator Service

Given a derived table's schema, its stored DDL, and business context, calls the LLM
to generate a curated list of analysis ideas that a PM can turn into parameterised
SQL queries for the insights engine.
"""
from __future__ import annotations

import json
import logging
import re

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI

from app.config import get_settings
from app.schemas.builder import AnalysisIdea

log = logging.getLogger(__name__)
settings = get_settings()

# --------------------------------------------------------------------------- #
# Prompt templates
# --------------------------------------------------------------------------- #

_SYSTEM = """\
You are a senior business-intelligence architect helping a Product Manager discover \
high-value, recurring analysis opportunities in their data.

Given a derived table's full definition — including its DDL (the actual SELECT used to build it), \
business context, source joins, and computed columns — you will propose specific, actionable \
analysis ideas that can be automated as daily SQL-driven insights.

The engine runs every query at all geography levels automatically (overall → region → area → market) \
using null-safe parameter filters. You do NOT need to think about geography scoping — the engine \
handles it. Focus entirely on WHAT the data reveals.

ANALYTICAL FOCUS — push analysis toward:
  ✓ Metric thresholds and SLA violations (e.g. rate > 5%, availability < 99%)
  ✓ Statistical outliers (sites/entities deviating significantly from the norm)
  ✓ Efficiency ratios and utilisation patterns
  ✓ Quality scoring and ranking (top N / bottom N performers)
  ✓ Risk indicators and anomaly detection
  ✓ Comparative analysis across categories

DATE / TEMPORAL ANALYSIS RULE — strictly enforced:
  Only propose trend or time-series ideas if the column schema contains at least one date or
  timestamp column (data type containing "date", "time", or "timestamp").
  If no such column exists, do NOT suggest any time-based, trend, week-over-week, or period
  comparison analysis — these would be unsupported by the table's data.

PM GOALS RULE — strictly enforced:
  The "PRIMARY REQUIREMENT" section below contains the PM's actual stated goals.
  You MUST map each distinct goal the PM mentions to at least one dedicated idea.
  Do not paraphrase the goal into something generic — generate an idea that directly
  answers what the PM asked for using the columns available in the table.

STRICT COLUMN RULES — non-negotiable:
1. Every column name in "goal" MUST appear verbatim in the schema provided. Do NOT invent, infer, or rename.
2. If a valuable idea needs a missing column:
   • Include the idea, set "feasibility": "partial", list missing columns in "missing_columns".
   • In "goal", describe without fabricating — write e.g. "a cost_per_unit column (not in table)".
3. All columns present → "feasibility": "full", "missing_columns": [].

Map to exactly one category: performance | trend | outlier | quality | efficiency | risk
Map to exactly one template: performance_insight | trend_insight | comparison_insight | anomaly_insight

Respond ONLY with a valid JSON array — no markdown, no prose.

JSON schema for each element:
{
  "name":               "<60-char descriptive title>",
  "category":           "<category>",
  "goal":               "<specific analysis goal — use ONLY real column names>",
  "rationale":          "<1–2 sentences: why this matters to the PM>",
  "suggested_template": "<template name>",
  "feasibility":        "full|partial",
  "missing_columns":    ["<col_needed_but_absent>", ...]
}
"""

_USER = """\
PRIMARY REQUIREMENT — PM Goals (address these first and foremost):
{pm_goals}

---

Table: {qualified_name}
Description: {description}
Business context: {business_context}
{composition_section}\
{ddl_section}\
Column schema (ONLY these columns exist — do not reference any others):
{columns_section}

Generate {num_ideas} analysis ideas following these priorities in order:
1. First, create one idea per distinct PM goal stated above — map each goal directly to columns in the schema.
2. Fill remaining slots with high-value analyses across: threshold violations, outlier identification,
   efficiency patterns, quality ranking, risk detection.
3. Do NOT generate any temporal/trend/week-over-week idea unless a date or timestamp column is present in the schema.
Each idea must surface a specific, actionable signal — not a generic summary.
Check every column reference against the schema and set feasibility + missing_columns accordingly.
"""

# --------------------------------------------------------------------------- #
# Service
# --------------------------------------------------------------------------- #

class AnalysisIdeator:
    """LLM-powered analysis idea generator for a derived table."""

    def __init__(self) -> None:
        self._llm = ChatOpenAI(
            api_key="NONE",
            model=settings.llm_model,
            base_url=settings.llm_api_base_url,
            default_headers={
                "api-key": settings.llm_gateway_api_key,
                "workspacename": settings.llm_workspace_name,
            },
            temperature=0.4,
            max_tokens=3000,
            timeout=settings.llm_timeout_seconds,
            max_retries=0,
        )

    async def ideate(
        self,
        *,
        qualified_name: str,
        columns: list[dict],          # [{"name": str, "data_type": str}, ...]
        business_context: str,
        description: str,
        join_logic: str | None = None,
        filter_logic: str | None = None,
        additional_logic: str | None = None,
        generated_ddl: str | None = None,
        pm_goals: str | None = None,
        num_ideas: int = 6,
    ) -> list[AnalysisIdea]:
        columns_section = "\n".join(
            f"  • {c['name']}  ({c['data_type']})" for c in columns
        )

        # Table composition — source joins, filters, computed columns
        composition_lines: list[str] = []
        if join_logic:
            composition_lines.append(f"Join / source logic: {join_logic}")
        if filter_logic:
            composition_lines.append(f"Filter conditions: {filter_logic}")
        if additional_logic:
            composition_lines.append(f"Computed / derived columns: {additional_logic}")
        composition_section = (
            "Table composition (how this derived table was built):\n"
            + "\n".join(f"  {l}" for l in composition_lines)
            + "\n\n"
        ) if composition_lines else ""

        # DDL — the fullest representation of what columns exist and how they are computed
        ddl_section = ""
        if generated_ddl:
            # Trim CREATE TABLE ... AS wrapper to expose just the SELECT
            select_body = re.sub(
                r"^\s*CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?\S+\s+AS\s*",
                "",
                generated_ddl,
                flags=re.IGNORECASE,
            ).strip()
            ddl_section = (
                "Derived table SQL (the actual SELECT — use this to understand every column, "
                "its computation, and data lineage):\n"
                "```sql\n"
                f"{select_body}\n"
                "```\n\n"
            )

        user_msg = _USER.format(
            qualified_name=qualified_name,
            description=description or "N/A",
            business_context=business_context or "N/A",
            composition_section=composition_section,
            ddl_section=ddl_section,
            columns_section=columns_section,
            pm_goals=pm_goals or "General performance monitoring and anomaly detection",
            num_ideas=num_ideas,
        )
        messages = [SystemMessage(content=_SYSTEM), HumanMessage(content=user_msg)]
        response = await self._llm.ainvoke(messages)
        raw = response.content if isinstance(response.content, str) else ""
        ideas = _parse_ideas(raw)
        log.info(
            "Ideated %d analysis ideas for table=%s", len(ideas), qualified_name
        )
        return ideas


# --------------------------------------------------------------------------- #
# Parsing helpers
# --------------------------------------------------------------------------- #

def _parse_ideas(raw: str) -> list[AnalysisIdea]:
    """Extract and parse the JSON array from the LLM response."""
    raw = raw.strip()
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.IGNORECASE)
    raw = re.sub(r"\s*```$", "", raw)
    raw = raw.strip()

    match = re.search(r"\[.*\]", raw, re.DOTALL)
    if match:
        raw = match.group(0)

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        log.error("Failed to parse ideation JSON: %s\nRaw snippet: %.400s", exc, raw)
        return []

    ideas: list[AnalysisIdea] = []
    for item in data:
        if not isinstance(item, dict):
            continue
        try:
            missing = item.get("missing_columns") or []
            if not isinstance(missing, list):
                missing = []
            feasibility = str(item.get("feasibility", "full"))
            if feasibility not in ("full", "partial"):
                feasibility = "partial" if missing else "full"
            ideas.append(
                AnalysisIdea(
                    name=str(item.get("name", "Unnamed Analysis"))[:80],
                    category=str(item.get("category", "performance")),
                    goal=str(item.get("goal", "")),
                    rationale=str(item.get("rationale", "")),
                    suggested_template=item.get("suggested_template"),
                    feasibility=feasibility,
                    missing_columns=[str(c) for c in missing],
                )
            )
        except Exception as exc:
            log.warning("Skipping malformed idea: %s — %s", item, exc)

    return ideas
