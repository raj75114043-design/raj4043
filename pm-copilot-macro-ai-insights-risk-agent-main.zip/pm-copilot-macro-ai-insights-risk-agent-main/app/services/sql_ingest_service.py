"""
SQL-first free-form KPI onboarding service.

Pipeline
--------
1. analyse()  — LLM infers + enriches metadata from SQL + free-form context
2. apply()    — test-run SQL, persist approved metadata to sql_query_library
"""
from __future__ import annotations

import json
import logging
import re
import uuid
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.models.query_library import SqlQueryLibrary
from app.schemas.sql_ingest import (
    InferredKpiMetadata,
    SqlAnalyseResponse,
    SqlApplyRequest,
    SqlApplyResponse,
    SqlContextRequest,
)
from app.services.template_ingest_service import _add_text_casts, test_sql
from app.utils.validators import is_safe_read_query

log = logging.getLogger(__name__)
settings = get_settings()


# ================================================================== #
# LLM prompt
# ================================================================== #

_ANALYSE_SYSTEM = """\
You are an expert data analyst configuring an Insights Engine.

Given a SQL SELECT query and a free-text KPI description, do two things:
  1. Extract and enrich structured KPI metadata — one entry per numeric
     metric column in the query.
  2. Rewrite the SQL with engine bind-parameters so it can be executed against any date range
     and any geography scope — this is the "parameterized_sql".

Return ONLY a valid JSON object with EXACTLY this schema (no extra keys, no markdown, no explanation):
{
  "geography_level": "<market|area|region|overall>",
  "category": "<performance|capacity|quality|reliability|compliance|operational>",
  "subcategory": "<string or null>",
  "display_name": "<concise human-readable label for the query as a whole>",
  "description": "<one sentence: what this query measures>",
  "purpose": "<one sentence: why these KPIs matter to the business>",
  "prompt_template": "<performance_insight|trend_insight|capacity_insight|executive_summary_insight|vendor_performance|schedule_adherence|anomaly_detection|comparative_analysis|multi_kpi_synthesis>",
  "team": "<string or null>",
  "functions": ["<string>"] or null,
  "tags": ["<string>"] or null,
  "projects": null,
  "pm_category": "<Cost|Quality|Schedule|Other> or null",
  "business_context": {
    "kpis": [
      {
        "column": "<exact column alias from SELECT — e.g. 'volte_drop_rate_pct'>",
        "kpi_name": "<human-readable name for this metric>",
        "unit": "<% | ms | Mbps | count | days | etc., or null>",
        "target": <numeric goal value, or null>,
        "sla_threshold": <numeric minimum/breach value, or null>,
        "lower_is_better": <true|false>,
        "aggregation": "<avg|sum|max|min>",
        "interpretation": "<1-2 professional sentences: direction, thresholds, business impact>"
      }
    ]
  },
  "parameterized_sql": "<see rules below>"
}

METADATA RULES:
- Infer geography_level from the SQL GROUP BY:
    GROUP BY market / city / cluster → "market"
    GROUP BY area / district / zone  → "area"
    GROUP BY region                  → "region"
    No geo GROUP BY, single-row output → "overall"
- MULTIPLE KPIs: inspect the SELECT clause and create one entry in business_context.kpis[]
  for every numeric metric column. Exclude geography columns (market, area, region, site,
  site_id, element, node) and row-count columns (site_count, count, total_count).
  If the query produces only one numeric metric, the kpis array will have one entry.
- For each KPI's "column" value: use the exact alias from the SELECT clause.
  For each "aggregation": match the SQL function (AVG → "avg", SUM → "sum", MAX → "max",
  MIN → "min"). If no function is used, default to "avg".
- For each KPI's "interpretation": write 1-2 clear professional sentences stating
  the direction, threshold values, business impact, and implied action.
- Enrich and standardise the user's language — do not just copy it verbatim.

PARAMETERIZED SQL RULES — read carefully:
The engine runs every query with these named bind-parameters:
  :start_date   (DATE string, e.g. '2024-01-01')
  :end_date     (DATE string, e.g. '2024-01-31')
  :market       (text or NULL — filters to a specific market when set)
  :area         (text or NULL — filters to a specific area when set)
  :region       (text or NULL — filters to a specific region when set)

Rewrite the original SQL so that:

1. DATE FILTERING — follow the user's explicit instruction (provided in the user message):
   If date_filterable = TRUE:
   - If a hardcoded date literal / range exists → replace it with :start_date / :end_date:
       WHERE date_col = '2024-01-01'                    → WHERE date_col BETWEEN :start_date AND :end_date
       WHERE date_col >= '...' AND date_col <= '...'    → WHERE date_col BETWEEN :start_date AND :end_date
   - If no date filter exists → add: AND date_col BETWEEN :start_date AND :end_date
     using the most likely date column found in the query.
   If date_filterable = FALSE:
   - Do NOT add :start_date or :end_date under any circumstances.
   - Leave any existing date literals as-is or remove them only if they are clearly wrong.
   NEVER use LIMIT in parameterized_sql — the engine wraps with its own limit.

2. GEOGRAPHY FILTERING — add a filter for the inferred geography_level.
   Use CAST(:param AS TEXT) — NOT :param::text — and the IS NULL guard so the query
   returns all rows when the param is not set:
   - geography_level = "market"  → add: AND (CAST(:market AS TEXT) IS NULL OR LOWER(<market_col>) = LOWER(CAST(:market AS TEXT)))
   - geography_level = "area"    → add: AND (CAST(:area AS TEXT) IS NULL OR LOWER(<area_col>) = LOWER(CAST(:area AS TEXT)))
   - geography_level = "region"  → add: AND (CAST(:region AS TEXT) IS NULL OR LOWER(<region_col>) = LOWER(CAST(:region AS TEXT)))
   - geography_level = "overall" → no geo filter needed
   If the original SQL already filters on that column with a literal, replace that literal with the param.
   IMPORTANT: always use CAST(:param AS TEXT), never :param::text.

3. OTHER:
   - Remove any trailing semicolon.
   - Do not wrap in a subquery or CTE.
   - Do not change SELECT columns, GROUP BY, or ORDER BY.
   - Preserve the original table aliases and joins.

Return ONLY the JSON object. No explanation, no markdown fences, no prefix.
"""


# ================================================================== #
# Public API
# ================================================================== #

async def analyse(
    request: SqlContextRequest,
    source_db: AsyncSession,
) -> SqlAnalyseResponse:
    """
    LLM-infer metadata from SQL + free-form context, then test-run the SQL.
    Returns the result for user review — nothing is written to the database.
    """
    # ---- Step 1: Safety check ---- #
    if not is_safe_read_query(request.sql):
        return SqlAnalyseResponse(
            name=request.name,
            original_sql=request.sql,
            inferred=_fallback_metadata(request.name),
            sql_valid=False,
            sql_test_error="SQL contains unsafe statements (DML/DDL not allowed). Use SELECT only.",
        )

    # ---- Step 2: LLM inference + parameterization ---- #
    inferred = await _infer_metadata(request.name, request.sql, request.context, request.date_filterable)

    # ---- Step 3: Test-run the parameterized SQL (engine adds bind-params) ---- #
    sql_to_test = inferred.parameterized_sql or request.sql
    ok, row_count, sql_err = await test_sql(sql_to_test, source_db)

    return SqlAnalyseResponse(
        name=request.name,
        original_sql=request.sql,
        inferred=inferred,
        sql_valid=ok,
        sql_test_rows=row_count if ok else None,
        sql_test_error=sql_err,
    )


async def apply(
    request: SqlApplyRequest,
    source_db: AsyncSession,
    insights_db: AsyncSession,
) -> SqlApplyResponse:
    """
    Test-run the SQL, then persist the approved metadata to sql_query_library.
    """
    # ---- Safety check ---- #
    if not is_safe_read_query(request.sql):
        raise ValueError("SQL contains unsafe statements (DML/DDL not allowed).")

    # ---- Test-run ---- #
    ok, row_count, sql_err = await test_sql(request.sql, source_db)
    if not ok:
        raise ValueError(f"SQL test-run failed: {sql_err}")

    # ---- Persist ---- #
    # request.sql is already the parameterized version reviewed by the user;
    # _add_text_casts ensures ::text casts on all geo params for asyncpg.
    query_id = str(uuid.uuid4())

    # Merge display_name, category, subcategory into business_context so they
    # persist (SqlQueryLibrary has no dedicated columns for these).
    bc = dict(request.business_context) if request.business_context else {}
    # Only set legacy kpi_name when there's no kpis[] array
    if request.display_name and "kpis" not in bc:
        bc.setdefault("kpi_name", request.display_name)
    if request.category:
        bc["category"] = request.category
    if request.subcategory:
        bc["subcategory"] = request.subcategory

    row = SqlQueryLibrary(
        query_id=query_id,
        name=request.name,
        query_sql=_add_text_casts(request.sql.rstrip(";")),
        description=request.description,
        purpose=request.purpose or f"Insight for {request.display_name or request.name}",
        geography_level=request.geography_level,
        projects=request.projects,
        functions=request.functions,
        team=request.team,
        tags=request.tags,
        pm_category=request.pm_category,
        prompt_template_id=request.prompt_template,
        business_context=bc or None,
        row_limit=request.row_limit,
        group_by_column=request.group_by_column or None,
        is_active=True,
        version="1.0",
    )
    insights_db.add(row)
    await insights_db.commit()
    log.info("SQL-ingest: persisted query '%s' as %s", request.name, query_id)

    return SqlApplyResponse(
        query_id=query_id,
        name=request.name,
        status="ingested",
        sql_test_rows=row_count,
    )


# ================================================================== #
# LLM call
# ================================================================== #

async def _infer_metadata(name: str, sql: str, context: str, date_filterable: bool = True) -> InferredKpiMetadata:
    """
    Ask the LLM to infer and enrich KPI metadata from SQL + free-form context.
    Falls back to a minimal default on any error.
    """
    date_instruction = (
        "DATE FILTERING: The user confirmed this KPI HAS a date/time dimension. "
        "Add or replace date filters using :start_date and :end_date as instructed."
        if date_filterable else
        "DATE FILTERING: The user confirmed this KPI does NOT have a date/time dimension (static/reference data). "
        "Do NOT add :start_date or :end_date params under any circumstances."
    )
    user_prompt = f"""KPI identifier: {name}

SQL query:
{sql}

Free-form context provided by the user:
{context}

User instruction — {date_instruction}

Return the structured JSON metadata as specified in your instructions."""

    try:
        from langchain_core.messages import HumanMessage, SystemMessage
        from langchain_openai import ChatOpenAI

        llm = ChatOpenAI(
            api_key="NONE",
            model=settings.llm_model,
            base_url=settings.llm_api_base_url,
            default_headers={
                "api-key": settings.llm_gateway_api_key,
                "workspacename": settings.llm_workspace_name,
            },
            temperature=0.0,   # deterministic — we want consistent structured output
            max_tokens=2000,   # needs headroom for multi-KPI business_context
            timeout=settings.llm_timeout_seconds,
            max_retries=2,
        )
        messages = [
            SystemMessage(content=_ANALYSE_SYSTEM),
            HumanMessage(content=user_prompt),
        ]
        response = await llm.ainvoke(messages)
        raw = response.content if isinstance(response.content, str) else ""
        return _parse_llm_response(name, raw)

    except Exception as exc:
        log.warning("LLM inference failed for '%s': %s — using fallback metadata", name, exc)
        return _fallback_metadata(name)


def _parse_llm_response(name: str, raw: str) -> InferredKpiMetadata:
    """
    Parse the LLM JSON response into InferredKpiMetadata.
    Falls back to minimal defaults on parse failure.
    """
    # Strip any accidental markdown fences
    cleaned = re.sub(r"```(?:json)?\s*", "", raw).replace("```", "").strip()

    try:
        data: dict[str, Any] = json.loads(cleaned)
    except json.JSONDecodeError:
        # Try to extract just the JSON object if there's surrounding text
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group())
            except json.JSONDecodeError:
                log.warning("Could not parse LLM JSON for '%s' — using fallback", name)
                return _fallback_metadata(name)
        else:
            log.warning("No JSON found in LLM response for '%s' — using fallback", name)
            return _fallback_metadata(name)

    # business_context defaults — normalise to kpis[] format
    bc = data.get("business_context") or {}

    # If LLM returned legacy flat format, convert to kpis[] array
    if "kpis" not in bc and bc.get("kpi_name"):
        bc["kpis"] = [{
            "column": list((bc.get("aggregation_rules") or {}).keys())[0]
                       if bc.get("aggregation_rules") else "value",
            "kpi_name": bc.get("kpi_name") or name,
            "unit": bc.get("unit"),
            "target": bc.get("target"),
            "sla_threshold": bc.get("sla_threshold"),
            "lower_is_better": bc.get("lower_is_better", False),
            "aggregation": list((bc.get("aggregation_rules") or {}).values())[0]
                           if bc.get("aggregation_rules") else "avg",
            "interpretation": bc.get("interpretation"),
        }]
        # Remove legacy top-level keys now that they're in kpis[]
        for k in ("kpi_name", "unit", "target", "sla_threshold",
                   "lower_is_better", "interpretation", "aggregation_rules"):
            bc.pop(k, None)

    # Ensure kpis is at least an empty list
    if "kpis" not in bc:
        bc["kpis"] = []

    return InferredKpiMetadata(
        geography_level=data.get("geography_level", "market"),
        category=data.get("category", "performance"),
        subcategory=data.get("subcategory"),
        display_name=data.get("display_name") or name.replace("_", " ").title(),
        description=data.get("description"),
        purpose=data.get("purpose"),
        prompt_template=data.get("prompt_template", "performance_insight"),
        team=data.get("team"),
        functions=data.get("functions"),
        tags=data.get("tags"),
        projects=data.get("projects"),
        pm_category=data.get("pm_category"),
        business_context=bc,
        parameterized_sql=data.get("parameterized_sql") or None,
    )


def _fallback_metadata(name: str) -> InferredKpiMetadata:
    """Minimal defaults used when LLM inference is unavailable."""
    display = name.replace("_", " ").title()
    return InferredKpiMetadata(
        geography_level="market",
        category="performance",
        display_name=display,
        business_context={"kpis": [{"column": "value", "kpi_name": display, "aggregation": "avg", "lower_is_better": False}]},
    )
