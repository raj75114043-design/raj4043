"""
SQL Executor Service

Responsible for:
  - Loading SQL queries from the query library (DB or YAML fallback)
  - Safely executing them against the source database with bound parameters
  - Returning results as list[dict] for downstream LLM processing
"""
from __future__ import annotations

import logging
import re
from datetime import date, datetime, timedelta
from typing import Any

import yaml
from pathlib import Path
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from tenacity import retry, stop_after_attempt, wait_exponential

from app.config import get_settings
from app.models.query_library import SqlQueryLibrary
from app.utils.validators import is_safe_read_query

log = logging.getLogger(__name__)
settings = get_settings()


class SqlExecutionError(Exception):
    """Raised when a query execution fails."""


class SqlQueryLoader:
    """Loads SQL queries from the database or YAML fallback."""

    async def load_queries(
        self,
        db: AsyncSession,
        *,
        geography_level: str | None = None,
        projects: list[str] | None = None,
        functions: list[str] | None = None,
        pack_ids: list[str] | None = None,
        query_ids: list[str] | None = None,
        tags: list[str] | None = None,
    ) -> list[SqlQueryLibrary]:
        """
        Fetch active queries from the library matching the given filters.

        Filters are AND-combined across dimensions.

        Geography matching:
          - Queries whose geography_level matches the requested level are included.
          - Queries with geography_level = 'overall' always match (run at every level).
          - Queries with geography_level IS NULL are level-agnostic and always match.

        pack_ids and query_ids are mutually exclusive:
          - pack_ids filter by pack membership (preferred when running pack-based jobs).
          - query_ids filter by specific query UUIDs.
          - When both are supplied, pack_ids takes precedence.
        """
        from sqlalchemy import func, select, or_

        stmt = select(SqlQueryLibrary).where(SqlQueryLibrary.is_active.is_(True))

        if geography_level:
            level_lower = geography_level.lower()
            stmt = stmt.where(
                or_(
                    func.lower(SqlQueryLibrary.geography_level) == level_lower,
                    func.lower(SqlQueryLibrary.geography_level) == "overall",
                    SqlQueryLibrary.geography_level.is_(None),
                )
            )

        if pack_ids:
            stmt = stmt.where(SqlQueryLibrary.pack_id.in_(pack_ids))
        elif query_ids:
            stmt = stmt.where(SqlQueryLibrary.query_id.in_(query_ids))

        clean_projects = [p for p in projects if p] if projects else None
        clean_functions = [f for f in functions if f] if functions else None

        if clean_projects:
            stmt = stmt.where(SqlQueryLibrary.projects.overlap(clean_projects))
        if clean_functions:
            stmt = stmt.where(SqlQueryLibrary.functions.overlap(clean_functions))
        if tags:
            stmt = stmt.where(SqlQueryLibrary.tags.overlap(tags))

        result = await db.execute(stmt)
        queries = list(result.scalars().all())
        log.info(
            "load_queries: found=%d geography_level=%r pack_ids=%r query_ids=%r",
            len(queries), geography_level, pack_ids, query_ids,
        )
        if not queries:
            log.warning(
                "load_queries: 0 queries — check sql_query_library: "
                "is_active=TRUE, geography_level IN ('%s', 'overall', NULL)",
                geography_level,
            )
        return queries


class SqlExecutor:
    """Executes parameterised SQL queries against the source database."""

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        reraise=True,
    )
    async def execute(
        self,
        source_db: AsyncSession,
        query_sql: str,
        params: dict[str, Any],
        max_rows: int | None = None,
    ) -> list[dict[str, Any]]:
        """
        Execute a read-only query with bound parameters.

        Parameters
        ----------
        source_db : AsyncSession
            Read-only session to the source/derived-tables database.
        query_sql : str
            Parameterised SQL with :name style placeholders.
        params : dict
            Parameter values. Only keys referenced in SQL are passed.
        max_rows : int | None
            Safety limit on result set size. None = no limit.

        Returns
        -------
        list[dict]
            Each row as a dict keyed by column name.
        """
        if not is_safe_read_query(query_sql):
            raise SqlExecutionError(
                "Attempted to execute a non-read-only query — blocked for safety."
            )

        # Coerce date objects to strings for the driver.
        # Always inject 'limit' so SQL that uses :limit for an inner LIMIT clause works.
        safe_params = {k: _coerce_param(v) for k, v in params.items()}
        if max_rows is not None:
            safe_params.setdefault("limit", max_rows)
        elif ":limit" in query_sql:
            # Query explicitly uses :limit but caller passed no max_rows —
            # provide a safe default so the bind parameter is satisfied.
            safe_params.setdefault("limit", 500)

        # Strip params not referenced in the SQL to avoid driver complaints
        referenced = {k for k in safe_params if f":{k}" in query_sql}
        bound_params = {k: v for k, v in safe_params.items() if k in referenced}

        try:
            base_sql = query_sql.strip().rstrip(";")
            if max_rows is not None:
                final_sql = f"SELECT * FROM ({base_sql}) _q LIMIT {max_rows}"
            else:
                final_sql = base_sql
            log.info("Executing SQL (rendered):\n%s", _render_sql(final_sql, bound_params))
            result = await source_db.execute(text(final_sql), bound_params)
            columns = list(result.keys())
            rows = [
                {col: _coerce_value(v) for col, v in zip(columns, row)}
                for row in result.fetchall()
            ]
            log.info("Query returned %d rows (limit=%s)", len(rows), max_rows or "unlimited")
            return rows
        except Exception as exc:
            # Roll back the aborted transaction so the session is usable again
            # before tenacity retries, and so the connection pool isn't poisoned.
            try:
                await source_db.rollback()
            except Exception:
                pass
            log.error("SQL execution failed: %s", exc, exc_info=True)
            raise SqlExecutionError(f"Query execution failed: {exc}") from exc


def _coerce_param(value: Any) -> Any:
    """Convert Python objects to types understood by asyncpg."""
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    return value


def _coerce_value(value: Any) -> Any:
    """
    Convert result row values to JSON-serializable Python types.

    PostgreSQL INTERVAL columns are returned as Python timedelta objects,
    which are not JSON-serializable.  Convert to total seconds (float) so
    the LLM receives a numeric value it can interpret.

    date / datetime are converted to ISO-8601 strings for the same reason.
    """
    if isinstance(value, timedelta):
        return value.total_seconds()
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    return value


def _render_sql(sql: str, params: dict[str, Any]) -> str:
    """
    Return a best-effort human-readable SQL string with :name placeholders
    replaced by their literal values — for logging only, not for execution.
    """

    def _fmt(v: Any) -> str:
        if v is None:
            return "NULL"
        if isinstance(v, (int, float)):
            return str(v)
        return f"'{str(v)}'"

    # Replace longest param names first to avoid partial replacement
    # (e.g. :start_date before :start).
    for key in sorted(params, key=len, reverse=True):
        sql = re.sub(rf":{re.escape(key)}\b", _fmt(params[key]), sql)
    return sql
