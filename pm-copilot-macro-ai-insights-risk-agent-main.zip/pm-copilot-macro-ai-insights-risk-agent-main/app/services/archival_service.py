"""
Archival Service

Moves expired insights from `insights` to `insights_historical`,
keeping the hot table lean and query-efficient.
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from sqlalchemy import delete, insert, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.insights import Insight, InsightHistorical

log = logging.getLogger(__name__)


class ArchivalService:

    async def archive_old_insights(
        self,
        db: AsyncSession,
        days_threshold: int = 90,
        batch_size: int = 500,
        dry_run: bool = False,
    ) -> int:
        """
        Archive insights older than `days_threshold` days.

        1. SELECT candidates
        2. INSERT INTO insights_historical
        3. DELETE FROM insights

        Returns the number of insights archived (0 for dry_run).
        """
        cutoff = datetime.now(timezone.utc) - timedelta(days=days_threshold)

        # --- Find candidates --- #
        stmt = (
            select(Insight)
            .where(
                (Insight.created_at < cutoff) | (Insight.expires_at <= datetime.now(timezone.utc))
            )
            .limit(batch_size)
        )
        result = await db.execute(stmt)
        candidates: list[Insight] = list(result.scalars().all())

        if not candidates:
            log.info("No insights to archive (threshold=%d days)", days_threshold)
            return 0

        log.info("Found %d insight(s) to archive (dry_run=%s)", len(candidates), dry_run)

        if dry_run:
            return len(candidates)

        archived_count = 0
        insight_ids = []

        for insight in candidates:
            historical = InsightHistorical(
                insight_id=insight.insight_id,
                title=insight.title,
                insight=insight.insight,
                insight_detail=insight.insight_detail,
                market=insight.market,
                area=insight.area,
                region=insight.region,
                team=insight.team,
                severity_score=insight.severity_score,
                category=insight.category,
                subcategory=insight.subcategory,
                type=insight.type,
                site_count=insight.site_count,
                drill_down_sql=insight.drill_down_sql,
                source_data=insight.source_data,
                projects=insight.projects,
                functions=insight.functions,
                tags=insight.tags,
                query_id=insight.query_id,
                prompt_template_id=insight.prompt_template_id,
                llm_model=insight.llm_model,
                job_id=insight.job_id,
                created_at=insight.created_at,
                updated_at=insight.updated_at,
                expires_at=insight.expires_at,
                is_active=False,
            )
            db.add(historical)
            insight_ids.append(insight.insight_id)
            archived_count += 1

        # Flush to insert historical records first
        await db.flush()

        # Delete from active table (cascade will clean embeddings + interactions)
        await db.execute(delete(Insight).where(Insight.insight_id.in_(insight_ids)))
        await db.commit()

        log.info("Archived %d insights successfully", archived_count)
        return archived_count
