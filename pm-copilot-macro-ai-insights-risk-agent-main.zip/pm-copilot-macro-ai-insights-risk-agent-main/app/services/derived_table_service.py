"""
Derived Table Builder Service

Uses the LLM to generate a CREATE TABLE AS SELECT statement from a plain-English
specification, then optionally executes it against the source database.

After DDL generation a second LLM call synthesises a rich, structured context
description that is stored on the DerivedTableDefinition record.  This context
is later consumed by the query-builder and analysis-ideation prompts so every
downstream LLM call has a complete, well-worded understanding of the table.

Refresh strategies
------------------
truncate_insert : TRUNCATE the table then re-INSERT — table stays visible during refresh.
create_replace  : DROP + recreate — guarantees a clean schema but brief unavailability.
"""
from __future__ import annotations

import logging
import re
from datetime import datetime, timezone

from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import ChatOpenAI
from sqlalchemy import text, update
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.models.derived_tables import DerivedTableDefinition
from app.schemas.builder import DerivedTableRequest

log = logging.getLogger(__name__)
settings = get_settings()


# ------------------------------------------------------------------ #
# DDL generation prompts
# ------------------------------------------------------------------ #

_DDL_SYSTEM_PROMPT = """\
You are a PostgreSQL expert generating derived table SQL.

Rules:
- Return ONLY a SQL SELECT statement — no CREATE TABLE wrapper, no markdown fences, no explanation.
- The SELECT must be syntactically valid PostgreSQL and produce all columns needed for analysis.
- Use LOWER() for case-insensitive string comparisons where appropriate.
- Do not add a trailing semicolon.
- If aggregating, include a meaningful GROUP BY.
"""

_DDL_USER_TEMPLATE = """\
Generate the SELECT body for a derived table with this specification:

Target table  : {schema_name}.{table_name}
Description   : {description}

Business purpose:
{business_context}

Source tables (join these):
{source_tables}

Join logic:
{join_logic}

Filter / WHERE conditions:
{filter_logic}

Additional logic (aggregations, CASE expressions, computed columns, etc.):
{additional_logic}

Return only the SELECT statement. It will be wrapped as:
  CREATE TABLE IF NOT EXISTS {schema_name}.{table_name} AS
  <your SELECT here>
"""


# ------------------------------------------------------------------ #
# Context synthesis prompts
# ------------------------------------------------------------------ #

_CTX_SYSTEM = """\
You are a data documentation specialist writing concise, accurate context descriptions \
for derived database tables used in a business-intelligence insights engine.

Your output is consumed by downstream LLMs that generate SQL queries and business insights. \
Make it precise, complete, and useful — not marketing copy.

Return ONLY the description text. No markdown, no headers, no bullet points, no preamble.
"""

_CTX_USER = """\
Write a 3-5 sentence context description for this derived table. Cover:
1. What raw data it is built from and how (joins, aggregations, filters).
2. What business questions it is designed to answer and what KPIs/metrics it surfaces.
3. What recurring analysis patterns it enables (e.g. threshold alerts, trend detection, outlier ranking).
4. Any important domain constraints or data-quality notes a SQL developer should know.

Table name      : {schema_name}.{table_name}
User description: {description}
Business context: {business_context}
Source tables   : {source_tables}
Join logic      : {join_logic}
Filter logic    : {filter_logic}
Additional logic: {additional_logic}

Derived SELECT (actual SQL):
{select_body}
"""


# ------------------------------------------------------------------ #
# Purpose synthesis prompts (used by QueryBuilderService)
# ------------------------------------------------------------------ #

_PURPOSE_SYSTEM = """\
You are a data analyst writing precise purpose statements for SQL analysis queries \
used in an automated business-intelligence insights engine.

Return ONLY the purpose text — 2 sentences maximum. No markdown, no headers.
"""

_PURPOSE_USER = """\
Write a 1-2 sentence purpose statement for this SQL query.
Cover: (1) what metric or signal it measures, (2) what pattern it identifies, \
(3) what PM decision or action it informs.

Analysis goal  : {analysis_goal}
Table context  : {table_context}
"""


class DerivedTableService:
    """Generates and executes derived table DDL via LLM."""

    def __init__(self) -> None:
        self._llm = ChatOpenAI(
            api_key="NONE",
            model=settings.llm_model,
            base_url=settings.llm_api_base_url,
            default_headers={
                "api-key": settings.llm_gateway_api_key,
                "workspacename": settings.llm_workspace_name,
            },
            temperature=0.0,
            max_tokens=2048,
            timeout=settings.llm_timeout_seconds,
            max_retries=0,
        )

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    async def generate_ddl(self, request: DerivedTableRequest) -> str:
        """Call LLM and return a complete CREATE TABLE AS SELECT statement."""
        user_msg = _DDL_USER_TEMPLATE.format(
            schema_name=request.schema_name,
            table_name=request.table_name,
            description=request.description or "N/A",
            business_context=request.business_context,
            source_tables="\n".join(f"  - {t}" for t in request.source_tables),
            join_logic=request.join_logic,
            filter_logic=request.filter_logic or "None",
            additional_logic=request.additional_logic or "None",
        )
        messages = [SystemMessage(content=_DDL_SYSTEM_PROMPT), HumanMessage(content=user_msg)]
        response = await self._llm.ainvoke(messages)
        raw = response.content if isinstance(response.content, str) else ""
        select_body = _clean_sql(raw)
        ddl = (
            f"CREATE TABLE IF NOT EXISTS {request.schema_name}.{request.table_name} AS\n"
            f"{select_body}"
        )
        log.info("DDL generated for %s.%s", request.schema_name, request.table_name)
        return ddl

    async def synthesize_context(self, request: DerivedTableRequest, generated_ddl: str) -> str:
        """
        Call LLM to produce a well-structured, comprehensive context description
        for the derived table.  This synthesises the user's raw inputs and the
        generated DDL into a single coherent paragraph that downstream prompts
        (ideation, query-builder) can consume without re-reading the raw fields.
        """
        select_body = re.sub(
            r"^\s*CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?\S+\s+AS\s*",
            "",
            generated_ddl,
            flags=re.IGNORECASE,
        ).strip()

        user_msg = _CTX_USER.format(
            schema_name=request.schema_name,
            table_name=request.table_name,
            description=request.description or "N/A",
            business_context=request.business_context,
            source_tables=", ".join(request.source_tables),
            join_logic=request.join_logic,
            filter_logic=request.filter_logic or "None",
            additional_logic=request.additional_logic or "None",
            select_body=select_body,
        )
        messages = [SystemMessage(content=_CTX_SYSTEM), HumanMessage(content=user_msg)]
        try:
            response = await self._llm.ainvoke(messages)
            ctx = (response.content or "").strip() if isinstance(response.content, str) else ""
            log.info("Context synthesised for %s.%s (%d chars)", request.schema_name, request.table_name, len(ctx))
            return ctx
        except Exception as exc:
            log.warning("Context synthesis failed for %s.%s: %s", request.schema_name, request.table_name, exc)
            return request.description or request.business_context or ""

    async def create_table(
        self,
        insights_db: AsyncSession,
        source_db: AsyncSession,
        request: DerivedTableRequest,
        created_by: str | None = None,
    ) -> DerivedTableDefinition:
        """
        Generate DDL via LLM, synthesise a rich context description, optionally
        execute the DDL, and persist the definition.

        If ``request.execute`` is False the definition is saved as ``"draft"``
        without touching the source database.
        """
        ddl = await self.generate_ddl(request)

        # Synthesise a comprehensive context description from all inputs + DDL.
        # This becomes the primary context consumed by ideation and query-builder prompts.
        synthesized_description = await self.synthesize_context(request, ddl)

        status = "draft"
        row_count: int | None = None
        last_error: str | None = None
        refreshed_at: datetime | None = None

        if request.execute:
            try:
                await self._run_ddl(source_db, ddl)
                row_count = await self._count_rows(source_db, request.schema_name, request.table_name)
                status = "active"
                refreshed_at = datetime.now(timezone.utc)
                log.info(
                    "Table %s.%s created — %d rows",
                    request.schema_name, request.table_name, row_count or 0,
                )
            except Exception as exc:
                status = "error"
                last_error = str(exc)
                log.error("DDL execution failed: %s", exc, exc_info=True)
                try:
                    await source_db.rollback()
                except Exception:
                    pass

        defn = DerivedTableDefinition(
            table_name=request.table_name,
            schema_name=request.schema_name,
            # Store the LLM-synthesised context as description; keep raw business_context
            description=synthesized_description,
            business_context=request.business_context,
            source_tables=request.source_tables,
            join_logic=request.join_logic,
            filter_logic=request.filter_logic,
            additional_logic=request.additional_logic,
            generated_ddl=ddl,
            refresh_mode=request.refresh_mode,
            status=status,
            last_refreshed_at=refreshed_at,
            last_error=last_error,
            row_count=row_count,
            created_by=created_by,
        )
        insights_db.add(defn)
        await insights_db.commit()
        await insights_db.refresh(defn)
        return defn

    async def refresh_table(
        self,
        insights_db: AsyncSession,
        source_db: AsyncSession,
        defn: DerivedTableDefinition,
    ) -> DerivedTableDefinition:
        """Re-run the stored DDL using the definition's refresh strategy."""
        status = "active"
        last_error: str | None = None
        row_count: int | None = None

        try:
            if defn.refresh_mode == "truncate_insert":
                insert_sql = re.sub(
                    rf"CREATE TABLE IF NOT EXISTS\s+{re.escape(defn.schema_name)}\.{re.escape(defn.table_name)}\s+AS\s*",
                    f"INSERT INTO {defn.schema_name}.{defn.table_name}\n",
                    defn.generated_ddl,
                    flags=re.IGNORECASE,
                )
                await source_db.execute(
                    text(f"TRUNCATE TABLE {defn.schema_name}.{defn.table_name}")
                )
                await source_db.execute(text(insert_sql))
            else:
                await source_db.execute(
                    text(f"DROP TABLE IF EXISTS {defn.schema_name}.{defn.table_name}")
                )
                create_sql = re.sub(r"\bIF NOT EXISTS\b", "", defn.generated_ddl, flags=re.IGNORECASE)
                await source_db.execute(text(create_sql))

            await source_db.commit()
            row_count = await self._count_rows(source_db, defn.schema_name, defn.table_name)
            log.info(
                "Refreshed %s.%s — %d rows",
                defn.schema_name, defn.table_name, row_count or 0,
            )

        except Exception as exc:
            status = "error"
            last_error = str(exc)
            log.error("Refresh failed for %s.%s: %s", defn.schema_name, defn.table_name, exc, exc_info=True)
            try:
                await source_db.rollback()
            except Exception:
                pass

        await insights_db.execute(
            update(DerivedTableDefinition)
            .where(DerivedTableDefinition.table_def_id == defn.table_def_id)
            .values(
                status=status,
                last_refreshed_at=(
                    datetime.now(timezone.utc) if status == "active" else defn.last_refreshed_at
                ),
                last_error=last_error,
                row_count=row_count,
            )
        )
        await insights_db.commit()
        await insights_db.refresh(defn)
        return defn

    # ------------------------------------------------------------------ #
    # Private helpers
    # ------------------------------------------------------------------ #

    @staticmethod
    async def _run_ddl(db: AsyncSession, ddl: str) -> None:
        """Execute DDL directly — bypasses the read-only safety check intentionally."""
        await db.execute(text(ddl))
        await db.commit()

    @staticmethod
    async def _count_rows(db: AsyncSession, schema: str, table: str) -> int | None:
        try:
            result = await db.execute(text(f"SELECT COUNT(*) FROM {schema}.{table}"))
            return result.scalar()
        except Exception:
            return None


def _clean_sql(raw: str) -> str:
    """Strip markdown fences and trailing semicolons."""
    raw = raw.strip()
    raw = re.sub(r"^```(?:sql)?\s*", "", raw, flags=re.IGNORECASE)
    raw = re.sub(r"\s*```$", "", raw)
    return raw.strip().rstrip(";")
