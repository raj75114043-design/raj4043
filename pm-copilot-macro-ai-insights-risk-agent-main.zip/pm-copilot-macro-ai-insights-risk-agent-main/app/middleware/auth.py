"""
JWT Authentication middleware.

Provides:
  - get_current_user dependency for protected endpoints
  - create_access_token utility for token generation
  - Optional auth bypass for development (AUTH_ENABLED=false)

Token format: Bearer <JWT>
JWT payload: { sub: user_id, exp: timestamp }
"""
from __future__ import annotations

import logging
from datetime import datetime, timedelta, timezone

from fastapi import Depends, HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from pydantic import BaseModel

from app.config import get_settings

log = logging.getLogger(__name__)
settings = get_settings()

_bearer = HTTPBearer(auto_error=False)


# ------------------------------------------------------------------ #
# Token models
# ------------------------------------------------------------------ #
class TokenPayload(BaseModel):
    sub: str        # user_id
    exp: datetime


class CurrentUser(BaseModel):
    user_id: str
    is_admin: bool = False


# ------------------------------------------------------------------ #
# Token creation
# ------------------------------------------------------------------ #
def create_access_token(user_id: str, is_admin: bool = False) -> str:
    """Generate a signed JWT access token."""
    expire = datetime.now(timezone.utc) + timedelta(
        minutes=settings.jwt_access_token_expire_minutes
    )
    payload = {
        "sub": user_id,
        "exp": expire,
        "is_admin": is_admin,
    }
    return jwt.encode(payload, settings.jwt_secret_key, algorithm=settings.jwt_algorithm)


# ------------------------------------------------------------------ #
# Dependencies
# ------------------------------------------------------------------ #
async def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Security(_bearer),
) -> CurrentUser:
    """
    FastAPI dependency that validates the Bearer JWT.

    If AUTH_ENABLED=false, returns a default dev user without validation.
    """
    if not settings.auth_enabled:
        return CurrentUser(user_id="dev-user", is_admin=True)

    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )

    try:
        payload = jwt.decode(
            credentials.credentials,
            settings.jwt_secret_key,
            algorithms=[settings.jwt_algorithm],
        )
        user_id: str = payload.get("sub", "")
        if not user_id:
            raise JWTError("Missing subject claim")
        return CurrentUser(
            user_id=user_id,
            is_admin=payload.get("is_admin", False),
        )
    except JWTError as exc:
        log.warning("JWT validation failed: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired token",
            headers={"WWW-Authenticate": "Bearer"},
        ) from exc


async def require_admin(current_user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
    """Dependency that additionally requires admin role."""
    if not current_user.is_admin:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required",
        )
    return current_user
