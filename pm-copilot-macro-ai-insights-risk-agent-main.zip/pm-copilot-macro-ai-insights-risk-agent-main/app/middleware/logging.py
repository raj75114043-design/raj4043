"""
Structured logging middleware.

Adds correlation IDs to every request and emits structured JSON logs
(or colourised text in development) via structlog.
"""
from __future__ import annotations

import logging
import time
import uuid
from typing import Callable

import structlog
from fastapi import Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

from app.config import get_settings

settings = get_settings()

# ------------------------------------------------------------------ #
# Configure structlog once at import time
# ------------------------------------------------------------------ #
_PROCESSORS_JSON = [
    structlog.contextvars.merge_contextvars,
    structlog.stdlib.add_log_level,
    structlog.stdlib.add_logger_name,
    structlog.processors.TimeStamper(fmt="iso"),
    structlog.processors.StackInfoRenderer(),
    structlog.processors.format_exc_info,
    structlog.processors.JSONRenderer(),
]

_PROCESSORS_TEXT = [
    structlog.contextvars.merge_contextvars,
    structlog.stdlib.add_log_level,
    structlog.stdlib.add_logger_name,
    structlog.processors.TimeStamper(fmt="%H:%M:%S"),
    structlog.dev.ConsoleRenderer(),
]

def configure_logging() -> None:
    """Call once at application startup."""
    processors = _PROCESSORS_JSON if settings.log_format == "json" else _PROCESSORS_TEXT

    logging.basicConfig(
        format="%(message)s",
        level=getattr(logging, settings.log_level),
    )

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, settings.log_level)
        ),
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),  # ✅ FIX
        cache_logger_on_first_use=True,
    )

# ------------------------------------------------------------------ #
# Request logging middleware
# ------------------------------------------------------------------ #
class RequestLoggingMiddleware(BaseHTTPMiddleware):
    """
    Attaches a correlation_id to every request and logs:
      - Incoming request (method, path, client IP)
      - Outgoing response (status, latency_ms)
    """

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        correlation_id = request.headers.get("X-Correlation-ID", str(uuid.uuid4()))
        structlog.contextvars.clear_contextvars()
        structlog.contextvars.bind_contextvars(
            correlation_id=correlation_id,
            method=request.method,
            path=request.url.path,
            client_ip=self._get_client_ip(request),
        )

        log = structlog.get_logger()
        log.info("request_started")

        start_time = time.perf_counter()
        response: Response | None = None
        try:
            response = await call_next(request)
        except Exception as exc:
            log.error("request_failed", error=str(exc), exc_info=True)
            raise
        finally:
            latency_ms = (time.perf_counter() - start_time) * 1000
            log.info(
                "request_finished",
                status_code=response.status_code if response is not None else 500,
                latency_ms=round(latency_ms, 2),
            )

        # Propagate correlation ID in response header
        response.headers["X-Correlation-ID"] = correlation_id
        return response

    @staticmethod
    def _get_client_ip(request: Request) -> str:
        forwarded = request.headers.get("X-Forwarded-For")
        if forwarded:
            return forwarded.split(",")[0].strip()
        return request.client.host if request.client else "unknown"
