"""
Insight Agent — Agentic Batch Processing Orchestrator

Coordinates the full insight generation pipeline across all combinations
of (SQL query × geography parameters), managing:
  - Parallel execution with configurable concurrency
  - Progress tracking and job status updates
  - Per-step error handling, logging, and retry
  - Graceful shutdown on cancellation

Architecture
------------
InsightAgent.run()
  └── for each geography_param_set:
        └── for each matching sql_query:
              └── InsightGenerator.generate()   ← async, parallelised
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.database import get_insights_session_factory, get_source_session_factory
from app.models.jobs import BatchJob, BatchJobLog
from app.schemas.admin import GenerateInsightsRequest
from app.services.insight_generator import InsightGenerator, InsightGenerationError
from app.services.sql_executor import SqlQueryLoader
from app.utils.filters import GeoParams, get_geography_loader

log = logging.getLogger(__name__)
settings = get_settings()


class InsightAgent:
    """
    Top-level orchestrator for batch insight generation.

    Usage (called from Celery task or admin API):
        agent = InsightAgent()
        await agent.run(job_id, request)
    """

    def __init__(
        self,
        generator: InsightGenerator | None = None,
        query_loader: SqlQueryLoader | None = None,
    ) -> None:
        self.generator = generator or InsightGenerator()
        self.query_loader = query_loader or SqlQueryLoader()

    # ------------------------------------------------------------------ #
    # Main entry point
    # ------------------------------------------------------------------ #
    async def run(
        self,
        job_id: str,
        request: GenerateInsightsRequest,
    ) -> dict[str, Any]:
        """
        Execute the full batch pipeline for the given job.

        Returns a summary dict suitable for updating the BatchJob record.
        """
        geo = request.geography_filters
        geo_loader = get_geography_loader()

        # ---- Expand geography from dim_geography source table ---- #
        source_factory = get_source_session_factory()
        async with source_factory() as source_db:
            geo_params: list[GeoParams] = await geo_loader.expand(
                source_db,
                level=geo.level if geo else None,
                region=geo.region if geo else None,
                area=geo.area if geo else None,
                market=geo.market if geo else None,
            )

        log.info(
            "Job %s starting — %d geography param sets to process",
            job_id,
            len(geo_params),
        )

        # ---- Mark job as running ---- #
        await self._update_job(job_id, status="running", started_at=datetime.now(timezone.utc))

        total_queries = 0
        completed = 0
        failed = 0
        total_insights = 0

        # Determine batch concurrency
        max_parallel = request.max_parallel or settings.batch_max_parallel
        semaphore = asyncio.Semaphore(max_parallel)

        # Timeframe params
        timeframe = request.timeframe
        start_date = str(timeframe.start_date) if timeframe and timeframe.start_date else ""
        end_date = str(timeframe.end_date) if timeframe and timeframe.end_date else ""

        # ---- Build work items list ---- #
        # Load queries once per distinct geo level, not once per geo_param.
        # With 50 market geo_params that share the same level, this reduces
        # DB calls from 50 to 1.
        from collections import defaultdict
        insights_factory = get_insights_session_factory()

        async with insights_factory() as insights_db:
            # Group geo_params by their level (overall / region / area / market)
            geo_by_level: dict[str, list[GeoParams]] = defaultdict(list)
            for gp in geo_params:
                geo_by_level[gp.level].append(gp)

            all_work_items: list[tuple[Any, GeoParams]] = []
            for level, level_geo_params in geo_by_level.items():
                queries = await self.query_loader.load_queries(
                    insights_db,
                    geography_level=level,
                    projects=request.projects,
                    functions=request.functions,
                    pack_ids=request.pack_ids,
                    query_ids=request.query_ids,
                )
                for q in queries:
                    for gp in level_geo_params:
                        all_work_items.append((q, gp))

        total_queries = len(all_work_items)
        log.info("Job %s — total work items (query × geo): %d", job_id, total_queries)
        await self._update_job(job_id, total_queries=total_queries)

        # ---- Execute all work items in bounded parallel ---- #
        _vendor_grouping = getattr(request, "vendor_grouping", False)
        tasks = [
            self._run_single(
                job_id=job_id,
                query=q,
                geo=gp,
                start_date=start_date,
                end_date=end_date,
                semaphore=semaphore,
                vendor_grouping=_vendor_grouping,
            )
            for q, gp in all_work_items
        ]

        results = await asyncio.gather(*tasks, return_exceptions=True)

        insight_ids: list[str] = []
        for res in results:
            if isinstance(res, Exception):
                failed += 1
                log.error("Work item failed: %s", res)
            elif isinstance(res, str):
                # res is the insight_id
                completed += 1
                total_insights += 1
                insight_ids.append(res)
            else:
                # res is None → no rows returned / skipped
                completed += 1

        # ---- Elect pack summary insights ---- #
        # For each InsightPack that produced results in this job, mark the
        # insight with the highest severity_score as is_pack_summary=True.
        # This is the "hero" card shown on the home feed for the pack.
        packs_scored = await self._score_packs(job_id)
        log.info("Job %s — pack scoring complete (%d packs scored)", job_id, packs_scored)

        # ---- Finalise job record ---- #
        status = "completed" if failed == 0 else "completed_with_errors"
        await self._update_job(
            job_id,
            status=status,
            completed_queries=completed,
            failed_queries=failed,
            total_insights_generated=total_insights,
            progress_pct=100.0,
            completed_at=datetime.now(timezone.utc),
            insight_ids=insight_ids,
        )

        summary = {
            "job_id": job_id,
            "status": status,
            "total_queries": total_queries,
            "completed_queries": completed,
            "failed_queries": failed,
            "total_insights_generated": total_insights,
            "packs_scored": packs_scored,
            "insight_ids": insight_ids,
        }
        log.info("Job %s finished: %s", job_id, summary)
        return summary

    # ------------------------------------------------------------------ #
    # Single work item execution
    # ------------------------------------------------------------------ #
    async def _run_single(
        self,
        job_id: str,
        query: Any,
        geo: GeoParams,
        start_date: str,
        end_date: str,
        semaphore: asyncio.Semaphore,
        vendor_grouping: bool = False,
    ) -> str | None:
        """Execute one (query, geo) pair. Returns insight_id or None."""
        async with semaphore:
            insights_factory = get_insights_session_factory()
            source_factory = get_source_session_factory()

            async with insights_factory() as insights_db, source_factory() as source_db:
                try:
                    insight = await self.generator.generate(
                        query=query,
                        geo=geo,
                        start_date=start_date,
                        end_date=end_date,
                        insights_db=insights_db,
                        source_db=source_db,
                        job_id=job_id,
                        vendor_grouping=vendor_grouping,
                    )
                    await self._log_step(
                        job_id,
                        level="INFO",
                        step="insight_generated",
                        query_id=str(query.query_id),
                        message=f"Insight created for {geo.label()} — {query.name}",
                        details={"insight_id": insight.insight_id if insight else None},
                    )
                    return insight.insight_id if insight else None

                except InsightGenerationError as exc:
                    await self._log_step(
                        job_id,
                        level="ERROR",
                        step="insight_generation_failed",
                        query_id=str(query.query_id),
                        message=str(exc),
                    )
                    raise  # re-raise to be caught by gather()

                except Exception as exc:
                    await self._log_step(
                        job_id,
                        level="ERROR",
                        step="unexpected_error",
                        query_id=str(query.query_id),
                        message=f"Unexpected error: {exc}",
                    )
                    raise

    # ------------------------------------------------------------------ #
    # Pack scoring
    # ------------------------------------------------------------------ #
    async def _score_packs(self, job_id: str) -> int:
        """
        For every InsightPack that has insights in this job:
          1. Reset is_pack_summary=False for all insights in the pack+job.
          2. Elect the insight with the highest severity_score (or most
             recent created_at as a tie-breaker) as is_pack_summary=True.

        Returns the number of packs scored.
        """
        from sqlalchemy import select, update, func as sqlfunc
        from app.models.insights import Insight

        factory = get_insights_session_factory()
        async with factory() as db:
            # Find distinct pack_ids produced in this job (NULL pack_id = unpacked, skip)
            pack_stmt = (
                select(Insight.pack_id)
                .where(
                    Insight.job_id == job_id,
                    Insight.pack_id.is_not(None),
                    Insight.is_active.is_(True),
                )
                .distinct()
            )
            result = await db.execute(pack_stmt)
            pack_ids: list[str] = [row[0] for row in result.all()]

            if not pack_ids:
                return 0

            scored = 0
            for pack_id in pack_ids:
                # Step 1: reset all to False
                await db.execute(
                    update(Insight)
                    .where(Insight.job_id == job_id, Insight.pack_id == pack_id)
                    .values(is_pack_summary=False)
                )

                # Step 2: find the winner — highest severity, newest as tie-breaker
                winner_stmt = (
                    select(Insight.insight_id)
                    .where(
                        Insight.job_id == job_id,
                        Insight.pack_id == pack_id,
                        Insight.is_active.is_(True),
                    )
                    .order_by(
                        Insight.severity_score.desc().nullslast(),
                        Insight.created_at.desc(),
                    )
                    .limit(1)
                )
                winner_result = await db.execute(winner_stmt)
                winner_id = winner_result.scalar_one_or_none()

                if winner_id:
                    await db.execute(
                        update(Insight)
                        .where(Insight.insight_id == winner_id)
                        .values(is_pack_summary=True)
                    )
                    log.debug(
                        "Pack %s — elected summary insight %s (job %s)",
                        pack_id, winner_id, job_id,
                    )
                    scored += 1

            await db.commit()
            return scored

    # ------------------------------------------------------------------ #
    # Job management helpers
    # ------------------------------------------------------------------ #
    async def _update_job(self, job_id: str, **fields: Any) -> None:
        """Update BatchJob fields atomically."""
        from sqlalchemy import update
        factory = get_insights_session_factory()
        async with factory() as db:
            await db.execute(
                update(BatchJob)
                .where(BatchJob.job_id == job_id)
                .values(**fields)
            )
            await db.commit()

    async def _log_step(
        self,
        job_id: str,
        *,
        level: str = "INFO",
        step: str | None = None,
        query_id: str | None = None,
        message: str,
        details: dict | None = None,
    ) -> None:
        """Append a log entry to batch_job_logs."""
        factory = get_insights_session_factory()
        async with factory() as db:
            log_entry = BatchJobLog(
                job_id=job_id,
                level=level,
                step=step,
                query_id=query_id,
                message=message,
                details=details,
            )
            db.add(log_entry)
            await db.commit()
