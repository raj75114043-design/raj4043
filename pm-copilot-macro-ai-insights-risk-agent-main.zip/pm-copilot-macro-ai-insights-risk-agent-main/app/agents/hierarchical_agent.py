"""
Hierarchical Insight Agent

Runs insight generation through the geography hierarchy with LLM-driven
routing at each level.

Flow
----
1. Run OVERALL level — queries against the full dataset (no geo filter).
2. LLM reviews overall insights → selects which REGIONs need deeper investigation.
3. For each flagged REGION — run queries scoped to that region.
4. LLM reviews region insights → selects which AREAs need deeper investigation.
5. For each flagged AREA — run queries scoped to that area.
6. LLM reviews area insights → selects which MARKETs need deeper investigation.
7. For each flagged MARKET — run queries scoped to that market. Stop drilling.
8. Generate one overall summary that synthesises all lower-level findings.
9. Pack scoring elects the highest-severity insight as the hero card.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.database import get_insights_session_factory, get_source_session_factory
from app.models.jobs import BatchJob, BatchJobLog
from app.services.drill_down_router import DrillDownRouter
from app.services.insight_generator import InsightGenerator, InsightGenerationError
from app.services.sql_executor import SqlQueryLoader
from app.utils.filters import GeoParams, get_geography_loader

log = logging.getLogger(__name__)
settings = get_settings()

_LEVELS = ["overall", "region", "area", "market"]
_CHILD_OF: dict[str, str | None] = {
    "overall": "region",
    "region": "area",
    "area": "market",
    "market": None,
}


class HierarchicalInsightAgent:
    """
    Top-down, LLM-routed insight generation across the geography hierarchy.

    Usage:
        agent = HierarchicalInsightAgent()
        await agent.run(job_id, request)
    """

    def __init__(
        self,
        generator: InsightGenerator | None = None,
        query_loader: SqlQueryLoader | None = None,
        router: DrillDownRouter | None = None,
    ) -> None:
        self.generator = generator or InsightGenerator()
        self.query_loader = query_loader or SqlQueryLoader()
        self.router = router or DrillDownRouter()
        self._total_insights = 0
        self._total_queries = 0
        self._failed = 0
        self._insight_ids: list[str] = []

    # ------------------------------------------------------------------ #
    # Main entry point
    # ------------------------------------------------------------------ #
    async def run(self, job_id: str, request: Any) -> dict[str, Any]:
        """
        Execute the hierarchical pipeline for the given job.

        Flow:
          1. Run OVERALL level — queries against full dataset (no geo filter).
          2. LLM router selects REGIONs to drill into.
          3. For each flagged region → run queries → router → select AREAs.
          4. For each flagged area → run queries → router → select MARKETs.
          5. For each flagged market → run queries (terminal level).
          6. Generate one overall summary synthesising all lower-level findings.
          7. Pack scoring elects the highest-severity insight as hero card.

        `request` must have:
          - timeframe (TimeframeFilter | None)
          - projects / functions / pack_ids / query_ids (list | None)
          - max_parallel (int | None)
          - max_depth (int)              — how many levels to drill (default 4)
          - max_children_per_level (int) — max children to drill per node (default 3)
          - severity_floor (float)       — min avg severity to trigger drilling (default 40)
        """
        await self._update_job(job_id, status="running", started_at=datetime.now(timezone.utc))

        timeframe = request.timeframe
        start_date = str(timeframe.start_date) if timeframe and timeframe.start_date else ""
        end_date = str(timeframe.end_date) if timeframe and timeframe.end_date else ""

        semaphore = asyncio.Semaphore(request.max_parallel or settings.batch_max_parallel)

        # Start at the OVERALL level — queries run against the full dataset
        # (no geography filter) to produce genuine top-level insights.
        overall_node = [GeoParams(level="overall")]

        log.info("Job %s — starting hierarchical run at overall level", job_id)

        # Overall → region → area → market drilling (depth starts at 0).
        # The overall level runs real SQL queries, then the LLM router decides
        # which regions to drill into, and so on down the hierarchy.
        try:
            await self._run_at_level(
                job_id=job_id,
                request=request,
                geo_nodes=overall_node,
                start_date=start_date,
                end_date=end_date,
                semaphore=semaphore,
                depth=0,
            )
        except Exception as exc:
            log.error("Job %s — hierarchical drilling failed, continuing: %s", job_id, exc, exc_info=True)
            self._failed += 1

        # Generate one overall synthesis insight that aggregates findings
        # from all levels (overall + region + area + market) into one
        # executive summary card.
        try:
            await self._generate_overall_summary(
                job_id=job_id,
                request=request,
                start_date=start_date,
                end_date=end_date,
            )
        except Exception as exc:
            log.error("Job %s — overall summary failed, continuing: %s", job_id, exc, exc_info=True)
            self._failed += 1

        # Elect pack summaries after all levels are done
        packs_scored = 0
        try:
            packs_scored = await self._score_packs(job_id)
            log.info("Job %s — pack scoring complete (%d packs)", job_id, packs_scored)
        except Exception as exc:
            log.error("Job %s — pack scoring failed: %s", job_id, exc, exc_info=True)

        status = "completed" if self._failed == 0 else "completed_with_errors"
        await self._update_job(
            job_id,
            status=status,
            completed_queries=self._total_queries - self._failed,
            failed_queries=self._failed,
            total_insights_generated=self._total_insights,
            progress_pct=100.0,
            completed_at=datetime.now(timezone.utc),
            insight_ids=self._insight_ids,
        )

        return {
            "job_id": job_id,
            "status": status,
            "total_queries_run": self._total_queries,
            "failed_queries": self._failed,
            "total_insights_generated": self._total_insights,
            "packs_scored": packs_scored,
            "insight_ids": self._insight_ids,
        }

    # ------------------------------------------------------------------ #
    # Recursive level runner
    # ------------------------------------------------------------------ #
    async def _run_at_level(
        self,
        job_id: str,
        request: Any,
        geo_nodes: list[GeoParams],
        start_date: str,
        end_date: str,
        semaphore: asyncio.Semaphore,
        depth: int,
    ) -> None:
        if not geo_nodes:
            return

        level = geo_nodes[0].level
        child_level = _CHILD_OF.get(level)
        max_depth = getattr(request, "max_depth", 4)

        log.info(
            "Job %s — depth=%d level=%s nodes=%d",
            job_id, depth, level, len(geo_nodes),
        )

        # Load ALL active queries — no level filter.
        # SQL queries are geography-agnostic (null-safe params + GROUP BY finest grain),
        # so the same query runs correctly at every scope. The geo params bound at
        # execution time naturally scope the results to the current node.
        insights_factory = get_insights_session_factory()
        async with insights_factory() as insights_db:
            queries = await self.query_loader.load_queries(
                insights_db,
                geography_level=None,
                projects=getattr(request, "projects", None),
                functions=getattr(request, "functions", None),
                pack_ids=getattr(request, "pack_ids", None),
                query_ids=getattr(request, "query_ids", None),
            )

        if not queries:
            log.info("Job %s — no queries for level=%s, skipping", job_id, level)
            return

        # Run all (query × geo_node) pairs in bounded parallel
        _vendor_grouping = getattr(request, "vendor_grouping", False)
        tasks = [
            self._run_single(
                job_id=job_id,
                query=q,
                geo=gp,
                start_date=start_date,
                end_date=end_date,
                semaphore=semaphore,
                vendor_grouping=_vendor_grouping,
            )
            for gp in geo_nodes
            for q in queries
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Collect insights by geo node for routing decisions
        # results is a list of (list[Insight] | Exception) in order
        node_insights: dict[str, list] = {gp.get_name(): [] for gp in geo_nodes}
        idx = 0
        for gp in geo_nodes:
            for _ in queries:
                res = results[idx]
                idx += 1
                if isinstance(res, Exception):
                    self._failed += 1
                elif isinstance(res, list):
                    node_insights[gp.get_name()].extend(res)

        # Stop drilling if we've reached max depth or there's no child level
        if not child_level or depth >= max_depth - 1:
            return

        # For each geo node, ask the router which children to explore
        source_factory = get_source_session_factory()
        geo_loader = get_geography_loader()

        for gp in geo_nodes:
            node_name = gp.get_name()
            insights_here = node_insights.get(node_name, [])

            try:
                # Get available children from the geo hierarchy
                async with source_factory() as source_db:
                    child_geo_params = await geo_loader.expand(
                        source_db,
                        level=child_level,
                        region=gp.region,
                        area=gp.area,
                        market=gp.market,
                    )

                if not child_geo_params:
                    continue

                available_children = [cgp.get_name() for cgp in child_geo_params]
                log.info(
                    "Job %s — drill-down: %s=%s has %d %s children: %s",
                    job_id, level, node_name, len(available_children),
                    child_level, available_children,
                )

                # Ask the LLM router which children need deeper investigation
                to_explore = await self.router.decide(
                    current_level=level,
                    current_node=node_name or "Overall",
                    insights=insights_here,
                    available_children=available_children,
                    max_children=getattr(request, "max_children_per_level", 3),
                    severity_floor=getattr(request, "severity_floor", 40.0),
                )

                if not to_explore:
                    log.info(
                        "Job %s — no children flagged for drill-down under %s=%s",
                        job_id, level, node_name,
                    )
                    continue

                await self._log_step(
                    job_id,
                    level="INFO",
                    step="drill_down_decision",
                    message=(
                        f"Drilling into {len(to_explore)} {child_level}(s) "
                        f"under {level}={node_name}: {to_explore}"
                    ),
                )

                # Filter to only flagged children
                selected = [cgp for cgp in child_geo_params if cgp.get_name() in to_explore]
                log.info(
                    "Job %s — selected %d %s(s) under %s=%s: %s",
                    job_id, len(selected), child_level, level, node_name,
                    [(s.get_name(), f"region={s.region}") for s in selected],
                )

                # Recurse into the next level
                await self._run_at_level(
                    job_id=job_id,
                    request=request,
                    geo_nodes=selected,
                    start_date=start_date,
                    end_date=end_date,
                    semaphore=semaphore,
                    depth=depth + 1,
                )

            except Exception as exc:
                self._failed += 1
                log.error(
                    "Job %s — drill-down failed for %s=%s: %s",
                    job_id, level, node_name, exc, exc_info=True,
                )
                await self._log_step(
                    job_id,
                    level="ERROR",
                    step="drill_down_failed",
                    message=f"Drill-down failed for {level}={node_name}: {exc}",
                )

    # ------------------------------------------------------------------ #
    # Single (query, geo) execution
    # ------------------------------------------------------------------ #
    async def _run_single(
        self,
        job_id: str,
        query: Any,
        geo: GeoParams,
        start_date: str,
        end_date: str,
        semaphore: asyncio.Semaphore,
        vendor_grouping: bool = False,
    ):
        """Execute one (query, geo) pair. Returns list of Insights."""
        async with semaphore:
            self._total_queries += 1
            insights_factory = get_insights_session_factory()
            source_factory = get_source_session_factory()

            async with insights_factory() as insights_db, source_factory() as source_db:
                try:
                    insights = await self.generator.generate_all_areas(
                        query=query,
                        geo=geo,
                        start_date=start_date,
                        end_date=end_date,
                        insights_db=insights_db,
                        source_db=source_db,
                        job_id=job_id,
                        vendor_grouping=vendor_grouping,
                    )
                    self._total_insights += len(insights)
                    self._insight_ids.extend(i.insight_id for i in insights)
                    areas_str = f" ({len(insights)} areas)" if len(insights) > 1 else ""
                    await self._log_step(
                        job_id,
                        level="INFO",
                        step="insight_generated",
                        query_id=str(query.query_id),
                        message=f"Insight for {geo.label()} — {query.name}{areas_str}",
                        details={
                            "insight_ids": [i.insight_id for i in insights],
                            "insight_areas": [i.insight_area for i in insights],
                        },
                    )
                    return insights

                except InsightGenerationError as exc:
                    await self._log_step(
                        job_id,
                        level="ERROR",
                        step="insight_generation_failed",
                        query_id=str(query.query_id),
                        message=str(exc),
                    )
                    raise

                except Exception as exc:
                    await self._log_step(
                        job_id,
                        level="ERROR",
                        step="unexpected_error",
                        query_id=str(query.query_id),
                        message=f"Unexpected error: {exc}",
                    )
                    raise

    # ------------------------------------------------------------------ #
    # Overall summary — one insight that synthesises all lower-level findings
    # ------------------------------------------------------------------ #
    async def _generate_overall_summary(
        self,
        job_id: str,
        request: Any,
        start_date: str,
        end_date: str,
    ) -> None:
        """
        Collect all insights generated in this job and produce one overall
        summary **per insight_area**.

        If insights have no insight_area (single-area queries), they all go
        into one summary.  If multiple areas exist, each area gets its own
        overall insight so the PM sees separate cards on the home screen —
        one per analysis angle.
        """
        from collections import defaultdict

        from sqlalchemy import select

        from app.models.insights import Insight

        factory = get_insights_session_factory()

        async with factory() as db:
            stmt = (
                select(Insight)
                .where(Insight.job_id == job_id, Insight.is_active.is_(True))
                .order_by(Insight.severity_score.desc().nullslast())
            )
            result = await db.execute(stmt)
            all_insights = list(result.scalars().all())

        if not all_insights:
            log.info("Job %s — no insights to summarise, skipping overall", job_id)
            return

        by_area: dict[str | None, list[Insight]] = defaultdict(list)
        for ins in all_insights:
            by_area[ins.insight_area].append(ins)

        area_keys = sorted(by_area.keys(), key=lambda x: (x is None, x or ""))
        log.info(
            "Job %s — generating %d overall summary(ies) for areas: %s",
            job_id, len(area_keys),
            [a or "(general)" for a in area_keys],
        )

        for area_key in area_keys:
            await self._generate_one_overall_summary(
                job_id=job_id,
                insights=by_area[area_key],
                insight_area=area_key,
                start_date=start_date,
                end_date=end_date,
                factory=factory,
            )

    async def _generate_one_overall_summary(
        self,
        job_id: str,
        insights: list,
        insight_area: str | None,
        start_date: str,
        end_date: str,
        factory: Any,
    ) -> None:
        """Generate a single overall summary for one insight_area group."""
        from collections import Counter
        from datetime import timedelta
        from string import Template

        from app.models.insights import Insight
        from app.services.embedding_service import EmbeddingService
        from app.services.llm_service import LLMService
        from app.utils.prompt_library import BASE_SYSTEM_PROMPT, BUILT_IN_TEMPLATES

        area_label = insight_area or "(general)"

        # ---- Collect union of metadata from child insights ---- #
        all_projects: set[str] = set()
        all_functions: set[str] = set()
        all_teams: set[str] = set()
        all_pack_ids: set[str] = set()
        all_query_ids: set[str] = set()
        all_site_ids: list[str] = []
        seen_sites: set[str] = set()
        for ins in insights:
            if ins.projects:
                all_projects.update(ins.projects)
            if ins.functions:
                all_functions.update(ins.functions)
            if ins.team:
                all_teams.add(ins.team)
            if ins.pack_id:
                all_pack_ids.add(ins.pack_id)
            if ins.query_id:
                all_query_ids.add(ins.query_id)
            if ins.site_ids:
                for sid in ins.site_ids:
                    if sid not in seen_sites:
                        seen_sites.add(sid)
                        all_site_ids.append(sid)

        # ---- Group by geo_level ---- #
        by_level: dict[str, list] = {"overall": [], "region": [], "area": [], "market": []}
        for ins in insights:
            level_key = ins.geo_level or "market"
            if level_key in by_level:
                by_level[level_key].append(ins)

        def _fmt(insights_list: list) -> str:
            if not insights_list:
                return "(none investigated at this level)"
            lines: list[str] = []
            for ins in insights_list:
                geo = ins.market or ins.area or ins.region or "All Geographies"
                score = f"{ins.severity_score:.0f}" if ins.severity_score is not None else "?"
                lines.append(f"- [{score}/100] {geo}: {ins.title} — {ins.insight}")
            return "\n".join(lines)

        # ---- Build synthesis prompt ---- #
        template_str = BUILT_IN_TEMPLATES.get(
            "hierarchical_summary",
            BUILT_IN_TEMPLATES["executive_summary_insight"],
        )
        user_prompt = Template(template_str).safe_substitute(
            start_date=start_date or "N/A",
            end_date=end_date or "N/A",
            insight_count=str(len(insights)),
            overall_count=str(len(by_level["overall"])),
            region_count=str(len(by_level["region"])),
            area_count=str(len(by_level["area"])),
            market_count=str(len(by_level["market"])),
            overall_insights=_fmt(by_level["overall"]),
            region_insights=_fmt(by_level["region"]),
            area_insights=_fmt(by_level["area"]),
            market_insights=_fmt(by_level["market"]),
        )

        if insight_area:
            user_prompt += (
                f"\n\n## Analysis Focus Area\n"
                f"All findings above are specifically about: **{insight_area}**.\n"
                f"Your overall summary must focus exclusively on this area. "
                f"The title should reflect this focus area."
            )

        # ---- Call LLM ---- #
        llm = LLMService()
        try:
            llm_dict = await llm.generate_insight(BASE_SYSTEM_PROMPT, user_prompt)
        except Exception as exc:
            log.error(
                "Job %s — overall insight LLM call failed for area=%s: %s",
                job_id, area_label, exc,
            )
            await self._log_step(
                job_id,
                level="ERROR",
                step="overall_summary_failed",
                message=f"LLM synthesis failed for area={area_label}: {exc}",
            )
            return

        # ---- Build source_data as a drill-down table of child insights ---- #
        source_rows: list[dict] = []
        for ins in insights:
            source_rows.append({
                "title": ins.title,
                "insight": ins.insight,
                "severity_score": ins.severity_score,
                "geo_level": ins.geo_level,
                "region": ins.region,
                "area": ins.area,
                "market": ins.market,
                "site_count": ins.site_count,
                "insight_id": ins.insight_id,
                "insight_area": ins.insight_area,
            })

        # ---- Persist the overall insight ---- #
        base_tags: list[str] = list(llm_dict.get("tags") or [])
        if "overall-summary" not in base_tags:
            base_tags.append("overall-summary")
        if "hierarchical" not in base_tags:
            base_tags.append("hierarchical")

        dominant_pack_id = None
        if all_pack_ids:
            pack_counts = Counter(
                ins.pack_id for ins in insights if ins.pack_id
            )
            dominant_pack_id = pack_counts.most_common(1)[0][0]

        create_schema = llm.llm_dict_to_create_schema(llm_dict, overrides={
            "geo_level": "overall",
            "insight_area": insight_area,
            "region": None,
            "area": None,
            "market": None,
            "job_id": job_id,
            "is_pack_summary": False,
            "tags": base_tags,
            "projects": sorted(all_projects) if all_projects else None,
            "functions": sorted(all_functions) if all_functions else None,
            "team": ", ".join(sorted(all_teams)) if all_teams else None,
            "pack_id": dominant_pack_id,
            "prompt_template_id": "hierarchical_summary",
            "llm_model": settings.llm_model,
            "expires_at": (
                datetime.now(timezone.utc)
                + timedelta(days=settings.insight_expiry_days)
            ),
            "query_id": (
                next(iter(all_query_ids)) if len(all_query_ids) == 1 else None
            ),
            "source_data": source_rows,
            "site_ids": all_site_ids if all_site_ids else None,
            "site_count": (
                len(all_site_ids) if all_site_ids
                else self._sum_site_count_finest_level(insights)
            ),
        })

        async with factory() as db:
            insight = Insight(**create_schema.model_dump())
            db.add(insight)
            await db.flush()

            emb_text = EmbeddingService.build_embedding_text(
                insight.title, insight.insight, insight.tags
            )
            try:
                emb_svc = EmbeddingService()
                await emb_svc.embed_and_store(db, insight.insight_id, emb_text)
            except Exception as exc:
                log.warning(
                    "Embedding failed for overall insight %s: %s",
                    insight.insight_id, exc,
                )

            await db.commit()
            self._total_insights += 1
            self._insight_ids.append(insight.insight_id)
            log.info(
                "Overall insight created: id=%s area=%s title=%r (from %d child insights)",
                insight.insight_id, area_label, insight.title, len(insights),
            )

        await self._log_step(
            job_id,
            level="INFO",
            step="overall_summary_generated",
            message=(
                f"Overall insight for area={area_label} generated from "
                f"{len(insights)} findings across "
                f"{len(by_level['overall'])} overall, "
                f"{len(by_level['region'])} regions, "
                f"{len(by_level['area'])} areas, {len(by_level['market'])} markets"
            ),
            details={"insight_id": insight.insight_id, "insight_area": insight_area},
        )

    @staticmethod
    def _sum_site_count_finest_level(insights: list) -> int | None:
        """Sum site_count from the finest (most granular) geo level only."""
        _GEO_PRIORITY = ["market", "area", "region"]
        for level in _GEO_PRIORITY:
            level_insights = [
                ins for ins in insights
                if ins.geo_level == level and ins.site_count
            ]
            if level_insights:
                return sum(ins.site_count for ins in level_insights)
        return None

    # ------------------------------------------------------------------ #
    # Pack scoring (same as flat agent)
    # ------------------------------------------------------------------ #
    async def _score_packs(self, job_id: str) -> int:
        from sqlalchemy import select, update
        from app.models.insights import Insight

        factory = get_insights_session_factory()
        async with factory() as db:
            pack_stmt = (
                select(Insight.pack_id)
                .where(
                    Insight.job_id == job_id,
                    Insight.pack_id.is_not(None),
                    Insight.is_active.is_(True),
                )
                .distinct()
            )
            result = await db.execute(pack_stmt)
            pack_ids = [row[0] for row in result.all()]

            if not pack_ids:
                return 0

            scored = 0
            for pack_id in pack_ids:
                await db.execute(
                    update(Insight)
                    .where(Insight.job_id == job_id, Insight.pack_id == pack_id)
                    .values(is_pack_summary=False)
                )
                # Exclude overall-level insights from hero card selection.
                # Overall insights are synthesis summaries — the hero card
                # should be the highest-severity finding from a specific
                # geography (region/area/market) so the PM sees the most
                # actionable item first.
                winner_stmt = (
                    select(Insight.insight_id)
                    .where(
                        Insight.job_id == job_id,
                        Insight.pack_id == pack_id,
                        Insight.is_active.is_(True),
                        Insight.geo_level != "overall",
                    )
                    .order_by(
                        Insight.severity_score.desc().nullslast(),
                        Insight.created_at.desc(),
                    )
                    .limit(1)
                )
                winner_id = (await db.execute(winner_stmt)).scalar_one_or_none()
                if winner_id:
                    await db.execute(
                        update(Insight)
                        .where(Insight.insight_id == winner_id)
                        .values(is_pack_summary=True)
                    )
                    scored += 1

            await db.commit()
            return scored

    # ------------------------------------------------------------------ #
    # Job / log helpers
    # ------------------------------------------------------------------ #
    async def _update_job(self, job_id: str, **fields: Any) -> None:
        from sqlalchemy import update
        factory = get_insights_session_factory()
        async with factory() as db:
            await db.execute(
                update(BatchJob).where(BatchJob.job_id == job_id).values(**fields)
            )
            await db.commit()

    async def _log_step(
        self,
        job_id: str,
        *,
        level: str = "INFO",
        step: str | None = None,
        query_id: str | None = None,
        message: str,
        details: dict | None = None,
    ) -> None:
        factory = get_insights_session_factory()
        async with factory() as db:
            db.add(BatchJobLog(
                job_id=job_id,
                level=level,
                step=step,
                query_id=query_id,
                message=message,
                details=details,
            ))
            await db.commit()
