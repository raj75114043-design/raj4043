"""
Insights Engine — FastAPI Application Entry Point

Startup sequence:
  1. Configure structured logging
  2. Connect to databases
  3. Register middleware (CORS, logging, rate limiting)
  4. Mount API routers
  5. Register error handlers
  6. Expose health + metrics endpoints
"""
from __future__ import annotations

from contextlib import asynccontextmanager
from typing import Any

import structlog
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from app.config import get_settings
from app.database import close_db, init_db
from app.middleware.error_handler import register_error_handlers
from app.middleware.logging import RequestLoggingMiddleware, configure_logging

settings = get_settings()
configure_logging()
log = structlog.get_logger(__name__)


# ------------------------------------------------------------------ #
# Lifespan (startup / shutdown)
# ------------------------------------------------------------------ #
@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("Starting Insights Engine", version=settings.app_version, env=settings.app_env)
    await init_db()
    log.info("Database ready")
    yield
    log.info("Shutting down")
    await close_db()


# ------------------------------------------------------------------ #
# App factory
# ------------------------------------------------------------------ #
def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.app_name,
        version=settings.app_version,
        description=(
            "Production-grade AI-powered insights generation and management system. "
            "Provides LLM-driven batch processing, semantic search, and reversible "
            "user interaction tracking."
        ),
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        lifespan=lifespan,
    )

    # ---- Middleware (order matters — outermost first) ---- #
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=settings.cors_allow_credentials,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["X-Correlation-ID"],
    )
    app.add_middleware(RequestLoggingMiddleware)

    # ---- Error handlers ---- #
    register_error_handlers(app)

    # ---- Static files ---- #
    import os
    static_dir = os.path.join(os.path.dirname(__file__), "static")
    if os.path.isdir(static_dir):
        app.mount("/static", StaticFiles(directory=static_dir), name="static")

    # ---- Routers ---- #
    from app.api.v1 import router as v1_router
    app.include_router(v1_router)

    # ---- Prometheus metrics ---- #
    if settings.prometheus_enabled:
        try:
            from prometheus_fastapi_instrumentator import Instrumentator
            Instrumentator().instrument(app).expose(app, endpoint="/metrics")
        except ImportError:
            log.warning("prometheus_fastapi_instrumentator not installed — metrics disabled")

    # ---- Health / utility endpoints ---- #
    _register_health_endpoints(app)

    return app


# ------------------------------------------------------------------ #
# Health endpoints
# ------------------------------------------------------------------ #
def _register_health_endpoints(app: FastAPI) -> None:

    @app.get("/health", tags=["Health"], include_in_schema=False)
    async def health() -> dict[str, Any]:
        """Basic liveness probe."""
        return {"status": "healthy", "version": settings.app_version}

    @app.get("/health/ready", tags=["Health"], include_in_schema=False)
    async def readiness() -> JSONResponse:
        """
        Readiness probe — checks database and Redis connectivity.
        Returns 503 if any dependency is unavailable.
        """
        checks: dict[str, str] = {}
        all_ok = True

        if settings.health_check_db:
            try:
                from sqlalchemy import text
                from app.database import get_insights_engine
                async with get_insights_engine().connect() as conn:
                    await conn.execute(text("SELECT 1"))
                checks["database"] = "ok"
            except Exception as exc:
                checks["database"] = f"error: {exc}"
                all_ok = False

        if settings.health_check_redis:
            try:
                from app.database import get_redis
                redis = get_redis()
                await redis.ping()
                checks["redis"] = "ok"
            except Exception as exc:
                checks["redis"] = f"error: {exc}"
                all_ok = False

        status_code = 200 if all_ok else 503
        return JSONResponse(
            status_code=status_code,
            content={"status": "ready" if all_ok else "not_ready", "checks": checks},
        )

    @app.get("/", include_in_schema=False)
    async def root() -> dict[str, str]:
        return {
            "service": settings.app_name,
            "version": settings.app_version,
            "docs": "/docs",
        }


# ------------------------------------------------------------------ #
# App instance (used by Uvicorn / Gunicorn)
# ------------------------------------------------------------------ #
app = create_app()
