"""
Async SQLAlchemy engine and session factory.
Provides connection pools for both the insights DB and the source DB.
"""
from __future__ import annotations

import logging
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any

import redis.asyncio as aioredis
from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import (
    AsyncEngine,
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy import MetaData
from sqlalchemy.orm import DeclarativeBase

from app.config import get_settings

log = logging.getLogger(__name__)
settings = get_settings()


# ------------------------------------------------------------------ #
# ORM Base
# All tables inherit this schema — driven by DB_SCHEMA in settings.
# effective_schema returns None for "public" (no explicit prefix needed)
# and the schema name for any custom schema (e.g. pwc_derived_tables_schema).
# ------------------------------------------------------------------ #
class Base(DeclarativeBase):
    """Shared declarative base for all ORM models."""
    metadata = MetaData(schema=settings.effective_schema)


# ------------------------------------------------------------------ #
# Engine factory
# ------------------------------------------------------------------ #
def _build_engine(url: str, **kwargs: Any) -> AsyncEngine:
    # Build search_path so that:
    #   1. Application tables (effective_schema) are found by unqualified names.
    #   2. The pgvector 'vector' type (pgvector_schema) is visible for DDL/queries.
    #   3. Standard PostgreSQL functions in 'public' are always accessible.
    parts: list[str] = []
    if settings.effective_schema:
        parts.append(settings.effective_schema)
    if settings.pgvector_schema not in ("public", *parts):
        parts.append(settings.pgvector_schema)
    if "public" not in parts:
        parts.append("public")
    search_path = ",".join(parts)
    return create_async_engine(
        url,
        pool_size=kwargs.pop("pool_size", settings.database_pool_size),
        max_overflow=kwargs.pop("max_overflow", settings.database_max_overflow),
        pool_timeout=settings.database_pool_timeout,
        pool_pre_ping=True,       # detect stale connections
        echo=settings.debug,
        connect_args={"server_settings": {"search_path": search_path}},
        **kwargs,
    )


# Primary insights database
_insights_engine: AsyncEngine | None = None
_insights_session_factory: async_sessionmaker[AsyncSession] | None = None

# Source database (read-only — derived tables)
_source_engine: AsyncEngine | None = None
_source_session_factory: async_sessionmaker[AsyncSession] | None = None


def get_insights_engine() -> AsyncEngine:
    global _insights_engine
    if _insights_engine is None:
        _insights_engine = _build_engine(settings.database_url)
    return _insights_engine


def get_source_engine() -> AsyncEngine:
    global _source_engine
    if _source_engine is None:
        _source_engine = _build_engine(
            settings.source_db_url,
            # Source DB is read-only — smaller pool
            pool_size=max(5, settings.database_pool_size // 2),
            max_overflow=5,
        )
    return _source_engine


def get_insights_session_factory() -> async_sessionmaker[AsyncSession]:
    global _insights_session_factory
    if _insights_session_factory is None:
        _insights_session_factory = async_sessionmaker(
            bind=get_insights_engine(),
            expire_on_commit=False,
            autoflush=False,
            autocommit=False,
        )
    return _insights_session_factory


def get_source_session_factory() -> async_sessionmaker[AsyncSession]:
    global _source_session_factory
    if _source_session_factory is None:
        _source_session_factory = async_sessionmaker(
            bind=get_source_engine(),
            expire_on_commit=False,
            autoflush=False,
            autocommit=False,
        )
    return _source_session_factory


# ------------------------------------------------------------------ #
# Dependency-injectable session providers
# ------------------------------------------------------------------ #
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency — yields an insights DB session."""
    factory = get_insights_session_factory()
    async with factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


async def get_source_db() -> AsyncGenerator[AsyncSession, None]:
    """FastAPI dependency — yields a source DB session (read-only)."""
    factory = get_source_session_factory()
    async with factory() as session:
        yield session


@asynccontextmanager
async def transaction(session: AsyncSession):
    """Context manager for explicit transactions with save-points."""
    async with session.begin_nested():
        yield session


# ------------------------------------------------------------------ #
# Redis connection pool
# ------------------------------------------------------------------ #
_redis_pool: aioredis.Redis | None = None


def get_redis() -> aioredis.Redis:
    global _redis_pool
    if _redis_pool is None:
        _redis_pool = aioredis.from_url(
            settings.redis_url,
            encoding="utf-8",
            decode_responses=True,
            socket_connect_timeout=5,
            socket_timeout=5,
            retry_on_timeout=True,
            health_check_interval=30,
        )
    return _redis_pool


# ------------------------------------------------------------------ #
# Lifecycle helpers (called from app lifespan)
# ------------------------------------------------------------------ #
async def init_db() -> None:
    """Install pgvector extension (if not present), then create all tables."""
    # Import all models so their tables are registered with Base.metadata
    import app.models.insights          # noqa: F401
    import app.models.embeddings        # noqa: F401
    import app.models.interactions      # noqa: F401
    import app.models.jobs              # noqa: F401
    import app.models.query_library     # noqa: F401
    import app.models.derived_tables    # noqa: F401

    engine = get_insights_engine()

    # Step 1 — pgvector must be committed before table creation so the
    # 'vector' type is visible to subsequent DDL.
    async with engine.connect() as conn:
        await conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        await conn.commit()

    # Step 2 — Create all ORM-declared tables (schema from MetaData).
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    log.info("Database initialized successfully")


async def close_db() -> None:
    """Dispose engines gracefully on shutdown."""
    global _insights_engine, _source_engine, _redis_pool
    if _insights_engine:
        await _insights_engine.dispose()
        _insights_engine = None
    if _source_engine:
        await _source_engine.dispose()
        _source_engine = None
    if _redis_pool:
        await _redis_pool.aclose()
        _redis_pool = None
    log.info("Database connections closed")
