"""
Input validation helpers used across services and API layers.

Centralises common validation patterns to avoid duplication.
"""
from __future__ import annotations

import re
import uuid

from fastapi import HTTPException, status


# ------------------------------------------------------------------ #
# UUID validation
# ------------------------------------------------------------------ #
def validate_uuid(value: str, field_name: str = "id") -> str:
    """Validate that a string is a well-formed UUID v4."""
    try:
        uuid.UUID(value, version=4)
    except (ValueError, AttributeError):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid UUID format for field '{field_name}': {value!r}",
        )
    return value


# ------------------------------------------------------------------ #
# SQL safety (for drill-down queries read from DB)
# ------------------------------------------------------------------ #
_FORBIDDEN_SQL_PATTERNS = re.compile(
    r"\b(INSERT|UPDATE|DELETE|DROP|TRUNCATE|ALTER|CREATE|GRANT|REVOKE|EXEC|EXECUTE|CALL)\b",
    re.IGNORECASE,
)


def is_safe_read_query(sql: str) -> bool:
    """
    Returns True only if the SQL appears to be a read-only SELECT.
    Used to guard drill-down SQL stored in the database.
    """
    stripped = sql.strip().upper()
    if not stripped.startswith("SELECT") and not stripped.startswith("WITH"):
        return False
    if _FORBIDDEN_SQL_PATTERNS.search(sql):
        return False
    return True


def validate_drill_down_sql(sql: str | None) -> str:
    """Raise HTTPException if drill-down SQL is not a safe read query."""
    if not sql or not sql.strip():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="This insight has no drill-down SQL configured.",
        )
    if not is_safe_read_query(sql):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Drill-down SQL is not a safe read-only query.",
        )
    return sql


# ------------------------------------------------------------------ #
# Pagination
# ------------------------------------------------------------------ #
def validate_pagination(limit: int, offset: int) -> tuple[int, int]:
    """Clamp pagination params to safe ranges."""
    limit = max(1, min(limit, 500))
    offset = max(0, offset)
    return limit, offset


# ------------------------------------------------------------------ #
# User ID
# ------------------------------------------------------------------ #
_USER_ID_RE = re.compile(r"^[\w\-\.@]{1,100}$")


def validate_user_id(user_id: str) -> str:
    if not _USER_ID_RE.match(user_id):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid user_id format: {user_id!r}",
        )
    return user_id
