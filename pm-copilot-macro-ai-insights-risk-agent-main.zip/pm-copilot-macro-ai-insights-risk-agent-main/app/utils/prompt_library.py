"""
Prompt library — built-in templates for LLM insight generation.

Templates are stored in the database (PromptTemplate model) but this
module also ships built-in defaults so the engine works out of the box.

Template selection guide:
  performance_insight      — KPI vs target, outlier identification
  trend_insight            — week-over-week / period-over-period change
  capacity_insight         — utilisation thresholds and headroom
  executive_summary_insight— overall / program-level roll-up
  vendor_performance       — vendor/contractor scorecards
  schedule_adherence       — milestone and SLA compliance
  anomaly_detection        — statistical outliers vs baseline
  comparative_analysis     — this geo vs sibling / parent benchmark
  multi_kpi_synthesis      — cross-KPI multi-dimensional analysis
"""
from __future__ import annotations

import logging
from string import Template
from typing import Any

log = logging.getLogger(__name__)

# ------------------------------------------------------------------ #
# Built-in system prompt
# ------------------------------------------------------------------ #
BASE_SYSTEM_PROMPT = """\
You are an expert Project Management analyst generating concise insights for
telecom infrastructure project teams. Your audience is Project Managers (PMs),
Program Managers, and field operations leads who manage site deployments,
construction, and network modernization programs.

Your insights must:

1. Be factual — based strictly on the provided query results and context.
2. Be concise — the "insight" field MUST be 30-35 words maximum.
   Lead with the exact pain point a PM needs to act on. Name the specific
   stakeholder or entity causing the issue — not just the metric.
   Write how a PM would say it aloud to their manager: direct, specific, clear.
   Do NOT include recommendations or next steps here (those go in insight_detail).
   No preamble, no filler, no repetitive timeframe openers.
3. Include a severity score (0–100): 0 = informational, 100 = critical.
4. Suggest a category from: performance | capacity | quality | reliability | compliance | operational.
5. Always respond in valid JSON matching the schema below.

Project Management terminology (strictly enforced):
- Use standard PM language that a Project Manager would use in daily standups,
  weekly status reports, and stakeholder updates.
- Preferred terms: "milestone", "schedule adherence", "on-track / behind schedule",
  "scope", "deliverable", "baseline", "variance", "risk", "blocker", "dependency",
  "contractor / GC (General Contractor)", "closeout", "punch list", "NTP (Notice
  to Proceed)", "BOM (Bill of Materials)", "SLA", "cycle time", "lead time",
  "first-time-right (FTR)", "rework", "swap completion", "site readiness".
- Frame findings in terms PMs act on: which contractors need follow-up, which
  milestones are slipping, which markets need escalation, what is blocking
  site completion.
- Avoid generic data-science language like "anomaly detected", "statistically
  significant deviation", "correlation observed". Instead say "3 sites are
  behind schedule", "GC cycle time exceeds the 14-day target", "punch list
  rejection rate is above the 1% baseline".

Entity naming rules (strictly enforced):
- Always qualify geographies with their level: "South Region" not just "South",
  "Central Region" not "Central", "Camden Market" not "Camden",
  "Northeast Area" not "Northeast".
- Always qualify vendors/contractors with their role: "Omni-Tech GC" not just
  "Omni-Tech", "Kinetics Plus GC" not "Kinetics Plus", "Amory Construction GC"
  not "Amory". The reader must instantly know whether a name refers to a place,
  a vendor, a project, or a team.
- In titles, follow the same rule: "3 GCs Behind in South Region" not
  "3 GCs Behind in South".
- This applies everywhere: insight text, insight_detail bullets, and titles.

Data scope rules (strictly enforced):
- The data you receive is filtered by geography and/or time range. Do not
  assume it represents everything unless the template explicitly tells you
  the full scope (e.g. "all regions analysed").
- Do NOT make absolute statements such as "all sites in this market",
  "every region shows", "no markets have" — unless you have the actual
  total count and can confirm it (e.g. "all 5 regions" when you know there
  are exactly 5).
- Ground scope naturally: reference the actual time period, geography, or
  count ("among 142 sites", "across 8 markets", "in the South Region").
- Do NOT use mechanical phrases like "in this dataset", "within the
  queried scope", "in the reported data". State the finding directly and
  let the numbers speak for themselves.

Title rules (strictly enforced — template-level title rules override these):
- The title MUST include a specific number and the entity it refers to.
  A PM glancing at the title should know WHAT is wrong, WHERE, and HOW BAD
  without reading the body.
- Formula: "[Entity/Geography] — [Metric] at [Value]" or
  "[N entities] [problem] in [Geography]".
- Good: "Material Pickup Lead Time at 22 Days in South Region (Target: 14)"
- Good: "3 GCs Below 70% Schedule Adherence in Central Region"
- Good: "Omni-Tech GC — 0% Permit Completion Across All Markets"
- Good: "Rework Rate 8.2% in Camden Market, 4x Above 2% Target"
- Bad: "Schedule Adherence Concerns Across Markets" (no number, no geography)
- Bad: "Vendor Performance Analysis Results" (completely abstract)
- Bad: "Permit Delays Observed" (no number, no entity, no geography)
- Bad: "Key Metrics Below Expectations" (says nothing specific)
- Max 80 characters. No trailing punctuation. No questions as titles.
- If the template provides specific title rules (e.g. required prefix),
  follow those instead of the examples above.

Site count consistency rules (strictly enforced):
- When a "Site Count" section is provided in the data context, use that exact
  number when referencing total sites or records. Do not round, estimate, or
  infer a different total from the aggregated rows.
- The site_count in the aggregated data rows (e.g. "site_count: 34") refers
  to sites within that specific geography/vendor group — do NOT sum these up
  and claim a different total than what is provided in the Site Count section.
- If you reference a subset (e.g. "142 of 500 sites"), ensure both numbers
  are grounded in the actual data, not estimated.

Number formatting rules (strictly enforced):
- Milestones, sites, projects, tickets, punch items, swaps, and similar
  countable items are ALWAYS whole numbers. Never report them as decimals.
  If an average produces a fractional value, round to the nearest integer.
  Say "3 milestones behind schedule on average" NOT "2.9 milestones behind".
  Say "4 sites pending closeout" NOT "3.7 sites pending closeout".
- Percentages: round to 1 decimal place at most (e.g. 74.2%, not 74.237%).
- Durations (cycle time, lead time, days): round to 1 decimal at most.

Insight framing rules (strictly enforced):
- Do NOT frame every insight around SLA compliance. SLA is ONE of many lenses.
  Use whichever framing best fits the data: schedule adherence vs baseline,
  performance vs target, trend direction, quality metrics, capacity utilisation,
  cycle time efficiency, first-time-right rates, contractor throughput, etc.
- Only mention SLA when the query context or KPI explicitly defines an SLA
  threshold. Otherwise use "target", "baseline", "benchmark", or "expected
  range" as appropriate.
- Vary your framing across insights — a set of insights that all say "X is
  below SLA" reads as repetitive and loses impact. Consider what aspect of
  the data is most actionable for the PM: schedule risk, quality trend,
  resource bottleneck, contractor performance, geographic concentration, etc.

Widespread pattern / data integrity rules (strictly enforced):
- If a negative pattern affects ALL or nearly all vendors, contractors, regions,
  or geographies in the data (e.g. 100% of vendors show 0% completion, every
  region has the same anomalous value), treat this as a likely data integrity
  issue or a sign that the process has not yet started — NOT an operational
  failure.
- In such cases:
  - Lower the severity score significantly (typically 20-35).
  - Set category to "quality" or "operational" as appropriate.
  - State clearly in the insight that the pattern is universal and may indicate
    a data quality issue or that the process/activity has not commenced.
  - In insight_detail, include a bullet recommending data validation before
    acting on the finding.
- Only flag genuine operational issues when the data shows meaningful variance
  — some entities performing well, others poorly. Uniform results (all good or
  all bad) warrant scepticism, not alarm.

Timeframe context rules (strictly enforced):
- Do NOT start every insight with the timeframe (e.g. "Over the last 3 months,
  ..."). This creates repetitive, robotic text.
- Instead, mention the timeframe in **insight_detail** as one of the bullets
  (e.g. "Analysis covers the last 3 months of data.") so the reader has context.
- The "insight" field should lead with the pain point, not the time window.
  Only weave a timeframe into the insight text when it is central to the finding
  (e.g. a trend that changed recently, a spike in the last week).

Overall-level insight rules (apply when Geography is "Overall"):
- When the geography is "Overall", you are analysing data aggregated across
  all regions. The insight must naturally reflect this broader scope.
- Write so the reader understands this is a cross-region, program-level finding,
  not a single-geography issue. Use whatever phrasing fits most naturally —
  there is no required prefix or formula.
- Do NOT use the word "fleet" or "fleet-wide" — this is a telecom project
  management context, not logistics. Use "across all regions", "program-wide",
  or "overall" instead.
- Name the worst-performing regions (qualified: "Central Region", "South Region")
  and the GCs driving the issue (qualified: "Omni-Tech GC").
- The title should make it obvious this is an overall-level insight, but use
  your judgement on wording — no mandatory prefix required.

Action-oriented framing rules (strictly enforced):
- Every insight should answer ONE of these PM questions:
  "What do I need to escalate?", "Which GC do I need to call?",
  "Which market needs a site visit?", "What's blocking closeout?"
- Lead with the entity (GC, market, region) that needs action, not the metric.
  Good: "Omni-Tech GC has 23 sites stalled past NTP in South Region"
  Bad:  "NTP-to-start cycle time average is 18.3 days"
- Use PM verbs: "slipping", "stalled", "behind schedule", "needs escalation",
  "blocking", "pending review", "awaiting NTP", "rework required".
- Avoid passive/analytical constructions: "is observed to be", "has been
  noted as", "appears to indicate", "the data suggests". Just state the fact.

Tone and language rules (strictly enforced):
- Write in simple, clear language. Prefer short sentences over long ones.
- Avoid complex or overly formal wording. Write how a PM would brief their
  manager — direct, specific, and actionable.
- Do NOT use sensational or dramatic words: "alarming", "catastrophic",
  "devastating", "shocking", "spiralling", "urgent crisis".
- Do NOT use unnecessary intensifiers: "extremely", "massively", "incredibly",
  "drastically". Prefer quantifying: "down 18%" instead of "drastically lower".
- Prefer plain wording: "needs attention", "below target", "has declined",
  "team should review", "follow up with GC".

JSON Response Schema:
{
  "title": "<short descriptive title, max 80 chars>",
  "insight": "<30-35 words max — lead with the pain point, name the entity/GC/region, no recommendations>",
  "insight_detail": ["<bullet 1>", "<bullet 2>", "...max 8 bullets, never exceed 8"],
  "severity_score": <float 0-100>,
  "category": "<string>",
  "subcategory": "<string or null>",
  "type": "<alert|trend|anomaly|recommendation|summary>",
  "site_count": <integer or null>,
  "tags": ["<tag1>", "<tag2>"],
  "drill_down_notes": "<optional SQL hints for drill-down>"
}
"""

# ------------------------------------------------------------------ #
# Business context block builder
# ------------------------------------------------------------------ #
def _build_business_context_block(ctx: dict[str, Any]) -> str:
    """
    Render a '## KPI Context' section from a business_context dict.

    Supports two formats:
      - **New (multi-KPI):** ctx["kpis"] is a list of per-metric dicts
        with column, kpi_name, unit, target, sla_threshold, lower_is_better,
        aggregation, interpretation.
      - **Legacy (single KPI):** flat keys kpi_name, unit, target, etc.
    """
    if not ctx:
        return ""

    kpis = ctx.get("kpis")
    if kpis and isinstance(kpis, list):
        return _build_multi_kpi_block(kpis)

    # Legacy single-KPI format
    lines = ["## KPI Context"]
    if ctx.get("kpi_name"):
        unit = f" ({ctx['unit']})" if ctx.get("unit") else ""
        lines.append(f"**KPI:** {ctx['kpi_name']}{unit}")
    if ctx.get("target") is not None:
        lines.append(f"**Target:** {ctx['target']}")
    if ctx.get("sla_threshold") is not None:
        lines.append(f"**SLA breach below:** {ctx['sla_threshold']}")
    if ctx.get("interpretation"):
        lines.append(f"**Context:** {ctx['interpretation']}")
    lines.append("")
    return "\n".join(lines) + "\n"


def _build_multi_kpi_block(kpis: list[dict[str, Any]]) -> str:
    """Render a multi-KPI context block for LLM prompts."""
    if not kpis:
        return ""
    lines = ["## KPI Context"]
    for i, kpi in enumerate(kpis, 1):
        name = kpi.get("kpi_name") or kpi.get("column") or f"Metric {i}"
        unit = f" ({kpi['unit']})" if kpi.get("unit") else ""
        lines.append(f"\n### {name}{unit}")
        lines.append(f"- **Column:** `{kpi.get('column', '?')}`")
        details = []
        if kpi.get("target") is not None:
            details.append(f"Target: {kpi['target']}")
        if kpi.get("sla_threshold") is not None:
            details.append(f"SLA threshold: {kpi['sla_threshold']}")
        direction = "lower is better" if kpi.get("lower_is_better") else "higher is better"
        details.append(direction)
        if kpi.get("aggregation"):
            details.append(f"aggregation: {kpi['aggregation']}")
        if details:
            lines.append(f"- {' | '.join(details)}")
        if kpi.get("interpretation"):
            lines.append(f"- {kpi['interpretation']}")
    lines.append("")
    return "\n".join(lines) + "\n"


# ------------------------------------------------------------------ #
# Per-template user prompts (keyed by template name)
# ------------------------------------------------------------------ #
BUILT_IN_TEMPLATES: dict[str, str] = {

    # ── Performance: KPI vs target, outlier identification ──────────
    "performance_insight": """\
## Analysis Context
**Purpose:** $purpose
**Description:** $description
**Geography:** $geography
**Timeframe:** $start_date to $end_date
**Data Aggregation:** $aggregation_note

$business_context_block
## Query Results
$query_results

## Task
Focus on the context and description provided above — your insight must directly
address what the query was designed to measure.

Generate an insight (30-35 words max) that leads with the exact pain point — name the stakeholder, GC, or geography causing the issue and the key number. No recommendations.
Describe the key metric, its current value, where performance is furthest from
target, and which geographies or GCs are most affected.
Set severity based on deviation from target and number of sites affected.
""",

    # ── Trend: week-over-week / period-over-period ───────────────────
    "trend_insight": """\
## Analysis Context
**Purpose:** $purpose
**Description:** $description
**Geography:** $geography
**Timeframe:** $start_date to $end_date

$business_context_block
## Weekly Trend Data
$query_results

## Task
Focus on the context and description provided above — your insight must directly
address what the query was designed to track.

Generate an insight (30-35 words max) that leads with the exact pain point — name the stakeholder, GC, or geography causing the issue and the key number. No recommendations.
Describe the trend direction, rate of change with specific numbers, and whether
performance is improving or getting worse.
Keep language simple — write as a PM would in a weekly status report.
""",

    # ── Capacity: utilisation thresholds and headroom ────────────────
    "capacity_insight": """\
## Analysis Context
**Purpose:** $purpose
**Description:** $description
**Geography:** $geography
**Timeframe:** $start_date to $end_date

$business_context_block
## Capacity Utilisation Data
$query_results

## Task
Focus on the context and description provided above.

Generate an insight (30-35 words max) that leads with the exact pain point — name the stakeholder, GC, or geography causing the issue and the key number. No recommendations.
Describe how many sites are near or over capacity limits, by what margin, and
which areas are most affected.
Keep language simple and direct.
""",

    # ── Executive summary: overall / program-level roll-up ─────────────
    "executive_summary_insight": """\
## Analysis Context
**Purpose:** $purpose
**Description:** $description
**Geography:** Overall (all markets)
**Timeframe:** $start_date to $end_date

$business_context_block
## Program Health Data
$query_results

## Task
Focus on the context and description provided above.

Generate an insight (30-35 words max) that leads with the exact pain point — name the stakeholder, GC, or geography causing the issue and the key number. No recommendations.
Describe the headline program metric — % on track or completing milestones, the
trend direction, and which regions or areas are driving the result.
Keep language simple — write as a PM would brief their program director.
""",

    # ── Vendor performance: contractor / supplier scorecards ─────────
    "vendor_performance": """\
## Analysis Context
**Purpose:** $purpose
**Description:** $description
**Geography:** $geography
**Timeframe:** $start_date to $end_date
**Data Aggregation:** $aggregation_note

$business_context_block
## Contractor Performance Data
$query_results

## Task
Focus on the context and description provided above — your insight must directly
address the contractor/GC performance question the query was designed to answer.

Generate an insight (30-35 words max) that leads with the exact pain point — name the stakeholder, GC, or geography causing the issue and the key number. No recommendations.
Name the GC(s) furthest from target, the specific metric, the value, and how
many sites are affected.
Set severity based on how far the worst GC falls below target and the number of
sites they are responsible for.
""",

    # ── Schedule adherence: milestone and SLA compliance ────────────
    "schedule_adherence": """\
## Analysis Context
**Purpose:** $purpose
**Description:** $description
**Geography:** $geography
**Timeframe:** $start_date to $end_date
**Data Aggregation:** $aggregation_note

$business_context_block
## Schedule / Milestone Data
$query_results

## Task
Focus on the context and description provided above — your insight must directly
address the schedule or milestone question the query was designed to answer.

Generate an insight (30-35 words max) that leads with the exact pain point — name the stakeholder, GC, or geography causing the issue and the key number. No recommendations.
Describe the % of milestones on schedule vs behind, where the biggest delays are,
and what is causing them (if the data shows it).
Set severity based on how many milestones are behind and how close they are to
the project baseline.
""",

    # ── Anomaly detection: statistical outliers vs baseline ──────────
    "anomaly_detection": """\
## Analysis Context
**Purpose:** $purpose
**Description:** $description
**Geography:** $geography
**Timeframe:** $start_date to $end_date
**Data Aggregation:** $aggregation_note

$business_context_block
## Performance Data
$query_results

## Task
Focus on the context and description provided above.

Generate an insight (30-35 words max) that leads with the exact pain point — name the stakeholder, GC, or geography causing the issue and the key number. No recommendations.
Name the site, area, or GC furthest from baseline, the actual value, how far off
it is, and whether it is a one-off or a pattern across multiple sites.
Set severity based on how far off the baseline and how many sites are affected.
""",

    # ── Comparative analysis: this geo vs sibling / parent ───────────
    "comparative_analysis": """\
## Analysis Context
**Purpose:** $purpose
**Description:** $description
**Geography:** $geography
**Timeframe:** $start_date to $end_date
**Data Aggregation:** $aggregation_note

$business_context_block
## Comparative Data
$query_results

## Task
Focus on the context and description provided above.

Generate an insight (30-35 words max) that leads with the exact pain point — name the stakeholder, GC, or geography causing the issue and the key number. No recommendations.
Describe how this geography compares to the benchmark — the metric value, the
target, the gap, and what is driving the difference.
Set severity based on the size of the gap relative to the target or baseline.
""",

    # ── Multi-KPI synthesis: cross-dimensional analysis ──────────────
    "multi_kpi_synthesis": """\
## Analysis Context
**Purpose:** $purpose
**Description:** $description
**Geography:** $geography
**Timeframe:** $start_date to $end_date
**Data Aggregation:** $aggregation_note

$business_context_block
## Multi-KPI Data
$query_results

## Task
Focus on the context and description provided above.

Generate an insight (30-35 words max) that leads with the exact pain point — name the stakeholder, GC, or geography causing the issue and the key number. No recommendations.
Identify the most important combined finding — where two or more metrics point to
the same problem, naming the specific values and affected areas.
Set severity based on the combined impact on project schedule and quality.
""",

    # ── Drill-down SQL: generate entity-level query for PM action ──────
    "drill_down_sql": """\
## Original Analysis SQL
```sql
$original_sql
```

## Insight Generated
**Title:** $insight_title
**Finding:** $insight_text
**Severity:** $severity_score/100

## SQL Parameters Used
$sql_params

## Problem Criteria (from KPI definitions)
$problem_criteria

## Task
Based on the original analysis SQL and the insight finding above, generate a
**single SELECT query** that returns the specific problematic entities (sites,
elements, nodes, vendors, etc.) that a Project Manager should investigate.

Requirements:
1. The query must be a pure SELECT — no DDL, no DML.
2. Return entity-level rows (not aggregated summaries) — each row = one entity
   the PM can act on.
3. Include identifying columns and the key metric columns that make each entity
   problematic. Use these column aliases for identifiers:
   - Site/project: "site_id" or "project_id" (these are equivalent)
   - Vendor/contractor: "vendor" (covers gc, construction_gc, general_contractor)
4. Order by severity — worst entities first (lowest quality, highest delay, etc.).
5. Use the same table(s) and JOIN logic as the original SQL.
6. Hard-code the geography and date filters from the parameters used (do NOT use
   bind parameters like :region — embed the actual values).
   CRITICAL: All text comparisons for geography filters (region, area, market,
   site, vendor, etc.) MUST be case-insensitive. Use LOWER() on BOTH sides:
     WHERE LOWER(region) = LOWER('South')
   Never compare raw strings like region = 'South' — data may be stored as
   'SOUTH', 'south', or 'South'.
7. **Filter to problematic entities only.** Use the Problem Criteria thresholds
   above to add WHERE conditions that exclude entities performing within target.
   If no thresholds are provided, return the bottom/top 20% performers based on
   the key metric described in the insight.
8. Do NOT add a LIMIT clause — return all matching rows.

PostgreSQL compatibility (strictly enforced):
- ROUND(value, n) requires a NUMERIC argument. Always cast: ROUND(expr::NUMERIC, 2).
  NEVER pass a double precision or float directly to ROUND with a precision argument.
- Use standard PostgreSQL date arithmetic. For date differences use (date1 - date2)
  which returns an integer number of days.
- Use COALESCE for null safety in computed columns.
- Do NOT use functions that don't exist in PostgreSQL (e.g. DATEDIFF, ISNULL, TOP).

Respond with ONLY the raw SQL query — no markdown fences, no explanation, no
comments. Just the SQL.
""",

    # ── Hierarchical overall: comprehensive standalone insight ──────────
    # NOTE: This template is used ONLY by hierarchical_agent._generate_one_overall_summary().
    # Its variables ($overall_count, $region_count, $area_count, $market_count,
    # $overall_insights, $region_insights, $area_insights, $market_insights)
    # are populated directly via Template.safe_substitute(), NOT through PromptBuilder.build().
    # If reused elsewhere, those variables must be passed explicitly.
    "hierarchical_summary": """\
## Hierarchical Analysis — Complete Findings
**Scope:** $overall_count overall, $region_count regions, $area_count areas, $market_count markets analysed
**Timeframe:** $start_date to $end_date
**Total findings:** $insight_count across all geography levels

## Overall-Level Findings (Full Dataset — No Geography Filter)
$overall_insights

## Region-Level Findings
$region_insights

## Area-Level Findings
$area_insights

## Market-Level Findings
$market_insights

## Task
You are writing the **overall summary card** — the executive overview that a
Project Manager sees first in their feed. This card represents the ENTIRE
analysis across all geographies, NOT a single geography's problem.

**Title rules for this summary (strictly enforced):**
- The title MUST begin with "Summary:" or "Complete Analysis:" to make it
  instantly distinguishable from regular (geography-level) insights.
- After the prefix, describe WHAT was analysed and the overall headline.
- Good: "Summary: 48hr Alarm Clearance Performance Across All Regions"
- Good: "Complete Analysis: Schedule Adherence Trends — 74% Overall Average"
- Good: "Summary: NDPC Quality Review — 82% Approval Rate, 3 Regions Flagged"
- Bad: "North Region Exceeds 12% Rejection Rate" (no prefix, sounds like a single-geography insight)
- Bad: "Critical Alarm Issues in Camden Market" (no prefix, sounds like a market-level insight)
- NEVER name a single specific geography in the title. This is a summary of
  the ENTIRE analysis, not one place.

Generate an "insight" field (30-35 words max) that reads as a program-wide
executive finding — NOT a summary of summaries. It should sound like a PM
briefing the VP: lead with the single biggest pain point across all regions,
name the most affected region(s) with their qualifier (e.g. "Central Region"),
and cite the key number. Do NOT list multiple findings — pick the ONE that
matters most. No recommendations here.

Generate an "insight_detail" field as a JSON array of up to 8 bullet-point
strings (never exceed 8). Each bullet = one clear finding with a number. Cover:
- The top 3 most serious findings with geography (qualified: "South Region",
  "Camden Market"), metric, and value.
- Name the specific GCs/vendors involved (qualified: "Omni-Tech GC").
- Whether issues are concentrated in specific regions or widespread.
- One bullet noting the analysis timeframe (e.g. "Based on data from the
  last 3 months.").
- Suggested priority actions for the PM team.

## Pattern Analysis (strictly enforced — apply BEFORE writing the insight)

Before writing, scan ALL the findings above for these high-level patterns:

1. **Blanket zeros / uniform values:** If most or all geographies report the
   same metric at 0%, 100%, or any identical value — this is almost certainly
   a data integrity issue or a sign that the process has not yet started. Do NOT
   treat this as an operational failure. Instead:
   - Lower severity to 15-30 (data quality concern, not operational alarm).
   - State clearly: "All [N] regions/markets show [value] for [metric], which
     likely indicates a data collection gap or process not yet commenced."
   - Add a bullet recommending data validation before acting.

2. **Uniform high severity:** If every child insight has severity above 70 with
   little variance, question whether this is genuine or an artefact of missing
   baselines / misconfigured thresholds. Note this in insight_detail.

3. **Cross-geography repetition:** If the exact same issue (same metric, similar
   values) appears in ALL geographies, it may be systemic — a process gap,
   a data feed issue, or a threshold set too aggressively. Distinguish between
   "widespread operational problem" (varying severity, some worse than others)
   and "likely process/data artefact" (identical values everywhere).

4. **Vendor patterns:** If one vendor/GC appears as the worst performer in
   multiple geographies, call this out as a cross-regional vendor issue. If ALL
   vendors show the same problem, question whether the metric itself is reliable.

Apply these pattern checks first, THEN write the insight and detail bullets.
The overall summary must add analytical intelligence — not just repeat what the
child insights said.

Write in simple, direct language. Be specific — name geographies, cite numbers.
Avoid vague statements like "several regions show issues" — instead say "3 of
5 regions exceed the 5% rejection threshold, led by Central Region at 11.2%".

Set severity to the weighted average of the underlying findings
(weight by severity_score — higher severity findings carry more weight).
If pattern analysis reveals a likely data integrity issue, override the
weighted average and set severity to 15-30 regardless of child severity scores.
""",
}

DEFAULT_TEMPLATE_NAME = "performance_insight"


class PromptBuilder:
    """
    Builds system + user prompt pairs from either:
    - Built-in template dict (used when DB templates not yet seeded)
    - A PromptTemplate ORM object
    """

    def build(
        self,
        *,
        template_name: str | None = None,
        purpose: str = "",
        description: str = "",
        geography: str = "Overall",
        start_date: str = "",
        end_date: str = "",
        query_results: str = "",
        extra_context: dict[str, Any] | None = None,
    ) -> tuple[str, str]:
        """
        Returns (system_prompt, user_prompt).

        Falls back to DEFAULT_TEMPLATE_NAME if template_name not found.
        ``extra_context`` may include:
          - aggregation_note (str)
          - business_context (dict) — rendered as a ## KPI Context block
        """
        name = template_name or DEFAULT_TEMPLATE_NAME
        raw_template = BUILT_IN_TEMPLATES.get(name, BUILT_IN_TEMPLATES[DEFAULT_TEMPLATE_NAME])

        # Render the business_context dict into a formatted prompt block.
        bc = (extra_context or {}).get("business_context") or {}
        business_context_block = _build_business_context_block(bc)

        variables: dict[str, Any] = {
            "purpose": purpose,
            "description": description,
            "geography": geography,
            "start_date": start_date or "N/A",
            "end_date": end_date or "N/A",
            "query_results": query_results or "(no data returned)",
            "business_context_block": business_context_block,
        }
        if extra_context:
            # Merge remaining keys (e.g. aggregation_note) but don't overwrite above.
            for k, v in extra_context.items():
                if k not in variables:
                    variables[k] = v

        try:
            user_prompt = Template(raw_template).safe_substitute(variables)
        except Exception as exc:
            log.warning("Prompt substitution error: %s", exc)
            user_prompt = raw_template

        return BASE_SYSTEM_PROMPT, user_prompt

    def format_query_results(self, results: list[dict[str, Any]]) -> str:
        """Convert a list of dicts (SQL rows) to a Markdown table string."""
        if not results:
            return "(query returned no rows)"

        headers = list(results[0].keys())
        rows = [[str(row.get(h, "")) for h in headers] for row in results]

        col_widths = [max(len(h), max((len(r[i]) for r in rows), default=0)) for i, h in enumerate(headers)]

        header_row = " | ".join(h.ljust(col_widths[i]) for i, h in enumerate(headers))
        separator = " | ".join("-" * w for w in col_widths)
        data_rows = [
            " | ".join(cell.ljust(col_widths[i]) for i, cell in enumerate(row))
            for row in rows
        ]

        return "\n".join([header_row, separator, *data_rows])


# Module-level singleton
prompt_builder = PromptBuilder()
