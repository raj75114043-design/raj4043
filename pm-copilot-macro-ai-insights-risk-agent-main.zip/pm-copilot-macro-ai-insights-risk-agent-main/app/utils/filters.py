"""
Geography filter utilities.

Responsible for:
  - Loading geography hierarchy from dim_geography source table (async)
  - Expanding a filter request into a list of concrete parameter sets
  - Building geography label strings (for prompt context)
"""
from __future__ import annotations

import logging
from dataclasses import dataclass

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings

log = logging.getLogger(__name__)
settings = get_settings()


@dataclass
class GeoParams:
    """One concrete set of geography parameters for a single query run."""

    level: str                  # overall | region | area | market
    region: str | None = None
    area: str | None = None
    market: str | None = None

    def as_sql_params(self) -> dict[str, str | None]:
        return {
            "level": self.level,
            "market": self.market,
            "region": self.region,
            "area": self.area,
        }

    def get_name(self) -> str:
        """Return the name of the node at this level (used for routing decisions)."""
        if self.level == "market":
            return self.market or ""
        if self.level == "area":
            return self.area or ""
        if self.level == "region":
            return self.region or ""
        return "Overall"

    def label(self) -> str:
        parts = []
        if self.region:
            parts.append(f"Region: {self.region}")
        if self.area:
            parts.append(f"Area: {self.area}")
        if self.market:
            parts.append(f"Market: {self.market}")
        return ", ".join(parts) if parts else "Overall"


class GeographyLoader:
    """
    Loads geography hierarchy from the dim_geography source table.

    Call ``await expand(source_db, ...)`` to get the list of GeoParams
    that should be iterated during a batch generation run.

    ``name_col`` controls which dim_geography column is used as the
    parameter value passed to SQL queries (e.g. :region, :area, :market).
    Default is ``geo_name``; set to ``geo_code`` if your fact tables
    store the uppercase code instead.
    """

    name_col: str = "geo_name"

    async def expand(
        self,
        source_db: AsyncSession,
        level: str | None = None,
        region: str | None = None,
        area: str | None = None,
        market: str | None = None,
    ) -> list[GeoParams]:
        """Return all GeoParams matching the requested scope.

        When ``level`` is provided explicitly it always takes precedence.
        Implicit inference from filter parameters is only used when ``level``
        is None — this prevents the hierarchical agent from receiving the wrong
        geo tier when drilling down (e.g. asking for areas within a region
        should never return the region itself just because ``region`` is set).
        """
        level_lower = level.lower() if level else None

        # ── Explicit level — dispatch directly, ignore filter heuristics ── #
        if level_lower == "overall":
            return [GeoParams(level="overall")]

        if level_lower == "region":
            return await self._regions(source_db, filter_region=region)

        if level_lower == "area":
            return await self._areas(source_db, filter_region=region, filter_area=area)

        if level_lower == "market":
            return await self._markets(
                source_db, filter_region=region, filter_area=area, filter_market=market
            )

        # ── No explicit level — infer from filter parameters ── #
        if not region and not area and not market:
            return [GeoParams(level="overall")]

        if region and not area and not market:
            return await self._regions(source_db, filter_region=region)

        if area and not market:
            return await self._areas(source_db, filter_region=region, filter_area=area)

        if market:
            return await self._markets(
                source_db, filter_region=region, filter_area=area, filter_market=market
            )

        # Default: all levels
        return await self._all_levels(source_db)

    # ------------------------------------------------------------------ #
    # Private expansion helpers
    # ------------------------------------------------------------------ #

    async def _regions(
        self,
        db: AsyncSession,
        *,
        filter_region: str | None = None,
    ) -> list[GeoParams]:
        tbl = settings.table_dim_geography
        col = self.name_col
        sql = text(f"""
            SELECT {col} AS name
            FROM {tbl}
            WHERE geo_level = 'REGION'
              AND is_active = TRUE
              AND (CAST(:region AS TEXT) IS NULL OR LOWER({col}) = LOWER(:region))
            ORDER BY display_order, {col}
        """)
        rows = (await db.execute(sql, {"region": filter_region})).fetchall()
        log.info("GeographyLoader._regions: found %d rows (filter=%r)", len(rows), filter_region)
        return [GeoParams(level="region", region=row.name) for row in rows]

    async def _areas(
        self,
        db: AsyncSession,
        *,
        filter_region: str | None = None,
        filter_area: str | None = None,
    ) -> list[GeoParams]:
        tbl = settings.table_dim_geography
        col = self.name_col
        sql = text(f"""
            SELECT
                a.{col} AS area_name,
                r.{col} AS region_name
            FROM {tbl} a
            JOIN {tbl} r ON r.geo_id = a.region_id
            WHERE a.geo_level = 'AREA'
              AND a.is_active = TRUE
              AND (CAST(:region AS TEXT) IS NULL OR LOWER(r.{col}) = LOWER(:region))
              AND (CAST(:area   AS TEXT) IS NULL OR LOWER(a.{col}) = LOWER(:area))
            ORDER BY a.display_order, a.{col}
        """)
        rows = (await db.execute(sql, {"region": filter_region, "area": filter_area})).fetchall()
        area_names = [row.area_name for row in rows]
        log.info(
            "GeographyLoader._areas: found %d rows (filter_region=%r, filter_area=%r) → %s",
            len(rows), filter_region, filter_area, area_names,
        )
        return [
            GeoParams(level="area", region=row.region_name, area=row.area_name)
            for row in rows
        ]

    async def _markets(
        self,
        db: AsyncSession,
        *,
        filter_region: str | None = None,
        filter_area: str | None = None,
        filter_market: str | None = None,
    ) -> list[GeoParams]:
        tbl = settings.table_dim_geography
        col = self.name_col
        sql = text(f"""
            SELECT
                m.{col} AS market_name,
                a.{col} AS area_name,
                r.{col} AS region_name
            FROM {tbl} m
            JOIN {tbl} a ON a.geo_id = m.area_id
            JOIN {tbl} r ON r.geo_id = m.region_id
            WHERE m.geo_level = 'MARKET'
              AND m.is_active = TRUE
              AND (CAST(:region AS TEXT) IS NULL OR LOWER(r.{col}) = LOWER(:region))
              AND (CAST(:area   AS TEXT) IS NULL OR LOWER(a.{col}) = LOWER(:area))
              AND (CAST(:market AS TEXT) IS NULL OR LOWER(m.{col}) = LOWER(:market))
            ORDER BY m.display_order, m.{col}
        """)
        rows = (
            await db.execute(sql, {"region": filter_region, "area": filter_area, "market": filter_market})
        ).fetchall()
        market_names = [row.market_name for row in rows]
        log.info(
            "GeographyLoader._markets: found %d rows (filter_region=%r, filter_area=%r) → %s",
            len(rows), filter_region, filter_area, market_names,
        )
        return [
            GeoParams(level="market", region=row.region_name, area=row.area_name, market=row.market_name)
            for row in rows
        ]

    async def _all_levels(self, db: AsyncSession) -> list[GeoParams]:
        return (
            [GeoParams(level="overall")]
            + await self._regions(db)
            + await self._areas(db)
            + await self._markets(db)
        )


# Module-level singleton
_geo_loader: GeographyLoader | None = None


def get_geography_loader() -> GeographyLoader:
    global _geo_loader
    if _geo_loader is None:
        _geo_loader = GeographyLoader()
    return _geo_loader
