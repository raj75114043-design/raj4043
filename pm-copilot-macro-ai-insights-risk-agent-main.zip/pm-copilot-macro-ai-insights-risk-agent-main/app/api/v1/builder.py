"""
Builder API — /api/v1/builder/*

Two sub-domains:

  Derived Table Builder
  ─────────────────────
  POST   /builder/derived-tables/preview          → generate DDL (no DB changes)
  POST   /builder/derived-tables                  → generate DDL + optionally execute + save spec
  GET    /builder/derived-tables                  → list all definitions
  GET    /builder/derived-tables/{id}             → get one
  POST   /builder/derived-tables/{id}/refresh     → re-run DDL to reload table data
  DELETE /builder/derived-tables/{id}             → archive (soft-delete)

  SQL Query Builder
  ─────────────────
  POST   /builder/sql-queries/preview             → generate SQL (no save)
  POST   /builder/sql-queries                     → generate SQL + save to query library
  GET    /builder/sql-queries                     → list queries in library
"""
from __future__ import annotations

import logging
import os
from typing import Annotated

log = logging.getLogger(__name__)

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import FileResponse
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession

import re
import time
from typing import Any

from app.database import get_db, get_source_session_factory
from app.middleware.auth import CurrentUser, require_admin
from app.middleware.error_handler import NotFoundError
from app.models.derived_tables import DerivedTableDefinition
from app.models.query_library import SqlQueryLibrary
from app.schemas.builder import (
    AnalysisIdea,
    ColumnInfo,
    DerivedTableListResponse,
    DerivedTablePreviewResponse,
    DerivedTableRequest,
    DerivedTableResponse,
    DerivedTableUpdateRequest,
    IdeateRequest,
    IdeateResponse,
    RefreshResponse,
    SqlQueryBuilderRequest,
    SqlQueryBuilderResponse,
    SqlQueryListItem,
    SqlQueryUpdateRequest,
    TableSampleResponse,
    ValidateSqlRequest,
)
from app.services.analysis_ideator import AnalysisIdeator
from app.services.derived_table_service import DerivedTableService
from app.services.query_builder_service import QueryBuilderService
from app.services.sql_executor import _coerce_value
from app.utils.validators import validate_uuid
from sqlalchemy import String, bindparam, text

router = APIRouter(prefix="/builder", tags=["Builder"])

_derived_svc = DerivedTableService()
_query_svc = QueryBuilderService()
_ideator = AnalysisIdeator()

_STATIC = os.path.join(os.path.dirname(__file__), "..", "..", "static")


@router.get("/ui", include_in_schema=False)
async def builder_ui() -> FileResponse:
    """Legacy builder form UI."""
    return FileResponse(os.path.join(_STATIC, "builder.html"), media_type="text/html")


@router.get("/console", include_in_schema=False)
async def builder_console() -> FileResponse:
    """Context Ingestion Console — 5-step developer wizard."""
    return FileResponse(os.path.join(_STATIC, "console.html"), media_type="text/html")


@router.get("/generate", include_in_schema=False)
async def generate_ui() -> FileResponse:
    """Insights Generation UI — trigger batch and hierarchical generation jobs."""
    return FileResponse(os.path.join(_STATIC, "generate.html"), media_type="text/html")


# ================================================================== #
#  DERIVED TABLE BUILDER
# ================================================================== #

@router.post(
    "/derived-tables/preview",
    response_model=DerivedTablePreviewResponse,
    summary="Preview generated DDL (no DB changes)",
)
async def preview_derived_table(
    body: DerivedTableRequest,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> DerivedTablePreviewResponse:
    """
    Generate a ``CREATE TABLE AS SELECT`` statement via LLM.

    The table is **not** created — review the SQL and resubmit with
    ``execute=true`` when satisfied.
    """
    ddl = await _derived_svc.generate_ddl(body)
    return DerivedTablePreviewResponse(
        table_name=body.table_name,
        schema_name=body.schema_name,
        generated_ddl=ddl,
        message="DDL generated. Review it, then POST to /builder/derived-tables with execute=true to create the table.",
    )


@router.post(
    "/derived-tables",
    response_model=DerivedTableResponse,
    status_code=201,
    summary="Create a derived table (LLM DDL + optional execution)",
)
async def create_derived_table(
    body: DerivedTableRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> DerivedTableResponse:
    """
    Generate DDL via LLM and save the definition.

    - ``execute=false`` (default) — saves as **draft**, no source DB changes.
    - ``execute=true`` — runs the DDL against the source DB, then saves as **active**.
    """
    source_factory = get_source_session_factory()
    async with source_factory() as source_db:
        defn = await _derived_svc.create_table(
            insights_db=db,
            source_db=source_db,
            request=body,
            created_by=current_user.user_id,
        )
    return _defn_to_response(defn)


@router.get(
    "/derived-tables",
    response_model=DerivedTableListResponse,
    summary="List derived table definitions",
)
async def list_derived_tables(
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> DerivedTableListResponse:
    """Return all non-archived derived table definitions, newest first."""
    result = await db.execute(
        select(DerivedTableDefinition)
        .where(DerivedTableDefinition.status != "archived")
        .order_by(DerivedTableDefinition.created_at.desc())
    )
    items = result.scalars().all()
    return DerivedTableListResponse(
        items=[_defn_to_response(d) for d in items],
        total=len(items),
    )


@router.get(
    "/derived-tables/{table_def_id}",
    response_model=DerivedTableResponse,
    summary="Get a single derived table definition",
)
async def get_derived_table(
    table_def_id: str,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> DerivedTableResponse:
    validate_uuid(table_def_id, "table_def_id")
    defn = await _get_defn_or_404(db, table_def_id)
    return _defn_to_response(defn)


@router.post(
    "/derived-tables/{table_def_id}/refresh",
    response_model=RefreshResponse,
    summary="Re-run DDL to refresh the derived table",
)
async def refresh_derived_table(
    table_def_id: str,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> RefreshResponse:
    """
    Re-execute the stored DDL using the definition's ``refresh_mode``:

    - **truncate_insert** — truncates and re-inserts (table stays visible).
    - **create_replace** — drops and recreates (clean schema, brief downtime).
    """
    validate_uuid(table_def_id, "table_def_id")
    defn = await _get_defn_or_404(db, table_def_id)

    source_factory = get_source_session_factory()
    async with source_factory() as source_db:
        defn = await _derived_svc.refresh_table(db, source_db, defn)

    ok = defn.status == "active"
    return RefreshResponse(
        table_def_id=defn.table_def_id,
        table_name=f"{defn.schema_name}.{defn.table_name}",
        status=defn.status,
        row_count=defn.row_count,
        message="Refresh complete." if ok else f"Refresh failed: {defn.last_error}",
    )


@router.patch(
    "/derived-tables/{table_def_id}",
    response_model=DerivedTableResponse,
    summary="Update derived table metadata",
)
async def update_derived_table(
    table_def_id: str,
    body: DerivedTableUpdateRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> DerivedTableResponse:
    """Partial update of table definition metadata. Only supplied fields are changed."""
    validate_uuid(table_def_id, "table_def_id")
    defn = await _get_defn_or_404(db, table_def_id)
    updates = body.model_dump(exclude_none=True)
    for field, value in updates.items():
        setattr(defn, field, value)
    await db.commit()
    await db.refresh(defn)
    return _defn_to_response(defn)


@router.delete(
    "/derived-tables/{table_def_id}",
    status_code=204,
    summary="Archive a derived table definition",
)
async def archive_derived_table(
    table_def_id: str,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> None:
    """Soft-delete — marks status as ``archived``. Does not drop the actual table."""
    validate_uuid(table_def_id, "table_def_id")
    await _get_defn_or_404(db, table_def_id)   # 404 if missing
    await db.execute(
        update(DerivedTableDefinition)
        .where(DerivedTableDefinition.table_def_id == table_def_id)
        .values(status="archived")
    )
    await db.commit()


# ================================================================== #
#  SQL QUERY BUILDER
# ================================================================== #

@router.post(
    "/sql-queries/preview",
    response_model=SqlQueryBuilderResponse,
    summary="Preview generated analysis SQL (no save)",
)
async def preview_sql_query(
    body: SqlQueryBuilderRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> SqlQueryBuilderResponse:
    """
    Generate a parameterized analysis SQL query via LLM.

    The query is **not** saved — review it and resubmit with ``save=true``
    when satisfied.  Table schema is fetched automatically from the source DB
    so the LLM uses real column names.  If ``table_def_id`` is supplied the
    full derived-table context (business purpose, join logic, filter conditions,
    computed columns) is fetched and injected into the LLM prompt.
    """
    table_context = await _resolve_table_context(db, body.table_def_id) if body.table_def_id else None
    source_factory = get_source_session_factory()
    async with source_factory() as source_db:
        sql = await _query_svc.generate_query(body, source_db=source_db, table_context=table_context)
    return SqlQueryBuilderResponse(
        generated_sql=sql,
        saved=False,
        message="SQL generated. Review it, then POST to /builder/sql-queries with save=true to add to the query library.",
    )


@router.post(
    "/sql-queries",
    response_model=SqlQueryBuilderResponse,
    status_code=201,
    summary="Generate analysis SQL and save to query library",
)
async def create_sql_query(
    body: SqlQueryBuilderRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> SqlQueryBuilderResponse:
    """
    Generate an analysis SQL query via LLM and save it to ``sql_query_library``.

    ``query_name`` is required when saving.  Table schema is fetched
    automatically from the source DB so the LLM uses real column names.
    If ``table_def_id`` is supplied the full derived-table context is injected
    into the LLM prompt for more accurate SQL generation.
    """
    if not body.query_name:
        raise HTTPException(status_code=422, detail="query_name is required when saving a query.")

    table_context = await _resolve_table_context(db, body.table_def_id) if body.table_def_id else None
    source_factory = get_source_session_factory()
    async with source_factory() as source_db:
        sql = await _query_svc.generate_query(body, source_db=source_db, table_context=table_context)
    entry = await _query_svc.save_query(db, body, sql, table_context=table_context)
    return SqlQueryBuilderResponse(
        generated_sql=sql,
        query_id=str(entry.query_id),
        query_name=entry.name,
        saved=True,
        message=f"Query '{entry.name}' saved to library (id={entry.query_id}).",
    )


@router.get(
    "/sql-queries",
    response_model=list[SqlQueryListItem],
    summary="List queries in the sql_query_library",
)
async def list_sql_queries(
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> list[SqlQueryListItem]:
    """Return active queries from the library, newest first (max 200)."""
    result = await db.execute(
        select(SqlQueryLibrary)
        .where(SqlQueryLibrary.is_active.is_(True))
        .order_by(SqlQueryLibrary.created_at.desc())
        .limit(200)
    )
    return [_query_to_list_item(q) for q in result.scalars().all()]


@router.get(
    "/sql-queries/{query_id}",
    response_model=SqlQueryListItem,
    summary="Get a single query library entry",
)
async def get_sql_query(
    query_id: str,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> SqlQueryListItem:
    validate_uuid(query_id, "query_id")
    q = await _get_query_or_404(db, query_id)
    return _query_to_list_item(q)


@router.patch(
    "/sql-queries/{query_id}",
    response_model=SqlQueryListItem,
    summary="Update a query library entry",
)
async def update_sql_query(
    query_id: str,
    body: SqlQueryUpdateRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> SqlQueryListItem:
    """Partial update — only supplied fields are changed."""
    validate_uuid(query_id, "query_id")
    q = await _get_query_or_404(db, query_id)
    updates = body.model_dump(exclude_unset=True)
    # Deduplicate list fields to prevent accumulation of repeated values
    _list_fields = {"projects", "functions", "tags", "insight_areas"}
    for field, value in updates.items():
        if field in _list_fields and isinstance(value, list):
            value = list(dict.fromkeys(value))  # dedupe preserving order
        setattr(q, field, value)
    await db.commit()
    await db.refresh(q)
    return _query_to_list_item(q)


@router.delete(
    "/sql-queries/{query_id}",
    status_code=204,
    summary="Deactivate (soft-delete) a query library entry",
)
async def deactivate_sql_query(
    query_id: str,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> None:
    validate_uuid(query_id, "query_id")
    q = await _get_query_or_404(db, query_id)
    q.is_active = False
    await db.commit()


# ================================================================== #
#  CONSOLE — TABLE SAMPLE
# ================================================================== #

@router.get(
    "/derived-tables/{table_def_id}/sample",
    response_model=TableSampleResponse,
    summary="Fetch column schema + sample rows for a derived table",
)
async def sample_derived_table(
    table_def_id: str,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
    rows: int = 20,
) -> TableSampleResponse:
    """
    Returns column names/types (from ``pg_catalog``) and up to *rows* sample
    rows from the derived table.  Used by the console to let the developer
    verify data before ideating analysis queries.
    """
    validate_uuid(table_def_id, "table_def_id")
    defn = await _get_defn_or_404(db, table_def_id)
    qualified = f"{defn.schema_name}.{defn.table_name}"

    source_factory = get_source_session_factory()
    async with source_factory() as source_db:
        columns = await _fetch_column_info(source_db, defn.schema_name, defn.table_name)

        if not columns:
            return TableSampleResponse(
                table_def_id=table_def_id,
                qualified_name=qualified,
                columns=[],
                sample_rows=[],
                error="Table not found or not yet created (status may be 'draft').",
            )

        try:
            # Row count
            count_result = await source_db.execute(
                text(f"SELECT COUNT(*) FROM {qualified}")  # noqa: S608 — table name from trusted DB row
            )
            row_count: int = count_result.scalar_one()

            # Sample rows — normalize to JSON-safe primitives (datetime, Decimal,
            # UUID etc. are not serializable in dict[str, Any] by default)
            sample_result = await source_db.execute(
                text(f"SELECT * FROM {qualified} LIMIT {min(rows, 100)}")  # noqa: S608
            )
            col_names = list(sample_result.keys())
            sample_rows = [
                {col: _coerce_value(v) for col, v in zip(col_names, row)}
                for row in sample_result.fetchall()
            ]

            return TableSampleResponse(
                table_def_id=table_def_id,
                qualified_name=qualified,
                row_count=row_count,
                columns=columns,
                sample_rows=sample_rows,
            )
        except Exception as exc:
            return TableSampleResponse(
                table_def_id=table_def_id,
                qualified_name=qualified,
                columns=columns,
                sample_rows=[],
                error=str(exc),
            )


# ================================================================== #
#  CONSOLE — ANALYSIS IDEATION
# ================================================================== #

@router.post(
    "/derived-tables/{table_def_id}/ideate",
    response_model=IdeateResponse,
    summary="Generate analysis ideas for a derived table via LLM",
)
async def ideate_analysis(
    table_def_id: str,
    body: IdeateRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> IdeateResponse:
    """
    Calls the LLM to brainstorm high-value, recurring analysis ideas for the
    specified derived table.  The returned ideas can be selected by the
    developer and turned into parameterised SQL queries in the next step.
    """
    validate_uuid(table_def_id, "table_def_id")
    defn = await _get_defn_or_404(db, table_def_id)
    qualified = f"{defn.schema_name}.{defn.table_name}"

    source_factory = get_source_session_factory()
    async with source_factory() as source_db:
        columns = await _fetch_column_info(source_db, defn.schema_name, defn.table_name)

    # If the table hasn't been executed yet (draft status) the source DB has no rows.
    # Fall back to extracting column names from the stored DDL so ideation still works.
    if not columns and defn.generated_ddl:
        columns = _columns_from_ddl(defn.generated_ddl)
        if columns:
            log.info(
                "ideate_analysis: table %s is draft — extracted %d columns from DDL",
                qualified, len(columns),
            )

    pm_goals_str = (
        body.pm_goals
        + (f"\nFocus areas: {', '.join(body.focus_areas)}" if body.focus_areas else "")
        if body.pm_goals
        else (f"Focus areas: {', '.join(body.focus_areas)}" if body.focus_areas else None)
    )
    ideas: list[AnalysisIdea] = await _ideator.ideate(
        qualified_name=qualified,
        columns=[{"name": c.name, "data_type": c.data_type} for c in columns],
        business_context=defn.business_context or "",
        description=defn.description or "",
        join_logic=defn.join_logic or None,
        filter_logic=defn.filter_logic or None,
        additional_logic=defn.additional_logic or None,
        generated_ddl=defn.generated_ddl or None,
        pm_goals=pm_goals_str,
        num_ideas=body.num_ideas,
    )
    return IdeateResponse(table_def_id=table_def_id, ideas=ideas)


# ================================================================== #
#  CONSOLE — SQL VALIDATION
# ================================================================== #

def _check_null_safe_geo_params(sql: str) -> list[str]:
    """Warn if geo params are used without null-safe IS NULL guard.

    At the overall level :region, :area, :market are NULL.  A bare equality
    like ``WHERE region = :region`` becomes ``region = NULL`` which always
    returns zero rows.  The correct pattern is:
        (CAST(:region AS TEXT) IS NULL OR LOWER(col) = LOWER(CAST(:region AS TEXT)))
    """
    warnings: list[str] = []
    sql_lower = sql.lower()
    for param in ("region", "area", "market"):
        if f":{param}" not in sql_lower:
            continue
        # Check for the null-safe CAST pattern for this specific param
        pattern = rf"CAST\s*\(\s*:{param}\s+AS\s+TEXT\s*\)\s+IS\s+NULL"
        if not re.search(pattern, sql, re.IGNORECASE):
            warnings.append(
                f"Parameter :{param} is used but lacks a null-safe guard. "
                f"At overall level :{param} is NULL and bare equality "
                f"(col = :{param}) will return no rows. Recommended pattern: "
                f"(CAST(:{param} AS TEXT) IS NULL OR LOWER(col) = LOWER(CAST(:{param} AS TEXT)))"
            )
    return warnings


_DEFAULT_TEST_PARAMS: dict[str, Any] = {
    "level": "overall",
    "region": None,
    "area": None,
    "market": None,
    "start_date": "2024-01-01",
    "end_date": "2024-12-31",
    "limit": 50,
}

_PARAM_RE = re.compile(r":([a-zA-Z_][a-zA-Z0-9_]*)")


@router.post(
    "/sql-queries/validate",
    summary="Test-run a parameterised SQL query against the source DB",
)
async def validate_sql_query(
    body: ValidateSqlRequest,
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> dict:
    """
    Executes the provided SQL against the source database using safe test
    parameters.  Returns columns, a sample of rows, and execution time.

    Default test params: ``level='overall'``, ``region/area/market=NULL``,
    ``start_date='2024-01-01'``, ``end_date='2024-12-31'``, ``limit=50``.

    Supply ``test_params`` in the request body to override any of these.
    """
    # Build param dict: defaults → user overrides → clamp limit
    bound: dict[str, Any] = {**_DEFAULT_TEST_PARAMS}
    if body.test_params:
        bound.update(body.test_params)
    bound["limit"] = min(int(bound.get("limit", 50)), body.row_limit)

    # Only include params that actually appear in the SQL
    used_keys = set(_PARAM_RE.findall(body.sql))
    bound = {k: v for k, v in bound.items() if k in used_keys}

    # Build explicit bindparams so asyncpg never has to guess types
    bp_list = [
        bindparam(k, type_=String) if k != "limit" else bindparam(k)
        for k in bound
    ]
    stmt = text(body.sql).bindparams(*bp_list)

    source_factory = get_source_session_factory()
    async with source_factory() as source_db:
        try:
            t0 = time.perf_counter()
            result = await source_db.execute(stmt, bound)
            elapsed_ms = (time.perf_counter() - t0) * 1000

            col_names = list(result.keys())
            rows_raw = result.fetchall()
            rows = [
                {col: _coerce_value(v) for col, v in zip(col_names, row)}
                for row in rows_raw
            ]
            warnings = _check_null_safe_geo_params(body.sql)
            return {
                "success": True,
                "columns": col_names,
                "rows": rows,
                "row_count": len(rows),
                "execution_time_ms": round(elapsed_ms, 1),
                "error": None,
                "warnings": warnings,
            }
        except Exception as exc:
            return {
                "success": False,
                "columns": [],
                "rows": [],
                "row_count": 0,
                "execution_time_ms": None,
                "error": str(exc),
                "warnings": [],
            }


# ------------------------------------------------------------------ #
# Private helpers
# ------------------------------------------------------------------ #

async def _get_defn_or_404(db: AsyncSession, table_def_id: str) -> DerivedTableDefinition:
    result = await db.execute(
        select(DerivedTableDefinition).where(
            DerivedTableDefinition.table_def_id == table_def_id
        )
    )
    defn = result.scalar_one_or_none()
    if not defn:
        raise NotFoundError("DerivedTableDefinition", table_def_id)
    return defn


_IDENT_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*$")


async def _fetch_column_info(
    db: AsyncSession, schema_name: str, table_name: str
) -> list[ColumnInfo]:
    """
    Return columns with data types from pg_catalog.

    pg_namespace.nspname and pg_class.relname are PostgreSQL ``name`` type.
    asyncpg cannot bind a SQLAlchemy ``String`` (VARCHAR) to a ``name`` column,
    causing silent failures.  We interpolate the identifiers directly into the
    SQL after validating they contain only safe identifier characters — safe
    because the values originate from our own DerivedTableDefinition record
    (created by an admin via our API), not from raw user input.
    """
    if not _IDENT_RE.match(schema_name) or not _IDENT_RE.match(table_name):
        log.warning(
            "Unsafe identifier rejected in _fetch_column_info: %s.%s",
            schema_name, table_name,
        )
        return []

    # pg_catalog stores identifiers in lowercase (PostgreSQL folds unquoted
    # identifiers to lowercase at creation time).
    schema_lc = schema_name.lower()
    table_lc = table_name.lower()

    sql = (
        f"SELECT a.attname, pg_catalog.format_type(a.atttypid, a.atttypmod) "
        f"FROM pg_catalog.pg_attribute  a "
        f"JOIN pg_catalog.pg_class      c ON c.oid = a.attrelid "
        f"JOIN pg_catalog.pg_namespace  n ON n.oid = c.relnamespace "
        f"WHERE n.nspname = '{schema_lc}' AND c.relname = '{table_lc}' "
        f"  AND a.attnum > 0 AND NOT a.attisdropped "
        f"ORDER BY a.attnum"
    )
    try:
        result = await db.execute(text(sql))
        rows = result.fetchall()
        if not rows:
            log.warning(
                "_fetch_column_info: no columns found for %s.%s (queried as %s.%s) — "
                "table may not exist in source DB or user lacks access",
                schema_name, table_name, schema_lc, table_lc,
            )
        return [ColumnInfo(name=row[0], data_type=row[1]) for row in rows]
    except Exception as exc:
        log.warning("Could not fetch column info for %s.%s: %s", schema_name, table_name, exc)
        return []


def _defn_to_response(defn: DerivedTableDefinition) -> DerivedTableResponse:
    return DerivedTableResponse(
        table_def_id=defn.table_def_id,
        table_name=defn.table_name,
        schema_name=defn.schema_name,
        description=defn.description or "",
        business_context=defn.business_context or "",
        source_tables=defn.source_tables or [],
        join_logic=defn.join_logic or "",
        filter_logic=defn.filter_logic,
        additional_logic=defn.additional_logic,
        generated_ddl=defn.generated_ddl,
        refresh_mode=defn.refresh_mode,
        status=defn.status,
        last_refreshed_at=defn.last_refreshed_at,
        row_count=defn.row_count,
        last_error=defn.last_error,
        created_at=defn.created_at,
    )


async def _get_query_or_404(db: AsyncSession, query_id: str) -> SqlQueryLibrary:
    result = await db.execute(
        select(SqlQueryLibrary).where(SqlQueryLibrary.query_id == query_id)
    )
    q = result.scalar_one_or_none()
    if not q:
        raise NotFoundError("SqlQueryLibrary", query_id)
    return q


def _query_to_list_item(q: SqlQueryLibrary) -> SqlQueryListItem:
    return SqlQueryListItem(
        query_id=str(q.query_id),
        name=q.name,
        query_sql=q.query_sql,
        purpose=q.purpose,
        description=q.description,
        geography_level=q.geography_level,
        prompt_template_id=q.prompt_template_id,
        pm_category=q.pm_category,
        pack_id=q.pack_id,
        projects=q.projects,
        functions=q.functions,
        tags=q.tags,
        team=q.team,
        is_active=q.is_active,
        version=q.version,
        business_context=q.business_context,
        row_limit=q.row_limit,
        group_by_column=q.group_by_column,
        insight_areas=q.insight_areas,
    )


def _columns_from_ddl(generated_ddl: str) -> list[ColumnInfo]:
    """
    Best-effort extraction of column names from a stored ``CREATE TABLE AS SELECT`` DDL.

    Parses the top-level SELECT aliases (``AS alias_name``) and bare column
    references (``table.col_name`` or bare ``col_name``).  Data type is reported
    as ``"unknown"`` since we don't execute the DDL — this is a fallback for
    draft tables that haven't been created in the source DB yet.
    """
    # Strip the CREATE TABLE ... AS wrapper to get the raw SELECT
    select_body = re.sub(
        r"^\s*CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?\S+\s+AS\s*",
        "",
        generated_ddl,
        flags=re.IGNORECASE,
    ).strip()

    names: list[str] = []
    seen: set[str] = set()

    # Match explicit aliases:  <expr> AS alias_name  (case-insensitive)
    for m in re.finditer(r"\bAS\s+([A-Za-z_][A-Za-z0-9_]*)", select_body, re.IGNORECASE):
        alias = m.group(1).lower()
        if alias not in seen:
            names.append(alias)
            seen.add(alias)

    # Fallback: bare column refs in SELECT clause (before first FROM/WHERE/GROUP/HAVING/ORDER/LIMIT)
    if not names:
        select_clause = re.split(r"\bFROM\b", select_body, maxsplit=1, flags=re.IGNORECASE)[0]
        for m in re.finditer(r"(?:^|,)\s*(?:\w+\.)?([A-Za-z_][A-Za-z0-9_]*)\s*(?:,|$)", select_clause):
            col = m.group(1).lower()
            if col not in seen:
                names.append(col)
                seen.add(col)

    return [ColumnInfo(name=n, data_type="unknown") for n in names]


async def _resolve_table_context(db: AsyncSession, table_def_id: str) -> str | None:
    """
    Fetch a DerivedTableDefinition and build a plain-text context block for the
    LLM — covers business purpose, source tables, join logic, filter conditions,
    and any additional computed-column logic.

    Returns None if the definition is not found (non-fatal — LLM falls back to
    column names only).
    """
    try:
        validate_uuid(table_def_id, "table_def_id")
        result = await db.execute(
            select(DerivedTableDefinition).where(
                DerivedTableDefinition.table_def_id == table_def_id
            )
        )
        defn = result.scalar_one_or_none()
        if not defn:
            log.warning("_resolve_table_context: table_def_id=%s not found", table_def_id)
            return None

        lines: list[str] = []
        if defn.description:
            lines.append(f"Description: {defn.description}")
        if defn.business_context:
            lines.append(f"Business purpose: {defn.business_context}")
        if defn.source_tables:
            lines.append(f"Source tables: {', '.join(defn.source_tables)}")
        if defn.join_logic:
            lines.append(f"Join logic: {defn.join_logic}")
        if defn.filter_logic:
            lines.append(f"Filter conditions (already applied in derived table): {defn.filter_logic}")
        if defn.additional_logic:
            lines.append(f"Computed / derived columns: {defn.additional_logic}")
        if defn.generated_ddl:
            # Strip the CREATE TABLE wrapper and expose just the SELECT body
            select_body = re.sub(
                r"^\s*CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?\S+\s+AS\s*",
                "",
                defn.generated_ddl,
                flags=re.IGNORECASE,
            ).strip()
            lines.append(f"Derived table SQL (actual SELECT — shows every column and its computation):\n```sql\n{select_body}\n```")
        return "\n".join(lines) if lines else None
    except Exception as exc:
        log.warning("_resolve_table_context failed for table_def_id=%s: %s", table_def_id, exc)
        return None
