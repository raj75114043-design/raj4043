"""API v1 router aggregator."""
from fastapi import APIRouter

from app.api.v1 import insights, interactions, search, admin, builder, users, email, ingest, sql_ingest

router = APIRouter(prefix="/api/v1")
router.include_router(insights.router)
router.include_router(interactions.router)
router.include_router(search.router)
router.include_router(admin.router)
router.include_router(builder.router)
router.include_router(users.router)
router.include_router(email.router)
router.include_router(ingest.router)
router.include_router(sql_ingest.router)
