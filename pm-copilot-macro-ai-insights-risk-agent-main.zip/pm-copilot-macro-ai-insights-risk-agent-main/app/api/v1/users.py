"""
User profile and preferences API.

GET  /api/v1/users/me              — current user identity + preferences
PATCH /api/v1/users/me/preferences — save / update default filter preferences
"""
from __future__ import annotations

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.middleware.auth import CurrentUser, get_current_user
from app.models.packs import UserPreferences

router = APIRouter(prefix="/users", tags=["Users"])


# ------------------------------------------------------------------ #
# Schemas (local — no separate file needed yet)
# ------------------------------------------------------------------ #

class PreferencesPayload(BaseModel):
    """
    All fields are optional; PATCH applies only supplied fields.
    Send null to clear an array (removes filter for that dimension).
    """
    projects: list[str] | None = Field(None, examples=[["NTM", "AHLOB"]])
    functions: list[str] | None = Field(None, examples=[["PDM", "HSE"]])
    categories: list[str] | None = Field(None, examples=[["Cost", "Vendor Performance"]])
    geo_level: str | None = Field(None, pattern=r"^(overall|region|area|market)$")
    geo_regions: list[str] | None = None
    geo_areas: list[str] | None = None
    geo_markets: list[str] | None = None
    threshold_pct: float | None = Field(None, ge=0.0, le=100.0)


class PreferencesResponse(PreferencesPayload):
    pref_id: str
    user_id: str

    model_config = {"from_attributes": True}


class UserMeResponse(BaseModel):
    user_id: str
    email: str | None = None
    name: str | None = None
    preferences: PreferencesResponse | None = None


# ------------------------------------------------------------------ #
# GET /users/me
# ------------------------------------------------------------------ #
@router.get("/me", response_model=UserMeResponse)
async def get_me(
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> UserMeResponse:
    """Return the current user's identity and saved preferences."""
    stmt = select(UserPreferences).where(UserPreferences.user_id == current_user.user_id)
    prefs = (await db.execute(stmt)).scalar_one_or_none()

    return UserMeResponse(
        user_id=current_user.user_id,
        email=getattr(current_user, "email", None),
        name=getattr(current_user, "name", None),
        preferences=PreferencesResponse.model_validate(prefs) if prefs else None,
    )


# ------------------------------------------------------------------ #
# PATCH /users/me/preferences
# ------------------------------------------------------------------ #
@router.patch("/me/preferences", response_model=PreferencesResponse)
async def update_preferences(
    payload: PreferencesPayload,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> PreferencesResponse:
    """
    Upsert the current user's default filter preferences.

    Only fields included in the request body are updated.
    To clear an array (remove a filter), pass an explicit empty list [].
    """
    stmt = select(UserPreferences).where(UserPreferences.user_id == current_user.user_id)
    prefs = (await db.execute(stmt)).scalar_one_or_none()

    if prefs is None:
        prefs = UserPreferences(
            pref_id=str(uuid.uuid4()),
            user_id=current_user.user_id,
        )
        db.add(prefs)

    # Apply only the fields that were explicitly provided in the payload
    update_data = payload.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        # Treat empty list same as None (no filter) for array fields
        if isinstance(value, list) and len(value) == 0:
            value = None
        setattr(prefs, field, value)

    await db.commit()
    await db.refresh(prefs)

    return PreferencesResponse.model_validate(prefs)
