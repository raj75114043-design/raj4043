"""
User interactions API — POST /api/v1/interactions/*

All interaction operations are:
  - Reversible (toggle-based)
  - Idempotent (safe to call multiple times)
  - Audited (previous_state stored in JSONB)
"""
from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, Path
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.middleware.auth import CurrentUser, get_current_user
from app.middleware.error_handler import NotFoundError
from app.models.insights import Insight
from app.models.interactions import UserInteraction
from app.schemas.interactions import (
    CommentRequest,
    DeleteCommentRequest,
    FlagRequest,
    InteractionRequest,
    InteractionResponse,
    UserInteractionsResponse,
)
from app.utils.validators import validate_uuid

router = APIRouter(prefix="/interactions", tags=["Interactions"])


# ------------------------------------------------------------------ #
# Helper: get-or-create interaction row
# ------------------------------------------------------------------ #
async def _get_or_create_interaction(
    db: AsyncSession, insight_id: str, user_id: str
) -> UserInteraction:
    """Fetch existing interaction or create a blank one."""
    stmt = select(UserInteraction).where(
        UserInteraction.insight_id == insight_id,
        UserInteraction.user_id == user_id,
    )
    result = await db.execute(stmt)
    interaction = result.scalar_one_or_none()

    if not interaction:
        interaction = UserInteraction(insight_id=insight_id, user_id=user_id)
        db.add(interaction)
        await db.flush()

    return interaction


async def _assert_insight_exists(db: AsyncSession, insight_id: str) -> None:
    stmt = select(Insight.insight_id).where(Insight.insight_id == insight_id)
    result = await db.execute(stmt)
    if not result.scalar_one_or_none():
        raise NotFoundError("Insight", insight_id)


def _save_state_and_return(interaction: UserInteraction) -> InteractionResponse:
    """Snapshot current state → previous_state and return response model."""
    interaction.previous_state = interaction.to_state_snapshot()
    return InteractionResponse.model_validate(interaction)


# ------------------------------------------------------------------ #
# Toggle: LIKE
# ------------------------------------------------------------------ #
@router.post("/{insight_id}/like", response_model=InteractionResponse)
async def toggle_like(
    insight_id: Annotated[str, Path()],
    body: InteractionRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> InteractionResponse:
    """Toggle like on an insight. Liking clears any dislike."""
    validate_uuid(insight_id, "insight_id")
    await _assert_insight_exists(db, insight_id)

    interaction = await _get_or_create_interaction(db, insight_id, body.user_id)
    snapshot = interaction.to_state_snapshot()

    # Toggle
    interaction.liked = not bool(interaction.liked)
    if interaction.liked:
        interaction.disliked = False  # mutually exclusive

    interaction.previous_state = snapshot
    await db.flush()
    await db.refresh(interaction)
    return InteractionResponse.model_validate(interaction)


# ------------------------------------------------------------------ #
# Toggle: DISLIKE
# ------------------------------------------------------------------ #
@router.post("/{insight_id}/dislike", response_model=InteractionResponse)
async def toggle_dislike(
    insight_id: Annotated[str, Path()],
    body: InteractionRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> InteractionResponse:
    """Toggle dislike on an insight. Disliking clears any like."""
    validate_uuid(insight_id, "insight_id")
    await _assert_insight_exists(db, insight_id)

    interaction = await _get_or_create_interaction(db, insight_id, body.user_id)
    snapshot = interaction.to_state_snapshot()

    interaction.disliked = not bool(interaction.disliked)
    if interaction.disliked:
        interaction.liked = False  # mutually exclusive

    interaction.previous_state = snapshot
    await db.flush()
    await db.refresh(interaction)
    return InteractionResponse.model_validate(interaction)


# ------------------------------------------------------------------ #
# Toggle: ACKNOWLEDGE
# ------------------------------------------------------------------ #
@router.post("/{insight_id}/acknowledge", response_model=InteractionResponse)
async def toggle_acknowledge(
    insight_id: Annotated[str, Path()],
    body: InteractionRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> InteractionResponse:
    """Toggle acknowledgment of an insight."""
    validate_uuid(insight_id, "insight_id")
    await _assert_insight_exists(db, insight_id)

    interaction = await _get_or_create_interaction(db, insight_id, body.user_id)
    snapshot = interaction.to_state_snapshot()
    interaction.acknowledged = not bool(interaction.acknowledged)
    interaction.previous_state = snapshot
    await db.flush()
    await db.refresh(interaction)
    return InteractionResponse.model_validate(interaction)


# ------------------------------------------------------------------ #
# Toggle: MUTE
# ------------------------------------------------------------------ #
@router.post("/{insight_id}/mute", response_model=InteractionResponse)
async def toggle_mute(
    insight_id: Annotated[str, Path()],
    body: InteractionRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> InteractionResponse:
    """Toggle mute — muted insights are hidden from the user's feed."""
    validate_uuid(insight_id, "insight_id")
    await _assert_insight_exists(db, insight_id)

    interaction = await _get_or_create_interaction(db, insight_id, body.user_id)
    snapshot = interaction.to_state_snapshot()
    interaction.muted = not bool(interaction.muted)
    interaction.previous_state = snapshot
    await db.flush()
    await db.refresh(interaction)
    return InteractionResponse.model_validate(interaction)


# ------------------------------------------------------------------ #
# Toggle: FLAG
# ------------------------------------------------------------------ #
@router.post("/{insight_id}/flag", response_model=InteractionResponse)
async def toggle_flag(
    insight_id: Annotated[str, Path()],
    body: FlagRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> InteractionResponse:
    """Toggle flag on an insight — optionally record a reason."""
    validate_uuid(insight_id, "insight_id")
    await _assert_insight_exists(db, insight_id)

    interaction = await _get_or_create_interaction(db, insight_id, body.user_id)
    snapshot = interaction.to_state_snapshot()
    interaction.flagged = not bool(interaction.flagged)
    if interaction.flagged:
        interaction.flag_reason = body.reason
    else:
        interaction.flag_reason = None  # clear reason when unflagging

    interaction.previous_state = snapshot
    await db.flush()
    await db.refresh(interaction)
    return InteractionResponse.model_validate(interaction)


# ------------------------------------------------------------------ #
# COMMENT — add / update
# ------------------------------------------------------------------ #
@router.post("/{insight_id}/comment", response_model=InteractionResponse)
async def add_or_update_comment(
    insight_id: Annotated[str, Path()],
    body: CommentRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> InteractionResponse:
    """Add or update a comment on an insight."""
    validate_uuid(insight_id, "insight_id")
    await _assert_insight_exists(db, insight_id)

    interaction = await _get_or_create_interaction(db, insight_id, body.user_id)
    snapshot = interaction.to_state_snapshot()
    interaction.comment = body.comment
    interaction.previous_state = snapshot
    await db.flush()
    await db.refresh(interaction)
    return InteractionResponse.model_validate(interaction)


# ------------------------------------------------------------------ #
# COMMENT — delete
# ------------------------------------------------------------------ #
@router.delete("/{insight_id}/comment", response_model=InteractionResponse)
async def delete_comment(
    insight_id: Annotated[str, Path()],
    body: DeleteCommentRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> InteractionResponse:
    """Remove a user's comment from an insight."""
    validate_uuid(insight_id, "insight_id")
    await _assert_insight_exists(db, insight_id)

    interaction = await _get_or_create_interaction(db, insight_id, body.user_id)
    snapshot = interaction.to_state_snapshot()
    interaction.comment = None
    interaction.previous_state = snapshot
    await db.flush()
    await db.refresh(interaction)
    return InteractionResponse.model_validate(interaction)


# ------------------------------------------------------------------ #
# GET /interactions/user/{user_id} — all interactions for a user
# ------------------------------------------------------------------ #
@router.get("/user/{user_id}", response_model=UserInteractionsResponse)
async def get_user_interactions(
    user_id: Annotated[str, Path(description="User identifier")],
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> UserInteractionsResponse:
    """Retrieve all interactions recorded for the specified user."""
    stmt = (
        select(UserInteraction)
        .where(UserInteraction.user_id == user_id)
        .order_by(UserInteraction.updated_at.desc().nullslast())
    )
    result = await db.execute(stmt)
    items = list(result.scalars().all())

    return UserInteractionsResponse(
        user_id=user_id,
        items=[InteractionResponse.model_validate(i) for i in items],
        total=len(items),
    )
