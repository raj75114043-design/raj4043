"""
Semantic search API — POST /api/v1/search/semantic
"""
from __future__ import annotations

from typing import Annotated

import logging

from fastapi import APIRouter, Depends
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.middleware.auth import CurrentUser, get_current_user
from app.models.insights import Insight
from app.schemas.insights import InsightResponse
from app.schemas.search import (
    SemanticSearchRequest,
    SemanticSearchResponse,
    SemanticSearchResult,
)
from app.config import get_settings
from app.services.embedding_service import EmbeddingService

log = logging.getLogger(__name__)

router = APIRouter(prefix="/search", tags=["Search"])
_embedding_service = EmbeddingService()
_settings = get_settings()


async def _has_any_embeddings(db: AsyncSession) -> bool:
    result = await db.execute(
        text(f"SELECT EXISTS(SELECT 1 FROM {_settings.table_insight_embeddings} LIMIT 1)")
    )
    return bool(result.scalar_one())


@router.post("/semantic", response_model=SemanticSearchResponse)
async def semantic_search(
    body: SemanticSearchRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> SemanticSearchResponse:
    """
    Find insights semantically similar to the natural-language query.

    Steps:
    1. Embed the query text using the configured embedding model.
    2. Perform cosine-similarity vector search via pgvector.
    3. Apply optional structured filters.
    4. Return ranked results with similarity scores.
    """
    filters = body.filters.model_dump(exclude_none=True) if body.filters else {}

    # Vector search → list of (insight_id, score)
    ranked = await _embedding_service.semantic_search(
        db,
        body.query,
        limit=body.limit,
        similarity_threshold=body.similarity_threshold,
        filters=filters or None,
    )

    if not ranked:
        return SemanticSearchResponse(
            query=body.query,
            results=[],
            total_found=0,
            message=(
                "No embeddings found in the database. "
                "Run POST /api/v1/admin/backfill-embeddings to generate them."
                if not await _has_any_embeddings(db)
                else f"No results above similarity threshold {body.similarity_threshold}. "
                "Try lowering similarity_threshold or rephrasing your query."
            ),
        )

    # Bulk fetch insight objects in one query (preserve ranking order)
    ids = [r[0] for r in ranked]
    score_by_id = {r[0]: r[1] for r in ranked}

    log.info("search: vector_search_returned=%d ids=%s", len(ids), ids[:3])

    stmt = select(Insight).where(Insight.insight_id.in_(ids))
    result = await db.execute(stmt)
    insights_by_id = {i.insight_id: i for i in result.scalars().all()}

    log.info(
        "search: orm_fetch_returned=%d (expected %d) — missing=%s",
        len(insights_by_id),
        len(ids),
        [i for i in ids if i not in insights_by_id],
    )

    # Build ordered results
    results = []
    for insight_id in ids:
        insight = insights_by_id.get(insight_id)
        if insight:
            results.append(
                SemanticSearchResult(
                    insight=InsightResponse.model_validate(insight),
                    similarity_score=round(score_by_id[insight_id], 4),
                )
            )

    return SemanticSearchResponse(
        query=body.query,
        results=results,
        total_found=len(results),
    )
