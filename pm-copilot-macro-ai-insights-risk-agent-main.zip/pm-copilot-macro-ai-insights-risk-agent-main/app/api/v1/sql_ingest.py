"""
SQL-first free-form KPI onboarding API.

Endpoints
---------
POST /ingest/sql/analyse   SQL + free-form context → LLM infers metadata (for review)
POST /ingest/sql/apply     Reviewed/corrected metadata → test SQL → persist
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db, get_source_db
from app.schemas.sql_ingest import (
    SqlAnalyseResponse,
    SqlApplyRequest,
    SqlApplyResponse,
    SqlContextRequest,
)
from app.services import sql_ingest_service as svc

log = logging.getLogger(__name__)

router = APIRouter(prefix="/ingest/sql", tags=["ingest-sql"])


@router.post(
    "/analyse",
    response_model=SqlAnalyseResponse,
    summary="SQL + free-form context → LLM-inferred metadata (review before applying)",
)
async def analyse_sql(
    request: SqlContextRequest,
    source_db: AsyncSession = Depends(get_source_db),
):
    """
    Two things happen in this call:

    1. The LLM reads your SQL query and free-form context description and produces
       structured metadata: geography level (inferred from GROUP BY), category,
       targets, SLA thresholds, interpretation, and a richly-worded `business_context`
       that the engine injects into LLM prompts at insight generation time.

    2. The SQL is test-run against the source database (LIMIT 5) to confirm it executes.

    **Nothing is written to the database.** Review the `inferred` block, correct any
    fields as needed, then submit the result to `/ingest/sql/apply`.
    """
    return await svc.analyse(request, source_db)


@router.post(
    "/apply",
    response_model=SqlApplyResponse,
    summary="Apply reviewed metadata → test SQL → persist to query library",
)
async def apply_sql(
    request: SqlApplyRequest,
    source_db: AsyncSession = Depends(get_source_db),
    insights_db: AsyncSession = Depends(get_db),
):
    """
    Finalise onboarding:

    1. Re-runs the SQL as a safety test.
    2. Persists the KPI (SQL + metadata + business_context) to the `sql_query_library`
       table, making it immediately available for the next batch insight generation job.

    Submit the `inferred` block from `/analyse` as the request body, with any
    corrections you have made (e.g. fixing the `geography_level` or adjusting thresholds).
    """
    try:
        return await svc.apply(request, source_db, insights_db)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
