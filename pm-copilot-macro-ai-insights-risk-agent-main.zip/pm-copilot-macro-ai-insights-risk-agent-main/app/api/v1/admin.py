"""
Admin / Orchestration API — POST /api/v1/admin/*

All admin endpoints require the `admin` role.
Batch jobs are dispatched asynchronously via Celery.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Annotated

from fastapi import APIRouter, BackgroundTasks, Depends
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.middleware.auth import CurrentUser, require_admin
from app.middleware.error_handler import NotFoundError
from app.models.jobs import BatchJob, BatchJobLog
from app.schemas.admin import (
    ArchiveRequest,
    ArchiveResponse,
    BackfillEmbeddingsRequest,
    BackfillEmbeddingsResponse,
    GenerateInsightsRequest,
    GenerateInsightsResponse,
    HierarchicalInsightsRequest,
    JobStatusResponse,
    QuickHierarchicalRequest,
)
from app.services.archival_service import ArchivalService
from app.utils.validators import validate_uuid

router = APIRouter(prefix="/admin", tags=["Admin"])
_archival_service = ArchivalService()


# ------------------------------------------------------------------ #
# POST /admin/generate-insights — kick off batch job
# ------------------------------------------------------------------ #
@router.post("/generate-insights", response_model=GenerateInsightsResponse, status_code=202)
async def generate_insights(
    body: GenerateInsightsRequest,
    background_tasks: BackgroundTasks,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> GenerateInsightsResponse:
    """
    Trigger a batch insight generation run.

    The job is created synchronously (returns a job_id immediately) and
    then processed asynchronously in the background.

    Geography and timeframe filters control which queries are executed
    and at which geographic granularity.
    """
    job_id = str(uuid.uuid4())

    # Persist job record
    job = BatchJob(
        job_id=job_id,
        status="pending",
        geography_filters=body.geography_filters.model_dump(mode="json") if body.geography_filters else None,
        timeframe=body.timeframe.model_dump(mode="json") if body.timeframe else None,
        query_tags={
            "projects": body.projects,
            "functions": body.functions,
            "pack_ids": body.pack_ids,
            "query_ids": body.query_ids,
        },
        triggered_by=current_user.user_id,
    )
    db.add(job)
    await db.commit()

    # Dispatch async job
    background_tasks.add_task(_run_batch_job, job_id, body)

    return GenerateInsightsResponse(
        job_id=job_id,
        status="pending",
        message="Batch insight generation job queued successfully.",
    )


async def _run_batch_job(job_id: str, request: GenerateInsightsRequest) -> None:
    """Background task: run the InsightAgent pipeline."""
    from app.agents.insight_agent import InsightAgent
    agent = InsightAgent()
    try:
        await agent.run(job_id, request)
    except Exception as exc:
        import logging
        logging.getLogger(__name__).error("Batch job %s failed: %s", job_id, exc, exc_info=True)
        # Update job to failed state
        from sqlalchemy import update
        from app.database import get_insights_session_factory
        factory = get_insights_session_factory()
        async with factory() as db:
            await db.execute(
                update(BatchJob)
                .where(BatchJob.job_id == job_id)
                .values(
                    status="failed",
                    error_message=str(exc),
                    completed_at=datetime.now(timezone.utc),
                )
            )
            await db.commit()


# ------------------------------------------------------------------ #
# POST /admin/generate-insights-hierarchical — hierarchical drill-down
# ------------------------------------------------------------------ #
@router.post("/generate-insights-hierarchical", response_model=GenerateInsightsResponse, status_code=202)
async def generate_insights_hierarchical(
    body: HierarchicalInsightsRequest,
    background_tasks: BackgroundTasks,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> GenerateInsightsResponse:
    """
    Trigger a hierarchical insight generation run.

    Starts at the OVERALL level, generates insights, then uses the LLM to
    decide which regions/areas/markets have problems worth investigating
    deeper. Only drills into flagged nodes, so compute scales with the
    number of actual problem areas rather than the full geo tree.

    Controls:
    - max_depth: how many levels to drill (1–4, default 4)
    - max_children_per_level: how many children to explore per node (default 3)
    - severity_floor: min avg severity to trigger drilling (default 40/100)
    """
    job_id = str(uuid.uuid4())

    job = BatchJob(
        job_id=job_id,
        status="pending",
        geography_filters={"mode": "hierarchical"},
        timeframe=body.timeframe.model_dump(mode="json") if body.timeframe else None,
        query_tags={
            "projects": body.projects,
            "functions": body.functions,
            "pack_ids": body.pack_ids,
            "query_ids": body.query_ids,
        },
        triggered_by=current_user.user_id,
    )
    db.add(job)
    await db.commit()

    background_tasks.add_task(_run_hierarchical_job, job_id, body)

    return GenerateInsightsResponse(
        job_id=job_id,
        status="pending",
        message=(
            f"Hierarchical insight generation queued. "
            f"max_depth={body.max_depth}, max_children={body.max_children_per_level}, "
            f"severity_floor={body.severity_floor}"
        ),
    )


async def _run_hierarchical_job(job_id: str, request: HierarchicalInsightsRequest) -> None:
    """Background task: run the HierarchicalInsightAgent pipeline."""
    from app.agents.hierarchical_agent import HierarchicalInsightAgent
    agent = HierarchicalInsightAgent()
    try:
        await agent.run(job_id, request)
    except Exception as exc:
        import logging
        logging.getLogger(__name__).error(
            "Hierarchical job %s failed: %s", job_id, exc, exc_info=True
        )
        from sqlalchemy import update
        from app.database import get_insights_session_factory
        factory = get_insights_session_factory()
        async with factory() as db:
            await db.execute(
                update(BatchJob)
                .where(BatchJob.job_id == job_id)
                .values(
                    status="failed",
                    error_message=str(exc),
                    completed_at=datetime.now(timezone.utc),
                )
            )
            await db.commit()


# ------------------------------------------------------------------ #
# POST /admin/generate-insights-hierarchical-quick — last N queries
# ------------------------------------------------------------------ #
@router.post(
    "/generate-insights-hierarchical-quick",
    response_model=GenerateInsightsResponse,
    status_code=202,
)
async def generate_insights_hierarchical_quick(
    body: QuickHierarchicalRequest,
    background_tasks: BackgroundTasks,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> GenerateInsightsResponse:
    """
    Trigger hierarchical insight generation for the **last N added** active
    queries (ordered by created_at DESC).

    This is a convenience endpoint — it fetches the query IDs internally and
    delegates to the standard hierarchical pipeline.
    """
    from app.models.query_library import SqlQueryLibrary

    # Fetch last N active query IDs ordered by most recently created
    stmt = (
        select(SqlQueryLibrary.query_id)
        .where(SqlQueryLibrary.is_active.is_(True))
        .order_by(SqlQueryLibrary.created_at.desc())
        .limit(body.last_n_queries)
    )
    result = await db.execute(stmt)
    query_ids = [str(row[0]) for row in result.all()]

    if not query_ids:
        return GenerateInsightsResponse(
            job_id="",
            status="skipped",
            message="No active queries found in the library.",
            estimated_queries=0,
        )

    # Build a standard HierarchicalInsightsRequest with the resolved query IDs
    hierarchical_request = HierarchicalInsightsRequest(
        query_ids=query_ids,
        max_depth=body.max_depth,
        max_children_per_level=body.max_children_per_level,
        severity_floor=body.severity_floor,
        max_parallel=body.max_parallel,
        vendor_grouping=body.vendor_grouping,
    )

    job_id = str(uuid.uuid4())
    job = BatchJob(
        job_id=job_id,
        status="pending",
        geography_filters={"mode": "hierarchical-quick"},
        query_tags={"query_ids": query_ids},
        triggered_by=current_user.user_id,
    )
    db.add(job)
    await db.commit()

    background_tasks.add_task(_run_hierarchical_job, job_id, hierarchical_request)

    return GenerateInsightsResponse(
        job_id=job_id,
        status="pending",
        message=(
            f"Hierarchical run queued for the last {len(query_ids)} queries. "
            f"max_depth={body.max_depth}, severity_floor={body.severity_floor}"
        ),
        estimated_queries=len(query_ids),
    )


# ------------------------------------------------------------------ #
# GET /admin/jobs/{job_id} — job status
# ------------------------------------------------------------------ #
@router.get("/jobs/{job_id}", response_model=JobStatusResponse)
async def get_job_status(
    job_id: str,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> JobStatusResponse:
    """Retrieve the current status and progress of a batch generation job."""
    validate_uuid(job_id, "job_id")

    stmt = select(BatchJob).where(BatchJob.job_id == job_id)
    result = await db.execute(stmt)
    job = result.scalar_one_or_none()

    if not job:
        raise NotFoundError("BatchJob", job_id)

    # Fetch last 10 log entries
    log_stmt = (
        select(BatchJobLog)
        .where(BatchJobLog.job_id == job_id)
        .order_by(BatchJobLog.created_at.desc())
        .limit(10)
    )
    log_result = await db.execute(log_stmt)
    recent_logs = [
        {
            "level": l.level,
            "step": l.step,
            "message": l.message,
            "created_at": l.created_at.isoformat() if l.created_at else None,
        }
        for l in log_result.scalars().all()
    ]

    return JobStatusResponse(
        job_id=job.job_id,
        status=job.status,
        total_queries=job.total_queries,
        completed_queries=job.completed_queries,
        failed_queries=job.failed_queries,
        total_insights_generated=job.total_insights_generated,
        progress_pct=job.progress_pct,
        created_at=job.created_at,
        started_at=job.started_at,
        completed_at=job.completed_at,
        error_message=job.error_message,
        recent_logs=recent_logs,
        insight_ids=job.insight_ids,
    )


# ------------------------------------------------------------------ #
# POST /admin/archive-old-insights
# ------------------------------------------------------------------ #
@router.post("/archive-old-insights", response_model=ArchiveResponse)
async def archive_old_insights(
    body: ArchiveRequest,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> ArchiveResponse:
    """
    Move insights older than `days_threshold` days to the historical table.

    Use `dry_run=true` to preview the count without making changes.
    """
    count = await _archival_service.archive_old_insights(
        db,
        days_threshold=body.days_threshold,
        dry_run=body.dry_run,
    )

    if body.dry_run:
        message = f"{count} insight(s) would be archived (dry run — no changes made)."
    else:
        message = f"Successfully archived {count} insight(s) to historical table."

    return ArchiveResponse(
        insights_archived=count,
        dry_run=body.dry_run,
        message=message,
    )


# ------------------------------------------------------------------ #
# POST /admin/backfill-embeddings
# ------------------------------------------------------------------ #
@router.post("/backfill-embeddings", response_model=BackfillEmbeddingsResponse, status_code=202)
async def backfill_embeddings(
    body: BackfillEmbeddingsRequest,
    background_tasks: BackgroundTasks,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(require_admin)],
) -> BackfillEmbeddingsResponse:
    """
    Generate embeddings for active insights that are missing them.

    Use `dry_run=true` to count pending insights without starting generation.
    Use `limit` to cap how many are processed in one run.
    Runs asynchronously in the background — returns immediately.
    """
    from sqlalchemy import exists, func, select
    from app.models.insights import Insight
    from app.models.embeddings import InsightEmbedding

    stmt = (
        select(func.count())
        .select_from(Insight)
        .where(
            Insight.is_active.is_(True),
            ~exists().where(InsightEmbedding.insight_id == Insight.insight_id),
        )
    )
    pending_count: int = (await db.execute(stmt)).scalar_one()

    if body.dry_run:
        return BackfillEmbeddingsResponse(
            pending_count=pending_count,
            started=False,
            message=f"{pending_count} insight(s) need embeddings (dry run — no changes made).",
        )

    if pending_count == 0:
        return BackfillEmbeddingsResponse(
            pending_count=0,
            started=False,
            message="All active insights already have embeddings.",
        )

    background_tasks.add_task(_run_backfill, body.limit)
    cap = body.limit if body.limit and body.limit < pending_count else pending_count
    return BackfillEmbeddingsResponse(
        pending_count=pending_count,
        started=True,
        message=f"Embedding backfill started — processing up to {cap} insight(s) in the background.",
    )


async def _run_backfill(limit: int | None) -> None:
    """Background task: generate and store embeddings for insights that have none."""
    import logging as _logging
    from sqlalchemy import exists, select
    from app.database import get_insights_session_factory
    from app.models.embeddings import InsightEmbedding
    from app.models.insights import Insight
    from app.services.embedding_service import EmbeddingService

    _log = _logging.getLogger(__name__)
    factory = get_insights_session_factory()
    embedding_svc = EmbeddingService()

    async with factory() as session:
        stmt = (
            select(Insight)
            .where(
                Insight.is_active.is_(True),
                ~exists().where(InsightEmbedding.insight_id == Insight.insight_id),
            )
            .order_by(Insight.created_at.asc())
        )
        if limit:
            stmt = stmt.limit(limit)

        result = await session.execute(stmt)
        insights = result.scalars().all()

        created = failed = 0
        for insight in insights:
            try:
                text = EmbeddingService.build_embedding_text(
                    insight.title, insight.insight, insight.tags
                )
                await embedding_svc.embed_and_store(session, insight.insight_id, text)
                await session.commit()
                created += 1
            except Exception as exc:
                await session.rollback()
                _log.warning("Backfill embedding failed for %s: %s", insight.insight_id, exc)
                failed += 1

    _log.info("Embedding backfill complete: created=%d failed=%d", created, failed)
