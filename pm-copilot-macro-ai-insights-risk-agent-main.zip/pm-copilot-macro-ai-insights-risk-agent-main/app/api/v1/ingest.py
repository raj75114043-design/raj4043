"""
Ingest API — template-based onboarding for the Insights Engine.

Endpoints
---------
GET  /ingest/template           Download the Excel (.xlsx) configuration template
GET  /ingest/template?format=yaml  Download the YAML sample template
POST /ingest/validate           Upload template → parse + validate → return report
POST /ingest/apply              Upload template → validate → generate SQL → test → persist
"""
from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from fastapi.responses import Response
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db, get_source_db
from app.schemas.ingest import (
    IngestReport,
    IngestStatus,
    IngestTemplateData,
    IssueSeverity,
    ValidationIssue,
)
from app.services import template_ingest_service as svc

log = logging.getLogger(__name__)

router = APIRouter(prefix="/ingest", tags=["ingest"])

# Max upload size — 5 MB is well above any realistic template
_MAX_UPLOAD_BYTES = 5 * 1024 * 1024


# ================================================================== #
# Template download
# ================================================================== #
@router.get(
    "/template",
    summary="Download the onboarding template (Excel or YAML)",
    response_class=Response,
)
async def download_template(
    format: str = Query("excel", pattern="^(excel|yaml)$"),
):
    """
    Download a pre-filled template that guides configuration of the engine.

    - **format=excel** (default) — returns an .xlsx workbook with dropdown validation,
      examples, and guidelines across three sheets.
    - **format=yaml** — returns a YAML sample for programmatic / CI-based onboarding.
    """
    if format == "yaml":
        content = svc.generate_yaml_sample()
        return Response(
            content=content,
            media_type="application/x-yaml",
            headers={"Content-Disposition": "attachment; filename=insights_engine_template.yaml"},
        )

    content = svc.generate_excel_template()
    return Response(
        content=content,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=insights_engine_template.xlsx"},
    )


# ================================================================== #
# Validate
# ================================================================== #
@router.post(
    "/validate",
    response_model=IngestReport,
    summary="Upload template → validate without persisting",
)
async def validate_template(
    file: UploadFile = File(...),
    source_db: AsyncSession = Depends(get_source_db),
):
    """
    Parse and validate an uploaded template file (Excel or YAML).

    Returns a full validation report with per-KPI status and issues.
    **Nothing is written to the database.**

    Use this endpoint to check your template before calling `/ingest/apply`.
    """
    content = await file.read()
    if len(content) > _MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File exceeds 5 MB limit.")

    template_data = _parse_upload(file.filename or "", content)
    report = await svc.validate(template_data, source_db)
    return report


# ================================================================== #
# Apply  (validate + generate SQL + test + ingest)
# ================================================================== #
@router.post(
    "/apply",
    response_model=IngestReport,
    summary="Upload template → generate SQL → test → ingest valid KPIs",
)
async def apply_template(
    file: UploadFile = File(...),
    kpi_names: str | None = Query(
        None,
        description="Comma-separated list of kpi_names to ingest; omit to ingest all valid ones.",
    ),
    source_db: AsyncSession = Depends(get_source_db),
    insights_db: AsyncSession = Depends(get_db),
):
    """
    Full onboarding pipeline:

    1. Parse the uploaded file (Excel or YAML).
    2. Validate each KPI definition against the live source database.
    3. For KPIs without `custom_sql`, call the LLM to generate a SQL query.
    4. Test-run each generated SQL against the source DB (LIMIT 5).
    5. Persist valid, tested KPIs to the `sql_query_library` table.
    6. Return a full report showing what was ingested, warned, or skipped.

    **Optional**: supply `kpi_names` to ingest only a subset of the file.
    """
    content = await file.read()
    if len(content) > _MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="File exceeds 5 MB limit.")

    template_data = _parse_upload(file.filename or "", content)

    # Filter KPIs if caller specified a subset
    selected_names: set[str] | None = None
    if kpi_names:
        selected_names = {n.strip() for n in kpi_names.split(",") if n.strip()}
        template_data.kpi_entries = [
            k for k in template_data.kpi_entries
            if k.kpi_name in selected_names
        ]
        if not template_data.kpi_entries:
            raise HTTPException(
                status_code=400,
                detail=f"None of the requested kpi_names found in template: {kpi_names}",
            )

    # Step 1 — Validate
    report = await svc.validate(template_data, source_db)

    # Index kpi_entries by name for later enrichment
    kpi_map = {k.kpi_name: k for k in template_data.kpi_entries}
    ds_map = {ds.table_name: ds for ds in template_data.data_sources}

    # Step 2 & 3 — Generate + test SQL for each valid result
    ingested = 0
    for result in report.kpi_results:
        if result.status == IngestStatus.failed:
            continue  # Skip KPIs with blocking errors

        kpi = kpi_map.get(result.kpi_name)
        if not kpi:
            continue

        # Generate SQL if not already present
        if not result.generated_sql:
            sql, err = await svc.generate_sql_for_kpi(kpi, ds_map, llm_service=None)
            if err or not sql:
                result.status = IngestStatus.failed
                result.issues.append(ValidationIssue(
                    kpi_name=kpi.kpi_name,
                    field="custom_sql",
                    severity=IssueSeverity.error,
                    message=f"SQL generation failed: {err}",
                    suggestion="Provide a custom_sql in the template.",
                ))
                continue
            result.generated_sql = sql
            result.status = IngestStatus.sql_generated

        # Test-run the SQL
        ok, row_count, sql_err = await svc.test_sql(result.generated_sql, source_db)
        if not ok:
            result.sql_test_error = sql_err
            result.status = IngestStatus.failed
            result.issues.append(ValidationIssue(
                kpi_name=kpi.kpi_name,
                field="custom_sql",
                severity=IssueSeverity.error,
                message=f"SQL test-run failed: {sql_err}",
                suggestion="Review the generated SQL or provide a custom_sql override.",
            ))
            continue

        result.sql_test_rows = row_count
        result.status = IngestStatus.sql_tested

        # Ingest
        query_id = await svc.ingest_kpi(kpi, result, insights_db)
        if query_id:
            result.status = IngestStatus.ingested
            result.query_id = query_id
            ingested += 1
        else:
            result.status = IngestStatus.failed

    # Commit if anything was ingested
    if ingested > 0:
        await insights_db.commit()

    report.ingested_count = ingested
    report.applied = True

    # Recalculate counts
    report.valid_count = sum(
        1 for r in report.kpi_results
        if r.status not in (IngestStatus.failed, IngestStatus.skipped)
    )
    report.error_count = sum(1 for r in report.kpi_results if r.status == IngestStatus.failed)

    return report


# ================================================================== #
# Helper
# ================================================================== #
def _parse_upload(filename: str, content: bytes) -> IngestTemplateData:
    lower = filename.lower()
    try:
        if lower.endswith(".yaml") or lower.endswith(".yml"):
            return svc.parse_yaml(content)
        else:
            # Default: Excel
            return svc.parse_excel(content)
    except Exception as exc:
        log.error("Template parse error (%s): %s", filename, exc)
        raise HTTPException(
            status_code=422,
            detail=f"Could not parse template file: {exc}",
        )
