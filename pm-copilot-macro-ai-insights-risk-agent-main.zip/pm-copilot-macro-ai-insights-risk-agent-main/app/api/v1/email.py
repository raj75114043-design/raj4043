"""
Insight Email API — POST /api/v1/email/send-insight

Sends a Nokia-branded HTML email with:
  • Full insight analysis text and metadata
  • Optional custom sender note
  • Excel (.xlsx) attachment with three sheets:
    - Insight Details (metadata)
    - Source Data (aggregated rows fed to AI)
    - Drill-Down Sites (entity-level rows for investigation)

Supports two email backends (set EMAIL_BACKEND in .env):
  • "nokia_gateway"  — Nokia internal JSONRPC mail relay (default)
  • "smtp"           — Standard SMTP (Gmail, Exchange, etc.)
"""
from __future__ import annotations

import base64
import io
import logging
import re
import smtplib
import ssl
import requests
from datetime import datetime
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email import encoders
from typing import Annotated, Any, Dict, List, Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import get_settings
from app.database import get_db
from app.middleware.auth import CurrentUser, get_current_user
from app.middleware.error_handler import NotFoundError
from app.models.insights import Insight
from app.utils.validators import validate_uuid

try:
    import openpyxl
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    _XLSX_AVAILABLE = True
except ImportError:
    _XLSX_AVAILABLE = False

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/email", tags=["Email"])

# ── Nokia Brand Palette ───────────────────────────────────────────────────────
_C = {
    "primary":    "#005AFF",
    "primary_dk": "#0044CC",
    "light":      "#E8F0FF",
    "alt_row":    "#F5F8FF",
    "page_bg":    "#F4F6F9",
    "border":     "#DEE3EB",
    "footer":     "#888888",
    "sev_high":   "#D32F2F",
    "sev_mid":    "#F57C00",
    "sev_low":    "#2E7D32",
}


# ── Request Model ─────────────────────────────────────────────────────────────
class SendInsightEmailRequest(BaseModel):
    """Payload for emailing an insight report."""

    insight_id: str = Field(..., description="UUID of the insight to email")
    to_list: List[str] = Field(
        ..., min_length=1, description="One or more recipient email addresses"
    )
    cc_list: List[str] = Field(default=[], description="CC recipients (optional)")
    bcc_list: List[str] = Field(default=[], description="BCC recipients (optional)")
    custom_message: Optional[str] = Field(
        default=None,
        max_length=1000,
        description="Optional personal note shown at the top of the email",
    )


# ── Utility Helpers ───────────────────────────────────────────────────────────
def _esc(value: Any) -> str:
    """HTML-escape any value to a safe string."""
    if value is None:
        return ""
    return (
        str(value)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&#39;")
    )


def _md_to_html(text: str) -> str:
    """Convert a subset of Markdown to inline HTML suitable for email."""
    if not text:
        return ""
    text = str(text)

    # Fenced code blocks (process before inline code)
    def _code_block(m: re.Match) -> str:
        return (
            '<pre style="background:#f5f5f5;padding:12px 14px;border-radius:5px;'
            "font-family:'Courier New',monospace;font-size:12px;overflow-x:auto;"
            f'line-height:1.5;margin:10px 0;"><code>{_esc(m.group(1).strip())}</code></pre>'
        )

    text = re.sub(r"```(?:\w+\n)?(.*?)```", _code_block, text, flags=re.DOTALL)

    # Line-by-line for bullet lists
    lines = text.split("\n")
    out: List[str] = []
    in_ul = False

    for line in lines:
        if re.match(r"^\s*[-*]\s+", line):
            if not in_ul:
                out.append('<ul style="margin:8px 0 8px 4px;padding-left:18px;">')
                in_ul = True
            item = _inline_md(_esc(re.sub(r"^\s*[-*]\s+", "", line)))
            out.append(f'<li style="margin:4px 0;line-height:1.65;">{item}</li>')
        else:
            if in_ul:
                out.append("</ul>")
                in_ul = False
            if line.strip():
                out.append(
                    f'<p style="margin:6px 0;line-height:1.7;">{_inline_md(_esc(line))}</p>'
                )
            # blank lines: just skip (email clients add space naturally)
    if in_ul:
        out.append("</ul>")

    return "\n".join(out)


def _inline_md(text: str) -> str:
    """Apply inline markdown (bold, italic, code) to already-escaped text."""
    # Bold **...**
    text = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", text)
    # Italic *...* (not preceded/followed by *)
    text = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<em>\1</em>", text)
    # Inline code `...`
    text = re.sub(
        r"`([^`]+)`",
        r'<code style="background:#f0f0f0;padding:2px 5px;border-radius:3px;'
        r"font-family:'Courier New',monospace;font-size:12px;\">\1</code>",
        text,
    )
    return text


def _severity_color(score: float | None) -> str:
    if score is None:
        return _C["footer"]
    return _C["sev_high"] if score >= 67 else (_C["sev_mid"] if score >= 34 else _C["sev_low"])


def _severity_label(score: float | None) -> str:
    if score is None:
        return "N/A"
    return "High" if score >= 67 else ("Medium" if score >= 34 else "Low")


# ── HTML Builders ─────────────────────────────────────────────────────────────

def _build_insight_email(
    insight: Insight,
    custom_message: Optional[str] = None,
) -> str:
    """Render the full Nokia-branded HTML email body for an insight."""

    # ── Derived values ────────────────────────────────────────────────────────
    sev_score = insight.severity_score
    sev_color = _severity_color(sev_score)
    sev_label = _severity_label(sev_score)
    sev_display = f"{sev_label} — {sev_score:.0f} / 100" if sev_score is not None else "N/A"

    created_str = (
        insight.created_at.strftime("%d %b %Y, %H:%M UTC")
        if isinstance(insight.created_at, datetime)
        else str(insight.created_at or "—")
    )
    expires_str = (
        insight.expires_at.strftime("%d %b %Y")
        if isinstance(insight.expires_at, datetime)
        else "—"
    )

    # Geography chips
    geo_pairs = [
        ("Geo Level", insight.geo_level),
        ("Region", insight.region),
        ("Area", insight.area),
        ("Market", insight.market),
    ]
    geo_chips = "".join(
        f'<span style="display:inline-block;background:{_C["light"]};color:{_C["primary"]};'
        f'border:1px solid {_C["primary"]}33;padding:4px 10px;border-radius:12px;'
        f'margin:3px 4px 3px 0;font-size:12px;font-weight:500;">'
        f'<span style="opacity:0.7;">{label}: </span>{_esc(val)}</span>'
        for label, val in geo_pairs
        if val
    )

    # Tag chips
    tag_chips = "".join(
        f'<span style="display:inline-block;background:#EFEFEF;color:#555;'
        f'padding:3px 9px;border-radius:10px;margin:3px 4px 3px 0;font-size:11px;">'
        f"{_esc(t)}</span>"
        for t in (insight.tags or [])
    )

    # ── Section builders ──────────────────────────────────────────────────────
    def _section(title: str, body: str, border_color: str = _C["primary"]) -> str:
        return f"""
        <div style="margin:24px 0;">
          <div style="color:{border_color};font-size:14px;font-weight:700;letter-spacing:0.3px;
               border-bottom:2px solid {border_color};padding-bottom:8px;margin-bottom:14px;
               text-transform:uppercase;">
            {title}
          </div>
          {body}
        </div>"""

    custom_section = (
        _section(
            "Note from Sender",
            f'<div style="background:{_C["light"]};border-left:4px solid {_C["primary"]};'
            f'padding:14px 18px;border-radius:4px;line-height:1.7;">'
            f"{_md_to_html(custom_message)}</div>",
        )
        if custom_message
        else ""
    )

    analysis_section = _section(
        "AI Analysis",
        f'<div style="background:{_C["page_bg"]};border-left:4px solid {_C["primary"]};'
        f'padding:16px 20px;border-radius:4px;line-height:1.75;font-size:14px;color:#333;">'
        f"{_md_to_html(insight.insight or '')}</div>",
    )

    if insight.insight_detail:
        if isinstance(insight.insight_detail, list):
            detail_bullets = "".join(
                f'<li style="margin-bottom:6px">{_esc(b)}</li>'
                for b in insight.insight_detail
            )
            detail_body = (
                f'<div style="background:#fff;border:1px solid {_C["border"]};'
                f'padding:16px 20px;border-radius:4px;font-size:13px;color:#444;">'
                f'<ul style="margin:0;padding-left:20px;line-height:1.75">{detail_bullets}</ul></div>'
            )
        else:
            detail_body = (
                f'<div style="background:#fff;border:1px solid {_C["border"]};'
                f'padding:16px 20px;border-radius:4px;line-height:1.75;font-size:13px;color:#444;">'
                f'{_md_to_html(insight.insight_detail)}</div>'
            )
        detail_section = _section("Detailed Analysis", detail_body)
    else:
        detail_section = ""

    geo_section = (
        _section("Geography", f'<div style="line-height:2;">{geo_chips}</div>')
        if geo_chips
        else ""
    )

    projects_str = ", ".join(insight.projects or []) or "—"
    functions_str = ", ".join(insight.functions or []) or "—"

    meta_cards = f"""
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0"
           style="margin:20px 0;">
      <tr>
        <td width="33%" style="padding-right:10px;vertical-align:top;">
          <div style="background:{_C['page_bg']};border:1px solid {_C['border']};
               border-radius:6px;padding:14px 16px;">
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.2px;
                 color:{_C['footer']};margin-bottom:6px;">Category</div>
            <div style="font-size:14px;font-weight:600;color:#1a1a2e;">
              {_esc(insight.category or "—")}
            </div>
            <div style="font-size:12px;color:#666;margin-top:3px;">
              {_esc(insight.subcategory or insight.type or "")}
            </div>
          </div>
        </td>
        <td width="33%" style="padding-right:10px;vertical-align:top;">
          <div style="background:{_C['page_bg']};border:1px solid {_C['border']};
               border-radius:6px;padding:14px 16px;">
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.2px;
                 color:{_C['footer']};margin-bottom:6px;">Projects</div>
            <div style="font-size:14px;font-weight:600;color:#1a1a2e;">{_esc(projects_str)}</div>
          </div>
        </td>
        <td width="34%" style="vertical-align:top;">
          <div style="background:{_C['page_bg']};border:1px solid {_C['border']};
               border-radius:6px;padding:14px 16px;">
            <div style="font-size:10px;text-transform:uppercase;letter-spacing:1.2px;
                 color:{_C['footer']};margin-bottom:6px;">Functions</div>
            <div style="font-size:14px;font-weight:600;color:#1a1a2e;">{_esc(functions_str)}</div>
          </div>
        </td>
      </tr>
    </table>"""

    attachment_note = (
        f'<p style="margin:0 0 24px;font-size:12px;color:{_C["footer"]};'
        f'padding:10px 14px;background:#fff9e6;border-radius:4px;'
        f'border-left:3px solid #F9A825;">'
        "📎  Supporting data tables are attached in the Excel file — "
        "<em>Source Data</em> (aggregated rows fed to AI) and "
        "<em>Drill-Down Sites</em> (specific entities for investigation)."
        "</p>"
    )

    tags_section = (
        f'<div style="margin:0 0 20px;">{tag_chips}</div>' if tag_chips else ""
    )

    # ── Full HTML document ────────────────────────────────────────────────────
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1.0">
  <title>PM Twin Insight Report</title>
</head>
<body style="margin:0;padding:0;background-color:{_C['page_bg']};
     font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif;color:#333;">

  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0">
    <tr><td align="center" style="padding:32px 12px;">

      <!-- ── Outer card ── -->
      <table role="presentation" width="700" cellspacing="0" cellpadding="0" border="0"
             style="max-width:700px;background:#fff;border-radius:12px;
             box-shadow:0 6px 30px rgba(0,0,0,0.10);overflow:hidden;">

        <!-- ══ HEADER ══ -->
        <tr>
          <td style="background:linear-gradient(135deg,{_C['primary']} 0%,{_C['primary_dk']} 100%);
               padding:36px 40px 28px;text-align:center;">
            <div style="font-size:10px;letter-spacing:4px;text-transform:uppercase;
                 color:rgba(255,255,255,0.65);margin-bottom:8px;font-weight:500;">
              PM TWIN &nbsp;·&nbsp; AI INSIGHTS ENGINE
            </div>
            <div style="font-size:28px;font-weight:700;color:#fff;line-height:1.2;
                 letter-spacing:-0.5px;">
              Insight Report
            </div>
            <div style="margin-top:10px;font-size:13px;color:rgba(255,255,255,0.80);">
              Generated {created_str}
            </div>
          </td>
        </tr>

        <!-- ══ SEVERITY BANNER ══ -->
        <tr>
          <td style="background:{sev_color};padding:11px 40px;text-align:center;">
            <span style="color:#fff;font-size:13px;font-weight:700;letter-spacing:1.5px;
                 text-transform:uppercase;">
              SEVERITY &nbsp;{sev_display}
            </span>
          </td>
        </tr>

        <!-- ══ META STRIP ══ -->
        <tr>
          <td style="background:{_C['page_bg']};padding:14px 40px;
               border-bottom:1px solid {_C['border']};">
            <table role="presentation" cellspacing="0" cellpadding="0" border="0">
              <tr>
                <td style="padding-right:10px;padding-bottom:4px;">
                  <span style="border:1px solid {_C['primary']};color:{_C['primary']};
                       padding:5px 11px;border-radius:4px;font-size:11px;font-weight:600;
                       white-space:nowrap;">
                    {_esc(insight.category or "Uncategorized")}
                  </span>
                </td>
                <td style="padding-right:10px;padding-bottom:4px;">
                  <span style="border:1px solid #CCC;color:#555;
                       padding:5px 11px;border-radius:4px;font-size:11px;white-space:nowrap;">
                    ID: {str(insight.insight_id)[:8]}…
                  </span>
                </td>
                <td style="padding-right:10px;padding-bottom:4px;">
                  <span style="border:1px solid #CCC;color:#555;
                       padding:5px 11px;border-radius:4px;font-size:11px;white-space:nowrap;">
                    Expires: {expires_str}
                  </span>
                </td>
                {(
                    '<td style="padding-bottom:4px;">'
                    f'<span style="border:1px solid #CCC;color:#555;'
                    'padding:5px 11px;border-radius:4px;font-size:11px;white-space:nowrap;">'
                    f'Sites: {insight.site_count}</span></td>'
                ) if insight.site_count else ""}
              </tr>
            </table>
          </td>
        </tr>

        <!-- ══ BODY ══ -->
        <tr>
          <td style="padding:30px 40px 36px;">

            {custom_section}

            <!-- Insight title -->
            <h2 style="margin:0 0 20px;font-size:22px;font-weight:700;
                 color:#0D1B40;line-height:1.3;letter-spacing:-0.3px;">
              {_esc(insight.title or "Untitled Insight")}
            </h2>

            {analysis_section}
            {detail_section}
            {geo_section}
            {meta_cards}
            {tags_section}
            {attachment_note}

          </td>
        </tr>

        <!-- ══ FOOTER ══ -->
        <tr>
          <td style="background:{_C['page_bg']};border-top:1px solid {_C['border']};
               padding:22px 40px;text-align:center;">
            <p style="margin:0;font-size:12px;color:{_C['footer']};">
              Powered by&nbsp;
              <strong style="color:{_C['primary']};">PM Twin: AI Assistant</strong>
              &nbsp;|&nbsp; Nokia
            </p>
            <p style="margin:6px 0 0;font-size:11px;color:{_C['footer']};">
              This report was automatically generated. Please do not reply to this message.
            </p>
          </td>
        </tr>

      </table>
    </td></tr>
  </table>

</body>
</html>"""


# ── Excel Builder ─────────────────────────────────────────────────────────────
def _write_data_sheet(
    wb: "openpyxl.Workbook",
    title: str,
    rows: List[Dict[str, Any]],
    empty_message: str = "No data available.",
) -> None:
    """Populate a worksheet with Nokia-styled tabular data."""
    nokia_fill = PatternFill("solid", fgColor="005AFF")
    nokia_font = Font(bold=True, color="FFFFFF", size=11)
    alt_fill = PatternFill("solid", fgColor="F5F8FF")
    center = Alignment(horizontal="center", vertical="center")
    wrap = Alignment(horizontal="left", vertical="center", wrap_text=False)

    ws = wb.create_sheet(title=title)

    if not rows:
        ws.cell(row=1, column=1, value=empty_message)
        return

    columns = list(rows[0].keys())

    # Header row
    for col_idx, col_name in enumerate(columns, start=1):
        cell = ws.cell(row=1, column=col_idx, value=col_name)
        cell.fill = nokia_fill
        cell.font = nokia_font
        cell.alignment = center

    # Data rows
    for row_idx, record in enumerate(rows, start=2):
        for col_idx, col_name in enumerate(columns, start=1):
            cell = ws.cell(row=row_idx, column=col_idx, value=record.get(col_name))
            cell.alignment = wrap
            if row_idx % 2 == 0:
                cell.fill = alt_fill

    # Auto-fit column widths (sample first 200 rows for performance)
    for col_idx, col_name in enumerate(columns, start=1):
        max_len = len(str(col_name))
        for record in rows[:200]:
            cell_val = str(record.get(col_name, "") or "")
            if len(cell_val) > max_len:
                max_len = len(cell_val)
        ws.column_dimensions[get_column_letter(col_idx)].width = min(max_len + 3, 42)

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(len(columns))}1"


def _build_excel(
    source_rows: List[Dict[str, Any]],
    drill_down_rows: List[Dict[str, Any]],
    insight: Insight,
) -> bytes:
    """
    Build an Excel workbook with three sheets:
      • "Insight Details"  — key metadata
      • "Source Data"       — aggregated rows that were fed to the AI
      • "Drill-Down Sites" — entity-level rows from the drill-down SQL
    """
    wb = openpyxl.Workbook()

    # ── Sheet 1: Insight Details ──────────────────────────────────────────────
    ws_info = wb.active
    ws_info.title = "Insight Details"

    nokia_fill = PatternFill("solid", fgColor="005AFF")
    label_font = Font(bold=True, color="005AFF", size=11)
    value_font = Font(size=11)
    header_align = Alignment(horizontal="left", vertical="center", wrap_text=False)
    value_align = Alignment(horizontal="left", vertical="center", wrap_text=True)

    # Title row
    ws_info.merge_cells("A1:B1")
    title_cell = ws_info.cell(row=1, column=1, value="PM Twin — Insight Report")
    title_cell.fill = nokia_fill
    title_cell.font = Font(bold=True, color="FFFFFF", size=14)
    title_cell.alignment = Alignment(horizontal="center", vertical="center")
    ws_info.row_dimensions[1].height = 30

    details = [
        ("Insight ID", str(insight.insight_id)),
        ("Title", insight.title or ""),
        ("Category", insight.category or ""),
        ("Subcategory", insight.subcategory or ""),
        ("Type", insight.type or ""),
        ("Severity Score", insight.severity_score),
        ("Severity Level", _severity_label(insight.severity_score)),
        ("Geo Level", insight.geo_level or ""),
        ("Region", insight.region or ""),
        ("Area", insight.area or ""),
        ("Market", insight.market or ""),
        ("Team", insight.team or ""),
        ("Projects", ", ".join(insight.projects or [])),
        ("Functions", ", ".join(insight.functions or [])),
        ("Tags", ", ".join(insight.tags or [])),
        ("Site Count", insight.site_count),
        ("Created At", str(insight.created_at or "")),
        ("Expires At", str(insight.expires_at or "")),
        ("Is Active", insight.is_active),
        ("Analysis", insight.insight or ""),
        ("Detailed Analysis", "\n".join(f"• {b}" for b in insight.insight_detail) if isinstance(insight.insight_detail, list) else (insight.insight_detail or "")),
    ]

    for row_idx, (label, value) in enumerate(details, start=2):
        lc = ws_info.cell(row=row_idx, column=1, value=label)
        lc.font = label_font
        lc.alignment = header_align

        vc = ws_info.cell(row=row_idx, column=2, value=value)
        vc.font = value_font
        vc.alignment = value_align

    ws_info.column_dimensions["A"].width = 20
    ws_info.column_dimensions["B"].width = 65

    # ── Sheet 2: Source Data ──────────────────────────────────────────────────
    _write_data_sheet(wb, "Source Data", source_rows,
                      empty_message="No source data available for this insight.")

    # ── Sheet 3: Drill-Down Sites ─────────────────────────────────────────────
    _write_data_sheet(wb, "Drill-Down Sites", drill_down_rows,
                      empty_message="No drill-down data available for this insight.")

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


# ── Email Dispatch ────────────────────────────────────────────────────────────
def _send_email(
    to_list: List[str],
    cc_list: List[str],
    bcc_list: List[str],
    subject: str,
    html_body: str,
    attachments: List[Dict[str, str]],   # [{"filename": "...", "filedata": "<b64>"}]
) -> None:
    """
    Dispatch an email via the configured backend.

    Reads EMAIL_BACKEND from settings:
      • "nokia_gateway" — Nokia internal JSONRPC mail relay
      • "smtp"          — Standard SMTP (Gmail, Exchange, etc.)
    """
    cfg = get_settings()

    if cfg.email_backend == "smtp":
        _send_via_smtp(to_list, cc_list, bcc_list, subject, html_body, attachments, cfg)
    else:
        _send_via_nokia_gateway(to_list, cc_list, bcc_list, subject, html_body, attachments, cfg)


def _send_via_nokia_gateway(
    to_list: List[str],
    cc_list: List[str],
    bcc_list: List[str],
    subject: str,
    html_body: str,
    attachments: List[Dict[str, str]],
    cfg: Any,
) -> None:
    """Send via the Nokia internal JSONRPC mail relay."""
    # 1 — Authenticate
    auth_payload = {
        "jsonrpc": "2.0",
        "method": "call",
        "params": {
            "db": cfg.email_gateway_db,
            "login": cfg.email_gateway_login,
            "password": cfg.email_gateway_password,
        },
    }
    session = requests.Session()
    resp = session.post(cfg.email_gateway_auth_url, json=auth_payload, timeout=15)
    resp.raise_for_status()
    sid = session.cookies.get("session_id")
    if not sid:
        raise RuntimeError("Nokia gateway did not return a session_id cookie")

    # 2 — Send
    payload = {
        "params": {
            "tolist": to_list,
            "cclist": cc_list,
            "bcclist": bcc_list,
            "subject": subject,
            "body": html_body,
            "file": attachments,
        }
    }
    resp = requests.post(
        cfg.email_gateway_send_url,
        json=payload,
        headers={"Content-Type": "application/json", "Cookie": f"session_id={sid}"},
        timeout=cfg.email_gateway_timeout,
    )
    resp.raise_for_status()


def _send_via_smtp(
    to_list: List[str],
    cc_list: List[str],
    bcc_list: List[str],
    subject: str,
    html_body: str,
    attachments: List[Dict[str, str]],
    cfg: Any,
) -> None:
    """Send via standard SMTP (TLS or plain)."""
    sender = cfg.smtp_from or cfg.smtp_user
    if not sender:
        raise RuntimeError("SMTP_FROM / SMTP_USER is not configured")

    all_recipients = to_list + cc_list + bcc_list

    msg = MIMEMultipart("mixed")
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = ", ".join(to_list)
    if cc_list:
        msg["Cc"] = ", ".join(cc_list)

    # HTML body
    msg.attach(MIMEText(html_body, "html", "utf-8"))

    # Attachments
    for att in attachments:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(base64.b64decode(att["filedata"]))
        encoders.encode_base64(part)
        part.add_header(
            "Content-Disposition",
            "attachment",
            filename=att["filename"],
        )
        msg.attach(part)

    context = ssl.create_default_context()
    if cfg.smtp_use_tls:
        with smtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=cfg.smtp_timeout) as server:
            server.ehlo()
            server.starttls(context=context)
            server.ehlo()
            if cfg.smtp_user and cfg.smtp_password:
                server.login(cfg.smtp_user, cfg.smtp_password)
            server.sendmail(sender, all_recipients, msg.as_bytes())
    else:
        with smtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=cfg.smtp_timeout) as server:
            if cfg.smtp_user and cfg.smtp_password:
                server.login(cfg.smtp_user, cfg.smtp_password)
            server.sendmail(sender, all_recipients, msg.as_bytes())


# ── Endpoint ──────────────────────────────────────────────────────────────────
@router.post(
    "/send-insight",
    status_code=202,
    summary="Email an insight report (fire-and-forget)",
    description=(
        "Validates the insight, builds the HTML email and Excel attachment, "
        "then dispatches the send in a background task and returns 202 immediately. "
        "The caller is not blocked by gateway or SMTP latency."
    ),
)
async def send_insight_email(
    request: SendInsightEmailRequest,
    background_tasks: BackgroundTasks,
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> Dict[str, Any]:
    """
    Queue an insight report email and return immediately (fire-and-forget).

    **Flow (synchronous, before returning):**
    1. Validate `insight_id` and fetch the insight from the DB.
    2. Render the Nokia-blue HTML email body.
    3. Build the Excel attachment.

    **Flow (background, after returning 202):**
    4. Dispatch the email via the configured backend (Nokia gateway or SMTP).
       Errors are logged but do not affect the caller.

    **Requires:** `openpyxl` (`pip install openpyxl`).
    """
    if not _XLSX_AVAILABLE:
        raise HTTPException(
            status_code=500,
            detail=(
                "openpyxl is not installed on this server. "
                "Add it to requirements.txt and restart the service."
            ),
        )

    validate_uuid(request.insight_id, "insight_id")

    # 1 — Fetch insight (must happen before returning — needs DB session)
    stmt = select(Insight).where(Insight.insight_id == request.insight_id)
    result = await db.execute(stmt)
    insight = result.scalar_one_or_none()

    if not insight:
        raise NotFoundError("Insight", request.insight_id)

    # 2 — Build HTML (CPU-bound but fast, do it now so we can report row count)
    html_body = _build_insight_email(insight, custom_message=request.custom_message)

    # 3 — Build Excel attachment (source data + drill-down sites)
    attachments: List[Dict[str, str]] = []
    source_rows: List[Dict[str, Any]] = insight.source_data or []
    drill_down_rows: List[Dict[str, Any]] = insight.drill_down_data or []
    try:
        xlsx_bytes = _build_excel(source_rows, drill_down_rows, insight)
        short_id = str(insight.insight_id)[:8]
        attachments.append({
            "filename": f"insight_{short_id}_data.xlsx",
            "filedata": base64.b64encode(xlsx_bytes).decode("utf-8"),
        })
    except Exception as exc:
        logger.warning("Excel attachment build failed (skipping): %s", exc)

    # 4 — Queue the actual network call as a background task
    subject = f"PM Twin Insight: {(insight.title or 'Report')[:65]}"

    def _dispatch() -> None:
        try:
            _send_email(
                to_list=request.to_list,
                cc_list=request.cc_list,
                bcc_list=request.bcc_list,
                subject=subject,
                html_body=html_body,
                attachments=attachments,
            )
            logger.info(
                "Insight email sent",
                extra={"insight_id": str(insight.insight_id), "to": request.to_list},
            )
        except Exception as exc:
            logger.error(
                "Background email send failed (%s): %s",
                get_settings().email_backend,
                exc,
                exc_info=True,
            )

    background_tasks.add_task(_dispatch)

    return {
        "status": "queued",
        "insight_id": str(insight.insight_id),
        "title": insight.title,
        "recipients": request.to_list,
        "has_excel_attachment": bool(attachments),
        "data_rows": len(source_rows),
        "backend": get_settings().email_backend,
    }
