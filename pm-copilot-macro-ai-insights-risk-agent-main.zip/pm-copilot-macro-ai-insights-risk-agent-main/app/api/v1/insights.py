"""
Insights retrieval API — GET /api/v1/insights

Filter hierarchy (all AND-combined across dimensions, OR within each multi-value param):

  Project     : ?project=NTM&project=AHLOB
  Function    : ?function=PDM&function=HSE
  KPI Category: ?category=quality&category=performance   (values: performance|capacity|quality|reliability|compliance|operational)
  Geo level   : ?geo_level=market          (overall | region | area | market)
  Geo scope   : ?geo_region=North&geo_area=London&geo_market=Camden
                (can be combined; OR within each scope type)

The same endpoint serves:
  • Home-screen session filters  — params supplied by the filter bar
  • User preference defaults     — caller pre-populates params from UserPreferences
"""
from __future__ import annotations

import logging
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, Path, Query
from sqlalchemy import and_, bindparam, case, func, literal, or_, select, text
from sqlalchemy.dialects.postgresql import ARRAY as PG_ARRAY
from sqlalchemy.types import String
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.middleware.auth import CurrentUser, get_current_user
from app.middleware.error_handler import NotFoundError
from app.models.insights import Insight
from app.schemas.insights import (
    DrillDownResponse,
    InsightListItem,
    InsightListResponse,
    InsightResponse,
)
from app.utils.validators import validate_uuid

log = logging.getLogger(__name__)

router = APIRouter(prefix="/insights", tags=["Insights"])


def _ilike_array_overlap(column, values: list[str]):
    """
    Case-insensitive array overlap for PostgreSQL ARRAY(String) columns.

    For each filter value v, generates:
      LOWER('v') = ANY(SELECT LOWER(e) FROM unnest(column) AS e)
    Multiple values are OR'd together.
    """
    lowered_elements = select(func.lower(func.unnest(column))).scalar_subquery()
    clauses = [literal(v.lower()).op("= ANY")(lowered_elements) for v in values]
    return or_(*clauses) if len(clauses) > 1 else clauses[0]


def _ilike_array_has_any(column, values: list[str]):
    """
    Case-insensitive array overlap — returns True when the column's array
    shares at least one element with the provided filter values.

    Uses PostgreSQL's ``&&`` (overlap) operator on lowered arrays:
      lowered(projects) && ARRAY['ntm','ahlob']

    An insight with projects=["NTM","AHLOB"] IS returned when the filter
    is project=NTM — the insight matches if ANY of its elements is in the
    filter set.
    """
    col_name = column.key
    param_name = f"_arr_{col_name}"
    return text(
        f"(SELECT array_agg(LOWER(e))::varchar[] FROM unnest({col_name}) AS e) && :{param_name}"
    ).bindparams(
        bindparam(param_name, value=[v.lower() for v in values], type_=PG_ARRAY(String))
    )


# ------------------------------------------------------------------ #
# GET /insights — list with filters and pagination
# ------------------------------------------------------------------ #
@router.get("", response_model=InsightListResponse)
async def list_insights(
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    # ── PM hierarchy filters ────────────────────────────────────────
    project: list[str] | None = Query(
        None, alias="project",
        description="Filter by project(s) — OR logic. e.g. ?project=NTM&project=AHLOB",
    ),
    function: list[str] | None = Query(
        None, alias="function",
        description="Filter by function(s) — OR logic. e.g. ?function=PDM&function=HSE",
    ),
    category: list[str] | None = Query(
        None, alias="category",
        description=(
            "KPI category filter — OR logic. "
            "Allowed values: performance | capacity | quality | reliability | compliance | operational. "
            "e.g. ?category=quality&category=performance"
        ),
    ),
    subcategory: str | None = Query(None),
    # ── Geography filters ───────────────────────────────────────────
    geo_level: Literal["overall", "region", "area", "market"] | None = Query(
        None, description="Aggregation granularity to return insights for",
    ),
    geo_region: list[str] | None = Query(
        None, description="Region scope — OR logic",
    ),
    geo_area: list[str] | None = Query(
        None, description="Area scope — OR logic",
    ),
    geo_market: list[str] | None = Query(
        None, description="Market scope — OR logic",
    ),
    # ── Pack filters ────────────────────────────────────────────────
    pack_id: str | None = Query(
        None, description="Return insights for a specific pack (all geo cuts)",
    ),
    pack_summary_only: bool = Query(
        False,
        description=(
            "When True, return only the hero insight per pack "
            "(is_pack_summary=True). Use this for the home-screen feed."
        ),
    ),
    # ── Legacy / convenience filters ────────────────────────────────
    team: str | None = Query(None, description="Filter by team"),
    type: str | None = Query(None, description="Filter by insight type"),
    insight_area: str | None = Query(
        None, description="Filter by analysis area (e.g. 'Approval & Rejection Rates')",
    ),
    severity_min: float | None = Query(None, ge=0, le=100),
    severity_max: float | None = Query(None, ge=0, le=100),
    tags: list[str] | None = Query(None, description="Filter by tags"),
    job_id: str | None = Query(None, description="Filter by generation job ID"),
    is_active: bool | None = Query(True),
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
) -> InsightListResponse:
    """
    Retrieve a paginated list of insights with optional filters.

    Filters are AND-combined across dimensions.
    Within multi-value params (project, function, category, geo_*) OR logic applies —
    an insight matches if it overlaps with any of the supplied values.
    Note: `category` filters the KPI category (quality/performance/etc.), not PM category (Cost/Schedule).
    """
    if severity_min is not None and severity_max is not None and severity_min > severity_max:
        raise HTTPException(status_code=422, detail="severity_min must not exceed severity_max")

    conditions = []

    if is_active is not None:
        conditions.append(Insight.is_active == is_active)

    # PM hierarchy — case-insensitive matching throughout
    # Project/function filters use overlap (&&) so that an insight matches
    # when ANY of its projects/functions appear in the filter set.
    if project:
        conditions.append(_ilike_array_has_any(Insight.projects, project))
    if function:
        conditions.append(_ilike_array_has_any(Insight.functions, function))
    if category:
        conditions.append(func.lower(Insight.category).in_([c.lower() for c in category]))
    if subcategory:
        conditions.append(func.lower(Insight.subcategory) == subcategory.lower())

    # Pack filters
    if pack_id:
        conditions.append(Insight.pack_id == pack_id)
    if pack_summary_only:
        conditions.append(Insight.is_pack_summary.is_(True))

    # Geography — level filter
    if geo_level:
        conditions.append(func.lower(Insight.geo_level) == geo_level.lower())

    # Geography — scope filters (OR within each scope type, each type is also OR'd together
    # so a user assigned to region=North AND market=Camden still gets both)
    geo_scope_clauses = []
    if geo_region:
        geo_scope_clauses.append(func.lower(Insight.region).in_([r.lower() for r in geo_region]))
    if geo_area:
        geo_scope_clauses.append(func.lower(Insight.area).in_([a.lower() for a in geo_area]))
    if geo_market:
        geo_scope_clauses.append(func.lower(Insight.market).in_([m.lower() for m in geo_market]))
    if geo_scope_clauses:
        conditions.append(or_(*geo_scope_clauses))

    # Misc
    if team:
        conditions.append(func.lower(Insight.team) == team.lower())
    if type:
        conditions.append(func.lower(Insight.type) == type.lower())
    if insight_area:
        conditions.append(func.lower(Insight.insight_area) == insight_area.lower())
    if severity_min is not None:
        conditions.append(Insight.severity_score >= severity_min)
    if severity_max is not None:
        conditions.append(Insight.severity_score <= severity_max)
    if tags:
        conditions.append(_ilike_array_overlap(Insight.tags, tags))
    if job_id:
        conditions.append(Insight.job_id == job_id)

    where = and_(*conditions) if conditions else True

    # Single-round-trip query: fetch data + total in one DB call using a
    # window function.  Selecting explicit columns also avoids loading
    # source_data (the large JSONB drill-down snapshot) which is only needed
    # on the single-insight detail view — not the list.
    # Sort by geo hierarchy (overall first, then region, area, market),
    # then by severity within each level.
    _geo_order = case(
        {"overall": 0, "region": 1, "area": 2, "market": 3},
        value=func.lower(Insight.geo_level),
        else_=4,
    )
    _sort = (_geo_order.asc(), Insight.severity_score.desc().nullslast(), Insight.created_at.desc())
    stmt = (
        select(
            Insight.insight_id,
            Insight.title,
            Insight.insight,
            Insight.insight_detail,
            Insight.market,
            Insight.area,
            Insight.region,
            Insight.team,
            Insight.severity_score,
            Insight.category,
            Insight.subcategory,
            Insight.type,
            Insight.site_count,
            Insight.projects,
            Insight.functions,
            Insight.tags,
            Insight.consecutive_occurrences,
            Insight.llm_model,
            Insight.query_id,
            Insight.job_id,
            Insight.pack_id,
            Insight.is_pack_summary,
            Insight.geo_level,
            Insight.created_at,
            Insight.updated_at,
            Insight.expires_at,
            Insight.is_active,
            func.count().over().label("_total"),
        )
        .where(where)
        .order_by(*_sort)
        .limit(limit)
        .offset(offset)
    )
    rows = (await db.execute(stmt)).mappings().all()

    total = int(rows[0]["_total"]) if rows else 0
    items = [InsightListItem.model_validate(dict(r)) for r in rows]

    return InsightListResponse(
        items=items,
        total=total,
        limit=limit,
        offset=offset,
        has_more=(offset + limit) < total,
    )


# ------------------------------------------------------------------ #
# GET /insights/{insight_id} — single insight
# ------------------------------------------------------------------ #
@router.get("/{insight_id}", response_model=InsightResponse)
async def get_insight(
    insight_id: Annotated[str, Path(description="Insight UUID")],
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
) -> InsightResponse:
    """Retrieve a single insight by ID."""
    validate_uuid(insight_id, "insight_id")

    stmt = select(Insight).where(Insight.insight_id == insight_id)
    result = await db.execute(stmt)
    insight = result.scalar_one_or_none()

    if not insight:
        raise NotFoundError("Insight", insight_id)

    return InsightResponse.model_validate(insight)


# ------------------------------------------------------------------ #
# GET /insights/{insight_id}/generation-context
# ------------------------------------------------------------------ #
@router.get("/{insight_id}/generation-context")
async def get_generation_context(
    insight_id: Annotated[str, Path(description="Insight UUID")],
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
):
    """Return the generation debug context for an insight.

    Includes the system/user prompts sent to the LLM, the data rows it
    consumed, SQL params, and the raw LLM JSON response.
    """
    validate_uuid(insight_id, "insight_id")

    stmt = select(
        Insight.generation_context,
        Insight.query_id,
        Insight.prompt_template_id,
        Insight.llm_model,
        Insight.geo_level,
    ).where(Insight.insight_id == insight_id)
    result = await db.execute(stmt)
    row = result.one_or_none()

    if not row:
        raise NotFoundError("Insight", insight_id)

    ctx = row.generation_context or {}
    return {
        "insight_id": insight_id,
        "query_id": row.query_id,
        "prompt_template_id": row.prompt_template_id,
        "llm_model": row.llm_model,
        "geo_level": row.geo_level,
        "has_context": bool(ctx),
        **ctx,
    }


# ------------------------------------------------------------------ #
# GET /insights/{insight_id}/drill-down — execute drill-down SQL
# ------------------------------------------------------------------ #
@router.get("/{insight_id}/drill-down", response_model=DrillDownResponse)
async def drill_down(
    insight_id: Annotated[str, Path(description="Insight UUID")],
    db: Annotated[AsyncSession, Depends(get_db)],
    current_user: Annotated[CurrentUser, Depends(get_current_user)],
    refresh: bool = False,
) -> DrillDownResponse:
    """
    Return the data rows for an insight.

    Returns the stored drill-down data (point-in-time snapshot captured when
    the insight was generated).  Falls back to source_data if drill-down data
    is not available.  For overall/summary insights, returns child insight rows.
    """
    validate_uuid(insight_id, "insight_id")

    stmt = select(Insight).where(Insight.insight_id == insight_id)
    result = await db.execute(stmt)
    insight = result.scalar_one_or_none()

    if not insight:
        raise NotFoundError("Insight", insight_id)

    # ── Overall synthesis insights: drill-down = child insights ── #
    # Overall synthesis insights (tagged "overall-summary") have no
    # drill_down_sql; their source_data contains child insight rows.
    # On refresh, re-fetch from the DB instead.
    _is_overall_synthesis = (
        insight.geo_level == "overall"
        and "overall-summary" in (insight.tags or [])
    )
    if _is_overall_synthesis:
        if not refresh and insight.source_data:
            rows = insight.source_data
            return DrillDownResponse(
                insight_id=insight_id,
                columns=list(rows[0].keys()) if rows else [],
                rows=rows,
                row_count=len(rows),
                query_executed=False,
                message="Child insights from cached snapshot. Use ?refresh=true to re-fetch.",
            )

        # Refresh: re-query child insights from the same job.
        # Exclude sibling overall insights — only return region/area/market.
        if insight.job_id:
            _child_geo_order = case(
                {"region": 0, "area": 1, "market": 2},
                value=func.lower(Insight.geo_level),
                else_=3,
            )
            child_stmt = (
                select(
                    Insight.title,
                    Insight.insight,
                    Insight.severity_score,
                    Insight.geo_level,
                    Insight.region,
                    Insight.area,
                    Insight.market,
                    Insight.site_count,
                    Insight.insight_id,
                )
                .where(
                    Insight.job_id == insight.job_id,
                    Insight.is_active.is_(True),
                    Insight.insight_id != insight_id,  # exclude the overall itself
                    Insight.geo_level != "overall",    # exclude sibling overall summaries
                )
                .order_by(_child_geo_order, Insight.severity_score.desc().nullslast())
            )
            child_rows = (await db.execute(child_stmt)).mappings().all()
            rows = [dict(r) for r in child_rows]
            return DrillDownResponse(
                insight_id=insight_id,
                columns=list(rows[0].keys()) if rows else [],
                rows=rows,
                row_count=len(rows),
                query_executed=True,
                message=f"Refreshed: {len(rows)} child insights from job {insight.job_id}.",
            )

        return DrillDownResponse(
            insight_id=insight_id,
            columns=[],
            rows=insight.source_data or [],
            row_count=len(insight.source_data or []),
            query_executed=False,
            message="Overall insight — no job_id for live refresh.",
        )

    # ── Primary: return stored drill-down data (point-in-time snapshot) ── #
    if insight.drill_down_data:
        rows = insight.drill_down_data
        return DrillDownResponse(
            insight_id=insight_id,
            columns=list(rows[0].keys()) if rows else [],
            rows=rows,
            row_count=len(rows),
            query_executed=False,
            message="Stored drill-down data (point-in-time snapshot from when insight was generated).",
        )

    # ── Fallback: return source_data if no drill-down data ── #
    if insight.source_data:
        rows = insight.source_data
        return DrillDownResponse(
            insight_id=insight_id,
            columns=list(rows[0].keys()) if rows else [],
            rows=rows,
            row_count=len(rows),
            query_executed=False,
            message="Served from source_data snapshot (no drill-down data available).",
        )

    return DrillDownResponse(
        insight_id=insight_id,
        columns=[],
        rows=[],
        row_count=0,
        query_executed=False,
        message="No drill-down data or source data available for this insight.",
    )
