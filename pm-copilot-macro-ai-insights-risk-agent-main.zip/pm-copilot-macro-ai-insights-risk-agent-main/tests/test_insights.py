"""
Tests for GET /api/v1/insights endpoints.
"""
from __future__ import annotations

import uuid

import pytest
from httpx import AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession

from tests.conftest import make_insight_data


@pytest.mark.asyncio
class TestListInsights:

    async def test_list_returns_empty_initially(self, client: AsyncClient, db_session: AsyncSession):
        resp = await client.get("/api/v1/insights")
        assert resp.status_code == 200
        data = resp.json()
        assert "items" in data
        assert "total" in data
        assert data["offset"] == 0
        assert data["limit"] == 50

    async def test_list_returns_insight(self, client: AsyncClient, sample_insight):
        resp = await client.get("/api/v1/insights")
        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] >= 1
        ids = [i["insight_id"] for i in data["items"]]
        assert sample_insight.insight_id in ids

    async def test_filter_by_market(self, client: AsyncClient, sample_insight):
        resp = await client.get("/api/v1/insights", params={"market": "New York"})
        assert resp.status_code == 200
        for item in resp.json()["items"]:
            assert item["market"] == "New York"

    async def test_filter_by_market_no_match(self, client: AsyncClient, sample_insight):
        resp = await client.get("/api/v1/insights", params={"market": "NonExistentMarket"})
        assert resp.status_code == 200
        assert resp.json()["total"] == 0

    async def test_filter_by_severity_range(self, client: AsyncClient, sample_insight):
        resp = await client.get("/api/v1/insights", params={"severity_min": 50, "severity_max": 90})
        assert resp.status_code == 200
        for item in resp.json()["items"]:
            assert 50 <= item["severity_score"] <= 90

    async def test_pagination(self, client: AsyncClient, db_session: AsyncSession):
        from app.models.insights import Insight
        # Create 5 insights
        for i in range(5):
            db_session.add(Insight(**make_insight_data(title=f"Insight {i}")))
        await db_session.flush()

        resp = await client.get("/api/v1/insights", params={"limit": 2, "offset": 0})
        data = resp.json()
        assert len(data["items"]) == 2
        assert data["has_more"] is True

    async def test_invalid_severity_range(self, client: AsyncClient):
        resp = await client.get("/api/v1/insights", params={"severity_min": 80, "severity_max": 20})
        assert resp.status_code == 422


@pytest.mark.asyncio
class TestGetInsight:

    async def test_get_existing_insight(self, client: AsyncClient, sample_insight):
        resp = await client.get(f"/api/v1/insights/{sample_insight.insight_id}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["insight_id"] == sample_insight.insight_id
        assert data["title"] == sample_insight.title

    async def test_get_nonexistent_insight(self, client: AsyncClient):
        fake_id = str(uuid.uuid4())
        resp = await client.get(f"/api/v1/insights/{fake_id}")
        assert resp.status_code == 404

    async def test_get_invalid_uuid(self, client: AsyncClient):
        resp = await client.get("/api/v1/insights/not-a-valid-uuid")
        assert resp.status_code == 422
