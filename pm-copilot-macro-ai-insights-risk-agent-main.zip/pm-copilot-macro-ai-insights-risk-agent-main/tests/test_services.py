"""
Unit tests for service layer — mocked external dependencies.
"""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from app.services.llm_service import LLMService, LLMParseError
from app.utils.filters import GeographyConfig, GeoParams
from app.utils.prompt_library import PromptBuilder


# ------------------------------------------------------------------ #
# LLM Service
# ------------------------------------------------------------------ #
class TestLLMServiceParsing:

    def setup_method(self):
        self.svc = LLMService.__new__(LLMService)  # skip __init__

    def test_parse_clean_json(self):
        raw = '{"title": "Test", "insight": "Something happened.", "severity_score": 70}'
        result = self.svc._parse_json_response(raw)
        assert result["title"] == "Test"
        assert result["severity_score"] == 70.0

    def test_parse_json_in_markdown_block(self):
        raw = '```json\n{"title": "X", "insight": "Y"}\n```'
        result = self.svc._parse_json_response(raw)
        assert result["title"] == "X"

    def test_parse_json_embedded_in_text(self):
        raw = 'Here is my result: {"title": "A", "insight": "B"} done.'
        result = self.svc._parse_json_response(raw)
        assert result["title"] == "A"

    def test_parse_raises_on_garbage(self):
        with pytest.raises(LLMParseError):
            self.svc._parse_json_response("This is not JSON at all.")

    def test_severity_clamping(self):
        raw = '{"title": "T", "insight": "I", "severity_score": 150}'
        result = self.svc._parse_json_response(raw)
        assert result["severity_score"] == 100.0

    def test_missing_title_raises(self):
        with pytest.raises(LLMParseError):
            self.svc._parse_json_response('{"insight": "No title here"}')


# ------------------------------------------------------------------ #
# PromptBuilder
# ------------------------------------------------------------------ #
class TestPromptBuilder:

    def setup_method(self):
        self.builder = PromptBuilder()

    def test_returns_system_and_user(self):
        system, user = self.builder.build(
            template_name="performance_insight",
            purpose="Test purpose",
            description="Test description",
            geography="New York",
            start_date="2025-01-01",
            end_date="2025-01-31",
            query_results="col1 | col2\n-----|-----\nval1 | val2",
        )
        assert "JSON Response Schema" in system
        assert "Test purpose" in user
        assert "New York" in user

    def test_fallback_template(self):
        # Unknown template should fall back to default
        system, user = self.builder.build(template_name="nonexistent_template")
        assert isinstance(system, str)
        assert isinstance(user, str)

    def test_format_query_results_table(self):
        rows = [{"site_id": "S1", "kpi": "95.0"}, {"site_id": "S2", "kpi": "72.3"}]
        table = self.builder.format_query_results(rows)
        assert "site_id" in table
        assert "S1" in table
        assert "kpi" in table

    def test_format_empty_results(self):
        result = self.builder.format_query_results([])
        assert "no rows" in result.lower()


# ------------------------------------------------------------------ #
# Geography Config
# ------------------------------------------------------------------ #
class TestGeographyConfig:

    def _build_config(self) -> GeographyConfig:
        cfg = GeographyConfig.__new__(GeographyConfig)
        cfg._data = {
            "regions": [
                {
                    "name": "North",
                    "areas": [
                        {"name": "North-East", "markets": ["New York", "Boston"]},
                        {"name": "North-West", "markets": ["Chicago"]},
                    ],
                }
            ]
        }
        return cfg

    def test_expand_overall(self):
        cfg = self._build_config()
        result = cfg.expand(level="overall")
        assert len(result) == 1
        assert result[0].level == "overall"

    def test_expand_region(self):
        cfg = self._build_config()
        result = cfg.expand(level="region")
        assert len(result) == 1
        assert result[0].region == "North"

    def test_expand_area(self):
        cfg = self._build_config()
        result = cfg.expand(level="area")
        assert len(result) == 2
        area_names = {r.area for r in result}
        assert "North-East" in area_names

    def test_expand_market(self):
        cfg = self._build_config()
        result = cfg.expand(level="market")
        assert len(result) == 3
        markets = {r.market for r in result}
        assert "New York" in markets
        assert "Chicago" in markets

    def test_expand_single_market(self):
        cfg = self._build_config()
        result = cfg.expand(level="market", market="Boston")
        assert len(result) == 1
        assert result[0].market == "Boston"

    def test_geo_params_label(self):
        gp = GeoParams(level="market", region="North", area="North-East", market="New York")
        label = gp.label()
        assert "New York" in label
        assert "North-East" in label

    def test_geo_params_overall_label(self):
        gp = GeoParams(level="overall")
        assert gp.label() == "Overall"
