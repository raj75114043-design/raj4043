"""
Tests for POST /api/v1/interactions/* endpoints.

Validates toggle idempotency, mutual exclusivity, and state persistence.
"""
from __future__ import annotations

import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
class TestLikeToggle:

    async def test_like_toggles_on(self, client: AsyncClient, sample_insight):
        resp = await client.post(
            f"/api/v1/interactions/{sample_insight.insight_id}/like",
            json={"user_id": "user-1"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["liked"] is True
        assert data["disliked"] is None or data["disliked"] is False

    async def test_like_toggles_off(self, client: AsyncClient, sample_insight):
        uid = "user-toggle-like"
        await client.post(
            f"/api/v1/interactions/{sample_insight.insight_id}/like",
            json={"user_id": uid},
        )
        resp = await client.post(
            f"/api/v1/interactions/{sample_insight.insight_id}/like",
            json={"user_id": uid},
        )
        assert resp.status_code == 200
        assert resp.json()["liked"] is False

    async def test_like_clears_dislike(self, client: AsyncClient, sample_insight):
        uid = "user-like-clears"
        # First dislike
        await client.post(
            f"/api/v1/interactions/{sample_insight.insight_id}/dislike",
            json={"user_id": uid},
        )
        # Then like — should clear dislike
        resp = await client.post(
            f"/api/v1/interactions/{sample_insight.insight_id}/like",
            json={"user_id": uid},
        )
        data = resp.json()
        assert data["liked"] is True
        assert data["disliked"] is False


@pytest.mark.asyncio
class TestFlagAndComment:

    async def test_flag_with_reason(self, client: AsyncClient, sample_insight):
        resp = await client.post(
            f"/api/v1/interactions/{sample_insight.insight_id}/flag",
            json={"user_id": "user-flag", "reason": "Incorrect data"},
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["flagged"] is True
        assert data["flag_reason"] == "Incorrect data"

    async def test_unflag_clears_reason(self, client: AsyncClient, sample_insight):
        uid = "user-unflag"
        await client.post(
            f"/api/v1/interactions/{sample_insight.insight_id}/flag",
            json={"user_id": uid, "reason": "Some reason"},
        )
        resp = await client.post(
            f"/api/v1/interactions/{sample_insight.insight_id}/flag",
            json={"user_id": uid},
        )
        data = resp.json()
        assert data["flagged"] is False
        assert data["flag_reason"] is None

    async def test_add_comment(self, client: AsyncClient, sample_insight):
        resp = await client.post(
            f"/api/v1/interactions/{sample_insight.insight_id}/comment",
            json={"user_id": "user-comment", "comment": "This needs follow-up."},
        )
        assert resp.status_code == 200
        assert resp.json()["comment"] == "This needs follow-up."

    async def test_delete_comment(self, client: AsyncClient, sample_insight):
        uid = "user-del-comment"
        await client.post(
            f"/api/v1/interactions/{sample_insight.insight_id}/comment",
            json={"user_id": uid, "comment": "Temporary comment"},
        )
        resp = await client.request(
            "DELETE",
            f"/api/v1/interactions/{sample_insight.insight_id}/comment",
            json={"user_id": uid},
        )
        assert resp.status_code == 200
        assert resp.json()["comment"] is None

    async def test_interaction_on_nonexistent_insight(self, client: AsyncClient):
        import uuid
        resp = await client.post(
            f"/api/v1/interactions/{uuid.uuid4()}/like",
            json={"user_id": "user-x"},
        )
        assert resp.status_code == 404


@pytest.mark.asyncio
class TestUserInteractions:

    async def test_get_user_interactions(self, client: AsyncClient, sample_insight):
        uid = "user-get-all"
        await client.post(
            f"/api/v1/interactions/{sample_insight.insight_id}/like",
            json={"user_id": uid},
        )
        resp = await client.get(f"/api/v1/interactions/user/{uid}")
        assert resp.status_code == 200
        data = resp.json()
        assert data["user_id"] == uid
        assert data["total"] >= 1
