"""
pytest fixtures shared across all tests.

API/DB tests use the real PostgreSQL database.  Each test gets a brand-new
async engine (and therefore a brand-new asyncpg connection) so there is
never any cross-event-loop state sharing — the main source of hard-to-debug
"Future attached to a different loop" errors with asyncpg.

Tables are created idempotently (CREATE IF NOT EXISTS) on each test's engine
and the session is always rolled back on teardown, leaving the DB clean.

Service unit tests have no external dependencies and always run.
"""
from __future__ import annotations

import os
import uuid
from collections.abc import AsyncGenerator
from datetime import datetime, timezone
from typing import Any

import pytest_asyncio
from httpx import ASGITransport, AsyncClient
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine

from app.config import get_settings
from app.database import Base, get_db, get_source_db
from app.main import create_app
from app.middleware.auth import get_current_user, CurrentUser

settings = get_settings()


# ------------------------------------------------------------------ #
# Engine factory — called fresh for every test so asyncpg connections
# are always on the current test's event loop.
# ------------------------------------------------------------------ #
def _build_test_engine():
    parts: list[str] = []
    schema = settings.effective_schema
    if schema:
        parts.append(schema)
    if settings.pgvector_schema not in ("public", *parts):
        parts.append(settings.pgvector_schema)
    if "public" not in parts:
        parts.append("public")
    return create_async_engine(
        os.environ.get("TEST_DATABASE_URL", settings.database_url),
        connect_args={"server_settings": {"search_path": ",".join(parts)}},
        pool_size=2,
        max_overflow=0,
        echo=False,
    )


# ------------------------------------------------------------------ #
# Per-test DB session — fresh engine, tables created idempotently,
# session always rolled back so no test data persists.
# ------------------------------------------------------------------ #
@pytest_asyncio.fixture
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    engine = _build_test_engine()
    try:
        # Ensure tables exist (fast no-op when they already do)
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)

        session = AsyncSession(engine, expire_on_commit=False)
        try:
            yield session
        finally:
            await session.rollback()
            await session.close()
    finally:
        await engine.dispose()


# ------------------------------------------------------------------ #
# FastAPI test client wired to the per-test rolled-back session
# ------------------------------------------------------------------ #
@pytest_asyncio.fixture
async def client(db_session: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    app = create_app()

    async def _override_db():
        yield db_session

    async def _override_source_db():
        yield db_session

    async def _override_auth():
        return CurrentUser(user_id="test-user", is_admin=True)

    app.dependency_overrides[get_db] = _override_db
    app.dependency_overrides[get_source_db] = _override_source_db
    app.dependency_overrides[get_current_user] = _override_auth

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac


# ------------------------------------------------------------------ #
# Sample data factories
# ------------------------------------------------------------------ #
def make_insight_data(**overrides: Any) -> dict[str, Any]:
    return {
        "insight_id": str(uuid.uuid4()),
        "title": "Test Insight Title",
        "insight": "This is a test insight. Performance is below average. Recommend investigation.",
        "market": "New York",
        "region": "North",
        "area": "North-East",
        "severity_score": 75.0,
        "category": "performance",
        "subcategory": "kpi",
        "type": "alert",
        "site_count": 12,
        "projects": ["network_quality"],
        "functions": ["engineering"],
        "tags": ["performance", "kpi"],
        "is_active": True,
        "created_at": datetime.now(timezone.utc),
        **overrides,
    }


@pytest_asyncio.fixture
async def sample_insight(db_session: AsyncSession):
    from app.models.insights import Insight

    data = make_insight_data()
    insight = Insight(**data)
    db_session.add(insight)
    await db_session.flush()
    return insight
