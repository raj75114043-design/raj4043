"""Add source_data JSONB column to insights and insights_historical.

Revision ID: 0003
Revises: 0002
Create Date: 2026-03-10

Changes:
  - ALTER TABLE insights ADD COLUMN source_data JSONB
  - ALTER TABLE insights_historical ADD COLUMN source_data JSONB

source_data stores the aggregated rows that were fed to the LLM at
generation time, enabling instant drill-down without re-querying the
source database.
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from app.config import get_settings

revision = "0003"
down_revision = "0002"
branch_labels = None
depends_on = None

_s = get_settings()
_schema = _s.effective_schema  # None → public


def upgrade() -> None:
    for tbl_attr in ("table_insights", "table_insights_historical"):
        tbl = getattr(_s, tbl_attr)
        op.add_column(
            tbl,
            sa.Column("source_data", postgresql.JSONB, nullable=True),
            schema=_schema,
        )


def downgrade() -> None:
    for tbl_attr in ("table_insights", "table_insights_historical"):
        tbl = getattr(_s, tbl_attr)
        op.drop_column(tbl, "source_data", schema=_schema)
