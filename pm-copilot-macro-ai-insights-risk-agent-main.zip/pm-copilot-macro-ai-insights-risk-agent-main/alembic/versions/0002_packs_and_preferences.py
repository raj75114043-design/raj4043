"""Add insight_packs, user_preferences, and extend sql_query_library + insights.

Revision ID: 0002
Revises: 0001
Create Date: 2026-03-09

Changes:
  - CREATE TABLE insight_packs
  - CREATE TABLE user_preferences
  - ALTER TABLE sql_query_library ADD COLUMNS pack_id, pm_category
  - ALTER TABLE insights ADD COLUMNS pack_id, is_pack_summary, geo_level
  - ALTER TABLE insights_historical ADD COLUMNS pack_id, is_pack_summary, geo_level
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from app.config import get_settings

revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

_s = get_settings()
_schema = _s.effective_schema  # None → public


def _tbl(name_attr: str) -> str:
    return getattr(_s, name_attr)


def upgrade() -> None:
    # ------------------------------------------------------------------ #
    # insight_packs
    # ------------------------------------------------------------------ #
    op.create_table(
        _tbl("table_insight_packs"),
        sa.Column("pack_id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("name", sa.String(200), nullable=False, unique=True),
        sa.Column("description", sa.Text),
        sa.Column("category", sa.String(100)),
        sa.Column("subcategory", sa.String(100)),
        sa.Column("projects", postgresql.ARRAY(sa.String)),
        sa.Column("functions", postgresql.ARRAY(sa.String)),
        sa.Column("geo_levels", postgresql.ARRAY(sa.String)),
        sa.Column("is_active", sa.Boolean, nullable=False, default=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True)),
        schema=_schema,
    )
    op.create_index(
        "idx_pack_category", _tbl("table_insight_packs"),
        ["category", "subcategory"], schema=_schema,
    )
    op.create_index(
        "idx_pack_is_active", _tbl("table_insight_packs"),
        ["is_active"], schema=_schema,
    )

    # ------------------------------------------------------------------ #
    # user_preferences
    # ------------------------------------------------------------------ #
    op.create_table(
        _tbl("table_user_preferences"),
        sa.Column("pref_id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("user_id", sa.String(100), nullable=False),
        sa.Column("projects", postgresql.ARRAY(sa.String)),
        sa.Column("functions", postgresql.ARRAY(sa.String)),
        sa.Column("categories", postgresql.ARRAY(sa.String)),
        sa.Column("geo_level", sa.String(20)),
        sa.Column("geo_regions", postgresql.ARRAY(sa.String)),
        sa.Column("geo_areas", postgresql.ARRAY(sa.String)),
        sa.Column("geo_markets", postgresql.ARRAY(sa.String)),
        sa.Column("threshold_pct", sa.Float),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True)),
        schema=_schema,
    )
    op.create_index(
        "idx_uprefs_user_id", _tbl("table_user_preferences"),
        ["user_id"], unique=True, schema=_schema,
    )

    # ------------------------------------------------------------------ #
    # sql_query_library — new columns
    # ------------------------------------------------------------------ #
    op.add_column(
        _tbl("table_sql_query_library"),
        sa.Column("pack_id", sa.String(36)),
        schema=_schema,
    )
    op.add_column(
        _tbl("table_sql_query_library"),
        sa.Column("pm_category", sa.String(100)),
        schema=_schema,
    )
    op.create_index(
        "idx_sql_pack_id", _tbl("table_sql_query_library"),
        ["pack_id"], schema=_schema,
    )
    op.create_index(
        "idx_sql_pm_category", _tbl("table_sql_query_library"),
        ["pm_category"], schema=_schema,
    )

    # ------------------------------------------------------------------ #
    # insights — pack + geo_level columns
    # ------------------------------------------------------------------ #
    for tbl_attr in ("table_insights", "table_insights_historical"):
        tbl = _tbl(tbl_attr)
        op.add_column(tbl, sa.Column("pack_id", sa.String(36)), schema=_schema)
        op.add_column(
            tbl,
            sa.Column("is_pack_summary", sa.Boolean, nullable=False, server_default="false"),
            schema=_schema,
        )
        op.add_column(tbl, sa.Column("geo_level", sa.String(20)), schema=_schema)

    op.create_index(
        "idx_insight_pack_id", _tbl("table_insights"), ["pack_id"], schema=_schema,
    )
    op.create_index(
        "idx_insight_pack_summary", _tbl("table_insights"),
        ["pack_id", "is_pack_summary"], schema=_schema,
    )
    op.create_index(
        "idx_insight_geo_level", _tbl("table_insights"), ["geo_level"], schema=_schema,
    )


def downgrade() -> None:
    # insights pack columns
    op.drop_index("idx_insight_geo_level", table_name=_tbl("table_insights"), schema=_schema)
    op.drop_index("idx_insight_pack_summary", table_name=_tbl("table_insights"), schema=_schema)
    op.drop_index("idx_insight_pack_id", table_name=_tbl("table_insights"), schema=_schema)
    for tbl_attr in ("table_insights", "table_insights_historical"):
        tbl = _tbl(tbl_attr)
        op.drop_column(tbl, "geo_level", schema=_schema)
        op.drop_column(tbl, "is_pack_summary", schema=_schema)
        op.drop_column(tbl, "pack_id", schema=_schema)

    # sql_query_library pack columns
    op.drop_index("idx_sql_pm_category", table_name=_tbl("table_sql_query_library"), schema=_schema)
    op.drop_index("idx_sql_pack_id", table_name=_tbl("table_sql_query_library"), schema=_schema)
    op.drop_column(_tbl("table_sql_query_library"), "pm_category", schema=_schema)
    op.drop_column(_tbl("table_sql_query_library"), "pack_id", schema=_schema)

    op.drop_index("idx_uprefs_user_id", table_name=_tbl("table_user_preferences"), schema=_schema)
    op.drop_table(_tbl("table_user_preferences"), schema=_schema)

    op.drop_index("idx_pack_is_active", table_name=_tbl("table_insight_packs"), schema=_schema)
    op.drop_index("idx_pack_category", table_name=_tbl("table_insight_packs"), schema=_schema)
    op.drop_table(_tbl("table_insight_packs"), schema=_schema)
