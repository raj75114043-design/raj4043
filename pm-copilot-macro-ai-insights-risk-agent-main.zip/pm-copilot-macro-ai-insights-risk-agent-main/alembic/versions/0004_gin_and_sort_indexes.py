"""Add GIN indexes on array columns and composite sort index.

GIN indexes make ARRAY overlap queries (projects, functions, tags) use an
index scan instead of a sequential scan.  The composite sort index covers the
default list ordering (severity_score DESC, created_at DESC).

Revision ID: 0004
Revises: 0003
Create Date: 2026-03-10
"""
from __future__ import annotations

from alembic import op

revision: str = "0004"
down_revision: str | None = "0003"
branch_labels: str | None = None
depends_on: str | None = None

from app.config import get_settings

_s      = get_settings()
_schema = _s.db_schema
_tbl    = _s.table_insights   # e.g. "insights" (without schema prefix)


def upgrade() -> None:
    op.create_index(
        "idx_insight_sort",
        _tbl,
        ["severity_score", "created_at"],
        schema=_schema,
    )
    op.create_index(
        "idx_insight_projects_gin",
        _tbl,
        ["projects"],
        schema=_schema,
        postgresql_using="gin",
    )
    op.create_index(
        "idx_insight_functions_gin",
        _tbl,
        ["functions"],
        schema=_schema,
        postgresql_using="gin",
    )
    op.create_index(
        "idx_insight_tags_gin",
        _tbl,
        ["tags"],
        schema=_schema,
        postgresql_using="gin",
    )


def downgrade() -> None:
    for name in (
        "idx_insight_sort",
        "idx_insight_projects_gin",
        "idx_insight_functions_gin",
        "idx_insight_tags_gin",
    ):
        op.drop_index(name, table_name=_tbl, schema=_schema)
