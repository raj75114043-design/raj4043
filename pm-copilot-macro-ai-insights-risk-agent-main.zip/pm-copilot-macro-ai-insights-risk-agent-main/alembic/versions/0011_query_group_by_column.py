"""Add group_by_column to sql_query_library.

Optional secondary grouping column (e.g. vendor/company name) for
cross-vendor analysis within each geography level.

Revision ID: 0011
Revises: 0010
Create Date: 2026-03-24
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa

revision: str = "0011"
down_revision: str | None = "0010"
branch_labels: str | None = None
depends_on: str | None = None

from app.config import get_settings

_s = get_settings()
_schema = _s.db_schema
_query_lib = _s.table_sql_query_library


def upgrade() -> None:
    op.add_column(
        _query_lib,
        sa.Column("group_by_column", sa.String(100), nullable=True),
        schema=_schema,
    )


def downgrade() -> None:
    op.drop_column(_query_lib, "group_by_column", schema=_schema)
