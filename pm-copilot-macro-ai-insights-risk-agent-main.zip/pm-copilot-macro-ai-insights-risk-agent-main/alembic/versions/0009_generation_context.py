"""Add generation_context JSONB column to insights.

Stores the rendered prompts, data rows fed to the LLM, SQL params, and raw
LLM response so that each insight's generation can be inspected post-hoc.

Revision ID: 0009
Revises: 0008
Create Date: 2026-03-24
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "0009"
down_revision: str | None = "0008"
branch_labels: str | None = None
depends_on: str | None = None

from app.config import get_settings

_s = get_settings()
_schema = _s.db_schema
_insights = _s.table_insights


def upgrade() -> None:
    op.add_column(
        _insights,
        sa.Column("generation_context", postgresql.JSONB(), nullable=True),
        schema=_schema,
    )


def downgrade() -> None:
    op.drop_column(_insights, "generation_context", schema=_schema)
