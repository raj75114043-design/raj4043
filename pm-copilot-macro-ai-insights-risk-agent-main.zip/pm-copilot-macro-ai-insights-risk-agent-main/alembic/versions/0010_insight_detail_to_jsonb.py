"""Change insight_detail from TEXT to JSONB.

Allows storing structured bullet-point arrays instead of plain text.
Existing text values are migrated to single-element JSON arrays.

Revision ID: 0010
Revises: 0009
Create Date: 2026-03-24
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "0010"
down_revision: str | None = "0009"
branch_labels: str | None = None
depends_on: str | None = None

from app.config import get_settings

_s = get_settings()
_schema = _s.db_schema
_insights = _s.table_insights


def upgrade() -> None:
    # Convert existing text values to JSON strings, then alter type
    op.execute(
        f'ALTER TABLE {_schema}.{_insights} '
        f'ALTER COLUMN insight_detail TYPE JSONB '
        f'USING CASE WHEN insight_detail IS NOT NULL '
        f"THEN to_jsonb(insight_detail) ELSE NULL END"
    )


def downgrade() -> None:
    op.execute(
        f'ALTER TABLE {_schema}.{_insights} '
        f'ALTER COLUMN insight_detail TYPE TEXT '
        f"USING CASE WHEN jsonb_typeof(insight_detail) = 'array' "
        f"THEN array_to_string(ARRAY(SELECT jsonb_array_elements_text(insight_detail)), E'\\n') "
        f'ELSE insight_detail::TEXT END'
    )
