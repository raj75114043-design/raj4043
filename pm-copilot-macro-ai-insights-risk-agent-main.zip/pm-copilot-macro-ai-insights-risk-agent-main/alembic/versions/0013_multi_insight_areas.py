"""Add insight_areas (JSONB) to sql_query_library and insight_area (varchar) to insights.

Enables generating multiple distinct insights per query by defining analysis areas
on the query, and tracking which area each insight covers.

Revision ID: 0013
Revises: 0012
Create Date: 2026-03-25
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "0013"
down_revision: str | None = "0012"
branch_labels: str | None = None
depends_on: str | None = None

from app.config import get_settings

_s = get_settings()
_schema = _s.db_schema
_query_lib = _s.table_sql_query_library
_insights = _s.table_insights
_hist = _s.table_insights_historical


def upgrade() -> None:
    # Add insight_areas to sql_query_library
    op.add_column(
        _query_lib,
        sa.Column("insight_areas", postgresql.JSONB, nullable=True),
        schema=_schema,
    )

    # Add insight_area to insights
    op.add_column(
        _insights,
        sa.Column("insight_area", sa.String(200), nullable=True),
        schema=_schema,
    )

    # Add insight_area to insights_historical
    op.add_column(
        _hist,
        sa.Column("insight_area", sa.String(200), nullable=True),
        schema=_schema,
    )


def downgrade() -> None:
    op.drop_column(_hist, "insight_area", schema=_schema)
    op.drop_column(_insights, "insight_area", schema=_schema)
    op.drop_column(_query_lib, "insight_areas", schema=_schema)
