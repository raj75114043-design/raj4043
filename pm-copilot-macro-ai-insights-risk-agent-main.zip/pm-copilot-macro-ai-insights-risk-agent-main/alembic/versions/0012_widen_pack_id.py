"""Widen pack_id from varchar(36) to varchar(200).

Allows pack_id to hold descriptive names in addition to UUIDs.

Revision ID: 0012
Revises: 0011
Create Date: 2026-03-24
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa

revision: str = "0012"
down_revision: str | None = "0011"
branch_labels: str | None = None
depends_on: str | None = None

from app.config import get_settings

_s = get_settings()
_schema = _s.db_schema
_query_lib = _s.table_sql_query_library


def upgrade() -> None:
    op.alter_column(
        _query_lib,
        "pack_id",
        type_=sa.String(200),
        schema=_schema,
    )


def downgrade() -> None:
    op.alter_column(
        _query_lib,
        "pack_id",
        type_=sa.String(36),
        schema=_schema,
    )
