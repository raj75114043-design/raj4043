"""Initial schema — all tables + pgvector extension.

Revision ID: 0001
Revises:
Create Date: 2026-03-01

Table names and target schema are read from application settings so this
migration honours any overrides set in the .env file.
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

from app.config import get_settings

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

# Read once at migration load time (settings are cached via lru_cache)
_s = get_settings()
_schema = _s.effective_schema   # None → public (no explicit prefix)

# Helpers for fully-qualified FK references needed in Alembic DDL
def _fk(table_attr: str, column: str) -> str:
    """Build schema-qualified FK target string for op.create_table."""
    table = getattr(_s, table_attr)
    return f"{_schema}.{table}.{column}" if _schema else f"{table}.{column}"


def _tbl(name_attr: str) -> str:
    return getattr(_s, name_attr)


def _alter(table_attr: str, sql: str) -> str:
    """Build a schema-qualified ALTER TABLE statement."""
    tbl = _tbl(table_attr)
    qualified = f'"{_schema}"."{tbl}"' if _schema else f'"{tbl}"'
    return f"ALTER TABLE {qualified} {sql}"


def upgrade() -> None:
    # pgvector extension installed by env.py before this runs; kept here
    # as an idempotent safety net.
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")

    # ------------------------------------------------------------------ #
    # sql_query_library
    # ------------------------------------------------------------------ #
    op.create_table(
        _tbl("table_sql_query_library"),
        sa.Column("query_id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("name", sa.String(200), nullable=False, unique=True),
        sa.Column("query_sql", sa.Text, nullable=False),
        sa.Column("purpose", sa.Text),
        sa.Column("description", sa.Text),
        sa.Column("geography_level", sa.String(20)),
        sa.Column("projects", postgresql.ARRAY(sa.String)),
        sa.Column("functions", postgresql.ARRAY(sa.String)),
        sa.Column("team", sa.String(100)),
        sa.Column("user_type", sa.String(100)),
        sa.Column("tags", postgresql.ARRAY(sa.String)),
        sa.Column("parameter_schema", postgresql.JSONB),
        sa.Column("prompt_template_id", sa.String(36)),
        sa.Column("is_active", sa.Boolean, default=True),
        sa.Column("version", sa.String(20), default="1.0"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True)),
        schema=_schema,
    )
    op.create_index("idx_sql_geography_level", _tbl("table_sql_query_library"),
                    ["geography_level"], schema=_schema)
    op.create_index("idx_sql_is_active", _tbl("table_sql_query_library"),
                    ["is_active"], schema=_schema)

    # ------------------------------------------------------------------ #
    # prompt_templates
    # ------------------------------------------------------------------ #
    op.create_table(
        _tbl("table_prompt_templates"),
        sa.Column("template_id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("name", sa.String(200), nullable=False, unique=True),
        sa.Column("system_prompt", sa.Text, nullable=False),
        sa.Column("user_prompt", sa.Text, nullable=False),
        sa.Column("category", sa.String(100)),
        sa.Column("subcategory", sa.String(100)),
        sa.Column("expected_variables", postgresql.ARRAY(sa.String)),
        sa.Column("is_active", sa.Boolean, default=True),
        sa.Column("version", sa.String(20), default="1.0"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        schema=_schema,
    )

    # ------------------------------------------------------------------ #
    # insights
    # ------------------------------------------------------------------ #
    op.create_table(
        _tbl("table_insights"),
        sa.Column("insight_id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("title", sa.String(200), nullable=False),
        sa.Column("insight", sa.Text, nullable=False),
        sa.Column("market", sa.String(100)),
        sa.Column("area", sa.String(100)),
        sa.Column("region", sa.String(100)),
        sa.Column("team", sa.String(100)),
        sa.Column("severity_score", sa.Float),
        sa.Column("category", sa.String(100)),
        sa.Column("subcategory", sa.String(100)),
        sa.Column("type", sa.String(50)),
        sa.Column("site_count", sa.Integer),
        sa.Column("drill_down_sql", sa.Text),
        sa.Column("projects", postgresql.ARRAY(sa.String)),
        sa.Column("functions", postgresql.ARRAY(sa.String)),
        sa.Column("tags", postgresql.ARRAY(sa.String)),
        sa.Column("query_id", sa.String(100)),
        sa.Column("prompt_template_id", sa.String(100)),
        sa.Column("llm_model", sa.String(100)),
        sa.Column("job_id", sa.String(36)),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True)),
        sa.Column("expires_at", sa.DateTime(timezone=True)),
        sa.Column("is_active", sa.Boolean, nullable=False, default=True),
        schema=_schema,
    )
    op.create_index("idx_insight_market_region", _tbl("table_insights"),
                    ["market", "region"], schema=_schema)
    op.create_index("idx_insight_created_at", _tbl("table_insights"),
                    ["created_at"], schema=_schema)
    op.create_index("idx_insight_severity", _tbl("table_insights"),
                    ["severity_score"], schema=_schema)
    op.create_index("idx_insight_category", _tbl("table_insights"),
                    ["category", "subcategory"], schema=_schema)
    op.create_index("idx_insight_is_active", _tbl("table_insights"),
                    ["is_active"], schema=_schema)
    op.create_index("idx_insight_expires_at", _tbl("table_insights"),
                    ["expires_at"], schema=_schema)
    op.create_index("idx_insight_job_id", _tbl("table_insights"),
                    ["job_id"], schema=_schema)

    # ------------------------------------------------------------------ #
    # insight_embeddings  (vector column added via ALTER after creation)
    # ------------------------------------------------------------------ #
    op.create_table(
        _tbl("table_insight_embeddings"),
        sa.Column("embedding_id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "insight_id",
            postgresql.UUID(as_uuid=False),
            sa.ForeignKey(_fk("table_insights", "insight_id"), ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("embedding_vector", sa.Text, nullable=False),   # text → cast below
        sa.Column("model_name", sa.String(100), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        schema=_schema,
    )
    # Cast the text column to the pgvector type
    op.execute(_alter(
        "table_insight_embeddings",
        f"ALTER COLUMN embedding_vector TYPE vector({_s.embedding_dimension}) "
        "USING embedding_vector::vector",
    ))
    # IVFFlat approximate nearest-neighbour index
    emb_qualified = (
        f'"{_schema}"."{_tbl("table_insight_embeddings")}"'
        if _schema else f'"{_tbl("table_insight_embeddings")}"'
    )
    op.execute(
        f"CREATE INDEX idx_embedding_vector ON {emb_qualified} "
        "USING ivfflat (embedding_vector vector_cosine_ops) WITH (lists = 100)"
    )
    op.create_index("idx_embedding_insight_id", _tbl("table_insight_embeddings"),
                    ["insight_id"], schema=_schema)

    # ------------------------------------------------------------------ #
    # user_interactions
    # ------------------------------------------------------------------ #
    op.create_table(
        _tbl("table_user_interactions"),
        sa.Column("interaction_id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column(
            "insight_id",
            postgresql.UUID(as_uuid=False),
            sa.ForeignKey(_fk("table_insights", "insight_id"), ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("user_id", sa.String(100), nullable=False),
        sa.Column("liked", sa.Boolean),
        sa.Column("disliked", sa.Boolean),
        sa.Column("acknowledged", sa.Boolean),
        sa.Column("muted", sa.Boolean),
        sa.Column("flagged", sa.Boolean),
        sa.Column("flag_reason", sa.Text),
        sa.Column("comment", sa.Text),
        sa.Column("previous_state", postgresql.JSONB),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True)),
        schema=_schema,
    )
    op.create_unique_constraint(
        "uq_insight_user", _tbl("table_user_interactions"),
        ["insight_id", "user_id"], schema=_schema,
    )
    op.create_index("idx_ui_user_insight", _tbl("table_user_interactions"),
                    ["user_id", "insight_id"], schema=_schema)
    op.create_index("idx_ui_insight", _tbl("table_user_interactions"),
                    ["insight_id"], schema=_schema)
    op.create_index("idx_ui_user_id", _tbl("table_user_interactions"),
                    ["user_id"], schema=_schema)

    # ------------------------------------------------------------------ #
    # insights_historical
    # ------------------------------------------------------------------ #
    op.create_table(
        _tbl("table_insights_historical"),
        sa.Column("archive_id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("insight_id", postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column("title", sa.String(200), nullable=False),
        sa.Column("insight", sa.Text, nullable=False),
        sa.Column("market", sa.String(100)),
        sa.Column("area", sa.String(100)),
        sa.Column("region", sa.String(100)),
        sa.Column("team", sa.String(100)),
        sa.Column("severity_score", sa.Float),
        sa.Column("category", sa.String(100)),
        sa.Column("subcategory", sa.String(100)),
        sa.Column("type", sa.String(50)),
        sa.Column("site_count", sa.Integer),
        sa.Column("drill_down_sql", sa.Text),
        sa.Column("projects", postgresql.ARRAY(sa.String)),
        sa.Column("functions", postgresql.ARRAY(sa.String)),
        sa.Column("tags", postgresql.ARRAY(sa.String)),
        sa.Column("query_id", sa.String(100)),
        sa.Column("prompt_template_id", sa.String(100)),
        sa.Column("llm_model", sa.String(100)),
        sa.Column("job_id", sa.String(36)),
        sa.Column("created_at", sa.DateTime(timezone=True)),
        sa.Column("updated_at", sa.DateTime(timezone=True)),
        sa.Column("expires_at", sa.DateTime(timezone=True)),
        sa.Column("is_active", sa.Boolean, default=False),
        sa.Column("archived_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        schema=_schema,
    )
    op.create_index("idx_hist_insight_id", _tbl("table_insights_historical"),
                    ["insight_id"], schema=_schema)
    op.create_index("idx_hist_market_region", _tbl("table_insights_historical"),
                    ["market", "region"], schema=_schema)
    op.create_index("idx_hist_archived_at", _tbl("table_insights_historical"),
                    ["archived_at"], schema=_schema)

    # ------------------------------------------------------------------ #
    # batch_jobs
    # ------------------------------------------------------------------ #
    op.create_table(
        _tbl("table_batch_jobs"),
        sa.Column("job_id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("geography_filters", postgresql.JSONB),
        sa.Column("timeframe", postgresql.JSONB),
        sa.Column("user_segments", postgresql.JSONB),
        sa.Column("query_tags", postgresql.JSONB),
        sa.Column("status", sa.String(20), nullable=False, default="pending"),
        sa.Column("total_queries", sa.Integer, default=0),
        sa.Column("completed_queries", sa.Integer, default=0),
        sa.Column("failed_queries", sa.Integer, default=0),
        sa.Column("total_insights_generated", sa.Integer, default=0),
        sa.Column("progress_pct", sa.Float, default=0.0),
        sa.Column("error_message", sa.Text),
        sa.Column("error_details", postgresql.JSONB),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("started_at", sa.DateTime(timezone=True)),
        sa.Column("completed_at", sa.DateTime(timezone=True)),
        sa.Column("triggered_by", sa.String(100)),
        schema=_schema,
    )
    op.create_index("idx_job_status", _tbl("table_batch_jobs"),
                    ["status"], schema=_schema)
    op.create_index("idx_job_created_at", _tbl("table_batch_jobs"),
                    ["created_at"], schema=_schema)

    # ------------------------------------------------------------------ #
    # batch_job_logs
    # ------------------------------------------------------------------ #
    op.create_table(
        _tbl("table_batch_job_logs"),
        sa.Column("log_id", postgresql.UUID(as_uuid=False), primary_key=True),
        sa.Column("job_id", postgresql.UUID(as_uuid=False), nullable=False),
        sa.Column("level", sa.String(10), default="INFO"),
        sa.Column("step", sa.String(100)),
        sa.Column("query_id", sa.String(100)),
        sa.Column("message", sa.Text, nullable=False),
        sa.Column("details", postgresql.JSONB),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        schema=_schema,
    )
    op.create_index("idx_joblog_job_id", _tbl("table_batch_job_logs"),
                    ["job_id"], schema=_schema)


def downgrade() -> None:
    op.drop_table(_tbl("table_batch_job_logs"), schema=_schema)
    op.drop_table(_tbl("table_batch_jobs"), schema=_schema)
    op.drop_table(_tbl("table_insights_historical"), schema=_schema)
    op.drop_table(_tbl("table_user_interactions"), schema=_schema)
    op.drop_table(_tbl("table_insight_embeddings"), schema=_schema)
    op.drop_table(_tbl("table_insights"), schema=_schema)
    op.drop_table(_tbl("table_prompt_templates"), schema=_schema)
    op.drop_table(_tbl("table_sql_query_library"), schema=_schema)
    op.execute("DROP EXTENSION IF EXISTS vector")
