"""Add row_limit to sql_query_library.

Per-query configurable max rows fetched from the source DB during insight
generation.  NULL means use the system default (200).

Revision ID: 0007
Revises: 0006
Create Date: 2026-03-24
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa

revision: str = "0007"
down_revision: str | None = "0006"
branch_labels: str | None = None
depends_on: str | None = None

from app.config import get_settings

_s = get_settings()
_schema = _s.db_schema
_query_lib = _s.table_sql_query_library


def upgrade() -> None:
    op.add_column(
        _query_lib,
        sa.Column("row_limit", sa.Integer(), nullable=True),
        schema=_schema,
    )


def downgrade() -> None:
    op.drop_column(_query_lib, "row_limit", schema=_schema)
