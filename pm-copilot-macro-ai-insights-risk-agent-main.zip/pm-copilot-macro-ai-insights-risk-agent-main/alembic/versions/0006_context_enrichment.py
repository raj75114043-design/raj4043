"""Context enrichment: site_ids, consecutive_occurrences, business_context.

- insights.site_ids TEXT[]          — flat list of every site id in the raw rows
                                      before aggregation; lets the drill-down view
                                      always show site-level identifiers even when
                                      the LLM saw only aggregated geo summaries.
- insights.consecutive_occurrences  — how many consecutive daily runs produced an
                                      insight for the same (query, geo) pair. The
                                      engine auto-tags repeated issues rather than
                                      deduplicating; this counter drives that tag.
- sql_query_library.business_context JSONB
                                    — structured KPI context injected into prompts:
                                      kpi_name, unit, target, sla_threshold,
                                      interpretation, aggregation_rules.

Revision ID: 0006
Revises: 0005
Create Date: 2026-03-18
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "0006"
down_revision: str | None = "0005"
branch_labels: str | None = None
depends_on: str | None = None

from app.config import get_settings

_s = get_settings()
_schema = _s.db_schema
_insights = _s.table_insights
_query_lib = _s.table_sql_query_library


def upgrade() -> None:
    # ── insights table ──────────────────────────────────────────────
    op.add_column(
        _insights,
        sa.Column("site_ids", postgresql.ARRAY(sa.String()), nullable=True),
        schema=_schema,
    )
    op.add_column(
        _insights,
        sa.Column("consecutive_occurrences", sa.Integer(), nullable=False, server_default="1"),
        schema=_schema,
    )
    op.create_index(
        "idx_insight_query_geo",
        _insights,
        ["query_id", "geo_level", "region", "area", "market"],
        schema=_schema,
    )

    # ── sql_query_library table ─────────────────────────────────────
    op.add_column(
        _query_lib,
        sa.Column("business_context", postgresql.JSONB(), nullable=True),
        schema=_schema,
    )


def downgrade() -> None:
    op.drop_index("idx_insight_query_geo", table_name=_insights, schema=_schema)
    op.drop_column(_insights, "consecutive_occurrences", schema=_schema)
    op.drop_column(_insights, "site_ids", schema=_schema)
    op.drop_column(_query_lib, "business_context", schema=_schema)
