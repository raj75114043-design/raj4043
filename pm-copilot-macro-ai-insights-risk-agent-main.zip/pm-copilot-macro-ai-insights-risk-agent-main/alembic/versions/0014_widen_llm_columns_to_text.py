"""Widen LLM-generated columns from varchar to TEXT.

Prevents truncation errors when the LLM generates longer-than-expected values
for title, category, subcategory, and type fields.

Revision ID: 0014
Revises: 0013
Create Date: 2026-03-25
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa

revision: str = "0014"
down_revision: str | None = "0013"
branch_labels: str | None = None
depends_on: str | None = None

from app.config import get_settings

_s = get_settings()
_schema = _s.db_schema
_insights = _s.table_insights
_hist = _s.table_insights_historical

# Columns to widen: (column_name, old_type_for_downgrade)
_COLUMNS = [
    ("title", "VARCHAR(200)"),
    ("category", "VARCHAR(100)"),
    ("subcategory", "VARCHAR(100)"),
    ("type", "VARCHAR(50)"),
]


def upgrade() -> None:
    for col, _ in _COLUMNS:
        op.alter_column(_insights, col, type_=sa.Text, schema=_schema)
        op.alter_column(_hist, col, type_=sa.Text, schema=_schema)


def downgrade() -> None:
    for col, old_type in _COLUMNS:
        # Downgrade truncates values that exceed the original limit
        for table in (_insights, _hist):
            op.execute(
                f'ALTER TABLE {_schema}.{table} '
                f'ALTER COLUMN {col} TYPE {old_type}'
            )
