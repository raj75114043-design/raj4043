"""Add drill_down_data JSONB column to insights.

Stores the full result rows from the drill-down SQL execution at generation
time, so the drill-down API returns point-in-time data rather than re-running
queries against potentially updated source tables.

Revision ID: 0008
Revises: 0007
Create Date: 2026-03-24
"""
from __future__ import annotations

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "0008"
down_revision: str | None = "0007"
branch_labels: str | None = None
depends_on: str | None = None

from app.config import get_settings

_s = get_settings()
_schema = _s.db_schema
_insights = _s.table_insights


def upgrade() -> None:
    op.add_column(
        _insights,
        sa.Column("drill_down_data", postgresql.JSONB(), nullable=True),
        schema=_schema,
    )


def downgrade() -> None:
    op.drop_column(_insights, "drill_down_data", schema=_schema)
