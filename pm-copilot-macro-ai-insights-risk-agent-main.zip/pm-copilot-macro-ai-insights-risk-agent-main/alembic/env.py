"""Alembic environment — async SQLAlchemy setup."""
from __future__ import annotations

import asyncio
from logging.config import fileConfig

from alembic import context
from sqlalchemy import pool
from sqlalchemy.engine import Connection
from sqlalchemy.ext.asyncio import async_engine_from_config

# Import all models so Alembic can see them for autogenerate
from app.database import Base  # noqa: F401
import app.models  # noqa: F401

config = context.config
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Use the DATABASE_URL from settings at migration time
from app.config import get_settings  # noqa: E402
settings = get_settings()
# configparser uses % as its interpolation character, so any % in the URL
# (e.g. %40 for @ in passwords) must be escaped as %% before being stored.
config.set_main_option("sqlalchemy.url", settings.database_url.replace("%", "%%"))

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    """Run migrations without a live DB connection (generates SQL)."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def do_run_migrations(connection: Connection) -> None:
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        compare_type=True,
        include_schemas=True,
        # Store alembic_version in the same schema as application tables
        version_table_schema=settings.effective_schema,
    )
    with context.begin_transaction():
        context.run_migrations()


async def run_async_migrations() -> None:
    """Run migrations against a live async engine."""
    from sqlalchemy import text as sa_text

    # Build search_path matching _build_engine() so the 'vector' type is visible.
    parts: list[str] = []
    if settings.effective_schema:
        parts.append(settings.effective_schema)
    if settings.pgvector_schema not in ("public", *parts):
        parts.append(settings.pgvector_schema)
    if "public" not in parts:
        parts.append("public")
    search_path = ",".join(parts)

    connectable = async_engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
        connect_args={"server_settings": {"search_path": search_path}},
    )

    # pgvector must be committed before DDL so the 'vector' type is visible.
    async with connectable.connect() as conn:
        await conn.execute(sa_text("CREATE EXTENSION IF NOT EXISTS vector"))
        await conn.commit()

    async with connectable.connect() as connection:
        await connection.run_sync(do_run_migrations)

    await connectable.dispose()


def run_migrations_online() -> None:
    asyncio.run(run_async_migrations())


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
