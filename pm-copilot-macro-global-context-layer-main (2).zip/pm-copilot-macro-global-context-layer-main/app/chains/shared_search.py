"""

Shared 5-search utility for context diagnostic chains.
Runs keyword fuzzy, keyword semantic, KPI fuzzy, KPI semantic,
and question bank semantic searches against a single query.

"""

import asyncio
import logging
import numpy as np
from typing import List, Set
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.models.semantic_models import SemanticKPI, SemanticKeyword, SemanticQuestionBank
from app.services.embedding_service import embedding_service
from app.api.endpoints.search import (
    _keyword_store,
    _kpi_store,
    _fuzzy_match_precomputed,
    _filter_stopwords,
    _word_segments,
)

logger = logging.getLogger(__name__)


def _cosine_sim(v1: List[float], v2: List[float]) -> float:
    a, b = np.array(v1), np.array(v2)
    na, nb = np.linalg.norm(a), np.linalg.norm(b)
    return float(np.dot(a, b) / (na * nb)) if na > 0 and nb > 0 else 0.0


async def run_five_searches(db: AsyncSession, query: str, top_k: int = 5) -> dict:
    """
    Run all 5 diagnostic searches and return structured results keyed by search type.

    Search types:
      keyword_search          – fuzzy name/synonym match on keywords
      keyword_semantic_search – vector cosine similarity on keywords
      kpi_keyword_search      – fuzzy name match on KPIs
      kpi_semantic_search     – vector cosine similarity on KPIs
      question_bank_search    – vector cosine similarity on question bank
    """
    # Fetch all records (needed for embeddings regardless of cache state)
    kw_records = (await db.execute(select(SemanticKeyword))).scalars().all()
    kpi_records = (await db.execute(select(SemanticKPI))).scalars().all()
    qb_records = (await db.execute(select(SemanticQuestionBank))).scalars().all()

    # Refresh keyword/KPI caches if stale, reusing records already fetched
    if _keyword_store.is_stale:
        _keyword_store.build_from(kw_records)
    if _kpi_store.is_stale:
        _kpi_store.build_from(kpi_records)

    # Generate query embedding for semantic searches
    try:
        query_emb = await embedding_service.generate_embedding(query)
    except Exception as exc:
        logger.warning("Embedding generation failed for diagnostic search: %s", exc)
        query_emb = None

    # Build embedding lookup maps (keyword_id/kpi_id → embedding)
    kw_emb_map = {kw.keyword_id: kw.embedding for kw in kw_records if kw.embedding}
    kpi_emb_map = {kpi.kpi_id: kpi.embedding for kpi in kpi_records if kpi.embedding}

    def _compute() -> dict:
        # Pre-compute sentence components once for all fuzzy comparisons
        q_lower = query.lower()
        q_words = q_lower.split()
        q_words_filtered = _filter_stopwords(q_words)
        q_word_segs = [_word_segments(w) for w in q_words_filtered]

        # ── Candidate pre-filtering via token + prefix index (mirrors agent endpoint) ──
        kw_candidates: Set[int] = set()
        for tok in q_words_filtered:
            kw_candidates.update(_keyword_store.token_index.get(tok, set()))
        for tok in q_words:  # raw tokens catch short acronyms that are stopwords
            kw_candidates.update(_keyword_store.token_index.get(tok, set()))
        for tok in q_words_filtered:
            if len(tok) >= 3:
                kw_candidates.update(_keyword_store.prefix_index.get(tok[:3], set()))

        kpi_candidates: Set[int] = set()
        for tok in q_words_filtered:
            kpi_candidates.update(_kpi_store.token_index.get(tok, set()))
        for tok in q_words:
            kpi_candidates.update(_kpi_store.token_index.get(tok, set()))
        for tok in q_words_filtered:
            if len(tok) >= 3:
                kpi_candidates.update(_kpi_store.prefix_index.get(tok[:3], set()))

        logger.debug(
            "shared_search candidate pre-filter | query=%r | kw_candidates=%d kpi_candidates=%d",
            query[:80],
            len(kw_candidates),
            len(kpi_candidates),
        )

        # ── 1. Keyword fuzzy match — all matches, no top_k cap (binary hit/miss) ──
        kw_keyword: list = []
        for idx in kw_candidates:
            entry = _keyword_store.entries[idx]
            matched = []
            for term in entry.terms:
                if _fuzzy_match_precomputed(
                    q_lower, q_words, q_words_filtered, q_word_segs, term
                ):
                    if not matched or term.lower() != (entry.keyword_name or "").lower():
                        matched.append(term)
            if matched:
                kw_keyword.append({
                    "keyword_id": entry.keyword_id,
                    "keyword_name": entry.keyword_name,
                    "keyword_description": entry.keyword_description,
                    "mapped_tables_columns": entry.mapped_tables_columns,
                    "logic": entry.logic,
                    "synonyms": entry.synonyms,
                    "matched_terms": matched,
                    "score": 1.0,
                })

        # ── 2. Keyword semantic search ──────────────────────────────────────
        kw_semantic: list = []
        if query_emb:
            for entry in _keyword_store.entries:
                emb = kw_emb_map.get(entry.keyword_id)
                if emb:
                    score = round(_cosine_sim(query_emb, emb), 4)
                    kw_semantic.append({
                        "keyword_id": entry.keyword_id,
                        "keyword_name": entry.keyword_name,
                        "keyword_description": entry.keyword_description,
                        "mapped_tables_columns": entry.mapped_tables_columns,
                        "logic": entry.logic,
                        "synonyms": entry.synonyms,
                        "score": score,
                    })
            kw_semantic.sort(key=lambda x: x["score"], reverse=True)
            kw_semantic = kw_semantic[:top_k]

        # ── 3. KPI fuzzy match — all matches, no top_k cap (binary hit/miss) ──
        kpi_keyword: list = []
        for idx in kpi_candidates:
            entry = _kpi_store.entries[idx]
            matched = []
            for term in entry.terms:
                if _fuzzy_match_precomputed(
                    q_lower, q_words, q_words_filtered, q_word_segs, term
                ):
                    matched.append(term)
            if matched:
                kpi_keyword.append({
                    "kpi_id": entry.kpi_id,
                    "kpi_name": entry.kpi_name,
                    "description": entry.description,
                    "formula": entry.formula,
                    "mapped_tables_columns": entry.mapped_tables_columns,
                    "logic": entry.logic,
                    "matched_terms": matched,
                    "score": 1.0,
                })

        # ── 4. KPI semantic search ──────────────────────────────────────────
        kpi_semantic: list = []
        if query_emb:
            for entry in _kpi_store.entries:
                emb = kpi_emb_map.get(entry.kpi_id)
                if emb:
                    score = round(_cosine_sim(query_emb, emb), 4)
                    kpi_semantic.append({
                        "kpi_id": entry.kpi_id,
                        "kpi_name": entry.kpi_name,
                        "description": entry.description,
                        "formula": entry.formula,
                        "mapped_tables_columns": entry.mapped_tables_columns,
                        "logic": entry.logic,
                        "score": score,
                    })
            kpi_semantic.sort(key=lambda x: x["score"], reverse=True)
            kpi_semantic = kpi_semantic[:top_k]

        # ── 5. Question bank semantic search ───────────────────────────────
        qb_semantic: list = []
        if query_emb:
            for qb in qb_records:
                if qb.embedding:
                    score = round(_cosine_sim(query_emb, qb.embedding), 4)
                    qb_semantic.append({
                        "question_id": qb.question_id,
                        "question": qb.question,
                        "sql": qb.sql,
                        "score": score,
                    })
            qb_semantic.sort(key=lambda x: x["score"], reverse=True)
            qb_semantic = qb_semantic[:top_k]

        logger.debug(
            "shared_search results | query=%r | kw_fuzzy=%d kw_sem=%d kpi_fuzzy=%d kpi_sem=%d qb=%d",
            query[:80],
            len(kw_keyword),
            len(kw_semantic),
            len(kpi_keyword),
            len(kpi_semantic),
            len(qb_semantic),
        )
        return {
            "keyword_search": kw_keyword,
            "keyword_semantic_search": kw_semantic,
            "kpi_keyword_search": kpi_keyword,
            "kpi_semantic_search": kpi_semantic,
            "question_bank_search": qb_semantic,
        }

    return await asyncio.to_thread(_compute)


async def run_keyword_fuzzy_search(db: AsyncSession, query: str) -> list:
    """
    Run only the keyword fuzzy (non-semantic) search against a query.

    Used for SQL-side matching in the ground truth fixer, where token overlap
    against SQL identifiers/column names is meaningful but embedding similarity
    is not (SQL text is not natural language).
    """
    kw_records = (await db.execute(select(SemanticKeyword))).scalars().all()

    if _keyword_store.is_stale:
        _keyword_store.build_from(kw_records)

    def _compute() -> list:
        q_lower = query.lower()
        q_words = q_lower.split()
        q_words_filtered = _filter_stopwords(q_words)
        q_word_segs = [_word_segments(w) for w in q_words_filtered]

        candidates: Set[int] = set()
        for tok in q_words_filtered:
            candidates.update(_keyword_store.token_index.get(tok, set()))
        for tok in q_words:
            candidates.update(_keyword_store.token_index.get(tok, set()))
        for tok in q_words_filtered:
            if len(tok) >= 3:
                candidates.update(_keyword_store.prefix_index.get(tok[:3], set()))

        results: list = []
        for idx in candidates:
            entry = _keyword_store.entries[idx]
            matched = []
            for term in entry.terms:
                if _fuzzy_match_precomputed(
                    q_lower, q_words, q_words_filtered, q_word_segs, term
                ):
                    if not matched or term.lower() != (entry.keyword_name or "").lower():
                        matched.append(term)
            if matched:
                results.append({
                    "keyword_id": entry.keyword_id,
                    "keyword_name": entry.keyword_name,
                    "keyword_description": entry.keyword_description,
                    "mapped_tables_columns": entry.mapped_tables_columns,
                    "logic": entry.logic,
                    "synonyms": entry.synonyms,
                    "matched_terms": matched,
                    "score": 1.0,
                })

        logger.debug(
            "run_keyword_fuzzy_search | query=%r | hits=%d",
            query[:80],
            len(results),
        )
        return results

    return await asyncio.to_thread(_compute)
