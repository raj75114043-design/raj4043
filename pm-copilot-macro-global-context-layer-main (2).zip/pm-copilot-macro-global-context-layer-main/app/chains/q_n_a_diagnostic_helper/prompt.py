from langchain_core.prompts import PromptTemplate

# ── Call 1: Identification ────────────────────────────────────────────────────
_IDENTIFICATION_TEMPLATE = """\
You are an expert retrieval analyst for a Nokia PM Copilot text-to-SQL system.
Your job is to study TWO sets of search results — one from the user's original \
query, one from their feedback — and pinpoint which keyword entries are relevant \
and where retrieval gaps exist.

## INPUT

User Query: {user_query}

User Feedback (what was missing or incorrect in the response):
{user_feedback}

## SEARCH RESULTS — USER QUERY

### 1. Keyword Name/Synonym Fuzzy Match
{keyword_search}

### 2. Keyword Semantic Search
{keyword_semantic_search}

### 3. KPI Name Fuzzy Match
{kpi_keyword_search}

### 4. KPI Semantic Search
{kpi_semantic_search}

### 5. Question Bank Semantic Search
{question_bank_search}

## SEARCH RESULTS — USER FEEDBACK (searched separately)

### 1. Keyword Name/Synonym Fuzzy Match
{fb_keyword_search}

### 2. Keyword Semantic Search
{fb_keyword_semantic}

### 3. KPI Name Fuzzy Match
{fb_kpi_keyword_search}

### 4. KPI Semantic Search
{fb_kpi_semantic}

### 5. Question Bank Semantic Search
{fb_question_bank_search}

## TASK

Compare the two search result sets and identify:

1. Entries that appear in BOTH sets — these are strong retrieval signals and are \
   likely already well-covered.
2. Entries that appear ONLY in the query search — the query terms trigger them but \
   the feedback terms do not; assess if this is a gap in synonyms or description.
3. Entries that appear ONLY in the feedback search — the feedback language reaches \
   them but the original query does not; this often reveals missing synonyms or \
   description gaps that caused the initial retrieval failure.

For each relevant keyword entry found, state its ID and name, then assess:
  - Does its keyword_description cover the concept expressed in the user query?
  - Do its synonyms include the terms the user used in their query and feedback?
  - Does its mapped_tables_columns reflect the data the user expected to get back?
  - Does the entry address the gap described in the user's feedback?

Be precise. Reference IDs and actual field values from the results.
Return plain text only — no JSON, no bullet points required, just a clear analysis.
"""

IDENTIFICATION_PROMPT = PromptTemplate.from_template(_IDENTIFICATION_TEMPLATE)


# ── Call 2: Diagnostic ────────────────────────────────────────────────────────
_DIAGNOSTIC_TEMPLATE = """\
You are an expert retrieval analyst for a Nokia PM Copilot text-to-SQL system.
You have already identified which keyword entries are relevant to the query. \
Now write a precise field-level diagnostic.

## INPUT

User Query: {user_query}

User Feedback (what was missing or incorrect in the response):
{user_feedback}

## IDENTIFICATION (from previous analysis step)

{identification}

## TASK

Based on the identification above, diagnose exactly what needs to change in the \
keyword entries to resolve the user's feedback and ensure this query reliably \
retrieves the correct context in future.

Focus ONLY on keyword entries. Do NOT propose changes to KPI entries or \
Question Bank entries.

For each keyword that needs improvement, specify:
  - Keyword ID and name
  - Which field(s) need changing: keyword_description / synonyms / logic / mapped_tables_columns
  - What the current value is missing relative to the user's feedback
  - What the updated value should contain and why

Return plain text only — no JSON.
"""

DIAGNOSTIC_PROMPT = PromptTemplate.from_template(_DIAGNOSTIC_TEMPLATE)


# ── Call 3: JSON Update Patches ───────────────────────────────────────────────
_UPDATES_TEMPLATE = """\
You are an expert retrieval analyst for a Nokia PM Copilot text-to-SQL system.
You have a diagnostic report describing exactly what keyword fields need to change. \
Now produce the update patches.

## INPUT

User Query: {user_query}

## DIAGNOSTIC REPORT (from previous analysis step)

{diagnostic}

## TASK

Produce a JSON array of keyword update patches based strictly on the diagnostic above.

Return ONLY a valid JSON array. No markdown fences. No explanation. No extra text.

Rules:
  - type must always be "keyword" — do NOT create KPI or question_bank entries
  - id must be the integer keyword_id from the diagnostic
  - Include only fields inside "updates" that need to change (omit fields that stay the same)
  - Return [] if the diagnostic concludes no changes are needed

[
  {{
    "type": "keyword",
    "id": <keyword_id as integer>,
    "name": "<keyword_name>",
    "updates": {{
      "keyword_description": "<improved description — only if changing>",
      "synonyms": "<comma-separated synonyms — only if changing>",
      "logic": "<business logic — only if changing>",
      "mapped_tables_columns": "<table.column — only if changing>"
    }}
  }}
]
"""

UPDATES_PROMPT = PromptTemplate.from_template(_UPDATES_TEMPLATE)
