"""
Q&A Diagnostic Helper Chain  —  Tree of Thought (3 LLM calls)
==============================================================
Call 1 — Identification : which keyword entries from the 5 searches are
                          relevant to the query and user feedback
Call 2 — Diagnostic     : field-level analysis of what should change in
                          those keyword entries (keywords only)
Call 3 — JSON Updates   : ready-to-use keyword update patches for the API
"""

import json
import logging
import time
from sqlalchemy.ext.asyncio import AsyncSession

from app.chains.shared_search import run_five_searches
from app.chains.q_n_a_diagnostic_helper.config import llm
from app.chains.q_n_a_diagnostic_helper.prompt import (
    IDENTIFICATION_PROMPT,
    DIAGNOSTIC_PROMPT,
    UPDATES_PROMPT,
)

logger = logging.getLogger(__name__)


def _fmt(results: list) -> str:
    """Format search result dicts as readable text for the LLM prompt."""
    if not results:
        return "  (no results found)"
    lines = []
    for i, r in enumerate(results, 1):
        score = r.get("score", "N/A")
        rid = r.get("keyword_id") or r.get("kpi_id") or r.get("question_id", "?")
        name = r.get("keyword_name") or r.get("kpi_name") or r.get("question", "?")
        lines.append(f"  {i}. [ID:{rid}] {name}  (score: {score})")
        for field in (
            "keyword_description", "description", "synonyms",
            "logic", "formula", "sql", "matched_terms",
        ):
            val = r.get(field)
            if val:
                val_str = str(val)
                if len(val_str) > 250:
                    val_str = val_str[:250] + "..."
                lines.append(f"     {field}: {val_str}")
    return "\n".join(lines)


def _content(response) -> str:
    """Extract string content from an LLM response object."""
    return response.content if hasattr(response, "content") else str(response)


def _extract_json_array(raw: str) -> list:
    """Extract a JSON array from the LLM response, handling markdown fences."""
    s = raw.strip()
    try:
        result = json.loads(s)
        if isinstance(result, list):
            return result
    except json.JSONDecodeError:
        pass
    if "```" in s:
        for part in s.split("```"):
            cleaned = part.strip()
            if cleaned.lower().startswith("json"):
                cleaned = cleaned[4:].strip()
            try:
                result = json.loads(cleaned)
                if isinstance(result, list):
                    return result
            except json.JSONDecodeError:
                continue
    start, end = s.find("["), s.rfind("]")
    if start != -1 and end > start:
        try:
            result = json.loads(s[start:end + 1])
            if isinstance(result, list):
                return result
        except json.JSONDecodeError:
            pass
    return []


async def run_qna_diagnostic_helper(
    db: AsyncSession,
    user_query: str,
    user_feedback: str,
    top_k: int = 5,
) -> dict:
    """
    Tree-of-Thought Q&A diagnostic helper — 3 sequential LLM calls.

    1. Identification  : analyse search results from BOTH query and feedback searches
    2. Diagnostic      : field-level keyword changes needed (keywords only)
    3. JSON Updates    : keyword update patches ready for the API

    Returns a dict ready to be unpacked into QnADiagnosticHelperResponse.
    """
    # Run 5 searches on the user query and separately on the user feedback
    t_search = time.perf_counter()
    search_results = await run_five_searches(db, user_query, top_k=top_k)
    feedback_search_results = await run_five_searches(db, user_feedback, top_k=top_k)
    logger.info(
        "Q&A helper — searches done in %.2fs | "
        "query: kw_fuzzy=%d kw_sem=%d kpi_fuzzy=%d kpi_sem=%d qb=%d | "
        "feedback: kw_fuzzy=%d kw_sem=%d kpi_fuzzy=%d kpi_sem=%d qb=%d",
        time.perf_counter() - t_search,
        len(search_results["keyword_search"]),
        len(search_results["keyword_semantic_search"]),
        len(search_results["kpi_keyword_search"]),
        len(search_results["kpi_semantic_search"]),
        len(search_results["question_bank_search"]),
        len(feedback_search_results["keyword_search"]),
        len(feedback_search_results["keyword_semantic_search"]),
        len(feedback_search_results["kpi_keyword_search"]),
        len(feedback_search_results["kpi_semantic_search"]),
        len(feedback_search_results["question_bank_search"]),
    )

    fmt_args = {
        # Query-based search results
        "keyword_search":          _fmt(search_results["keyword_search"]),
        "keyword_semantic_search": _fmt(search_results["keyword_semantic_search"]),
        "kpi_keyword_search":      _fmt(search_results["kpi_keyword_search"]),
        "kpi_semantic_search":     _fmt(search_results["kpi_semantic_search"]),
        "question_bank_search":    _fmt(search_results["question_bank_search"]),
        # Feedback-based search results (searched separately)
        "fb_keyword_search":       _fmt(feedback_search_results["keyword_search"]),
        "fb_keyword_semantic":     _fmt(feedback_search_results["keyword_semantic_search"]),
        "fb_kpi_keyword_search":   _fmt(feedback_search_results["kpi_keyword_search"]),
        "fb_kpi_semantic":         _fmt(feedback_search_results["kpi_semantic_search"]),
        "fb_question_bank_search": _fmt(feedback_search_results["question_bank_search"]),
    }

    # ── Call 1: Identification ────────────────────────────────────────────────
    logger.info("Q&A helper — Call 1: Identification (LLM)")
    t1 = time.perf_counter()
    resp1 = await (IDENTIFICATION_PROMPT | llm).ainvoke({
        "user_query":    user_query,
        "user_feedback": user_feedback,
        **fmt_args,
    })
    identification = _content(resp1)
    logger.info("Q&A helper — Call 1 done in %.2fs | chars=%d", time.perf_counter() - t1, len(identification))
    logger.debug("Q&A helper — identification preview: %s", identification[:300])

    # ── Call 2: Diagnostic ────────────────────────────────────────────────────
    logger.info("Q&A helper — Call 2: Diagnostic (LLM)")
    t2 = time.perf_counter()
    resp2 = await (DIAGNOSTIC_PROMPT | llm).ainvoke({
        "user_query":     user_query,
        "user_feedback":  user_feedback,
        "identification": identification,
    })
    diagnostic = _content(resp2)
    logger.info("Q&A helper — Call 2 done in %.2fs | chars=%d", time.perf_counter() - t2, len(diagnostic))
    logger.debug("Q&A helper — diagnostic preview: %s", diagnostic[:300])

    # ── Call 3: JSON Update Patches ───────────────────────────────────────────
    logger.info("Q&A helper — Call 3: JSON updates (LLM)")
    t3 = time.perf_counter()
    resp3 = await (UPDATES_PROMPT | llm).ainvoke({
        "user_query": user_query,
        "diagnostic": diagnostic,
    })
    raw_updates = _content(resp3)
    json_updates = _extract_json_array(raw_updates)
    logger.info(
        "Q&A helper — Call 3 done in %.2fs | patches=%d | raw_chars=%d",
        time.perf_counter() - t3,
        len(json_updates),
        len(raw_updates),
    )

    if not json_updates and raw_updates.strip() not in ("[]", ""):
        logger.warning("Q&A diagnostic helper: JSON array extraction failed — raw: %s", raw_updates[:300])

    return {
        "user_query":               user_query,
        "user_feedback":            user_feedback,
        "search_results":           search_results,
        "feedback_search_results":  feedback_search_results,
        "identification":           identification,
        "diagnostic":               diagnostic,
        "json_updates":             json_updates,
        "llm_raw_response":         raw_updates,
    }
