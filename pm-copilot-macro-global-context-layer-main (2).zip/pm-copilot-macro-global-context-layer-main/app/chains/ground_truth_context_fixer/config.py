from langchain_openai import ChatOpenAI
from app.core.config import settings

llm = ChatOpenAI(
    api_key="NONE",
    model="o4-mini",
    base_url=settings.llm_gateway_link,
    default_headers={
        "api-key": settings.llm_api_key,
        "workspacename": settings.workspace_name,
    },
    temperature=0,
    timeout=120,
)
