from langchain_core.prompts import PromptTemplate

# ── Call 1: Identification ────────────────────────────────────────────────────
_IDENTIFICATION_TEMPLATE = """\
You are an expert retrieval analyst for a Nokia PM Copilot text-to-SQL system.
Your job is to study the search results and pinpoint which keyword entries are \
relevant to the query and the verified correct SQL.

## INPUT

User Query: {user_query}

Correct SQL:
{correct_sql}

## SEARCH RESULTS

### 1. Keyword Name/Synonym Fuzzy Match
{keyword_search}

### 2. Keyword Semantic Search
{keyword_semantic_search}

### 3. KPI Name Fuzzy Match
{kpi_keyword_search}

### 4. KPI Semantic Search
{kpi_semantic_search}

### 5. Question Bank Semantic Search
{question_bank_search}


## Search Results of SQL [New Keywords match extracted from SQL ]

### 1. Keyword Name/Synonym Fuzzy Match
{keyword_search_sql}




## TASK

For each keyword entry found in the search results above, state its ID and name, \
then assess:
  - Does its keyword_description reflect what the SQL actually selects or filters?
  - Do its synonyms cover the vocabulary used in the user query?
  - Does its mapped_tables_columns match the tables/columns in the correct SQL?
  - Are there any obvious gaps in coverage?
  - Look into the extracted keyword search from SQL which will showcase where coverage can be got 

Be precise. Reference IDs and actual field values from the results.
Return plain text only — no JSON, no bullet points required, just a clear analysis.
"""

IDENTIFICATION_PROMPT = PromptTemplate.from_template(_IDENTIFICATION_TEMPLATE)


# ── Call 2: Diagnostic ────────────────────────────────────────────────────────
_DIAGNOSTIC_TEMPLATE = """\
You are an expert retrieval analyst for a Nokia PM Copilot text-to-SQL system.
You have already identified which keyword entries are relevant to the query. \
Now write a precise field-level diagnostic.

## INPUT

User Query: {user_query}

Correct SQL:
{correct_sql}

## IDENTIFICATION (from previous analysis step)

{identification}

## SEARCH RESULTS

### 1. Keyword Name/Synonym Fuzzy Match
{keyword_search}

### 2. Keyword Semantic Search
{keyword_semantic_search}

### 3. KPI Name Fuzzy Match
{kpi_keyword_search}

### 4. KPI Semantic Search
{kpi_semantic_search}

### 5. Question Bank Semantic Search
{question_bank_search}


## Search Results of SQL [New Keywords match extracted from SQL ]

### 1. Keyword Name/Synonym Fuzzy Match
{keyword_search_sql}


## TASK

Based on the identification above, diagnose exactly what needs to change in the \
keyword entries to ensure this user query reliably retrieves the correct context.

Focus ONLY on keyword entries. Do NOT propose changes to KPI entries or \
Question Bank entries.

For each keyword that needs improvement, specify:
  - Keyword ID and name
  - Which field(s) need changing: keyword_description / synonyms / logic / mapped_tables_columns
  - What the current value fails to capture
  - What the updated value should contain and why (reference SQL table/column names directly)

Return plain text only — no JSON.
"""

DIAGNOSTIC_PROMPT = PromptTemplate.from_template(_DIAGNOSTIC_TEMPLATE)


# ── Call 3: JSON Update Patches ───────────────────────────────────────────────
_UPDATES_TEMPLATE = """\
You are an expert retrieval analyst for a Nokia PM Copilot text-to-SQL system.
You have a diagnostic report describing exactly what keyword fields need to change. \
Now produce the update patches.

## INPUT

User Query: {user_query}

Correct SQL:
{correct_sql}

## IDENTIFICATION (from previous analysis step 1)

{identification}


## DIAGNOSTIC REPORT (from previous analysis step 2)

{diagnostic}

## SEARCH RESULTS

### 1. Keyword Name/Synonym Fuzzy Match
{keyword_search}

### 2. Keyword Semantic Search
{keyword_semantic_search}

### 3. KPI Name Fuzzy Match
{kpi_keyword_search}

### 4. KPI Semantic Search
{kpi_semantic_search}

### 5. Question Bank Semantic Search
{question_bank_search}


## Search Results of SQL [New Keywords match extracted from SQL ]

### 1. Keyword Name/Synonym Fuzzy Match
{keyword_search_sql}



## TASK

Produce a JSON array of keyword update patches based strictly on the diagnostic above.

Return ONLY a valid JSON array. No markdown fences. No explanation. No extra text.

Rules:
  - type must always be "keyword" — do NOT create KPI or question_bank entries
  - id must be the integer keyword_id from the diagnostic
  - Include only fields inside "updates" that need to change (omit fields that stay the same)
  - Return [] if the diagnostic concludes no changes are needed

[
  {{
    "type": "keyword",
    "id": <keyword_id as integer>,
    "name": "<keyword_name>",
    "updates": {{
      "keyword_description": "<improved description — only if changing>",
      "synonyms": "<comma-separated synonyms — only if changing>",
      "logic": "<business logic — only if changing>",
      "mapped_tables_columns": "<table.column — only if changing>"
    }}
  }}
]
"""

UPDATES_PROMPT = PromptTemplate.from_template(_UPDATES_TEMPLATE)
