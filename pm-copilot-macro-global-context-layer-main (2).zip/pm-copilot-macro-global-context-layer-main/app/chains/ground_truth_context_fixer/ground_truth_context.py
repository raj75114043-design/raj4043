"""
Ground Truth Context Fixer Chain  —  Tree of Thought (3 LLM calls)
==================================================================
Call 1 — Identification : which keyword entries from the 5 searches are
                          relevant to the query and correct SQL
Call 2 — Diagnostic     : field-level analysis of what should change in
                          those keyword entries (keywords only)
Call 3 — JSON Updates   : ready-to-use keyword update patches for the API
"""

import json
import logging
import time
from sqlalchemy.ext.asyncio import AsyncSession

from app.chains.shared_search import run_five_searches, run_keyword_fuzzy_search
from app.chains.ground_truth_context_fixer.config import llm
from app.chains.ground_truth_context_fixer.prompt import (
    IDENTIFICATION_PROMPT,
    DIAGNOSTIC_PROMPT,
    UPDATES_PROMPT,
)

logger = logging.getLogger(__name__)


def _fmt(results: list) -> str:
    """Format search result dicts as readable text for the LLM prompt."""
    if not results:
        return "  (no results found)"
    lines = []
    for i, r in enumerate(results, 1):
        score = r.get("score", "N/A")
        rid = r.get("keyword_id") or r.get("kpi_id") or r.get("question_id", "?")
        name = r.get("keyword_name") or r.get("kpi_name") or r.get("question", "?")
        lines.append(f"  {i}. [ID:{rid}] {name}  (score: {score})")
        for field in (
            "keyword_description", "description", "synonyms",
            "logic", "formula", "sql", "matched_terms",
        ):
            val = r.get(field)
            if val:
                val_str = str(val)
                if len(val_str) > 250:
                    val_str = val_str[:250] + "..."
                lines.append(f"     {field}: {val_str}")
    return "\n".join(lines)


def _content(response) -> str:
    """Extract string content from an LLM response object."""
    return response.content if hasattr(response, "content") else str(response)


def _extract_json_array(raw: str) -> list:
    """Extract a JSON array from the LLM response, handling markdown fences."""
    s = raw.strip()
    try:
        result = json.loads(s)
        if isinstance(result, list):
            return result
    except json.JSONDecodeError:
        pass
    if "```" in s:
        for part in s.split("```"):
            cleaned = part.strip()
            if cleaned.lower().startswith("json"):
                cleaned = cleaned[4:].strip()
            try:
                result = json.loads(cleaned)
                if isinstance(result, list):
                    return result
            except json.JSONDecodeError:
                continue
    start, end = s.find("["), s.rfind("]")
    if start != -1 and end > start:
        try:
            result = json.loads(s[start:end + 1])
            if isinstance(result, list):
                return result
        except json.JSONDecodeError:
            pass
    return []


async def run_ground_truth_context_fixer(
    db: AsyncSession,
    user_query: str,
    correct_sql: str,
    top_k: int = 5,
) -> dict:
    """
    Tree-of-Thought ground truth context fixer — 3 sequential LLM calls.

    1. Identification  : analyse search results vs. correct SQL
    2. Diagnostic      : field-level keyword changes needed (keywords only)
    3. JSON Updates    : keyword update patches ready for the API

    Returns a dict ready to be unpacked into GroundTruthContextFixerResponse.
    """

    t_search = time.perf_counter()
    search_results = await run_five_searches(db, user_query, top_k=top_k)
    sql_keyword_results = await run_keyword_fuzzy_search(db, correct_sql)
    logger.info(
        "Ground truth fixer — searches done in %.2fs | "
        "kw_fuzzy=%d kw_sem=%d kpi_fuzzy=%d kpi_sem=%d qb=%d | "
        "sql_kw_fuzzy=%d",
        time.perf_counter() - t_search,
        len(search_results["keyword_search"]),
        len(search_results["keyword_semantic_search"]),
        len(search_results["kpi_keyword_search"]),
        len(search_results["kpi_semantic_search"]),
        len(search_results["question_bank_search"]),
        len(sql_keyword_results),
    )

    fmt_args = {
        "keyword_search":          _fmt(search_results["keyword_search"]),
        "keyword_semantic_search": _fmt(search_results["keyword_semantic_search"]),
        "kpi_keyword_search":      _fmt(search_results["kpi_keyword_search"]),
        "kpi_semantic_search":     _fmt(search_results["kpi_semantic_search"]),
        "question_bank_search":    _fmt(search_results["question_bank_search"]),
    }

    fmt_args_sql = {
        "keyword_search_sql": _fmt(sql_keyword_results)
    }

    # ── Call 1: Identification ────────────────────────────────────────────────
    logger.info("Ground truth fixer — Call 1: Identification (LLM)")
    t1 = time.perf_counter()
    resp1 = await (IDENTIFICATION_PROMPT | llm).ainvoke({
        "user_query":  user_query,
        "correct_sql": correct_sql,
        **fmt_args,
        **fmt_args_sql
    })
    identification = _content(resp1)
    logger.info("Ground truth fixer — Call 1 done in %.2fs | chars=%d", time.perf_counter() - t1, len(identification))
    logger.debug("Ground truth fixer — identification preview: %s", identification[:300])

    # ── Call 2: Diagnostic ────────────────────────────────────────────────────
    logger.info("Ground truth fixer — Call 2: Diagnostic (LLM)")
    t2 = time.perf_counter()
    resp2 = await (DIAGNOSTIC_PROMPT | llm).ainvoke({
        "user_query":     user_query,
        "correct_sql":    correct_sql,
        "identification": identification,
        **fmt_args,
        **fmt_args_sql
    })
    diagnostic = _content(resp2)
    logger.info("Ground truth fixer — Call 2 done in %.2fs | chars=%d", time.perf_counter() - t2, len(diagnostic))
    logger.debug("Ground truth fixer — diagnostic preview: %s", diagnostic[:300])

    # ── Call 3: JSON Update Patches ───────────────────────────────────────────
    logger.info("Ground truth fixer — Call 3: JSON updates (LLM)")
    t3 = time.perf_counter()
    resp3 = await (UPDATES_PROMPT | llm).ainvoke({
        "user_query": user_query,
        "correct_sql": correct_sql,
        "diagnostic": diagnostic,
        "identification": identification,
        **fmt_args,
        **fmt_args_sql
    })
    raw_updates = _content(resp3)
    json_updates = _extract_json_array(raw_updates)
    logger.info(
        "Ground truth fixer — Call 3 done in %.2fs | patches=%d | raw_chars=%d",
        time.perf_counter() - t3,
        len(json_updates),
        len(raw_updates),
    )

    if not json_updates and raw_updates.strip() not in ("[]", ""):
        logger.warning("Ground truth fixer: JSON array extraction failed — raw: %s", raw_updates[:300])

    return {
        "user_query":      user_query,
        "correct_sql":     correct_sql,
        "search_results":  search_results,
        "identification":  identification,
        "diagnostic":      diagnostic,
        "json_updates":    json_updates,
        "llm_raw_response": raw_updates,
    }
