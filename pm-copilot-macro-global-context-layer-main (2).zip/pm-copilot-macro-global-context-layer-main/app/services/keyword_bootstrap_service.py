"""
Keyword Bootstrap Service
=========================
Auto-generates base keyword entries from a staging table's columns.
Produces a JSON payload for human review — does NOT insert into the database.
"""

import re
import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text

logger = logging.getLogger(__name__)

# ── Type classification ──

_NUMERIC_TYPES = {
    "integer", "bigint", "smallint", "numeric", "real",
    "double precision", "money", "decimal",
    "int2", "int4", "int8",
}
_DATE_TYPES = {
    "date",
    "timestamp without time zone", "timestamp with time zone",
    "time without time zone", "time with time zone",
    "interval",
}
_BOOLEAN_TYPES = {"boolean"}

# System/audit columns that carry no business meaning
_SKIP_COLUMNS = {"id", "create_date", "create_uid", "write_date", "write_uid"}

_SAFE_ID_RE = re.compile(r'^[a-zA-Z0-9_]+$')


# ── Helpers ──

def _validate_identifier(name: str, label: str = "identifier") -> None:
    """Raise ValueError if name is not a safe SQL identifier."""
    if not _SAFE_ID_RE.match(name):
        raise ValueError(
            f"Unsafe {label} '{name}': only letters, digits, and underscores are allowed."
        )


def _clean_column_name(col: str) -> str:
    """scop_pending -> 'Scop Pending'"""
    return col.replace("_", " ").title()


def _build_synonyms(col: str, extra_values: list | None = None) -> str:
    """
    Build the synonym string for a column.

    Always includes three forms of the column name:
      - Original:      scop_pending
      - Title-cased:   Scop Pending
      - Lowercase:     scop pending

    If extra_values are provided (categorical distinct values), they are
    appended after the column-derived synonyms.
    """
    candidates = [
        col,                         # scop_pending
        _clean_column_name(col),     # Scop Pending
        col.replace("_", " "),       # scop pending
    ]

    seen: set[str] = set()
    unique: list[str] = []
    for part in candidates:
        if part not in seen:
            seen.add(part)
            unique.append(part)

    if extra_values:
        for val in extra_values:
            v = str(val).strip()
            if v and v not in seen:
                seen.add(v)
                unique.append(v)

    return ", ".join(unique)


def _is_categorical_type(data_type: str) -> bool:
    """Return True for text-based column types that may have a bounded set of values."""
    dt = data_type.lower()
    return dt not in _NUMERIC_TYPES and dt not in _DATE_TYPES and dt not in _BOOLEAN_TYPES


async def _fetch_distinct_values(
    db: AsyncSession,
    schema: str,
    table: str,
    column: str,
    ceiling: int = 51,
) -> list:
    """
    Return up to `ceiling` distinct non-null values for a column.
    All identifiers are double-quoted; schema/table/column are validated before this call.
    """
    try:
        sql = text(
            f'SELECT DISTINCT "{column}" '
            f'FROM "{schema}"."{table}" '
            f'WHERE "{column}" IS NOT NULL '
            f'LIMIT :ceiling'
        )
        result = await db.execute(sql, {"ceiling": ceiling})
        return [row[0] for row in result.fetchall()]
    except Exception as exc:
        logger.warning("Could not fetch distinct values for %s.%s: %s", table, column, exc)
        return []


# ── Main entry point ──

async def run_keyword_bootstrap(
    db: AsyncSession,
    table: str,
    table_prefix: str,
    schema: str,
) -> dict:
    """
    Generate base keyword entries for every column in ``schema``.``table``.

    ``table_prefix`` is applied **only** to the ``mapped_tables_columns`` field in the
    JSON output — it is never prepended to the name used for the database lookup.
    This lets callers enter the raw table name as it exists in the DB while still
    producing correctly-prefixed column references in the output.

    Returns a dict with keys: table, schema, total_columns, keywords.
    """
    # Validate user-supplied identifiers before they touch SQL
    _validate_identifier(table, "table")
    if table_prefix and not re.match(r'^[a-zA-Z0-9_]*$', table_prefix):
        raise ValueError(f"Unsafe table_prefix '{table_prefix}'.")
    _validate_identifier(schema, "schema")

    # DB lookup: always use the raw table name exactly as provided
    lookup_table = table

    # Output label: prepend prefix to mapped_tables_columns (idempotent — skip if already present)
    if table_prefix and not table.startswith(table_prefix):
        display_table = f"{table_prefix}{table}"
    else:
        display_table = table

    _validate_identifier(display_table, "display_table")

    # 1. Fetch columns and their data types using the raw lookup name
    rows = (
        await db.execute(
            text("""
                SELECT column_name, data_type
                FROM information_schema.columns
                WHERE table_schema = :schema
                  AND table_name   = :table
                ORDER BY ordinal_position
            """),
            {"schema": schema, "table": lookup_table},
        )
    ).fetchall()

    if not rows:
        raise ValueError(
            f"No columns found for '{schema}.{lookup_table}'. "
            "Verify the table name and schema are correct."
        )

    # 2. Build one keyword entry per column
    keywords = []
    for col_name, data_type in rows:
        if col_name in _SKIP_COLUMNS:
            continue

        extra_values: list = []
        if _is_categorical_type(data_type):
            distinct = await _fetch_distinct_values(db, schema, lookup_table, col_name)
            # Only use distinct values if there are <=50 (categorical) — ceiling query returns 51 if more
            if 0 < len(distinct) <= 50:
                extra_values = [str(v) for v in distinct if v is not None]

        keywords.append({
            "keyword_name": _clean_column_name(col_name),
            "keyword_description": "Empty String : Please fill in the description",
            "mapped_tables_columns": f"{display_table}.{col_name}",
            "logic": "Empty String : Please fill in logic",
            "synonyms": _build_synonyms(col_name, extra_values),
        })

    return {
        "table": display_table,
        "schema": schema,
        "total_columns": len(keywords),
        "keywords": keywords,
    }
