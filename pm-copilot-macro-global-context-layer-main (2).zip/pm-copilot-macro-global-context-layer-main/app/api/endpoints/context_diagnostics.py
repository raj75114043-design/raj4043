"""
Dev Utility Context Diagnostics Endpoints
==========================================
Two LLM-powered diagnostic chains that run 5 searches and use an LLM
to identify retrieval gaps and generate ready-to-use update patches.

  POST /api/v1/dev/context/ground-truth-fixer
      Input: user query + verified correct SQL
      Use when you have the ground-truth SQL and want to know why the
      retrieval system isn't finding the right context for it.

  POST /api/v1/dev/context/qna-helper
      Input: user query + user feedback (what was missing/wrong)
      Use when you have end-user feedback about a bad response and want
      to diagnose which keywords/KPIs/QB entries need to be improved.

Both endpoints stream SSE:
  - ": keep-alive" comments every 30 s (transparent to EventSource.onmessage)
  - "data: <json>"  final event — same JSON shape as before
  - "event: error / data: <json>" on failure
"""

import asyncio
import json
import logging
import time
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from fastapi.security import HTTPBasicCredentials
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.api.endpoints.database import verify_dev_password
from app.schemas.semantic_schemas import (
    GroundTruthContextFixerRequest,
    GroundTruthContextFixerResponse,
    QnADiagnosticHelperRequest,
    QnADiagnosticHelperResponse,
)
from app.chains.ground_truth_context_fixer.ground_truth_context import run_ground_truth_context_fixer
from app.chains.q_n_a_diagnostic_helper.q_n_a_to_context_helper import run_qna_diagnostic_helper

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/dev/context",
    tags=["Dev Utility Context Diagnostics"],
)


@router.post("/ground-truth-fixer")
async def ground_truth_context_fixer(
    request: GroundTruthContextFixerRequest,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
):
    """
    Ground Truth Context Fixer

    Runs 5 diagnostic searches against the user query (keyword fuzzy match,
    keyword semantic search, KPI fuzzy match, KPI semantic search, question
    bank semantic search), then calls the LLM to produce:

    - **identification**: which keywords/KPIs/QB entries from the search results
      are relevant to the query and correct SQL
    - **diagnostic**: what is impacting retrieval quality and what specific
      field-level changes would improve it
    - **json_updates**: a JSON array of update patches ready for the
      `/keywords`, `/kpis`, and `/question-bank` Update endpoints

    Streams SSE: keep-alive comments during processing, then a single
    `data:` event containing the JSON result.

    Requires dev password (HTTP Basic Auth).
    """
    logger.info(
        "Ground truth fixer — request received | query=%r | sql_preview=%r | top_k=%d",
        request.user_query[:120],
        request.correct_sql[:120],
        request.top_k,
    )
    t0 = time.perf_counter()

    async def _stream():
        task = asyncio.create_task(run_ground_truth_context_fixer(
            db=db,
            user_query=request.user_query,
            correct_sql=request.correct_sql,
            top_k=request.top_k,
        ))
        try:
            last_ping = time.time()
            while not task.done():
                if time.time() - last_ping > 30:
                    yield ": keep-alive\n\n"
                    last_ping = time.time()
                    logger.debug("Keep-alive ping sent during ground truth fixer")
                await asyncio.sleep(1)

            result = task.result()
            elapsed = time.perf_counter() - t0
            logger.info(
                "Ground truth fixer — completed in %.2fs | patches=%d",
                elapsed,
                len(result.get("json_updates", [])),
            )
            response = GroundTruthContextFixerResponse(**result)
            yield f"data: {response.model_dump_json()}\n\n"
        except Exception as e:
            task.cancel()
            logger.error(
                "Ground truth context fixer failed after %.2fs: %s",
                time.perf_counter() - t0,
                e,
                exc_info=True,
            )
            yield f"event: error\ndata: {json.dumps({'detail': str(e)})}\n\n"

    return StreamingResponse(_stream(), media_type="text/event-stream")


@router.post("/qna-helper")
async def qna_diagnostic_helper(
    request: QnADiagnosticHelperRequest,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
):
    """
    Q&A Diagnostic Helper

    Runs 5 diagnostic searches against the user query (keyword fuzzy match,
    keyword semantic search, KPI fuzzy match, KPI semantic search, question
    bank semantic search), then calls the LLM to produce:

    - **identification**: which keywords/KPIs/QB entries from the search results
      are relevant to the query and user feedback
    - **diagnostic**: what gaps exist in the knowledge base based on the feedback
      and what specific changes would resolve them
    - **json_updates**: a JSON array of update patches ready for the
      `/keywords`, `/kpis`, and `/question-bank` Update endpoints

    Streams SSE: keep-alive comments during processing, then a single
    `data:` event containing the JSON result.

    Requires dev password (HTTP Basic Auth).
    """
    logger.info(
        "Q&A helper — request received | query=%r | feedback_preview=%r | top_k=%d",
        request.user_query[:120],
        request.user_feedback[:120],
        request.top_k,
    )
    t0 = time.perf_counter()

    async def _stream():
        task = asyncio.create_task(run_qna_diagnostic_helper(
            db=db,
            user_query=request.user_query,
            user_feedback=request.user_feedback,
            top_k=request.top_k,
        ))
        try:
            last_ping = time.time()
            while not task.done():
                if time.time() - last_ping > 30:
                    yield ": keep-alive\n\n"
                    last_ping = time.time()
                    logger.debug("Keep-alive ping sent during Q&A helper")
                await asyncio.sleep(1)

            result = task.result()
            elapsed = time.perf_counter() - t0
            logger.info(
                "Q&A helper — completed in %.2fs | patches=%d",
                elapsed,
                len(result.get("json_updates", [])),
            )
            response = QnADiagnosticHelperResponse(**result)
            yield f"data: {response.model_dump_json()}\n\n"
        except Exception as e:
            task.cancel()
            logger.error(
                "Q&A diagnostic helper failed after %.2fs: %s",
                time.perf_counter() - t0,
                e,
                exc_info=True,
            )
            yield f"event: error\ndata: {json.dumps({'detail': str(e)})}\n\n"

    return StreamingResponse(_stream(), media_type="text/event-stream")
