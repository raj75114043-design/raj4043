"""
Developer Utility Endpoints
============================
Thin route definitions that delegate to service modules:
  1. GET  /schema-compare       – Compare staging schema against KPI/QB/Keywords
  2. GET  /table-schema-builder – Build table-centric JSON, store in PostgreSQL
  3. POST /schema-world-view    – Produce focused SQL schema world view
"""

import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.security import HTTPBasicCredentials
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.core.config import settings
from app.schemas.semantic_schemas import (
    SchemaCompareResponse,
    TableSchemaBuilderResponse,
    SchemaWorldViewRequest,
    SchemaWorldViewResponse,
    KeywordBootstrapResponse,
)
from app.api.endpoints.database import verify_dev_password
from app.services.schema_compare_service import run_schema_compare
from app.services.table_schema_builder_service import run_table_schema_builder
from app.services.schema_world_view_service import run_schema_world_view
from app.services.keyword_bootstrap_service import run_keyword_bootstrap

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/dev", tags=["Developer Utilities [Dev Only]"])


@router.get("/schema-compare", response_model=SchemaCompareResponse)
async def schema_compare(
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
):
    """
    Compare the staging schema (db_schema_compare) against KPI, Question Bank,
    and Keywords data stored in the semantic tables. Returns two markdown reports:
    a global summary and a detailed per-entry report.
    """
    try:
        logger.info("Starting schema comparison...")
        result = await run_schema_compare(db)
        return SchemaCompareResponse(success=True, **result)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Schema comparison failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Schema comparison failed: {str(e)}")


@router.get("/table-schema-builder", response_model=TableSchemaBuilderResponse)
async def table_schema_builder(
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
    include_profiles: bool = Query(True, description="Include per-column data profiles (data_type, distinct count, null %, min/max/avg). Uses one query per table — fast on any schema size."),
):
    """
    Build comprehensive table-centric JSON mapping KPIs, Questions, and Keywords
    to staging tables and columns. Stores the result in PostgreSQL and returns it.

    Column profiling (data_type, distinct count, null %, min/max/avg) is enabled by
    default and runs one query per table — safe to leave on for any schema size.
    """
    try:
        logger.info("Starting table schema builder (include_profiles=%s, profiles default=True)...", include_profiles)
        result = await run_table_schema_builder(db, include_profiles=include_profiles)
        return TableSchemaBuilderResponse(
            success=True,
            message=f"Table schema map built and stored (id={result['stored_id']}) in {settings.db_schema}.table_schema_map",
            table_schema_map=result["schema_map"],
            stored_id=result["stored_id"],
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Table schema builder failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Table schema builder failed: {str(e)}")


@router.post("/schema-world-view", response_model=SchemaWorldViewResponse)
async def schema_world_view(
    request: SchemaWorldViewRequest,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
):
    """
    Consume the stored table schema map from PostgreSQL and produce a focused
    SQL schema world view for a text-to-SQL system. Takes lists of KPI names,
    question texts, and keyword names as input.
    """
    try:
        result = await run_schema_world_view(db, request)
        return SchemaWorldViewResponse(success=True, **result)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Schema world view failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Schema world view failed: {str(e)}")


@router.get("/keyword-bootstrap", response_model=KeywordBootstrapResponse)
async def keyword_bootstrap(
    table: str = Query(..., description="Table name as stored in the DB, without the prefix (e.g. ndpd_mbt_tmobile_macro_combined)"),
    table_prefix: str = Query("stg_", description="Prefix prepended to the table name for both the DB query and the mapped_tables_columns output. Pass an empty string to disable."),
    schema: str = Query(None, description="Staging schema to query. Defaults to the configured staging schema (pwc_macro_staging_schema)."),
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
):
    """
    Scan every column in the given staging table and produce a base keyword
    entry for each one.  The result is returned as a JSON list ready for human
    review — nothing is written to the database.

    Each entry contains:
    - **keyword_name** – human-readable column name (scop_pending → Scop Pending)
    - **keyword_description** – placeholder to fill in
    - **mapped_tables_columns** – `{prefix}{table}.{column}` (e.g. stg_ndpd_mbt_tmobile_macro_combined.scop_pending)
    - **logic** – placeholder to fill in
    - **synonyms** – column name variants; for categorical text columns with ≤ 50 distinct values the actual values are also included
    """
    try:
        resolved_schema = schema or settings.db_schema_compare
        result = await run_keyword_bootstrap(
            db=db,
            table=table,
            table_prefix=table_prefix,
            schema=resolved_schema,
        )
        return KeywordBootstrapResponse(success=True, schema_used=resolved_schema, **result)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Keyword bootstrap failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Keyword bootstrap failed: {str(e)}")
