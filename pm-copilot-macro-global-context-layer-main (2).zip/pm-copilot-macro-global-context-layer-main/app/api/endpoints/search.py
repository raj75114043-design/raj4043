"""
Global search endpoints for PM Copilot Global Context Layer
Schema: pwc_semantic_information_schema
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import time
from dataclasses import dataclass
from typing import List, Dict, Any, Set, Optional
from difflib import SequenceMatcher
from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, or_, func
from app.db.database import get_db
from app.models.semantic_models import (
    SemanticKPI,
    SemanticKeyword,
    SemanticQuestionBank,
    SemanticRCA,
    SemanticSimulation,
)
from app.schemas.semantic_schemas import (
    KeywordDetectionResponse,
    DetectedKeywordDetail,
    KPIDetectionResponse,
    DetectedKPIDetail,
)

router = APIRouter(prefix="/search", tags=["Search & Query"])

# How long to keep the in-memory keyword/KPI cache before refreshing from DB
CACHE_TTL_SECONDS = 300  # 5 minutes

# Common English stopwords to filter out during fuzzy matching
STOPWORDS: Set[str] = {
    "a", "an", "and", "are", "as", "at", "be", "but", "by", "for", "if", "in", "is", "it",
    "no", "not", "of", "on", "or", "such", "the", "to", "with", "i", "me", "my", "we", "he", "she", "it"
}


def _filter_stopwords(words: List[str]) -> List[str]:
    """Remove stopwords from a list of words, keeping only meaningful tokens."""
    return [w for w in words if w.lower() not in STOPWORDS and len(w) > 0]


def _word_segments(word: str) -> List[str]:
    """Return the word itself plus its hyphen-split segments (deduplicated, non-empty)."""
    segments = word.split('-')
    return list({word} | {s for s in segments if s})


def _fuzzy_match_in_text(text: str, keyword: str, threshold: float = 0.85) -> bool:
    """
    Multi-strategy fuzzy match: checks if keyword appears in text.

    Strategy 1 — Exact word match: keyword words must match complete text words
                 (or hyphen segments), not substring within a word.
                 e.g. "OA" will NOT match "AHLO-A"; "AHLO-A" WILL match "AHLO-A".
    Strategy 2 — Token coverage (stopword-filtered): ≥75% of meaningful keyword
                 tokens each fuzzy-match at least one text token at `threshold`.
                 Handles word-order variations, typos.
    Strategy 3 — Sliding phrase window: ordered n-gram comparison at `threshold`
                 on raw (non-filtered) words to preserve phrase ordering.

    Delegates to _fuzzy_match_precomputed.  Hot paths should pre-compute the
    text components once and call _fuzzy_match_precomputed directly.
    """
    text_lower = text.lower()
    text_words = text_lower.split()
    text_words_filtered = _filter_stopwords(text_words)
    text_word_segments = [_word_segments(w) for w in text_words_filtered]
    return _fuzzy_match_precomputed(text_lower, text_words, text_words_filtered, text_word_segments, keyword, threshold)


# ---------------------------------------------------------------------------
# In-memory cache infrastructure
# ---------------------------------------------------------------------------

@dataclass
class _CachedKeyword:
    """Keyword row stored in memory with pre-processed term data."""
    keyword_id: int
    keyword_name: Optional[str]
    keyword_description: Optional[str]
    mapped_tables_columns: Optional[str]
    logic: Optional[str]
    synonyms: Optional[str]
    created_at: Any
    updated_at: Any
    terms: List[str]           # [keyword_name, synonym1, synonym2, …]
    term_tokens: List[Set[str]]  # stopword-filtered token set per term (parallel to terms)


@dataclass
class _CachedKPI:
    """KPI row stored in memory with pre-processed term data."""
    kpi_id: int
    kpi_name: Optional[str]
    description: Optional[str]
    formula: Optional[str]
    mapped_tables_columns: Optional[str]
    logic: Optional[str]
    root_cause_positive: Optional[str]
    root_cause_negative: Optional[str]
    created_at: Any
    updated_at: Any
    terms: List[str]
    term_tokens: List[Set[str]]


class _KeywordStore:
    """
    In-memory store for all SemanticKeyword rows.

    Loaded once on first request; refreshed automatically after CACHE_TTL_SECONDS.
    Maintains two indexes for fast candidate pre-filtering:
      - token_index  : exact stopword-filtered token  → set of entry indices
      - prefix_index : first-3-char prefix of each token → set of entry indices
                       (catches single-word typos such as "dronne" → "drone")
    """

    def __init__(self) -> None:
        self.entries: List[_CachedKeyword] = []
        self.token_index: Dict[str, Set[int]] = {}
        self.prefix_index: Dict[str, Set[int]] = {}
        self._loaded_at: float = 0.0

    @property
    def is_stale(self) -> bool:
        return (time.monotonic() - self._loaded_at) > CACHE_TTL_SECONDS

    def build_from(self, keywords: list) -> None:
        entries: List[_CachedKeyword] = []
        token_index: Dict[str, Set[int]] = {}
        prefix_index: Dict[str, Set[int]] = {}

        for i, kw in enumerate(keywords):
            terms: List[str] = []
            if kw.keyword_name:
                terms.append(kw.keyword_name)
            if kw.synonyms:
                for syn in kw.synonyms.split(","):
                    s = syn.strip()
                    if s:
                        terms.append(s)

            term_tokens: List[Set[str]] = []
            for term in terms:
                tokens = set(_filter_stopwords(term.lower().split()))
                term_tokens.append(tokens)
                for tok in tokens:
                    token_index.setdefault(tok, set()).add(i)
                    if len(tok) >= 3:
                        prefix_index.setdefault(tok[:3], set()).add(i)

            entries.append(_CachedKeyword(
                keyword_id=kw.keyword_id,
                keyword_name=kw.keyword_name,
                keyword_description=kw.keyword_description,
                mapped_tables_columns=kw.mapped_tables_columns,
                logic=kw.logic,
                synonyms=kw.synonyms,
                created_at=kw.created_at,
                updated_at=kw.updated_at,
                terms=terms,
                term_tokens=term_tokens,
            ))

        self.entries = entries
        self.token_index = token_index
        self.prefix_index = prefix_index
        self._loaded_at = time.monotonic()


class _KPIStore:
    """In-memory store for all SemanticKPI rows — same caching strategy as _KeywordStore."""

    def __init__(self) -> None:
        self.entries: List[_CachedKPI] = []
        self.token_index: Dict[str, Set[int]] = {}
        self.prefix_index: Dict[str, Set[int]] = {}
        self._loaded_at: float = 0.0

    @property
    def is_stale(self) -> bool:
        return (time.monotonic() - self._loaded_at) > CACHE_TTL_SECONDS

    def build_from(self, kpis: list) -> None:
        entries: List[_CachedKPI] = []
        token_index: Dict[str, Set[int]] = {}
        prefix_index: Dict[str, Set[int]] = {}

        for i, kpi in enumerate(kpis):
            terms: List[str] = []
            if kpi.kpi_name:
                terms.append(kpi.kpi_name)

            term_tokens: List[Set[str]] = []
            for term in terms:
                tokens = set(_filter_stopwords(term.lower().split()))
                term_tokens.append(tokens)
                for tok in tokens:
                    token_index.setdefault(tok, set()).add(i)
                    if len(tok) >= 3:
                        prefix_index.setdefault(tok[:3], set()).add(i)

            entries.append(_CachedKPI(
                kpi_id=kpi.kpi_id,
                kpi_name=kpi.kpi_name,
                description=kpi.description,
                formula=kpi.formula,
                mapped_tables_columns=kpi.mapped_tables_columns,
                logic=kpi.logic,
                root_cause_positive=kpi.root_cause_positive,
                root_cause_negative=kpi.root_cause_negative,
                created_at=kpi.created_at,
                updated_at=kpi.updated_at,
                terms=terms,
                term_tokens=term_tokens,
            ))

        self.entries = entries
        self.token_index = token_index
        self.prefix_index = prefix_index
        self._loaded_at = time.monotonic()


# Module-level singletons — shared across all requests in the same worker process
_keyword_store = _KeywordStore()
_kpi_store = _KPIStore()


# ---------------------------------------------------------------------------
# Optimised fuzzy match — accepts pre-computed sentence components
# ---------------------------------------------------------------------------

def _fuzzy_match_precomputed(
    text_lower: str,
    text_words: List[str],
    text_words_filtered: List[str],
    text_word_segments: List[List[str]],
    keyword: str,
    threshold: float = 0.85,
) -> bool:
    """
    Identical logic to _fuzzy_match_in_text but avoids re-processing the
    sentence on every call.  Pass the sentence components computed once by
    the endpoint and reuse them across all keyword comparisons.

    text_word_segments must be [_word_segments(w) for w in text_words_filtered],
    pre-computed once per request to avoid redundant work inside the inner loop.
    """
    keyword_lower = keyword.lower()
    keyword_words = keyword_lower.split()

    if not keyword_words:
        return False

    # Strategy 1: exact phrase match at word boundaries, respecting hyphens
    if len(keyword_words) == 1:
        kw = keyword_words[0]
        for txt_word in text_words:
            if kw == txt_word or kw in txt_word.split('-'):
                return True
    else:
        for i in range(len(text_words) - len(keyword_words) + 1):
            if all(
                kw_w == txt_w or kw_w in txt_w.split('-')
                for kw_w, txt_w in zip(keyword_words, text_words[i:i + len(keyword_words)])
            ):
                return True

    keyword_words_filtered = _filter_stopwords(keyword_words)

    if not keyword_words_filtered or not text_words_filtered:
        return False

    # Strategy 2: token coverage — fuzzy match each keyword token against text tokens.
    # Optimisations applied here:
    #   a) text_word_segments is pre-computed outside this function — no _word_segments
    #      calls on the same sentence words across repeated keyword comparisons.
    #   b) Length-difference pruning: if two strings are so different in length that
    #      SequenceMatcher ratio can never reach `threshold`, skip without constructing
    #      a SequenceMatcher object (2×min/(a+b) < threshold → impossible).
    #   c) Early exit: after each keyword token, if the max achievable coverage
    #      (matched so far + all remaining tokens) falls below 75%, bail out early.
    n_kw_tokens = len(keyword_words_filtered)
    matched_kw_tokens = 0

    for token_idx, kw_word in enumerate(keyword_words_filtered):
        kw_segments = _word_segments(kw_word)
        found = False

        for kw_seg in kw_segments:
            kw_len = len(kw_seg)
            for txt_segs in text_word_segments:
                for txt_seg in txt_segs:
                    # Fast path: exact match avoids SequenceMatcher entirely
                    if kw_seg == txt_seg:
                        found = True
                        break
                    # Length-difference pruning (avoids constructing SequenceMatcher)
                    txt_len = len(txt_seg)
                    if 2 * min(kw_len, txt_len) < threshold * (kw_len + txt_len):
                        continue
                    if SequenceMatcher(None, kw_seg, txt_seg).ratio() >= threshold:
                        found = True
                        break
                if found:
                    break
            if found:
                break

        if found:
            matched_kw_tokens += 1

        # Early exit: if even perfect matches on all remaining tokens can't reach 75%
        remaining = n_kw_tokens - token_idx - 1
        if (matched_kw_tokens + remaining) / n_kw_tokens < 0.75:
            return False

    if matched_kw_tokens / n_kw_tokens >= 0.75:
        return True

    # Strategy 3: sliding phrase window on raw words (preserves phrase ordering)
    if len(keyword_words) > 1 and len(text_words) >= len(keyword_words):
        for i in range(len(text_words) - len(keyword_words) + 1):
            phrase = " ".join(text_words[i:i + len(keyword_words)])
            if SequenceMatcher(None, keyword_lower, phrase).ratio() >= threshold:
                return True

    return False


@router.get("/keywords/detect", response_model=KeywordDetectionResponse)
async def detect_keywords_in_sentence(
    sentence: str = Query(..., min_length=1, description="Input sentence to detect keywords from"),
    db: AsyncSession = Depends(get_db)
) -> KeywordDetectionResponse:
    """
    Detect keywords and synonyms from any input sentence using fuzzy matching.

    Scans all stored keywords and their synonyms against the input sentence.
    Handles spacing issues and minor spelling mistakes with 0.85 similarity threshold.
    Returns full keyword details for every match found, along with which
    terms (keyword name or synonym) were detected.

    Example: "How many sites completed QMC and drone survey?"
    → detects "QMC" and "Drone Survey" keywords with full details.

    Performance notes:
      - Keywords are cached in memory (refreshed every 5 min) — no DB call on cache hit.
      - Sentence is tokenised once and reused across all comparisons.
      - Token + prefix index pre-filters candidates before running fuzzy matching.
    """
    # --- 1. Refresh cache only when stale (single DB call, then silent for 5 min) ---
    if _keyword_store.is_stale:
        result = await db.execute(select(SemanticKeyword))
        _keyword_store.build_from(result.scalars().all())

    # --- 2. Pre-compute sentence components once for all keyword comparisons ---
    sentence_lower = sentence.lower()
    sentence_words = sentence_lower.split()
    sentence_words_filtered = _filter_stopwords(sentence_words)
    # Pre-compute hyphen segments for each filtered word so Strategy 2 doesn't
    # recompute them inside the inner loop for every candidate keyword
    sentence_word_segments = [_word_segments(w) for w in sentence_words_filtered]

    # --- 3. Build candidate set via token + prefix index (avoids scanning all 1000+) ---
    # Exact token lookup — catches correctly-spelled matches
    candidate_indices: Set[int] = set()
    for tok in sentence_words_filtered:
        candidate_indices.update(_keyword_store.token_index.get(tok, set()))

    # Also index raw (non-stopword-filtered) sentence words so single-word keywords
    # that happen to be stopwords (e.g. short acronyms) are not silently excluded
    for tok in sentence_words:
        candidate_indices.update(_keyword_store.token_index.get(tok, set()))

    # Prefix lookup (first 3 chars) — catches single-word typos, e.g. "dronne" → "drone"
    for tok in sentence_words_filtered:
        if len(tok) >= 3:
            candidate_indices.update(_keyword_store.prefix_index.get(tok[:3], set()))

    # --- 4. Run fuzzy matching only on pre-filtered candidates ---
    detected: List[DetectedKeywordDetail] = []

    for idx in candidate_indices:
        entry = _keyword_store.entries[idx]
        matched_terms: List[str] = []

        for j, term in enumerate(entry.terms):
            if _fuzzy_match_precomputed(sentence_lower, sentence_words, sentence_words_filtered, sentence_word_segments, term):
                # terms[0] is keyword_name; synonyms must not duplicate it
                if j == 0 or term.lower() != (entry.keyword_name or "").lower():
                    matched_terms.append(term)

        if matched_terms:
            detected.append(DetectedKeywordDetail(
                keyword_id=entry.keyword_id,
                keyword_name=entry.keyword_name,
                keyword_description=entry.keyword_description,
                mapped_tables_columns=entry.mapped_tables_columns,
                logic=entry.logic,
                synonyms=entry.synonyms,
                matched_terms=matched_terms,
                created_at=entry.created_at,
                updated_at=entry.updated_at,
            ))

    return KeywordDetectionResponse(
        input_sentence=sentence,
        detected_count=len(detected),
        detected_keywords=detected,
    )


@router.get("/kpis/detect", response_model=KPIDetectionResponse)
async def detect_kpis_in_sentence(
    sentence: str = Query(..., min_length=1, description="Input sentence to detect KPIs from"),
    db: AsyncSession = Depends(get_db)
) -> KPIDetectionResponse:
    """
    Detect KPIs from any input sentence using fuzzy matching.

    Scans all stored KPIs against the input sentence.
    Handles spacing issues and minor spelling mistakes with 0.9 similarity threshold.
    Returns full KPI details for every match found, along with which
    terms (KPI name) were detected.

    Example: "What is the impact on our KPI performance and key metric trends?"
    → detects KPIs like "KPI performance" and "key metric" with full details.

    Performance notes:
      - KPIs are cached in memory (refreshed every 5 min) — no DB call on cache hit.
      - Sentence is tokenised once and reused across all comparisons.
      - Token + prefix index pre-filters candidates before running fuzzy matching.
    """
    # --- 1. Refresh cache only when stale ---
    if _kpi_store.is_stale:
        result = await db.execute(select(SemanticKPI))
        _kpi_store.build_from(result.scalars().all())

    # --- 2. Pre-compute sentence components once ---
    sentence_lower = sentence.lower()
    sentence_words = sentence_lower.split()
    sentence_words_filtered = _filter_stopwords(sentence_words)
    sentence_word_segments = [_word_segments(w) for w in sentence_words_filtered]

    # --- 3. Build candidate set via token + prefix index ---
    candidate_indices: Set[int] = set()
    for tok in sentence_words_filtered:
        candidate_indices.update(_kpi_store.token_index.get(tok, set()))
    for tok in sentence_words:
        candidate_indices.update(_kpi_store.token_index.get(tok, set()))
    for tok in sentence_words_filtered:
        if len(tok) >= 3:
            candidate_indices.update(_kpi_store.prefix_index.get(tok[:3], set()))

    # --- 4. Run fuzzy matching only on pre-filtered candidates ---
    detected: List[DetectedKPIDetail] = []

    for idx in candidate_indices:
        entry = _kpi_store.entries[idx]
        matched_terms: List[str] = []

        for term in entry.terms:
            if _fuzzy_match_precomputed(sentence_lower, sentence_words, sentence_words_filtered, sentence_word_segments, term):
                matched_terms.append(term)

        if matched_terms:
            detected.append(DetectedKPIDetail(
                kpi_id=entry.kpi_id,
                kpi_name=entry.kpi_name,
                description=entry.description,
                formula=entry.formula,
                mapped_tables_columns=entry.mapped_tables_columns,
                logic=entry.logic,
                root_cause_positive=entry.root_cause_positive,
                root_cause_negative=entry.root_cause_negative,
                matched_terms=matched_terms,
                created_at=entry.created_at,
                updated_at=entry.updated_at,
            ))

    return KPIDetectionResponse(
        input_sentence=sentence,
        detected_count=len(detected),
        detected_kpis=detected,
    )


@router.get("/global")
async def global_search(
    query: str = Query(..., min_length=1, description="Search query"),
    limit: int = Query(50, ge=1, le=500, description="Maximum results per table"),
    db: AsyncSession = Depends(get_db)
) -> Dict[str, Any]:
    """
    Global search across all tables

    Searches for the query text in relevant fields across KPI, Keywords,
    Question Bank, RCA, and Simulation tables.

    Args:
        query: Search query string
        limit: Maximum results per table
        db: Database session

    Returns:
        Dictionary with results from all tables
    """
    search_pattern = f"%{query}%"
    results: Dict[str, Any] = {}

    # Search KPIs
    kpi_result = await db.execute(
        select(SemanticKPI).where(
            or_(
                SemanticKPI.kpi_name.ilike(search_pattern),
                SemanticKPI.description.ilike(search_pattern),
                SemanticKPI.formula.ilike(search_pattern)
            )
        ).limit(limit)
    )
    kpis = kpi_result.scalars().all()
    results["kpis"] = [
        {
            "kpi_id": k.kpi_id,
            "kpi_name": k.kpi_name,
            "description": k.description,
            "formula": k.formula
        }
        for k in kpis
    ]

    # Search Keywords
    keyword_result = await db.execute(
        select(SemanticKeyword).where(
            or_(
                SemanticKeyword.keyword_name.ilike(search_pattern),
                SemanticKeyword.keyword_description.ilike(search_pattern),
                SemanticKeyword.synonyms.ilike(search_pattern)
            )
        ).limit(limit)
    )
    keywords = keyword_result.scalars().all()
    results["keywords"] = [
        {
            "keyword_id": k.keyword_id,
            "keyword_name": k.keyword_name,
            "keyword_description": k.keyword_description,
            "synonyms": k.synonyms
        }
        for k in keywords
    ]

    # Search Question Bank
    question_result = await db.execute(
        select(SemanticQuestionBank).where(
            or_(
                SemanticQuestionBank.question.ilike(search_pattern),
                SemanticQuestionBank.sql.ilike(search_pattern)
            )
        ).limit(limit)
    )
    questions = question_result.scalars().all()
    results["questions"] = [
        {
            "question_id": q.question_id,
            "question": q.question,
            "sql": q.sql
        }
        for q in questions
    ]

    # Search RCA
    rca_result = await db.execute(
        select(SemanticRCA).where(
            or_(
                SemanticRCA.rca_question.ilike(search_pattern),
                SemanticRCA.recommendation_area.ilike(search_pattern)
            )
        ).limit(limit)
    )
    rca_items = rca_result.scalars().all()
    results["rca"] = [
        {
            "problem_id": r.problem_id,
            "rca_question": r.rca_question,
            "type_of_rca_question": r.type_of_rca_question.value,
            "recommendation_area": r.recommendation_area
        }
        for r in rca_items
    ]

    # Search Simulations
    simulation_result = await db.execute(
        select(SemanticSimulation).where(
            or_(
                SemanticSimulation.scenario.ilike(search_pattern),
                SemanticSimulation.simulation_methodology.ilike(search_pattern)
            )
        ).limit(limit)
    )
    simulations = simulation_result.scalars().all()
    results["simulations"] = [
        {
            "scenario_id": s.scenario_id,
            "scenario": s.scenario,
            "simulation_methodology": s.simulation_methodology
        }
        for s in simulations
    ]

    # Add summary
    results["summary"] = {
        "total_results": sum(len(v) for v in results.values() if isinstance(v, list)),
        "kpi_count": len(results["kpis"]),
        "keyword_count": len(results["keywords"]),
        "question_count": len(results["questions"]),
        "rca_count": len(results["rca"]),
        "simulation_count": len(results["simulations"])
    }

    return results


@router.get("/table/{table_name}")
async def search_by_table(
    table_name: str,
    query: str = Query(..., min_length=1, description="Search query"),
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: AsyncSession = Depends(get_db)
) -> Dict[str, Any]:
    """
    Search within a specific table

    Args:
        table_name: Name of table (kpi, keywords, question_bank, rca, simulation)
        query: Search query string
        skip: Number of records to skip
        limit: Maximum number of records to return
        db: Database session

    Returns:
        Search results from specified table
    """
    search_pattern = f"%{query}%"

    if table_name == "kpi":
        result = await db.execute(
            select(SemanticKPI).where(
                or_(
                    SemanticKPI.kpi_name.ilike(search_pattern),
                    SemanticKPI.description.ilike(search_pattern),
                    SemanticKPI.formula.ilike(search_pattern),
                    SemanticKPI.logic.ilike(search_pattern)
                )
            ).offset(skip).limit(limit)
        )
        items = result.scalars().all()
        return {
            "table": "kpi",
            "results": [
                {
                    "kpi_id": k.kpi_id,
                    "kpi_name": k.kpi_name,
                    "description": k.description,
                    "formula": k.formula
                }
                for k in items
            ],
            "count": len(items)
        }

    elif table_name == "keywords":
        result = await db.execute(
            select(SemanticKeyword).where(
                or_(
                    SemanticKeyword.keyword_name.ilike(search_pattern),
                    SemanticKeyword.keyword_description.ilike(search_pattern),
                    SemanticKeyword.synonyms.ilike(search_pattern),
                    SemanticKeyword.logic.ilike(search_pattern)
                )
            ).offset(skip).limit(limit)
        )
        items = result.scalars().all()
        return {
            "table": "keywords",
            "results": [
                {
                    "keyword_id": k.keyword_id,
                    "keyword_name": k.keyword_name,
                    "keyword_description": k.keyword_description,
                    "synonyms": k.synonyms
                }
                for k in items
            ],
            "count": len(items)
        }

    elif table_name == "question_bank":
        result = await db.execute(
            select(SemanticQuestionBank).where(
                or_(
                    SemanticQuestionBank.question.ilike(search_pattern),
                    SemanticQuestionBank.sql.ilike(search_pattern)
                )
            ).offset(skip).limit(limit)
        )
        items = result.scalars().all()
        return {
            "table": "question_bank",
            "results": [
                {
                    "question_id": q.question_id,
                    "question": q.question,
                    "sql": q.sql
                }
                for q in items
            ],
            "count": len(items)
        }

    elif table_name == "rca":
        result = await db.execute(
            select(SemanticRCA).where(
                or_(
                    SemanticRCA.rca_question.ilike(search_pattern),
                    SemanticRCA.recommendation_area.ilike(search_pattern),
                    SemanticRCA.relevant_kpis.ilike(search_pattern)
                )
            ).offset(skip).limit(limit)
        )
        items = result.scalars().all()
        return {
            "table": "rca",
            "results": [
                {
                    "problem_id": r.problem_id,
                    "rca_question": r.rca_question,
                    "type_of_rca_question": r.type_of_rca_question.value,
                    "root_causes": r.root_causes
                }
                for r in items
            ],
            "count": len(items)
        }

    elif table_name == "simulation":
        result = await db.execute(
            select(SemanticSimulation).where(
                or_(
                    SemanticSimulation.scenario.ilike(search_pattern),
                    SemanticSimulation.simulation_methodology.ilike(search_pattern)
                )
            ).offset(skip).limit(limit)
        )
        items = result.scalars().all()
        return {
            "table": "simulation",
            "results": [
                {
                    "scenario_id": s.scenario_id,
                    "scenario": s.scenario,
                    "simulation_methodology": s.simulation_methodology
                }
                for s in items
            ],
            "count": len(items)
        }

    else:
        return {
            "error": f"Invalid table name: {table_name}",
            "valid_tables": ["kpi", "keywords", "question_bank", "rca", "simulation"]
        }


@router.get("/statistics")
async def get_statistics(
    db: AsyncSession = Depends(get_db)
) -> Dict[str, Any]:
    """
    Get overall statistics for all tables

    Args:
        db: Database session

    Returns:
        Statistics for all tables
    """
    # Get counts for all tables
    kpi_result = await db.execute(select(func.count()).select_from(SemanticKPI))
    keyword_result = await db.execute(select(func.count()).select_from(SemanticKeyword))
    question_result = await db.execute(select(func.count()).select_from(SemanticQuestionBank))
    rca_result = await db.execute(select(func.count()).select_from(SemanticRCA))
    simulation_result = await db.execute(select(func.count()).select_from(SemanticSimulation))

    # Store scalar values - .scalar() consumes the result, so only call it once
    kpi_count = kpi_result.scalar() or 0
    keyword_count = keyword_result.scalar() or 0
    question_count = question_result.scalar() or 0
    rca_count = rca_result.scalar() or 0
    simulation_count = simulation_result.scalar() or 0

    # Get RCA type breakdown
    rca_type_result = await db.execute(
        select(SemanticRCA.type_of_rca_question, func.count()).group_by(SemanticRCA.type_of_rca_question)
    )
    rca_types = {str(rca_type): count for rca_type, count in rca_type_result.all()}

    return {
        "total_kpis": kpi_count,
        "total_keywords": keyword_count,
        "total_questions": question_count,
        "total_rca": rca_count,
        "total_simulations": simulation_count,
        "rca_by_type": rca_types,
        "total_records": kpi_count + keyword_count + question_count + rca_count + simulation_count
    }
