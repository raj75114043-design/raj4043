"""
Async Neo4j connection manager
Author: Advait Shah, PwC India
Client: Nokia
"""

import logging
from neo4j import AsyncGraphDatabase
from app.core.config import settings

logger = logging.getLogger(__name__)

# Global async driver instance
neo4j_driver = None


# ==================== INIT / SHUTDOWN ====================

async def init_neo4j() -> None:
    """
    Initialize the async Neo4j driver.
    Called during FastAPI startup lifespan.
    """

    global neo4j_driver

    logger.info("Initializing Async Neo4j driver...")

    try:
        neo4j_driver = AsyncGraphDatabase.driver(
            settings.neo4j_uri,
            auth=settings.neo4j_auth,
        )

        # Test connection (official async pattern)
        async with neo4j_driver.session() as session:
            await session.run("RETURN 1")

        logger.info("Async Neo4j connection established successfully")

    except Exception as e:
        logger.error(f"Async Neo4j connection failed: {e}")
        raise


async def close_neo4j() -> None:
    """
    Close driver on application shutdown.
    """
    global neo4j_driver

    if neo4j_driver:
        logger.info("Closing Async Neo4j driver...")
        await neo4j_driver.close()
        logger.info("Async Neo4j driver closed")


# ==================== DRIVER ACCESS ====================

def get_neo4j_driver():
    """
    Return the initialized async Neo4j driver.
    """
    if neo4j_driver is None:
        raise RuntimeError("Neo4j driver not initialized")
    return neo4j_driver


# ==================== HEALTH CHECK ====================

async def health_check_neo4j() -> bool:
    """
    Check if Neo4j connection is alive.
    """
    try:
        driver = get_neo4j_driver()
        async with driver.session() as session:
            await session.run("RETURN 1")
        return True
    except Exception as e:
        logger.warning(f"Neo4j health check failed: {e}")
        return False
    

# ==================== INIT / SHUTDOWN (SCHEMA KG) ====================

async def init_neo4j_db() -> None:
    """
    Initialize the async Neo4j driver for the Schema KG (Neo4j_DB).
    """
    global neo4j_db_driver
    logger.info("Initializing Async Neo4j_DB driver (schema KG)...")
    try:
        neo4j_db_driver = AsyncGraphDatabase.driver(
            settings.neo4j_db_uri,
            auth=settings.neo4j_db_auth,
        )
        async with neo4j_db_driver.session() as session:
            await session.run("RETURN 1")
        logger.info("Async Neo4j_DB (schema KG) connection established successfully")
    except Exception as e:
        logger.error(f"Async Neo4j_DB (schema KG) connection failed: {e}")
        raise


async def close_neo4j_db() -> None:
    """
    Close the Neo4j_DB driver on application shutdown.
    """
    global neo4j_db_driver
    if neo4j_db_driver:
        logger.info("Closing Async Neo4j_DB driver (schema KG)...")
        await neo4j_db_driver.close()
        logger.info("Async Neo4j_DB driver (schema KG) closed")


def get_neo4j_db_driver():
    """
    Return the initialized async Neo4j_DB driver (schema KG).
    """
    if neo4j_db_driver is None:
        raise RuntimeError("Neo4j_DB (schema KG) driver not initialized")
    return neo4j_db_driver


async def health_check_neo4j_db() -> bool:
    """
    Check if Neo4j_DB (schema KG) connection is alive.
    """
    try:
        driver = get_neo4j_db_driver()
        async with driver.session() as session:
            await session.run("RETURN 1")
        return True
    except Exception as e:
        logger.warning(f"Neo4j_DB (schema KG) health check failed: {e}")
        return False
