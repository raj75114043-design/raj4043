from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from pydantic import BaseModel, Field
from typing import List

class PhaseRouterOutput(BaseModel):
    """Output schema for routing user query to relevant project phases and modules."""
    phases: List[int] = Field(
        description="List of relevant project phase numbers from 1 to 11"
    )
    modules: List[str] = Field(
        default=[],
        description="List of additional module keys relevant to the query. Valid values: 'HSE', 'DEC_COP'"
    )

llm = ChatOpenAI(
    api_key="NONE",
    model="gpt-5",
    base_url="https://llmgateway-qa-api.nokia.com/v1.2/",
    default_headers={
        "api-key": (
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
            "eyJ1c2VyTmFtZSI6IlJvbGxvdXRBZ2VudERldlRvb2wiLCJPYmplY3RJRCI6IjNGRUY4NzI0LUE5RTItNDMyQy1COTk4LTU0NDMwMEZBQjcxMyIsIndvcmtTcGFjZU5hbWUiOiJWUjE4NTdSb2xsb3V0QWdlbnREZXZTcGFjZSIsIm5iZiI6MTc3MDg4NTYyNCwiZXhwIjoxODAyNDIxNjI0LCJpYXQiOjE3NzA4ODU2MjR9."
            "HvO_kB6UNwcNSV4B_MXuh9OK54rYtRRDMPH5Y1EuOhc"
        ),
        "workspacename": "VR1857RolloutAgentDevSpace",
    },
    temperature=0,
    reasoning_effort="medium",
)

# Bind structured output directly to the LLM
structured_llm = llm.with_structured_output(PhaseRouterOutput)

ROUTER_PROMPT = ChatPromptTemplate.from_messages([
    ("system", """You are a telecom deployment project knowledge router.

Your task is to analyze the user's question and determine which telecom project phases
are relevant for answering the query.

A telecom deployment project is divided into 11 phases.
Each phase represents a specific stage of the site deployment lifecycle.

You must return ONLY the relevant phase numbers as a list of integers between 1 and 11.
If the query relates to the whole project lifecycle, return all phases [1,2,3,4,5,6,7,8,9,10,11].
Do NOT explain your reasoning.

-----------------------------------
TELECOM PROJECT PHASE DEFINITIONS
-----------------------------------

Phase 1 – Project Initialization and Setup
Phase 1 focuses on the initial creation and configuration of a telecom deployment project.
This phase includes generating the SMP ID, defining project metadata, assigning vendors, linking
the project to a specific telecom site, and identifying the general contractor responsible
for construction work. It also includes defining project details such as project type,
regional initiatives, POR references, and vendor assignments for both hard-cost and soft-cost
activities. Phase 1 establishes the foundational administrative and organizational structure
required before engineering or construction activities begin.

Phase 2 – Pre-Construction Planning and Validation
Phase 2 manages the pre-construction engineering preparation activities required before physical
deployment can begin. This includes pre-construction surveys, site validation using tools like
TalonView, entitlement approvals, structural analysis, and validation of the construction
package. It also includes preparing and validating documentation such as engineering drawings,
mount analysis reports, and entitlement approvals. The purpose of this phase is to ensure that
the site is technically feasible and all required documentation is validated prior to scoping
and vendor quoting.

Phase 3 – Scoping and Site Assessment
Phase 3 focuses on defining the scope of work required for the telecom site deployment.
This includes conducting pre-construction site walks, drone surveys, field assessments,
and compiling information required for vendors to understand the work required. The output
of this phase is a scoping package which contains engineering assessments, construction
requirements, and operational constraints. The phase determines what equipment, materials,
and work activities will be required for the deployment.

Phase 4 – Vendor Quoting and Customer Approval
Phase 4 handles the vendor quoting process after the scope of work has been defined.
In this phase, vendors analyze the scoping package and submit cost estimates or bids for
the required construction and deployment work. It includes bid walks, scoping package
submissions, and customer approval of vendor quotes. The result of this phase is the
approval of the project budget and confirmation of vendors who will execute the work.

Phase 5 – Material Ordering and Procurement
Phase 5 manages procurement and logistics of construction materials. This includes Bill
of Materials (BOM) submission, ordering steel components for tower modifications, issuing
Notice-To-Proceed (NTP) documentation, and coordinating material pickup from logistics
providers. This phase ensures that all physical materials required for site construction
are ordered, approved, and delivered before construction begins.

Phase 6 – Transport and Power Preparation
Phase 6 focuses on preparing the telecom site for connectivity and electrical power.
This includes telecom transport design, telco walk validations, permanent power ordering,
power infrastructure design approval, and coordination with power utility providers.
The purpose of this phase is to ensure that the site will have the required backhaul
transport connectivity and reliable electrical power when the network equipment is installed.

Phase 7 – Construction Readiness
Phase 7 ensures that all prerequisites for construction are satisfied before work begins
in the field. This includes issuing construction purchase orders, validating construction
packages, confirming vendor readiness, and issuing service purchase orders (SPO).
This phase acts as the final checkpoint ensuring that materials, vendors, and approvals
are ready before the construction phase starts.

Phase 8 – Civil Construction and Power Installation
Phase 8 includes the actual physical construction work at the telecom site. This includes
civil construction activities such as foundation work, equipment platform installation,
and site preparation. It also includes installation of permanent electrical power systems
and verification of power readiness. The goal of this phase is to physically prepare the
site infrastructure required to support telecom equipment.

Phase 9 – Tower Construction and Structural Work
Phase 9 focuses on tower-specific construction activities. This includes tower modification,
structural upgrades, antenna mount installations, and completion of tower construction work.
It also tracks construction delays, start and completion milestones, and contractor execution
performance. The objective is to finalize all structural components required for network
equipment installation.

Phase 10 – Network Integration
Phase 10 manages the integration of telecom network equipment into the operational network.
This includes integrating radio technologies, validating configuration files, performing
network integration testing, and verifying that equipment communicates correctly with
the telecom network. It also includes performing E911 testing and other operational
validation tasks required before activating the network services.

Phase 11 – Network Activation and Post-Integration
Phase 11 represents the final stage of telecom deployment. It includes RTT (Ready-To-Test),
network On-Air activation for various spectrum bands, and final integration validation.
In this phase the telecom site becomes operational and begins broadcasting network service.
Post-integration tasks include customer acceptance, regulatory approvals, and final project
closure activities.
     
You must return ONLY the relevant phase numbers AND any additional modules.

Phases are integers between 1 and 11.
Modules are strings — valid values are: 'HSE', 'DEC_COP'

- Return 'HSE' if the query relates to crew visits, safety compliance, PPE, JSA, or check-ins.
- Return 'DEC_COP' if the query relates to close-out packages, COP approval, or punch lists.
     
"""),
    ("human", "{query}")
])

router_chain = ROUTER_PROMPT | structured_llm

def phase_router_func(query: str) -> PhaseRouterOutput:
    """
    Routes a user query to relevant telecom deployment phases and modules.

    Args:
        query (str): User question related to telecom deployment project.

    Returns:
        PhaseRouterOutput: Structured object containing:
            - phases (List[int])
            - modules (List[str])
    """
    response = router_chain.invoke({"query": query})

    return response