PHASE_SCHEMA_DESCRIPTIONS = {
0: """
=== BASE NODES: Core Entities ===

These are the foundational nodes representing the key organizations and assets in the telecom deployment system. Every project originates from T-Mobile assigning a site to Nokia, with vendors and TMO vendors linked to that site.

--- NODES ---

1. TMobile
   - name | STRING | Singleton node representing T-Mobile as the customer/owner; always 'TMobile'

2. Nokia
   - name | STRING | Singleton node representing Nokia as the deployment partner; always 'Nokia'

3. Site
   - s_site_id                          | STRING | Unique site identifier; primary key (e.g., '9NV0517R')
   - s_site_name                        | STRING | Human-readable site name (e.g., 'Nolensville II')
   - s_address                          | STRING | Street address of the site
   - s_city                             | STRING | City where the site is located
   - s_state                            | STRING | State abbreviation (e.g., 'TN', 'IN')
   - s_zip                              | STRING | ZIP code of the site
   - s_site_latitude                    | STRING | GPS latitude coordinate of the site
   - s_site_longitude                   | STRING | GPS longitude coordinate of the site
   - s_site_class                       | STRING | Structural class of the tower (e.g., 'Monopole', 'Guyed Tower', 'Self Support Tower')
   - s_site_type                        | STRING | Site type category (e.g., 'Structure Non Building')
   - s_site_jurisdiction                | STRING | Governing jurisdiction of the site (e.g., 'Metro/Davidson Co.')
   - s_structure_landlord_name_siterra  | STRING | Landlord/tower owner name (e.g., 'Crown Castle', 'SBA')
   - site_deployment_reference_model    | FLOAT  | Reference deployment model config (e.g., 'Config4-Split')
   - region                             | STRING | Nokia deployment region (e.g., 'CENTRAL')
   - m_area                             | STRING | Market area grouping (e.g., 'Appalachian', 'Heartland')
   - m_market                           | STRING | Specific market name (e.g., 'NASHVILLE', 'ARKANSAS')
   - name                               | STRING | Node label name, always 'Site'

4. Vendor
   - construction_gc        | STRING | General contractor company name; primary key (e.g., 'IMPIRIUM GROUP INC')
   - pj_general_contractor  | STRING | GC name as recorded in the project (e.g., 'Tower Pioneers', 'Nokia')
   - name                   | STRING | Node label name, always 'Vendor'

5. TMO_Vendor
   - s_primary_aav_vendor_name_salesforce | STRING | TMO soft-cost vendor name; primary key (e.g., 'VERIZON', 'AT&T')
   - s_power_provider_company_name        | STRING | Electrical utility provider name (e.g., 'DUKE ENERGY')
   - s_power_provider_contact_number      | FLOAT  | Contact number for the power utility provider
   - name                                 | STRING | Node label name, always 'TMO Vendor'

--- RELATIONSHIPS ---

(TMobile)-[:TMOBILE_HAS_SITE]->(Site)
(Nokia)-[:NOKIA_IS_ASSIGNED_SITE]->(Site)
(Vendor)-[:OPERATED_BY_VENDOR]->(Site)
(TMO_Vendor)-[:OPERATED_BY_TMO_VENDOR]->(Site)
(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)
""",

    "HSE": """
=== HSE: Health, Safety and Environment ===

The HSE node monitors safety compliance for vendors during active construction phases. It tracks crew availability, PPE validation, JSA completion, and check-in status for every site visit made by construction crews. HSE is linked from both Phase 8 (civil) and Phase 9 (tower) construction nodes.

--- NODES ---

1. HSE
   - pj_project_id | STRING | Unique project identifier; primary key
   - name          | STRING | Node label name, always 'HSE'
   - description   | STRING | Description of HSE compliance monitoring

2. Visit
   - pj_project_id         | STRING  | Project identifier this visit belongs to
   - visit_num             | INTEGER | Visit sequence number (1 to 114); part of composite primary key
   - check_in_status       | STRING  | Whether crew checked in (e.g., 'Done', 'Not Done')
   - check_in_date         | STRING  | Date of the crew check-in
   - ppe_validation        | STRING  | PPE inspection result (e.g., 'Pass', 'Failed')
   - ppe_photo_available   | STRING  | Whether PPE photo was captured (e.g., 'Yes', 'No')
   - jsa_completion_status | STRING  | Job Safety Analysis completion status (e.g., 'Completed', 'Not Completed')
   - each_crew_ptid_l2w_status | STRING | Crew PTID L2W availability status (e.g., 'Available', 'Not Available')
   - name                  | STRING  | Node label name, always 'HSE'

--- RELATIONSHIPS ---

(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)-[:PHASE1_TO_PHASE2]->(Phase2_PreConstruction)-[:PHASE2_TO_PHASE3]->(Phase3_Scoping)-[:PHASE3_TO_PHASE4]->(Phase4_Quoting)-[:PHASE4_TO_PHASE5]->(Phase5_NTP_and_Material)-[:PHASE5_TO_PHASE6]->(Phase6_Transport_and_Power)-[:PHASE6_TO_PHASE7]->(Phase7_Construction_Readiness)-[:PHASE7_TO_PHASE8]->(Phase8_Civil_Work)-[:PHASE8_TO_HSE]->(HSE)
(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)-[:PHASE1_TO_PHASE2]->(Phase2_PreConstruction)-[:PHASE2_TO_PHASE3]->(Phase3_Scoping)-[:PHASE3_TO_PHASE4]->(Phase4_Quoting)-[:PHASE4_TO_PHASE5]->(Phase5_NTP_and_Material)-[:PHASE5_TO_PHASE6]->(Phase6_Transport_and_Power)-[:PHASE6_TO_PHASE7]->(Phase7_Construction_Readiness)-[:PHASE7_TO_PHASE8]->(Phase8_Civil_Work)-[:PHASE8_TO_PHASE9]->(Phase9_Tower_Work)-[:PHASE9_TO_HSE]->(HSE)
(HSE)-[:VISITS]->(Visit)
""",

    "DEC_COP": """
=== DEC_COP: Close-Out Package ===

The DEC_COP node tracks the Nokia close-out punch list process (COP) submitted to T-Mobile after civil construction. It records the approval percentage of each close-out package and is linked directly from Phase 8 civil work. Each project has one COP document capturing final sign-off details.

--- NODES ---

1. DEC_COP
   - pj_project_id   | STRING | Unique project identifier; primary key
   - scop_title      | STRING | Full title of the close-out package (e.g., 'A1Q0166G_CENTRAL_MINNEAPOLIS_Replacement_AHLOB_Close Out Pack')
   - approvedpercent | STRING | Percentage of the COP approved by T-Mobile (e.g., '100', '39')
   - name            | STRING | Node label name, always 'DEC_COP'
   - description     | STRING | Description of the DEC COP close-out tracking process

--- RELATIONSHIPS ---

(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)-[:PHASE1_TO_PHASE2]->(Phase2_PreConstruction)-[:PHASE2_TO_PHASE3]->(Phase3_Scoping)-[:PHASE3_TO_PHASE4]->(Phase4_Quoting)-[:PHASE4_TO_PHASE5]->(Phase5_NTP_and_Material)-[:PHASE5_TO_PHASE6]->(Phase6_Transport_and_Power)-[:PHASE6_TO_PHASE7]->(Phase7_Construction_Readiness)-[:PHASE7_TO_PHASE8]->(Phase8_Civil_Work)-[:PHASE8_TO_DEC_COP]->(DEC_COP)
""",
    1: """
=== PHASE 1: Project Initialization and Setup ===

Phase 1 covers the foundational setup of a telecom deployment project. It begins when T-Mobile assigns a project to Nokia and includes SMP ID creation, project metadata definition, vendor assignments (hard cost, soft cost, general contractor), and linking the project to a telecom site. Every subsequent phase is rooted in Phase 1's site assignment node.

--- NODES ---

1. Phase1_SiteAssignment
   - pj_project_id       | STRING    | Unique project identifier (e.g., 'ML80092A-0002570154'); primary key
   - s_site_id           | STRING    | The telecom site ID this project is assigned to
   - assigned_status     | STRING    | Assignment status of the project (e.g., 'Assigned')
   - name                | STRING    | Node label name, always 'Phase_1'
   - description         | STRING    | Description of the site assignment milestone

2. Phase1_SMP_ID_Creation
   - pj_project_id       | STRING    | Unique project identifier; primary key
   - smp_id              | STRING    | The generated SMP Work Order ID (e.g., 'SMP-WO-1296358')
   - smp_version         | FLOAT     | Version number of the SMP record
   - smp_status          | STRING    | Current status of the SMP (e.g., 'Active')
   - smp_name            | STRING    | Name/type of the SMP program (e.g., 'AHLOB Modernization', 'NTM')
   - name                | STRING    | Node label name, always 'Creates SMP_ID'
   - description         | STRING    | Description of the SMP ID creation step

3. Phase1_Details
   - pj_project_id       | STRING    | Unique project identifier; primary key
   - smp_id              | STRING    | Associated SMP Work Order ID
   - pj_project_type     | STRING    | Type of project (e.g., 'M-Modification General')
   - por                 | FLOAT     | Period of Record value (e.g., '07 2025')
   - por_por_id          | STRING    | POR reference ID (e.g., 'POR1046041')
   - por_regional_dev_initiatives | STRING | Regional initiative this project belongs to (e.g., '2025 Build Plan')
   - pj_por_count        | STRING    | Number of PORs linked to this project
   - t_mobile_proj_cd    | FLOAT     | T-Mobile internal project code
   - pj_gc_crew_name     | FLOAT     | General contractor crew name (if assigned)
   - name                | STRING    | Node label name, always 'Details'
   - description         | STRING    | Description of Phase 1 additional details

4. Phase1_Hard_cost_vendor_assignment
   - pj_project_id                  | STRING           | Unique project identifier; primary key
   - pj_hard_cost_vendor_assignment_po | STRING        | Hard cost vendor PO assignment name (e.g., 'NOKIA SOLUTIONS AND NETWORKS US LLC')
   - pj_hard_cost_approval_date     | LOCAL_DATE_TIME  | Date the hard cost vendor was approved
   - pj_hard_cost_pm                | FLOAT            | Hard cost project manager identifier
   - assigned_status                | STRING           | Assignment status (e.g., 'Assigned')
   - name                           | STRING           | Node label name, always 'Hard Cost Vendor Assignment'
   - description                    | STRING           | Description of the hard cost vendor assignment step

5. Phase1_Soft_cost_vendor_assignment
   - pj_project_id                  | STRING           | Unique project identifier; primary key
   - s_primary_aav_vendor_name_salesforce | STRING     | Soft cost (TMO) vendor name (e.g., 'VERIZON', 'AT&T')
   - pj_soft_cost_pm                | STRING           | Soft cost project manager name
   - pj_soft_cost_approval_date     | LOCAL_DATE_TIME  | Date soft cost vendor was approved
   - pj_soft_cost_comments          | FLOAT            | Any comments related to soft cost assignment
   - assigned_status                | STRING           | Assignment status (e.g., 'Not Assigned')
   - name                           | STRING           | Node label name, always 'Soft Cost Vendor Assignment'
   - description                    | STRING           | Description of the soft cost vendor assignment step

6. Phase1_Vendor_assignment
   - pj_project_id                        | STRING           | Unique project identifier; primary key
   - construction_gc                      | FLOAT            | General contractor assigned for construction
   - assigned_status                      | STRING           | GC assignment status (e.g., 'Not Assigned')
   - pj_p_3775_gc_selected_finish         | LOCAL_DATE_TIME  | Planned date for GC selection completion
   - pj_a_3775_gc_selected_finish         | LOCAL_DATE_TIME  | Actual date for GC selection completion
   - name                                 | STRING           | Node label name, always 'Vendor Assignment'
   - description                          | STRING           | Description of the Nokia GC vendor assignment step

--- RELATIONSHIPS (Site → Phase 1 Nodes) ---

(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)
(Phase1_SiteAssignment)-[:PHASE1_HAS_SUBPHASE1]->(Phase1_SMP_ID_Creation)
(Phase1_SiteAssignment)-[:PHASE1_HAS_DETAILS]->(Phase1_Details)
(Phase1_SiteAssignment)-[:PHASE1_HAS_SUBPHASE3]->(Phase1_Hard_cost_vendor_assignment)
(Phase1_SiteAssignment)-[:PHASE1_HAS_SUBPHASE2]->(Phase1_Soft_cost_vendor_assignment)
(Phase1_SiteAssignment)-[:PHASE1_HAS_SUBPHASE4]->(Phase1_Vendor_assignment)
(Phase1_SiteAssignment)-[:PHASE1_TO_PHASE2]->(Phase2_PreConstruction)
""",

    2: """
=== PHASE 2: Pre-Construction Planning and Validation ===

Phase 2 handles all pre-construction engineering and validation activities before physical work begins. It includes TalonView site surveys, structural and mount analysis, construction drawing preparation, entitlement completion, and validation of the pre-construction package by Nokia. This phase ensures the site is technically ready for scoping and construction.

--- NODES ---

1. Phase2_PreConstruction
   - pj_project_id   | STRING | Unique project identifier; primary key
   - precon_status   | STRING | Status of the pre-construction submission (e.g., 'Not Yet Submitted')
   - name            | STRING | Node label name, always 'Phase_2'
   - description     | STRING | Description of the pre-construction phase

2. Phase2_Precon_Validation
   - pj_project_id                                          | STRING           | Unique project identifier; primary key
   - validation_status                                      | FLOAT            | Validation result status
   - pre_con_validation_rejection_reason                    | FLOAT            | Reason for rejection if package was rejected
   - pj_p_1010_talonview_pre_con_site_survey_ordered_finish | LOCAL_DATE_TIME  | Planned date TalonView survey was ordered
   - pj_a_1010_talonview_pre_con_site_survey_ordered_finish | LOCAL_DATE_TIME  | Actual date TalonView survey was ordered
   - pj_p_1015_talonview_pre_con_site_survey_approved_finish| LOCAL_DATE_TIME  | Planned date TalonView survey was approved
   - pj_a_1015_talonview_pre_con_site_survey_approved_finish| LOCAL_DATE_TIME  | Actual date TalonView survey was approved
   - ms_1313_pre_construction_package_validated_actual      | LOCAL_DATE_TIME  | Actual date pre-construction package was validated
   - ms_1315_pre_construction_package_rejected_actual       | LOCAL_DATE_TIME  | Actual date pre-construction package was rejected
   - name                                                   | STRING           | Node label name, always 'Precon Validation'
   - description                                            | STRING           | Description of the Nokia package validation step

3. Phase2_Entitlement_Complete
   - pj_project_id                             | STRING           | Unique project identifier; primary key
   - pj_p_3710_ran_entitlement_complete_finish  | LOCAL_DATE_TIME  | Planned date for RAN entitlement completion
   - pj_a_3710_ran_entitlement_complete_finish  | LOCAL_DATE_TIME  | Actual date for RAN entitlement completion
   - pj_p_3725_all_entitlement_complete_finish  | LOCAL_DATE_TIME  | Planned date for all entitlements completion
   - pj_a_3725_all_entitlement_complete_finish  | LOCAL_DATE_TIME  | Actual date for all entitlements completion
   - name                                       | STRING           | Node label name, always 'Entitlement Complete'
   - description                                | STRING           | Description of entitlement approval milestone

4. Phase2_Precon_Milestones
   - pj_project_id                                              | STRING           | Unique project identifier; primary key
   - pj_p_1400_structural_complete_finish                       | LOCAL_DATE_TIME  | Planned date structural analysis is complete
   - pj_a_1400_structural_complete_finish                       | LOCAL_DATE_TIME  | Actual date structural analysis is complete
   - pj_p_1525_mount_analysis_ordered_finish                    | LOCAL_DATE_TIME  | Planned date mount analysis was ordered
   - pj_a_1525_mount_analysis_ordered_finish                    | LOCAL_DATE_TIME  | Actual date mount analysis was ordered
   - pj_p_1550_mount_analysis_received_finish                   | LOCAL_DATE_TIME  | Planned date mount analysis report was received
   - pj_a_1550_mount_analysis_received_finish                   | LOCAL_DATE_TIME  | Actual date mount analysis report was received
   - pj_p_2200_construction_drawings_ordered_finish             | LOCAL_DATE_TIME  | Planned date construction drawings were ordered
   - pj_a_2200_construction_drawings_ordered_finish             | LOCAL_DATE_TIME  | Actual date construction drawings were ordered
   - pj_p_2225_construction_drawings_received_finish            | LOCAL_DATE_TIME  | Planned date construction drawings were received
   - pj_a_2225_construction_drawings_received_finish            | LOCAL_DATE_TIME  | Actual date construction drawings were received
   - pj_p_2250_construction_drawings_redlines_compiled_finish   | LOCAL_DATE_TIME  | Planned date redlines were compiled
   - pj_a_2250_construction_drawings_redlines_compiled_finish   | LOCAL_DATE_TIME  | Actual date redlines were compiled
   - pj_p_2275_final_construction_drawings_approved_finish      | LOCAL_DATE_TIME  | Planned date final drawings were approved
   - pj_a_2275_final_construction_drawings_approved_finish      | LOCAL_DATE_TIME  | Actual date final drawings were approved
   - pj_p_2286_mw_final_construction_drawings_approved_finish   | LOCAL_DATE_TIME  | Planned date MW-specific drawings were approved
   - pj_a_2286_mw_final_construction_drawings_approved_finish   | LOCAL_DATE_TIME  | Actual date MW-specific drawings were approved
   - pj_p_2350_bom_submitted_from_market_to_region_finish       | LOCAL_DATE_TIME  | Planned date BOM was submitted market-to-region
   - pj_a_2350_bom_submitted_from_market_to_region_finish       | LOCAL_DATE_TIME  | Actual date BOM was submitted market-to-region
   - pj_p_3800_pre_ntp_issued_finish                            | LOCAL_DATE_TIME  | Planned date pre-NTP was issued
   - pj_a_3800_pre_ntp_issued_finish                            | LOCAL_DATE_TIME  | Actual date pre-NTP was issued
   - pj_a_2475_dou_final_rfds_issued                            | LOCAL_DATE_TIME  | Actual date DOU final RFDs were issued
   - ms_1310_pre_construction_package_received_actual           | LOCAL_DATE_TIME  | Actual date pre-construction package was received
   - name                                                       | STRING           | Node label name, always 'Precon Milestones'
   - description                                                | STRING           | Description of pre-construction milestone tracking

--- RELATIONSHIPS (Site → Phase 2 Nodes) ---

(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)-[:PHASE1_TO_PHASE2]->(Phase2_PreConstruction)
(Phase2_PreConstruction)-[:PHASE2_HAS_SUBPHASE]->(Phase2_Precon_Validation)
(Phase2_PreConstruction)-[:PHASE2_HAS_SUBPHASE2]->(Phase2_Entitlement_Complete)
(Phase2_PreConstruction)-[:PHASE2_HAS_MILESTONES]->(Phase2_Precon_Milestones)
(Phase2_PreConstruction)-[:PHASE2_TO_PHASE3]->(Phase3_Scoping)
""",

    3: """
=== PHASE 3: Scoping and Site Assessment ===

Phase 3 focuses on defining the exact scope of construction work at the site. Nokia performs pre-construction site walks, drone surveys (via TalonView), and field assessments to compile a scoping and quoting package. This determines the equipment, materials, and construction activities required.

--- NODES ---

1. Phase3_Scoping
   - pj_project_id   | STRING | Unique project identifier; primary key
   - scoping_status  | STRING | Current status of the scoping phase (e.g., 'Site Walk Not Assigned', 'Site Walk/Survey Ongoing')
   - name            | STRING | Node label name, always 'Phase_3'
   - description     | STRING | Description of the scoping phase

2. Phase3_Details
   - pj_project_id                                    | STRING           | Unique project identifier; primary key
   - pj_p_3825_pre_construction_walk_complete_finish  | LOCAL_DATE_TIME  | Planned date the pre-construction site walk is complete
   - pj_a_3825_pre_construction_walk_complete_finish  | LOCAL_DATE_TIME  | Actual date the pre-construction site walk is complete
   - ms_1316_pre_con_site_walk_completed_actual        | LOCAL_DATE_TIME  | Milestone: actual date site walk was completed
   - ms_1323_ready_for_scoping_actual                  | LOCAL_DATE_TIME  | Milestone: actual date project was marked ready for scoping
   - ms_1327_scoping_and_quoting_package_validated_actual | LOCAL_DATE_TIME | Milestone: actual date scoping/quoting package was validated
   - ms_1321_talon_view_drone_svcs_spo_issued_date     | LOCAL_DATE_TIME  | Date the TalonView drone SPO was issued
   - ms_1321_talon_view_drone_svcs_actual              | LOCAL_DATE_TIME  | Actual date TalonView drone services were completed
   - ms_1314_ndpc_survey_request_form_submitted_actual | LOCAL_DATE_TIME  | Actual date NDPC survey request was submitted
   - name                                              | STRING           | Node label name, always 'Scoping Details'
   - description                                       | STRING           | Description of scoping detail milestones

--- RELATIONSHIPS (Site → Phase 3 Nodes) ---

(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)-[:PHASE1_TO_PHASE2]->(Phase2_PreConstruction)-[:PHASE2_TO_PHASE3]->(Phase3_Scoping)
(Phase3_Scoping)-[:PHASE3_HAS_DETAILS]->(Phase3_Details)
(Phase3_Scoping)-[:PHASE3_TO_PHASE4]->(Phase4_Quoting)
""",

    4: """
=== PHASE 4: Vendor Quoting and Customer Approval ===

Phase 4 manages the vendor quoting process. After the scope is defined, vendors conduct bid walks, review the scoping package, and submit cost estimates. T-Mobile reviews and approves the quotes, resulting in budget approval and vendor selection for construction execution.

--- NODES ---

1. Phase4_Quoting
   - pj_project_id                              | STRING           | Unique project identifier; primary key
   - quoting_status                             | STRING           | Current quoting status (e.g., 'Not Started')
   - pj_p_3815_bid_walk_complete_finish         | LOCAL_DATE_TIME  | Planned date the bid walk is complete
   - pj_a_3815_bid_walk_complete_finish         | LOCAL_DATE_TIME  | Actual date the bid walk is complete
   - pj_bid_walk_complete_3815_doc              | FLOAT            | Documentation reference for bid walk completion
   - pj_bid_walk_complete_optional_status       | FLOAT            | Optional bid walk status flag
   - ms_1331_scoping_package_submitted_actual   | LOCAL_DATE_TIME  | Actual date scoping package was submitted to customer
   - ms_1333_scoping_package_approved_by_customer_actual | LOCAL_DATE_TIME | Actual date scoping package was approved by T-Mobile
   - name                                       | STRING           | Node label name, always 'Phase_4'
   - description                                | STRING           | Description of the quoting phase

--- RELATIONSHIPS (Site → Phase 4 Nodes) ---

(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)-[:PHASE1_TO_PHASE2]->(Phase2_PreConstruction)-[:PHASE2_TO_PHASE3]->(Phase3_Scoping)-[:PHASE3_TO_PHASE4]->(Phase4_Quoting)
(Phase4_Quoting)-[:PHASE4_TO_PHASE5]->(Phase5_NTP_and_Material)
""",

    5: """
=== PHASE 5: Material Ordering and Procurement ===

Phase 5 covers all procurement and logistics activities. It includes BOM submission, ordering tower steel components, issuing Notice-To-Proceed (NTP) documentation to the general contractor, and coordinating material pickup from logistics providers (MSL). This phase ensures all physical materials are ready before construction begins.

--- NODES ---

1. Phase5_NTP_and_Material
   - pj_project_id                                    | STRING           | Unique project identifier; primary key
   - pj_p_4025_civil_ntp_submitted_to_gc_finish       | LOCAL_DATE_TIME  | Planned date Civil NTP was submitted to GC
   - pj_a_4025_civil_ntp_submitted_to_gc_finish       | LOCAL_DATE_TIME  | Actual date Civil NTP was submitted to GC
   - pj_p_4050_civil_ntp_accepted_by_gc_finish        | LOCAL_DATE_TIME  | Planned date Civil NTP was accepted by GC
   - pj_a_4050_civil_ntp_accepted_by_gc_finish        | LOCAL_DATE_TIME  | Actual date Civil NTP was accepted by GC
   - pj_p_4075_construction_ntp_submitted_to_gc_finish| LOCAL_DATE_TIME  | Planned date Tower/Construction NTP submitted to GC
   - pj_a_4075_construction_ntp_submitted_to_gc_finish| LOCAL_DATE_TIME  | Actual date Tower/Construction NTP submitted to GC
   - pj_p_4100_construction_ntp_accepted_by_gc_finish | LOCAL_DATE_TIME  | Planned date Tower/Construction NTP accepted by GC
   - pj_a_4100_construction_ntp_accepted_by_gc_finish | LOCAL_DATE_TIME  | Actual date Tower/Construction NTP accepted by GC
   - ms_1407_tower_ntp_validated_actual               | LOCAL_DATE_TIME  | Actual date tower NTP was validated
   - ms_1507_tower_ntp_approved_actual                | LOCAL_DATE_TIME  | Actual date tower NTP was approved
   - name                                             | STRING           | Node label name, always 'Phase_5_NTP'
   - description                                      | STRING           | Description of NTP and material phase

2. Phase5_BOM_Submission
   - pj_project_id                               | STRING           | Unique project identifier; primary key
   - pj_p_3850_bom_submitted_bom_in_bat_finish   | LOCAL_DATE_TIME  | Planned date BOM was submitted (entered in BAT)
   - pj_a_3850_bom_submitted_bom_in_bat_finish   | LOCAL_DATE_TIME  | Actual date BOM was submitted (entered in BAT)
   - pj_p_3875_bom_received_bom_in_aims_finish   | LOCAL_DATE_TIME  | Planned date BOM was received in AIMS system
   - pj_a_3875_bom_received_bom_in_aims_finish   | LOCAL_DATE_TIME  | Actual date BOM was received in AIMS system
   - pj_p_3900_all_bat_orders_received_finish     | LOCAL_DATE_TIME  | Planned date all BAT orders were received
   - pj_a_3900_all_bat_orders_received_finish     | LOCAL_DATE_TIME  | Actual date all BAT orders were received
   - name                                         | STRING           | Node label name, always 'BOM'
   - description                                  | STRING           | Description of BOM submission milestones

3. Phase5_Steel_Submission
   - pj_project_id           | STRING           | Unique project identifier; primary key
   - pj_steel_ordered_status | FLOAT            | Status indicating whether steel has been ordered
   - pj_steel_received_status| FLOAT            | Status indicating whether steel has been received
   - pj_steel_po_number      | FLOAT            | Purchase order number for steel procurement
   - pj_steel_ordered        | LOCAL_DATE_TIME  | Date steel was ordered
   - pj_steel_received_date  | LOCAL_DATE_TIME  | Date steel was received at site/warehouse
   - name                    | STRING           | Node label name, always 'Steel'
   - description             | STRING           | Description of steel ordering and tracking

4. Phase5_Material_Pickup
   - pj_project_id                          | STRING           | Unique project identifier; primary key
   - pj_p_3925_msl_pickup_date_finish       | LOCAL_DATE_TIME  | Planned date for MSL material pickup
   - pj_a_3925_msl_pickup_date_finish       | LOCAL_DATE_TIME  | Actual date for MSL material pickup
   - ms_1461_pickup_tower_materials_and_validate_actual | LOCAL_DATE_TIME | Actual date tower materials were picked up and validated
   - ms_14610_gc_material_pickup_actual     | LOCAL_DATE_TIME  | Actual date GC completed material pickup
   - name                                   | STRING           | Node label name, always 'Material_Pickup'
   - description                            | STRING           | Description of material pickup from logistics

--- RELATIONSHIPS (Site → Phase 5 Nodes) ---

(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)-[:PHASE1_TO_PHASE2]->(Phase2_PreConstruction)-[:PHASE2_TO_PHASE3]->(Phase3_Scoping)-[:PHASE3_TO_PHASE4]->(Phase4_Quoting)-[:PHASE4_TO_PHASE5]->(Phase5_NTP_and_Material)
(Phase5_NTP_and_Material)-[:PHASE5_HAS_BOM]->(Phase5_BOM_Submission)
(Phase5_NTP_and_Material)-[:PHASE5_HAS_STEEL]->(Phase5_Steel_Submission)
(Phase5_NTP_and_Material)-[:PHASE5_HAS_MATERIAL_PICKUP]->(Phase5_Material_Pickup)
(Phase5_NTP_and_Material)-[:PHASE5_TO_PHASE6]->(Phase6_Transport_and_Power)
""",

    6: """
=== PHASE 6: Transport and Power Preparation ===

Phase 6 prepares the telecom site for network backhaul connectivity and electrical power. Activities include AAV telco site walks, transport design completion, permanent power ordering, power walk, and power design approval. This phase ensures the site will have working transport and reliable power before equipment installation.

--- NODES ---

1. Phase6_Transport_and_Power
   - pj_project_id                              | STRING           | Unique project identifier; primary key
   - pj_p_2075_aav_telco_site_walk_complete_finish | LOCAL_DATE_TIME | Planned date AAV telco site walk is complete
   - pj_a_2075_aav_telco_site_walk_complete_finish | LOCAL_DATE_TIME | Actual date AAV telco site walk is complete
   - pj_p_2080_aav_telco_design_complete_finish | LOCAL_DATE_TIME  | Planned date AAV telco design is complete
   - pj_a_2080_aav_telco_design_complete_finish | LOCAL_DATE_TIME  | Actual date AAV telco design is complete
   - pj_p_4450_permanent_power_ordered_finish   | LOCAL_DATE_TIME  | Planned date permanent power was ordered
   - pj_a_4450_permanent_power_ordered_finish   | LOCAL_DATE_TIME  | Actual date permanent power was ordered
   - pj_p_4475_complete_power_walk_finish       | LOCAL_DATE_TIME  | Planned date power walk was completed
   - pj_a_4475_complete_power_walk_finish       | LOCAL_DATE_TIME  | Actual date power walk was completed
   - pj_p_4500_power_design_approval_finish     | LOCAL_DATE_TIME  | Planned date power design was approved
   - pj_a_4500_power_design_approval_finish     | LOCAL_DATE_TIME  | Actual date power design was approved
   - name                                       | STRING           | Node label name, always 'Phase_6'
   - description                                | STRING           | Description of transport and power preparation phase

--- RELATIONSHIPS (Site → Phase 6 Nodes) ---

(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)-[:PHASE1_TO_PHASE2]->(Phase2_PreConstruction)-[:PHASE2_TO_PHASE3]->(Phase3_Scoping)-[:PHASE3_TO_PHASE4]->(Phase4_Quoting)-[:PHASE4_TO_PHASE5]->(Phase5_NTP_and_Material)-[:PHASE5_TO_PHASE6]->(Phase6_Transport_and_Power)
(Phase6_Transport_and_Power)-[:PHASE6_TO_PHASE7]->(Phase7_Construction_Readiness)
""",

    7: """
=== PHASE 7: Construction Readiness ===

Phase 7 is the final checkpoint before physical construction begins. It validates that all materials, vendor approvals, purchase orders, and service purchase orders (SPOs) are in place. This includes issuing construction POs, validating construction packages, and issuing SPOs for civil, tower, and integration work.

--- NODES ---

1. Phase7_Construction_Readiness
   - pj_project_id                            | STRING           | Unique project identifier; primary key
   - pj_p_4200_pull_construction_po_number_finish | LOCAL_DATE_TIME | Planned date construction PO number was pulled
   - pj_a_4200_pull_construction_po_number_finish | LOCAL_DATE_TIME | Actual date construction PO number was pulled
   - pj_construction_pos_issued               | FLOAT            | Flag/count indicating if construction POs were issued
   - base_spo_requested_date                  | LOCAL_DATE_TIME  | Date the base SPO was requested
   - ms_1321_talon_view_drone_svcs_spo        | FLOAT            | SPO number for TalonView drone services
   - ms_1321_talon_view_drone_svcs_spo_issued_date | LOCAL_DATE_TIME | Date TalonView drone SPO was issued
   - ms_1551_civil_construction_complete_spo  | FLOAT            | SPO number for civil construction completion
   - ms_1551_civil_construction_complete_spo_issued_date | LOCAL_DATE_TIME | Date civil construction SPO was issued
   - ms_1551_module_spo_vendor_name           | FLOAT            | Vendor name for civil module SPO
   - ms1555_construction_complete_spo         | FLOAT            | SPO number for tower construction completion
   - ms1555_construction_complete_spo_issued_date | LOCAL_DATE_TIME | Date tower construction SPO was issued
   - ms_1555_module_spo_vendor_name           | FLOAT            | Vendor name for tower module SPO
   - ms_1970_integration_complete_spo         | FLOAT            | SPO number for integration completion
   - ms_1559_cop_approved_by_t_mobile_spo     | FLOAT            | SPO number approved by T-Mobile for COP
   - ms_1559_cop_approved_by_t_mobile_spo_issued_date | LOCAL_DATE_TIME | Date T-Mobile approved COP SPO
   - name                                     | STRING           | Node label name, always 'Phase_7'
   - description                              | STRING           | Description of construction readiness phase

--- RELATIONSHIPS (Site → Phase 7 Nodes) ---

(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)-[:PHASE1_TO_PHASE2]->(Phase2_PreConstruction)-[:PHASE2_TO_PHASE3]->(Phase3_Scoping)-[:PHASE3_TO_PHASE4]->(Phase4_Quoting)-[:PHASE4_TO_PHASE5]->(Phase5_NTP_and_Material)-[:PHASE5_TO_PHASE6]->(Phase6_Transport_and_Power)-[:PHASE6_TO_PHASE7]->(Phase7_Construction_Readiness)
(Phase7_Construction_Readiness)-[:PHASE7_TO_PHASE8]->(Phase8_Civil_Work)
""",

    8: """
=== PHASE 8: Civil Construction and Power Installation ===

Phase 8 covers physical civil construction at the site, including foundation work, equipment platform installation, and site preparation. It also tracks permanent power installation and handles Inspection Acceptance (IA) and Goods Receipt (GR) milestones for civil work, as well as links to the DEC COP close-out process.

--- NODES ---

1. Phase8_Civil_Work
   - pj_project_id                                | STRING           | Unique project identifier; primary key
   - pj_p_4250_civil_construction_start_finish    | LOCAL_DATE_TIME  | Planned date civil construction starts
   - pj_a_4250_civil_construction_start_finish    | LOCAL_DATE_TIME  | Actual date civil construction starts
   - pj_p_4750_civil_construction_complete_finish | LOCAL_DATE_TIME  | Planned date civil construction completes
   - pj_a_4750_civil_construction_complete_finish | LOCAL_DATE_TIME  | Actual date civil construction completes
   - name                                         | STRING           | Node label name, always 'Phase_8'
   - description                                  | STRING           | Description of civil construction milestones

2. Phase8_Power_Installation
   - pj_project_id                          | STRING           | Unique project identifier; primary key
   - pj_p_4525_power_ready_finish           | LOCAL_DATE_TIME  | Planned date site power is ready
   - pj_a_4525_power_ready_finish           | LOCAL_DATE_TIME  | Actual date site power is ready
   - pj_p_4550_permanent_power_installed_finish | LOCAL_DATE_TIME | Planned date permanent power is installed
   - pj_a_4550_permanent_power_installed_finish | LOCAL_DATE_TIME | Actual date permanent power is installed
   - name                                   | STRING           | Node label name, always 'Power_Installation'
   - description                            | STRING           | Description of permanent power installation milestones

3. Phase8_Civil_IA_GR
   - pj_project_id                                          | STRING           | Unique project identifier; primary key
   - pj_p_2275_final_construction_drawings_approved_finish  | LOCAL_DATE_TIME  | Planned date final drawings were approved (cross-reference)
   - pj_a_2275_final_construction_drawings_approved_finish  | LOCAL_DATE_TIME  | Actual date final drawings were approved (cross-reference)
   - ms_1551_civil_construction_complete_ia_date            | LOCAL_DATE_TIME  | Date civil construction Inspection Acceptance was completed
   - ms_1551_civil_construction_complete_gr_date            | LOCAL_DATE_TIME  | Date civil construction Goods Receipt was completed
   - name                                                   | STRING           | Node label name, always 'Civil_IA_GR'
   - description                                            | STRING           | Description of civil IA and GR milestone tracking

--- RELATIONSHIPS (Site → Phase 8 Nodes) ---

(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)-[:PHASE1_TO_PHASE2]->(Phase2_PreConstruction)-[:PHASE2_TO_PHASE3]->(Phase3_Scoping)-[:PHASE3_TO_PHASE4]->(Phase4_Quoting)-[:PHASE4_TO_PHASE5]->(Phase5_NTP_and_Material)-[:PHASE5_TO_PHASE6]->(Phase6_Transport_and_Power)-[:PHASE6_TO_PHASE7]->(Phase7_Construction_Readiness)-[:PHASE7_TO_PHASE8]->(Phase8_Civil_Work)
(Phase8_Civil_Work)-[:PHASE8_HAS_POWER_INSTALLATION]->(Phase8_Power_Installation)
(Phase8_Civil_Work)-[:PHASE7_TO_PHASE8_CIVIL_IA_GR]->(Phase8_Civil_IA_GR)
(Phase8_Civil_Work)-[:PHASE8_TO_PHASE9]->(Phase9_Tower_Work)
(Phase8_Civil_Work)-[:PHASE8_TO_DEC_COP]->(DEC_COP)
(Phase8_Civil_Work)-[:PHASE8_TO_HSE]->(HSE)
""",

    9: """
=== PHASE 9: Tower Construction and Structural Work ===

Phase 9 covers all tower-specific construction activities including structural modifications, antenna mount installations, and tower construction completion. It tracks construction start and completion milestones, delay codes, and commercial approval (CA), Inspection Acceptance (IA), and Goods Receipt (GR) milestones for tower work.

--- NODES ---

1. Phase9_Tower_Work
   - pj_project_id                                | STRING           | Unique project identifier; primary key
   - pj_p_4225_construction_start_finish          | LOCAL_DATE_TIME  | Planned date tower construction starts
   - pj_a_4225_construction_start_finish          | LOCAL_DATE_TIME  | Actual date tower construction starts
   - pj_p_5175_construction_complete_finish       | LOCAL_DATE_TIME  | Planned date tower construction completes
   - pj_a_5175_construction_complete_finish       | LOCAL_DATE_TIME  | Actual date tower construction completes
   - pj_construction_start_delay_code             | STRING           | Delay code for construction start (e.g., 'No Delay')
   - pj_construction_start_delay_comments         | FLOAT            | Comments on construction start delay
   - pj_construction_complete_delay_code          | FLOAT            | Delay code for construction completion
   - pj_construction_complete_delay_comments      | FLOAT            | Comments on construction completion delay
   - name                                         | STRING           | Node label name, always 'Phase_9_Tower_Work'
   - description                                  | STRING           | Description of tower construction milestones

2. Phase9_Tower_CA
   - pj_project_id                          | STRING           | Unique project identifier; primary key
   - ms1555_construction_complete_ca_date   | LOCAL_DATE_TIME  | Date Commercial Approval (CA) was completed for tower
   - ms1555_construction_complete_invoice   | FLOAT            | Invoice number for tower construction completion
   - ms1555_construction_complete_invoice_date | LOCAL_DATE_TIME | Date invoice was submitted for tower construction
   - ms1555_construction_complete_bbr_date  | LOCAL_DATE_TIME  | Date BBR (Back-Billed Revenue) was completed for tower
   - name                                   | STRING           | Node label name, always 'Tower_CA'
   - description                            | STRING           | Description of tower commercial approval milestones

3. Phase9_Tower_IA_GR
   - pj_project_id                          | STRING           | Unique project identifier; primary key
   - ms1555_construction_complete_ia_date   | LOCAL_DATE_TIME  | Date Inspection Acceptance (IA) was completed for tower
   - ms1555_construction_complete_gr_date   | LOCAL_DATE_TIME  | Date Goods Receipt (GR) was completed for tower
   - name                                   | STRING           | Node label name, always 'Tower_IA_GR'
   - description                            | STRING           | Description of tower IA and GR milestone tracking

--- RELATIONSHIPS (Site → Phase 9 Nodes) ---

(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)-[:PHASE1_TO_PHASE2]->(Phase2_PreConstruction)-[:PHASE2_TO_PHASE3]->(Phase3_Scoping)-[:PHASE3_TO_PHASE4]->(Phase4_Quoting)-[:PHASE4_TO_PHASE5]->(Phase5_NTP_and_Material)-[:PHASE5_TO_PHASE6]->(Phase6_Transport_and_Power)-[:PHASE6_TO_PHASE7]->(Phase7_Construction_Readiness)-[:PHASE7_TO_PHASE8]->(Phase8_Civil_Work)-[:PHASE8_TO_PHASE9]->(Phase9_Tower_Work)
(Phase9_Tower_Work)-[:PHASE9_HAS_CA]->(Phase9_Tower_CA)
(Phase9_Tower_Work)-[:PHASE9_HAS_IAGR]->(Phase9_Tower_IA_GR)
(Phase9_Tower_Work)-[:PHASE9_TO_PHASE10]->(Phase10_Integration)
(Phase9_Tower_Work)-[:PHASE9_TO_HSE]->(HSE)
""",

    10: """
=== PHASE 10: Network Integration ===

Phase 10 manages the integration of telecom network equipment into the live network. This includes validating SCF configuration files, integrating all planned radio technologies, running AirView reports, performing E911 test calls, and completing integration start and finish milestones. The site is functionally connected to the network at the end of this phase.

--- NODES ---

1. Phase10_Integration
   - pj_project_id                                      | STRING           | Unique project identifier; primary key
   - pj_p_5270_integration_start_finish                 | LOCAL_DATE_TIME  | Planned date integration work starts
   - pj_a_5270_integration_start_finish                 | LOCAL_DATE_TIME  | Actual date integration work starts
   - pj_p_5275_integration_complete_finish              | LOCAL_DATE_TIME  | Planned date integration work completes
   - pj_a_5275_integration_complete_finish              | LOCAL_DATE_TIME  | Actual date integration work completes
   - pj_integration_comments                            | STRING           | Comments on integration progress or issues
   - ms_1564_validate_scf_files_are_available_actual    | LOCAL_DATE_TIME  | Actual date SCF configuration files were validated
   - ms_1899_all_planned_technologies_integrated_actual | LOCAL_DATE_TIME  | Actual date all planned radio technologies were integrated
   - ms_1971_air_view_report_completed_actual           | LOCAL_DATE_TIME  | Actual date AirView integration report was completed
   - ms_2123_planned_e911_test_calls_actual             | LOCAL_DATE_TIME  | Actual date E911 test calls were completed
   - name                                               | STRING           | Node label name, always 'Phase10_Integration'
   - description                                        | STRING           | Description of network integration milestones

--- RELATIONSHIPS (Site → Phase 10 Nodes) ---

(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)-[:PHASE1_TO_PHASE2]->(Phase2_PreConstruction)-[:PHASE2_TO_PHASE3]->(Phase3_Scoping)-[:PHASE3_TO_PHASE4]->(Phase4_Quoting)-[:PHASE4_TO_PHASE5]->(Phase5_NTP_and_Material)-[:PHASE5_TO_PHASE6]->(Phase6_Transport_and_Power)-[:PHASE6_TO_PHASE7]->(Phase7_Construction_Readiness)-[:PHASE7_TO_PHASE8]->(Phase8_Civil_Work)-[:PHASE8_TO_PHASE9]->(Phase9_Tower_Work)-[:PHASE9_TO_PHASE10]->(Phase10_Integration)
(Phase10_Integration)-[:PHASE8_TO_PHASE9]->(Phase11_Post_Integration)
""",

    11: """
=== PHASE 11: Network Activation and Post-Integration ===

Phase 11 is the final phase of the telecom deployment lifecycle. It includes RTT (Radio Technology Testing) for each spectrum band, On-Air network activation per band, and post-integration commercial milestones (IA, GR, CA, invoicing). The site becomes fully operational and broadcasting at the conclusion of this phase.

--- NODES ---

1. Phase11_Post_Integration
   - pj_project_id                              | STRING           | Unique project identifier; primary key
   - ms_1970_integration_complete_actual        | LOCAL_DATE_TIME  | Actual date integration was marked complete
   - ms_1970_integration_complete_spo_issued_date | LOCAL_DATE_TIME | Date integration complete SPO was issued
   - ms_1970_integration_complete_ia_date       | LOCAL_DATE_TIME  | Date Inspection Acceptance for integration was completed
   - ms_1970_integration_complete_gr_date       | LOCAL_DATE_TIME  | Date Goods Receipt for integration was completed
   - ms_1970_integration_complete_bbr_date      | LOCAL_DATE_TIME  | Date BBR was completed for integration milestone
   - ms_1970_integration_complete_so_inv_date   | LOCAL_DATE_TIME  | Date sales order invoice was submitted for integration
   - ms_1970_integration_complete_ca_date       | LOCAL_DATE_TIME  | Date Commercial Approval was completed for integration
   - name                                       | STRING           | Node label name, always 'Phase11_Post_Integration'
   - description                                | STRING           | Description of post-integration milestone tracking

2. Phase11_RTT
   - pj_project_id                        | STRING           | Unique project identifier; primary key
   - pj_p_5725_l1900_rtt_finish           | LOCAL_DATE_TIME  | Planned RTT completion date for L1900 band
   - pj_a_5725_l1900_rtt_finish           | LOCAL_DATE_TIME  | Actual RTT completion date for L1900 band
   - pj_p_5775_l2100_rtt_finish           | LOCAL_DATE_TIME  | Planned RTT completion date for L2100 band
   - pj_a_5775_l2100_rtt_finish           | LOCAL_DATE_TIME  | Actual RTT completion date for L2100 band
   - pj_p_5825_l2100_aws3_rtt_finish      | LOCAL_DATE_TIME  | Planned RTT completion date for L2100 AWS3 band
   - pj_a_5825_l2100_aws3_rtt_finish      | LOCAL_DATE_TIME  | Actual RTT completion date for L2100 AWS3 band
   - pj_p_5860_l2500_rtt_finish           | LOCAL_DATE_TIME  | Planned RTT completion date for L2500 band
   - pj_p_5875_l600_rtt_finish            | LOCAL_DATE_TIME  | Planned RTT completion date for L600 band
   - pj_a_5875_l600_rtt_finish            | LOCAL_DATE_TIME  | Actual RTT completion date for L600 band
   - pj_p_5925_n600_rtt_finish            | LOCAL_DATE_TIME  | Planned RTT completion date for N600 (5G) band
   - pj_a_5925_n600_rtt_finish            | LOCAL_DATE_TIME  | Actual RTT completion date for N600 (5G) band
   - pj_p_5975_l700_rtt_finish            | LOCAL_DATE_TIME  | Planned RTT completion date for L700 band
   - pj_a_5975_l700_rtt_finish            | LOCAL_DATE_TIME  | Actual RTT completion date for L700 band
   - pj_p_6255_n1900_rtt_finish           | LOCAL_DATE_TIME  | Planned RTT completion date for N1900 (5G) band
   - pj_a_6255_n1900_rtt_finish           | LOCAL_DATE_TIME  | Actual RTT completion date for N1900 (5G) band
   - pj_p_6268_n2100_rtt_finish           | LOCAL_DATE_TIME  | Planned RTT completion date for N2100 (5G) band
   - pj_a_6268_n2100_rtt_finish           | LOCAL_DATE_TIME  | Actual RTT completion date for N2100 (5G) band
   - pj_p_6315_n2500_rtt_finish           | LOCAL_DATE_TIME  | Planned RTT completion date for N2500 (5G) band
   - pj_a_6315_n2500_rtt_finish           | LOCAL_DATE_TIME  | Actual RTT completion date for N2500 (5G) band
   - name                                 | STRING           | Node label name, always 'Phase11_RTT'
   - description                          | STRING           | Description of RTT milestone tracking per spectrum band

3. Phase11_OnAir
   - pj_project_id                          | STRING           | Unique project identifier; primary key
   - pj_a_5750_l1900_onair_finish           | LOCAL_DATE_TIME  | Actual On-Air activation date for L1900 band
   - pj_a_5800_l2100_onair_finish           | LOCAL_DATE_TIME  | Actual On-Air activation date for L2100 band
   - pj_a_5850_l2100_aws3_onair_finish      | LOCAL_DATE_TIME  | Actual On-Air activation date for L2100 AWS3 band
   - pj_a_5900_l600_onair_finish            | LOCAL_DATE_TIME  | Actual On-Air activation date for L600 band
   - pj_a_5950_n600_onair_finish            | LOCAL_DATE_TIME  | Actual On-Air activation date for N600 (5G) band
   - pj_a_6000_l700_onair_finish            | LOCAL_DATE_TIME  | Actual On-Air activation date for L700 band
   - pj_a_6257_n1900_onair_finish           | LOCAL_DATE_TIME  | Actual On-Air activation date for N1900 (5G) band
   - pj_a_6270_n2100_onair_finish           | LOCAL_DATE_TIME  | Actual On-Air activation date for N2100 (5G) band
   - pj_a_6318_n2500_onair_finish           | LOCAL_DATE_TIME  | Actual On-Air activation date for N2500 (5G) band
   - name                                   | STRING           | Node label name, always 'Phase11_OnAir'
   - description                            | STRING           | Description of network On-Air activation per band

--- RELATIONSHIPS (Site → Phase 11 Nodes) ---

(Site)-[:SITE_HAS_PHASE1]->(Phase1_SiteAssignment)-[:PHASE1_TO_PHASE2]->(Phase2_PreConstruction)-[:PHASE2_TO_PHASE3]->(Phase3_Scoping)-[:PHASE3_TO_PHASE4]->(Phase4_Quoting)-[:PHASE4_TO_PHASE5]->(Phase5_NTP_and_Material)-[:PHASE5_TO_PHASE6]->(Phase6_Transport_and_Power)-[:PHASE6_TO_PHASE7]->(Phase7_Construction_Readiness)-[:PHASE7_TO_PHASE8]->(Phase8_Civil_Work)-[:PHASE8_TO_PHASE9]->(Phase9_Tower_Work)-[:PHASE9_TO_PHASE10]->(Phase10_Integration)-[:PHASE8_TO_PHASE9]->(Phase11_Post_Integration)
(Phase11_Post_Integration)-[:PHASE11_HAS_RTT]->(Phase11_RTT)
(Phase11_Post_Integration)-[:PHASE11_HAS_ONAIR]->(Phase11_OnAir)
""",

}