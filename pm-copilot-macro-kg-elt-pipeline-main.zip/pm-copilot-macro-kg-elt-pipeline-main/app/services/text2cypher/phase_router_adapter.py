# app/services/text2cypher/phase_router_adapter.py
from typing import List
from app.services.text2cypher.phase_router import phase_router_func, PhaseRouterOutput

def route_phases_and_modules(question: str) -> tuple[List[int], List[str]]:
    """
    Thin adapter, so we can mock in tests and keep boundaries clean.
    """
    res: PhaseRouterOutput = phase_router_func(question)
    return res.phases, res.modules