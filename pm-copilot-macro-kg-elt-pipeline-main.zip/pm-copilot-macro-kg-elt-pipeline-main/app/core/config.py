"""
Configuration management for Neo4j ETL
Author: Advait Shah, Associate, PwC India
Client: Nokia
"""

from typing import List
from urllib.parse import quote_plus
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from .env"""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
    )

    # ── Database ─────────────────────────────────────────────────────
    db_host: str = Field(default="localhost")
    db_port: int = Field(default=5432)
    db_name: str = Field(default="postgres")
    db_user: str = Field(default="postgres")
    db_password: str = Field(default="")
    db_schema: str = Field(
        default="pwc_agent_utility_schema",
        description="Utility schema (chat history, feedback, HITL)",
    )
    db_schema_staging: str = Field(
        default="pwc_macro_staging_schema",
        description="Staging schema for text-to-SQL tasks",
    )

    # ── LLM Gateway (Nokia) ─────────────────────────────────────────
    llm_gateway_link: str = Field(default="")
    llm_api_key: str = Field(default="")
    workspace_name: str = Field(default="")

    # ── Global Context Layer APIs ────────────────────────────────────
    keyword_search_api: str = Field(default="")
    kpi_search_api: str = Field(default="")
    qb_search_api: str = Field(default="")
    schema_world_view_api: str = Field(default="")
    kpi_list_api: str = Field(default="")
    world_view_auth_password: str = Field(default="")

    # ── Azure Speech Services ────────────────────────────────────────
    speech_key_1: str = Field(default="")
    speech_key_2: str = Field(default="")
    speech_endpoint: str = Field(default="")
    speech_region: str = Field(default="westeurope")

    # ── Database Pool ────────────────────────────────────────────────
    db_pool_min_size: int = Field(default=5)
    db_pool_max_size: int = Field(default=20)
    db_pool_max_queries: int = Field(default=50000)
    db_pool_max_inactive_connection_lifetime: float = Field(default=300.0)

    # ── Neo4j Graph Database ─────────────────────────────────────────
    neo4j_uri: str = Field(default="")
    neo4j_user: str = Field(default="")
    neo4j_password: str = Field(default="")

    # ── Neo4j_DB Graph Database (schema KG for Postgres) ────────────
    neo4j_db_uri: str = Field(default="")
    neo4j_db_user: str = Field(default="")
    neo4j_db_password: str = Field(default="")

    # ── Application ──────────────────────────────────────────────────
    app_name: str = Field(default="Knowledge Graph Assistant")
    app_version: str = Field(default="1.0.1")
    api_v1_prefix: str = Field(default="/api/v1")
    debug: bool = Field(default=False)

    # ── Server ───────────────────────────────────────────────────────
    host: str = Field(default="0.0.0.0")
    port: int = Field(default=8000)
    workers: int = Field(default=4)

    # ── CORS ─────────────────────────────────────────────────────────
    cors_origins: List[str] = Field(
        default=["http://localhost:3000", "http://localhost:8000"],
    )

    # ── Logging ──────────────────────────────────────────────────────
    log_level: str = Field(default="INFO")

    # ── Security ─────────────────────────────────────────────────────
    secret_key: str = Field(default="change-this-in-production")
    api_key: str = Field(default="")

    # ── Computed properties ──────────────────────────────────────────

    @property
    def database_url(self) -> str:
        """Async database URL (asyncpg)"""
        return (
            f"postgresql+asyncpg://{self.db_user}:{quote_plus(self.db_password)}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )

    @property
    def sync_database_url(self) -> str:
        """Sync database URL (psycopg2 / Alembic)"""
        return (
            f"postgresql://{self.db_user}:{quote_plus(self.db_password)}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )

    @property
    def neo4j_auth(self) -> tuple[str, str]:
        """Return Neo4j authentication tuple."""
        return (self.neo4j_user, self.neo4j_password)


    @property
    def neo4j_driver_config(self) -> dict:
        """Return configuration used to initialize the Neo4j driver."""
        return {
            "uri": self.neo4j_uri,
            "auth": self.neo4j_auth,
        }
    
    @property
    def neo4j_db_auth(self) -> tuple[str, str]:
        """Return Neo4j_DB (schema KG) authentication tuple."""
        return (self.neo4j_db_user, self.neo4j_db_password)

    @property
    def neo4j_db_driver_config(self) -> dict:
        """Configuration used to initialize the Neo4j_DB driver."""
        return {
            "uri": self.neo4j_db_uri,
            "auth": self.neo4j_db_auth,
        }

    @field_validator("cors_origins", mode="before")
    @classmethod
    def assemble_cors_origins(cls, v: str | List[str]) -> List[str]:
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(",")]
        return v


settings = Settings()

def get_settings() -> Settings:
    """Get application settings instance"""
    return settings
