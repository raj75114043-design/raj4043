from pydantic import BaseModel, Field
from typing import List, Optional, Any


# ──────────────────────────────────────────────
# Shared sub-models
# ──────────────────────────────────────────────

class TableColumns(BaseModel):
    """A table name paired with the matched/shared columns relevant to the query."""
    table: str
    columns: List[str] = Field(default_factory=list)


# ──────────────────────────────────────────────
# KPI
# ──────────────────────────────────────────────

class KPIResponse(BaseModel):
    name: str
    description: Optional[str] = None
    formula: Optional[str] = None
    logic: Optional[str] = None
    can_execute: Optional[bool] = None
    coverage_pct: Optional[float] = None
    matched_count: Optional[int] = None
    total_columns_extracted: Optional[int] = None
    related_tables: List[TableColumns] = Field(default_factory=list)


# ──────────────────────────────────────────────
# Keyword
# ──────────────────────────────────────────────

class KeywordResponse(BaseModel):
    name: str
    description: Optional[str] = None
    synonyms: List[str] = Field(default_factory=list)
    can_execute: Optional[bool] = None
    coverage_pct: Optional[float] = None
    matched_count: Optional[int] = None
    total_columns_extracted: Optional[int] = None
    related_tables: List[TableColumns] = Field(default_factory=list)


# ──────────────────────────────────────────────
# Question
# ──────────────────────────────────────────────

class QuestionResponse(BaseModel):
    name: str
    sql: Optional[str] = None
    can_execute: Optional[bool] = None
    coverage_pct: Optional[float] = None
    matched_count: Optional[int] = None
    total_columns_extracted: Optional[int] = None
    related_tables: List[TableColumns] = Field(default_factory=list)


# ──────────────────────────────────────────────
# Table
# ──────────────────────────────────────────────

class RelatedTable(BaseModel):
    """A table that is related to the queried table, along with relationship details."""
    table: str
    affinity_score: Optional[float] = None
    shared_column_count: Optional[int] = None
    shared_columns: List[str] = Field(default_factory=list)
    columns: List[str] = Field(default_factory=list)


class TableResponse(BaseModel):
    table: str
    column_count: Optional[int] = None
    columns: List[str] = Field(default_factory=list)
    related_tables: List[RelatedTable] = Field(default_factory=list)



# ──────────────────────────────────────────────
# Graph
# ──────────────────────────────────────────────

class GraphNode(BaseModel):
    id: str
    label: str
    type: str  # "kpi" | "keyword" | "question" | "table"


class GraphEdge(BaseModel):
    source: str
    target: str
    relation: str  # "INVOLVES" | "HAS_KEYWORD" | "SUPPORTS"
    matched_columns: List[str] = Field(default_factory=list)


class GraphRequest(BaseModel):
    kpis:      List[str] = Field(default_factory=list)
    keywords:  List[str] = Field(default_factory=list)
    questions: List[str] = Field(default_factory=list)


class GraphResponse(BaseModel):
    nodes: List[GraphNode]
    edges: List[GraphEdge]