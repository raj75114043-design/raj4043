from fastapi import APIRouter, HTTPException
from app.db.neo4j_database import get_neo4j_db_driver
from app.schemas.db_kg.schemas import (
    KPIResponse,
    KeywordResponse,
    QuestionResponse,
    RelatedTable,
    TableColumns,
    TableResponse,
)
from app.schemas.db_kg.schemas import (
    GraphNode,
    GraphEdge,
    GraphRequest,
    GraphResponse,
)

router = APIRouter(prefix="/schema-kg", tags=["Schema KG"])


# ──────────────────────────────────────────────────────────────────────────────
# HELPER
# ──────────────────────────────────────────────────────────────────────────────

def _node_to_dict(node) -> dict:
    """Convert a Neo4j Node object to a plain Python dict."""
    return dict(node)


# ──────────────────────────────────────────────────────────────────────────────
# API 1 — KPI
# Input : kpi_name
# Output: KPI properties + related tables with matched columns
# ──────────────────────────────────────────────────────────────────────────────

@router.get(
    "/kpi/{kpi_name}",
    response_model=KPIResponse,
    summary="Get KPI details with related tables and matched columns",
)
async def get_kpi(kpi_name: str):
    """
    Looks up a :KPI node by name, then traverses
        (t:Table)-[:INVOLVES]->(k:KPI)
    to return each involved table together with the matched columns stored
    on that relationship.
    """
    cypher = """
    MATCH (k:KPI {name: $name})
    OPTIONAL MATCH (t:Table)-[r:INVOLVES]->(k)
    RETURN k,
           collect({
               table:           t.name,
               matched_columns: coalesce(r.matched_columns, [])
           }) AS table_hits
    """
    driver = get_neo4j_db_driver()
    async with driver.session() as session:
        result = await session.run(cypher, name=kpi_name)
        record = await result.single()

    if not record or record["k"] is None:
        raise HTTPException(status_code=404, detail=f"KPI '{kpi_name}' not found")

    props = _node_to_dict(record["k"])
    table_hits = record["table_hits"] or []

    related_tables = [
        TableColumns(table=hit["table"], columns=hit["matched_columns"] or [])
        for hit in table_hits
        if hit.get("table")
    ]

    return KPIResponse(
        name=props.get("name", kpi_name),
        description=props.get("description"),
        formula=props.get("formula"),
        logic=props.get("logic"),
        can_execute=props.get("can_execute"),
        coverage_pct=props.get("coverage_pct"),
        matched_count=props.get("matched_count"),
        total_columns_extracted=props.get("total_columns_extracted"),
        related_tables=related_tables,
    )


# ──────────────────────────────────────────────────────────────────────────────
# API 2 — KEYWORD
# Input : keyword_name
# Output: Keyword properties + related tables with matched columns
# ──────────────────────────────────────────────────────────────────────────────

@router.get(
    "/keyword/{keyword_name}",
    response_model=KeywordResponse,
    summary="Get Keyword details with related tables and matched columns",
)
async def get_keyword(keyword_name: str):
    """
    Looks up a :Keyword node by name, then traverses
        (t:Table)-[:HAS_KEYWORD]->(kw:Keyword)
    to return each involved table together with the matched columns stored
    on that relationship.
    """
    cypher = """
    MATCH (kw:Keyword {name: $name})
    OPTIONAL MATCH (t:Table)-[r:HAS_KEYWORD]->(kw)
    RETURN kw,
           collect({
               table:           t.name,
               matched_columns: coalesce(r.matched_columns, [])
           }) AS table_hits
    """
    driver = get_neo4j_db_driver()
    async with driver.session() as session:
        result = await session.run(cypher, name=keyword_name)
        record = await result.single()

    if not record or record["kw"] is None:
        raise HTTPException(status_code=404, detail=f"Keyword '{keyword_name}' not found")

    props = _node_to_dict(record["kw"])
    table_hits = record["table_hits"] or []

    related_tables = [
        TableColumns(table=hit["table"], columns=hit["matched_columns"] or [])
        for hit in table_hits
        if hit.get("table")
    ]

    return KeywordResponse(
        name=props.get("name", keyword_name),
        description=props.get("description"),
        synonyms=props.get("synonyms") or [],
        can_execute=props.get("can_execute"),
        coverage_pct=props.get("coverage_pct"),
        matched_count=props.get("matched_count"),
        total_columns_extracted=props.get("total_columns_extracted"),
        related_tables=related_tables,
    )


# ──────────────────────────────────────────────────────────────────────────────
# API 3 — QUESTION
# Input : question_name (the question text, URL-encoded)
# Output: Question properties + related tables with matched columns
# ──────────────────────────────────────────────────────────────────────────────

@router.get(
    "/question/{question_name:path}",
    response_model=QuestionResponse,
    summary="Get Question details with related tables and matched columns",
)
async def get_question(question_name: str):
    """
    Looks up a :Question node by name, then traverses
        (t:Table)-[:SUPPORTS]->(q:Question)
    to return each involved table together with the matched columns stored
    on that relationship.

    The route uses `{question_name:path}` so that question texts containing
    slashes or special characters can be passed URL-encoded.
    """
    cypher = """
    MATCH (q:Question {name: $name})
    OPTIONAL MATCH (t:Table)-[r:SUPPORTS]->(q)
    RETURN q,
           collect({
               table:           t.name,
               matched_columns: coalesce(r.matched_columns, [])
           }) AS table_hits
    """
    driver = get_neo4j_db_driver()
    async with driver.session() as session:
        result = await session.run(cypher, name=question_name)
        record = await result.single()

    if not record or record["q"] is None:
        raise HTTPException(status_code=404, detail=f"Question '{question_name}' not found")

    props = _node_to_dict(record["q"])
    table_hits = record["table_hits"] or []

    related_tables = [
        TableColumns(table=hit["table"], columns=hit["matched_columns"] or [])
        for hit in table_hits
        if hit.get("table")
    ]

    return QuestionResponse(
        name=props.get("name", question_name),
        sql=props.get("sql"),
        can_execute=props.get("can_execute"),
        coverage_pct=props.get("coverage_pct"),
        matched_count=props.get("matched_count"),
        total_columns_extracted=props.get("total_columns_extracted"),
        related_tables=related_tables,
    )


# ──────────────────────────────────────────────────────────────────────────────
# API 4 — TABLE
# Input : table_name
# Output: Table's own columns + related tables (via RELATED_TO) with their
#         shared columns, affinity score, and each related table's own columns
# ──────────────────────────────────────────────────────────────────────────────

@router.get(
    "/table/{table_name}",
    response_model=TableResponse,
    summary="Get Table details with its columns and related tables",
)
async def get_table(table_name: str):
    """
    Looks up a :Table node by name.

    Returns:
    - The table's own column list (via HAS_COL)
    - Every related table (via RELATED_TO) with:
        - affinity_score, shared_column_count, shared_columns (from the relationship)
        - The related table's own column list (via its HAS_COL edges)
    """
    cypher = """
    MATCH (t:Table {name: $name})

    // Own columns
    OPTIONAL MATCH (t)-[:HAS_COL]->(oc:Column)

    // Related tables and their columns
    OPTIONAL MATCH (t)-[r:RELATED_TO]->(rt:Table)
    OPTIONAL MATCH (rt)-[:HAS_COL]->(rc:Column)

    WITH t,
         collect(DISTINCT oc.name)  AS own_columns,
         rt, r,
         collect(DISTINCT rc.name)  AS related_columns

    RETURN t,
           own_columns,
           collect({
               table:              rt.name,
               affinity_score:     r.affinity_score,
               shared_column_count: r.shared_column_count,
               shared_columns:     coalesce(r.shared_columns, []),
               columns:            related_columns
           }) AS related_tables
    """
    driver = get_neo4j_db_driver()
    async with driver.session() as session:
        result = await session.run(cypher, name=table_name)
        record = await result.single()

    if not record or record["t"] is None:
        raise HTTPException(status_code=404, detail=f"Table '{table_name}' not found")

    props = _node_to_dict(record["t"])
    own_columns: list = [c for c in (record["own_columns"] or []) if c]

    related_raw = record["related_tables"] or []
    related_tables = [
        RelatedTable(
            table=hit["table"],
            affinity_score=hit.get("affinity_score"),
            shared_column_count=hit.get("shared_column_count"),
            shared_columns=hit.get("shared_columns") or [],
            columns=[c for c in (hit.get("columns") or []) if c],
        )
        for hit in related_raw
        if hit.get("table")
    ]

    return TableResponse(
        table=props.get("name", table_name),
        column_count=props.get("column_count"),
        columns=own_columns,
        related_tables=related_tables,
    )


# ──────────────────────────────────────────────────────────────────────────────
# API 5 — KNOWLEDGE GRAPH
# Input : list of {type, name} items (KPIs, Keywords, Questions)
# Output: nodes + edges for graph rendering
# ──────────────────────────────────────────────────────────────────────────────

@router.post(
    "/graph",
    response_model=GraphResponse,
    summary="Build a knowledge graph for a mixed list of KPIs, Keywords, and Questions",
)
async def get_graph(request: GraphRequest):
    """
    Accepts a mixed list of KPI / Keyword / Question names.
    Returns all matching nodes, their related Table nodes, and the edges between them.
    Relationship direction is reversed for display: Item -> Table.
    matched_columns from the relationship are carried on each edge.
    """
    kpi_names      = request.kpis
    keyword_names  = request.keywords
    question_names = request.questions

    cypher = """
    // KPIs
    UNWIND $kpi_names AS kname
    MATCH (k:KPI {name: kname})
    OPTIONAL MATCH (t:Table)-[r:INVOLVES]->(k)
    WITH collect(DISTINCT {id: k.name, label: k.name, type: 'kpi'})          AS kpi_nodes,
         collect(DISTINCT {id: t.name, label: t.name, type: 'table'})        AS kpi_table_nodes,
         collect(DISTINCT {source: k.name, target: t.name,
                           relation: 'INVOLVES',
                           matched_columns: coalesce(r.matched_columns, [])}) AS kpi_edges

    // Keywords
    UNWIND $keyword_names AS kwname
    MATCH (kw:Keyword {name: kwname})
    OPTIONAL MATCH (t2:Table)-[r2:HAS_KEYWORD]->(kw)
    WITH kpi_nodes, kpi_table_nodes, kpi_edges,
         collect(DISTINCT {id: kw.name, label: kw.name, type: 'keyword'})     AS kw_nodes,
         collect(DISTINCT {id: t2.name, label: t2.name, type: 'table'})       AS kw_table_nodes,
         collect(DISTINCT {source: kw.name, target: t2.name,
                           relation: 'HAS_KEYWORD',
                           matched_columns: coalesce(r2.matched_columns, [])}) AS kw_edges

    // Questions
    UNWIND $question_names AS qname
    MATCH (q:Question {name: qname})
    OPTIONAL MATCH (t3:Table)-[r3:SUPPORTS]->(q)
    WITH kpi_nodes, kpi_table_nodes, kpi_edges,
         kw_nodes,  kw_table_nodes,  kw_edges,
         collect(DISTINCT {id: q.name, label: q.name, type: 'question'})      AS q_nodes,
         collect(DISTINCT {id: t3.name, label: t3.name, type: 'table'})       AS q_table_nodes,
         collect(DISTINCT {source: q.name, target: t3.name,
                           relation: 'SUPPORTS',
                           matched_columns: coalesce(r3.matched_columns, [])}) AS q_edges

    RETURN kpi_nodes, kpi_table_nodes, kpi_edges,
           kw_nodes,  kw_table_nodes,  kw_edges,
           q_nodes,   q_table_nodes,   q_edges
    """

    driver = get_neo4j_db_driver()
    async with driver.session() as session:
        result = await session.run(
            cypher,
            kpi_names=kpi_names or ["__none__"],
            keyword_names=keyword_names or ["__none__"],
            question_names=question_names or ["__none__"],
        )
        record = await result.single()

    if not record:
        return GraphResponse(nodes=[], edges=[])

    # Merge all nodes, deduplicate by id
    raw_nodes: dict[str, GraphNode] = {}
    for group in ["kpi_nodes", "kpi_table_nodes", "kw_nodes", "kw_table_nodes", "q_nodes", "q_table_nodes"]:
        for n in (record[group] or []):
            if n.get("id"):
                raw_nodes[n["id"]] = GraphNode(id=n["id"], label=n["label"], type=n["type"])

    # Merge all edges, deduplicate by (source, target, relation)
    raw_edges: dict[tuple, GraphEdge] = {}
    for group in ["kpi_edges", "kw_edges", "q_edges"]:
        for e in (record[group] or []):
            if e.get("source") and e.get("target"):
                key = (e["source"], e["target"], e["relation"])
                raw_edges[key] = GraphEdge(
                    source=e["source"],
                    target=e["target"],
                    relation=e["relation"],
                    matched_columns=e.get("matched_columns") or [],
                )

    return GraphResponse(
        nodes=list(raw_nodes.values()),
        edges=list(raw_edges.values()),
    )