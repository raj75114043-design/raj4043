"""
Async ETL Router for Node & Relationship Ingestion into AHLOA Neo4j
Author: Advait Shah (PwC India)
Client: Nokia
"""

from fastapi import APIRouter, HTTPException
import asyncio
import json
from pathlib import Path
import logging
from typing import List, Dict

from sqlalchemy import text

from app.db.database import AsyncSessionLocal  # Postgres session stays the same
# 🔁 Only the driver changes to AHLOA:
from app.db.neo4j_database import get_neo4j_ahloa_driver

from app.services.neo4j_builder.async_node_builder import AsyncNeo4jNodeBuilder
from app.services.neo4j_builder.async_relation_builder import AsyncNeo4jRelationBuilder

router = APIRouter(
    prefix="/etl-ahloa",
    tags=["AHLOA KG Data Sync"]
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------
# Schema Loaders (JSON under app/schemas/ahloa)  <-- Adjust if needed
# ---------------------------------------------------------------------

def _schemas_root() -> Path:
    # endpoints/ -> api/ -> app/
    return Path(__file__).resolve().parents[2] / "schemas" / "ahloa"

def load_node_schemas_ahloa() -> dict:
    """
    Loads node_schemas_new.json for AHLOA inside the FastAPI project structure.
    """
    schema_path = _schemas_root() / "node_ahloa.json"
    if not schema_path.exists():
        raise FileNotFoundError(f"Schema file not found: {schema_path}")
    with open(schema_path, "r") as f:
        return json.load(f)

def load_relation_schemas_ahloa() -> dict:
    """
    Loads relation_schemas_new.json for AHLOA inside the FastAPI project structure.
    """
    schema_path = _schemas_root() / "relation_ahloa.json"
    if not schema_path.exists():
        raise FileNotFoundError(f"Relationship schema file not found: {schema_path}")
    with open(schema_path, "r") as f:
        return json.load(f)

# ---------------------------------------------------------------------
# Workers
# ---------------------------------------------------------------------

async def run_single_node_ahloa(
    name: str,
    schema: dict,
    batch_size: int = 2000,
    max_concurrency: int = 5,
):
    """
    Full ETL for a single node: constraint + batch insert, targeting AHLOA DB.
    """
    logger.info(f"🔵 [AHLOA] ETL Started for node: {name}")

    driver = get_neo4j_ahloa_driver()

    builder = AsyncNeo4jNodeBuilder(
        node_schema=schema,
        driver=driver,
        pg_session_factory=AsyncSessionLocal,
    )

    # Step 1: constraint
    await builder.create_constraint_async()

    # Step 2: ETL run
    await builder.run(
        batch_size=batch_size,
        max_concurrency=max_concurrency,
    )

    logger.info(f"🟢 [AHLOA] ETL Completed for node: {name}")


async def run_single_relationship_ahloa(
    name: str,
    schema: dict,
    batch_size: int = 500,
    max_concurrency: int = 5,
):
    """
    Full ETL for a single relationship: fetch + batch MERGE, targeting AHLOA DB.
    """
    logger.info(f"🔵 [AHLOA] Relationship ETL Started: {name}")

    driver = get_neo4j_ahloa_driver()

    builder = AsyncNeo4jRelationBuilder(
        rel_schema=schema,
        driver=driver,
        pg_session_factory=AsyncSessionLocal,
    )

    await builder.run(
        batch_size=batch_size,
        max_concurrency=max_concurrency,
    )

    logger.info(f"🟢 [AHLOA] Relationship ETL Completed: {name}")

# ---------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------

@router.post("/run-nodes")
async def run_all_nodes_ahloa(
    max_parallel_nodes: int = 3,
    batch_size: int = 2000,
    max_batch_concurrency: int = 5,
):
    """
    Triggers async ETL for all nodes defined in AHLOA node_schemas_new.json.
    Executes ETL concurrently with concurrency limits.
    """
    try:
        node_schemas = load_node_schemas_ahloa()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"[AHLOA] Schema load failed: {e}")

    semaphore = asyncio.Semaphore(max_parallel_nodes)
    tasks = []

    async def run_with_limit(node_name, schema):
        async with semaphore:
            await run_single_node_ahloa(
                name=node_name,
                schema=schema,
                batch_size=batch_size,
                max_concurrency=max_batch_concurrency,
            )

    for name, schema in node_schemas.items():
        tasks.append(asyncio.create_task(run_with_limit(name, schema)))

    logger.info("🚀 [AHLOA] Starting ETL for ALL Neo4j nodes...")
    await asyncio.gather(*tasks)
    logger.info("🎉 [AHLOA] All nodes injected successfully!")

    return {
        "status": "success",
        "message": "[AHLOA] All Neo4j nodes ETL completed successfully.",
        "nodes_processed": list(node_schemas.keys()),
    }


@router.post("/run-relationships")
async def run_all_relationships_ahloa(
    max_parallel_relationships: int = 3,
    batch_size: int = 500,
    max_batch_concurrency: int = 5,
):
    """
    Triggers async ETL for all relationships defined in AHLOA relation_schemas_new.json.
    Executes ETL concurrently with concurrency limits.
    """
    try:
        rel_schemas = load_relation_schemas_ahloa()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"[AHLOA] Relationship schema load failed: {e}")

    semaphore = asyncio.Semaphore(max_parallel_relationships)
    tasks = []

    async def run_with_limit(rel_name, schema):
        async with semaphore:
            await run_single_relationship_ahloa(
                name=rel_name,
                schema=schema,
                batch_size=batch_size,
                max_concurrency=max_batch_concurrency,
            )

    for name, schema in rel_schemas.items():
        tasks.append(asyncio.create_task(run_with_limit(name, schema)))

    logger.info("🚀 [AHLOA] Starting ETL for ALL Neo4j relationships...")
    await asyncio.gather(*tasks)
    logger.info("🎉 [AHLOA] All relationships injected successfully!")

    return {
        "status": "success",
        "message": "[AHLOA] All Neo4j relationships ETL completed successfully.",
        "relationships_processed": list(rel_schemas.keys()),
    }

# ====================== Custom Visit Injection Endpoint ======================

# ====================== Custom Visit + Revisit Injection Endpoint ======================

@router.post("/custom-injection")
async def custom_injection_ahloa(
    batch_size: int = 1000,
    max_parallel_batches: int = 4,
):
    """
    Custom Visit + Revisit ingestion for AHLOA Neo4j DB.

    Workflow:
    1. Ensure static nodes (:Nokia, :TMobile)
    2. Fetch Visit + Revisit source rows from Postgres
    3. Ensure Neo4j constraints for Visit + Revisit
    4. Bulk upsert Visit nodes & VISITS relationships
    5. Conditionally create Revisit nodes + REJECTED relationship
    """

    driver = get_neo4j_ahloa_driver()

    # ------------------------- 1. STATIC NODES --------------------------------
    async def _create_static_nodes(tx):
        await tx.run("MERGE (:Nokia {name: 'Nokia'})")
        await tx.run("MERGE (:TMobile {name: 'TMobile'})")

    async with driver.session() as n4j_sess:
        await n4j_sess.execute_write(_create_static_nodes)
        logger.info("[AHLOA] Static nodes ensured: Nokia, TMobile")

    # ------------------------- 2. FETCH SQL DATA ------------------------------
    sql = text("""
        SELECT
            m.smp_id,
            m.smp_name,
            m.pj_project_id,
            h.check_in_status,
            h.check_in_date,
            h.ppe_photo_available,
            h.ppe_validation,
            h.jsa_completion_status,
            h.each_crew_ptid_l2w_status,

            h.non_compliance_status,
            h.market_cm_name,
            h.escalation_l1_to_gc,
            h.esaclation_l2_to_cm,
            h.esaclation_l3_to_pm,
            h.escalation_l4_pd_all,
            h.non_compliance_category,

            ROW_NUMBER() OVER (
                PARTITION BY m.pj_project_id
                ORDER BY h.check_in_date
            ) AS visit_num

        FROM pwc_macro_staging_schema.stg_ndpd_hse_site_checklist h
        JOIN pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined m
            ON h.smp_id = m.smp_id
        WHERE 
            h.check_in_status IS NOT NULL
            AND m.smp_id IS NOT NULL
            AND m.smp_name LIKE 'AHLOB Modernization';
    """)

    async with AsyncSessionLocal() as pg_sess:
        result = await pg_sess.execute(sql)
        rows = result.mappings().all()

    if not rows:
        return {
            "status": "success",
            "message": "[AHLOA] No qualifying rows found.",
            "total_rows": 0,
            "batches_processed": 0,
            "created_nodes": ["Nokia", "TMobile"],
        }

    data: List[Dict] = [dict(r) for r in rows]
    total_rows = len(data)
    logger.info(f"[AHLOA] Retrieved {total_rows} rows from Postgres")

    # ------------------------- 3. CONSTRAINTS --------------------------------
    visit_constraint = """
    CREATE CONSTRAINT visit_pk IF NOT EXISTS
    FOR (v:Visit)
    REQUIRE (v.pj_project_id, v.visit_num) IS UNIQUE
    """

    revisit_constraint = """
    CREATE CONSTRAINT revisit_pk IF NOT EXISTS
    FOR (r:Revisit)
    REQUIRE (r.pj_project_id, r.visit_num) IS UNIQUE
    """

    async with driver.session() as n4j_sess:
        await n4j_sess.run(visit_constraint)
        await n4j_sess.run(revisit_constraint)
        logger.info("[AHLOA] Constraints ensured for Visit & Revisit")

    # ------------------------- 4. CYPHER UPSERT ------------------------------
    CYPHER = """
    UNWIND $rows AS row
    MATCH (h:HSE {pj_project_id: row.pj_project_id})

    MERGE (v:Visit {
        pj_project_id: row.pj_project_id,
        visit_num: row.visit_num
    })
    SET  v.check_in_status           = row.check_in_status,
         v.check_in_date             = row.check_in_date,
         v.ppe_photo_available       = row.ppe_photo_available,
         v.ppe_validation            = row.ppe_validation,
         v.jsa_completion_status     = row.jsa_completion_status,
         v.each_crew_ptid_l2w_status = row.each_crew_ptid_l2w_status

    MERGE (h)-[:VISITS]->(v)

    WITH row, v
    WHERE row.non_compliance_status IS NULL
       OR toLower(row.non_compliance_status) CONTAINS 'not ok'

    MERGE (r:Revisit {
        pj_project_id: row.pj_project_id,
        visit_num: row.visit_num
    })
    SET r.market_cm_name          = row.market_cm_name,
        r.escalation_l1_to_gc     = row.escalation_l1_to_gc,
        r.esaclation_l2_to_cm     = row.esaclation_l2_to_cm,
        r.esaclation_l3_to_pm     = row.esaclation_l3_to_pm,
        r.escalation_l4_pd_all    = row.escalation_l4_pd_all,
        r.non_compliance_category = row.non_compliance_category

    MERGE (v)-[:REJECTED]->(r)
    """

    # ------------------------- 5. BATCHING LOGIC -----------------------------
    def _chunker(seq: List[Dict], size: int):
        for i in range(0, len(seq), size):
            yield seq[i:i + size]

    semaphore = asyncio.Semaphore(max_parallel_batches)
    batches = list(_chunker(data, batch_size))

    async def _run_batch(batch_rows: List[Dict]):
        async with semaphore:
            async with driver.session() as n4j_sess:
                async def _uow(tx):
                    await tx.run(CYPHER, rows=batch_rows)
                await n4j_sess.execute_write(_uow)

    await asyncio.gather(*[_run_batch(b) for b in batches])
    batches_processed = len(batches)

    logger.info(
        f"[AHLOA] Visit + Revisit upserts completed in {batches_processed} batches (size={batch_size})"
    )

    # ------------------------- 6. RESPONSE ----------------------------------
    return {
        "status": "success",
        "message": "[AHLOA] Visit + Revisit data injected successfully.",
        "created_nodes": ["Nokia", "TMobile"],
        "total_rows": total_rows,
        "batch_size": batch_size,
        "max_parallel_batches": max_parallel_batches,
        "batches_processed": batches_processed,
    }


@router.post("/sync-neo4j")
async def sync_neo4j_ahloa(
    node_batch_size: int = 2000,
    node_concurrency: int = 5,
    visit_batch_size: int = 1000,
    visit_concurrency: int = 4,
    relation_batch_size: int = 1000,
    relation_concurrency: int = 4,
    # Optional cleanup knobs (same defaults)
    cleanup_chunk_size: int = 20000,
    cleanup_max_loops: int = 100,
    wipe_store: bool = False,
):
    """
    FULL NEO4J SYNC PIPELINE (AHLOA):
    0. Cleanup current graph (constraints, non-lookup indexes, nodes/relationships)
    1. Run general Node ETL
    2. Run Custom Visit Injection
    3. Run general Relationship ETL
    """
    # STEP 0: ---------------------------
    # CLEANUP BEFORE INSERTS
    # -----------------------------------
    try:
        logger.info("🧹 [AHLOA] Step 0/3 — Cleaning up Neo4j (pre-sync)...")
        from app.api.endpoints.ahloa import cleanup_neo4j_ahloa
        cleanup_resp = await cleanup_neo4j_ahloa(
            chunk_size=cleanup_chunk_size,
            max_loops=cleanup_max_loops,
            wipe_store=wipe_store,
        )
        logger.info("🧽 [AHLOA] Pre-sync cleanup completed")
    except Exception as e:
        logger.error(f"❌ [AHLOA] Pre-sync cleanup failed: {e}")
        raise HTTPException(status_code=500, detail=f"[AHLOA] Pre-sync cleanup failed: {e}")

    # STEP 1: ---------------------------
    try:
        logger.info("🔵 [AHLOA] Step 1/3 — Running General Node ETL...")
        nodes_resp = await run_all_nodes_ahloa(
            batch_size=node_batch_size,
            max_batch_concurrency=node_concurrency,
            max_parallel_nodes=4
        )
        logger.info("🟢 [AHLOA] General Node ETL Completed")
    except Exception as e:
        logger.error(f"❌ [AHLOA] General Node ETL Failed: {e}")
        raise HTTPException(status_code=500, detail=f"[AHLOA] General Node ETL failed: {e}")

    # STEP 2: ---------------------------
    try:
        logger.info("🔵 [AHLOA] Step 2/3 — Running Custom Visit Injection...")
        visit_resp = await custom_injection_ahloa(
            batch_size=visit_batch_size,
            max_parallel_batches=visit_concurrency
        )
        logger.info("🟢 [AHLOA] Custom Visit Injection Completed")
    except Exception as e:
        logger.error(f"❌ [AHLOA] Custom Visit ETL Failed: {e}")
        raise HTTPException(status_code=500, detail=f"[AHLOA] Custom Visit ETL failed: {e}")

    # STEP 3: ---------------------------
    try:
        logger.info("🔵 [AHLOA] Step 3/3 — Running General Relationship ETL...")
        rel_resp = await run_all_relationships_ahloa(
            batch_size=relation_batch_size,
            max_batch_concurrency=relation_concurrency,
            max_parallel_relationships=4
        )
        logger.info("🟢 [AHLOA] General Relationship ETL Completed")
    except Exception as e:
        logger.error(f"❌ [AHLOA] Relationship ETL Failed: {e}")
        raise HTTPException(status_code=500, detail=f"[AHLOA] Relationship ETL failed: {e}")

    return {
        "status": "success",
        "message": "[AHLOA] Neo4j Full Sync Completed Successfully (with pre-sync cleanup)",
        "steps": {
            "cleanup": cleanup_resp,
            "general_nodes": nodes_resp,
            "custom_visit": visit_resp,
            "general_relationships": rel_resp
        }
    }

# ---------------------------------------------------------------------
# Cleanup (AHLOA)
# ---------------------------------------------------------------------

@router.delete("/cleanup-neo4j")
async def cleanup_neo4j_ahloa(
    chunk_size: int = 20000,
    max_loops: int = 100,
    wipe_store: bool = False,
):
    """
    Full Neo4j cleanup for the AHLOA (self-hosted Community edition) database.

    Steps:
      1. Drop all constraints (one by one via correct DDL)
      2. Drop all non-LOOKUP indexes (one by one via correct DDL)
      3. Batch DETACH DELETE all nodes + relationships

    NOTE on label/property/rel-type tokens:
      Neo4j permanently caches these internal tokens in the store files
      (neostore.labeltokenstore.*, neostore.propertystore.*, etc.). They
      CANNOT be removed while Neo4j is running — not even by Cypher.
      They only disappear after a full store wipe (offline).

    If `wipe_store=True` is passed, the endpoint will return instructions
    for the offline wipe instead of attempting it (unsafe to do live).
    """
    if wipe_store:
        return {
            "status": "manual_action_required",
            "message": "[AHLOA] To fully reset label/property tokens, follow these steps:",
            "steps": [
                "1. Stop Neo4j:  sudo systemctl stop neo4j",
                "2. Wipe data:   sudo rm -rf /var/lib/neo4j/data/databases/neo4j /var/lib/neo4j/data/transactions/neo4j",
                "3. Start Neo4j: sudo systemctl start neo4j",
                "   (Paths may differ — check neo4j.conf for 'dbms.directories.data')",
                "   Docker: docker exec <container> rm -rf /data/databases /data/transactions && restart container",
            ],
        }

    driver = get_neo4j_ahloa_driver()
    stats = {
        "constraints_dropped": 0,
        "indexes_dropped": 0,
        "nodes_deleted": 0,
        "passes": 0,
        "token_warning": (
            "Label, property-key, and relationship-type TOKENS persist in the "
            "Neo4j store even after all nodes are deleted. This is normal for "
            "Community edition. They vanish only after an offline store wipe. "
            "Pass ?wipe_store=true to this endpoint for instructions."
        ),
    }

    async with driver.session() as session:

        # ── 1. Drop all constraints individually ──────────────────────────────
        try:
            result = await session.run("SHOW CONSTRAINTS YIELD name")
            constraint_names = [record["name"] async for record in result]
            for name in constraint_names:
                try:
                    await session.run(f"DROP CONSTRAINT `{name}`")
                    stats["constraints_dropped"] += 1
                    logger.info(f"[AHLOA] Dropped constraint: {name}")
                except Exception as e:
                    logger.warning(f"[AHLOA] Could not drop constraint '{name}': {e}")
        except Exception as e:
            logger.warning(f"[AHLOA] Could not list constraints: {e}")

        # ── 2. Drop all non-LOOKUP indexes individually ───────────────────────
        try:
            result = await session.run("SHOW INDEXES YIELD name, type")
            index_names = [
                record["name"]
                async for record in result
                if record["type"] != "LOOKUP"
            ]
            for name in index_names:
                try:
                    await session.run(f"DROP INDEX `{name}`")
                    stats["indexes_dropped"] += 1
                    logger.info(f"[AHLOA] Dropped index: {name}")
                except Exception as e:
                    logger.warning(f"[AHLOA] Could not drop index '{name}': {e}")
        except Exception as e:
            logger.warning(f"[AHLOA] Could not list indexes: {e}")

        # ── 3. Batch-delete all nodes + relationships ─────────────────────────
        count_result = await session.run("MATCH (n) RETURN count(n) AS c")
        count_record = await count_result.single()
        remaining = count_record["c"] if count_record else 0
        initial_count = remaining
        loops = 0

        while remaining > 0 and loops < max_loops:
            loops += 1
            await session.run(
                """
                MATCH (n)
                WITH n LIMIT $limit
                DETACH DELETE n
                """,
                {"limit": chunk_size},
            )
            count_result = await session.run("MATCH (n) RETURN count(n) AS c")
            count_record = await count_result.single()
            new_remaining = count_record["c"] if count_record else 0

            logger.info(
                f"[AHLOA-cleanup] pass={loops} "
                f"deleted≈{remaining - new_remaining}, "
                f"remaining={new_remaining}"
            )

            if new_remaining >= remaining:
                # Nothing was deleted — bail out to avoid infinite loop
                logger.warning(
                    f"[AHLOA-cleanup] No progress after pass {loops}. "
                    f"Stopping early with {new_remaining} nodes remaining."
                )
                break
            remaining = new_remaining

        stats["nodes_deleted"] = initial_count - remaining
        stats["passes"] = loops

        # ── 4. Final state snapshot ───────────────────────────────────────────
        c = await session.run("SHOW CONSTRAINTS")
        stats["constraints_now"] = len([r async for r in c])

        i = await session.run("SHOW INDEXES YIELD name, type WHERE type <> 'LOOKUP'")
        stats["indexes_now"] = len([r async for r in i])

        n = await session.run("MATCH (n) RETURN count(n) AS c")
        stats["nodes_now"] = (await n.single())["c"]

        r = await session.run("MATCH ()-[r]->() RETURN count(r) AS c")
        stats["relationships_now"] = (await r.single())["c"]

    return {
        "status": "success" if stats["nodes_now"] == 0 else "partial",
        "message": (
            "[AHLOA] All nodes, relationships, constraints, and user indexes removed. "
            "Label/property tokens remain (see token_warning in stats). "
            "Call with ?wipe_store=true for offline reset instructions."
        ),
        "stats": stats,
    }