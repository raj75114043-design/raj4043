"""
Async Neo4j Demo Router
Shows fundamentals:
- APIRouter
- Async Neo4j queries
- Request/Response models
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from app.db.neo4j_database import get_neo4j_driver

router = APIRouter(
    prefix="/neo4j",
    tags=["Neo4j Demo (Async)"]
)


# ==================== MODELS ====================

class QueryRequest(BaseModel):
    label: str = Field(..., description="Node label to fetch")


class QueryResponse(BaseModel):
    count: int
    nodes: list[dict]


# ==================== ENDPOINTS ====================

@router.post("/get-nodes", response_model=QueryResponse)
async def get_nodes(request: QueryRequest):
    """
    Simple async Neo4j query:
    MATCH (n:<label>) RETURN n LIMIT 20
    """

    driver = get_neo4j_driver()

    try:
        query = f"MATCH (n:{request.label}) RETURN n LIMIT 20"

        async with driver.session() as session:
            result = await session.run(query)

            # Official async usage: .data() returns list of dict() rows
            records = await result.data()

        return QueryResponse(
            count=len(records),
            nodes=[record["n"] for record in records],
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Neo4j query failed: {e}")


@router.get("/ping")
async def ping_neo4j():
    """
    Quick async health check endpoint.
    """

    driver = get_neo4j_driver()

    try:
        async with driver.session() as session:
            await session.run("RETURN 1")

        return {"status": "connected"}

    except Exception:
        return {"status": "disconnected"}