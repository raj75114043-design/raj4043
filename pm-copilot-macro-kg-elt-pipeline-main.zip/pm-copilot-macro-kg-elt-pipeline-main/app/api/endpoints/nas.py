"""
Async ETL Router for Node & Relationship Ingestion into NAS Neo4j
Author: Advait Shah (PwC India)
Client: Nokia
"""

from fastapi import APIRouter, HTTPException
import asyncio
import json
from pathlib import Path
import logging
from typing import List, Dict

from sqlalchemy import text

from app.db.database import AsyncSessionLocal  # Postgres session stays the same
# 🔁 Only the driver changes to NAS:
from app.db.neo4j_database import get_neo4j_nas_driver

from app.services.neo4j_builder.async_node_builder import AsyncNeo4jNodeBuilder
from app.services.neo4j_builder.async_relation_builder import AsyncNeo4jRelationBuilder

router = APIRouter(
    prefix="/etl-nas",
    tags=["NAS KG Data Sync"]
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------
# Schema Loaders (JSON under app/schemas/nas)
# ---------------------------------------------------------------------

def _schemas_root() -> Path:
    # endpoints/ -> api/ -> app/
    return Path(__file__).resolve().parents[2] / "schemas" / "nas"

def load_node_schemas_nas() -> dict:
    """
    Loads node_nas.json for NAS inside the FastAPI project structure.
    """
    schema_path = _schemas_root() / "node_nas.json"
    if not schema_path.exists():
        raise FileNotFoundError(f"Schema file not found: {schema_path}")
    with open(schema_path, "r") as f:
        return json.load(f)

def load_relation_schemas_nas() -> dict:
    """
    Loads relation_nas.json for NAS inside the FastAPI project structure.
    """
    schema_path = _schemas_root() / "relation_nas.json"
    if not schema_path.exists():
        raise FileNotFoundError(f"Relationship schema file not found: {schema_path}")
    with open(schema_path, "r") as f:
        return json.load(f)

# ---------------------------------------------------------------------
# Workers
# ---------------------------------------------------------------------

async def run_single_node_nas(
    name: str,
    schema: dict,
    batch_size: int = 2000,
    max_concurrency: int = 5,
):
    """
    Full ETL for a single node: constraint + batch insert, targeting NAS DB.
    """
    logger.info(f"🔵 [NAS] ETL Started for node: {name}")

    driver = get_neo4j_nas_driver()

    builder = AsyncNeo4jNodeBuilder(
        node_schema=schema,
        driver=driver,
        pg_session_factory=AsyncSessionLocal,
    )

    await builder.create_constraint_async()

    await builder.run(
        batch_size=batch_size,
        max_concurrency=max_concurrency,
    )

    logger.info(f"🟢 [NAS] ETL Completed for node: {name}")


async def run_single_relationship_nas(
    name: str,
    schema: dict,
    batch_size: int = 500,
    max_concurrency: int = 5,
):
    """
    Full ETL for a single relationship: fetch + batch MERGE, targeting NAS DB.
    """
    logger.info(f"🔵 [NAS] Relationship ETL Started: {name}")

    driver = get_neo4j_nas_driver()

    builder = AsyncNeo4jRelationBuilder(
        rel_schema=schema,
        driver=driver,
        pg_session_factory=AsyncSessionLocal,
    )

    await builder.run(
        batch_size=batch_size,
        max_concurrency=max_concurrency,
    )

    logger.info(f"🟢 [NAS] Relationship ETL Completed: {name}")

# ---------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------

@router.post("/run-nodes")
async def run_all_nodes_nas(
    max_parallel_nodes: int = 3,
    batch_size: int = 2000,
    max_batch_concurrency: int = 5,
):
    """
    Triggers async ETL for all nodes defined in NAS node JSON.
    Executes ETL concurrently with concurrency limits.
    """
    try:
        node_schemas = load_node_schemas_nas()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"[NAS] Schema load failed: {e}")

    semaphore = asyncio.Semaphore(max_parallel_nodes)
    tasks = []

    async def run_with_limit(node_name, schema):
        async with semaphore:
            await run_single_node_nas(
                name=node_name,
                schema=schema,
                batch_size=batch_size,
                max_concurrency=max_batch_concurrency,
            )

    for name, schema in node_schemas.items():
        tasks.append(asyncio.create_task(run_with_limit(name, schema)))

    logger.info("🚀 [NAS] Starting ETL for ALL Neo4j nodes...")
    await asyncio.gather(*tasks)
    logger.info("🎉 [NAS] All nodes injected successfully!")

    return {
        "status": "success",
        "message": "[NAS] All Neo4j nodes ETL completed successfully.",
        "nodes_processed": list(node_schemas.keys()),
    }


@router.post("/run-relationships")
async def run_all_relationships_nas(
    max_parallel_relationships: int = 3,
    batch_size: int = 500,
    max_batch_concurrency: int = 5,
):
    """
    Triggers async ETL for all relationships defined in NAS relation JSON.
    """
    try:
        rel_schemas = load_relation_schemas_nas()
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"[NAS] Relationship schema load failed: {e}")

    semaphore = asyncio.Semaphore(max_parallel_relationships)
    tasks = []

    async def run_with_limit(rel_name, schema):
        async with semaphore:
            await run_single_relationship_nas(
                name=rel_name,
                schema=schema,
                batch_size=batch_size,
                max_concurrency=max_batch_concurrency,
            )

    for name, schema in rel_schemas.items():
        tasks.append(asyncio.create_task(run_with_limit(name, schema)))

    logger.info("🚀 [NAS] Starting ETL for ALL Neo4j relationships...")
    await asyncio.gather(*tasks)
    logger.info("🎉 [NAS] All relationships injected successfully!")

    return {
        "status": "success",
        "message": "[NAS] All Neo4j relationships ETL completed successfully.",
        "relationships_processed": list(rel_schemas.keys()),
    }

# ---------------------------------------------------------------------
# CUSTOM VISIT + REVISIT INJECTION — NAS
# ---------------------------------------------------------------------

@router.post("/custom-injection")
async def custom_injection_nas(
    batch_size: int = 1000,
    max_parallel_batches: int = 4,
):
    """
    Custom Visit + Revisit ingestion for NAS Neo4j DB.
    """
    driver = get_neo4j_nas_driver()

    # Static nodes
    async def _create_static_nodes(tx):
        await tx.run("MERGE (:Nokia {name: 'Nokia'})")
        await tx.run("MERGE (:TMobile {name: 'TMobile'})")

    async with driver.session() as n4j_sess:
        await n4j_sess.execute_write(_create_static_nodes)
        logger.info("[NAS] Static nodes ensured: Nokia, TMobile")

    # SQL FETCH
    sql = text("""
        SELECT
            m.smp_id,
            m.smp_name,
            m.pj_project_id,
            h.check_in_status,
            h.check_in_date,
            h.ppe_photo_available,
            h.ppe_validation,
            h.jsa_completion_status,
            h.each_crew_ptid_l2w_status,

            h.non_compliance_status,
            h.market_cm_name,
            h.escalation_l1_to_gc,
            h.esaclation_l2_to_cm,
            h.esaclation_l3_to_pm,
            h.escalation_l4_pd_all,
            h.non_compliance_category,

            ROW_NUMBER() OVER (
                PARTITION BY m.pj_project_id
                ORDER BY h.check_in_date
            ) AS visit_num

        FROM pwc_macro_staging_schema.stg_ndpd_hse_site_checklist h
        JOIN pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined m
            ON h.smp_id = m.smp_id
        WHERE 
            h.check_in_status IS NOT NULL
            AND m.smp_id IS NOT NULL
            AND m.smp_name LIKE 'NAS Modernization';
    """)

    async with AsyncSessionLocal() as pg_sess:
        result = await pg_sess.execute(sql)
        rows = result.mappings().all()

    if not rows:
        return {
            "status": "success",
            "message": "[NAS] No qualifying rows found.",
            "total_rows": 0,
            "batches_processed": 0,
            "created_nodes": ["Nokia", "TMobile"],
        }

    data: List[Dict] = [dict(r) for r in rows]
    total_rows = len(data)
    logger.info(f"[NAS] Retrieved {total_rows} rows from Postgres")

    # Constraints
    visit_constraint = """
    CREATE CONSTRAINT visit_pk IF NOT EXISTS
    FOR (v:Visit)
    REQUIRE (v.pj_project_id, v.visit_num) IS UNIQUE
    """

    revisit_constraint = """
    CREATE CONSTRAINT revisit_pk IF NOT EXISTS
    FOR (r:Revisit)
    REQUIRE (r.pj_project_id, r.visit_num) IS UNIQUE
    """

    async with driver.session() as n4j_sess:
        await n4j_sess.run(visit_constraint)
        await n4j_sess.run(revisit_constraint)
        logger.info("[NAS] Constraints ensured for Visit & Revisit")

    CYPHER = """
    UNWIND $rows AS row
    MATCH (h:HSE {pj_project_id: row.pj_project_id})

    MERGE (v:Visit {
        pj_project_id: row.pj_project_id,
        visit_num: row.visit_num
    })
    SET  v.check_in_status           = row.check_in_status,
         v.check_in_date             = row.check_in_date,
         v.ppe_photo_available       = row.ppe_photo_available,
         v.ppe_validation            = row.ppe_validation,
         v.jsa_completion_status     = row.jsa_completion_status,
         v.each_crew_ptid_l2w_status = row.each_crew_ptid_l2w_status

    MERGE (h)-[:VISITS]->(v)

    WITH row, v
    WHERE row.non_compliance_status IS NULL
       OR toLower(row.non_compliance_status) CONTAINS 'not ok'

    MERGE (r:Revisit {
        pj_project_id: row.pj_project_id,
        visit_num: row.visit_num
    })
    SET r.market_cm_name          = row.market_cm_name,
        r.escalation_l1_to_gc     = row.escalation_l1_to_gc,
        r.esaclation_l2_to_cm     = row.esaclation_l2_to_cm,
        r.esaclation_l3_to_pm     = row.esaclation_l3_to_pm,
        r.escalation_l4_pd_all    = row.escalation_l4_pd_all,
        r.non_compliance_category = row.non_compliance_category

    MERGE (v)-[:REJECTED]->(r)
    """

    # batching
    def _chunker(seq: List[Dict], size: int):
        for i in range(0, len(seq), size):
            yield seq[i:i + size]

    batches = list(_chunker(data, batch_size))
    semaphore = asyncio.Semaphore(max_parallel_batches)

    async def _run_batch(batch_rows: List[Dict]):
        async with semaphore:
            async with driver.session() as n4j_sess:
                async def _uow(tx):
                    await tx.run(CYPHER, rows=batch_rows)
                await n4j_sess.execute_write(_uow)

    await asyncio.gather(*[_run_batch(b) for b in batches])

    return {
        "status": "success",
        "message": "[NAS] Visit + Revisit data injected successfully.",
        "created_nodes": ["Nokia", "TMobile"],
        "total_rows": total_rows,
        "batch_size": batch_size,
        "max_parallel_batches": max_parallel_batches,
        "batches_processed": len(batches),
    }

# ---------------------------------------------------------------------
# FULL SYNC — NAS
# ---------------------------------------------------------------------

@router.post("/sync-neo4j")
async def sync_neo4j_nas(
    node_batch_size: int = 2000,
    node_concurrency: int = 5,
    visit_batch_size: int = 1000,
    visit_concurrency: int = 4,
    relation_batch_size: int = 1000,
    relation_concurrency: int = 4,
    cleanup_chunk_size: int = 20000,
    cleanup_max_loops: int = 100,
    wipe_store: bool = False,
):
    """
    FULL NEO4J SYNC PIPELINE (NAS)
    """
    try:
        logger.info("🧹 [NAS] Cleaning Neo4j...")
        from app.api.endpoints.nas import cleanup_neo4j_nas
        cleanup_resp = await cleanup_neo4j_nas(
            chunk_size=cleanup_chunk_size,
            max_loops=cleanup_max_loops,
            wipe_store=wipe_store,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"[NAS] Cleanup failed: {e}")

    try:
        nodes_resp = await run_all_nodes_nas(
            batch_size=node_batch_size,
            max_batch_concurrency=node_concurrency,
            max_parallel_nodes=4,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"[NAS] Node ETL failed: {e}")

    try:
        visit_resp = await custom_injection_nas(
            batch_size=visit_batch_size,
            max_parallel_batches=visit_concurrency,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"[NAS] Visit ETL failed: {e}")

    try:
        rel_resp = await run_all_relationships_nas(
            batch_size=relation_batch_size,
            max_batch_concurrency=relation_concurrency,
            max_parallel_relationships=4,
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"[NAS] Relationship ETL failed: {e}")

    return {
        "status": "success",
        "message": "[NAS] Full Neo4j Sync Completed Successfully",
        "steps": {
            "cleanup": cleanup_resp,
            "general_nodes": nodes_resp,
            "custom_visit": visit_resp,
            "general_relationships": rel_resp
        }
    }

# ---------------------------------------------------------------------
# CLEANUP — NAS
# ---------------------------------------------------------------------

@router.delete("/cleanup-neo4j")
async def cleanup_neo4j_nas(
    chunk_size: int = 20000,
    max_loops: int = 100,
    wipe_store: bool = False,
):
    """
    Full Neo4j cleanup for the NAS database.
    """
    if wipe_store:
        return {
            "status": "manual_action_required",
            "message": "[NAS] To fully reset label/property tokens, follow:",
            "steps": [
                "1. Stop Neo4j",
                "2. Delete neostore files",
                "3. Restart Neo4j",
            ],
        }

    driver = get_neo4j_nas_driver()
    stats = {
        "constraints_dropped": 0,
        "indexes_dropped": 0,
        "nodes_deleted": 0,
        "passes": 0,
        "token_warning": (
            "Tokens persist in Community edition. They disappear only after offline wipe."
        ),
    }

    async with driver.session() as session:
        # Drop constraints
        try:
            result = await session.run("SHOW CONSTRAINTS YIELD name")
            constraint_names = [record["name"] async for record in result]
            for name in constraint_names:
                try:
                    await session.run(f"DROP CONSTRAINT `{name}`")
                    stats["constraints_dropped"] += 1
                except:
                    pass
        except:
            pass

        # Drop indexes
        try:
            result = await session.run("SHOW INDEXES YIELD name, type")
            index_names = [
                record["name"] async for record in result if record["type"] != "LOOKUP"
            ]
            for name in index_names:
                try:
                    await session.run(f"DROP INDEX `{name}`")
                    stats["indexes_dropped"] += 1
                except:
                    pass
        except:
            pass

        # Delete nodes in batches
        count_result = await session.run("MATCH (n) RETURN count(n) AS c")
        count_record = await count_result.single()
        remaining = count_record["c"]
        initial_count = remaining
        loops = 0

        while remaining > 0 and loops < max_loops:
            loops += 1
            await session.run("""
                MATCH (n) 
                WITH n LIMIT $limit 
                DETACH DELETE n
            """, {"limit": chunk_size})

            count_result = await session.run("MATCH (n) RETURN count(n) AS c")
            remaining = (await count_result.single())["c"]

        stats["nodes_deleted"] = initial_count - remaining
        stats["passes"] = loops

    return {
        "status": "success" if remaining == 0 else "partial",
        "message": "[NAS] Neo4j cleanup complete.",
        "stats": stats,
    }