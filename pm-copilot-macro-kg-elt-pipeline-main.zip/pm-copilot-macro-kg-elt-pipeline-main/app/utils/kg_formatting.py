# app/utils/kg_formatting.py
from typing import Dict, List, Any
from collections import OrderedDict

def build_kg_edges(context_per_item: Dict[str, Any]) -> Dict[str, List[str]]:
    """
    Convert ContextPerItemResponse (dict) into two lists of human-readable edges:
      - item_to_table:  "From: <item> (<type>) → <table>"
      - table_to_column:"From: <table> → <column>"

    The function is resilient to missing keys and deduplicates edges.
    """
    items = context_per_item.get("items", []) or []

    item_to_table: "OrderedDict[str, None]" = OrderedDict()
    table_to_column: "OrderedDict[str, None]" = OrderedDict()

    for it in items:
        name = it.get("name")
        typ  = it.get("type")
        for t in it.get("tables", []) or []:
            tbl = t.get("table")
            cols = t.get("columns") or []
            if name and typ and tbl:
                item_to_table[f"From: {name} ({typ}) → {tbl}"] = None
            if tbl:
                for c in cols:
                    if c:
                        table_to_column[f"From: {tbl} → {c}"] = None

    return {
        "item_to_table": list(item_to_table.keys()),
        "table_to_column": list(table_to_column.keys()),
    }