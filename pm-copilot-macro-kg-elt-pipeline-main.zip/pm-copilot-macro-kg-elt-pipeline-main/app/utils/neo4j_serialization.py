# app/utils/neo4j_serialization.py
from neo4j.time import Date, DateTime, Time, Duration

def serialize_neo4j_value(value):
    """Convert Neo4j temporal objects into JSON-safe primitives."""
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value

    if isinstance(value, list):
        return [serialize_neo4j_value(v) for v in value]

    if isinstance(value, dict):
        return {k: serialize_neo4j_value(v) for k, v in value.items()}

    # Neo4j temporal types
    if isinstance(value, DateTime):
        return value.isoformat()

    if isinstance(value, Date):
        return value.isoformat()

    if isinstance(value, Time):
        return value.isoformat()

    if isinstance(value, Duration):
        # Convert to ISO duration (e.g. P3DT4H)
        return f"P{value.days}DT{value.hours}H{value.minutes}M{value.seconds}S"

    # Last resort: string conversion
    return str(value)