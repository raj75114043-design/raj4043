from pathlib import Path
import json


def load_node_schemas(path):
    path = Path(path)

    if not path.exists():
        raise FileNotFoundError(f"Schema file not found: {path.resolve()}")

    with open(path, "r") as f:
        return json.load(f)
