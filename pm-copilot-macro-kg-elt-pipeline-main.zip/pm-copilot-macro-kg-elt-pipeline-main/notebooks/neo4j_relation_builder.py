from typing import Any, Dict, List, Optional, Set, Tuple
import time
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
from neo4j.exceptions import TransientError


# Neo4j error codes that are safe to retry
_RETRYABLE_CODES: Set[str] = {
    "Neo.TransientError.Transaction.LockClientStoppedException",
    "Neo.TransientError.Transaction.DeadlockDetected",
    "Neo.TransientError.General.MemoryPoolOutOfMemoryError",
    "Neo.TransientError.Transaction.Outdated",
    "Neo.TransientError.Transaction.ConstraintsChanged",
}


def _is_retryable(exc: Exception) -> bool:
    """Return True if the exception is a Neo4j lock / transient error."""
    if isinstance(exc, TransientError):
        return True
    code = getattr(exc, "code", "") or ""
    return any(code.startswith(rc) for rc in _RETRYABLE_CODES)


class Neo4jRelationBuilder:
    """
    Handles ETL and Neo4j injection for a single relationship in a graph schema.

    Schema format
    -------------
    {
        'type':       'BELONGS_TO',        # relationship label
        'from_node':  'Site',              # source node label
        'from_key':   'site_id',           # PK/property to MATCH source node
                                           # omit or set None for singleton nodes
        'to_node':    'GlobalConfig',      # target node label
        'to_key':     None,                # None → singleton: MATCH (b:GlobalConfig)
        'SQL_ETL':    'SELECT site_id, weight FROM ...'
                      # present keys   → MATCH columns
                      # None/absent keys → label-only MATCH (singleton node)
                      # everything else  → relationship properties (optional)
    }

    Column role inference
    ---------------------
    Given SQL result columns [site_id, region_id, weight, since]:
      • site_id   == from_key         → MATCH source node by property
      • region_id == to_key           → MATCH target node by property
      • weight, since                 → SET r.weight, r.since  (all remaining cols)

    Singleton node (no key):
      • from_key / to_key = None      → MATCH (x:Label)  — no property filter
      • that column is NOT expected in the SQL result
      • all non-key SQL columns → relationship properties

    Three public methods
    --------------------
    fetch_data()        Pull the single SQL_ETL query into one DataFrame and
                        auto-derive mapping keys vs. relationship properties.
    build_query()       Build an UNWIND Cypher MATCH...MERGE query.
    inject_batches()    Parallel batch injection with automatic recovery of
                        failed rows (lock errors -> retry queue -> repeat until clear).
    run()               Convenience wrapper: fetch -> inject in one call.
    """

    def __init__(
        self,
        rel_schema: Dict[str, Any],
        driver,
        pg_query_fn,
    ):
        self.rel_type:  str           = rel_schema["type"]
        self.from_node: str           = rel_schema["from_node"]
        self.from_key:  Optional[str] = rel_schema.get("from_key") or None
        self.to_node:   str           = rel_schema["to_node"]
        self.to_key:    Optional[str] = rel_schema.get("to_key") or None
        self.sql_etl:   str           = rel_schema["SQL_ETL"]

        self.driver      = driver
        self.pg_query_fn = pg_query_fn

        # Derived after fetch_data() — the non-key columns become rel properties
        self.properties: List[str] = []
        self._cypher:    Optional[str] = None

    # ------------------------------------------------------------------
    # 1. Data fetching
    # ------------------------------------------------------------------

    def fetch_data(self) -> pd.DataFrame:
        """
        Execute SQL_ETL and return a clean DataFrame.

        Column role inference
        ---------------------
        - from_key column  -> used in MATCH (source node)
        - to_key column    -> used in MATCH (target node)
        - everything else  -> relationship properties (SET r.<col> = row.<col>)

        Returns
        -------
        df : DataFrame containing from_key, to_key, and any property columns.
        """
        df: pd.DataFrame = self.pg_query_fn(self.sql_etl)

        # Validate that key columns declared in schema are present in the result.
        # None keys = singleton node — no column expected in SQL for that side.
        declared_keys = {k for k in [self.from_key, self.to_key] if k is not None}
        for col in declared_keys:
            if col not in df.columns:
                raise ValueError(
                    f"[{self.rel_type}] Key column '{col}' missing from SQL_ETL result. "
                    f"Available columns: {list(df.columns)}"
                )

        # Derive relationship properties = every column that is NOT a declared key
        self.properties = [c for c in df.columns if c not in declared_keys]

        # Logging
        from_desc = f"{self.from_key}" if self.from_key else f"(singleton {self.from_node})"
        to_desc   = f"{self.to_key}"   if self.to_key   else f"(singleton {self.to_node})"
        if self.properties:
            print(f"[{self.rel_type}] From key      : {from_desc}")
            print(f"[{self.rel_type}] To key        : {to_desc}")
            print(f"[{self.rel_type}] Rel properties: {self.properties}")
        else:
            print(f"[{self.rel_type}] From: {from_desc} | To: {to_desc} | (no rel properties)")

        # Clean up
        df = df.where(pd.notnull(df), other=None)

        # Dedup — only on the columns that actually exist
        dedup_cols = [k for k in [self.from_key, self.to_key] if k is not None]
        if dedup_cols:
            before = len(df)
            df = df.drop_duplicates(subset=dedup_cols)
            dropped = before - len(df)
            if dropped:
                print(f"[{self.rel_type}] Dropped {dropped} duplicate (from, to) pairs.")

        # Invalidate cached query so it is rebuilt with the correct properties
        self._cypher = None

        print(f"[{self.rel_type}] Fetched {len(df)} rows from Postgres.")
        return df

    # ------------------------------------------------------------------
    # 2. Query construction
    # ------------------------------------------------------------------

    def build_query(self) -> str:
        """
        Build and cache the UNWIND Cypher query.

        Each element in $rows is a flat dict with from_key, to_key,
        and any property columns — exactly the columns from fetch_data().

        Example output (with properties)
        ---------------------------------
        UNWIND $rows AS row
        MATCH (a:Site   {site_id:   row.site_id})
        MATCH (b:Region {region_id: row.region_id})
        MERGE (a)-[r:BELONGS_TO]->(b)
        SET
          r.weight = row.weight,
          r.since  = row.since

        Example output (no properties)
        --------------------------------
        UNWIND $rows AS row
        MATCH (a:Site   {site_id:   row.site_id})
        MATCH (b:Region {region_id: row.region_id})
        MERGE (a)-[r:BELONGS_TO]->(b)
        """
        if self._cypher is not None:
            return self._cypher

        # MATCH clause for each side:
        #   - key present  → MATCH (x:Label {key: row.key})
        #   - key is None  → MATCH (x:Label)   singleton, no property filter
        if self.from_key:
            from_match = f"MATCH (a:{self.from_node} {{{self.from_key}: row.{self.from_key}}})"
        else:
            from_match = f"MATCH (a:{self.from_node})"

        if self.to_key:
            to_match = f"MATCH (b:{self.to_node}   {{{self.to_key}:   row.{self.to_key}}})"
        else:
            to_match = f"MATCH (b:{self.to_node})"

        lines = [
            "UNWIND $rows AS row",
            from_match,
            to_match,
            f"MERGE (a)-[r:{self.rel_type}]->(b)",
        ]

        if self.properties:
            set_clauses = ",\n  ".join(
                f"r.{prop} = row.{prop}" for prop in self.properties
            )
            lines.append(f"SET\n  {set_clauses}")

        self._cypher = "\n".join(lines)
        return self._cypher

    def display_query(self) -> None:
        """Pretty-print the generated Cypher query."""
        print("=" * 72)
        print(f"CYPHER QUERY  —  Relationship: {self.rel_type}")
        print("=" * 72)
        print(self.build_query())
        print("=" * 72)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _split_into_batches(
        records: List[Dict[str, Any]], batch_size: int
    ) -> List[List[Dict[str, Any]]]:
        return [
            records[i : i + batch_size]
            for i in range(0, len(records), batch_size)
        ]

    def _inject_single_batch(
        self,
        batch: List[Dict[str, Any]],
        batch_idx: int,
        retry_delay: float,
    ) -> Tuple[int, List[Dict[str, Any]]]:
        """
        Inject one batch inside its own Neo4j session.

        Returns
        -------
        (rows_written, failed_rows)
            failed_rows is non-empty only on retryable failures.
        """
        cypher = self.build_query()
        try:
            with self.driver.session() as session:
                session.execute_write(lambda tx: tx.run(cypher, rows=batch))
            return len(batch), []

        except Exception as exc:
            if _is_retryable(exc):
                print(
                    f"[{self.rel_type}] Batch {batch_idx} hit retryable error "
                    f"({type(exc).__name__}: {exc}). Queued for recovery."
                )
                time.sleep(retry_delay)
                return 0, list(batch)
            else:
                print(
                    f"[{self.rel_type}] Batch {batch_idx} FAILED (non-retryable): {exc}"
                )
                return 0, []

    # ------------------------------------------------------------------
    # 3. Parallel batch injection with recovery loop
    # ------------------------------------------------------------------

    def inject_batches(
        self,
        df: Optional[pd.DataFrame] = None,
        batch_size: int = 500,
        max_workers: int = 4,
        max_recovery_rounds: int = 10,
        recovery_batch_size: Optional[int] = None,
        retry_delay: float = 0.5,
    ) -> None:
        """
        Split df into batches and inject in parallel.

        Any batch that fails with a Neo4j lock / transient error is collected
        into a recovery queue and retried (at recovery_batch_size) in the next
        round — until all rows are written or max_recovery_rounds is exhausted.

        Args
        ----
        df                   : DataFrame to inject. Calls fetch_data() if None.
        batch_size           : Rows per batch for the initial pass (n).
        max_workers          : Parallel threads (m).
        max_recovery_rounds  : Max retry iterations for lock-failed rows.
        recovery_batch_size  : Batch size during recovery (default: batch_size // 2).
        retry_delay          : Seconds to back-off before re-queuing a failed batch.
        """
        if df is None:
            df = self.fetch_data()

        if df.empty:
            print(f"[{self.rel_type}] DataFrame is empty — nothing to inject.")
            return

        rec_batch_size = recovery_batch_size or max(1, batch_size // 2)
        total_rows    = len(df)
        total_written = 0
        round_num     = 0
        pending       = self._split_into_batches(
            df.to_dict(orient="records"), batch_size
        )

        print(
            f"[{self.rel_type}] Starting injection: {total_rows} rows | "
            f"batch_size={batch_size} | workers={max_workers}"
        )

        while pending:
            round_num += 1
            is_recovery = round_num > 1

            if is_recovery:
                if round_num - 1 > max_recovery_rounds:
                    unresolved = sum(len(b) for b in pending)
                    print(
                        f"[{self.rel_type}] X Max recovery rounds ({max_recovery_rounds}) "
                        f"reached. {unresolved} rows could not be injected."
                    )
                    break

                # Re-split into smaller batches to reduce lock contention
                flat = [row for batch in pending for row in batch]
                pending = self._split_into_batches(flat, rec_batch_size)
                print(
                    f"[{self.rel_type}] -- Recovery round {round_num - 1}: "
                    f"{len(flat)} rows | "
                    f"{len(pending)} batches | size={rec_batch_size} --"
                )

            workers      = min(max_workers, len(pending))
            next_pending: List[List[Dict[str, Any]]] = []

            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = {
                    pool.submit(
                        self._inject_single_batch, batch, idx, retry_delay
                    ): (idx, batch)
                    for idx, batch in enumerate(pending)
                }

                for future in as_completed(futures):
                    idx, original_batch = futures[future]
                    try:
                        written, failed_rows = future.result()
                        total_written += written

                        if failed_rows:
                            next_pending.extend(
                                self._split_into_batches(failed_rows, rec_batch_size)
                            )
                        else:
                            status = "OK" if written > 0 else "SKIPPED (non-retryable)"
                            print(
                                f"[{self.rel_type}] "
                                f"R{round_num} Batch {idx + 1}/{len(pending)} "
                                f"-- {written} rows {status}  "
                                f"(total: {total_written}/{total_rows})"
                            )

                    except Exception as exc:
                        print(
                            f"[{self.rel_type}] "
                            f"R{round_num} Batch {idx + 1} unexpected error: {exc}"
                        )
                        next_pending.extend(
                            self._split_into_batches(original_batch, rec_batch_size)
                        )

            pending = next_pending

        remaining = total_rows - total_written
        if remaining == 0:
            print(
                f"[{self.rel_type}] Injection complete. "
                f"All {total_written} rows written in {round_num} round(s)."
            )
        else:
            print(
                f"[{self.rel_type}] Injection finished with issues. "
                f"Written: {total_written}/{total_rows} | "
                f"Unresolved: {remaining} rows after {round_num} round(s)."
            )

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    def run(
        self,
        batch_size: int = 500,
        max_workers: int = 4,
        max_recovery_rounds: int = 10,
        recovery_batch_size: Optional[int] = None,
        retry_delay: float = 0.5,
    ) -> None:
        """Fetch data from Postgres and inject into Neo4j in one step."""
        df = self.fetch_data()
        self.inject_batches(
            df=df,
            batch_size=batch_size,
            max_workers=max_workers,
            max_recovery_rounds=max_recovery_rounds,
            recovery_batch_size=recovery_batch_size,
            retry_delay=retry_delay,
        )