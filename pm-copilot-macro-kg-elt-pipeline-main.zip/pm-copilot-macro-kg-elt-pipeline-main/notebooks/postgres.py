import os
import psycopg2
import pandas as pd
from typing import Optional
from contextlib import contextmanager
from dotenv import load_dotenv
from sqlalchemy import create_engine
from sqlalchemy.engine import URL
from sqlalchemy import create_engine, text, inspect


load_dotenv()

class DatabaseConnection:
    def __init__(self):
        self.connection_params = {
            "dbname": os.environ["DB_NAME"],
            "user": os.environ["DB_USER"],
            "password": os.environ["DB_PASSWORD"],
            "host": os.environ["DB_HOST"],
            "port": os.environ["DB_PORT"]
        }

        # Validate connection parameters
        if not all(self.connection_params.values()):
            missing_params = [k for k, v in self.connection_params.items() if not v]
            raise ValueError(f"Missing database connection parameters: {', '.join(missing_params)}")

        self._connection = None

    @contextmanager
    def get_connection(self):
        """Context manager for database connections"""
        try:
            if self._connection is None or self._connection.closed:
                self._connection = psycopg2.connect(**self.connection_params)
            yield self._connection
        except psycopg2.Error as e:
            if self._connection and not self._connection.closed:
                self._connection.close()
                self._connection = None
            raise ConnectionError(f"Failed to connect to database: {str(e)}") from e
        except Exception as e:
            if self._connection and not self._connection.closed:
                self._connection.close()
                self._connection = None
            raise Exception(f"Unexpected error during connection: {str(e)}") from e

    def close_connection(self):
        """Safely close the database connection"""
        try:
            if self._connection and not self._connection.closed:
                self._connection.close()
        finally:
            self._connection = None

    def __del__(self):
        """Destructor to ensure connection is closed"""
        self.close_connection()


# Create a singleton instance
DB_CONN = DatabaseConnection()

def query_execution_postgres_db(sql_query: str) -> pd.DataFrame:
    """
    Execute SQL query and return results as DataFrame

    Args:
        sql_query (str): SQL query to execute
        db_connection (DatabaseConnection, optional): Database connection manager. 
            If None, uses the default DB_CONN.

    Returns:
        pd.DataFrame: Query results

    Raises:
        ValueError: For empty queries or non-SELECT statements
        Exception: For database operation failures
    """
    # print(sql_query)
    if not sql_query or not sql_query.strip():
        raise ValueError("SQL query is empty or blank: db_executer")

    # Use default connection if none provided
    db_connection = DB_CONN

    try:
        with db_connection.get_connection() as conn:
            with conn.cursor() as cur:

                schema_name = "osdp_pwc_sch"  # <-- change schema as needed
                # cur.execute(f"SET search_path TO {schema_name}")

                cur.execute("BEGIN;")

                cur.execute("SHOW search_path;")
                before_path = cur.fetchone()[0]
                print(f"Before SET LOCAL, search_path = {before_path}")

                # Set schema path for this transaction only
                cur.execute(f"SET LOCAL search_path TO {schema_name};")

                cur.execute("SHOW search_path;")
                during_exec_path = cur.fetchone()[0]
                print(f"After Executing Query, search_path = {during_exec_path}")

                # Run the actual query
                cur.execute(sql_query)

                if not cur.description:
                    raise ValueError("Query is not a SELECT statement")

                columns = [col.name for col in cur.description]
                data = cur.fetchall()

                # Commit the transaction
                cur.execute("COMMIT;")

                cur.execute("SHOW search_path;")
                after_path = cur.fetchone()[0]
                print(f"After Executing Query, search_path = {after_path}")

                return pd.DataFrame(data, columns=columns)

    except (psycopg2.Error, Exception) as e:
        error_msg = f"Database operation failed: {str(e)}"
        db_connection.close_connection()  # Ensure connection is closed on error
        raise Exception(error_msg) from e

    finally:
        # Optional: if you want to close the connection after each query
        # Comment this out if you want to keep connections alive for reuse
        db_connection.close_connection()