from typing import Any, Dict, List, Optional
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed


class Neo4jNodeBuilder:
    """
    Handles ETL and Neo4j injection for a single node in a graph schema.

    Responsibilities:
      1. fetch_data()     - Postgres -> Dataframe using the node's SQL_ETL query.
      2. build_query()    - Dataframe -> Neo4j (Step1 - Build cypher code for bulk insert with UNWIND & MERGE)
      3. inject_batches() - Dataframe -> Neo4j (Step2 - Actual bulk insert) Split the DataFrame into m batches of size n and
                            inject them in parallel using a thread pool.

    Args:
        node_schema: A dict describing one node, e.g.:
            {
                'label': 'Site',
                'primary_key': 'pj_project_id',
                'properties': ['m_area', 'pj_project_name', ...],
                'SQL_ETL': 'SELECT ... FROM ...'
            }
        driver: An active neo4j.GraphDatabase driver instance.
        pg_query_fn: A callable(sql: str) -> pd.DataFrame that executes
                     SQL against Postgres (e.g. query_execution_postgres_db).
    """

    # ------------------------------------------------------------------
    # 0. Constructor
    # ------------------------------------------------------------------

    def __init__(
        self,
        node_schema: Dict[str, Any],
        driver,
        pg_query_fn,
    ):
        self.label = node_schema["label"]
        self.primary_key = node_schema["primary_key"]
        
        # Remove duplicate properties while preserving their original order
        
        seen = set()
        self.properties: List[str] = []
        for p in node_schema.get("properties", []):
            if p not in seen:
                seen.add(p)
                self.properties.append(p)

        self.sql_etl: str = node_schema["SQL_ETL"]
        self.driver = driver
        self.pg_query_fn = pg_query_fn

        # All columns required cols from Postgres

        self.required_columns: List[str] = list(
            dict.fromkeys([self.primary_key] + self.properties)
        )

        self._cypher: Optional[str] = None  # built lazily / on demand

    # ------------------------------------------------------------------
    # 1. Data fetching
    # ------------------------------------------------------------------

    def fetch_data(self) -> pd.DataFrame:
        """
        Execute SQL_ETL against Postgres and return a cleaned DataFrame.

        - Only the columns declared in the schema are kept.
        - NaN values are replaced with None (Neo4j-safe).
        - Duplicate rows (by primary key) are dropped. (Highly impoertant process)

        Returns:
            pd.DataFrame with exactly the required columns.
        """
        df: pd.DataFrame = self.pg_query_fn(self.sql_etl)

        # Keep only the columns the schema cares about

        missing = [c for c in self.required_columns if c not in df.columns]
        if missing:
            raise ValueError(
                f"[{self.label}] Columns missing from SQL result: {missing}"
            )
        df = df[self.required_columns].copy()

        # Replace NaN → None so Neo4j driver handles them as null

        df = df.where(pd.notnull(df), other=None)

        # Drop duplicates on primary key to avoid redundant MERGE churn

        before = len(df)
        df = df.drop_duplicates(subset=[self.primary_key])
        dropped = before - len(df)
        if dropped:
            print(f"[{self.label}] Dropped {dropped} duplicate rows on '{self.primary_key}'.")

        print(f"[{self.label}] Fetched {len(df)} rows from Postgres.")
        return df

    # ------------------------------------------------------------------
    # 2. Query construction
    # ------------------------------------------------------------------

    def build_query(self) -> str:
        """
        Build and cache the UNWIND Cypher MERGE query for this node.

        The query expects a parameter named 'rows' which is a list of dicts,
        each dict keyed by the column names declared in the schema.

        Example output
        --------------
        UNWIND $rows AS row
        MERGE (n:Site {pj_project_id: row.pj_project_id})
        SET
          n.m_area             = row.m_area,
          n.m_market           = row.m_market,
          n.pj_project_id      = row.pj_project_id,
          n.pj_project_name    = row.pj_project_name,
          ...
        """
        if self._cypher is not None:
            return self._cypher
        
        # ---------------------------------
        # Injection cypher code starts here
        # ---------------------------------

        # Set / accumulate all properties
        set_clauses = ",\n  ".join(
            f"n.{prop} = row.{prop}" for prop in self.properties
        )
        
        # Create / Merge the node with primary key
        pk = self.primary_key
        
        query = (
            f"UNWIND $rows AS row\n"
            f"MERGE (n:{self.label} {{{pk}: row.{pk}}})\n"
            f"SET n = {{}}\n"          # ← wipe existing props first
            f"SET n.{pk} = row.{pk}\n" # ← re-set primary key
        )

        # Add all the accumulated / set properties to the injection code
        if set_clauses:
            query += f"SET\n  {set_clauses}"

        # ---------------------------------
        # Injection cypher code ends here
        # ---------------------------------   

        self._cypher = query.strip()
        return self._cypher

    def display_query(self) -> None:
        """Pretty-print the generated Cypher query."""
        print("=" * 72)
        print(f"CYPHER QUERY  —  Node: {self.label}")
        print("=" * 72)
        print(self.build_query())
        print("=" * 72)

    # ------------------------------------------------------------------
    # 3. Batch injection helpers
    # ------------------------------------------------------------------

    def _split_into_batches(
        self,
        df: pd.DataFrame, batch_size: int
    ) -> List[List[Dict[str, Any]]]:
        """
        Convert a DataFrame into a list of row-dicts lists, each of length
        at most *batch_size*.
        """
        records = df.to_dict(orient="records")

        normalized = [
            {col: row.get(col, None) for col in self.required_columns}
            for row in records
        ]

        return [
            normalized[i : i + batch_size]
            for i in range(0, len(normalized), batch_size)
        ]

    def _inject_single_batch(
        self, batch: List[Dict[str, Any]], batch_idx: int
    ) -> int:
        """
        Open a dedicated Neo4j session and write one batch inside a single
        transaction.  Returns the number of rows written.
        """
        cypher = self.build_query()

        with self.driver.session() as session:
            session.execute_write(lambda tx: tx.run(cypher, rows=batch))

        return len(batch)

    def inject_batches(
        self,
        df: Optional[pd.DataFrame] = None,
        batch_size: int = 500,
        max_workers: int = 4,
    ) -> None:
        """
        Split *df* into batches of *batch_size* rows and inject them in
        parallel using *max_workers* threads.

        Args:
            df:          DataFrame to inject.  If None, fetch_data() is
                         called automatically.
            batch_size:  Number of rows per batch (n).
            max_workers: Number of parallel threads (m ≈ ceil(len/batch_size),
                         capped at max_workers).
        """
        if df is None:
            df = self.fetch_data()

        if df.empty:
            print(f"[{self.label}] DataFrame is empty — nothing to inject.")
            return

        batches = self._split_into_batches(df, batch_size)
        num_batches = len(batches)
        workers = min(max_workers, num_batches)

        print(
            f"[{self.label}] Injecting {len(df)} rows "
            f"in {num_batches} batches (size={batch_size}) "
            f"with {workers} parallel workers …"
        )

        total_written = 0
        failed_batches = 0

        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(self._inject_single_batch, batch, idx): idx
                for idx, batch in enumerate(batches)
            }

            for future in as_completed(futures):
                idx = futures[future]
                try:
                    written = future.result()
                    total_written += written
                    print(
                        f"[{self.label}] Batch {idx + 1}/{num_batches} "
                        f"— {written} rows OK  "
                        f"(total so far: {total_written})"
                    )
                except Exception as exc:
                    failed_batches += 1
                    print(
                        f"[{self.label}] Batch {idx + 1}/{num_batches} "
                        f"FAILED: {exc}"
                    )

        status = "✓ complete" if failed_batches == 0 else f"⚠ {failed_batches} batch(es) failed"
        print(
            f"[{self.label}] Injection {status}. "
            f"Rows written: {total_written}/{len(df)}"
        )

    # ------------------------------------------------------------------
    # Convenience: run the full ETL → inject pipeline in one call
    # ------------------------------------------------------------------

    def run(self, batch_size: int = 500, max_workers: int = 4) -> None:
        """Fetch data from Postgres and inject into Neo4j in one step."""
        df = self.fetch_data()
        self.inject_batches(df=df, batch_size=batch_size, max_workers=max_workers)