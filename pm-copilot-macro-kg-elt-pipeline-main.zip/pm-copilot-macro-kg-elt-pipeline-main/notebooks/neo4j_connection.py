import os
from neo4j import GraphDatabase
from dotenv import load_dotenv


class Neo4jConnection:
    """
    Creates and manages a Neo4j driver instance.
    Loads credentials from .env by default.
    """

    def __init__(
        self,
        uri: str = None,
        user: str = None,
        password: str = None,
    ):
        load_dotenv()

        self.uri = uri or os.getenv("NEO4J_URI")
        self.user = user or os.getenv("NEO4J_USER")
        self.password = password or os.getenv("NEO4J_PASSWORD")

        if not all([self.uri, self.user, self.password]):
            raise ValueError("Missing Neo4j connection environment variables")

        self._driver = None

    def get_driver(self):
        if self._driver is None:
            self._driver = GraphDatabase.driver(
                self.uri,
                auth=(self.user, self.password),
            )
        return self._driver

    def close(self):
        if self._driver:
            self._driver.close()
            self._driver = None
