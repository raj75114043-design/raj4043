from langchain_openai import ChatOpenAI


class LLMProvider:
    LLM_BASE_URL = "https://llmgateway-qa-api.nokia.com/v1.2/"
    API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyTmFtZSI6IlJvbGxvdXRBZ2VudERldlRvb2wiLCJPYmplY3RJRCI6IjNGRUY4NzI0LUE5RTItNDMyQy1COTk4LTU0NDMwMEZBQjcxMyIsIndvcmtTcGFjZU5hbWUiOiJWUjE4NTdSb2xsb3V0QWdlbnREZXZTcGFjZSIsIm5iZiI6MTc3MDg4NTYyNCwiZXhwIjoxODAyNDIxNjI0LCJpYXQiOjE3NzA4ODU2MjR9.HvO_kB6UNwcNSV4B_MXuh9OK54rYtRRDMPH5Y1EuOhc"
    WORKSPACE = "VR1857RolloutAgentDevSpace"

    def __init__(self, model="gpt-4o-mini", temperature=0.2, reasoning_effort="low"):
        self.llm = ChatOpenAI(
            api_key=self.API_KEY,
            model=model,
            base_url=self.LLM_BASE_URL,
            default_headers={
                'api-key': self.API_KEY,
                'workspacename': self.WORKSPACE
            },
            temperature=temperature,
            max_tokens=16384,
            verbose=True,
            reasoning_effort=reasoning_effort,
        )

    def get_llm(self):
        return self.llm

    def invoke(self, messages):
        return self.llm.invoke(messages)

    def stream(self, messages):
        return self.llm.stream(messages)

    async def ainvoke(self, messages):
        return await self.llm.ainvoke(messages)