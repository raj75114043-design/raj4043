"""
Configuration settings for the Simulation Agent system.
"""
import os
from dataclasses import dataclass, field
from typing import Optional
from pydantic import Field


@dataclass
class Neo4jConfig:
    uri: str = os.getenv("NEO4J_URI", "neo4j://127.0.0.1:7687")
    user: str = os.getenv("NEO4J_USER", "neo4j")
    password: str = os.getenv("NEO4J_PASSWORD", "password")
    database: str = os.getenv("NEO4J_DATABASE", "nokia-v-one")


@dataclass
class LLMConfig:
    model: str = os.getenv("LLM_MODEL", "gpt-4o")
    fast_model: str = os.getenv("LLM_FAST_MODEL", "gpt-4o-mini")  # For synthesis/formatting tasks
    temperature: float = 0.0  # Deterministic for planning
    # max_tokens: int = 4096
    api_key: Optional[str] = os.getenv("OPENAI_API_KEY")
    llm_base_url: str = os.getenv("LLM_BASE_URL", "https://llmgateway-qa-api.nokia.com/v1.2/")
    llm_api_key_header: str = os.getenv("LLM_API_KEY_HEADER", "api-key")
    llm_api_key_value: str = os.getenv("LLM_API_KEY_VALUE", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyTmFtZSI6IlJvbGxvdXRBZ2VudERldlRvb2wiLCJPYmplY3RJRCI6IjNGRUY4NzI0LUE5RTItNDMyQy1COTk4LTU0NDMwMEZBQjcxMyIsIndvcmtTcGFjZU5hbWUiOiJWUjE4NTdSb2xsb3V0QWdlbnREZXZTcGFjZSIsIm5iZiI6MTc3MDg4NTYyNCwiZXhwIjoxODAyNDIxNjI0LCJpYXQiOjE3NzA4ODU2MjR9.HvO_kB6UNwcNSV4B_MXuh9OK54rYtRRDMPH5Y1EuOhc")
    llm_workspace: str = os.getenv("LLM_WORKSPACE", "VR1857RolloutAgentDevSpace")


@dataclass
class AppConfig:
    neo4j: Neo4jConfig = field(default_factory=Neo4jConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    max_traversal_steps: int = 15
    max_retries: int = 3
    verbose: bool = True
    log_level: str = "INFO"


# Singleton config
config = AppConfig()
