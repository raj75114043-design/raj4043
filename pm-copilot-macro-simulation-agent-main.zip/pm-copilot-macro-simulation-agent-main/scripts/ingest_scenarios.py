"""
One-time ingestion script: reads Nokia Simulation Excel and inserts rows with
embeddings into pwc_semantic_information_schema.semantics_simulation.

Embedding is created by concatenating the Scenario text and Data Phase Questions,
then calling text-embedding-ada-002 via internal LLM endpoint.

Usage (from the simulation-agent-v1 directory):
    ../venv/bin/python scripts/ingest_scenarios.py
    # or
    venv/bin/python scripts/ingest_scenarios.py
"""
from __future__ import annotations

import os
import re
import sys

# Ensure project root is importable
_PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _PROJECT_ROOT)

from dotenv import load_dotenv
load_dotenv(os.path.join(_PROJECT_ROOT, ".env"))

import openpyxl
import psycopg2
from openai import OpenAI

import config  # for PG_HOST, PG_PORT, PG_DATABASE, PG_USER, PG_PASSWORD

EXCEL_PATH = os.path.join(_PROJECT_ROOT, "Simulation Scenarios.xlsx")
SHEET_NAME = "Simulator Samples"
TABLE = "pwc_semantic_information_schema.semantic_simulation"
EMBEDDING_MODEL = "text-embedding-ada-002"

# ── Internal LLM endpoint config (provide your values) ─────────────────────
# API_BASE_URL = "https://llmgateway-qa-api.nokia.com/v1.2/"
# API_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyTmFtZSI6IlJvbGxvdXRBZ2VudERldlRvb2wiLCJPYmplY3RJRCI6IjNGRUY4NzI0LUE5RTItNDMyQy1COTk4LTU0NDMwMEZBQjcxMyIsIndvcmtTcGFjZU5hbWUiOiJWUjE4NTdSb2xsb3V0QWdlbnREZXZTcGFjZSIsIm5iZiI6MTc3MDg4NTYyNCwiZXhwIjoxODAyNDIxNjI0LCJpYXQiOjE3NzA4ODU2MjR9.HvO_kB6UNwcNSV4B_MXuh9OK54rYtRRDMPH5Y1EuOhc"
# WORKSPACE_NAME = "VR1857RolloutAgentDevSpace"

# ── Helpers ────────────────────────────────────────────────────────────────

def _parse_text_to_array(text: str | None) -> list[str]:
    """Split multi-paragraph text (separated by blank lines) into list items."""
    if not text:
        return []
    items = [item.strip() for item in re.split(r"\n\s*\n", text) if item.strip()]
    return items

def _build_embedding_text(scenario: str | None, data_phase_questions: list[str]) -> str:
    """Concatenate Scenario and Data Phase Questions for embedding."""
    parts = [str(scenario) if scenario is not None else ""]
    if data_phase_questions:
        parts.append("\n".join(data_phase_questions))
    return "\n\n".join(filter(None, parts))

def _create_embedding(text: str) -> list[float]:
    """Call internal LLM endpoint via OpenAI client to get embedding."""
    client = OpenAI(
        api_key="NONE",  # dummy
        base_url=API_BASE_URL,
        default_headers={
            "api-key": API_KEY,
            "workspacename": WORKSPACE_NAME,
        }
    )
    response = client.embeddings.create(
        model=EMBEDDING_MODEL,
        input=text.strip()
    )
    return response.data[0].embedding

# ── Main ingestion ─────────────────────────────────────────────────────────

def ingest(clear_existing: bool = False) -> None:
    print(f"📂 Loading Excel: {EXCEL_PATH}")
    wb = openpyxl.load_workbook(EXCEL_PATH)
    ws = wb[SHEET_NAME]
    print(f"   Sheet '{SHEET_NAME}': {ws.max_row - 1} potential data rows\n")

    conn = psycopg2.connect(
        host=config.PG_HOST,
        port=config.PG_PORT,
        database=config.PG_DATABASE,
        user=config.PG_USER,
        password=config.PG_PASSWORD,
    )
    cur = conn.cursor()

    if clear_existing:
        print("🗑  Clearing existing rows from semantics_simulation...")
        cur.execute(f"TRUNCATE TABLE {TABLE} RESTART IDENTITY")
        conn.commit()

    inserted = skipped = 0

    for row in ws.iter_rows(min_row=2, values_only=True):
        (
            _ignored_scenario_id,  # Excel Scenario Id, we ignore it
            scenario,
            data_phase_questions_txt,
            data_phase_steps_txt,
            calc_steps_txt,
            sim_steps_txt,
            simulation_output_txt,
        ) = row[:7]

        # Skip empty rows
        if not scenario:
            skipped += 1
            continue

        # Parse array fields
        data_phase_questions = _parse_text_to_array(data_phase_questions_txt)
        data_phase_steps = _parse_text_to_array(data_phase_steps_txt)
        calculation_phase_steps = _parse_text_to_array(calc_steps_txt)
        simulator_phase_steps = _parse_text_to_array(sim_steps_txt)
        simulation_methodology = simulation_output_txt or ""

        # Build embedding text: Scenario + Data Phase Questions
        emb_text = _build_embedding_text(scenario, data_phase_questions)

        print(f"  🔢 Creating embedding for Scenario...", end=" ", flush=True)
        embedding = _create_embedding(emb_text)
        print(f"✓  ({len(embedding)}-dim vector)")

        # Insert row
        cur.execute(
            f"""
            INSERT INTO {TABLE} (
                scenario,
                data_phase_steps,
                data_phase_questions,
                calculation_phase_steps,
                simulator_phase_steps,
                simulation_methodology,
                embedding,
                created_at,
                updated_at
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, NOW(), NOW())
            """,
            (
                scenario,
                data_phase_steps,
                data_phase_questions,
                calculation_phase_steps,
                simulator_phase_steps,
                simulation_methodology,
                embedding,
            ),
        )
        inserted += 1
        print(f"     ✅ Scenario inserted.")
        conn.commit()

    cur.close()
    conn.close()

    print(f"\n{'─'*50}")
    print(f"✅ Ingestion complete: {inserted} inserted, {skipped} skipped.")

# ── CLI ────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Ingest Nokia Simulation Excel into semantics_simulation table.")
    parser.add_argument(
        "--clear",
        action="store_true",
        help="Truncate the table before ingesting (fresh reload).",
    )
    args = parser.parse_args()
    ingest(clear_existing=args.clear)