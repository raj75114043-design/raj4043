"""
Workflow Agent FastAPI Application.

This is the main entry point for the Workflow Agent API.
It sets up the FastAPI application with:
- PostgreSQL connection pooling
- API routes for workflow management
- Health check endpoints
- CORS middleware
"""

from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.core.config import get_settings
from app.db.pool import DatabasePool
from app.api.routes import (
    health,
    data,
    workflow_orchestration,
    workflow_dev_functions,
    workflow_modification_agent,
    workflow_dev_util_chat,
)

@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Application lifespan manager.

    Handles startup and shutdown events:
    - Startup: Initialize database connection pool
    - Shutdown: Close database connection pool gracefully
    """
    # Startup
    settings = get_settings()
    print(f"Starting {settings.app_name}...")

    try:
        await DatabasePool.create_pool()
        print("Database pool initialized successfully")
    except Exception as e:
        print(f"Warning: Failed to initialize database pool: {e}")
        print("API will start but database features may not work")

    yield

    # Shutdown
    print("Shutting down...")
    await DatabasePool.close_pool()
    print("Database pool closed")


def create_app() -> FastAPI:
    """Create and configure the FastAPI application."""
    settings = get_settings()

    app = FastAPI(
        title=settings.app_name,
        description="""
## Workflow Agent API

A modular workflow agent for managing and executing site-based workflow pipelines.

### Features

- **Workflow Pipeline Management**: Create, configure, and manage multi-step workflows - ONLY FOR DEVELOPERS
- **Step Modification**: Dynamically mute/unmute steps, add/remove filter rules
- **Filter Rules**: Define validation rules with multiple operators (NOT_NULL, EQUALS, DATE_PASSED, etc.)
- **Dependency Management**: Steps can depend on multiple parents with UNION or INTERSECTION merge strategies
- **LLM-Assisted Modifications**: Use natural language to modify workflow steps
- **PostgreSQL Integration**: Async database operations with connection pooling

""",
        version="1.0.0",
        lifespan=lifespan,
    )

    # CORS middleware
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],  # Configure appropriately for production
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Include routers
    app.include_router(health.router)
    app.include_router(workflow_orchestration.router, prefix="/api/v1")
    app.include_router(workflow_dev_functions.router, prefix="/api/v1")
    app.include_router(workflow_modification_agent.router, prefix="/api/v1")
    app.include_router(workflow_dev_util_chat.router, prefix="/api/v1")
    app.include_router(data.router, prefix="/api/v1")

    return app


# Create the application instance
app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
    )
