"""
Sample workflow setup script demonstrating the MACRO Workflow PoC.

This script creates the same workflow structure as shown in the notebook,
suitable for API testing or initialization.
"""

import json

# Sample workflow configuration matching the notebook's MACRO Workflow PoC
SAMPLE_WORKFLOW = {
    "name": "MACRO Workflow PoC",
    "steps": [
        {
            "meta": {
                "step_id": 1,
                "name": "Pre-NTP Document Validation",
                "description": "Check Pre-NTP Document Milestones"
            },
            "execution": {
                "is_enabled": True,
                "on_disabled": "passthrough",
                "depends_on": [],
                "merge_strategy": "union"
            },
            "filter_criteria": {
                "enabled": True,
                "conditional_logic": "AND",
                "rules": [
                    {
                        "source_table": "mbt_base_table",
                        "site_code_column": "site_code",
                        "column_name": "a1310_pre_ntp_document_received_date",
                        "operator": "not_null",
                        "expected_value": None,
                        "description": "Pre-NTP document must be received"
                    }
                ]
            }
        },
        {
            "meta": {
                "step_id": 2,
                "name": "Package Validation",
                "description": "Check Package Validation Milestones"
            },
            "execution": {
                "is_enabled": True,
                "on_disabled": "passthrough",
                "depends_on": [1],
                "merge_strategy": "union"
            },
            "filter_criteria": {
                "enabled": True,
                "conditional_logic": "AND",
                "rules": [
                    {
                        "source_table": "mbt_base_table",
                        "site_code_column": "site_code",
                        "column_name": "a1313_package_validated_date",
                        "operator": "not_null",
                        "expected_value": None,
                        "description": "Package must be validated"
                    }
                ]
            }
        },
        {
            "meta": {
                "step_id": 3,
                "name": "Manual Survey Completion Validation",
                "description": "Check Manual Survey Completion Validation Milestones"
            },
            "execution": {
                "is_enabled": True,
                "on_disabled": "passthrough",
                "depends_on": [2],
                "merge_strategy": "union"
            },
            "filter_criteria": {
                "enabled": True,
                "conditional_logic": "AND",
                "rules": [
                    {
                        "source_table": "ndpd",
                        "site_code_column": "site_code",
                        "column_name": "a1316_mannual_survey_completion",
                        "operator": "not_null",
                        "expected_value": None,
                        "description": "Manual survey must be completed"
                    }
                ]
            }
        },
        {
            "meta": {
                "step_id": 4,
                "name": "Drone Survey Check",
                "description": "Check Drone Survey Milestones"
            },
            "execution": {
                "is_enabled": True,
                "on_disabled": "passthrough",
                "depends_on": [2],
                "merge_strategy": "union"
            },
            "filter_criteria": {
                "enabled": True,
                "conditional_logic": "AND",
                "rules": [
                    {
                        "source_table": "ndpd",
                        "site_code_column": "site_code",
                        "column_name": "a1321_drone_survey_completion",
                        "operator": "not_null",
                        "expected_value": None,
                        "description": "Drone survey must be completed"
                    }
                ]
            }
        },
        {
            "meta": {
                "step_id": 5,
                "name": "Scoping Package Approval",
                "description": "Check Scoping Package Approval Milestones"
            },
            "execution": {
                "is_enabled": True,
                "on_disabled": "passthrough",
                "depends_on": [3, 4],
                "merge_strategy": "union"
            },
            "filter_criteria": {
                "enabled": True,
                "conditional_logic": "AND",
                "rules": [
                    {
                        "source_table": "mbt_base_table",
                        "site_code_column": "site_code",
                        "column_name": "a1333_scoping_package_approved",
                        "operator": "not_null",
                        "expected_value": None,
                        "description": "Scoping package must be approved"
                    }
                ]
            }
        },
        {
            "meta": {
                "step_id": 6,
                "name": "Material Pickup from Warehouse",
                "description": "Check Material Pickup from Warehouse Milestones"
            },
            "execution": {
                "is_enabled": True,
                "on_disabled": "passthrough",
                "depends_on": [5],
                "merge_strategy": "union"
            },
            "filter_criteria": {
                "enabled": True,
                "conditional_logic": "AND",
                "rules": [
                    {
                        "source_table": "mbt_base_table",
                        "site_code_column": "site_code",
                        "column_name": "material_pickup_actual_date",
                        "operator": "not_null",
                        "expected_value": None,
                        "description": "Material must be picked up"
                    }
                ]
            }
        }
    ]
}


def get_sample_workflow_json() -> str:
    """Return the sample workflow as JSON string."""
    return json.dumps(SAMPLE_WORKFLOW, indent=2)


def get_sample_workflow_dict() -> dict:
    """Return the sample workflow as a dictionary."""
    return SAMPLE_WORKFLOW


if __name__ == "__main__":
    print("Sample MACRO Workflow Configuration:")
    print("=" * 60)
    print(get_sample_workflow_json())
