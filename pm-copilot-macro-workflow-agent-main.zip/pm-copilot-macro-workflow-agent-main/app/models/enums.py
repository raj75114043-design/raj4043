"""Enumerations for workflow agent domain models."""

from enum import Enum


class ValidationOperator(str, Enum):
    """Operators for validation logic in filter rules."""

    NOT_NULL = "not_null"
    IS_NULL = "is_null"
    EQUALS = "equals"
    NOT_EQUALS = "not_equals"
    GREATER_THAN = "greater_than"
    LESS_THAN = "less_than"
    DATE_PASSED = "date_passed"
    DATE_NOT_PASSED = "date_not_passed"
    IN_LIST = "in_list"
    NOT_IN_LIST = "not_in_list"
    CONTAINS = "contains"


class OnDisabledStrategy(str, Enum):
    """Strategy for handling disabled steps."""

    PASSTHROUGH = "passthrough"  # Pass all input site codes through
    EMPTY = "empty"  # Return empty result


class MergeStrategy(str, Enum):
    """Strategy for merging results from multiple parent steps."""

    UNION = "union"  # A ∪ B (combine all site codes)
    INTERSECTION = "intersection"  # A ∩ B (only common site codes)


class ConditionalLogic(str, Enum):
    """Logic for combining multiple filter rules."""

    AND = "AND"  # All rules must pass
    ANY = "ANY"  # At least one rule must pass


class StepStatus(str, Enum):
    """Status of step execution."""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    DISABLED = "disabled"
