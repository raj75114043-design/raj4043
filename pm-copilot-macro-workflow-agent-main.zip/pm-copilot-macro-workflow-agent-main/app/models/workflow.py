"""
Core workflow domain models.

These models represent the workflow structure and are designed for modularity,
matching the design from the notebook experimentation.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from datetime import datetime

from app.models.enums import (
    ValidationOperator,
    OnDisabledStrategy,
    MergeStrategy,
    ConditionalLogic,
    StepStatus,
)


@dataclass
class SitesFilterRule:
    """
    Defines a single validation rule for filtering sites.

    Attributes:
        source_table: Name of the table to query
        site_code_column: Column name containing site codes
        column_name: Column to validate
        operator: Validation operator to apply
        expected_value: Value to compare against (operator-dependent)
        description: Human-readable description of the rule
    """

    source_table: str
    site_code_column: str
    column_name: str
    operator: ValidationOperator
    expected_value: Optional[Any] = None
    description: str = ""

    def __post_init__(self):
        if not self.description:
            self.description = f"{self.column_name} {self.operator.value}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_table": self.source_table,
            "site_code_column": self.site_code_column,
            "column_name": self.column_name,
            "operator": self.operator.value,
            "expected_value": self.expected_value,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SitesFilterRule":
        return cls(
            source_table=data["source_table"],
            site_code_column=data["site_code_column"],
            column_name=data["column_name"],
            operator=ValidationOperator(data["operator"]),
            expected_value=data.get("expected_value"),
            description=data.get("description", ""),
        )


@dataclass
class FilterCriteriaConfig:
    """
    Configuration for filtering sites in a workflow step.

    Attributes:
        enabled: Whether filtering is active
        conditional_logic: How to combine multiple rules (AND/ANY)
        rules: List of filter rules to apply
    """

    enabled: bool = True
    conditional_logic: ConditionalLogic = ConditionalLogic.AND
    rules: List[SitesFilterRule] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "enabled": self.enabled,
            "conditional_logic": self.conditional_logic.value,
            "rules": [rule.to_dict() for rule in self.rules],
        }


@dataclass
class StepMetaData:
    """Metadata for a workflow step."""

    step_id: int
    name: str
    phase_id: int
    phase_name: str = ""
    category: List[str] = field(default_factory=list)
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step_id": self.step_id,
            "name": self.name,
            "description": self.description,
            "phase_id": self.phase_id,
            "phase_name": self.phase_name,
            "category": self.category
        }


@dataclass
class StepExecutionConfig:
    """
    Execution configuration for a workflow step.

    Attributes:
        is_enabled: Whether the step is active
        on_disabled: Strategy when step is disabled
        depends_on: List of parent step IDs
        merge_strategy: How to merge results from multiple parents
    """

    is_enabled: bool = True
    on_disabled: OnDisabledStrategy = OnDisabledStrategy.PASSTHROUGH
    depends_on: List[int] = field(default_factory=list)
    merge_strategy: MergeStrategy = MergeStrategy.UNION

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_enabled": self.is_enabled,
            "on_disabled": self.on_disabled.value,
            "depends_on": self.depends_on,
            "merge_strategy": self.merge_strategy.value,
        }


@dataclass
class InputTableConfig:
    """Configuration for an input table used in view output."""

    table_name: str
    site_code_column: str
    columns: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "table_name": self.table_name,
            "site_code_column": self.site_code_column,
            "columns": self.columns,
        }


@dataclass
class ViewOutputConfig:
    """Configuration for output view generation."""

    is_enabled: bool = False
    instruction: Optional[str] = None
    fallback_sql: Optional[str] = None
    input_tables: List[InputTableConfig] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_enabled": self.is_enabled,
            "instruction": self.instruction,
            "fallback_sql": self.fallback_sql,
            "input_tables": [t.to_dict() for t in self.input_tables],
        }


@dataclass
class ComputationConfig:
    """Configuration for computations to run in a step."""

    is_enabled: bool = False
    computations: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_enabled": self.is_enabled,
            "computations": self.computations,
        }


@dataclass
class AgentConfig:
    """Configuration for agents to invoke in a step."""

    is_enabled: bool = False
    agents: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_enabled": self.is_enabled,
            "agents": self.agents,
        }


@dataclass
class StepExecutionResult:
    """Result of executing a workflow step."""

    step_id: int
    step_name: str
    step_description: Optional[str] = None
    phase_id: Optional[int] = None
    phase_name: Optional[str] = None
    category:  List[str] = field(default_factory=list)
    enabled: bool = True
    depends_on: List[int] = field(default_factory=list)
    filter_enabled: bool = False
    status: StepStatus = None
    input_count: int = 0
    passed_count: int = 0
    failed_count: int = 0
    passed_site_codes: List[str] = field(default_factory=list)
    failed_site_codes: List[str] = field(default_factory=list)
    detailed_results: List[Dict[str, Any]] = field(default_factory=list)
    execution_time: float = 0.0
    error_message: Optional[str] = None
    output_table: Optional[str] = None
    output_table_status: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step_id": self.step_id,
            "step_name": self.step_name,
            "step_description": self.step_description,
            "phase_id": self.phase_id,
            "phase_name": self.phase_name,
            "category": self.category,
            "enabled": self.enabled,
            "depends_on": self.depends_on,
            "filter_enabled": self.filter_enabled,
            "status": self.status.value if self.status else None,
            "input_count": self.input_count,
            "passed_count": self.passed_count,
            "failed_count": self.failed_count,
            "passed_site_codes": self.passed_site_codes,
            "failed_site_codes": self.failed_site_codes,
            "detailed_results": self.detailed_results,
            "execution_time": self.execution_time,
            "error_message": self.error_message,
            "output_table": self.output_table,
            "output_table_status": self.output_table_status,
        }


@dataclass
class WorkflowExecutionResult:
    """Result of executing an entire workflow pipeline."""

    workflow_name: str
    initial_count: int
    final_count: int
    final_site_codes: List[str]
    steps_executed: int
    step_results: List[StepExecutionResult]
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "workflow_name": self.workflow_name,
            "initial_count": self.initial_count,
            "final_count": self.final_count,
            "final_site_codes": self.final_site_codes,
            "steps_executed": self.steps_executed,
            "step_results": [r.to_dict() for r in self.step_results],
            "timestamp": self.timestamp,
        }
