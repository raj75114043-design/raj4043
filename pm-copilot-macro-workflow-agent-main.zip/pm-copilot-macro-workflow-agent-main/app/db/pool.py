"""
PostgreSQL Connection Pool using asyncpg.

This module provides async connection pooling for PostgreSQL with proper
lifecycle management for FastAPI applications.
"""

import asyncpg
from asyncpg import Pool, Connection
from typing import Optional, AsyncGenerator
from contextlib import asynccontextmanager

from app.core.config import get_settings


class DatabasePool:
    """
    Async PostgreSQL connection pool manager.

    Provides connection pooling with automatic connection management,
    health checks, and graceful shutdown.
    """

    _pool: Optional[Pool] = None

    @classmethod
    async def create_pool(cls) -> Pool:
        """
        Create and initialize the connection pool.

        Returns:
            Pool: The asyncpg connection pool
        """
        if cls._pool is not None:
            return cls._pool

        settings = get_settings()
      
        cls._pool = await asyncpg.create_pool(
            host=settings.db_host,
            port=settings.db_port,
            user=settings.db_username,
            password=settings.db_password,
            database=settings.db_name,
            min_size=settings.db_pool_min_size,
            max_size=settings.db_pool_max_size,
            max_queries=settings.db_pool_max_queries,
            max_inactive_connection_lifetime=settings.db_pool_max_inactive_connection_lifetime,
            command_timeout=60,
        )

        return cls._pool

    @classmethod
    async def close_pool(cls) -> None:
        """Close the connection pool gracefully."""
        if cls._pool is not None:
            await cls._pool.close()
            cls._pool = None

    @classmethod
    def get_pool(cls) -> Optional[Pool]:
        """Get the current pool instance."""
        return cls._pool

    @classmethod
    async def health_check(cls) -> bool:
        """
        Check if the database connection is healthy.

        Returns:
            bool: True if connection is healthy, False otherwise
        """
        if cls._pool is None:
            return False

        try:
            async with cls._pool.acquire() as conn:
                await conn.fetchval("SELECT 1")
            return True
        except Exception:
            return False


@asynccontextmanager
async def get_connection() -> AsyncGenerator[Connection, None]:
    """
    Async context manager for acquiring a database connection.

    Usage:
        async with get_connection() as conn:
            result = await conn.fetch("SELECT * FROM table")

    Yields:
        Connection: An asyncpg database connection
    """
    pool = DatabasePool.get_pool()
    if pool is None:
        raise RuntimeError("Database pool not initialized. Call create_pool() first.")

    async with pool.acquire() as connection:
        yield connection


async def get_db() -> AsyncGenerator[Connection, None]:
    """
    FastAPI dependency for database connections.

    Usage in routes:
        @router.get("/items")
        async def get_items(db: Connection = Depends(get_db)):
            ...

    Yields:
        Connection: An asyncpg database connection
    """
    async with get_connection() as conn:
        yield conn
