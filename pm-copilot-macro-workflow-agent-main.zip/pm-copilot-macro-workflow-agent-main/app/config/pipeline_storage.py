"""
Pipeline Storage Service for YAML-based persistence.

This module provides functionality to save and load workflow pipelines
as YAML files in the config/pipelines directory.
"""

import os
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional, List
import yaml

# Get the directory where pipeline YAML files are stored
PIPELINES_DIR = Path(__file__).parent / "pipelines"


def ensure_pipelines_dir() -> Path:
    """Ensure the pipelines directory exists."""
    PIPELINES_DIR.mkdir(parents=True, exist_ok=True)
    return PIPELINES_DIR


def get_pipeline_path(pipeline_name: str) -> Path:
    """Get the path for a pipeline YAML file."""
    # Sanitize the name for filesystem use
    safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in pipeline_name)
    return PIPELINES_DIR / f"{safe_name}.yml"


def save_pipeline(pipeline_name: str, pipeline_config: Dict[str, Any]) -> Path:
    """
    Save a pipeline configuration to a YAML file.

    Args:
        pipeline_name: Name of the pipeline
        pipeline_config: Pipeline configuration dictionary

    Returns:
        Path to the saved YAML file
    """
    ensure_pipelines_dir()
    file_path = get_pipeline_path(pipeline_name)

    pipeline_config = {
        "name": pipeline_config.get("name"),
        "version": pipeline_config.get("version", "Latest"),
        "generated_at": datetime.now().isoformat(),
        "steps": pipeline_config.get("steps", []),
    }

   # Backup existing pipeline with timestamp (utc)
    if file_path.exists():
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        backup_path = file_path.with_name(
            f"{file_path.stem}_v{timestamp}{file_path.suffix}"
        )
        file_path.rename(backup_path)

    with open(file_path, "w", encoding="utf-8") as f:
        # yaml.dump(pipeline_config, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
        yaml.safe_dump(pipeline_config, f, default_flow_style=False, sort_keys=False, allow_unicode=True)


    return file_path


def load_pipeline(pipeline_name: str) -> Optional[Dict[str, Any]]:
    """
    Load a pipeline configuration from a YAML file.

    Args:
        pipeline_name: Name of the pipeline

    Returns:
        Pipeline configuration dictionary, or None if not found
    """
    file_path = get_pipeline_path(pipeline_name)

    if not file_path.exists():
        return None

    with open(file_path, "r", encoding="utf-8") as f:
        # return yaml.safe_load(f)
        return yaml.load(f, Loader=yaml.UnsafeLoader) #risk will have to fix later in prod



def delete_pipeline(pipeline_name: str) -> bool:
    """
    Delete a pipeline YAML file.

    Args:
        pipeline_name: Name of the pipeline

    Returns:
        True if deleted, False if not found
    """
    file_path = get_pipeline_path(pipeline_name)

    if not file_path.exists():
        return False

    os.remove(file_path)
    return True


def list_pipelines() -> List[str]:
    """
    List all available pipeline names from YAML files.

    Returns:
        List of pipeline names
    """
    ensure_pipelines_dir()

    pipelines = []
    for file_path in PIPELINES_DIR.glob("*.yml"):
        # Load the file to get the actual pipeline name from content
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                config = yaml.safe_load(f)
                if config and "name" in config:
                    pipelines.append(config["name"])
        except Exception:
            # If we can't read the file, use the filename
            pipelines.append(file_path.stem)

    return pipelines


def pipeline_exists(pipeline_name: str) -> bool:
    """
    Check if a pipeline YAML file exists.

    Args:
        pipeline_name: Name of the pipeline

    Returns:
        True if exists, False otherwise
    """
    return get_pipeline_path(pipeline_name).exists()
