"""
Pydantic schemas for API request/response validation.

These schemas handle serialization/deserialization for the workflow API endpoints.
"""
from pydantic import BaseModel, Field, model_validator
from typing import List, Dict, Any, Optional
from datetime import datetime

from app.models.enums import (
    ValidationOperator,
    OnDisabledStrategy,
    MergeStrategy,
    ConditionalLogic,
    StepStatus,
)


# ============================================================================
# Filter Rule Schemas
# ============================================================================

NO_VALUE_OPERATORS = {
    ValidationOperator.NOT_NULL,
    ValidationOperator.IS_NULL,
    ValidationOperator.DATE_PASSED,
    ValidationOperator.DATE_NOT_PASSED,
}

VALUE_REQUIRED_OPERATORS = {
    ValidationOperator.EQUALS,
    ValidationOperator.NOT_EQUALS,
    ValidationOperator.GREATER_THAN,
    ValidationOperator.LESS_THAN,
    ValidationOperator.CONTAINS,
    ValidationOperator.IN_LIST,
    ValidationOperator.NOT_IN_LIST,
}


class APIModel(BaseModel):
    """Base API model with unified serialization."""

    def to_dict(self) -> dict:
        return self.model_dump(exclude_none=True)

class SitesFilterRuleCreate(BaseModel):
    """Schema for creating a new filter rule."""

    source_table: str
    site_code_column: str = "site_code"
    column_name: str
    operator: ValidationOperator
    expected_value: Optional[Any] = None
    description: str = ""

    @model_validator(mode="after")
    def validate_expected_value(self):
        if self.operator in NO_VALUE_OPERATORS:
            if self.expected_value is not None:
                raise ValueError(
                    f"Operator '{self.operator.value}' does not accept expected_value"
                )

        if self.operator in VALUE_REQUIRED_OPERATORS:
            if self.expected_value is None:
                raise ValueError(
                    f"Operator '{self.operator.value}' requires expected_value"
                )

        return self


class SitesFilterRuleResponse(SitesFilterRuleCreate):
    """Schema for filter rule response."""

    pass


class FilterCriteriaConfigCreate(BaseModel):
    """Schema for creating filter criteria configuration."""

    enabled: bool = True
    conditional_logic: ConditionalLogic = ConditionalLogic.AND
    rules: List[SitesFilterRuleCreate] = Field(default_factory=list)


class FilterCriteriaConfigResponse(FilterCriteriaConfigCreate):
    """Schema for filter criteria response."""

    rules: List[SitesFilterRuleResponse] = Field(default_factory=list)


# ============================================================================
# Step Configuration Schemas
# ============================================================================


class StepMetaDataCreate(BaseModel):
    """Schema for creating step metadata."""

    step_id: int
    name: str
    phase_id: int
    phase_name: str = ""
    category: List[str] = Field(default_factory=list)
    description: str = ""


class StepMetaDataResponse(StepMetaDataCreate):
    """Schema for step metadata response."""

    pass


class StepExecutionConfigCreate(BaseModel):
    """Schema for creating step execution configuration."""

    is_enabled: bool = True
    on_disabled: OnDisabledStrategy = OnDisabledStrategy.PASSTHROUGH
    depends_on: List[int] = Field(default_factory=list)
    merge_strategy: MergeStrategy = MergeStrategy.UNION


class StepExecutionConfigResponse(StepExecutionConfigCreate):
    """Schema for step execution config response."""

    pass


class InputTableConfigCreate(BaseModel):
    """Schema for input table configuration."""

    table_name: str
    site_code_column: str = "site_code"
    columns: List[str] = Field(default_factory=list)


class ViewOutputConfigCreate(BaseModel):
    """Schema for view output configuration."""

    is_enabled: bool = False
    instruction: Optional[str] = None
    fallback_sql: Optional[str] = None
    input_tables: List[InputTableConfigCreate] = Field(default_factory=list)


class ComputationConfigCreate(BaseModel):
    """Schema for computation configuration."""

    is_enabled: bool = False
    computations: List[str] = Field(default_factory=list)


class AgentConfigCreate(BaseModel):
    """Schema for agent configuration."""

    is_enabled: bool = False
    agents: List[str] = Field(default_factory=list)


# ============================================================================
# Workflow Step Schemas
# ============================================================================


class WorkflowStepCreate(BaseModel):
    """Schema for creating a complete workflow step."""

    meta: StepMetaDataCreate
    execution: StepExecutionConfigCreate
    filter_criteria: Optional[FilterCriteriaConfigCreate] = None
    view_output: Optional[ViewOutputConfigCreate] = None
    computation: Optional[ComputationConfigCreate] = None
    agent: Optional[AgentConfigCreate] = None


class WorkflowStepResponse(BaseModel):
    """Schema for workflow step response."""

    meta: StepMetaDataResponse
    execution: StepExecutionConfigResponse
    filter_criteria: Optional[FilterCriteriaConfigResponse] = None
    view_output: Optional[ViewOutputConfigCreate] = None
    computation: Optional[ComputationConfigCreate] = None
    agent: Optional[AgentConfigCreate] = None


class WorkflowStepSummary(BaseModel):
    """Summary of a workflow step for listing."""

    step_id: int
    name: str
    step_description: str
    phase_id: int
    phase_name: str
    category: List[str] = Field(default_factory=list)
    enabled: bool = None
    depends_on: List[int] = Field(default_factory=list)
    merge_strategy: Optional[str] = None
    filter_enabled: bool = False
    criteria_count: int = 0

class StepsInfo(BaseModel):
    """Summary of a workflow step for listing."""

    step_id: int
    name: str
    step_description: str
    phase_id: int
    phase_name: str
    category: List[str]
    enabled: bool
    depends_on: List[int]
    merge_strategy: Optional[str] = None
    filter_enabled: bool = False
    filter_criteria: Optional[Dict[str, Any]] = None
    computation: Optional[Dict[str, Any]] = None
    agent_integration: Optional[Dict[str, Any]] = None

# ============================================================================
# Step Modification Schemas
# ============================================================================


class StepMuteRequest(BaseModel):
    """Request to mute/unmute a step."""

    step_id: int
    mute: bool = True


class StepLogicUpdateRequest(BaseModel):
    """Request to update step filter logic."""

    step_id: int
    require_all: bool = True  # True = AND, False = ANY


class AddFilterRuleRequest(BaseModel):
    """Request to add a filter rule to a step."""

    step_id: int
    rule: SitesFilterRuleCreate


class RemoveFilterRuleRequest(BaseModel):
    """Request to remove a filter rule from a step."""

    step_id: int
    rule_index: int


class LLMModifyStepRequest(BaseModel):
    """Request to modify step using natural language."""
    natural_language_request: str


# ============================================================================
# Execution Schemas
# ============================================================================


class StepExecutionResultResponse(APIModel):
    """Response for step execution result."""

    step_id: int
    step_name: str
    step_description: Optional[str] = None
    phase_id: Optional[int] = None
    phase_name: Optional[str] = None
    category: List[str] = Field(default_factory=list)
    enabled: bool = True
    depends_on: List[int] = Field(default_factory=list)
    filter_enabled: bool = False
    status: StepStatus
    input_count: int = 0
    passed_count: int = 0
    failed_count: int = 0
    execution_time: float = 0.0
    error_message: Optional[str] = None
    output_table: Optional[str] = None
    output_table_status: Optional[str] = None
    class Config:
        from_attributes = True

class WorkflowExecuteRequest(BaseModel):
    """Request to execute a workflow."""

    site_codes: List[str]


class WorkflowExecutionResultResponse(APIModel):
    """Response for workflow execution result."""

    workflow_name: str
    initial_count: int
    final_count: int
    steps_executed: int
    step_results: List[StepExecutionResultResponse]
    timestamp: str
    class Config:
        from_attributes = True

# ============================================================================
# Pipeline Schemas
# ============================================================================


class WorkflowPipelineCreate(BaseModel):
    """Schema for creating a workflow pipeline."""

    name: str
    steps: List[WorkflowStepCreate] = Field(default_factory=list)


class WorkflowPipelineResponse(BaseModel):
    """Response for workflow pipeline."""

    name: str
    total_steps: int
    steps: List[WorkflowStepSummary]


class WorkflowPipelineDetail(BaseModel):
    """Detailed response for workflow pipeline."""

    name: str
    steps: List[WorkflowStepResponse]


# ============================================================================
# Health Check Schemas
# ============================================================================


class HealthCheckResponse(BaseModel):
    """Response for health check endpoint."""

    status: str
    database: bool
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())


class MessageResponse(BaseModel):
    """Generic message response."""

    message: str
    success: bool = True
