"""
Graph Nodes for the Workflow Dev Utility Chat Agent.

Contains the processing nodes used in the LangGraph conversational workflow.
"""

from typing import Any

from app.agents.workflow_dev_utli_chat.state import (
    ChatState,
    ChatMessage,
    ChatResponse,
    PipelineContext,
)
from app.agents.workflow_dev_utli_chat.prompt import (
    SYSTEM_PROMPT,
    build_chat_prompt,
    get_suggested_questions,
)


def build_pipeline_context(pipeline_config: dict) -> PipelineContext:
    """
    Build a PipelineContext from pipeline configuration.

    Args:
        pipeline_config: The pipeline configuration dictionary

    Returns:
        PipelineContext instance
    """
    steps = pipeline_config.get("steps", [])
    step_names = [s.get("meta", {}).get("name", f"Step {i+1}") for i, s in enumerate(steps)]

    return PipelineContext(
        name=pipeline_config.get("name", "Unknown"),
        config=pipeline_config,
        total_steps=len(steps),
        step_names=step_names,
    )


def classify_intent_node(state: ChatState) -> ChatState:
    """
    Node: Classify the user's intent based on their input.

    Intent categories:
    - explain: User wants explanation of pipeline/steps
    - flow: User wants to understand execution flow
    - rules: User wants to understand filter rules
    - suggest: User wants suggestions or improvements
    - general: General questions or greetings

    Args:
        state: Current chat state

    Returns:
        Updated state with classified intent
    """
    user_input = state["user_input"].lower()

    # Simple keyword-based intent classification
    if any(word in user_input for word in ["explain", "what does", "what is", "describe", "tell me about"]):
        intent = "explain"
    elif any(word in user_input for word in ["flow", "order", "sequence", "execute", "run", "depend"]):
        intent = "flow"
    elif any(word in user_input for word in ["filter", "rule", "criteria", "validate", "check", "operator"]):
        intent = "rules"
    elif any(word in user_input for word in ["suggest", "improve", "recommend", "optimize", "better"]):
        intent = "suggest"
    elif any(word in user_input for word in ["hi", "hello", "hey", "help", "what can you"]):
        intent = "greeting"
    else:
        intent = "general"

    return {**state, "intent": intent}


async def generate_response_node(state: ChatState, llm: Any) -> ChatState:
    """
    Node: Generate a response using the LLM.

    Args:
        state: Current chat state
        llm: LLM client instance

    Returns:
        Updated state with generated response
    """
    pipeline_config = state.get("pipeline_config", {})
    messages = state.get("messages", [])
    user_input = state["user_input"]

    # Handle greeting without LLM
    if state.get("intent") == "greeting":
        pipeline_name = pipeline_config.get("name", "your workflow")
        greeting_response = f"""Hello! I'm the Nokia Network Management Workflow Assistant.

I'm here to help you understand the configuration of **{pipeline_name}** pipeline.

I can help you with:
- Explaining what each step does
- Understanding filter rules and validation logic
- Describing the execution flow and dependencies
- Answering questions about the pipeline configuration

What would you like to know?"""

        suggestions = get_suggested_questions(pipeline_config) if pipeline_config else [
            "Load a pipeline first to get started",
        ]

        response = ChatResponse(
            message=greeting_response,
            pipeline_context=build_pipeline_context(pipeline_config) if pipeline_config else None,
            suggestions=suggestions,
        )

        return {**state, "response": response}

    # Build the chat prompt
    chat_prompt = build_chat_prompt(user_input, pipeline_config, messages)

    # Prepare messages for LLM
    llm_messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": chat_prompt},
    ]

    try:
        llm_response = await llm.ainvoke(llm_messages)
        response_text = llm_response.content

        # Generate suggestions
        suggestions = get_suggested_questions(pipeline_config)

        response = ChatResponse(
            message=response_text,
            pipeline_context=build_pipeline_context(pipeline_config) if pipeline_config else None,
            suggestions=suggestions,
        )

        return {**state, "response": response}

    except Exception as e:
        error_response = ChatResponse(
            message=f"I encountered an error processing your request: {str(e)}. Please try rephrasing your question.",
            pipeline_context=build_pipeline_context(pipeline_config) if pipeline_config else None,
            suggestions=["Try asking about the pipeline overview", "Ask about a specific step"],
        )

        return {**state, "response": error_response}


def update_history_node(state: ChatState) -> ChatState:
    """
    Node: Update the conversation history with the new exchange.

    Args:
        state: Current chat state

    Returns:
        Updated state with new messages in history
    """
    messages = list(state.get("messages", []))

    # Add user message
    user_message = ChatMessage(role="user", content=state["user_input"])
    messages.append(user_message)

    # Add assistant response
    if state.get("response"):
        assistant_message = ChatMessage(role="assistant", content=state["response"].message)
        messages.append(assistant_message)

    # Keep conversation manageable (last 20 messages)
    if len(messages) > 20:
        messages = messages[-20:]

    return {**state, "messages": messages}
