"""
Configuration for the Workflow Dev Utility Chat Agent.

Contains settings and constants for the Nokia workflow assistant chatbot.
"""

from dataclasses import dataclass
from typing import Literal


@dataclass
class ChatAgentConfig:
    """
    Configuration settings for the chat agent.
    """
    # LLM settings
    llm_tier: Literal["high", "medium", "low"] = "medium"

    # Conversation settings
    max_history_messages: int = 20
    max_suggestions: int = 5

    # Response settings
    include_pipeline_context: bool = True
    include_suggestions: bool = True


# Default configuration
DEFAULT_CONFIG = ChatAgentConfig()


# Agent metadata
AGENT_INFO = {
    "name": "Nokia Workflow Dev Utility Chat",
    "version": "1.0.0",
    "description": "A conversational AI assistant for understanding Nokia network management workflow configurations",
    "capabilities": [
        "Explain pipeline structure and steps",
        "Describe filter rules and validation logic",
        "Explain execution flow and dependencies",
        "Answer questions about configuration details",
        "Provide suggestions for understanding workflows",
    ],
    "supported_intents": [
        "explain",
        "flow",
        "rules",
        "suggest",
        "greeting",
        "general",
    ],
}
