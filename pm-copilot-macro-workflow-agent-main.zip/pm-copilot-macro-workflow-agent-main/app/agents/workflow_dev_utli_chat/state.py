"""
State definitions for the Workflow Dev Utility Chat Agent.

Defines the state schema used by the LangGraph conversational workflow.
"""

from typing import TypedDict, List, Optional, Literal
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class ChatMessage:
    """
    Represents a single message in the conversation.
    """
    role: Literal["user", "assistant", "system"]
    content: str
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> dict:
        return {
            "role": self.role,
            "content": self.content,
            "timestamp": self.timestamp,
        }


@dataclass
class PipelineContext:
    """
    Context about a workflow pipeline for the chat agent.
    """
    name: str
    config: dict
    total_steps: int
    step_names: List[str]

    def to_summary(self) -> str:
        """Generate a brief summary of the pipeline."""
        return f"Pipeline '{self.name}' with {self.total_steps} steps: {', '.join(self.step_names)}"

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "config": self.config,
            "total_steps": self.total_steps,
            "step_names": self.step_names,
        }


@dataclass
class ChatResponse:
    """
    Response from the chat agent.
    """
    message: str
    pipeline_context: Optional[PipelineContext] = None
    suggestions: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "message": self.message,
            "pipeline_context": self.pipeline_context.to_dict() if self.pipeline_context else None,
            "suggestions": self.suggestions,
        }


class ChatState(TypedDict):
    """
    State for the LangGraph chat workflow.

    This state flows through the graph nodes during execution.
    """
    # Conversation
    messages: List[ChatMessage]
    user_input: str

    # Pipeline context
    pipeline_name: Optional[str]
    pipeline_config: Optional[dict]

    # Processing
    intent: Optional[str]  # explain, compare, suggest, general

    # Output
    response: Optional[ChatResponse]
