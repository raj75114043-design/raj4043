"""
Runner for the Workflow Dev Utility Chat Agent.

Orchestrates the LangGraph conversational workflow for chatting about
Nokia network management workflow configurations.
"""

from typing import Any, Optional, List, Dict
from langgraph.graph import StateGraph, END

from app.agents.workflow_dev_utli_chat.state import (
    ChatState,
    ChatMessage,
    ChatResponse,
)
from app.agents.workflow_dev_utli_chat.nodes import (
    classify_intent_node,
    generate_response_node,
    update_history_node,
    build_pipeline_context,
)


class WorkflowDevChatAgent:
    """
    LangGraph-based conversational agent for understanding workflow configurations.

    This agent helps developers and operators understand their Nokia network
    management workflow pipeline configurations through natural conversation.

    Features:
    - Explains pipeline structure and steps
    - Describes filter rules and validation logic
    - Explains execution flow and dependencies
    - Maintains conversation history for context
    - Provides suggested follow-up questions

    Usage:
        agent = WorkflowDevChatAgent(llm_client)

        # Start a conversation about a pipeline
        response = await agent.chat(
            user_input="What does this pipeline do?",
            pipeline_config=my_pipeline_config
        )

        # Continue the conversation
        response = await agent.chat(
            user_input="Tell me more about step 2",
            pipeline_config=my_pipeline_config,
            conversation_history=previous_messages
        )
    """

    def __init__(self, llm_client: Any):
        """
        Initialize the chat agent.

        Args:
            llm_client: LLM client instance (e.g., from get_llm_client)
        """
        self.llm = llm_client
        self._graph = self._build_graph()

    def _build_graph(self) -> StateGraph:
        """
        Build the LangGraph state graph for the conversational agent.

        Graph structure:
            [start] -> classify_intent -> generate_response -> update_history -> [end]

        Returns:
            Compiled StateGraph
        """
        graph = StateGraph(ChatState)

        # Add nodes
        graph.add_node("classify_intent", classify_intent_node)
        graph.add_node("generate_response", self._generate_response_wrapper)
        graph.add_node("update_history", update_history_node)

        # Define edges
        graph.set_entry_point("classify_intent")
        graph.add_edge("classify_intent", "generate_response")
        graph.add_edge("generate_response", "update_history")
        graph.add_edge("update_history", END)

        return graph.compile()

    async def _generate_response_wrapper(self, state: ChatState) -> ChatState:
        """Wrapper to pass LLM client to the node."""
        return await generate_response_node(state, self.llm)

    async def chat(
        self,
        user_input: str,
        pipeline_config: dict,
        conversation_history: Optional[List[ChatMessage]] = None,
    ) -> ChatResponse:
        """
        Send a message to the chat agent and get a response.

        Args:
            user_input: The user's message
            pipeline_config: The workflow pipeline configuration to discuss
            conversation_history: Optional list of previous messages for context

        Returns:
            ChatResponse containing the agent's reply and suggestions
        """
        # Build initial state
        initial_state: ChatState = {
            "messages": conversation_history or [],
            "user_input": user_input,
            "pipeline_name": pipeline_config.get("name"),
            "pipeline_config": pipeline_config,
            "intent": None,
            "response": None,
        }

        # Run the graph
        final_state = await self._graph.ainvoke(initial_state)

        response = final_state.get("response")

        if not response:
            return ChatResponse(
                message="I'm sorry, I couldn't generate a response. Please try again.",
                pipeline_context=build_pipeline_context(pipeline_config),
                suggestions=["Try asking about the pipeline overview"],
            )

        return response

    async def start_conversation(self, pipeline_config: dict) -> ChatResponse:
        """
        Start a new conversation about a pipeline.

        Sends a greeting and provides an overview of what the agent can help with.

        Args:
            pipeline_config: The workflow pipeline configuration

        Returns:
            ChatResponse with initial greeting and suggestions
        """
        return await self.chat(
            user_input="Hello, help me understand this pipeline",
            pipeline_config=pipeline_config,
            conversation_history=[],
        )

    def get_conversation_messages(self, state: ChatState) -> List[Dict]:
        """
        Extract conversation messages from state as dictionaries.

        Args:
            state: The chat state

        Returns:
            List of message dictionaries
        """
        return [msg.to_dict() for msg in state.get("messages", [])]


class ConversationSession:
    """
    Manages a conversation session with the chat agent.

    This class maintains conversation state across multiple exchanges,
    making it easier to have multi-turn conversations.

    Usage:
        session = ConversationSession(llm_client, pipeline_config)

        # First message
        response = await session.send("What does this pipeline do?")

        # Follow-up message (history is maintained)
        response = await session.send("Tell me more about the filter rules")

        # Get full history
        history = session.get_history()
    """

    def __init__(self, llm_client: Any, pipeline_config: dict):
        """
        Initialize a conversation session.

        Args:
            llm_client: LLM client instance
            pipeline_config: The workflow pipeline configuration to discuss
        """
        self.agent = WorkflowDevChatAgent(llm_client)
        self.pipeline_config = pipeline_config
        self.messages: List[ChatMessage] = []

    async def send(self, user_input: str) -> ChatResponse:
        """
        Send a message and get a response.

        Maintains conversation history automatically.

        Args:
            user_input: The user's message

        Returns:
            ChatResponse from the agent
        """
        response = await self.agent.chat(
            user_input=user_input,
            pipeline_config=self.pipeline_config,
            conversation_history=self.messages,
        )

        # Update history
        self.messages.append(ChatMessage(role="user", content=user_input))
        self.messages.append(ChatMessage(role="assistant", content=response.message))

        # Keep history manageable
        if len(self.messages) > 20:
            self.messages = self.messages[-20:]

        return response

    def get_history(self) -> List[Dict]:
        """
        Get the conversation history.

        Returns:
            List of message dictionaries
        """
        return [msg.to_dict() for msg in self.messages]

    def clear_history(self) -> None:
        """Clear the conversation history."""
        self.messages = []

    def update_pipeline(self, pipeline_config: dict) -> None:
        """
        Update the pipeline configuration being discussed.

        Clears conversation history as context has changed.

        Args:
            pipeline_config: The new pipeline configuration
        """
        self.pipeline_config = pipeline_config
        self.messages = []
