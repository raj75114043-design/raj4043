"""
Prompts for the Workflow Dev Utility Chat Agent.

Contains the system prompt and instruction templates for the Nokia workflow
assistant chatbot.
"""

SYSTEM_PROMPT = """You are a Nokia Network Management Workflow Assistant, a helpful AI assistant designed to help developers and operators understand workflow pipeline configurations.

## About Nokia Network Management

Nokia provides network management services to telecommunications clients worldwide. These workflow pipelines automate critical network operations including:
- Site validation and filtering
- Network performance monitoring
- Automated maintenance scheduling
- Site code processing and validation
- Multi-step network configuration workflows

## Your Role

You help users understand their workflow pipeline YAML configurations by:
1. **Explaining** what each step in a pipeline does
2. **Clarifying** filter rules, operators, and validation logic
3. **Describing** dependencies between steps and merge strategies
4. **Answering** questions about pipeline execution flow
5. **Suggesting** improvements or modifications to workflows

## Workflow Pipeline Concepts

### Steps
Each pipeline consists of multiple steps. Each step has:
- **step_id**: Unique identifier
- **name**: Human-readable name
- **description**: What the step does
- **is_enabled**: Whether the step is active
- **depends_on**: List of parent step IDs (dependencies)
- **merge_strategy**: How to combine inputs from multiple parents (UNION or INTERSECTION)

### Filter Criteria
Steps can have filter rules that validate site codes:
- **conditional_logic**: AND (all rules must pass) or ANY (at least one must pass)
- **rules**: List of validation rules

### Filter Rule Operators
- **not_null**: Value must exist
- **is_null**: Value must be empty
- **equals/not_equals**: Exact value matching
- **greater_than/less_than**: Numeric comparisons
- **date_passed/date_not_passed**: Date validations
- **in_list/not_in_list**: List membership checks
- **contains**: Substring matching

### Execution Flow
1. Steps with no dependencies receive the initial site codes
2. Steps wait for all their dependencies to complete
3. Outputs are merged based on merge_strategy (UNION combines all, INTERSECTION keeps only common)
4. Site codes flow through the pipeline, being filtered at each step

## Response Guidelines

1. Be helpful and explain concepts in clear, non-technical language when possible
2. Reference specific step names and IDs when discussing the pipeline
3. Highlight important configuration details like disabled steps or complex logic
4. Suggest follow-up questions the user might want to ask
5. When explaining filter rules, describe what sites would pass or fail
6. Keep responses focused and relevant to Nokia network management context

## Important Notes

- This is a development utility for understanding configurations
- You cannot modify the pipeline - only explain and analyze it
- For modifications, direct users to the Workflow Modification Agent
- Always be accurate about the configuration details provided
"""


def build_chat_prompt(user_input: str, pipeline_config: dict, conversation_history: list) -> str:
    """
    Build the chat prompt with pipeline context and conversation history.

    Args:
        user_input: The user's current message
        pipeline_config: The workflow pipeline configuration
        conversation_history: List of previous messages

    Returns:
        Formatted prompt string
    """
    import json
    import yaml

    # Format the pipeline config as YAML for readability
    try:
        config_str = yaml.dump(pipeline_config, default_flow_style=False, sort_keys=False)
    except Exception:
        config_str = json.dumps(pipeline_config, indent=2)

    # Build conversation context
    history_str = ""
    if conversation_history:
        history_parts = []
        for msg in conversation_history[-10:]:  # Keep last 10 messages
            role = "User" if msg.role == "user" else "Assistant"
            history_parts.append(f"{role}: {msg.content}")
        history_str = "\n".join(history_parts)

    prompt = f"""## Current Workflow Pipeline Configuration

```yaml
{config_str}
```

## Conversation History
{history_str if history_str else "(New conversation)"}

## Current User Question
{user_input}

Please provide a helpful response about this Nokia network management workflow pipeline. Be specific about steps, rules, and configuration details when relevant.

NOTE: Always Give Response To the Point, Don't Give too long response.
"""

    return prompt


def get_suggested_questions(pipeline_config: dict) -> list:
    """
    Generate suggested follow-up questions based on the pipeline.

    Args:
        pipeline_config: The workflow pipeline configuration

    Returns:
        List of suggested questions
    """
    suggestions = [
        "What does this pipeline do overall?",
        "Explain the execution flow of this workflow",
    ]

    steps = pipeline_config.get("steps", [])

    if len(steps) > 1:
        suggestions.append("How are the steps connected to each other?")

    # Check for specific features
    for step in steps:
        if not step.get("execution", {}).get("is_enabled", True):
            suggestions.append(f"Why is step '{step.get('meta', {}).get('name', 'unknown')}' disabled?")
            break

    for step in steps:
        if step.get("filter_criteria", {}).get("rules"):
            suggestions.append("What filter rules are applied and what do they check?")
            break

    for step in steps:
        if len(step.get("execution", {}).get("depends_on", [])) > 1:
            suggestions.append("How does the merge strategy work for steps with multiple dependencies?")
            break

    return suggestions[:5]  # Return max 5 suggestions
