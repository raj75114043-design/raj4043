"""
State definitions for the Workflow Modification Agent.

Defines the state schema used by the LangGraph workflow.
"""

from typing import TypedDict, Optional, Any, Literal, Union
from pydantic import BaseModel, Field

class ExpectedValue(BaseModel):
    value: str | int | float | bool

class ModificationAction(BaseModel):
    """
    Represents a single modification action to be applied to a workflow.

    This is the structured output that can be:
    1. Directly executed by the agent
    2. Returned to the caller for manual execution
    """
    operation: Literal["mute_step", "unmute_step", "change_logic", "add_criteria"] = Field(
        ..., description="The type of modification to perform on the workflow step"
    )
    step_id: int = Field(
        ..., description="The ID of the step to modify"
    )

    # For change_logic operation
    require_all: Optional[bool] = Field(
        default=None, description="For change_logic: whether all criteria must match (AND) or any (OR)"
    )

    # For add_criteria operation
    source_table: Optional[str] = Field(
        default=None, description="For add_criteria: the source table to query"
    )
    site_code_column: Optional[str] = Field(
        default="site_code", description="For add_criteria: the column containing site codes"
    )
    column_name: Optional[str] = Field(
        default=None, description="For add_criteria: the column to evaluate"
    )
    operator: Optional[str] = Field(
        default=None, description="For add_criteria: the comparison operator"
    )
    # expected_value: Optional[Any] = Field(
    #     default=None, description="For add_criteria: the value to compare against"
    # )
    expected_value: Optional[ExpectedValue] = Field(
        default=None,
        description="For add_criteria: the value to compare against"
    )
    description: Optional[str] = Field(
        default=None, description="Human-readable description of this modification"
    )

    def to_dict(self) -> dict:
        """Convert to dictionary representation."""
        result = {
            "operation": self.operation,
            "step_id": self.step_id,
        }

        if self.operation == "change_logic":
            result["require_all"] = self.require_all
        elif self.operation == "add_criteria":
            result["source_table"] = self.source_table
            result["site_code_column"] = self.site_code_column
            result["column_name"] = self.column_name
            result["operator"] = self.operator
            result["expected_value"] = self.expected_value
            result["description"] = self.description

        return result


class LLMErrorResponse(BaseModel):
    """Response when the LLM cannot interpret the request."""
    error: str = Field(..., description="Description of why the request could not be processed")


class LLMResponse(BaseModel):
    """
    Structured response from the LLM for workflow modification requests.

    The LLM will return either valid ModificationAction(s) or an error.
    Supports both single actions and batch operations (e.g., "mute all steps").
    """
    actions: list[ModificationAction] = Field(
        default_factory=list,
        description="List of modification actions to perform. Use a single-item list for single operations."
    )
    error: Optional[str] = Field(
        default=None, description="Error message if the request cannot be processed"
    )


class AgentResponse(BaseModel):
    """
    Response from the workflow modification agent.

    Contains either:
    - Success with action details and message
    - Error with error message
    """
    success: bool
    message: str
    actions: list[ModificationAction] = Field(default_factory=list)
    executed: bool = False  # Whether the actions were directly executed

    def to_dict(self) -> dict:
        """Convert to dictionary representation."""
        return {
            "success": self.success,
            "message": self.message,
            "actions": [a.to_dict() for a in self.actions],
            "executed": self.executed,
        }

    # Backwards compatibility property
    @property
    def action(self) -> Optional[ModificationAction]:
        """Returns first action for backwards compatibility."""
        return self.actions[0] if self.actions else None

    class Config:
        arbitrary_types_allowed = True


class AgentState(TypedDict):
    """
    State for the LangGraph workflow modification agent.

    This state flows through the graph nodes during execution.
    """
    # Input
    user_request: str
    pipeline_config: dict

    # Processing
    parsed_actions: list  # List of ModificationAction
    validation_error: Optional[str]

    # Output
    response: Optional[AgentResponse]

    # Execution mode
    execute_directly: bool  # If True, apply changes directly; if False, return action plan
