"""
Tools (Actions) for the Workflow Modification Agent.

Contains functions that execute modifications on workflow pipelines.
These can be used by the agent to directly apply changes or can be
called by external code with the action plan returned by the agent.
"""

from typing import Optional
from app.agents.workflow_modification_agent.state import ModificationAction, AgentResponse
from app.services.workflow_pipeline import WorkflowPipeline
from app.models.workflow import SitesFilterRule, FilterCriteriaConfig
from app.models.enums import ValidationOperator, ConditionalLogic


def execute_mute_step(pipeline: WorkflowPipeline, step_id: int) -> tuple[bool, str, ModificationAction]:
    """
    Mute (disable) a workflow step.

    Args:
        pipeline: The workflow pipeline instance
        step_id: ID of the step to mute

    Returns:
        Tuple of (success, message, action)
    """
    action = ModificationAction(operation="mute_step", step_id=step_id)
    step = pipeline.get_step(step_id)
    if not step:
        return False, f"Step with ID '{step_id}' not found.", action

    step.mute()
    return True, f"Step '{step.meta.name}' has been muted.", action


def execute_unmute_step(pipeline: WorkflowPipeline, step_id: int) -> tuple[bool, str, ModificationAction]:
    """
    Unmute (enable) a workflow step.

    Args:
        pipeline: The workflow pipeline instance
        step_id: ID of the step to unmute

    Returns:
        Tuple of (success, message, action)
    """
    action = ModificationAction(operation="unmute_step", step_id=step_id)
    step = pipeline.get_step(step_id)
    if not step:
        return False, f"Step with ID '{step_id}' not found.", action

    step.unmute()
    return True, f"Step '{step.meta.name}' has been unmuted.", action


def execute_change_logic(
    pipeline: WorkflowPipeline, step_id: int, require_all: bool
) -> tuple[bool, str, ModificationAction]:
    """
    Change the filter logic (AND/ANY) for a workflow step.

    Args:
        pipeline: The workflow pipeline instance
        step_id: ID of the step to modify
        require_all: True for AND logic, False for ANY logic

    Returns:
        Tuple of (success, message, action)
    """
    action = ModificationAction(
        operation="change_logic", step_id=step_id, require_all=require_all
    )
    step = pipeline.get_step(step_id)
    if not step:
        return False, f"Step with ID '{step_id}' not found.", action

    step.update_filter_logic(require_all)
    logic_str = "AND" if require_all else "ANY"

    return True, f"Filter logic updated to {logic_str} for step '{step.meta.name}'.", action


def execute_add_criteria(
    pipeline: WorkflowPipeline,
    step_id: int,
    source_table: str,
    site_code_column: str,
    column_name: str,
    operator: str,
    expected_value: Optional[any],
    description: str,
) -> tuple[bool, str, ModificationAction]:
    """
    Add a filter criteria rule to a workflow step.

    Args:
        pipeline: The workflow pipeline instance
        step_id: ID of the step to modify
        source_table: Database table to query
        site_code_column: Column containing site codes
        column_name: Column to validate
        operator: Validation operator name
        expected_value: Expected value for comparison
        description: Human-readable description of the rule

    Returns:
        Tuple of (success, message, action)
    """
    action = ModificationAction(
        operation="add_criteria",
        step_id=step_id,
        source_table=source_table,
        site_code_column=site_code_column,
        column_name=column_name,
        operator=operator,
        expected_value=expected_value,
        description=description,
    )

    step = pipeline.get_step(step_id)
    if not step:
        return False, f"Step with ID '{step_id}' not found.", action

    # Ensure filter_criteria exists
    if step.filter_criteria is None:
        step.filter_criteria = FilterCriteriaConfig(
            enabled=True,
            conditional_logic=ConditionalLogic.AND,
            rules=[],
        )

    # Create the rule
    try:
        rule = SitesFilterRule(
            source_table=source_table,
            site_code_column=site_code_column,
            column_name=column_name,
            operator=ValidationOperator(operator),
            expected_value=expected_value,
            description=description or "",
        )
    except ValueError as e:
        return False, f"Invalid operator '{operator}': {str(e)}", action

    step.add_filter_rule(rule)
    return True, f"Filter rule added to step '{step.meta.name}'.", action


def _execute_single_action(
    pipeline: WorkflowPipeline, action: ModificationAction
) -> tuple[bool, str, ModificationAction]:
    """
    Execute a single modification action on a workflow pipeline.

    Args:
        pipeline: The workflow pipeline instance
        action: The modification action to execute

    Returns:
        Tuple of (success, message, action)
    """
    if action.operation == "mute_step":
        return execute_mute_step(pipeline, action.step_id)

    elif action.operation == "unmute_step":
        return execute_unmute_step(pipeline, action.step_id)

    elif action.operation == "change_logic":
        if action.require_all is None:
            return False, "change_logic operation requires 'require_all' parameter.", action
        return execute_change_logic(pipeline, action.step_id, action.require_all)

    elif action.operation == "add_criteria":
        if not all([action.source_table, action.column_name, action.operator]):
            return False, "add_criteria operation requires source_table, column_name, and operator.", action
        return execute_add_criteria(
            pipeline,
            action.step_id,
            action.source_table,
            action.site_code_column or "site_code",
            action.column_name,
            action.operator,
            action.expected_value,
            action.description or "",
        )

    else:
        return False, f"Unknown operation '{action.operation}'.", action


def execute_action(
    pipeline: WorkflowPipeline, action: ModificationAction
) -> AgentResponse:
    """
    Execute a single modification action on a workflow pipeline.

    Args:
        pipeline: The workflow pipeline instance
        action: The modification action to execute

    Returns:
        AgentResponse with execution results
    """
    success, message, executed_action = _execute_single_action(pipeline, action)
    return AgentResponse(
        success=success,
        message=message,
        actions=[executed_action],
        executed=success,
    )


def execute_actions(
    pipeline: WorkflowPipeline, actions: list[ModificationAction]
) -> AgentResponse:
    """
    Execute multiple modification actions on a workflow pipeline.

    Executes actions in order. If any action fails, stops and returns
    the partial results.

    Args:
        pipeline: The workflow pipeline instance
        actions: List of modification actions to execute

    Returns:
        AgentResponse with execution results for all actions
    """
    if not actions:
        return AgentResponse(
            success=False,
            message="No actions to execute.",
            actions=[],
            executed=False,
        )

    executed_actions: list[ModificationAction] = []
    messages: list[str] = []

    for action in actions:
        success, message, executed_action = _execute_single_action(pipeline, action)
        executed_actions.append(executed_action)
        messages.append(message)

        if not success:
            # Stop on first failure
            return AgentResponse(
                success=False,
                message=f"Failed at action {len(executed_actions)}: {message}",
                actions=executed_actions,
                executed=False,
            )

    return AgentResponse(
        success=True,
        message=f"Successfully executed {len(actions)} action(s): " + "; ".join(messages),
        actions=executed_actions,
        executed=True,
    )
