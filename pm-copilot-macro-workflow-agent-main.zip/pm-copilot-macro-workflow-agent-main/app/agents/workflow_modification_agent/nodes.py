"""
Graph Nodes for the Workflow Modification Agent.

Contains the processing nodes used in the LangGraph workflow.
Each node is a function that takes the current state and returns updated state.
"""

from typing import Any

from pydantic import ValidationError

from app.agents.workflow_modification_agent.state import (
    AgentState,
    ModificationAction,
    AgentResponse,
    LLMResponse,
)
from app.agents.workflow_modification_agent.prompt import SYSTEM_PROMPT, build_user_prompt


async def call_llm_node(state: AgentState, llm: Any) -> AgentState:
    """
    Node: Call the LLM to interpret the user's modification request.

    Uses structured output via Pydantic to ensure the LLM returns a valid response.
    Supports batch operations (e.g., "mute all steps").

    Args:
        state: Current agent state
        llm: LLM client instance (must support with_structured_output)

    Returns:
        Updated state with parsed_actions or validation_error
    """
    user_prompt = build_user_prompt(state["user_request"], state["pipeline_config"])

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_prompt},
    ]

    try:
        # Use structured output to get a validated Pydantic model
        structured_llm = llm.with_structured_output(LLMResponse)
        response: LLMResponse = await structured_llm.ainvoke(messages)

        # Check for error response from LLM
        if response.error:
            return {
                **state,
                "parsed_actions": [],
                "validation_error": response.error,
            }

        if not response.actions:
            return {
                **state,
                "parsed_actions": [],
                "validation_error": "LLM returned neither actions nor an error.",
            }

        return {
            **state,
            "parsed_actions": response.actions,
            "validation_error": None,
        }

    except ValidationError as e:
        return {
            **state,
            "parsed_actions": [],
            "validation_error": f"LLM response validation failed: {str(e)}",
        }
    except Exception as e:
        return {
            **state,
            "parsed_actions": [],
            "validation_error": f"LLM call failed: {str(e)}",
        }


def _validate_single_action(action: ModificationAction, step_ids: list[int]) -> str | None:
    """
    Validate a single action against the pipeline configuration.

    Returns:
        Error message if validation fails, None if valid.
    """
    # Check step exists
    if action.step_id not in step_ids:
        return f"Step ID {action.step_id} not found in workflow. Available steps: {step_ids}"

    # Validate operation-specific requirements
    if action.operation == "change_logic" and action.require_all is None:
        return "change_logic operation requires 'require_all' to be specified."

    if action.operation == "add_criteria":
        missing = []
        if not action.source_table:
            missing.append("source_table")
        if not action.column_name:
            missing.append("column_name")
        if not action.operator:
            missing.append("operator")

        if missing:
            return f"add_criteria operation missing required fields: {', '.join(missing)}"

        # Validate operator
        valid_operators = [
            "not_null", "is_null", "equals", "not_equals",
            "greater_than", "less_than", "date_passed", "date_not_passed",
            "in_list", "not_in_list", "contains"
        ]
        if action.operator not in valid_operators:
            return f"Invalid operator '{action.operator}'. Valid operators: {', '.join(valid_operators)}"

    return None


def validate_action_node(state: AgentState) -> AgentState:
    """
    Node: Validate all parsed actions against the pipeline configuration.

    Checks that for each action:
    - The referenced step exists in the pipeline
    - Required fields are present for the operation type

    Args:
        state: Current agent state

    Returns:
        Updated state with validation_error if any validation fails
    """
    actions = state.get("parsed_actions", [])

    if not actions:
        # Already has a validation error from LLM parsing
        return state

    pipeline_config = state["pipeline_config"]
    steps = pipeline_config.get("steps", [])
    step_ids = [s["step_id"] for s in steps]

    # Validate each action
    for i, action in enumerate(actions):
        error = _validate_single_action(action, step_ids)
        if error:
            action_desc = f"Action {i + 1} ({action.operation} on step {action.step_id})"
            return {
                **state,
                "validation_error": f"{action_desc}: {error}",
            }

    return state


def build_response_node(state: AgentState) -> AgentState:
    """
    Node: Build the final response based on validation results.

    If there's a validation error, creates an error response.
    If execute_directly is False, returns the action plan without executing.
    Otherwise, marks the response for execution.

    Args:
        state: Current agent state

    Returns:
        Updated state with response
    """
    actions = state.get("parsed_actions", [])

    if state.get("validation_error"):
        response = AgentResponse(
            success=False,
            message=state["validation_error"],
            actions=actions,
            executed=False,
        )
        return {**state, "response": response}

    if not state.get("execute_directly", False):
        # Build message describing all actions
        if len(actions) == 1:
            action = actions[0]
            message = f"Action plan generated: {action.operation} on step {action.step_id}"
        else:
            action_summaries = [f"{a.operation} on step {a.step_id}" for a in actions]
            message = f"Action plan generated: {len(actions)} actions - {', '.join(action_summaries)}"

        response = AgentResponse(
            success=True,
            message=message,
            actions=actions,
            executed=False,
        )
        return {**state, "response": response}

    # Mark for execution (actual execution happens in runner)
    response = AgentResponse(
        success=True,
        message=f"{len(actions)} action(s) ready for execution",
        actions=actions,
        executed=False,  # Will be set to True after execution
    )
    return {**state, "response": response}
