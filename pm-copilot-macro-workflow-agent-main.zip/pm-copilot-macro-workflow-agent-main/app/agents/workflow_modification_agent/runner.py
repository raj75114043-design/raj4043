"""
Runner for the Workflow Modification Agent.

Orchestrates the LangGraph workflow for processing modification requests.
"""

from typing import Any, Optional
from langgraph.graph import StateGraph, END

from app.agents.workflow_modification_agent.state import (
    AgentState,
    ModificationAction,
    AgentResponse,
)
from app.agents.workflow_modification_agent.nodes import (
    call_llm_node,
    validate_action_node,
    build_response_node,
)
from app.agents.workflow_modification_agent.tools import execute_actions
from app.services.workflow_pipeline import WorkflowPipeline


class WorkflowModificationAgent:
    """
    LangGraph-based agent for modifying workflow pipelines.

    This agent interprets natural language requests and either:
    1. Directly executes modifications on the pipeline
    2. Returns a structured action plan for the caller to execute

    Usage:
        # Direct execution mode
        agent = WorkflowModificationAgent(llm_client)
        response = await agent.run(
            user_request="mute step 2",
            pipeline=my_pipeline,
            execute_directly=True
        )

        # Action plan mode
        response = await agent.run(
            user_request="mute step 2",
            pipeline=my_pipeline,
            execute_directly=False
        )
        if response.success and response.actions:
            # Caller can inspect/modify the actions before executing
            result = agent.execute_action_plan(my_pipeline, response.actions)
    """

    def __init__(self, llm_client: Any):
        """
        Initialize the workflow modification agent.

        Args:
            llm_client: LLM client instance (e.g., from get_llm_client)
        """
        self.llm = llm_client
        self._graph = self._build_graph()

    def _build_graph(self) -> StateGraph:
        """
        Build the LangGraph state graph for the agent.

        Graph structure:
            [start] -> call_llm -> validate -> build_response -> [end]

        Returns:
            Compiled StateGraph
        """
        graph = StateGraph(AgentState)

        # Add nodes
        graph.add_node("call_llm", self._call_llm_wrapper)
        graph.add_node("validate", validate_action_node)
        graph.add_node("build_response", build_response_node)

        # Define edges
        graph.set_entry_point("call_llm")
        graph.add_edge("call_llm", "validate")
        graph.add_edge("validate", "build_response")
        graph.add_edge("build_response", END)

        return graph.compile()

    async def _call_llm_wrapper(self, state: AgentState) -> AgentState:
        """Wrapper to pass LLM client to the node."""
        return await call_llm_node(state, self.llm)

    async def run(
        self,
        user_request: str,
        pipeline: WorkflowPipeline,
        execute_directly: bool = True,
    ) -> AgentResponse:
        """
        Run the agent to process a modification request.

        Args:
            user_request: Natural language modification request
            pipeline: The workflow pipeline to modify
            execute_directly: If True, apply changes directly to pipeline.
                            If False, return action plan without executing.

        Returns:
            AgentResponse containing the result
        """
        # Build initial state
        initial_state: AgentState = {
            "user_request": user_request,
            "pipeline_config": pipeline.get_pipeline_config(),
            "parsed_actions": [],
            "validation_error": None,
            "response": None,
            "execute_directly": execute_directly,
        }

        # Run the graph
        final_state = await self._graph.ainvoke(initial_state)

        response = final_state.get("response")

        # If direct execution is requested and actions were generated successfully
        if execute_directly and response and response.success and response.actions:
            return execute_actions(pipeline, response.actions)

        return response or AgentResponse(
            success=False,
            message="Agent failed to produce a response.",
            actions=[],
            executed=False,
        )

    async def get_action_plan(
        self,
        user_request: str,
        pipeline: WorkflowPipeline,
    ) -> AgentResponse:
        """
        Get an action plan without executing it.

        Convenience method that calls run() with execute_directly=False.

        Args:
            user_request: Natural language modification request
            pipeline: The workflow pipeline (for context)

        Returns:
            AgentResponse containing the action plan
        """
        return await self.run(user_request, pipeline, execute_directly=False)

    def execute_action_plan(
        self,
        pipeline: WorkflowPipeline,
        actions: list[ModificationAction],
    ) -> AgentResponse:
        """
        Execute a previously generated action plan.

        This allows the caller to inspect/modify the actions before execution.

        Args:
            pipeline: The workflow pipeline to modify
            actions: List of modification actions to execute

        Returns:
            AgentResponse with execution results
        """
        return execute_actions(pipeline, actions)

    @staticmethod
    def create_action(
        operation: str,
        step_id: int,
        **kwargs,
    ) -> ModificationAction:
        """
        Create a ModificationAction programmatically.

        Useful for creating actions without going through the LLM.

        Args:
            operation: One of "mute_step", "unmute_step", "change_logic", "add_criteria"
            step_id: ID of the step to modify
            **kwargs: Additional parameters for the operation

        Returns:
            ModificationAction instance
        """
        return ModificationAction(
            operation=operation,
            step_id=step_id,
            require_all=kwargs.get("require_all"),
            source_table=kwargs.get("source_table"),
            site_code_column=kwargs.get("site_code_column", "site_code"),
            column_name=kwargs.get("column_name"),
            operator=kwargs.get("operator"),
            expected_value=kwargs.get("expected_value"),
            description=kwargs.get("description"),
        )
