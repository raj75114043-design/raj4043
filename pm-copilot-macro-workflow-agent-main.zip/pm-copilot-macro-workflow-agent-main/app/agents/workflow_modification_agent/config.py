"""
Configuration for the Workflow Modification Agent.

Contains settings and constants for the Nokia workflow modification agent.
"""

from dataclasses import dataclass
from typing import Literal, List


@dataclass
class ModificationAgentConfig:
    """
    Configuration settings for the workflow modification agent.
    """
    # LLM settings
    llm_tier: Literal["high", "medium", "low"] = "medium"

    # Validation settings
    strict_validation: bool = True  # Validate step_id exists before executing
    validate_operators: bool = True  # Validate operator names

    # Execution settings
    default_execute_directly: bool = True  # Default mode for modifications

    # Retry settings
    max_retries: int = 2
    retry_on_parse_error: bool = True


# Default configuration
DEFAULT_CONFIG = ModificationAgentConfig()


# Valid operators for filter rules
VALID_OPERATORS: List[str] = [
    "not_null",
    "is_null",
    "equals",
    "not_equals",
    "greater_than",
    "less_than",
    "date_passed",
    "date_not_passed",
    "in_list",
    "not_in_list",
    "contains",
]

# Valid operations
VALID_OPERATIONS: List[str] = [
    "mute_step",
    "unmute_step",
    "change_logic",
    "add_criteria",
]


# Agent metadata
AGENT_INFO = {
    "name": "Nokia Workflow Modification Agent",
    "version": "1.0.0",
    "description": "A LangGraph-based agent for modifying Nokia network management workflow pipelines using natural language",
    "capabilities": [
        "Mute/unmute workflow steps",
        "Change filter logic (AND/ANY)",
        "Add filter criteria rules",
        "Validate modifications before execution",
        "Return action plans for review",
    ],
    "supported_operations": [
        {
            "name": "mute_step",
            "description": "Disable a workflow step so it won't execute",
            "parameters": ["step_id"],
            "examples": ["mute step 2", "disable the first step", "turn off step 3"],
        },
        {
            "name": "unmute_step",
            "description": "Enable a previously disabled workflow step",
            "parameters": ["step_id"],
            "examples": ["unmute step 2", "enable step 1", "turn on step 3"],
        },
        {
            "name": "change_logic",
            "description": "Change the filter logic between AND and ANY",
            "parameters": ["step_id", "require_all"],
            "examples": [
                "change step 3 to require all conditions",
                "make step 1 use OR logic",
                "set step 2 to AND logic",
            ],
        },
        {
            "name": "add_criteria",
            "description": "Add a new filter rule to a step",
            "parameters": [
                "step_id",
                "source_table",
                "site_code_column",
                "column_name",
                "operator",
                "expected_value",
                "description",
            ],
            "examples": [
                "add a rule to step 2 to check that status is not null",
                "add a filter to step 1 checking if priority equals high",
            ],
        },
    ],
    "supported_operators": [
        {"name": "not_null", "description": "Value must not be null", "requires_value": False},
        {"name": "is_null", "description": "Value must be null", "requires_value": False},
        {"name": "equals", "description": "Value must equal expected_value", "requires_value": True},
        {"name": "not_equals", "description": "Value must not equal expected_value", "requires_value": True},
        {"name": "greater_than", "description": "Value must be greater than expected_value", "requires_value": True},
        {"name": "less_than", "description": "Value must be less than expected_value", "requires_value": True},
        {"name": "date_passed", "description": "Date must be in the past", "requires_value": False},
        {"name": "date_not_passed", "description": "Date must be in the future", "requires_value": False},
        {"name": "in_list", "description": "Value must be in expected_value list", "requires_value": True},
        {"name": "not_in_list", "description": "Value must not be in expected_value list", "requires_value": True},
        {"name": "contains", "description": "Value must contain expected_value as substring", "requires_value": True},
    ],
    "execution_modes": [
        {
            "name": "direct",
            "description": "Execute the modification immediately on the pipeline",
            "use_case": "When you want changes applied right away",
        },
        {
            "name": "plan",
            "description": "Return the action plan without executing",
            "use_case": "When you want to review or approve changes before applying",
        },
    ],
}
