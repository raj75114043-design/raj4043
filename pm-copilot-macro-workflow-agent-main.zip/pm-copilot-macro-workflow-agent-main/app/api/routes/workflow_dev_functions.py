"""
Workflow Development API routes for pipeline creation and management.

WARNING: These endpoints are for DEVELOPERS ONLY.
All endpoints require password authentication.

This module provides REST endpoints for DEVELOPERS to:
- Create new workflow pipelines (saved as YAML files)
- Delete pipelines
- Add/remove steps from pipelines

Note: These endpoints are for development/configuration only.
For runtime operations (execution, step modification), use the workflow_orchestration routes.
"""

from typing import List
from fastapi import APIRouter, HTTPException, Header, Depends
from fastapi import Security, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import secrets
from fastapi.security import APIKeyHeader

from app.schemas.workflow import (
    WorkflowStepCreate,
    WorkflowPipelineCreate,
    MessageResponse,
    VALUE_REQUIRED_OPERATORS
)
from app.config.pipeline_storage import (
    save_pipeline,
    load_pipeline,
    delete_pipeline as delete_pipeline_file,
    list_pipelines,
    pipeline_exists,
)

from app.models.enums import (
    ValidationOperator,
)

security = HTTPBasic()
router = APIRouter(prefix="/workflow_dev", tags=["Workflow Developer Utility (DEV ONLY)"])



# Dev password for protecting endpoints
DEV_PASSWORD = "pwc_macro_team"


def verify_dev_password(credentials: HTTPBasicCredentials = Depends(security)):
    correct = secrets.compare_digest(credentials.password, "pwc_macro_team")
    if not correct:
        raise HTTPException(status_code=401, headers={"WWW-Authenticate": "Basic"})




def _step_to_dict(step_data: WorkflowStepCreate) -> dict:
    """Convert a WorkflowStepCreate schema to a dictionary for YAML storage."""
    
    
    step_dict = {
        "meta": {
            "step_id": step_data.meta.step_id,
            "name": step_data.meta.name,
            "description": step_data.meta.description,
            "phase_id": step_data.meta.phase_id,
            "phase_name": step_data.meta.phase_name,
            "category": step_data.meta.category
        },
        "execution": {
            "is_enabled": step_data.execution.is_enabled,
            "on_disabled": step_data.execution.on_disabled,
            "depends_on": step_data.execution.depends_on,
            "merge_strategy": step_data.execution.merge_strategy,
        },
    }

    if step_data.filter_criteria:
        step_dict["filter_criteria"] = {
            "enabled": step_data.filter_criteria.enabled,
            "conditional_logic": step_data.filter_criteria.conditional_logic,
            "rules": [
                {
                    "source_table": r.source_table,
                    "site_code_column": r.site_code_column,
                    "column_name": r.column_name,
                    "operator": r.operator,
                    "expected_value": r.expected_value,
                    "description": r.description,
                }
                for r in step_data.filter_criteria.rules
            ],
        }

    if step_data.view_output:
        step_dict["view_output"] = {
            "is_enabled": step_data.view_output.is_enabled,
            "instruction": step_data.view_output.instruction,
            "fallback_sql": step_data.view_output.fallback_sql,
            "input_tables": [
                {
                    "table_name": t.table_name,
                    "site_code_column": t.site_code_column,
                    "columns": t.columns,
                }
                for t in step_data.view_output.input_tables
            ],
        }

    if step_data.computation:
        step_dict["computation"] = {
            "is_enabled": step_data.computation.is_enabled,
            "computations": step_data.computation.computations,
        }

    if step_data.agent:
        step_dict["agent"] = {
            "is_enabled": step_data.agent.is_enabled,
            "agents": step_data.agent.agents,
        }

    return step_dict



@router.get("/existing_operators/{workflow_name}")
async def get_existing_operators(workflow_name: str):
    """Get available validation operators."""

    return {
        operator.value: {
            "requires_expected_value": operator in VALUE_REQUIRED_OPERATORS,
        }
        for operator in ValidationOperator
    }

@router.post("/pipelines", response_model=MessageResponse, dependencies=[])
async def create_pipeline(
    pipeline: WorkflowPipelineCreate,
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
):
    """
    [DEV ONLY] Create a new workflow pipeline configuration file.

    This endpoint is restricted to developers only and requires the X-Dev-Password header.
    The pipeline is saved as a YAML file in the config/pipelines directory.
    """

    if pipeline_exists(pipeline.name):
        raise HTTPException(
            status_code=400, detail=f"Workflow '{pipeline.name}' already exists"
        )

    # Build pipeline configuration
    # pipeline_config = {
    #     "name": pipeline.name,
    #     "steps": [_step_to_dict(step) for step in pipeline.steps],
    # }

    pipeline_config = pipeline.model_dump(
        mode="json",
        exclude_none=True
    )

    # Save to YAML file
    file_path = save_pipeline(pipeline.name, pipeline_config)

    return MessageResponse(
        message=f"Workflow '{pipeline.name}' created with {len(pipeline.steps)} steps. Saved to {file_path.name}"
    )


@router.delete("/pipelines/{workflow_name}", response_model=MessageResponse)
async def delete_pipeline(
    workflow_name: str,
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
):
    """
    [DEV ONLY] Delete a workflow pipeline YAML file.

    This endpoint is restricted to developers only and requires the X-Dev-Password header.
    """

    if not delete_pipeline_file(workflow_name):
        raise HTTPException(
            status_code=404, detail=f"Workflow '{workflow_name}' not found"
        )

    return MessageResponse(message=f"Workflow '{workflow_name}' deleted")


@router.get("/pipelines", response_model=List[str])
async def list_all_pipelines(
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
):
    """
    [DEV ONLY] List all available workflow pipelines (from YAML files).

    This endpoint is restricted to developers only and requires the X-Dev-Password header.
    """
    
    return list_pipelines()


@router.post("/pipelines/{workflow_name}/steps", response_model=MessageResponse)
async def add_step(
    workflow_name: str,
    step: WorkflowStepCreate,
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
):
    """
    [DEV ONLY] Add a step to an existing workflow pipeline.

    This endpoint is restricted to developers only and requires the X-Dev-Password header.
    """

    pipeline_config = load_pipeline(workflow_name)

    if not pipeline_config:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{workflow_name}' not found"
        )

    # Check if step_id already exists
    existing_ids = [s["meta"]["step_id"] for s in pipeline_config.get("steps", [])]
    if step.meta.step_id in existing_ids:
        raise HTTPException(
            status_code=400, detail=f"Step with ID {step.meta.step_id} already exists"
        )

    # Add the new step
    # pipeline_config["steps"].append(_step_to_dict(step))

    step_dict = step.model_dump(
        mode="json",
        exclude_none=True
    )

    pipeline_config.setdefault("steps", []).append(step_dict)

    # Save updated pipeline
    save_pipeline(workflow_name, pipeline_config)

    return MessageResponse(
        message=f"Step '{step.meta.name}' added to workflow '{workflow_name}'"
    )


@router.delete(
    "/pipelines/{workflow_name}/steps/{step_id}", response_model=MessageResponse
)
async def remove_step(
    workflow_name: str,
    step_id: int,
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
):
    """
    [DEV ONLY] Remove a step from a workflow pipeline.

    This endpoint is restricted to developers only and requires the X-Dev-Password header.
    """

    pipeline_config = load_pipeline(workflow_name)

    if not pipeline_config:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{workflow_name}' not found"
        )

    # # Find and remove the step
    # original_count = len(pipeline_config.get("steps", []))
    # pipeline_config["steps"] = [
    #     s for s in pipeline_config["steps"] if s["meta"]["step_id"] != step_id
    # ]

    steps = pipeline_config.get("steps", [])
    original_count = len(steps)
    # Safe removal
    pipeline_config["steps"] = [
        s for s in steps
        if s.get("meta", {}).get("step_id") != step_id
    ]

    if len(pipeline_config["steps"]) == original_count:
        raise HTTPException(status_code=404, detail=f"Step {step_id} not found")

    # Save updated pipeline
    save_pipeline(workflow_name, pipeline_config)

    return MessageResponse(
        message=f"Step {step_id} removed from workflow '{workflow_name}'"
    )


@router.get("/pipelines/{workflow_name}")
async def get_pipeline_config(
    workflow_name: str,
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
):
    """
    [DEV ONLY] Get the raw YAML configuration for a pipeline.

    This endpoint is restricted to developers only and requires the X-Dev-Password header.
    """

    pipeline_config = load_pipeline(workflow_name)

    if not pipeline_config:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{workflow_name}' not found"
        )

    return pipeline_config
