"""
Workflow Dev Utility Chat API routes.

This module provides REST endpoints for the Nokia Workflow Dev Utility Chatbot.
The chatbot helps developers and operators understand workflow pipeline
configurations through natural conversation.

Features:
- Chat with a specific pipeline configuration
- Maintain conversation sessions
- Get pipeline explanations and insights
"""

from typing import Optional, List, Dict
from fastapi import APIRouter, HTTPException, Header
from pydantic import BaseModel, Field

from app.core.llm_client import get_llm_client
from app.agents.workflow_dev_utli_chat import (
    WorkflowDevChatAgent,
    ConversationSession,
    AGENT_INFO,
)
from app.config.pipeline_storage import load_pipeline, list_pipelines, pipeline_exists


router = APIRouter(prefix="/workflow_chat", tags=["Workflow Dev Utility Chat"])

# In-memory session storage (for demo - use Redis/DB in production)
_sessions: Dict[str, ConversationSession] = {}




# ============================================================================
# Request/Response Schemas
# ============================================================================


class ChatRequest(BaseModel):
    """Request to send a chat message."""

    message: str = Field(
        ...,
        description="The user's message or question about the pipeline",
        min_length=1,
    )


class ChatMessageSchema(BaseModel):
    """Schema for a chat message."""

    role: str = Field(..., description="Message role: user or assistant")
    content: str = Field(..., description="Message content")
    timestamp: str = Field(..., description="ISO timestamp of the message")


class ChatResponseSchema(BaseModel):
    """Response from the chat agent."""

    message: str = Field(..., description="The agent's response")
    suggestions: List[str] = Field(
        default_factory=list,
        description="Suggested follow-up questions"
    )
    pipeline_name: Optional[str] = Field(None, description="Name of the pipeline being discussed")
    pipeline_summary: Optional[str] = Field(None, description="Brief summary of the pipeline")


class SessionInfoSchema(BaseModel):
    """Information about a chat session."""

    session_id: str = Field(..., description="Unique session identifier")
    pipeline_name: str = Field(..., description="Pipeline being discussed")
    message_count: int = Field(..., description="Number of messages in the session")


class StartSessionRequest(BaseModel):
    """Request to start a new chat session."""

    pipeline_name: str = Field(..., description="Name of the pipeline to discuss")


class ConversationHistorySchema(BaseModel):
    """Conversation history response."""

    session_id: str
    pipeline_name: str
    messages: List[ChatMessageSchema]


# ============================================================================
# Public Endpoints (No password required)
# ============================================================================


@router.get("/info")
async def get_agent_info():
    """
    Get information about the chat agent.

    Returns the agent's capabilities and supported features.
    """
    return AGENT_INFO


@router.get("/pipelines")
async def list_available_pipelines():
    """
    List all available pipelines that can be discussed.

    Returns a list of pipeline names that have YAML configurations.
    """
    return {"pipelines": list_pipelines()}


# ============================================================================
# Chat Endpoints (Password protected - DEV ONLY)
# ============================================================================


@router.post("/{workflow_name}/sessions", response_model=SessionInfoSchema)
async def start_session(
    workflow_name: str
):
    """
    [DEV ONLY] Start a new chat session for a pipeline.

    Creates a new conversation session for discussing the specified pipeline.
    Returns a session ID that should be used for subsequent chat messages.
    """

    if not pipeline_exists(workflow_name):
        raise HTTPException(
            status_code=404,
            detail=f"Pipeline '{workflow_name}' not found"
        )

    pipeline_config = load_pipeline(workflow_name)

    # Create session ID
    import uuid
    session_id = str(uuid.uuid4())[:8]

    # Create conversation session
    llm_client = get_llm_client("medium")
    session = ConversationSession(llm_client, pipeline_config)
    _sessions[session_id] = session

    return SessionInfoSchema(
        session_id=session_id,
        pipeline_name=workflow_name,
        message_count=0,
    )


@router.post("/sessions/{session_id}/chat", response_model=ChatResponseSchema)
async def chat_in_session(
    session_id: str,
    request: ChatRequest,
):
    """
    [DEV ONLY] Send a chat message in an existing session.

    Maintains conversation history for context-aware responses.
    """

    if session_id not in _sessions:
        raise HTTPException(
            status_code=404,
            detail=f"Session '{session_id}' not found. Start a new session first."
        )

    session = _sessions[session_id]
    response = await session.send(request.message)

    pipeline_context = response.pipeline_context
    return ChatResponseSchema(
        message=response.message,
        suggestions=response.suggestions,
        pipeline_name=pipeline_context.name if pipeline_context else None,
        pipeline_summary=pipeline_context.to_summary() if pipeline_context else None,
    )


@router.get("/sessions/{session_id}/history", response_model=ConversationHistorySchema)
async def get_session_history(
    session_id: str
):
    """
    [DEV ONLY] Get the conversation history for a session.
    """

    if session_id not in _sessions:
        raise HTTPException(
            status_code=404,
            detail=f"Session '{session_id}' not found"
        )

    session = _sessions[session_id]
    history = session.get_history()

    return ConversationHistorySchema(
        session_id=session_id,
        pipeline_name=session.pipeline_config.get("name", "Unknown"),
        messages=[ChatMessageSchema(**msg) for msg in history],
    )


@router.delete("/sessions/{session_id}")
async def end_session(
    session_id: str
):
    """
    [DEV ONLY] End a chat session and clear its history.
    """

    if session_id not in _sessions:
        raise HTTPException(
            status_code=404,
            detail=f"Session '{session_id}' not found"
        )

    del _sessions[session_id]
    return {"message": f"Session '{session_id}' ended"}


@router.get("/sessions")
async def list_sessions():
    """
    [DEV ONLY] List all active chat sessions.
    """

    sessions = []
    for session_id, session in _sessions.items():
        sessions.append(SessionInfoSchema(
            session_id=session_id,
            pipeline_name=session.pipeline_config.get("name", "Unknown"),
            message_count=len(session.messages),
        ))

    return {"sessions": sessions}


# ============================================================================
# Stateless Chat Endpoint (Password protected - DEV ONLY)
# ============================================================================


@router.post("/pipelines/{pipeline_name}/chat", response_model=ChatResponseSchema)
async def chat_about_pipeline(
    pipeline_name: str,
    request: ChatRequest):
    """
    [DEV ONLY] Send a single chat message about a pipeline (stateless).

    This endpoint does not maintain conversation history.
    Use sessions for multi-turn conversations.
    """

    if not pipeline_exists(pipeline_name):
        raise HTTPException(
            status_code=404,
            detail=f"Pipeline '{pipeline_name}' not found"
        )

    pipeline_config = load_pipeline(pipeline_name)

    llm_client = get_llm_client("medium")
    agent = WorkflowDevChatAgent(llm_client)

    response = await agent.chat(
        user_input=request.message,
        pipeline_config=pipeline_config,
    )

    pipeline_context = response.pipeline_context
    return ChatResponseSchema(
        message=response.message,
        suggestions=response.suggestions,
        pipeline_name=pipeline_context.name if pipeline_context else None,
        pipeline_summary=pipeline_context.to_summary() if pipeline_context else None,
    )


@router.get("/pipelines/{pipeline_name}/overview", response_model=ChatResponseSchema)
async def get_pipeline_overview(
    pipeline_name: str):
    """
    [DEV ONLY] Get an AI-generated overview of a pipeline.

    Starts a conversation with a greeting to get an initial explanation
    of the pipeline structure and purpose.
    """

    if not pipeline_exists(pipeline_name):
        raise HTTPException(
            status_code=404,
            detail=f"Pipeline '{pipeline_name}' not found"
        )

    pipeline_config = load_pipeline(pipeline_name)

    llm_client = get_llm_client("medium")
    agent = WorkflowDevChatAgent(llm_client)

    response = await agent.start_conversation(pipeline_config)

    pipeline_context = response.pipeline_context
    return ChatResponseSchema(
        message=response.message,
        suggestions=response.suggestions,
        pipeline_name=pipeline_context.name if pipeline_context else None,
        pipeline_summary=pipeline_context.to_summary() if pipeline_context else None,
    )
