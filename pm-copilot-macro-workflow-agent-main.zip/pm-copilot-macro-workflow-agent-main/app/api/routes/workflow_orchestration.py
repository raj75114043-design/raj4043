"""
Workflow Orchestration API routes for runtime operations.

This module provides REST endpoints for:
- Loading and executing workflow pipelines (from YAML config files)
- Step modification (mute/unmute, add/remove rules, change logic)
- LLM-assisted natural language modifications
- Workflow visualization

Note: Pipeline creation/deletion is handled by workflow_dev_functions.
This module handles runtime operations on existing pipelines.
"""

from typing import List, Dict
from fastapi import APIRouter, Depends, HTTPException
from asyncpg import Connection
from app.utils.save_workflow_execution import save_workflow_execution

from app.db.pool import get_db
from app.core.llm_client import get_llm_client
from pprint import pprint
from datetime import datetime
from app.schemas.workflow import (
    WorkflowStepSummary,
    StepsInfo,
    WorkflowPipelineResponse,
    StepMuteRequest,
    StepLogicUpdateRequest,
    AddFilterRuleRequest,
    RemoveFilterRuleRequest,
    LLMModifyStepRequest,
    WorkflowExecuteRequest,
    WorkflowExecutionResultResponse,
    StepExecutionResultResponse,
    MessageResponse,
)
from app.services.workflow_pipeline import WorkflowPipeline
from app.services.workflow_step import WorkflowStep
from app.services.load_storage_pipeline import load_latest_workflow_execution

from app.models.workflow import (
    StepMetaData,
    StepExecutionConfig,
    FilterCriteriaConfig,
    SitesFilterRule,
    ViewOutputConfig,
    ComputationConfig,
    AgentConfig,
    InputTableConfig,
)
from app.models.enums import (
    OnDisabledStrategy,
    MergeStrategy,
    ConditionalLogic,
    ValidationOperator,
)
from app.config.pipeline_storage import (
    save_pipeline,
    load_pipeline,
    list_pipelines,
    pipeline_exists,
)


# file_path = OUTPUT_DIR / f"{workflow_name.replace(' ', '_')}.json"

router = APIRouter(prefix="/workflow", tags=["Workflow Orchestration"])

# Runtime cache for loaded pipelines (loaded from YAML on demand)
_runtime_pipelines: Dict[str, WorkflowPipeline] = {}


def _create_step_from_config(step_config: dict) -> WorkflowStep:
    """Create a WorkflowStep from YAML configuration dictionary."""
    meta = StepMetaData(
        step_id=step_config["meta"]["step_id"],
        name=step_config["meta"]["name"],
        description=step_config["meta"]["description"],
        phase_id = step_config["meta"]["phase_id"],
        phase_name = step_config["meta"]["phase_name"],
        category = step_config["meta"].get("category", [])
    )

    execution = StepExecutionConfig(
        is_enabled=step_config["execution"].get("is_enabled", True),
        on_disabled=OnDisabledStrategy(step_config["execution"].get("on_disabled", "passthrough")),
        depends_on=step_config["execution"].get("depends_on", []),
        merge_strategy=MergeStrategy(step_config["execution"].get("merge_strategy", "union")),
    )

    filter_criteria = None
    if "filter_criteria" in step_config and step_config["filter_criteria"]:
        fc = step_config["filter_criteria"]
        rules = [
            SitesFilterRule(
                source_table=r["source_table"],
                site_code_column=r["site_code_column"],
                column_name=r["column_name"],
                operator=ValidationOperator(r["operator"]),
                expected_value=r.get("expected_value"),
                description=r.get("description", ""),
            )
            for r in fc.get("rules", [])
        ]
        filter_criteria = FilterCriteriaConfig(
            enabled=fc.get("enabled", True),
            conditional_logic=ConditionalLogic(fc.get("conditional_logic", "and")),
            rules=rules,
        )

    view_output = None
    if "view_output" in step_config and step_config["view_output"]:
        vo = step_config["view_output"]
        input_tables = [
            InputTableConfig(
                table_name=t["table_name"],
                site_code_column=t["site_code_column"],
                columns=t.get("columns", []),
            )
            for t in vo.get("input_tables", [])
        ]
        view_output = ViewOutputConfig(
            is_enabled=vo.get("is_enabled", False),
            instruction=vo.get("instruction", ""),
            fallback_sql=vo.get("fallback_sql"),
            input_tables=input_tables,
        )

    computation = None
    if "computation" in step_config and step_config["computation"]:
        comp = step_config["computation"]
        computation = ComputationConfig(
            is_enabled=comp.get("is_enabled", False),
            computations=comp.get("computations", []),
        )

    agent = None
    if "agent" in step_config and step_config["agent"]:
        ag = step_config["agent"]
        agent = AgentConfig(
            is_enabled=ag.get("is_enabled", False),
            agents=ag.get("agents", []),
        )

    return WorkflowStep(
        meta=meta,
        execution=execution,
        filter_criteria=filter_criteria,
        view_output=view_output,
        computation=computation,
        agent=agent,
    )


def _load_workflow_from_yaml(workflow_name: str) -> WorkflowPipeline:
    """Load a workflow from YAML file and cache it for runtime use."""
    pipeline_config = load_pipeline(workflow_name)

    if not pipeline_config:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{workflow_name}' not found"
        )

    llm_client = get_llm_client("medium")
    workflow = WorkflowPipeline(name=pipeline_config["name"], llm_client=llm_client)

    for step_config in pipeline_config.get("steps", []):
        step = _create_step_from_config(step_config)
        workflow.add_step(step)

    return workflow


def _get_workflow(workflow_name: str) -> WorkflowPipeline:
    """Get a workflow by name, loading from YAML if not cached."""
    # if workflow_name not in _runtime_pipelines:
    #     _runtime_pipelines[workflow_name] = _load_workflow_from_yaml(workflow_name)

    _runtime_pipelines[workflow_name] = _load_workflow_from_yaml(workflow_name)

    return _runtime_pipelines[workflow_name]


def _reload_workflow(workflow_name: str) -> WorkflowPipeline:
    """Force reload a workflow from YAML file."""
    if workflow_name in _runtime_pipelines:
        del _runtime_pipelines[workflow_name]
    return _get_workflow(workflow_name)


# ============================================================================
# Pipeline Management Endpoints
# ============================================================================

@router.get("/pipelines", response_model=List[str])
async def list_all_pipelines():
    """List all available workflow pipelines (from YAML files)."""
    return list_pipelines()


@router.get("/pipeline_summary/{workflow_name}", response_model=WorkflowPipelineResponse)
async def get_pipeline_summary(workflow_name: str):
    """Get a workflow pipeline Summary."""
    workflow = _get_workflow(workflow_name)
    config = workflow.get_pipeline_config()

    return WorkflowPipelineResponse(
        name=config["name"],
        total_steps=config["total_steps"],
        steps=[WorkflowStepSummary(**s) for s in config["steps"]],
    )


# @router.get("/pipeline_running_status/{workflow_name}", response_model=WorkflowPipelineResponse)
# async def get_running_status(workflow_name: str):
#     """Get a workflow pipeline configuration."""
#     workflow = _get_workflow(workflow_name)
#     config = workflow.get_pipeline_config()

#     return WorkflowPipelineResponse(
#         name=config["name"],
#         total_steps=config["total_steps"],
#         steps=[WorkflowStepSummary(**s) for s in config["steps"]],
#     )


@router.post("/pipelines/{workflow_name}/reload", response_model=MessageResponse)
async def reload_pipeline(workflow_name: str):
    """Reload a pipeline from its YAML file (discards runtime modifications)."""
    if not pipeline_exists(workflow_name):
        raise HTTPException(
            status_code=404, detail=f"Workflow '{workflow_name}' not found"
        )

    _reload_workflow(workflow_name)
    return MessageResponse(message=f"Workflow '{workflow_name}' reloaded from configuration")


# ============================================================================
# Step Management Endpoints
# ============================================================================


@router.get(
    "/pipelines/{workflow_name}/steps/{step_id}", response_model=StepsInfo
)
async def get_step_info(workflow_name: str, step_id: int):
    """Get a specific step from a workflow."""
    workflow = _get_workflow(workflow_name)
    step = workflow.get_step(step_id)

    if not step:
        raise HTTPException(status_code=404, detail=f"Step {step_id} not found")

    summary = step.get_step_detail()
    return StepsInfo(**summary)



# ============================================================================
# LLM-Assisted Modification Endpoint
# ============================================================================

## This Feature is Moved to the Standlone Workflow Agent Route ################

# @router.post("/pipelines/{workflow_name}/llm-modify", response_model=MessageResponse)
# async def llm_modify_step(workflow_name: str, request: LLMModifyStepRequest):
#     """Use natural language to modify a workflow step (requires LLM)."""
#     workflow = _get_workflow(workflow_name)

#     result = await workflow.llm_modify_step(request.natural_language_request)

#     return MessageResponse(message=result)


# ============================================================================
# Execution Endpoints
# ============================================================================


@router.post(
    "/pipelines/{workflow_name}/execute", response_model=WorkflowExecutionResultResponse
)
async def execute_workflow(
    workflow_name: str,
    # request: WorkflowExecuteRequest,
    db: Connection = Depends(get_db),
):
    """Execute a workflow pipeline with the given site codes."""
    workflow = _get_workflow(workflow_name)
    print("workflow", workflow)

    result = await workflow.execute(db)

    response = WorkflowExecutionResultResponse(
        workflow_name=result.workflow_name,
        initial_count=result.initial_count,
        final_count=result.final_count,
        steps_executed=result.steps_executed,
        step_results=[
            StepExecutionResultResponse.model_validate(r)
            for r in result.step_results
        ],
        timestamp=result.timestamp,
    )

    save_workflow_execution(workflow_name, response.to_dict())
    return response

    
@router.get(
    "/workflow_executed_pipeline/{workflow_name}",
    response_model=WorkflowExecutionResultResponse,
)
async def get_executed_pipeline(workflow_name: str):
    """Get the last executed workflow pipeline summary."""

    try:
        execution_data = load_latest_workflow_execution(workflow_name)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))

    #Rehydrate into the SAME response model
    return WorkflowExecutionResultResponse.model_validate(execution_data)

@router.get("/pipelines/{workflow_name}/visualize")
async def visualize_workflow(workflow_name: str):
    """Get a text visualization of the workflow."""
    workflow = _get_workflow(workflow_name)
    return {"visualization": workflow.visualize_flow()}



# ============================================================================
# Step Modification Endpoints
# ============================================================================


@router.post("/pipelines/{workflow_name}/steps/mute", response_model=MessageResponse)
async def mute_step(workflow_name: str, request: StepMuteRequest):
    """Mute or unmute a workflow step."""
    workflow = _get_workflow(workflow_name)
    step = workflow.get_step(request.step_id)

    if not step:
        raise HTTPException(status_code=404, detail=f"Step {request.step_id} not found")

    if request.mute:
        step.mute()
        action = "muted"
    else:
        step.unmute()
        action = "unmuted"

    workflow_dict = {
        "name": workflow.name,
        "version": "Latest",
        "generated_at": datetime.now().isoformat(),
        "steps": [step.to_dict() for step in workflow.steps],
    }
    # print(workflow_dict)
    save_pipeline(workflow.name, workflow_dict)

    return MessageResponse(message=f"Step '{step.meta.name}' has been {action}")


@router.post(
    "/pipelines/{workflow_name}/steps/update-logic", response_model=MessageResponse
)
async def update_step_logic(workflow_name: str, request: StepLogicUpdateRequest):
    """Update the filter logic (AND/ANY) for a step."""
    workflow = _get_workflow(workflow_name)
    step = workflow.get_step(request.step_id)

    if not step:
        raise HTTPException(status_code=404, detail=f"Step {request.step_id} not found")

    step.update_filter_logic(request.require_all)
    logic = "AND" if request.require_all else "ANY"

    workflow_dict = {
        "name": workflow.name,
        "version": "Latest",
        "generated_at": datetime.now().isoformat(),
        "steps": [step.to_dict() for step in workflow.steps],
    }
    # print(workflow_dict)
    save_pipeline(workflow.name, workflow_dict)

    return MessageResponse(
        message=f"Filter logic updated to {logic} for step '{step.meta.name}'"
    )


@router.post(
    "/pipelines/{workflow_name}/steps/add-rule", response_model=MessageResponse
)
async def add_filter_rule(workflow_name: str, request: AddFilterRuleRequest):
    """Add a filter rule to a workflow step."""
    workflow = _get_workflow(workflow_name)
    step = workflow.get_step(request.step_id)

    if not step:
        raise HTTPException(status_code=404, detail=f"Step {request.step_id} not found")

    rule = SitesFilterRule(
        source_table=request.rule.source_table,
        site_code_column=request.rule.site_code_column,
        column_name=request.rule.column_name,
        operator=ValidationOperator(request.rule.operator),
        expected_value=request.rule.expected_value,
        description=request.rule.description,
    )

    step.add_filter_rule(rule)

    workflow_dict = {
        "name": workflow.name,
        "version": "Latest",
        "generated_at": datetime.now().isoformat(),
        "steps": [step.to_dict() for step in workflow.steps],
    }
    # print(workflow_dict)
    save_pipeline(workflow.name, workflow_dict)

    return MessageResponse(message=f"Filter rule added to step '{step.meta.name}'")


@router.post(
    "/pipelines/{workflow_name}/steps/remove-rule", response_model=MessageResponse
)
async def remove_filter_rule(workflow_name: str, request: RemoveFilterRuleRequest):
    """Remove a filter rule from a workflow step."""
    workflow = _get_workflow(workflow_name)
    step = workflow.get_step(request.step_id)

    if not step:
        raise HTTPException(status_code=404, detail=f"Step {request.step_id} not found")

    if not step.remove_filter_rule(request.rule_index):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid rule index {request.rule_index}",
        )

    workflow_dict = {
        "name": workflow.name,
        "version": "Latest",
        "generated_at": datetime.now().isoformat(),
        "steps": [step.to_dict() for step in workflow.steps],
    }
    # print(workflow_dict)
    save_pipeline(workflow.name, workflow_dict)
    
    return MessageResponse(
        message=f"Filter rule {request.rule_index} removed from step '{step.meta.name}'"
    )
