"""
Data management endpoints for loading and querying site data.
"""

from typing import List, Dict, Any,  Set, Union
from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from asyncpg import Connection
import tempfile
import os
import uuid
from datetime import datetime
from uuid import uuid4
from app.db.pool import get_db
from app.services.data_sites import get_list_of_primary_key
from app.schemas.workflow import MessageResponse
from app.core.data_fetch_config import BASE_SCHEMA
from app.services.data_sites import(
        get_cached_primary_key,
        get_cached_base_table,
        get_cached_global_filter_columns,
)
from app.config.pipeline_storage import (
    load_pipeline,
    pipeline_exists
)
from app.schemas.data import (
    GlobalFiltersResponse,
    GlobalFiltersResponseUpdated,
    WorkflowKeyCountResponse,
    ChatDefaultQueries,
    AddUsersPMCoPilotRequest,
)

from app.services.update_staging_table import (
    updated_staging_tables,
    JOB_STORE,
)

from app.schemas.workflow import UserInfoRequest

router = APIRouter(prefix="/data", tags=["Data"])

def _extract_name_from_email(email: str) -> str:
    local_part = email.split("@")[0]
    parts = [p for p in local_part.split(".") if p.lower() != "ext"]
    return " ".join(p.capitalize() for p in parts)

def _extract_global_filters_from_pipeline(pipeline_config: dict):
    steps = pipeline_config.get("steps", [])

    # Find starting step (depends_on == [])
    start_step = None
    for step in steps:
        depends_on = step.get("execution", {}).get("depends_on", [])
        if not depends_on:
            start_step = step
            break

    if not start_step:
        return None, []

    rules = start_step.get("filter_criteria", {}).get("rules", [])

    if not rules:
        return None, []

    # 2. Find base table from primary_key operator
    base_table = None
    for rule in rules:
        if rule.get("operator") == "primary_key":
            base_table = rule.get("source_table")
            break

    if not base_table:
        return None, []

    # Extract global filter columns from same base table
    global_filter_columns = [
        rule.get("column_name")
        for rule in rules
        if rule.get("operator") == "global_filter"
        and rule.get("source_table") == base_table
    ]

    return base_table, global_filter_columns


@router.get("/workflow_input_flowing_keys/{worklfow_name}", response_model=WorkflowKeyCountResponse)
async def workflow_input_flow_keys(workflow_name: str, db: Connection = Depends(get_db)):
    """Get all site codes from the database."""
    try:
        base_schema = BASE_SCHEMA
        keys = await get_list_of_primary_key(db, workflow_name)
        primary_key_column = get_cached_primary_key(workflow_name)
        base_table = get_cached_base_table(workflow_name)
        return {
            "workflow": workflow_name,
            "count": len(keys),
            "primary_key": primary_key_column,
            "table": base_table,
            "base_schema": base_schema
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get primary keys: {e}")


@router.get("/workflow_table_info/{workflow_name}")
async def get_available_staging_tables_info(
    workflow_name: str,  # kept intentionally (future use: auth, routing, lineage)
    db: Connection = Depends(get_db),
):
    """
    Returns schema, table, column name, and data type
    for all tables available in the backend schema.
    """
    try:
        records = await db.fetch(
            """
            SELECT
                table_schema AS schema_name,
                table_name,
                column_name,
                data_type
            FROM information_schema.columns
            WHERE table_schema = $1
            ORDER BY table_name, ordinal_position
            """,
            BASE_SCHEMA,
        )

        if not records:
            return {
                "workflow": workflow_name,
                "table_count": 0,
                "tables": [],
                "message": "No tables or columns found in schema",
            }

        tables_map: dict[str, dict] = {}

        for row in records:
            table_name = row["table_name"]

            if table_name not in tables_map:
                tables_map[table_name] = {
                    "table_name": table_name,
                    "schema_name": row["schema_name"],
                    "columns": [],
                }

            tables_map[table_name]["columns"].append(
                {
                    "column_name": row["column_name"],
                    "data_type": row["data_type"],
                }
            )

        return {
            "workflow": workflow_name,
            "table_count": len(tables_map),
            "tables": list(tables_map.values()),
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch table metadata: {e}",
        )


@router.post("/update_staging_tables/run")
async def update_postgre_staging_tables(tables_requested: List[str], user_info: UserInfoRequest, background_tasks: BackgroundTasks):
    

    job_id = str(uuid4())
    user_id = user_info.user_id

    JOB_STORE[job_id] = {
        "status": "running",
        "phase": "schema_validation",
        "total_tables": len(tables_requested),
        "tables_requested": tables_requested,
        "processed": 0,
        "success": 0,
        "skipped": 0,
        "schema_mismatched_tables": [],
        "started_at": datetime.now().isoformat(),
        "completed_at": None
    }

    background_tasks.add_task(updated_staging_tables, job_id, tables_requested)

    return {
        "token_id": job_id,
        "status": "started",
        "message": "Schema validation started"
    }


@router.get("/update_staging_tables/status/{token_id}")
async def staging_tables_update_status(token_id: str):

    job = JOB_STORE.get(token_id)

    if not job:
        return {"status": "invalid_token"}

    return job



@router.get("/tables/details")
async def get_details_for_specific_table(
    schema_name: str,
    table_name: str,
    limit: int = 5,
    offset: int = 0,
    db: Connection = Depends(get_db),
):
    """
    Preview table metadata and sample data.
    """

    try:
        #Validate table exists
        table_exists = await db.fetchval(
            """
            SELECT EXISTS (
                SELECT 1
                FROM information_schema.tables
                WHERE table_schema = $1
                  AND table_name = $2
            )
            """,
            schema_name,
            table_name,
        )

        if not table_exists:
            raise HTTPException(
                status_code=404,
                detail=f"Table '{schema_name}.{table_name}' not found",
            )

        #Total row count
        total_rows = await db.fetchval(
            f'''
            SELECT COUNT(*)
            FROM "{schema_name}"."{table_name}"
            '''
        )

        #Column metadata
        columns = await db.fetch(
            """
            SELECT
                column_name,
                data_type
            FROM information_schema.columns
            WHERE table_schema = $1
              AND table_name = $2
            ORDER BY ordinal_position
            """,
            schema_name,
            table_name,
        )

        column_info = [
            {"column_name": c["column_name"], "data_type": c["data_type"]}
            for c in columns
        ]

        #Top rows preview
        rows = await db.fetch(
            f'''
            SELECT *
            FROM "{schema_name}"."{table_name}"
            LIMIT $1 OFFSET $2
            ''',
            limit,
            offset,
        )

        preview_data = [dict(r) for r in rows]

        return {
            "schema": schema_name,
            "table": table_name,
            "total_rows": total_rows,
            "total_columns": len(column_info),
            "columns": column_info,
            "preview_rows_count": len(preview_data),
            "preview_data": preview_data,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch table preview: {e}",
        )


@router.get("/workflow_used_tables/{workflow_name}")
async def get_workflow_used_tables(
    workflow_name: str,
    db: Connection = Depends(get_db),  # db kept for consistency / future use
):
    """
    Returns only the table names and schema names used in a workflow.
    """
    try:
        pipeline_config = await load_pipeline(db, workflow_name)
        
        if not pipeline_config:
            raise HTTPException(
                status_code=404,
                detail=f"Workflow '{workflow_name}' not found",
            )

        used_tables: Set[tuple[str, str]] = set()

        for step in pipeline_config.get("steps", []):
            filter_criteria = step.get("filter_criteria", {})
            for rule in filter_criteria.get("rules", []):
                table_name = rule.get("source_table")
                # schema_name = rule.get("schema_name", DEFAULT_SCHEMA)

                if table_name:
                    used_tables.add((BASE_SCHEMA, table_name))

        return {
            "workflow": workflow_name,
            "table_count": len(used_tables),
            "tables": [
                {
                    "schema_name": schema,
                    "table_name": table,
                }
                for schema, table in sorted(used_tables)
            ],
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch workflow used tables: {e}",
        )



@router.get("/global_filters_updated_new/{workflow_name}", response_model=GlobalFiltersResponseUpdated)
async def get_global_filters_info_updated_new(
    workflow_name: str,
    db: Connection = Depends(get_db),
):
    """
    Returns distinct global filters as flat rows (dataframe-style JSON).
    Fully dynamic based on cached global filter columns.
    """
    try:
        pipeline_config = await load_pipeline(db, workflow_name)
        
        if not pipeline_config:
            raise HTTPException(
                status_code=404,
                detail=f"Workflow '{workflow_name}' not found",
            )
        
        # Fetch from cache
        base_table, global_filter_columns = _extract_global_filters_from_pipeline(pipeline_config)

        if not global_filter_columns:
            return {"workflow": workflow_name, "filters": []}

        # Maintain order of columns
        columns_sql = ", ".join([f'"{col}"' for col in global_filter_columns])

        # Build query dynamically
        query = f"""
        SELECT DISTINCT {columns_sql}
        FROM {BASE_SCHEMA}.{base_table}
        ORDER BY {columns_sql}
        """

        records = await db.fetch(query)

        # Convert records to JSON-friendly dict
        filters = [
            {col: str(row[col]) if row[col] is not None else None for col in global_filter_columns}
            for row in records
        ]

        return {
            "workflow": workflow_name,
            "filters": filters
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch global filter values: {e}",
        )
    


# ====================================
# ----------- OUTPUT TABLE AI ASSISTANT----------------
# ======================================


@router.get(
    "/pipelines/{workflow_name}/output_table/ai_assistant/default_queries", response_model=ChatDefaultQueries
)
async def get_ai_assistant_default_queries(workflow_name: str, db: Connection = Depends(get_db)):
    """Remove a filter rule from a workflow step."""

    if not await pipeline_exists(db, workflow_name):
        raise HTTPException(
            status_code=404,
            detail=f"Pipeline '{workflow_name}' not found"
        )

    Default_question: Dict[int, str] = {
        1: "Show Distribution of sites Market wise.",
        2: "How many sites available in each region ?",
        3: "Distribution of Failed sites market wise.",
        4: "How many sites qualified and show graph region wise.",
    }

    response = Default_question

    return ChatDefaultQueries(
        questions=response
    )



@router.post("/add/user/pm_copilot/users")
async def add_user_pm_copilot(
    user_info: UserInfoRequest, 
    request: AddUsersPMCoPilotRequest,
    db: Connection = Depends(get_db),
):
    try:
        user_id = user_info.user_id
        user_ids = request.user_ids

        if isinstance(user_ids, str):
            user_ids = [user_ids]

        valid_records = []
        skipped_users = []

        for email in user_ids:
            if not email.endswith("@nokia.com"):
                skipped_users.append(email)
                continue

            name = _extract_name_from_email(email)

            # tuple must match query placeholders
            valid_records.append((name, email, "1234", 1))


        if valid_records:
            query = """
                INSERT INTO osdp_pwc_sch.users (name, email, password, role_id)
                VALUES ($1, $2, $3, $4)
                ON CONFLICT (email) DO NOTHING
            """

            await db.executemany(query, valid_records)
        else:
            return {
                "valid_user_ids": len(valid_records),
                "skipped_users": skipped_users,
                "status": "FAILED"
            }

        return {
            "added_count": len(valid_records),
            "added_users": [
                {"email": r[1], "name": r[0]} for r in valid_records
            ],
            "skipped_users": skipped_users,
            "status": "SUCCESS"
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to Add Users: {str(e)}",
        )