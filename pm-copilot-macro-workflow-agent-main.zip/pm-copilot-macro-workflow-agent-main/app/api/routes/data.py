"""
Data management endpoints for loading and querying site data.
"""

from typing import List, Dict, Any,  Set
from fastapi import APIRouter, Depends, HTTPException
from asyncpg import Connection
import tempfile
import os

from app.db.pool import get_db
from app.services.data_sites import get_all_site_codes
from app.schemas.workflow import MessageResponse

from app.config.pipeline_storage import (
    load_pipeline
)

router = APIRouter(prefix="/data", tags=["Data"])




@router.get("/site-codes", response_model=List[str])
async def list_site_codes(db: Connection = Depends(get_db)):
    """Get all site codes from the database."""
    try:
        return await get_all_site_codes(db)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to get site codes: {e}")


@router.get("/workflow_used_tables/{workflow_name}")
async def get_workflow_used_tables(
    workflow_name: str,
    db: Connection = Depends(get_db),  # db kept for consistency / future use
):
    """
    Returns only the table names and schema names used in a workflow.
    """
    try:
        pipeline_config = load_pipeline(workflow_name)
        
        DEFAULT_SCHEMA = "pwc_macro_staging_schema"     

        if not pipeline_config:
            raise HTTPException(
                status_code=404,
                detail=f"Workflow '{workflow_name}' not found",
            )

        used_tables: Set[tuple[str, str]] = set()

        for step in pipeline_config.get("steps", []):
            filter_criteria = step.get("filter_criteria", {})
            for rule in filter_criteria.get("rules", []):
                table_name = rule.get("source_table")
                schema_name = rule.get("schema_name", DEFAULT_SCHEMA)

                if table_name:
                    used_tables.add((schema_name, table_name))

        return {
            "workflow": workflow_name,
            "table_count": len(used_tables),
            "tables": [
                {
                    "schema_name": schema,
                    "table_name": table,
                }
                for schema, table in sorted(used_tables)
            ],
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch workflow used tables: {e}",
        )


@router.get("/workflow_table_info/{workflow_name}")
async def get_workflow_table_info(
    workflow_name: str,  # kept intentionally (future use: auth, routing, lineage)
    db: Connection = Depends(get_db),
):
    """
    Returns schema, table, column name, and data type
    for all tables available in the backend schema.
    """
    try:
        DEFAULT_SCHEMA = "pwc_macro_staging_schema"

        records = await db.fetch(
            """
            SELECT
                table_schema AS schema_name,
                table_name,
                column_name,
                data_type
            FROM information_schema.columns
            WHERE table_schema = $1
            ORDER BY table_name, ordinal_position
            """,
            DEFAULT_SCHEMA,
        )

        if not records:
            return {
                "workflow": workflow_name,
                "table_count": 0,
                "tables": [],
                "message": "No tables or columns found in schema",
            }

        tables_map: dict[str, dict] = {}

        for row in records:
            table_name = row["table_name"]

            if table_name not in tables_map:
                tables_map[table_name] = {
                    "table_name": table_name,
                    "schema_name": row["schema_name"],
                    "columns": [],
                }

            tables_map[table_name]["columns"].append(
                {
                    "column_name": row["column_name"],
                    "data_type": row["data_type"],
                }
            )

        return {
            "workflow": workflow_name,
            "table_count": len(tables_map),
            "tables": list(tables_map.values()),
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch table metadata: {e}",
        )
    


@router.get("/tables/details")
async def get_table_details(
    schema_name: str,
    table_name: str,
    limit: int = 5,
    offset: int = 0,
    db: Connection = Depends(get_db),
):
    """
    Preview table metadata and sample data.
    """

    try:
        #Validate table exists
        table_exists = await db.fetchval(
            """
            SELECT EXISTS (
                SELECT 1
                FROM information_schema.tables
                WHERE table_schema = $1
                  AND table_name = $2
            )
            """,
            schema_name,
            table_name,
        )

        if not table_exists:
            raise HTTPException(
                status_code=404,
                detail=f"Table '{schema_name}.{table_name}' not found",
            )

        #Total row count
        total_rows = await db.fetchval(
            f'''
            SELECT COUNT(*)
            FROM "{schema_name}"."{table_name}"
            '''
        )

        #Column metadata
        columns = await db.fetch(
            """
            SELECT
                column_name,
                data_type
            FROM information_schema.columns
            WHERE table_schema = $1
              AND table_name = $2
            ORDER BY ordinal_position
            """,
            schema_name,
            table_name,
        )

        column_info = [
            {"column_name": c["column_name"], "data_type": c["data_type"]}
            for c in columns
        ]

        #Top rows preview
        rows = await db.fetch(
            f'''
            SELECT *
            FROM "{schema_name}"."{table_name}"
            LIMIT $1 OFFSET $2
            ''',
            limit,
            offset,
        )

        preview_data = [dict(r) for r in rows]

        return {
            "schema": schema_name,
            "table": table_name,
            "total_rows": total_rows,
            "total_columns": len(column_info),
            "columns": column_info,
            "preview_rows_count": len(preview_data),
            "preview_data": preview_data,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch table preview: {e}",
        )


