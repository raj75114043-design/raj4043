"""
Workflow Modification Agent API routes.

This module provides REST endpoints for interacting with the LangGraph-based
Workflow Modification Agent. The agent interprets natural language requests
to modify workflow pipelines.

Endpoints support two modes:
1. Direct execution - Changes are applied immediately
2. Action plan - Returns the planned action for review before execution
"""

from typing import Optional
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from datetime import datetime
from fastapi import Header, Depends
from fastapi import Security, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import secrets

from app.core.llm_client import get_llm_client
from app.agents.workflow_modification_agent import (
    WorkflowModificationAgent,
    ModificationAction,
    AgentResponse,
    AGENT_INFO,
)
from app.config.pipeline_storage import load_pipeline, pipeline_exists
from app.api.routes.workflow_orchestration import _get_workflow
from app.config.pipeline_storage import (
    save_pipeline
)

router = APIRouter(prefix="/workflow_agent", tags=["Workflow Modification Agent"])


DEV_PASSWORD = "pwc_macro_team"

security = HTTPBasic()

def verify_dev_password(credentials: HTTPBasicCredentials = Depends(security)):
    correct = secrets.compare_digest(credentials.password, "pwc_macro_team")
    if not correct:
        raise HTTPException(status_code=401, headers={"WWW-Authenticate": "Basic"})


# ============================================================================
# Request/Response Schemas
# ============================================================================


class ModifyRequest(BaseModel):
    """Request to modify a workflow using natural language."""

    request: str = Field(
        ...,
        description="Natural language modification request (e.g., 'mute step 2', 'change step 1 to use OR logic')",
        min_length=1,
    )
    execute: bool = Field(
        default=True,
        description="If True, execute the modification immediately. If False, return the action plan without executing.",
    )


class ActionPlanRequest(BaseModel):
    """Request to get an action plan without executing."""

    request: str = Field(
        ...,
        description="Natural language modification request",
        min_length=1,
    )


class ExecuteActionRequest(BaseModel):
    """Request to execute a previously generated action plan."""

    operation: str = Field(
        ...,
        description="Operation type: mute_step, unmute_step, change_logic, add_criteria",
    )
    step_id: int = Field(..., description="ID of the step to modify")

    # For change_logic
    require_all: Optional[bool] = Field(
        None, description="For change_logic: True for AND, False for ANY"
    )

    # For add_criteria
    source_table: Optional[str] = Field(None, description="Database table name")
    site_code_column: Optional[str] = Field(
        "site_code", description="Column containing site codes"
    )
    column_name: Optional[str] = Field(None, description="Column to validate")
    operator: Optional[str] = Field(None, description="Validation operator")
    expected_value: Optional[str] = Field(None, description="Expected value for comparison")
    description: Optional[str] = Field(None, description="Human-readable description")


class ModificationResponse(BaseModel):
    """Response from a modification request."""

    success: bool = Field(..., description="Whether the operation succeeded")
    message: str = Field(..., description="Result message")
    actions: list[dict] = Field(default_factory=list, description="The actions that were/would be executed")
    executed: bool = Field(..., description="Whether the actions were executed")


# ============================================================================
# Endpoints
# ============================================================================


@router.post("/pipelines/{workflow_name}/modify", response_model=ModificationResponse)
async def modify_workflow(workflow_name: str, request: ModifyRequest):
    """
    Modify a workflow pipeline using natural language.

    The agent interprets the request and either:
    - Executes the modification immediately (if execute=True)
    - Returns the action plan for review (if execute=False)

    Examples:
    - "mute step 2"
    - "enable the first step"
    - "change step 3 to require all conditions"
    - "make step 1 use OR logic"
    - "add a rule to step 2 to check that status is not null"
    """
    # Load the workflow
    workflow = _get_workflow(workflow_name)

    # Create the agent
    llm_client = get_llm_client("medium")
    agent = WorkflowModificationAgent(llm_client)

    # Run the agent
    response = await agent.run(
        user_request=request.request,
        pipeline=workflow,
        execute_directly=request.execute,
    )

    workflow_dict = {
        "name": workflow.name,
        "version": "Latest",
        "generated_at": datetime.now().isoformat(),
        "steps": [step.to_dict() for step in workflow.steps],
    }

    save_pipeline(workflow.name, workflow_dict)


    return ModificationResponse(
        success=response.success,
        message=response.message,
        actions=[a.to_dict() for a in response.actions],
        executed=response.executed,
    )


@router.post("/pipelines/{workflow_name}/plan", response_model=ModificationResponse)
async def get_modification_plan(workflow_name: str, request: ActionPlanRequest):
    """
    Get a modification action plan without executing it.

    Use this endpoint to preview what changes would be made before applying them.
    The returned action can be inspected and then executed using the /execute endpoint.
    """
    # Load the workflow
    workflow = _get_workflow(workflow_name)

    # Create the agent
    llm_client = get_llm_client("medium")
    agent = WorkflowModificationAgent(llm_client)

    # Get the plan
    response = await agent.get_action_plan(
        user_request=request.request,
        pipeline=workflow,
    )

    return ModificationResponse(
        success=response.success,
        message=response.message,
        actions=[a.to_dict() for a in response.actions],
        executed=False,
    )


@router.post("/pipelines/{workflow_name}/execute", response_model=ModificationResponse)
async def execute_action_plan(workflow_name: str, request: ExecuteActionRequest,credentials: HTTPBasicCredentials = Depends(verify_dev_password)):
    """
    Execute a modification action plan directly.

    Use this endpoint to execute a specific action without going through
    the LLM. Useful when:
    - You have a previously generated action plan to execute
    - You want to programmatically modify a workflow
    - You want to bypass the LLM for known operations
    """
    # Load the workflow
    workflow = _get_workflow(workflow_name)

    # Create the action
    action = ModificationAction(
        operation=request.operation,
        step_id=request.step_id,
        require_all=request.require_all,
        source_table=request.source_table,
        site_code_column=request.site_code_column or "site_code",
        column_name=request.column_name,
        operator=request.operator,
        expected_value=request.expected_value,
        description=request.description,
    )

    # Create agent and execute (wrap single action in list)
    llm_client = get_llm_client("medium")
    agent = WorkflowModificationAgent(llm_client)
    response = agent.execute_action_plan(workflow, [action])

    return ModificationResponse(
        success=response.success,
        message=response.message,
        actions=[a.to_dict() for a in response.actions],
        executed=response.executed,
    )


@router.get("/capabilities")
async def get_agent_capabilities():
    """
    Get information about the agent's capabilities.

    Returns the available operations and operators that the agent understands.
    """
    return AGENT_INFO
