import psycopg2
import json
import pytz
from datetime import datetime
from psycopg2 import sql
from typing import List, Dict, Any,  Set
from app.core.data_fetch_config import(
    TABLES_TO_STAGING, 
    DB_CONFIG, 
    STAGING_SOURCE_SCHEMA, 
    STAGING_TARGET_SCHEMA, 
    STAGING_PREFIX
)    
IST = pytz.timezone("Asia/Kolkata")

JOB_STORE = {}


# -------------------------------
# Create staging table
# -------------------------------

def _create_staging_table(cur, source_table, staging_table):

    query = sql.SQL(
        "CREATE TABLE IF NOT EXISTS {}.{} (LIKE {}.{} INCLUDING ALL)"
    ).format(
        sql.Identifier(STAGING_TARGET_SCHEMA),
        sql.Identifier(staging_table),
        sql.Identifier(STAGING_SOURCE_SCHEMA),
        sql.Identifier(source_table),
    )

    cur.execute(query)


# -------------------------------
# Compare schemas
# -------------------------------

def _compare_table_schema(cur, source_table, staging_table):

    schema_query = """
    SELECT column_name, data_type
    FROM information_schema.columns
    WHERE table_schema = %s
    AND table_name = %s
    ORDER BY ordinal_position
    """

    cur.execute(schema_query, (STAGING_SOURCE_SCHEMA, source_table))
    source_columns = cur.fetchall()

    cur.execute(schema_query, (STAGING_TARGET_SCHEMA, staging_table))
    staging_columns = cur.fetchall()

    source_dict = {c[0]: c[1] for c in source_columns}
    staging_dict = {c[0]: c[1] for c in staging_columns}

    if len(source_dict) != len(staging_dict):
        return False

    for col, dtype in source_dict.items():

        if col not in staging_dict:
            return False

        if staging_dict[col] != dtype:
            return False

    return True

# -------------------------------
# Copy table data
# -------------------------------

def _copy_table_data(cur, source_table, staging_table):

    truncate_query = sql.SQL(
        "TRUNCATE TABLE {}.{}"
    ).format(
        sql.Identifier(STAGING_TARGET_SCHEMA),
        sql.Identifier(staging_table),
    )

    cur.execute(truncate_query)

    copy_query = sql.SQL(
        "INSERT INTO {}.{} SELECT * FROM {}.{}"
    ).format(
        sql.Identifier(STAGING_TARGET_SCHEMA),
        sql.Identifier(staging_table),
        sql.Identifier(STAGING_SOURCE_SCHEMA),
        sql.Identifier(source_table),
    )

    cur.execute(copy_query)


# -------------------------------
# Main pipeline
# -------------------------------

def updated_staging_tables(job_id: str, tables_requested: List[str]):

    job = JOB_STORE.get(job_id)

    if not job:
        return

    try:

        conn = psycopg2.connect(**DB_CONFIG)
        conn.autocommit = True
        cur = conn.cursor()

        mismatched_tables = []

        # Phase 1 : Validation
        # -------------------------
        invalid_tables = [
            table for table in tables_requested
            if table not in TABLES_TO_STAGING
        ]

        if invalid_tables:
            raise ValueError(f"Invalid tables requested: {invalid_tables}. ")

        # If valid → proceed
        TABLES_REQUESTED = tables_requested

        # -------------------------
        # Phase 1 : Schema Validation
        # -------------------------

        for table in TABLES_REQUESTED:

            staging_table = f"{STAGING_PREFIX}{table}"

            _create_staging_table(cur, table, staging_table)

            schema_ok = _compare_table_schema(cur, table, staging_table)

            if not schema_ok:
                mismatched_tables.append(table)

        # If any schema mismatch → abort
        if mismatched_tables:

            job["status"] = "failed"
            job["phase"] = "schema_validation"
            job["schema_mismatched_tables"] = mismatched_tables
            job["message"] = "Staging update aborted due to schema mismatch"
            job["completed_at"] = datetime.now(IST)

            cur.close()
            conn.close()

            return

        # -------------------------
        # Phase 2 : Data Copy
        # -------------------------

        job["phase"] = "data_copy"

        success = 0

        for idx, table in enumerate(TABLES_REQUESTED, 1):

            staging_table = f"{STAGING_PREFIX}{table}"

            _copy_table_data(cur, table, staging_table)

            success += 1

            job["processed"] = idx
            job["success"] = success

        job["status"] = "completed"
        job["completed_at"] = datetime.now(IST)

        cur.close()
        conn.close()

    except Exception as e:

        job["status"] = "failed"
        job["error"] = str(e)
        job["completed_at"] = datetime.now(IST)



def updated_staging_tables_cron(job_id="staging_job"):

    conn = psycopg2.connect(**DB_CONFIG)
    conn.autocommit = True
    cur = conn.cursor()

    start_time = datetime.now(IST)

    # -------------------------
    # Insert RUNNING entry
    # -------------------------
    cur.execute("""
        INSERT INTO pwc_workflow_agent_schema.staging_table_execution_log (job_id, start_time, status)
        VALUES (%s, %s, %s)
        RETURNING id
    """, (job_id, start_time, "RUNNING"))

    execution_id = cur.fetchone()[0]

    mismatched_tables = []

    try:
        # -------------------------
        # Phase 1 : Schema Validation
        # -------------------------
        for table in TABLES_TO_STAGING:

            staging_table = f"{STAGING_PREFIX}{table}"

            _create_staging_table(cur, table, staging_table)

            schema_ok = _compare_table_schema(cur, table, staging_table)

            if not schema_ok:
                mismatched_tables.append(table)

        # Abort if mismatch
        if mismatched_tables:

            cur.execute("""
                UPDATE pwc_workflow_agent_schema.staging_table_execution_log
                SET end_time = %s,
                    status = %s,
                    details = %s
                WHERE id = %s
            """, (
                datetime.now(IST),
                "FAILED",
                json.dumps({"mismatched_tables": mismatched_tables}),
                execution_id
            ))

            return

        # -------------------------
        # Phase 2 : Data Copy
        # -------------------------
        success = 0

        for table in TABLES_TO_STAGING:
            staging_table = f"{STAGING_PREFIX}{table}"
            _copy_table_data(cur, table, staging_table)
            success += 1

        # -------------------------
        # SUCCESS update
        # -------------------------
        cur.execute("""
            UPDATE pwc_workflow_agent_schema.staging_table_execution_log
            SET end_time = %s,
                status = %s,
                details = %s
            WHERE id = %s
        """, (
            datetime.now(IST),
            "SUCCESS",
            json.dumps({"tables_processed": success}),
            execution_id
        ))

    except Exception as e:

        # -------------------------
        # FAILURE update
        # -------------------------
        cur.execute("""
            UPDATE pwc_workflow_agent_schema.staging_table_execution_log
            SET end_time = %s,
                status = %s,
                details = %s
            WHERE id = %s
        """, (
            datetime.now(IST),
            "ERROR",
            json.dumps({"error": str(e)}),
            execution_id
        ))

        raise

    finally:
        cur.close()
        conn.close()