import json
from pathlib import Path
from typing import Dict, Any

OUTPUT_DIR = Path("output/workflows")


def load_latest_workflow_execution(workflow_name: str) -> Dict[str, Any]:
    file_path = OUTPUT_DIR / f"{workflow_name.replace(' ', '_')}.json"

    if not file_path.exists():
        raise FileNotFoundError(f"No execution found for workflow '{workflow_name}'")

    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # You overwrite executions, so always index 0
    return data["executions"][0]