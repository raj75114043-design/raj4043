"""
Data 

This module provides utilities for loading the dummy Excel data
into the PostgreSQL database for testing the workflow agent.
"""

import pandas as pd
from pathlib import Path
from asyncpg import Connection
from typing import Dict, List


async def get_all_site_codes(db: Connection) -> List[str]:
    """Get all site codes from the MBT base table."""
    rows = await db.fetch("SELECT DISTINCT(s_site_id) as site_code FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined LIMIT 1000")
    return [row["site_code"] for row in rows]
