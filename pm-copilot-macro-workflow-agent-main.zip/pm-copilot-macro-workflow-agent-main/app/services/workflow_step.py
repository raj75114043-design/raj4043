"""
WorkflowStep service for executing and managing individual workflow steps.

This service handles the core step logic including validation, filtering,
and execution tracking.
"""

from typing import List, Dict, Any, Optional
from datetime import datetime
from asyncpg import Connection
from collections import defaultdict
from app.services.workflow_save_output import save_view_output_table

from app.models.workflow import (
    StepMetaData,
    StepExecutionConfig,
    FilterCriteriaConfig,
    ViewOutputConfig,
    ComputationConfig,
    AgentConfig,
    SitesFilterRule,
    StepExecutionResult,
)
from app.models.enums import (
    ValidationOperator,
    OnDisabledStrategy,
    MergeStrategy,
    ConditionalLogic,
    StepStatus,
)


class WorkflowStep:
    """
    Represents a single step in a workflow pipeline.

    A step can:
    - Filter site codes based on validation rules
    - Track execution history and results
    - Be enabled/disabled dynamically
    - Have multiple dependencies with configurable merge strategies
    """

    def __init__(
        self,
        meta: StepMetaData,
        execution: StepExecutionConfig,
        filter_criteria: Optional[FilterCriteriaConfig] = None,
        view_output: Optional[ViewOutputConfig] = None,
        computation: Optional[ComputationConfig] = None,
        agent: Optional[AgentConfig] = None,
    ):
        self.meta = meta
        self.execution = execution
        self.filter_criteria = filter_criteria
        self.view_output = view_output
        self.computation = computation
        self.agent = agent

        # Execution tracking
        self.input_site_codes: List[str] = []
        self.passed_site_codes: List[str] = []
        self.failed_site_codes: List[str] = []
        self.execution_time: Optional[float] = None
        self.execution_count: int = 0

        # Validate merge strategy for multi-dependency steps
        if self.execution.depends_on and len(self.execution.depends_on) > 1:
            if not self.execution.merge_strategy:
                raise ValueError(
                    f"Step '{self.meta.step_id}' has multiple dependencies "
                    "but no merge strategy defined"
                )
        else:
            self.execution.merge_strategy = MergeStrategy.UNION
    

    @staticmethod
    def _rule_to_sql(rule: SitesFilterRule) -> str:
        col = f'"{rule.column_name}"'
        op = rule.operator

        if op == ValidationOperator.NOT_NULL:
            return f"{col} IS NOT NULL"

        if op == ValidationOperator.IS_NULL:
            return f"{col} IS NULL"

        if op == ValidationOperator.EQUALS:
            return f"{col} = '{rule.expected_value}'"

        if op == ValidationOperator.NOT_EQUALS:
            return f"{col} <> '{rule.expected_value}'"

        if op == ValidationOperator.GREATER_THAN:
            return f"{col} > {rule.expected_value}"

        if op == ValidationOperator.LESS_THAN:
            return f"{col} < {rule.expected_value}"

        if op == ValidationOperator.IN_LIST:
            if not rule.expected_value:
                return "FALSE"
            values = ",".join(f"'{v}'" for v in rule.expected_value)
            return f"{col} IN ({values})"

        if op == ValidationOperator.NOT_IN_LIST:
            if not rule.expected_value:
                return "TRUE"
            values = ",".join(f"'{v}'" for v in rule.expected_value)
            return f"{col} NOT IN ({values})"

        if op == ValidationOperator.CONTAINS:
            return f"{col} ILIKE '%{rule.expected_value}%'"

        if op == ValidationOperator.DATE_PASSED:
            return f"{col} <= CURRENT_TIMESTAMP"

        if op == ValidationOperator.DATE_NOT_PASSED:
            return f"{col} > CURRENT_TIMESTAMP"

        return "FALSE"


    def _build_bulk_step_sql(self) -> str:
        """
        Build a single SQL query that:
        - Evaluates all filter rules in bulk
        - Produces one boolean column per rule
        - Produces a final `passed` column based on AND / OR logic
        - GUARANTEES one row per site_code
        """

        # ------------------------------------------------------------------
        # 1. Short-circuit: no rules → all sites pass
        # ------------------------------------------------------------------
        if not self.filter_criteria or not self.filter_criteria.rules:
            return """
            WITH base_sites AS (
                SELECT UNNEST($1::text[]) AS site_code
            )
            SELECT
                site_code,
                TRUE AS passed
            FROM base_sites
            """

        rules = self.filter_criteria.rules

        ctes: list[str] = []
        joins: list[str] = []
        rule_columns: list[str] = []

        # ------------------------------------------------------------------
        # 2. Base CTE (controls cardinality)
        # ------------------------------------------------------------------
        ctes.append("""
        base_sites AS (
            SELECT UNNEST($1::text[]) AS site_code
        )
        """)

        # ------------------------------------------------------------------
        # 3. One AGGREGATED CTE per rule (KEY FIX)
        # ------------------------------------------------------------------
        for idx, rule in enumerate(rules, start=1):
            table = rule.source_table
            if "." not in table:
                table = f"pwc_macro_staging_schema.{table}"

            rule_expr = self._rule_to_sql(rule)

            ctes.append(f"""
            rule_{idx} AS (
                SELECT
                    "{rule.site_code_column}" AS site_code,
                    BOOL_OR({rule_expr}) AS rule_{idx}
                FROM {table}
                WHERE "{rule.site_code_column}" = ANY($1)
                GROUP BY "{rule.site_code_column}"
            )
            """)

            rule_columns.append(
                f"COALESCE(r{idx}.rule_{idx}, FALSE) AS rule_{idx}"
            )

            joins.append(
                f"LEFT JOIN rule_{idx} r{idx} ON b.site_code = r{idx}.site_code"
            )

        # ------------------------------------------------------------------
        # 4. Final AND / OR logic
        # ------------------------------------------------------------------
        operator = (
            " AND "
            if self.filter_criteria.conditional_logic == ConditionalLogic.AND
            else " OR "
        )

        passed_expression = operator.join(
            f"COALESCE(r{idx}.rule_{idx}, FALSE)"
            for idx in range(1, len(rules) + 1)
        )

        # ------------------------------------------------------------------
        # 5. Final SQL
        # ------------------------------------------------------------------
        return f"""
        WITH
        {",".join(ctes)}

        SELECT
            b.site_code,
            {", ".join(rule_columns)},
            ({passed_expression}) AS passed
        FROM base_sites b
        {" ".join(joins)}
        ORDER BY b.site_code
        """


    async def execute_bulk_validation(
        self,
        site_codes: list[str],
        db: Connection,
    ):
        sql = self._build_bulk_step_sql()
        # print("=================")
        # print(self.meta.step_id)
        # print(sql)
        # print("=================")

        rows = await db.fetch(sql, site_codes)

        passed = []
        failed = []
        detailed = []

        for row in rows:
            record = dict(row)
            site = record["site_code"]

            detailed.append(record)

            if record["passed"]:
                passed.append(site)
            else:
                failed.append(site)

        return passed, failed, detailed


    async def execute(
        self, site_codes: List[str], db: Connection
    ) -> StepExecutionResult:
        """
        Execute the step on a list of site codes.

        Args:
            site_codes: List of site codes to process
            db: Database connection

        Returns:
            StepExecutionResult with all execution details
        """
        start_time = datetime.now()
        self.execution_count += 1

        self.input_site_codes = site_codes
        self.passed_site_codes = []
        self.failed_site_codes = []

        # Handle disabled step
        if not self.execution.is_enabled:
            if self.execution.on_disabled == OnDisabledStrategy.EMPTY:
                output_sites = []
            else:
                output_sites = site_codes

            self.execution_time = (datetime.now() - start_time).total_seconds()

            return StepExecutionResult(
                step_id=self.meta.step_id,
                step_name=self.meta.name,
                step_description=self.meta.description,
                phase_id=self.meta.phase_id,
                phase_name=self.meta.phase_name,
                category=self.meta.category,
                enabled=self.execution.is_enabled,
                depends_on=self.execution.depends_on,
                filter_enabled=self.filter_criteria.enabled,
                status=StepStatus.DISABLED,
                input_count=len(site_codes),
                passed_count=len(output_sites),
                execution_time=self.execution_time
            )

        # Execute filter validation
        passed, failed, detailed_results = await self.execute_bulk_validation(
            site_codes, db
        )

        self.passed_site_codes = passed
        self.failed_site_codes = failed

        output_info = await save_view_output_table(
            db=db,
            step_id=self.meta.step_id,
            rules=self.filter_criteria.rules,
            input_site_codes=self.input_site_codes,
            passed_site_codes=self.passed_site_codes,
            failed_site_codes=self.failed_site_codes,
        )

        self.execution_time = (datetime.now() - start_time).total_seconds()

        return StepExecutionResult(
            step_id=self.meta.step_id,
            step_name=self.meta.name,
            step_description=self.meta.description,
            phase_id=self.meta.phase_id,
            phase_name=self.meta.phase_name,
            category=self.meta.category,
            enabled=self.execution.is_enabled,
            depends_on=self.execution.depends_on,
            filter_enabled=self.filter_criteria.enabled,
            status=StepStatus.COMPLETED,
            input_count=len(site_codes),
            passed_count=len(self.passed_site_codes),
            failed_count=len(self.failed_site_codes),
            passed_site_codes=self.passed_site_codes,
            failed_site_codes=self.failed_site_codes,
            execution_time=self.execution_time,
            output_table=output_info.get("output_table"),
            output_table_status=output_info.get("output_table_status")
        )
    




    # ========================================================================
    # Control Methods
    # ========================================================================

    def mute(self) -> None:
        """Disable the step."""
        self.execution.is_enabled = False

    def unmute(self) -> None:
        """Enable the step."""
        self.execution.is_enabled = True

    # ========================================================================
    # Filter Criteria Management
    # ========================================================================

    def add_filter_rule(self, rule: SitesFilterRule) -> None:
        """Add a filter rule to the step."""
        if self.filter_criteria is None:
            self.filter_criteria = FilterCriteriaConfig()
        self.filter_criteria.rules.append(rule)

    def remove_filter_rule(self, rule_index: int) -> bool:
        """Remove a filter rule by index."""
        if self.filter_criteria is None:
            return False
        if 0 <= rule_index < len(self.filter_criteria.rules):
            self.filter_criteria.rules.pop(rule_index)
            return True
        return False

    def update_filter_logic(self, require_all: bool) -> None:
        """Update the filter conditional logic."""
        if self.filter_criteria is None:
            self.filter_criteria = FilterCriteriaConfig()
        self.filter_criteria.conditional_logic = (
            ConditionalLogic.AND if require_all else ConditionalLogic.ANY
        )

    # ========================================================================
    # Serialization
    # ========================================================================

    def get_summary(self) -> Dict[str, Any]:
        """Get a summary of the step configuration."""
        return {
            "step_id": self.meta.step_id,
            "name": self.meta.name,
            "step_description": self.meta.description,
            "phase_id": self.meta.phase_id,
            "phase_name": self.meta.phase_name,
            "category": self.meta.category,
            "enabled": self.execution.is_enabled,
            "depends_on": self.execution.depends_on,
            "merge_strategy": (
                self.execution.merge_strategy.value
                if self.execution.merge_strategy
                else None
            ),
            "filter_enabled": (
                self.filter_criteria.enabled if self.filter_criteria else False
            ),
            "criteria_count": (
                len(self.filter_criteria.rules) if self.filter_criteria else 0
            )
        }

    def get_step_detail(self) -> Dict[str, Any]:
        """Get a summary of the step configuration."""
        return {
            "step_id": self.meta.step_id,
            "name": self.meta.name,
            "step_description": self.meta.description,
            "phase_id": self.meta.phase_id,
            "phase_name": self.meta.phase_name,
            "category": self.meta.category,
            "enabled": self.execution.is_enabled,
            "depends_on": self.execution.depends_on,
            "merge_strategy": (
                self.execution.merge_strategy.value
                if self.execution.merge_strategy
                else None
            ),
            "filter_enabled": (
                self.filter_criteria.enabled if self.filter_criteria else False
            ),
            "filter_criteria": (
                self.filter_criteria.to_dict() if self.filter_criteria else None
            ),
            # # "execution_count": self.execution_count,
            # "last_execution_time": self.execution_time,
            # "qualified_sites_count": len(self.passed_site_codes) if self.passed_site_codes else 0,
            # "failed_sites_count": len(self.failed_site_codes) if self.failed_site_codes else 0,
            # "total_sites_count": (
            #     (len(self.passed_site_codes) if self.passed_site_codes else 0)
            #     + (len(self.failed_site_codes) if self.failed_site_codes else 0)
            # ),
            "computation": self.computation if self.computation else None,
            "agent_integration": self.agent if self.agent else None 
        }
    

    def to_dict(self) -> Dict[str, Any]:
        """Convert step to dictionary representation."""
        return {
            "meta": self.meta.to_dict(),
            "execution": self.execution.to_dict(),
            "filter_criteria": (
                self.filter_criteria.to_dict() if self.filter_criteria else None
            ),
            "view_output": (
                self.view_output.to_dict() if self.view_output else None
            ),
            "computation": (
                self.computation.to_dict() if self.computation else None
            ),
            "agent": self.agent.to_dict() if self.agent else None,
        }
