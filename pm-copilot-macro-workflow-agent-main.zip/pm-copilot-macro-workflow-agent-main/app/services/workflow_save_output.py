import re
from typing import List, Dict
from asyncpg import Connection
from app.core.data_fetch_config import BASE_SCHEMA, WORKFLOW_OUTPUT_SCHEMA

from app.services.data_sites import(
        get_cached_primary_key,
        get_cached_base_table,
        get_cached_global_filter_columns,
        get_cached_common_columns,
)

def _safe_identifier(name: str) -> str:
    return (
        name.lower()
        .replace(".", "_")
        .replace(" ", "_")
        .replace("-", "_")
    )

def _normalize_identifier(name: str) -> str:
    # Replace one or more whitespace chars with underscore
    return re.sub(r"\s+", "_", name.strip()).lower()


def _get_base_columns(
    primary_key_column: str,
    global_filter_columns: List[str],
    common_columns: List[str],
) -> List[str]:
    """
    Combine all required base columns excluding primary key
    """
    return sorted({
        col
        for col in (set(global_filter_columns) | set(common_columns))
        if col and col != primary_key_column
    })


async def save_view_output_table(
    *,
    db: Connection,
    workflow_name: str,
    step_id: str,
    sql: str,  # pass full bulk SQL
    primary_keys: List[str],
) -> dict:
    """
    Creates final output table by:
    1. Running bulk rule SQL
    2. Joining with base table for additional columns
    3. Saving result
    """

    primary_key_column = get_cached_primary_key(workflow_name)
    base_table = get_cached_base_table(workflow_name)
    global_filter_columns = get_cached_global_filter_columns(workflow_name)
    common_columns = get_cached_common_columns(workflow_name)


    normalized_workflow_name = _normalize_identifier(workflow_name)
    table_name = _safe_identifier(f"wf_step_{step_id}_output")

    full_table_name = f'{WORKFLOW_OUTPUT_SCHEMA}."{normalized_workflow_name}_{table_name}"'

    #Get base columns
    base_columns = _get_base_columns(
        primary_key_column,
        global_filter_columns,
        common_columns,
    )

    # base_cols_sql = ", ".join([f'b."{col}"' for col in base_columns])
    base_cols_sql = ", ".join([f'b."{col}"' for col in base_columns])

    select_clause = f"{base_cols_sql}, e.*" if base_cols_sql else "e.*"

    final_sql = f"""
    CREATE TABLE {full_table_name} AS
    WITH eval AS (
        {sql}
    )
    SELECT DISTINCT
        {select_clause}
    FROM eval e
    LEFT JOIN {BASE_SCHEMA}.{base_table} b
        ON e."{primary_key_column}" = b."{primary_key_column}"
    """

    try:
        await db.execute(f'DROP TABLE IF EXISTS {full_table_name}')
        print("Old table dropped")

        await db.execute(final_sql, primary_keys)
        print("New table created")

        return {
            "output_table": full_table_name,
            "output_table_status": "CREATED",
        }

    except Exception as e:
        print("OUTPUT TABLE ERROR:", str(e))
        return {
            "output_table": full_table_name,
            "output_table_status": "FAILED",
            "error": str(e),
        }