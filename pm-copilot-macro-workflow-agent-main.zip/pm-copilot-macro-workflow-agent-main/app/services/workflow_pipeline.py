"""
WorkflowPipeline service for managing and executing workflow pipelines.

This service orchestrates multiple workflow steps, handles dependencies,
and manages the overall workflow execution.

Note: LLM-assisted modifications are handled by the WorkflowModificationAgent
in app/agents/workflow_modification_agent/
"""

from typing import List, Dict, Any, Optional
from asyncpg import Connection

from app.services.workflow_step import WorkflowStep
from app.services.data_sites import get_all_site_codes
from app.models.workflow import (
    WorkflowExecutionResult,
    StepExecutionResult,
)
from app.models.enums import (
    MergeStrategy,
    StepStatus,
)


class WorkflowPipeline:
    """
    Manages a cascading workflow of multiple steps.

    Features:
    - Step dependency management
    - Multiple merge strategies for combining parent outputs
    - Execution history tracking

    For LLM-assisted modifications, use the WorkflowModificationAgent:
        from app.agents.workflow_modification_agent import WorkflowModificationAgent
        agent = WorkflowModificationAgent(llm_client)
        response = await agent.run(user_request, pipeline)
    """

    def __init__(self, name: str, llm_client: Optional[Any] = None):
        """
        Initialize a workflow pipeline.

        Args:
            name: Name of the workflow
            llm_client: Optional LLM client for natural language modifications
                       (kept for backward compatibility, but prefer using
                        WorkflowModificationAgent directly)
        """
        self.name = name
        self.steps: List[WorkflowStep] = []
        self.llm = llm_client
        self.execution_history: List[WorkflowExecutionResult] = []
        self.step_outputs: Dict[int, List[str]] = {}
        self._modification_agent = None

    def add_step(self, step: WorkflowStep) -> None:
        """Add a step to the pipeline."""
        self.steps.append(step)

    def remove_step(self, step_id: int) -> bool:
        """Remove a step by ID."""
        original_count = len(self.steps)
        self.steps = [s for s in self.steps if s.meta.step_id != step_id]
        return len(self.steps) < original_count

    def get_step(self, step_id: int) -> Optional[WorkflowStep]:
        """Get a step by ID."""
        for step in self.steps:
            if step.meta.step_id == step_id:
                return step
        return None

    def _merge_site_codes(self, step: WorkflowStep) -> List[str]:
        """
        Merge site codes from parent steps based on merge strategy.

        Args:
            step: The step requiring merged inputs

        Returns:
            List of merged site codes
        """
        parent_outputs = [
            set(self.step_outputs[parent_id])
            for parent_id in step.execution.depends_on
            if parent_id in self.step_outputs
        ]

        if not parent_outputs:
            return []

        if step.execution.merge_strategy == MergeStrategy.INTERSECTION:
            return list(set.intersection(*parent_outputs))

        # Default: UNION
        return list(set().union(*parent_outputs))

    async def execute(
        self, db: Connection
    ) -> WorkflowExecutionResult:
        """
        Execute the complete workflow pipeline.

        Args:
            initial_site_codes: Starting list of site codes
            db: Database connection

        Returns:
            WorkflowExecutionResult with complete execution details
        """
        executed_steps: set = set()
        pending_steps = {step.meta.step_id: step for step in self.steps}
        step_results: List[StepExecutionResult] = []

        initial_site_codes = await get_all_site_codes(db)

        while pending_steps:
            progress_made = False

            for step_id, step in list(pending_steps.items()):
                # Check if dependencies are satisfied
                if step.execution.depends_on:
                    if not all(
                        dep in executed_steps for dep in step.execution.depends_on
                    ):
                        continue
                    input_site_codes = self._merge_site_codes(step)
                else:
                    input_site_codes = initial_site_codes

                # Skip if no input
                if not input_site_codes:
                    self.step_outputs[step_id] = []
                    executed_steps.add(step_id)
                    del pending_steps[step_id]

                    step_results.append(
                        StepExecutionResult(
                            step_id=step_id,
                            step_name=step.meta.name,
                            step_description=step.meta.description,
                            phase_id=step.meta.phase_id,
                            phase_name=step.meta.phase_name,
                            category=step.meta.category,
                            enabled=step.execution.is_enabled,
                            depends_on=step.execution.depends_on,
                            filter_enabled=step.filter_criteria.enabled,
                            status=StepStatus.SKIPPED,
                            input_count=0,
                        )
                    )
                    progress_made = True
                    continue

                # Execute the step
                result = await step.execute(input_site_codes, db)
                self.step_outputs[step_id] = result.passed_site_codes
                step_results.append(result)

                executed_steps.add(step_id)
                del pending_steps[step_id]
                progress_made = True

            if not progress_made:
                raise RuntimeError(
                    "Workflow execution stalled. Possible circular dependency."
                )

        # Get final output from last step
        final_sites = []
        if self.steps:
            final_step_id = self.steps[-1].meta.step_id
            final_sites = self.step_outputs.get(final_step_id, [])

        result = WorkflowExecutionResult(
            workflow_name=self.name,
            initial_count=len(initial_site_codes),
            final_count=len(final_sites),
            final_site_codes=final_sites,
            steps_executed=len(step_results),
            step_results=step_results,
        )

        self.execution_history.append(result)
        return result

    # ========================================================================
    # Configuration Methods
    # ========================================================================

    def get_pipeline_config(self) -> Dict[str, Any]:
        """Get the current pipeline configuration."""
        return {
            "name": self.name,
            "total_steps": len(self.steps),
            "steps": [step.get_summary() for step in self.steps],
        }

    def visualize_flow(self) -> str:
        """Generate a text visualization of the workflow."""
        lines = [
            f"\nWorkflow: {self.name}",
            "=" * 80,
        ]

        for step in self.steps:
            status = "ENABLED" if step.execution.is_enabled else "DISABLED"
            lines.append(f"\nStep ID: {step.meta.step_id}")
            lines.append(f"Name: {step.meta.name}")
            lines.append(f"Status: {status}")

            if step.execution.depends_on:
                lines.append(f"Depends On: {step.execution.depends_on}")
                if len(step.execution.depends_on) > 1:
                    lines.append(
                        f"Merge Strategy: {step.execution.merge_strategy.value}"
                    )
            else:
                lines.append("Depends On: ROOT")

            if step.filter_criteria:
                logic = step.filter_criteria.conditional_logic.value
                lines.append(f"Filter Logic: {logic}")
                lines.append(f"Rules ({len(step.filter_criteria.rules)}):")
                for idx, rule in enumerate(step.filter_criteria.rules, 1):
                    lines.append(f"  {idx}. {rule.description}")
            else:
                lines.append("Filter: None")

        return "\n".join(lines)

    # ========================================================================
    # LLM-Assisted Modification (using WorkflowModificationAgent)
    # ========================================================================

    def _get_modification_agent(self):
        """
        Get or create the modification agent instance.

        Lazy initialization to avoid import issues and only create when needed.
        """
        if self._modification_agent is None and self.llm:
            from app.agents.workflow_modification_agent import WorkflowModificationAgent
            self._modification_agent = WorkflowModificationAgent(self.llm)
        return self._modification_agent

    async def llm_modify_step(self, natural_language_request: str) -> str:
        """
        Use LLM to interpret natural language and modify step configuration.

        This method delegates to the WorkflowModificationAgent for processing.

        Args:
            natural_language_request: Natural language instruction

        Returns:
            Response message indicating the result
        """
        agent = self._get_modification_agent()

        if not agent:
            return "LLM not initialized. Cannot process natural language requests."

        try:
            response = await agent.run(
                user_request=natural_language_request,
                pipeline=self,
                execute_directly=True,
            )
            return response.message

        except Exception as e:
            return f"Error processing LLM request: {str(e)}"

    async def get_modification_plan(self, natural_language_request: str) -> dict:
        """
        Get a modification plan without executing it.

        Useful when you want to inspect or approve the action before applying.

        Args:
            natural_language_request: Natural language instruction

        Returns:
            Dictionary with action plan details
        """
        agent = self._get_modification_agent()

        if not agent:
            return {
                "success": False,
                "message": "LLM not initialized. Cannot process natural language requests.",
                "action": None,
            }

        try:
            response = await agent.get_action_plan(
                user_request=natural_language_request,
                pipeline=self,
            )
            return response.to_dict()

        except Exception as e:
            return {
                "success": False,
                "message": f"Error processing LLM request: {str(e)}",
                "action": None,
            }
