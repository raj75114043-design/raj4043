import base64
import csv
import io
import json
import requests
import asyncio
import re
from datetime import datetime
from typing import Any, Dict, List, Literal, Optional, Tuple
from asyncpg import Connection
from app.db.pool import get_db, get_connection
from langchain_openai import ChatOpenAI
from app.utils.timezone import get_datetime_now_without_zone
from app.services.load_storage_pipeline import load_latest_workflow_execution
from app.core.llm_client import get_llm_client

from app.schemas.workflow import UserInfoRequest

AUTH_URL = "https://nokiaosdp-gsd-staging.aibi-americas-002.dyn.nesc.nokia.net/web/session/authenticate"
SEND_MAIL_URL = "https://nokiaosdp-gsd-staging.aibi-americas-002.dyn.nesc.nokia.net/api/v1/send_mail"

_AUTH_PAYLOAD = {
    "jsonrpc": "2.0",
    "method": "call",
    "params": {
        "db": "postgres",
        "login": "pwc_osdp_user",
        "password": "pwc_osdp_user",
    },
}

AllowedSites = Literal["FAIL", "PASS", "ALL"]


# ---------------------------------------------------------------------------
# Logging helper
# ---------------------------------------------------------------------------

def log(message: str):
    print(f"[EMAIL_SERVICE] {datetime.now().isoformat()} | {message}")


# ---------------------------------------------------------------------------
# Step config
# ---------------------------------------------------------------------------

async def fetch_step_config(
    db: Connection,
    workflow_name: str,
    step_id: str,
) -> Dict[str, Any]:

    # log(f"Fetching step config | workflow={workflow_name} step_id={step_id}")

    execution_data = await load_latest_workflow_execution(db, workflow_name)

    step_results: List[Dict[str, Any]] = execution_data.get("step_results", [])

    for step in step_results:
        if str(step.get("step_id", "")) == str(step_id):
            return step

    raise ValueError(f"Step '{step_id}' not found in workflow '{workflow_name}'.")


# ---------------------------------------------------------------------------
# Output table fetch
# ---------------------------------------------------------------------------

def _normalize_identifier(name: str) -> str:
    return re.sub(r"\s+", "_", name.strip()).lower()


async def fetch_step_output(
    db: Connection,
    workflow_name: str,
    step_id: str,
    allowed_sites: AllowedSites,
    columns_name: List[str] = None,
    global_filters: Dict[str, List[str]] = None,
    step_config: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:

    output_table: Optional[str] = step_config.get("output_table")

    if not output_table:
        return []

    try:
        if columns_name:
            selected_columns = ", ".join(columns_name)
        else:
            selected_columns = "*"
            
        query = f"SELECT DISTINCT {selected_columns} FROM {output_table}"

        conditions = []
        values = []
        param_index = 1

        if allowed_sites != "ALL":
            conditions.append(f"final_status = ${param_index}")
            values.append(allowed_sites)
            param_index += 1

        if global_filters:
            for column, filter_values in global_filters.items():
                if not filter_values:
                    continue

                placeholders = []
                normalized_values = []

                for val in filter_values:
                    placeholders.append(f"${param_index}")
                    normalized_values.append(val.lower())
                    param_index += 1

                values.extend(normalized_values)
                conditions.append(f"LOWER({column}) IN ({', '.join(placeholders)})")

        if conditions:
            query += " WHERE " + " AND ".join(conditions)

        # print("QUERY:", query)
        # print("VALUES:", values)

        rows = await db.fetch(query, *values)

    except Exception as e:
        print(f"[FETCH ERROR] {e}")
        raise

    return [dict(row) for row in rows]

# ---------------------------------------------------------------------------
# CSV builder
# ---------------------------------------------------------------------------

def build_csv_attachment(rows: List[Dict[str, Any]], filename: str) -> Dict[str, str]:

    # log(f"Building CSV attachment | filename={filename}")

    if not rows:
        encoded = base64.b64encode(b"No data available").decode()
        return {"filename": filename, "filedata": encoded}

    buf = io.StringIO()

    writer = csv.DictWriter(buf, fieldnames=list(rows[0].keys()))
    writer.writeheader()
    writer.writerows(rows)

    encoded = base64.b64encode(buf.getvalue().encode()).decode()

    return {"filename": filename, "filedata": encoded}


# ---------------------------------------------------------------------------
# LLM email generation
# ---------------------------------------------------------------------------



def generate_email_content(
    llm: ChatOpenAI,
    workflow_name: str,
    step_config: Dict[str, Any],
    rows: List[Dict[str, Any]],
    allowed_sites,
) -> Tuple[str, str]:

    current_time = datetime.now().isoformat()
    sample = rows[:5] if rows else []

    prompt = f"""
You are generating a professional workflow notification email for a telecom network operations team.

Context:
- Workflow      : {workflow_name}
- Step ID       : {step_config.get("step_id")}
- Step Name     : {step_config.get("step_name")}
- Description   : {step_config.get("step_description")}
- Phase         : {step_config.get("phase_name")}
- Filter        : final_status = {allowed_sites}
- Rows in email : {len(rows)}
- Generated at  : {current_time}

Return ONLY valid JSON.

Format:
{{
  "subject": "<concise: [PMCopilot] Workflow | Step Name | Filter | N sites>",
  "body": "<complete HTML email with inline CSS only>"
}}

Rules:
- Do NOT include markdown fences
- Do NOT include explanation text
- Escape quotes properly inside HTML
- Dont add links or email addresses
"""

    response = llm.invoke(prompt)
    raw = response.content.strip()

    # Remove markdown fences if LLM added them
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]

    raw = raw.strip()

    # Extract JSON block safely
    match = re.search(r"\{.*\}", raw, re.DOTALL)

    if not match:
        raise ValueError(f"LLM did not return valid JSON:\n{raw}")

    json_text = match.group(0)

    try:
        parsed = json.loads(json_text)

    except json.JSONDecodeError:
        # Attempt repair for common escape issues
        json_text = json_text.replace("\\", "\\\\")
        parsed = json.loads(json_text)

    subject = parsed.get("subject", "Workflow Notification")
    body = parsed.get("body", "<html><body>Email content unavailable</body></html>")

    return subject, body

# ---------------------------------------------------------------------------
# Mail gateway
# ---------------------------------------------------------------------------

def _get_session_id() -> str:

    # log("Authenticating with Nokia mail gateway")

    session = requests.Session()

    resp = session.post(
        AUTH_URL,
        json=_AUTH_PAYLOAD,
        headers={"Content-Type": "application/json"},
        timeout=30,
    )

    resp.raise_for_status()

    session_id = session.cookies.get("session_id")

    if not session_id:
        raise RuntimeError("Authentication failed — session_id missing")

    # log("Mail gateway authentication successful")

    return session_id


def send_email(
    session_id: str,
    to_list: List[str],
    cc_list: List[str],
    bcc_list: List[str],
    subject: str,
    body: str,
    attachments: List[Dict[str, str]],
) -> Dict[str, Any]:

    # log("Sending email via gateway")

    payload = {
        "params": {
            "tolist": to_list,
            "cclist": cc_list,
            "bcclist": bcc_list,
            "subject": subject,
            "body": body,
            "file": attachments,
        }
    }

    resp = requests.post(
        SEND_MAIL_URL,
        json=payload,
        headers={
            "Content-Type": "application/json",
            "Cookie": f"session_id={session_id}",
        },
        timeout=60,
    )

    resp.raise_for_status()

    # log("Email sent successfully")

    return resp.json()


# ---------------------------------------------------------------------------
# Orchestrator
# ---------------------------------------------------------------------------

async def send_workflow_step_email(
    db,
    user_id: str,
    scheduled_id: str,
    workflow_name: str,
    step_id: int,
    to_list: List[str],
    cc_list: List[str],
    bcc_list: List[str],
    allowed_sites: AllowedSites,
    columns_name: List[str],
    global_filters: Dict[str, List[str]],
    llm: Optional[ChatOpenAI] = None,
    progress_callback=None,
) -> Dict[str, Any]:
    
    # log(f"Starting email workflow | workflow={workflow_name} step_id={step_id}")
    
    if llm is None:
        llm = get_llm_client("medium")
        
    step_config = await fetch_step_config(db, workflow_name, step_id)
    if progress_callback:
        progress_callback("STEP_CONFIG_LOADED")

    rows = await fetch_step_output(
        db,
        workflow_name,
        step_id,
        allowed_sites,
        columns_name,
        global_filters,
        step_config,
    )
    if progress_callback:
        progress_callback("OUTPUT_DATA_LOADED")

    skip_email = False
    email_status = "failed"
    failed_error = None

    if allowed_sites in ["PASS", "FAIL"] and len(rows) == 0:
        skip_email = True
        email_status = "failed"
        failed_error = f"No rows found with status {allowed_sites}"

    is_success = False
    subject = None
    result = None
    csv_filename = None

    try:

        if not skip_email:

            subject, body = await asyncio.to_thread(
                generate_email_content,
                llm,
                workflow_name,
                step_config,
                rows,
                allowed_sites,
            )
            if progress_callback:
                progress_callback("EMAIL_CONTENT_GENERATED")

            step_name_safe = _normalize_identifier(
                step_config.get("step_name", step_id)
            )

            csv_filename = f"{_normalize_identifier(workflow_name)}_{step_name_safe}_{allowed_sites}.csv"
            attachment = build_csv_attachment(rows, csv_filename)
            if progress_callback:
                progress_callback("CSV_ATTACHMENT_CREATED")

            session_id = await asyncio.to_thread(_get_session_id)
            if progress_callback:
                progress_callback("MAIL_GATEWAY_AUTHENTICATED")

            result = await asyncio.to_thread(
                send_email,
                session_id,
                to_list,
                cc_list,
                bcc_list,
                subject,
                body,
                [attachment],
            )
            if progress_callback:
                progress_callback("EMAIL_SENT")


            email_status = result.get("result", {}).get("status", "unknown")
            is_success = email_status.lower().startswith("success")

            if is_success:
                email_status = "sent"
            else:   
                failed_error = str(result)

    except Exception as e:
        failed_error = str(e)
        email_status = "failed"
        print(f"[EMAIL ERROR] {e}")

    finally:
        DATE_TIME = get_datetime_now_without_zone()

        await db.execute(
            """
            INSERT INTO pwc_workflow_agent_schema.workflow_email_sent_history (
                workflow_name,
                step_id,
                allowed_sites,
                to_list,
                cc_list,
                bcc_list,
                sent_by,
                sent_at,
                mail_status,
                failed_error,
                scheduled_id
            )
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
            """,
            workflow_name,
            step_id,
            allowed_sites,
            to_list,
            cc_list,
            bcc_list,
            user_id,
            DATE_TIME,
            email_status,
            failed_error,
            scheduled_id,
        )

        print(f"[Email Sent History] DB Updated for {workflow_name} - {step_id}")
        
    return {
        "status": email_status,
        "subject": subject,
        "step_name": step_config.get("step_name"),
        "total_rows": len(rows),
        "attachment": csv_filename,
        "gateway_response": result,
    }


async def send_simple_email(
    to_list: List[str],
    cc_list: List[str],
    bcc_list: List[str],
    subject: str,
    email_body: str,
    attachments: Optional[List[Dict[str, str]]] = None,
) -> Dict[str, Any]:
    """
    Send a simple email without workflow processing.
    """

    # log("Starting simple email send")

    attachments = []

    try:

        print("EMAIL JOB STARTED")

        # authenticate with mail gateway
        session_id = await asyncio.to_thread(_get_session_id)

        result = await asyncio.to_thread(
            send_email,
            session_id,
            to_list,
            cc_list,
            bcc_list,
            subject,
            email_body,
            attachments,
        )

        email_status = result.get("result", {}).get("status", "unknown")
        is_success = email_status.lower().startswith("success")  

        return {
            "status": "sent" if is_success else "failed",
            "subject": subject,
            "gateway_response": result,
        }

    except Exception as e:
        raise