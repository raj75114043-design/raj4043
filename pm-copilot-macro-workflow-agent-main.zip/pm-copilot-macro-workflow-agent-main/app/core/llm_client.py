"""
LLM Client module for initializing and managing LLM connections.

This module provides factory functions to create LLM clients using
credentials from environment variables and the configured LLM gateway.
"""

from typing import Optional
from langchain_openai import ChatOpenAI

from app.core.config import get_settings, LLMConfig


def create_llm_client(tier: str = "medium") -> ChatOpenAI:
    """
    Create an LLM client using environment credentials.

    Args:
        tier: Configuration tier - "high", "medium", or "low"
              Defaults to "medium" for balanced performance.
              Controls the reasoning_effort parameter of the model.

    Returns:
        ChatOpenAI: Configured LLM client instance

    Example:
        ```python
        # Create LLM with medium reasoning (default for workflow operations)
        llm = create_llm_client("medium")

        # Create LLM with high reasoning (more thorough analysis)
        llm_high = create_llm_client("high")

        # Create LLM with low reasoning (faster responses)
        llm_low = create_llm_client("low")
        ```
    """
    settings = get_settings()
    llm_config = settings.get_llm_config(tier)

    return ChatOpenAI(
        api_key="NONE",  # Not used, auth via headers
        model=llm_config.model,
        base_url=settings.llm_api_key_url,
        default_headers={
            "api-key": settings.llm_api_key,
            "workspacename": settings.workspace_name,
        },
        temperature=0,
        max_tokens=llm_config.max_tokens,
        reasoning_effort=llm_config.reasoning_effort,
        verbose=settings.debug,
    )


def get_default_llm_client() -> ChatOpenAI:
    """
    Get the default LLM client with medium configuration.

    This is the recommended client for workflow modification tasks.

    Returns:
        ChatOpenAI: Configured LLM client with medium tier settings
    """
    settings = get_settings()
    return create_llm_client(settings.llm_default_tier)


# Pre-configured clients for different use cases
_cached_clients: dict[str, ChatOpenAI] = {}


def get_llm_client(tier: str = "medium") -> ChatOpenAI:
    """
    Get a cached LLM client for the specified tier.

    Clients are cached to avoid recreating them on each call.

    Args:
        tier: Configuration tier - "high", "medium", or "low"

    Returns:
        ChatOpenAI: Cached LLM client instance
    """
    if tier not in _cached_clients:
        _cached_clients[tier] = create_llm_client(tier)
    return _cached_clients[tier]
