from pydantic_settings import BaseSettings
from pydantic import Field
from functools import lru_cache
from typing import Optional, Dict, Any
from dataclasses import dataclass
from langchain_openai import ChatOpenAI


@dataclass
class LLMConfig:
    """LLM configuration for different reasoning levels."""
    model: str
    reasoning_effort: str  # "low", "medium", or "high"
    max_tokens: int


# GPT-5 Mini configurations for different reasoning levels
GPT5_MINI_CONFIGS: Dict[str, LLMConfig] = {
    "high": LLMConfig(
        model="gpt-5-mini",
        reasoning_effort="high",
        max_tokens=4096,
    ),
    "medium": LLMConfig(
        model="gpt-5-mini",
        reasoning_effort="medium",
        max_tokens=2048,
    ),
    "low": LLMConfig(
        model="gpt-5-mini",
        reasoning_effort="low",
        max_tokens=1024,
    ),
}


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Application
    app_name: str = "Workflow Agent API"
    debug: bool = False

    # PostgreSQL Database
    db_host: str = Field(alias="db_host")
    db_port: int = Field(alias="db_port")
    db_username: str = Field(alias="db_username")
    db_password: str = Field(alias="db_password")
    db_name: str = Field(default="macro_workflow", alias="db_name")

    # Connection Pool Settings
    db_pool_min_size: int = 5
    db_pool_max_size: int = 20
    db_pool_max_queries: int = 50000
    db_pool_max_inactive_connection_lifetime: float = 300.0

    # LLM Configuration
    llm_api_key_url: str = Field(alias="LLM_API_KEY_URL")
    llm_api_key: str = Field(alias="LLM_API_KEY")
    workspace_name: str = Field(alias="WORKSPACE_NAME")

    # Default LLM tier for workflow operations
    llm_default_tier: str = Field(default="medium", alias="LLM_DEFAULT_TIER")

    def get_llm_config(self, tier: str = None) -> LLMConfig:
        """Get LLM configuration for specified tier."""
        tier = tier or self.llm_default_tier
        if tier not in GPT5_MINI_CONFIGS:
            raise ValueError(f"Invalid LLM tier: {tier}. Must be one of: {list(GPT5_MINI_CONFIGS.keys())}")
        return GPT5_MINI_CONFIGS[tier]

    @property
    def database_url(self) -> str:
        """Construct PostgreSQL connection URL."""
        return f"postgresql://{self.db_username}:{self.db_password}@{self.db_host}:{self.db_port}/{self.db_name}"

    @property
    def async_database_url(self) -> str:
        """Construct async PostgreSQL connection URL for asyncpg."""
        return f"postgresql+asyncpg://{self.db_username}:{self.db_password}@{self.db_host}:{self.db_port}/{self.db_name}"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        extra = "ignore"


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()



LLM_API_KEY_URL = "https://llmgateway-qa-api.nokia.com/v1.2/"
 
