import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any

OUTPUT_DIR = Path("output/workflows")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def save_workflow_execution(
    workflow_name: str,
    execution_payload: Dict[str, Any],
):
    """
    Save (overwrite) workflow execution result in JSON file.
    Existing executions will be deleted before inserting new one.
    """

    file_path = OUTPUT_DIR / f"{workflow_name.replace(' ', '_')}.json"

    # Always reset the content
    data = {
        "workflow_name": workflow_name,
        "saved_at": datetime.now().isoformat(),
        "executions": [
            {
                **execution_payload,
            }
        ],
    }

    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)