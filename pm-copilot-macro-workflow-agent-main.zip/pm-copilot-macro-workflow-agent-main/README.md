# Nokia PM CoPilot - Workflow Agent Microservice

A modular workflow orchestration microservice for managing and executing site-based workflow pipelines with LLM-assisted natural language modifications.

## Developers

- **Venkatesh Manikantan** - Senior Associate, PwC India
- **Talib K Raza** - PwC India

## Overview

The Workflow Agent is a FastAPI-based microservice designed for Nokia's PM CoPilot platform. It provides a flexible framework for defining, managing, and executing multi-step workflow pipelines with advanced filtering capabilities.

### Key Features

- **Workflow Pipeline Management**: Create, configure, and manage multi-step workflows with YAML-based configurations
- **Dynamic Step Modification**: Mute/unmute steps, add/remove filter rules at runtime
- **Filter Rules Engine**: Define validation rules with multiple operators (NOT_NULL, EQUALS, DATE_PASSED, IN_LIST, etc.)
- **Dependency Management**: Steps can depend on multiple parent steps with UNION or INTERSECTION merge strategies
- **LLM-Assisted Modifications**: Use natural language to modify workflow steps via the Workflow Modification Agent
- **PostgreSQL Integration**: Async database operations with connection pooling
- **LangGraph Integration**: Agentic workflows powered by LangChain and LangGraph

## Project Structure

```
workflow_agent/
├── app/                          # Main application package
│   ├── addons/                   # Optional addon modules
│   ├── agents/                   # LangGraph-based agents
│   │   └── workflow_modification_agent/  # NL workflow modification agent
│   │       ├── nodes.py          # Graph nodes for the agent
│   │       ├── runner.py         # Agent orchestration
│   │       ├── state.py          # Pydantic state definitions
│   │       ├── tools.py          # Execution tools
│   │       ├── prompt.py         # LLM prompts
│   │       └── config.py         # Agent configuration
│   ├── api/                      # API layer
│   │   └── routes/               # FastAPI route handlers
│   │       ├── health.py         # Health check endpoints
│   │       ├── data.py           # Data query endpoints
│   │       ├── workflow_orchestration.py      # Workflow execution
│   │       ├── workflow_dev_functions.py      # Developer utilities
│   │       ├── workflow_modification_agent.py # Agent API
│   │       └── workflow_dev_util_chat.py      # Chat utilities
│   ├── config/                   # Configuration management
│   │   └── pipeline_storage.py   # YAML pipeline storage
│   ├── core/                     # Core utilities
│   │   ├── config.py             # Application settings
│   │   └── llm_client.py         # LLM client factory
│   ├── db/                       # Database layer
│   │   └── pool.py               # Connection pooling
│   ├── models/                   # Domain models
│   │   ├── workflow.py           # Workflow data models
│   │   └── enums.py              # Enumeration types
│   ├── schemas/                  # Pydantic schemas
│   ├── semantic/                 # Semantic search components
│   └── services/                 # Business logic
│       ├── workflow_pipeline.py  # Pipeline orchestration
│       └── workflow_step.py      # Step execution
├── notebooks/                    # Jupyter notebooks for development
├── scripts/                      # Utility scripts
├── test/                         # Test suite
├── main.py                       # Application entry point
├── pyproject.toml                # Poetry project configuration
├── poetry.lock                   # Locked dependencies
├── requirements.txt              # Pip requirements (alternative)
└── .env                          # Environment configuration
```

## Prerequisites

- Python 3.14+
- Poetry (recommended) or pip
- PostgreSQL database
- Access to an LLM API endpoint (Azure OpenAI compatible)

## Installation

### Using Poetry (Recommended)

1. Install Poetry if not already installed:
   ```bash
   pip install poetry
   ```

2. Clone the repository and navigate to the project directory:
   ```bash
   cd workflow_agent
   ```

3. Install dependencies:
   ```bash
   poetry install
   ```

4. Activate the virtual environment:
   ```bash
   poetry shell
   ```

### Using pip

```bash
pip install -r requirements.txt
```

## Configuration

Create a `.env` file in the project root with the following variables:

```env
# Application
APP_NAME=Workflow Agent
DEBUG=false

# Database
DATABASE_URL=postgresql+asyncpg://user:password@host:port/database

# LLM Configuration
LLM_API_KEY=your-api-key
LLM_API_KEY_URL=https://your-llm-endpoint/v1
WORKSPACE_NAME=your-workspace

# Optional
LLM_DEFAULT_TIER=medium
```

## Running the Application

### Development Mode

Using Poetry:
```bash
poetry run uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

Or with the virtual environment activated:
```bash
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

### Production Mode

```bash
poetry run uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```

### Using Python directly

```bash
python main.py
```

## API Documentation

Once the application is running, access the interactive API documentation:

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## Core Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/health` | GET | Health check |
| `/api/v1/workflow/pipelines` | GET | List all pipelines |
| `/api/v1/workflow/pipelines/{name}/run` | POST | Execute a pipeline |
| `/api/v1/workflow_agent/pipelines/{name}/plan` | POST | Get modification plan |
| `/api/v1/workflow_agent/pipelines/{name}/modify` | POST | Modify workflow with NL |

## Usage Example

### Natural Language Workflow Modification

```bash
curl -X POST "http://localhost:8000/api/v1/workflow_agent/pipelines/my_workflow/plan" \
  -H "Content-Type: application/json" \
  -d '{"request": "mute all steps"}'
```

Response:
```json
{
  "success": true,
  "message": "Action plan generated: 6 actions - mute_step on step 1, mute_step on step 2, ...",
  "actions": [
    {"operation": "mute_step", "step_id": 1},
    {"operation": "mute_step", "step_id": 2}
  ],
  "executed": false
}
```

## License

Private Software - PwC India / Nokia

## Support

For issues and feature requests, contact the development team.
