"""
Configuration management for PM Copilot Global Context Layer
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

from typing import List
from urllib.parse import quote_plus
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings and configuration"""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False
    )

    # Database Configuration
    db_host: str = Field(default="localhost", description="Database host")
    db_port: int = Field(default=5432, description="Database port")
    db_name: str = Field(default="pm_copilot_db", description="Database name")
    db_user: str = Field(default="postgres", description="Database user")
    db_password: str = Field(default="", description="Database password")
    db_schema: str = Field(
        default="pwc_semantic_information_schema",
        description="Database schema name for semantic vector tables"
    )
    db_schema_compare: str = Field(
        default="pwc_macro_staging_schema",
        description="Staging schema name for comparison reports"
    )

    # LLM Gateway Configuration (Nokia)
    llm_api_key_url: str = Field(
        default="",
        description="Nokia LLM Gateway base URL"
    )
    llm_api_key: str = Field(
        default="",
        description="Nokia LLM Gateway API key (JWT)"
    )
    workspace_name: str = Field(
        default="",
        description="Nokia LLM Gateway workspace name"
    )
    embedding_model: str = Field(
        default="embedding-ada-002",
        description="Embedding model name"
    )

    # Legacy Embedding API Configuration (deprecated)
    embed_api_url: str = Field(
        default="",
        description="Embedding model API URL (deprecated, use llm_api_key_url)"
    )

    # Database Pool Configuration (asyncpg)
    db_pool_min_size: int = Field(default=5, description="Minimum pool connections")
    db_pool_max_size: int = Field(default=20, description="Maximum pool connections")
    db_pool_max_queries: int = Field(default=50000, description="Max queries per connection before recycling")
    db_pool_max_inactive_connection_lifetime: float = Field(default=300.0, description="Max idle time before closing connection")

    # Application Configuration
    app_name: str = Field(
        default="PM Copilot Global Context Layer",
        description="Application name"
    )
    app_version: str = Field(default="1.0.1", description="Application version")
    api_v1_prefix: str = Field(default="/api/v1", description="API v1 prefix")
    debug: bool = Field(default=False, description="Debug mode")

    # Server Configuration
    host: str = Field(default="0.0.0.0", description="Server host")
    port: int = Field(default=8000, description="Server port")
    workers: int = Field(default=4, description="Number of workers")

    # CORS Configuration
    cors_origins: List[str] = Field(
        default=["http://localhost:3000", "http://localhost:8000"],
        description="Allowed CORS origins"
    )

    # Logging
    log_level: str = Field(default="INFO", description="Log level")
    log_format: str = Field(default="json", description="Log format")

    # Security
    secret_key: str = Field(
        default="change-this-in-production",
        description="Secret key for security"
    )
    api_key: str = Field(
        default="",
        description="API key for service authentication"
    )

    @property
    def database_url(self) -> str:
        """Construct async database URL"""
        return (
            f"postgresql+asyncpg://{self.db_user}:{quote_plus(self.db_password)}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )

    @property
    def sync_database_url(self) -> str:
        """Construct sync database URL for Alembic"""
        return (
            f"postgresql://{self.db_user}:{quote_plus(self.db_password)}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
        )

    @field_validator("cors_origins", mode="before")
    @classmethod
    def assemble_cors_origins(cls, v: str | List[str]) -> List[str]:
        """Parse CORS origins from string or list"""
        if isinstance(v, str):
            return [origin.strip() for origin in v.split(",")]
        return v


settings = Settings()


def get_settings() -> Settings:
    """Get application settings instance"""
    return settings
