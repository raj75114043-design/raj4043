"""
Schema World View Service
==========================
Consumes stored table schema map from PostgreSQL and produces a focused
SQL schema world view for text-to-SQL systems.
"""

import logging

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc

from app.models.semantic_models import TableSchemaMap
from app.schemas.semantic_schemas import SchemaWorldViewRequest

logger = logging.getLogger(__name__)

# ── Fuzzy matching config ──

try:
    from rapidfuzz import fuzz as _wv_fuzz, process as _wv_rfprocess
    _WV_USE_RAPIDFUZZ = True
except ImportError:
    _WV_USE_RAPIDFUZZ = False

_WV_FUZZY_THRESHOLD = 60


def _fuzzy_find_wv(query: str, candidates: list, top_n: int = 1):
    if not query.strip():
        return []
    if _WV_USE_RAPIDFUZZ:
        results = _wv_rfprocess.extract(query, candidates, scorer=_wv_fuzz.WRatio, limit=top_n)
        return [(m, round(s, 1)) for m, s, _ in results if s >= _WV_FUZZY_THRESHOLD]
    else:
        import difflib
        scored = []
        q_lower = query.lower()
        for c in candidates:
            ratio = difflib.SequenceMatcher(None, q_lower, c.lower()).ratio() * 100
            if ratio >= _WV_FUZZY_THRESHOLD:
                scored.append((c, round(ratio, 1)))
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:top_n]


def _resolve_list_wv(inputs: list, candidates: list) -> list:
    resolved = []
    for inp in inputs:
        inp = inp.strip()
        if not inp:
            continue
        exact = None
        for c in candidates:
            if c.lower() == inp.lower():
                exact = c
                break
        if exact:
            resolved.append(exact)
            continue
        matches = _fuzzy_find_wv(inp, candidates, top_n=1)
        if matches and matches[0][1] >= _WV_FUZZY_THRESHOLD:
            resolved.append(matches[0][0])
    return resolved


def _build_world_view(schema_map: dict, kpi_keys=None, question_keys=None, keyword_keys=None) -> dict:
    tables_data = schema_map["tables"]
    kpi_index = schema_map["kpi_index"]
    question_index = schema_map["question_index"]
    keyword_index = schema_map.get("keyword_index", {})

    relevant_tables = set()
    kpi_contexts = []
    question_contexts = []
    keyword_contexts = []

    for kpi_key in (kpi_keys or []):
        if kpi_key not in kpi_index:
            continue
        entry = kpi_index[kpi_key]
        kpi_contexts.append({
            "kpi_name": kpi_key, "description": entry.get("description", ""),
            "formula": entry.get("formula", ""), "logic": entry.get("logic", ""),
            "tables_involved": entry["tables_involved"],
            "matched_columns_by_table": entry["matched_columns_by_table"],
            "unmatched_columns": entry["unmatched_columns"], "validation": entry["validation"],
        })
        relevant_tables.update(entry["tables_involved"])

    for q_key in (question_keys or []):
        if q_key not in question_index:
            continue
        entry = question_index[q_key]
        question_contexts.append({
            "question": q_key, "tables_involved": entry["tables_involved"],
            "matched_columns_by_table": entry["matched_columns_by_table"],
            "unmatched_columns": entry["unmatched_columns"],
            "reference_sql": entry.get("sql", entry.get("reference_sql", "")),
            "validation": entry["validation"],
        })
        relevant_tables.update(entry["tables_involved"])

    for kw_key in (keyword_keys or []):
        if kw_key not in keyword_index:
            continue
        entry = keyword_index[kw_key]
        keyword_contexts.append({
            "keyword_name": kw_key, "description": entry.get("description", ""),
            "synonyms": entry.get("synonyms", ""),
            "tables_involved": entry["tables_involved"],
            "matched_columns_by_table": entry["matched_columns_by_table"],
            "unmatched_columns": entry["unmatched_columns"], "validation": entry["validation"],
        })
        relevant_tables.update(entry["tables_involved"])

    # Focused tables
    focused_tables = {}
    for tbl_name in relevant_tables:
        if tbl_name not in tables_data:
            continue
        tbl = tables_data[tbl_name]
        referenced_cols = set()
        for ctx_list in [kpi_contexts, question_contexts, keyword_contexts]:
            for ctx in ctx_list:
                if tbl_name in ctx["matched_columns_by_table"]:
                    referenced_cols.update(ctx["matched_columns_by_table"][tbl_name])
        focused_tables[tbl_name] = {
            "total_columns_in_table": tbl["column_count"],
            "referenced_columns": sorted(referenced_cols),
            "all_columns": tbl["columns"],
        }

    # Related tables (one hop)
    related_tables_map = {}
    for tbl_name in relevant_tables:
        if tbl_name not in tables_data:
            continue
        for rel in tables_data[tbl_name].get("related_tables", []):
            peer = rel["table_name"]
            if peer not in relevant_tables:
                related_tables_map[peer] = {
                    "linked_from": tbl_name,
                    "shared_columns": rel["shared_columns"],
                    "affinity_score": rel["affinity_score"],
                }

    # Reference questions on these tables
    reference_questions = []
    seen_qs = set()
    for tbl_name in relevant_tables:
        if tbl_name not in tables_data:
            continue
        for q in tables_data[tbl_name].get("questions", []):
            if q["question"] not in seen_qs:
                seen_qs.add(q["question"])
                reference_questions.append({"question": q["question"], "reference_sql": q["reference_sql"]})

    return {
        "schema_name": schema_map["_metadata"]["schema_name"],
        "input": {"kpis": kpi_keys or [], "questions": question_keys or [], "keywords": keyword_keys or []},
        "kpi_contexts": kpi_contexts or None,
        "question_contexts": question_contexts or None,
        "keyword_contexts": keyword_contexts or None,
        "focused_tables": focused_tables,
        "related_tables": related_tables_map or None,
        "reference_questions_on_same_tables": reference_questions[:10],
    }


# ── Public entry point ──

async def run_schema_world_view(db: AsyncSession, request: SchemaWorldViewRequest) -> dict:
    """
    Load stored schema map, resolve inputs via fuzzy matching, build world view.
    Raises HTTPException on error.
    """
    from fastapi import HTTPException

    if not request.kpi_names and not request.question_texts and not request.keyword_names:
        raise HTTPException(status_code=400, detail="Provide at least one of: kpi_names, question_texts, keyword_names")

    result = await db.execute(
        select(TableSchemaMap).order_by(desc(TableSchemaMap.id)).limit(1)
    )
    record = result.scalar_one_or_none()
    if not record:
        raise HTTPException(
            status_code=404,
            detail="No table schema map found. Run GET /dev/table-schema-builder first."
        )

    schema_map = record.schema_data

    kpi_names_list = list(schema_map.get("kpi_index", {}).keys())
    question_texts_list = list(schema_map.get("question_index", {}).keys())
    keyword_names_list = list(schema_map.get("keyword_index", {}).keys())

    kpi_keys = _resolve_list_wv(request.kpi_names, kpi_names_list) if request.kpi_names else []
    q_keys = _resolve_list_wv(request.question_texts, question_texts_list) if request.question_texts else []
    kw_keys = _resolve_list_wv(request.keyword_names, keyword_names_list) if request.keyword_names else []

    if not kpi_keys and not q_keys and not kw_keys:
        raise HTTPException(status_code=404, detail="None of the provided inputs matched any known KPI, question, or keyword")

    world_view = _build_world_view(schema_map, kpi_keys, q_keys, kw_keys)

    return {"world_view": world_view}
