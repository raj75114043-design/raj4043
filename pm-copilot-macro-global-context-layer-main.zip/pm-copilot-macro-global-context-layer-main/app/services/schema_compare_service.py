"""
Schema Compare Service
======================
Compares the staging schema against KPI, Question Bank, and Keywords data.
Produces global summary and detailed per-entry markdown reports.
Also generates CSV reports for easy sharing and analysis.
"""

import re
import logging
import csv
import io
from collections import defaultdict
from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.services.dev_shared import (
    SQL_KEYWORDS, NOISE_TOKENS,
    STRUCTURED_PATTERN, COL_LIKE, BRACKET_COL, MBT_PREFIX,
    FROM_JOIN_PATTERN, QUALIFIED_COL, EXTERNAL_KEYWORDS,
    fetch_staging_schema_async, load_json_from_semantic_tables,
    build_staging_column_index, map_client_to_staging,
)

logger = logging.getLogger(__name__)


# ── Column extraction helpers ──

def _extract_qb_per_question(qb_data: list, staging_col_index: dict) -> list:
    """Extract columns per QB question from SQL."""
    results = []
    for entry in qb_data:
        sql = entry.get("sql", "")
        question = entry.get("question", "")
        if not sql:
            results.append({"question": question, "tables": {}, "all_columns": set()})
            continue

        tables_in_query = {}
        for match in FROM_JOIN_PATTERN.finditer(sql):
            tbl = match.group(1).lower().strip()
            alias = match.group(2).lower().strip() if match.group(2) else None
            if tbl in SQL_KEYWORDS:
                continue
            tables_in_query[tbl] = alias

        table_columns = {tbl: set() for tbl in tables_in_query}

        for match in QUALIFIED_COL.finditer(sql):
            prefix = match.group(1).lower()
            col = match.group(2).lower()
            for tbl, alias in tables_in_query.items():
                if prefix == tbl or prefix == alias:
                    table_columns[tbl].add(col)
                    break

        if tables_in_query:
            main_table = list(tables_in_query.keys())[0]
            all_table_refs = set(tables_in_query.keys()) | {a for a in tables_in_query.values() if a}
            for col_match in re.finditer(r'\b([a-z_][a-z0-9_]*)\b', sql, re.IGNORECASE):
                candidate = col_match.group(1).lower()
                if candidate in SQL_KEYWORDS or '_' not in candidate or candidate in all_table_refs:
                    continue
                table_columns[main_table].add(candidate)

        all_columns = set()
        for cols in table_columns.values():
            all_columns.update(cols)

        results.append({"question": question, "tables": table_columns, "all_columns": all_columns})
    return results


def _extract_kpi_columns_enhanced(kpi_data: list) -> list:
    """Extract columns from each KPI entry."""
    results = []
    for kpi in kpi_data:
        raw = kpi.get("mapped_tables_columns", "").strip()
        kpi_name = kpi.get("kpi_name", "unknown").strip()
        structured_tables = defaultdict(set)
        extracted_columns = set()

        if not raw:
            for field_name in ["formula", "logic"]:
                field_val = kpi.get(field_name, "").strip()
                if not field_val:
                    continue
                for regex in [COL_LIKE, BRACKET_COL]:
                    for match in regex.finditer(field_val):
                        token = match.group(1).lower().strip()
                        if '_' in token:
                            extracted_columns.add(token)
            extracted_columns -= NOISE_TOKENS
            results.append({
                "kpi_name": kpi_name,
                "structured_tables": {},
                "extracted_columns": extracted_columns,
                "parse_category": "empty" if not extracted_columns else "formula_with_columns",
                "raw_text": raw,
            })
            continue

        has_structured = bool(STRUCTURED_PATTERN.search(raw))
        has_mbt_prefix = bool(MBT_PREFIX.search(raw))
        is_external = any(kw in raw.lower() for kw in EXTERNAL_KEYWORDS)

        if has_structured:
            category = "structured"
            for match in STRUCTURED_PATTERN.finditer(raw):
                tbl = match.group(1).lower().strip()
                cols_raw = match.group(2)
                cols = [c.strip().lower() for c in cols_raw.split(",") if c.strip()]
                cols = [c for c in cols if re.match(r'^[a-z_][a-z0-9_]*$', c)]
                if tbl and cols:
                    structured_tables[tbl].update(cols)
                    extracted_columns.update(cols)
            matched_spans = [(m.start(), m.end()) for m in STRUCTURED_PATTERN.finditer(raw)]
            for regex in [COL_LIKE, BRACKET_COL]:
                for match in regex.finditer(raw):
                    token = match.group(1).lower().strip()
                    in_matched = any(s <= match.start() < e for s, e in matched_spans)
                    if not in_matched and '_' in token:
                        extracted_columns.add(token)
        elif is_external:
            category = "external_ref"
            for regex in [COL_LIKE, BRACKET_COL]:
                for match in regex.finditer(raw):
                    token = match.group(1).lower().strip()
                    if '_' in token:
                        extracted_columns.add(token)
        elif has_mbt_prefix:
            category = "mbt_prefixed"
            for match in MBT_PREFIX.finditer(raw):
                token = match.group(1).lower().strip()
                if token and token not in {'dump'}:
                    extracted_columns.add(token)
            for match in COL_LIKE.finditer(raw):
                extracted_columns.add(match.group(1).lower().strip())
        else:
            for regex in [COL_LIKE, BRACKET_COL]:
                for match in regex.finditer(raw):
                    token = match.group(1).lower().strip()
                    if '_' in token:
                        extracted_columns.add(token)
            category = "formula_with_columns" if extracted_columns else "unparseable"

        if not has_structured:
            for field_name in ["formula", "logic"]:
                field_val = kpi.get(field_name, "").strip()
                if not field_val:
                    continue
                for regex in [COL_LIKE, BRACKET_COL]:
                    for match in regex.finditer(field_val):
                        token = match.group(1).lower().strip()
                        if '_' in token:
                            extracted_columns.add(token)

        extracted_columns -= NOISE_TOKENS
        results.append({
            "kpi_name": kpi_name,
            "structured_tables": dict(structured_tables),
            "extracted_columns": extracted_columns,
            "parse_category": category,
            "raw_text": raw,
        })
    return results


def _extract_kw_columns(kw_data: list) -> list:
    """Extract columns from each keyword entry."""
    results = []
    for kw in kw_data:
        raw = kw.get("mapped_tables_columns", "").strip()
        logic = kw.get("logic", "").strip()
        kw_name = kw.get("keyword_name", "unknown").strip()
        kw_desc = (kw.get("keyword_description ", "") or kw.get("keyword_description", "") or "").strip()
        synonyms = kw.get("synonyms", "").strip()

        extracted_columns = set()
        structured_tables = defaultdict(set)

        if not raw and not logic:
            results.append({
                "keyword_name": kw_name, "description": kw_desc, "synonyms": synonyms,
                "structured_tables": {}, "extracted_columns": set(), "raw_text": raw,
            })
            continue

        for match in STRUCTURED_PATTERN.finditer(raw):
            tbl = match.group(1).lower().strip()
            cols_raw = match.group(2)
            cols = [c.strip().lower() for c in cols_raw.split(",") if c.strip()]
            cols = [c for c in cols if re.match(r'^[a-z_][a-z0-9_]*$', c)]
            if tbl and cols:
                structured_tables[tbl].update(cols)
                extracted_columns.update(cols)

        for text_val in [raw, logic]:
            if not text_val:
                continue
            for regex in [COL_LIKE, BRACKET_COL]:
                for match in regex.finditer(text_val):
                    token = match.group(1).lower().strip()
                    extracted_columns.add(token)

        extracted_columns -= NOISE_TOKENS
        results.append({
            "keyword_name": kw_name, "description": kw_desc, "synonyms": synonyms,
            "structured_tables": dict(structured_tables), "extracted_columns": extracted_columns,
            "raw_text": raw,
        })
    return results


# ── Staging mapping helpers ──

def _map_kpi_columns_to_staging(kpi_extractions, staging_col_index, staging_schema):
    results = []
    for kpi in kpi_extractions:
        columns = kpi["extracted_columns"]
        structured = kpi["structured_tables"]
        structured_table_mapping = {}
        for client_tbl, cols in structured.items():
            stg_tbl = map_client_to_staging(client_tbl, staging_schema)
            if stg_tbl:
                staging_cols = {c.lower() for c in staging_schema.get(stg_tbl, [])}
                found = {c for c in cols if c in staging_cols}
                structured_table_mapping[client_tbl] = {"staging_table": stg_tbl, "columns_found": found, "columns_missing": cols - found}
            else:
                structured_table_mapping[client_tbl] = {"staging_table": None, "columns_found": set(), "columns_missing": cols}

        staging_mapping = defaultdict(lambda: {"columns_found": set()})
        unmapped_columns = set()
        for col in columns:
            stg_tables = staging_col_index.get(col)
            if stg_tables:
                for stg_tbl in stg_tables:
                    staging_mapping[stg_tbl]["columns_found"].add(col)
            else:
                unmapped_columns.add(col)

        results.append({
            "kpi_name": kpi["kpi_name"], "parse_category": kpi["parse_category"],
            "staging_mapping": dict(staging_mapping), "unmapped_columns": unmapped_columns,
            "structured_table_mapping": structured_table_mapping, "all_extracted_columns": columns,
        })
    return results


def _map_kw_columns_to_staging(kw_extractions, staging_col_index, staging_schema):
    results = []
    for kw in kw_extractions:
        columns = kw["extracted_columns"]
        structured = kw["structured_tables"]
        structured_table_mapping = {}
        for client_tbl, cols in structured.items():
            stg_tbl = map_client_to_staging(client_tbl, staging_schema)
            if stg_tbl:
                staging_cols = {c.lower() for c in staging_schema.get(stg_tbl, [])}
                found = {c for c in cols if c in staging_cols}
                structured_table_mapping[client_tbl] = {"staging_table": stg_tbl, "columns_found": found, "columns_missing": cols - found}
            else:
                structured_table_mapping[client_tbl] = {"staging_table": None, "columns_found": set(), "columns_missing": cols}

        staging_mapping = defaultdict(lambda: {"columns_found": set()})
        unmapped_columns = set()
        for col in columns:
            stg_tables = staging_col_index.get(col)
            if stg_tables:
                for stg_tbl in stg_tables:
                    staging_mapping[stg_tbl]["columns_found"].add(col)
            else:
                unmapped_columns.add(col)

        results.append({
            "keyword_name": kw["keyword_name"], "description": kw["description"],
            "synonyms": kw["synonyms"], "staging_mapping": dict(staging_mapping),
            "unmapped_columns": unmapped_columns, "structured_table_mapping": structured_table_mapping,
            "all_extracted_columns": columns,
        })
    return results


def _build_kpi_qb_overlap(kpi_mappings, qb_questions, staging_schema):
    qb_resolved = []
    for q in qb_questions:
        stg_tables = set()
        all_cols = set()
        for tbl, cols in q["tables"].items():
            stg_tbl = map_client_to_staging(tbl, staging_schema)
            if stg_tbl:
                stg_tables.add(stg_tbl)
            all_cols.update(c.lower() for c in cols)
        qb_resolved.append({"question": q["question"], "staging_tables": stg_tables, "columns": all_cols})

    results = []
    for kpi in kpi_mappings:
        kpi_stg_tables = set(kpi["staging_mapping"].keys())
        kpi_cols = kpi.get("all_extracted_columns", set())
        if not kpi_cols:
            results.append({"kpi_name": kpi["kpi_name"], "related_questions": []})
            continue
        related = []
        for qb in qb_resolved:
            if not qb["columns"]:
                continue
            shared_cols = kpi_cols & qb["columns"]
            if shared_cols:
                shared_tables = kpi_stg_tables & qb["staging_tables"]
                related.append({
                    "question": qb["question"], "shared_staging_tables": shared_tables,
                    "shared_columns": shared_cols, "overlap_score": len(shared_cols),
                })
        related.sort(key=lambda x: x["overlap_score"], reverse=True)
        results.append({"kpi_name": kpi["kpi_name"], "related_questions": related})
    return results


def _build_global_column_analysis(kpi_extractions, qb_questions, kw_extractions, staging_col_index):
    kpi_cols = defaultdict(list)
    for ext in kpi_extractions:
        for col in ext["extracted_columns"]:
            kpi_cols[col.lower()].append(ext["kpi_name"])
    qb_cols = defaultdict(int)
    for q in qb_questions:
        for col in q["all_columns"]:
            qb_cols[col.lower()] += 1
    kw_cols = defaultdict(list)
    for ext in kw_extractions:
        for col in ext["extracted_columns"]:
            kw_cols[col.lower()].append(ext["keyword_name"])

    all_cols = set(kpi_cols.keys()) | set(qb_cols.keys()) | set(kw_cols.keys())
    per_column = {}
    per_staging_table = defaultdict(lambda: {"kpi": set(), "qb": set(), "kw": set()})

    for col in sorted(all_cols):
        stg_tables = staging_col_index.get(col, set())
        in_kpi = kpi_cols.get(col, [])
        in_qb = qb_cols.get(col, 0)
        in_kw = kw_cols.get(col, [])
        sources = []
        if in_kpi: sources.append("KPI")
        if in_qb: sources.append("QB")
        if in_kw: sources.append("KW")
        per_column[col] = {
            "found_in_staging": bool(stg_tables),
            "staging_tables": sorted(stg_tables) if stg_tables else [],
            "kpi_refs": in_kpi, "qb_count": in_qb, "kw_refs": in_kw,
            "sources": sources, "source_count": len(sources),
        }
        if stg_tables:
            for stg in stg_tables:
                if in_kpi: per_staging_table[stg]["kpi"].add(col)
                if in_qb: per_staging_table[stg]["qb"].add(col)
                if in_kw: per_staging_table[stg]["kw"].add(col)

    found = sum(1 for v in per_column.values() if v["found_in_staging"])
    kpi_set = set(kpi_cols.keys())
    qb_set = set(qb_cols.keys())
    kw_set = set(kw_cols.keys())

    return {
        "total_unique_columns": len(all_cols), "columns_found": found,
        "columns_missing": len(all_cols) - found,
        "kpi_unique": len(kpi_set), "qb_unique": len(qb_set), "kw_unique": len(kw_set),
        "in_all_three": sorted(kpi_set & qb_set & kw_set),
        "in_kpi_qb_only": sorted((kpi_set & qb_set) - kw_set),
        "in_kpi_kw_only": sorted((kpi_set & kw_set) - qb_set),
        "in_qb_kw_only": sorted((qb_set & kw_set) - kpi_set),
        "per_column": per_column, "per_staging_table": dict(per_staging_table),
    }


# ── CSV Report generators ──

def _generate_question_csv(qb_questions, staging_col_index):
    """
    Generate CSV report for Question Bank entries.
    One row per question with all details in a single row.
    """
    rows = []
    for idx, q in enumerate(qb_questions, 1):
        all_cols = q["all_columns"]
        question_text = q["question"]

        found_cols = [col for col in sorted(all_cols) if staging_col_index.get(col.lower())]
        missing_cols = [col for col in sorted(all_cols) if not staging_col_index.get(col.lower())]

        # Build column-to-table mapping for found columns
        col_mapping = []
        for col in found_cols:
            tables = sorted(staging_col_index.get(col.lower(), set()))
            col_mapping.append(f"{col}→{','.join(tables)}")

        total_cols = len(all_cols)
        found_count = len(found_cols)
        missing_count = len(missing_cols)
        coverage = (found_count / total_cols * 100) if total_cols > 0 else 0

        # Determine match status
        if missing_count == 0:
            status = "MATCHED"
        elif found_count > 0:
            status = "PARTIAL"
        else:
            status = "UNMATCHED"

        rows.append({
            "Item_Type": "Question",
            "Item_ID": f"Q{idx}",
            "Item_Name": question_text[:150],  # Truncate long questions
            "Total_Columns": total_cols,
            "Columns_Found": found_count,
            "Columns_Missing": missing_count,
            "Coverage_Pct": round(coverage, 1),
            "Match_Status": status,
            "Found_Columns": "; ".join(found_cols) if found_cols else "NONE",
            "Missing_Columns": "; ".join(missing_cols) if missing_cols else "NONE",
            "Column_Mapping": "; ".join(col_mapping) if col_mapping else "NONE",
        })

    return rows


def _generate_kpi_csv(kpi_extractions, staging_col_index):
    """
    Generate CSV report for KPI Bank entries.
    One row per KPI with all details in a single row.
    """
    rows = []
    for kpi in kpi_extractions:
        kpi_name = kpi["kpi_name"]
        cols = kpi["extracted_columns"]
        category = kpi["parse_category"]

        found_cols = [col for col in sorted(cols) if staging_col_index.get(col.lower())]
        missing_cols = [col for col in sorted(cols) if not staging_col_index.get(col.lower())]

        # Build column-to-table mapping for found columns
        col_mapping = []
        for col in found_cols:
            tables = sorted(staging_col_index.get(col.lower(), set()))
            col_mapping.append(f"{col}→{','.join(tables)}")

        total_cols = len(cols)
        found_count = len(found_cols)
        missing_count = len(missing_cols)
        coverage = (found_count / total_cols * 100) if total_cols > 0 else 0

        # Determine match status
        if missing_count == 0 and total_cols > 0:
            status = "MATCHED"
        elif found_count > 0:
            status = "PARTIAL"
        else:
            status = "UNMATCHED"

        rows.append({
            "Item_Type": "KPI",
            "Item_ID": kpi_name,
            "Item_Name": kpi_name,
            "Category": category,
            "Total_Columns": total_cols,
            "Columns_Found": found_count,
            "Columns_Missing": missing_count,
            "Coverage_Pct": round(coverage, 1),
            "Match_Status": status,
            "Found_Columns": "; ".join(found_cols) if found_cols else "NONE",
            "Missing_Columns": "; ".join(missing_cols) if missing_cols else "NONE",
            "Column_Mapping": "; ".join(col_mapping) if col_mapping else "NONE",
        })

    return rows


def _generate_keyword_csv(kw_extractions, staging_col_index):
    """
    Generate CSV report for Keyword entries.
    One row per keyword with all details in a single row.
    """
    rows = []
    for kw in kw_extractions:
        kw_name = kw["keyword_name"]
        kw_desc = kw["description"]
        cols = kw["extracted_columns"]

        found_cols = [col for col in sorted(cols) if staging_col_index.get(col.lower())]
        missing_cols = [col for col in sorted(cols) if not staging_col_index.get(col.lower())]

        # Build column-to-table mapping for found columns
        col_mapping = []
        for col in found_cols:
            tables = sorted(staging_col_index.get(col.lower(), set()))
            col_mapping.append(f"{col}→{','.join(tables)}")

        total_cols = len(cols)
        found_count = len(found_cols)
        missing_count = len(missing_cols)
        coverage = (found_count / total_cols * 100) if total_cols > 0 else 0

        # Determine match status
        if missing_count == 0 and total_cols > 0:
            status = "MATCHED"
        elif found_count > 0:
            status = "PARTIAL"
        else:
            status = "UNMATCHED"

        rows.append({
            "Item_Type": "Keyword",
            "Item_ID": kw_name,
            "Item_Name": kw_name,
            "Description": kw_desc[:100] if kw_desc else "",
            "Total_Columns": total_cols,
            "Columns_Found": found_count,
            "Columns_Missing": missing_count,
            "Coverage_Pct": round(coverage, 1),
            "Match_Status": status,
            "Found_Columns": "; ".join(found_cols) if found_cols else "NONE",
            "Missing_Columns": "; ".join(missing_cols) if missing_cols else "NONE",
            "Column_Mapping": "; ".join(col_mapping) if col_mapping else "NONE",
        })

    return rows


def _rows_to_csv_string(rows, fieldnames):
    """Convert list of row dicts to CSV string."""
    if not rows:
        return ""

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=fieldnames, quoting=csv.QUOTE_ALL)
    writer.writeheader()

    for row in rows:
        # Fill missing fields with empty string
        filled_row = {field: row.get(field, "") for field in fieldnames}
        writer.writerow(filled_row)

    return output.getvalue()


def _generate_combined_csv(qb_rows, kpi_rows, kw_rows):
    """
    Generate a combined CSV with all items (Questions, KPIs, Keywords) in one file.
    """
    # Unified fieldnames that work for all item types
    fieldnames = [
        "Item_Type", "Item_ID", "Item_Name", "Total_Columns", "Columns_Found",
        "Columns_Missing", "Coverage_Pct", "Match_Status", "Found_Columns",
        "Missing_Columns", "Column_Mapping"
    ]

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=fieldnames, quoting=csv.QUOTE_ALL)
    writer.writeheader()

    # Add all rows
    for row in qb_rows + kpi_rows + kw_rows:
        filled_row = {field: row.get(field, "") for field in fieldnames}
        writer.writerow(filled_row)

    return output.getvalue()


# ── Report generators ──

def _generate_global_report(staging_schema, global_analysis, kpi_extractions, qb_questions, kw_extractions):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    ga = global_analysis
    total = ga["total_unique_columns"]
    found = ga["columns_found"]
    coverage = (found / total * 100) if total else 0

    md = []
    md.append(f"# Global Schema Comparison Report\n")
    md.append(f"**Generated:** {timestamp}  ")
    md.append(f"**Staging Schema:** `{settings.db_schema_compare}`  ")
    md.append(f"**Database:** `{settings.db_name}` @ `{settings.db_host}:{settings.db_port}`\n")

    md.append("## Overview\n")
    md.append("| Metric | Value |")
    md.append("|--------|-------|")
    md.append(f"| Staging tables | {len(staging_schema)} |")
    md.append(f"| KPI Bank entries | {len(kpi_extractions)} |")
    md.append(f"| Question Bank entries | {len(qb_questions)} |")
    md.append(f"| Keyword entries | {len(kw_extractions)} |")
    md.append(f"| **Total unique columns referenced** | **{total}** |")
    md.append(f"| Columns found in any staging table | {found} ({coverage:.1f}%) |")
    md.append(f"| **Columns NOT found in any staging table** | **{ga['columns_missing']}** |")

    pc = ga["per_column"]

    kpi_set = set()
    for ext in kpi_extractions:
        kpi_set.update(c.lower() for c in ext["extracted_columns"])
    qb_set = set()
    for q in qb_questions:
        qb_set.update(c.lower() for c in q["all_columns"])
    kw_set = set()
    for ext in kw_extractions:
        kw_set.update(c.lower() for c in ext["extracted_columns"])

    kpi_found = sum(1 for c in kpi_set if pc.get(c, {}).get("found_in_staging"))
    qb_found = sum(1 for c in qb_set if pc.get(c, {}).get("found_in_staging"))
    kw_found = sum(1 for c in kw_set if pc.get(c, {}).get("found_in_staging"))

    md.append("\n## Column Coverage by Source\n")
    md.append("| Source | Unique Columns | Found in Staging | Missing | Coverage |")
    md.append("|--------|---------------|-----------------|---------|----------|")
    for name, col_set, fc in [("KPI Bank", kpi_set, kpi_found), ("Question Bank", qb_set, qb_found), ("Keywords", kw_set, kw_found)]:
        t = len(col_set)
        m = t - fc
        cov = (fc / t * 100) if t else 0
        md.append(f"| {name} | {t} | {fc} | {m} | {cov:.1f}% |")

    md.append("\n## Cross-Source Column Overlap\n")
    in_all = ga["in_all_three"]
    md.append("| Overlap | Count |")
    md.append("|---------|-------|")
    md.append(f"| Columns in all 3 sources | {len(in_all)} |")
    md.append(f"| KPI + QB only | {len(ga['in_kpi_qb_only'])} |")
    md.append(f"| KPI + Keywords only | {len(ga['in_kpi_kw_only'])} |")
    md.append(f"| QB + Keywords only | {len(ga['in_qb_kw_only'])} |")

    if in_all:
        md.append(f"\n### Columns in All Three Sources ({len(in_all)})\n")
        md.append("| # | Column | Staging Table(s) |")
        md.append("|---|--------|-----------------|")
        for i, col in enumerate(in_all, 1):
            info = pc[col]
            stg = ", ".join(f"`{t}`" for t in info["staging_tables"]) if info["staging_tables"] else "**NOT FOUND**"
            md.append(f"| {i} | `{col}` | {stg} |")

    per_stg = ga["per_staging_table"]
    if per_stg:
        md.append(f"\n## Staging Table Utilization\n")
        md.append("| Staging Table | KPI Cols | QB Cols | KW Cols | Total Unique |")
        md.append("|--------------|----------|---------|---------|-------------|")
        for stg_tbl in sorted(per_stg.keys()):
            info = per_stg[stg_tbl]
            kc = len(info["kpi"])
            qc = len(info["qb"])
            wc = len(info["kw"])
            tc = len(info["kpi"] | info["qb"] | info["kw"])
            md.append(f"| `{stg_tbl}` | {kc} | {qc} | {wc} | {tc} |")

    missing_cols = {col: info for col, info in pc.items() if not info["found_in_staging"]}
    if missing_cols:
        md.append(f"\n## Columns Not Found in Any Staging Table ({len(missing_cols)})\n")
        md.append("| # | Column | Sources | KPI Refs | QB Qs | KW Refs |")
        md.append("|---|--------|---------|----------|-------|---------|")
        for i, (col, info) in enumerate(sorted(missing_cols.items()), 1):
            sources = ", ".join(info["sources"])
            md.append(f"| {i} | `{col}` | {sources} | {len(info['kpi_refs'])} | {info['qb_count']} | {len(info['kw_refs'])} |")

    return "\n".join(md)


def _generate_detailed_report(staging_schema, staging_col_index, qb_questions, kpi_extractions,
                               kpi_mappings, kw_extractions, kw_mappings, kpi_qb_overlaps):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    md = []
    md.append(f"# Detailed Schema Comparison Report\n")
    md.append(f"**Generated:** {timestamp}  ")
    md.append(f"**Staging Schema:** `{settings.db_schema_compare}`  ")
    md.append(f"**Database:** `{settings.db_name}` @ `{settings.db_host}:{settings.db_port}`\n")

    category_labels = {
        "structured": "Structured table(cols)", "formula_with_columns": "Formula / prose with columns",
        "mbt_prefixed": "MBT/NDPd-prefixed columns", "external_ref": "External reference (non-DB)",
        "empty": "Empty (no mapping provided)", "unparseable": "Unparseable",
    }

    # Section 1: QB
    md.append("---\n# Section 1: Question Bank - Per Question Detail\n")
    for i, q in enumerate(qb_questions, 1):
        all_cols = q["all_columns"]
        md.append(f"### Q{i}: {q['question'][:100]}\n")
        if not all_cols:
            md.append("*No columns extracted from SQL.*\n")
            continue
        found_cols = [(col, sorted(staging_col_index.get(col.lower(), set()))) for col in sorted(all_cols) if staging_col_index.get(col.lower())]
        missing_cols = [col for col in sorted(all_cols) if not staging_col_index.get(col.lower())]
        cov = (len(found_cols) / len(all_cols) * 100) if all_cols else 0
        md.append(f"- Columns referenced: **{len(all_cols)}**")
        md.append(f"- Found: **{len(found_cols)}** ({cov:.0f}%) | Missing: **{len(missing_cols)}**\n")
        if found_cols:
            md.append("| Column | Found in Staging Table(s) |")
            md.append("|--------|--------------------------|")
            for col, tables in found_cols:
                md.append(f"| `{col}` | {', '.join(f'`{t}`' for t in tables)} |")
        if missing_cols:
            md.append(f"\n**Missing columns:** {', '.join(f'`{c}`' for c in missing_cols)}\n")

    # Section 2: KPIs
    md.append("\n---\n# Section 2: KPI Bank - Per KPI Detail\n")
    for ext, mapping in zip(kpi_extractions, kpi_mappings):
        cols = ext["extracted_columns"]
        md.append(f"### {ext['kpi_name']}\n")
        md.append(f"- **Category:** {category_labels.get(ext['parse_category'], ext['parse_category'])}")
        md.append(f"- **Columns extracted:** {len(cols)}")
        if not cols:
            md.append("\n*No columns extracted.*\n")
            continue
        found_cols = [(col, sorted(staging_col_index.get(col.lower(), set()))) for col in sorted(cols) if staging_col_index.get(col.lower())]
        missing_cols = [col for col in sorted(cols) if not staging_col_index.get(col.lower())]
        cov = (len(found_cols) / len(cols) * 100) if cols else 0
        md.append(f"- Found: **{len(found_cols)}** ({cov:.0f}%) | Missing: **{len(missing_cols)}**\n")
        if found_cols:
            md.append("| Column | Found in Staging Table(s) |")
            md.append("|--------|--------------------------|")
            for col, tables in found_cols:
                md.append(f"| `{col}` | {', '.join(f'`{t}`' for t in tables)} |")
        if missing_cols:
            md.append(f"\n**Missing columns:** {', '.join(f'`{c}`' for c in missing_cols)}\n")

    # Section 3: Keywords
    md.append("\n---\n# Section 3: Keywords - Per Keyword Detail\n")
    for ext, mapping in zip(kw_extractions, kw_mappings):
        cols = ext["extracted_columns"]
        md.append(f"### {ext['keyword_name']}\n")
        md.append(f"- **Columns extracted:** {len(cols)}")
        if not cols:
            md.append("\n*No columns extracted.*\n")
            continue
        found_cols = [(col, sorted(staging_col_index.get(col.lower(), set()))) for col in sorted(cols) if staging_col_index.get(col.lower())]
        missing_cols = [col for col in sorted(cols) if not staging_col_index.get(col.lower())]
        cov = (len(found_cols) / len(cols) * 100) if cols else 0
        md.append(f"- Found: **{len(found_cols)}** ({cov:.0f}%) | Missing: **{len(missing_cols)}**\n")
        if found_cols:
            md.append("| Column | Found in Staging Table(s) |")
            md.append("|--------|--------------------------|")
            for col, tables in found_cols:
                md.append(f"| `{col}` | {', '.join(f'`{t}`' for t in tables)} |")
        if missing_cols:
            md.append(f"\n**Missing columns:** {', '.join(f'`{c}`' for c in missing_cols)}\n")

    # Section 4: KPI <-> QB
    md.append("\n---\n# Section 4: KPI - Question Bank Relationships\n")
    kpis_with = [k for k in kpi_qb_overlaps if k["related_questions"]]
    kpis_without = [k for k in kpi_qb_overlaps if not k["related_questions"]]
    md.append("| Metric | Count |")
    md.append("|--------|-------|")
    md.append(f"| KPIs with related QB questions | {len(kpis_with)} |")
    md.append(f"| KPIs with NO QB overlap | {len(kpis_without)} |")

    if kpis_with:
        md.append("\n### KPI -> Related Questions\n")
        for kpi in kpis_with:
            md.append(f"#### {kpi['kpi_name']}\n")
            for j, rel in enumerate(kpi["related_questions"][:5], 1):
                shared_cols = ", ".join(f"`{c}`" for c in sorted(rel["shared_columns"]))
                md.append(f"{j}. **\"{rel['question'][:80]}\"** (overlap: {rel['overlap_score']} columns)")
                md.append(f"   - Shared columns: {shared_cols}")
            md.append("")

    return "\n".join(md)


# ── Public entry point ──

async def run_schema_compare(db: AsyncSession) -> dict:
    """
    Run full schema comparison and return dict with global_report, detailed_report, statistics.
    Raises HTTPException on error.
    """
    from fastapi import HTTPException

    staging_schema = await fetch_staging_schema_async(db, settings.db_schema_compare)
    if not staging_schema:
        raise HTTPException(status_code=404, detail=f"No tables found in schema '{settings.db_schema_compare}'")

    staging_col_index = build_staging_column_index(staging_schema)

    kpi_data, qb_data, kw_data = await load_json_from_semantic_tables(db)
    if not kpi_data and not qb_data and not kw_data:
        raise HTTPException(status_code=404, detail="No KPI, QB, or Keyword data found in semantic tables")

    qb_questions = _extract_qb_per_question(qb_data, staging_col_index)
    kpi_extractions = _extract_kpi_columns_enhanced(kpi_data)
    kpi_mappings = _map_kpi_columns_to_staging(kpi_extractions, staging_col_index, staging_schema)
    kw_extractions = _extract_kw_columns(kw_data)
    kw_mappings = _map_kw_columns_to_staging(kw_extractions, staging_col_index, staging_schema)
    kpi_qb_overlaps = _build_kpi_qb_overlap(kpi_mappings, qb_questions, staging_schema)
    global_analysis = _build_global_column_analysis(kpi_extractions, qb_questions, kw_extractions, staging_col_index)

    global_md = _generate_global_report(staging_schema, global_analysis, kpi_extractions, qb_questions, kw_extractions)
    detailed_md = _generate_detailed_report(
        staging_schema, staging_col_index, qb_questions,
        kpi_extractions, kpi_mappings, kw_extractions, kw_mappings, kpi_qb_overlaps,
    )

    # Generate CSV reports
    qb_rows = _generate_question_csv(qb_questions, staging_col_index)
    kpi_rows = _generate_kpi_csv(kpi_extractions, staging_col_index)
    kw_rows = _generate_keyword_csv(kw_extractions, staging_col_index)

    qb_csv = _rows_to_csv_string(qb_rows, [
        "Item_Type", "Item_ID", "Item_Name", "Total_Columns", "Columns_Found",
        "Columns_Missing", "Coverage_Pct", "Match_Status", "Found_Columns",
        "Missing_Columns", "Column_Mapping"
    ])
    kpi_csv = _rows_to_csv_string(kpi_rows, [
        "Item_Type", "Item_ID", "Item_Name", "Category", "Total_Columns", "Columns_Found",
        "Columns_Missing", "Coverage_Pct", "Match_Status", "Found_Columns",
        "Missing_Columns", "Column_Mapping"
    ])
    kw_csv = _rows_to_csv_string(kw_rows, [
        "Item_Type", "Item_ID", "Item_Name", "Description", "Total_Columns", "Columns_Found",
        "Columns_Missing", "Coverage_Pct", "Match_Status", "Found_Columns",
        "Missing_Columns", "Column_Mapping"
    ])
    combined_csv = _generate_combined_csv(qb_rows, kpi_rows, kw_rows)

    ga = global_analysis
    coverage = (ga["columns_found"] / ga["total_unique_columns"] * 100) if ga["total_unique_columns"] else 0

    return {
        "global_report": global_md,
        "detailed_report": detailed_md,
        "csv_reports": {
            "questions": qb_csv,
            "kpis": kpi_csv,
            "keywords": kw_csv,
            "combined": combined_csv,
        },
        "statistics": {
            "staging_tables": len(staging_schema),
            "kpi_entries": len(kpi_data),
            "qb_entries": len(qb_data),
            "kw_entries": len(kw_data),
            "total_unique_columns": ga["total_unique_columns"],
            "columns_found": ga["columns_found"],
            "columns_missing": ga["columns_missing"],
            "coverage_pct": round(coverage, 1),
        },
    }
