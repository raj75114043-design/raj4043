"""
Embedding Service for generating vector embeddings via Nokia LLM Gateway
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import logging
import httpx
from typing import List, Optional
from tenacity import retry, stop_after_attempt, wait_exponential
from app.core.config import settings

logger = logging.getLogger(__name__)


class EmbeddingService:
    """
    Service for generating text embeddings using Nokia LLM Gateway
    """

    def __init__(self):
        self.timeout = 30.0
        self._log_config()

    def _log_config(self):
        """Log the embedding service configuration on init"""
        logger.info(f"EmbeddingService initialized")
        logger.info(f"  API URL: {self.api_url}")
        logger.info(f"  Workspace: {settings.workspace_name}")
        logger.info(f"  Model: {settings.embedding_model}")
        logger.info(f"  API Key configured: {'Yes' if settings.llm_api_key else 'No'}")

    @property
    def api_url(self) -> str:
        """Get the embedding API URL"""
        if settings.llm_api_key_url:
            base_url = settings.llm_api_key_url.rstrip('/')
            return f"{base_url}/Embeddings"
        return settings.embed_api_url

    @property
    def headers(self) -> dict:
        """Get request headers with authentication for Nokia LLM Gateway"""
        return {
            "accept": "*/*",
            "workspaceName": settings.workspace_name,
            "api-key": settings.llm_api_key,
            "Content-Type": "application/json"
        }

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        reraise=True
    )
    async def generate_embedding(self, text: str) -> Optional[List[float]]:
        """
        Generate embedding vector for a single text

        Args:
            text: Text to generate embedding for

        Returns:
            List of floats representing the embedding vector
        """
        if not self.api_url:
            logger.error("Embedding API URL not configured")
            raise ValueError("Embedding API URL not configured (set LLM_API_KEY_URL in .env)")

        if not text or not text.strip():
            logger.warning("Empty text provided for embedding")
            return None

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            payload = {
                "input": text,
                "model": settings.embedding_model
            }

            logger.info(f"Calling embedding API: {self.api_url}")
            logger.debug(f"Model: {settings.embedding_model}, Text length: {len(text)}")

            try:
                response = await client.post(
                    self.api_url,
                    json=payload,
                    headers=self.headers
                )
                response.raise_for_status()
                result = response.json()

                logger.debug(f"API Response type: {type(result)}, keys: {result.keys() if isinstance(result, dict) else 'N/A'}")

                # Handle different response formats (matching Nokia LLM Gateway format)
                if isinstance(result, dict) and "data" in result and len(result["data"]) > 0:
                    embedding = result["data"][0].get("embedding")
                    if embedding:
                        logger.info(f"Generated embedding with {len(embedding)} dimensions")
                    return embedding
                elif isinstance(result, dict) and "embedding" in result:
                    return result["embedding"]
                elif isinstance(result, list) and len(result) > 0:
                    if isinstance(result[0], dict) and "embedding" in result[0]:
                        return result[0]["embedding"]
                    return result
                else:
                    logger.error(f"Unexpected response format: {result}")
                    raise ValueError(f"Unexpected embedding response format")

            except httpx.HTTPStatusError as e:
                logger.error(f"HTTP {e.response.status_code}: {e.response.text}")
                raise
            except Exception as e:
                logger.error(f"Embedding API error: {str(e)}")
                raise

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        reraise=True
    )
    async def generate_embeddings_batch(
        self,
        texts: List[str]
    ) -> List[Optional[List[float]]]:
        """
        Generate embedding vectors for multiple texts

        Args:
            texts: List of texts to generate embeddings for

        Returns:
            List of embedding vectors
        """
        if not self.api_url:
            raise ValueError("Embedding API URL not configured (set LLM_API_KEY_URL in .env)")

        # Filter out empty texts and track indices
        valid_texts = []
        valid_indices = []
        for i, text in enumerate(texts):
            if text and text.strip():
                valid_texts.append(text)
                valid_indices.append(i)

        if not valid_texts:
            return [None] * len(texts)

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            payload = {
                "input": valid_texts,
                "model": settings.embedding_model
            }

            logger.info(f"Calling embedding API for batch of {len(valid_texts)} texts")

            try:
                response = await client.post(
                    self.api_url,
                    json=payload,
                    headers=self.headers
                )
                response.raise_for_status()
                result = response.json()

                # Parse embeddings from response
                embeddings_data = []
                if isinstance(result, dict) and "data" in result:
                    embeddings_data = [item.get("embedding") for item in result["data"]]
                elif isinstance(result, dict) and "embeddings" in result:
                    embeddings_data = result["embeddings"]

                # Map back to original indices
                result_embeddings = [None] * len(texts)
                for idx, embedding in zip(valid_indices, embeddings_data):
                    result_embeddings[idx] = embedding

                logger.info(f"Generated {len(embeddings_data)} embeddings")
                return result_embeddings

            except httpx.HTTPStatusError as e:
                logger.error(f"HTTP {e.response.status_code}: {e.response.text}")
                raise
            except Exception as e:
                logger.error(f"Batch embedding API error: {str(e)}")
                raise

    def combine_text_for_embedding(self, **fields) -> str:
        """
        Combine multiple text fields into a single string for embedding

        Args:
            **fields: Named text fields to combine

        Returns:
            Combined text string
        """
        parts = []
        for field_name, value in fields.items():
            if value:
                if isinstance(value, list):
                    value = " ".join(str(v) for v in value if v)
                parts.append(f"{field_name}: {value}")
        return " | ".join(parts)


# Singleton instance
embedding_service = EmbeddingService()
