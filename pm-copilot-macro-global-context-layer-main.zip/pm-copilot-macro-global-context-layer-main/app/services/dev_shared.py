"""
Shared constants, regex patterns, and helper functions used by dev utility services.
"""

import re
import logging
from collections import defaultdict
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text

from app.models.semantic_models import SemanticKPI, SemanticQuestionBank, SemanticKeyword

logger = logging.getLogger(__name__)

# ── SQL / noise / system constants ──

SQL_KEYWORDS = {
    'select', 'distinct', 'as', 'count', 'sum', 'avg', 'min', 'max',
    'case', 'when', 'then', 'else', 'end', 'cast', 'numeric', 'date',
    'int', 'integer', 'filter', 'where', 'trim', 'upper', 'lower',
    'to_char', 'coalesce', 'nullif', 'round', 'interval', 'current_date',
    'null', 'not', 'and', 'or', 'in', 'like', 'ilike', 'between',
    'true', 'false', 'having', 'group', 'order', 'by', 'asc', 'desc',
    'from', 'join', 'left', 'right', 'inner', 'outer', 'on', 'cross',
    'union', 'all', 'exists', 'is', 'public',
    'with', 'recursive', 'over', 'partition', 'rows', 'range',
    'generate_series', 'extract', 'isodow', 'string_agg',
    'lag', 'lead', 'row_number', 'rank', 'dense_rank',
    'full', 'natural', 'using', 'into', 'values', 'insert',
    'update', 'delete', 'set', 'create', 'drop', 'alter', 'table',
    'index', 'view', 'schema', 'limit', 'offset', 'fetch', 'next',
    'first', 'last', 'nulls', 'preceding', 'following', 'unbounded',
    'current', 'row', 'groups', 'exclude', 'ties', 'no', 'others',
    'countrows', 'calculate', 'containsstring',
    'pwc_macro_staging_schema', 'subquery_alias',
    'isoweek', 'isoyear', 'week', 'month', 'year', 'day',
    'lpad', 'text', 'greatest', 'least',
}

NOISE_TOKENS = {
    'data_table', 'mbt_tracker', 'pm_tracker', 'mbt_dump',
    'ndpd_dump', 'action_tracker', 'mbt_data',
}

SYSTEM_COLUMNS = {"id", "create_date", "create_uid", "write_date", "write_uid"}

# ── Compiled regex patterns ──

STRUCTURED_PATTERN = re.compile(r'([a-z][a-z0-9_]*)\s*\(([^)]+)\)', re.IGNORECASE)
COL_LIKE = re.compile(r'\b([a-z][a-z0-9]*(?:_[a-z0-9]+)+)\b', re.IGNORECASE)
BRACKET_COL = re.compile(r'\[([a-z_][a-z0-9_]*)\]', re.IGNORECASE)
MBT_PREFIX = re.compile(
    r'(?:MBT|NDPd|NDPD|NDPc|PM\s*Tracker)\s*[\-:]\s*(?:Dump\s*[\-:]\s*)?([a-z_][a-z0-9_]*)',
    re.IGNORECASE,
)
FROM_JOIN_PATTERN = re.compile(
    r'(?:FROM|JOIN)\s+'
    r'(?:(?:public|pwc_macro_staging_schema)\.)?'
    r'([a-z][a-z0-9_]*)'
    r'(?:\s+(?:AS\s+)?([a-z][a-z0-9_]*))?',
    re.IGNORECASE,
)
QUALIFIED_COL = re.compile(r'([a-z][a-z0-9_]*)\.([a-z_][a-z0-9_]*)', re.IGNORECASE)
EXTERNAL_KEYWORDS = [
    'daily hse action report', 'e2e tracker', 'rider column',
    'tmo-dec-rsa', 'osdp table', 'to be integrated',
]


# ── Shared async helpers ──

async def fetch_staging_schema_async(db: AsyncSession, schema: str) -> dict:
    """Fetch all tables and columns from the specified schema. Returns {table: [columns]}."""
    result = await db.execute(
        text("""
            SELECT table_name, column_name
            FROM information_schema.columns
            WHERE table_schema = :schema
            ORDER BY table_name, ordinal_position
        """),
        {"schema": schema},
    )
    rows = result.fetchall()
    schema_dict = defaultdict(list)
    for table_name, column_name in rows:
        schema_dict[table_name].append(column_name)
    return dict(schema_dict)


async def load_json_from_semantic_tables(db: AsyncSession) -> tuple:
    """Load KPI, QB, Keywords data from the semantic tables in the DB."""
    kpi_result = await db.execute(select(SemanticKPI))
    kpis = []
    for row in kpi_result.scalars().all():
        kpis.append({
            "kpi_name": row.kpi_name,
            "description": row.description or "",
            "formula": row.formula or "",
            "mapped_tables_columns": row.mapped_tables_columns or "",
            "logic": row.logic or "",
            "root_cause_positive": row.root_cause_positive or "",
            "root_cause_negative": row.root_cause_negative or "",
        })

    qb_result = await db.execute(select(SemanticQuestionBank))
    questions = []
    for row in qb_result.scalars().all():
        questions.append({
            "question": row.question,
            "sql": row.sql,
        })

    kw_result = await db.execute(select(SemanticKeyword))
    keywords = []
    for row in kw_result.scalars().all():
        keywords.append({
            "keyword_name": row.keyword_name,
            "keyword_description": row.keyword_description or "",
            "mapped_tables_columns": row.mapped_tables_columns or "",
            "logic": row.logic or "",
            "synonyms": row.synonyms or "",
        })

    return kpis, questions, keywords


def build_staging_column_index(staging_schema: dict) -> dict:
    """column_name -> set of staging table names."""
    col_index = defaultdict(set)
    for stg_table, columns in staging_schema.items():
        for col in columns:
            col_index[col.lower()].add(stg_table)
    return dict(col_index)


def map_client_to_staging(client_table: str, staging_schema: dict) -> str | None:
    """Map client table name to staging table with stg_ prefix."""
    staging_names = set(staging_schema.keys())
    cleaned = client_table.lower().strip()

    stg_name = f"stg_{cleaned}"
    if stg_name in staging_names:
        return stg_name
    if cleaned.startswith("public."):
        cleaned = cleaned[7:]
        stg_name = f"stg_{cleaned}"
        if stg_name in staging_names:
            return stg_name
    if cleaned in staging_names:
        return cleaned
    for stg in staging_names:
        if stg.endswith(f"_{cleaned}"):
            return stg
    return None
