"""
Services module for PM Copilot Global Context Layer
"""

from app.services.embedding_service import embedding_service, EmbeddingService

__all__ = ["embedding_service", "EmbeddingService"]
