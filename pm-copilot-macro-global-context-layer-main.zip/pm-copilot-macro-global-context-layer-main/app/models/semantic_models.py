"""
Semantic Database models with vector embeddings for PM Copilot Global Context Layer
Schema: pwc_semantic_information_schema
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import random
from datetime import datetime
from typing import List, Optional
from sqlalchemy import (
    Integer,
    String,
    Text,
    DateTime,
    Enum,
    ARRAY,
    Float,
)
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.dialects.postgresql import JSONB
from app.db.database import Base
from app.core.config import settings
import enum


def _random_6_digit() -> int:
    """Generate a random 6-digit ID (100000–999999)."""
    return random.randint(100000, 999999)


class SemanticRCATypeEnum(str, enum.Enum):
    """RCA question types for semantic tables"""
    GENERAL_RCA = "General RCA"
    RECOMMENDATION = "Recommendation"
    ESCALATION = "Escalation"


class SemanticKPI(Base):
    """
    Semantic KPI Table: Stores KPIs with vector embeddings for semantic search
    """
    __tablename__ = "semantic_kpi"
    __table_args__ = {"schema": settings.db_schema}

    kpi_id: Mapped[int] = mapped_column(Integer, primary_key=True, default=_random_6_digit)
    kpi_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    formula: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    mapped_tables_columns: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    logic: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    root_cause_positive: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    root_cause_negative: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Vector embedding column stored as array of floats
    embedding: Mapped[Optional[List[float]]] = mapped_column(
        ARRAY(Float),
        nullable=True,
        comment="Vector embedding for semantic search"
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    def __repr__(self) -> str:
        return f"<SemanticKPI(kpi_id={self.kpi_id}, kpi_name='{self.kpi_name}')>"


class SemanticQuestionBank(Base):
    """
    Semantic Question Bank Table: Stores questions with vector embeddings
    """
    __tablename__ = "semantic_question_bank"
    __table_args__ = {"schema": settings.db_schema}

    question_id: Mapped[int] = mapped_column(Integer, primary_key=True, default=_random_6_digit)
    question: Mapped[str] = mapped_column(Text, nullable=False, index=True)
    sql: Mapped[str] = mapped_column(Text, nullable=False)

    # Vector embedding column
    embedding: Mapped[Optional[List[float]]] = mapped_column(
        ARRAY(Float),
        nullable=True,
        comment="Vector embedding for semantic search"
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    def __repr__(self) -> str:
        return f"<SemanticQuestionBank(question_id={self.question_id})>"


class SemanticRCA(Base):
    """
    Semantic RCA Table: Stores Root Cause Analysis with vector embeddings
    """
    __tablename__ = "semantic_rca"
    __table_args__ = {"schema": settings.db_schema}

    problem_id: Mapped[int] = mapped_column(Integer, primary_key=True, default=_random_6_digit)
    rca_question: Mapped[str] = mapped_column(Text, nullable=False, index=True)
    type_of_rca_question: Mapped[SemanticRCATypeEnum] = mapped_column(
        Enum(SemanticRCATypeEnum, native_enum=False, length=50),
        nullable=False,
        index=True
    )
    root_causes: Mapped[Optional[List[str]]] = mapped_column(ARRAY(Text), nullable=True)
    root_cause_sudo_sql_schema: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    relevant_kpis: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    steps_to_get_data_sql: Mapped[Optional[List[str]]] = mapped_column(ARRAY(Text), nullable=True)
    recommendation_area: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    output_preferred_template: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Vector embedding column
    embedding: Mapped[Optional[List[float]]] = mapped_column(
        ARRAY(Float),
        nullable=True,
        comment="Vector embedding for semantic search"
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    def __repr__(self) -> str:
        return f"<SemanticRCA(problem_id={self.problem_id})>"


class SemanticSimulation(Base):
    """
    Semantic Simulation Table: Stores simulation scenarios with vector embeddings
    """
    __tablename__ = "semantic_simulation"
    __table_args__ = {"schema": settings.db_schema}

    scenario_id: Mapped[int] = mapped_column(Integer, primary_key=True, default=_random_6_digit)
    scenario: Mapped[str] = mapped_column(String(500), nullable=False, index=True)
    data_phase_steps: Mapped[Optional[List[str]]] = mapped_column(ARRAY(Text), nullable=True)
    data_phase_questions: Mapped[Optional[List[str]]] = mapped_column(ARRAY(Text), nullable=True)
    calculation_phase_steps: Mapped[Optional[List[str]]] = mapped_column(ARRAY(Text), nullable=True)
    simulator_phase_steps: Mapped[Optional[List[str]]] = mapped_column(ARRAY(Text), nullable=True)
    simulation_methodology: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Vector embedding column
    embedding: Mapped[Optional[List[float]]] = mapped_column(
        ARRAY(Float),
        nullable=True,
        comment="Vector embedding for semantic search"
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    def __repr__(self) -> str:
        return f"<SemanticSimulation(scenario_id={self.scenario_id})>"


class SemanticKeyword(Base):
    """
    Keywords Table: Stores keywords with synonyms and mappings (no embedding)
    """
    __tablename__ = "semantic_keywords"
    __table_args__ = {"schema": settings.db_schema}

    keyword_id: Mapped[int] = mapped_column(Integer, primary_key=True, default=_random_6_digit)
    keyword_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    keyword_description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    mapped_tables_columns: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    logic: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    synonyms: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    def __repr__(self) -> str:
        return f"<SemanticKeyword(keyword_id={self.keyword_id}, keyword_name='{self.keyword_name}')>"


class SemanticEscalation(Base):
    """
    Semantic Escalation Table: Stores escalation scenarios with vector embeddings
    """
    __tablename__ = "semantic_escalation"
    __table_args__ = {"schema": settings.db_schema}

    scenario_id: Mapped[int] = mapped_column(Integer, primary_key=True, default=_random_6_digit)

    escalation_type: Mapped[str] = mapped_column(String(500), nullable=False, index=True)

    escalation_description: Mapped[Optional[List[str]]] = mapped_column(
        ARRAY(Text), nullable=True
    )

    probable_reasons: Mapped[Optional[List[str]]] = mapped_column(
        ARRAY(Text), nullable=True
    )

    recommended_resolution: Mapped[Optional[List[str]]] = mapped_column(
        ARRAY(Text), nullable=True
    )

    expected_agent_output: Mapped[Optional[List[str]]] = mapped_column(
        ARRAY(Text), nullable=True
    )

    draft_escalation_message_template: Mapped[Optional[str]] = mapped_column(
        Text, nullable=True
    )

    relevent_kpi_s: Mapped[Optional[List[str]]] = mapped_column(
        ARRAY(Text), nullable=True
    )

    vertical: Mapped[Optional[str]] = mapped_column(
        String(200), nullable=True, index=True
    )

    # Vector embedding column
    embedding: Mapped[Optional[List[float]]] = mapped_column(
        ARRAY(Float),
        nullable=True,
        comment="Vector embedding for semantic search of escalation scenarios"
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )

    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )

    def __repr__(self) -> str:
        return f"<SemanticEscalation(scenario_id={self.scenario_id}, escalation_type={self.escalation_type})>"


class TableSchemaMap(Base):
    """
    Table Schema Map: Stores the comprehensive table-centric schema JSON
    produced by the table_schema_builder utility.
    """
    __tablename__ = "table_schema_map"
    __table_args__ = {"schema": settings.db_schema}

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    schema_data: Mapped[dict] = mapped_column(JSONB, nullable=False, comment="Full table schema map JSON")
    created_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, nullable=False
    )

    def __repr__(self) -> str:
        return f"<TableSchemaMap(id={self.id}, created_at='{self.created_at}')>"
