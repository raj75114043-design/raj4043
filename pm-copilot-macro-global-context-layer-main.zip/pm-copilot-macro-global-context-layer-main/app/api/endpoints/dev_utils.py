"""
Developer Utility Endpoints
============================
Thin route definitions that delegate to service modules:
  1. GET  /schema-compare       – Compare staging schema against KPI/QB/Keywords
  2. GET  /table-schema-builder – Build table-centric JSON, store in PostgreSQL
  3. POST /schema-world-view    – Produce focused SQL schema world view
"""

import logging

from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import HTTPBasicCredentials
from sqlalchemy.ext.asyncio import AsyncSession

from app.db.database import get_db
from app.core.config import settings
from app.schemas.semantic_schemas import (
    SchemaCompareResponse,
    TableSchemaBuilderResponse,
    SchemaWorldViewRequest,
    SchemaWorldViewResponse,
)
from app.api.endpoints.database import verify_dev_password
from app.services.schema_compare_service import run_schema_compare
from app.services.table_schema_builder_service import run_table_schema_builder
from app.services.schema_world_view_service import run_schema_world_view

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/dev", tags=["Developer Utilities [Dev Only]"])


@router.get("/schema-compare", response_model=SchemaCompareResponse)
async def schema_compare(
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
):
    """
    Compare the staging schema (db_schema_compare) against KPI, Question Bank,
    and Keywords data stored in the semantic tables. Returns two markdown reports:
    a global summary and a detailed per-entry report.
    """
    try:
        logger.info("Starting schema comparison...")
        result = await run_schema_compare(db)
        return SchemaCompareResponse(success=True, **result)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Schema comparison failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Schema comparison failed: {str(e)}")


@router.get("/table-schema-builder", response_model=TableSchemaBuilderResponse)
async def table_schema_builder(
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
):
    """
    Build comprehensive table-centric JSON mapping KPIs, Questions, and Keywords
    to staging tables and columns. Stores the result in PostgreSQL and returns it.
    """
    try:
        logger.info("Starting table schema builder...")
        result = await run_table_schema_builder(db)
        return TableSchemaBuilderResponse(
            success=True,
            message=f"Table schema map built and stored (id={result['stored_id']}) in {settings.db_schema}.table_schema_map",
            table_schema_map=result["schema_map"],
            stored_id=result["stored_id"],
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Table schema builder failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Table schema builder failed: {str(e)}")


@router.post("/schema-world-view", response_model=SchemaWorldViewResponse)
async def schema_world_view(
    request: SchemaWorldViewRequest,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
):
    """
    Consume the stored table schema map from PostgreSQL and produce a focused
    SQL schema world view for a text-to-SQL system. Takes lists of KPI names,
    question texts, and keyword names as input.
    """
    try:
        result = await run_schema_world_view(db, request)
        return SchemaWorldViewResponse(success=True, **result)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Schema world view failed: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Schema world view failed: {str(e)}")
