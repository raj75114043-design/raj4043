"""
Question Bank CRUD endpoints for PM Copilot Global Context Layer
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""
import logging
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query


from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text, func
from sqlalchemy.orm import selectinload
import numpy as np

from fastapi import Security, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import secrets

from app.db.database import get_db, async_engine, Base
from app.core.config import settings
from app.models.semantic_models import (
    SemanticQuestionBank,
)
from app.schemas.semantic_schemas import (
    SemanticQuestionBankCreate,
    SemanticQuestionBankUpdate,
    SemanticQuestionBankResponse,
    MessageResponse,
    BulkDeleteRequest,
    BulkOperationResponse,
)
from app.services.embedding_service import embedding_service

security = HTTPBasic()
logger = logging.getLogger(__name__)
router = APIRouter(prefix="/question-bank", tags=["Question Bank Creations [Dev Only]"])
DEV_PASSOWRD = "pwc_macro_team"

def verify_dev_password(credentials: HTTPBasicCredentials = Depends(security)):
    correct = secrets.compare_digest(credentials.password, "pwc_macro_team")
    if not correct:
        raise HTTPException(status_code=401, headers={"WWW-Authenticate": "Basic"})




@router.post("/question-bank", response_model=SemanticQuestionBankResponse, status_code=201)
async def create_semantic_question(
    question: SemanticQuestionBankCreate,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> SemanticQuestionBankResponse:
    """Create a new semantic question with auto-generated embedding"""
    combined_text = embedding_service.combine_text_for_embedding(
        question=question.question,
        sql=question.sql
    )

    embedding = None
    try:
        embedding = await embedding_service.generate_embedding(combined_text)
    except Exception as e:
        logger.warning(f"Failed to generate embedding: {e}")

    db_question = SemanticQuestionBank(**question.model_dump(), embedding=embedding)
    db.add(db_question)
    await db.commit()
    await db.refresh(db_question)
    return SemanticQuestionBankResponse.model_validate(db_question)


@router.get("/question-bank", response_model=List[SemanticQuestionBankResponse])
async def list_semantic_questions(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: AsyncSession = Depends(get_db)
) -> List[SemanticQuestionBankResponse]:
    """List all semantic questions with pagination"""
    result = await db.execute(
        select(SemanticQuestionBank).offset(skip).limit(limit).order_by(SemanticQuestionBank.question_id)
    )
    questions = result.scalars().all()
    return [SemanticQuestionBankResponse.model_validate(q) for q in questions]




@router.post("/question-bank/bulk", response_model=BulkOperationResponse, status_code=201)
async def bulk_create_questions(
    questions: List[SemanticQuestionBankCreate],
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Bulk create semantic questions with auto-generated embeddings (max 100 items per request)

    Returns success/failure counts and details for each operation.
    """
    if len(questions) > 100:
        raise HTTPException(status_code=400, detail="Maximum 100 items per request")

    created_ids = []
    errors = []

    for index, question in enumerate(questions):
        try:
            # Generate embedding
            combined_text = embedding_service.combine_text_for_embedding(
                question=question.question,
                sql=question.sql
            )

            embedding = None
            try:
                embedding = await embedding_service.generate_embedding(combined_text)
            except Exception as e:
                logger.warning(f"Failed to generate embedding for question at index {index}: {e}")

            db_question = SemanticQuestionBank(**question.model_dump(), embedding=embedding)
            db.add(db_question)
            await db.flush()
            created_ids.append(db_question.question_id)
        except Exception as e:
            errors.append({"index": index, "error": str(e)})

    await db.commit()

    return BulkOperationResponse(
        success_count=len(created_ids),
        failed_count=len(errors),
        created_ids=created_ids,
        errors=errors if errors else None
    )


@router.delete("/question-bank/bulk", response_model=BulkOperationResponse)
async def bulk_delete_questions(
    request: BulkDeleteRequest,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Bulk delete semantic questions by IDs (max 100 IDs per request)

    Returns success/failure counts and details for each operation.
    """
    deleted_ids = []
    errors = []

    for question_id in request.ids:
        result = await db.execute(
            select(SemanticQuestionBank).where(SemanticQuestionBank.question_id == question_id)
        )
        question = result.scalar_one_or_none()

        if not question:
            errors.append({"id": question_id, "error": "Question not found"})
            continue

        await db.delete(question)
        deleted_ids.append(question_id)

    await db.commit()

    return BulkOperationResponse(
        success_count=len(deleted_ids),
        failed_count=len(errors),
        deleted_ids=deleted_ids,
        errors=errors if errors else None
    )



@router.get("/question-bank/{question_id}", response_model=SemanticQuestionBankResponse)
async def get_semantic_question(
    question_id: int,
    db: AsyncSession = Depends(get_db)
) -> SemanticQuestionBankResponse:
    """Get a specific semantic question by ID"""
    result = await db.execute(
        select(SemanticQuestionBank).where(SemanticQuestionBank.question_id == question_id)
    )
    question = result.scalar_one_or_none()
    if not question:
        raise HTTPException(status_code=404, detail=f"Question with ID {question_id} not found")
    return SemanticQuestionBankResponse.model_validate(question)


@router.put("/question-bank/{question_id}", response_model=SemanticQuestionBankResponse)
async def update_semantic_question(
    question_id: int,
    question_update: SemanticQuestionBankUpdate,
    regenerate_embedding: bool = Query(True),
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> SemanticQuestionBankResponse:
    """Update a semantic question and optionally regenerate embedding"""
    result = await db.execute(
        select(SemanticQuestionBank).where(SemanticQuestionBank.question_id == question_id)
    )
    question = result.scalar_one_or_none()
    if not question:
        raise HTTPException(status_code=404, detail=f"Question with ID {question_id} not found")

    update_data = question_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(question, field, value)

    if regenerate_embedding:
        combined_text = embedding_service.combine_text_for_embedding(
            question=question.question,
            sql=question.sql
        )
        try:
            question.embedding = await embedding_service.generate_embedding(combined_text)
        except Exception as e:
            logger.warning(f"Failed to regenerate embedding: {e}")

    await db.commit()
    await db.refresh(question)
    return SemanticQuestionBankResponse.model_validate(question)


@router.delete("/question-bank/{question_id}", response_model=MessageResponse)
async def delete_semantic_question(
    question_id: int,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> MessageResponse:
    """Delete a semantic question"""
    result = await db.execute(
        select(SemanticQuestionBank).where(SemanticQuestionBank.question_id == question_id)
    )
    question = result.scalar_one_or_none()
    if not question:
        raise HTTPException(status_code=404, detail=f"Question with ID {question_id} not found")
    await db.delete(question)
    await db.commit()
    return MessageResponse(message=f"Question with ID {question_id} deleted successfully")
