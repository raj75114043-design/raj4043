import logging
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query

from fastapi import Security, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import secrets

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text, func
from sqlalchemy.orm import selectinload
import numpy as np

from app.db.database import get_db, async_engine, Base
from app.core.config import settings
from app.models.semantic_models import (
    SemanticKPI,
    SemanticQuestionBank,
    SemanticRCA,
    SemanticSimulation,
    SemanticKeyword,
    SemanticEscalation
)
from app.schemas.semantic_schemas import (
    TableInitResponse,
    ResetTablesResponse,
    MessageResponse,
)
from app.services.embedding_service import embedding_service


security = HTTPBasic()
logger = logging.getLogger(__name__)
router = APIRouter(prefix="/data", tags=["Data Table Creation [Dev Only]"])


DEV_PASSOWRD = "pwc_macro_team"

def verify_dev_password(credentials: HTTPBasicCredentials = Depends(security)):
    correct = secrets.compare_digest(credentials.password, "pwc_macro_team")
    if not correct:
        raise HTTPException(status_code=401, headers={"WWW-Authenticate": "Basic"})




@router.post("/init-tables", response_model=TableInitResponse, status_code=201)
async def initialize_semantic_tables(
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> TableInitResponse:
    """
    Initialize semantic tables in the pwc_semantic_information_schema

    Creates the schema if it doesn't exist and creates all semantic tables
    with vector embedding columns.

    Returns:
        TableInitResponse with status and created tables
    """
    schema_name = settings.db_schema
    tables_created = []

    try:
        
        # Create all tables defined in semantic models
        async with async_engine.begin() as conn:
            # Create tables for semantic models only
            await conn.run_sync(
                Base.metadata.create_all,
                tables=[
                    SemanticKPI.__table__,
                    SemanticQuestionBank.__table__,
                    SemanticRCA.__table__,
                    SemanticSimulation.__table__,
                    SemanticKeyword.__table__,
                    SemanticEscalation.__table__
                ]
            )

        tables_created = [
            "semantic_kpi",
            "semantic_question_bank",
            "semantic_rca",
            "semantic_simulation",
            "semantic_keywords"
        ]

        return TableInitResponse(
            success=True,
            message=f"Semantic tables initialized successfully in schema '{schema_name}'",
            tables_created=tables_created,
            schema_name=schema_name
        )

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to initialize tables: {str(e)}"
        )


@router.get("/schema-info")
async def get_schema_info(
    db: AsyncSession = Depends(get_db)
) -> dict:
    """
    Get information about the semantic schema and tables

    Returns:
        Schema information including table names and record counts
    """
    schema_name = settings.db_schema

    try:
        # Check if schema exists
        result = await db.execute(
            text(f"""
                SELECT schema_name
                FROM information_schema.schemata
                WHERE schema_name = :schema
            """),
            {"schema": schema_name}
        )
        schema_exists = result.scalar() is not None

        if not schema_exists:
            return {
                "schema_name": schema_name,
                "exists": False,
                "tables": [],
                "message": f"Schema '{schema_name}' does not exist. Call /init-tables to create it."
            }

        # Get table information
        result = await db.execute(
            text(f"""
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = :schema
                ORDER BY table_name
            """),
            {"schema": schema_name}
        )
        tables = [row[0] for row in result.fetchall()]

        # Get record counts for each table
        table_counts = {}
        for table in tables:
            count_result = await db.execute(
                text(f'SELECT COUNT(*) FROM {schema_name}."{table}"')
            )
            table_counts[table] = count_result.scalar()

        return {
            "schema_name": schema_name,
            "exists": True,
            "tables": tables,
            "table_counts": table_counts,
            "embedding_api_configured": bool(settings.embed_api_url)
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to get schema info: {str(e)}"
        )


@router.delete("/reset-all-tables", response_model=ResetTablesResponse)
async def reset_all_tables(
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password),
):
    """
    Delete ALL rows from every semantic table and the table_schema_map.
    Protected behind dev password to prevent accidental use.
    """
    schema_name = settings.db_schema

    tables_to_clear = [
        "semantic_kpi",
        "semantic_question_bank",
        "semantic_rca",
        "semantic_simulation",
        "semantic_keywords",
        "table_schema_map",
        "semantic_escalation"
    ]

    rows_deleted = {}
    tables_cleared = []

    try:
        for table_name in tables_to_clear:
            count_result = await db.execute(
                text(f'SELECT COUNT(*) FROM {schema_name}."{table_name}"')
            )
            count = count_result.scalar()
            await db.execute(
                text(f'TRUNCATE TABLE {schema_name}."{table_name}" RESTART IDENTITY CASCADE')
            )
            rows_deleted[table_name] = count
            tables_cleared.append(table_name)

        await db.commit()

        return ResetTablesResponse(
            success=True,
            message=f"All {len(tables_cleared)} tables cleared successfully in schema '{schema_name}'",
            tables_cleared=tables_cleared,
            rows_deleted=rows_deleted,
        )

    except Exception as e:
        await db.rollback()
        logger.error(f"Failed to reset tables: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to reset tables: {str(e)}"
        )
