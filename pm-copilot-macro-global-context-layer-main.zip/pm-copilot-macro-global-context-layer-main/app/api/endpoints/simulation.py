"""
Simulation CRUD endpoints for PM Copilot Global Context Layer
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import logging
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query


from fastapi import Security, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import secrets


from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text, func
from sqlalchemy.orm import selectinload
import numpy as np

from app.db.database import get_db, async_engine, Base
from app.core.config import settings
from app.models.semantic_models import (
    SemanticSimulation,

)
from app.schemas.semantic_schemas import (
    SemanticSimulationCreate,
    SemanticSimulationUpdate,
    SemanticSimulationResponse,
    MessageResponse,
    BulkDeleteRequest,
    BulkOperationResponse,
)
from app.services.embedding_service import embedding_service


security = HTTPBasic()
logger = logging.getLogger(__name__)
router = APIRouter(prefix="/simulation", tags=["Simulation Management [Dev Only]"])


DEV_PASSOWRD = "pwc_macro_team"

def verify_dev_password(credentials: HTTPBasicCredentials = Depends(security)):
    correct = secrets.compare_digest(credentials.password, "pwc_macro_team")
    if not correct:
        raise HTTPException(status_code=401, headers={"WWW-Authenticate": "Basic"})



@router.post("/simulation", response_model=SemanticSimulationResponse, status_code=201)
async def create_semantic_simulation(
    simulation: SemanticSimulationCreate,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> SemanticSimulationResponse:
    """Create a new semantic simulation with auto-generated embedding"""
    combined_text = embedding_service.combine_text_for_embedding(
        scenario=simulation.scenario,
        data_phase_steps=simulation.data_phase_steps,
        data_phase_questions=simulation.data_phase_questions,
        calculation_phase_steps=simulation.calculation_phase_steps,
        simulator_phase_steps=simulation.simulator_phase_steps,
        simulation_methodology=simulation.simulation_methodology
    )

    embedding = None
    try:
        embedding = await embedding_service.generate_embedding(combined_text)
    except Exception as e:
        logger.warning(f"Failed to generate embedding: {e}")

    db_simulation = SemanticSimulation(**simulation.model_dump(), embedding=embedding)
    db.add(db_simulation)
    await db.commit()
    await db.refresh(db_simulation)
    return SemanticSimulationResponse.model_validate(db_simulation)


@router.get("/simulation", response_model=List[SemanticSimulationResponse])
async def list_semantic_simulations(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: AsyncSession = Depends(get_db)
) -> List[SemanticSimulationResponse]:
    """List all semantic simulations with pagination"""
    result = await db.execute(
        select(SemanticSimulation).offset(skip).limit(limit).order_by(SemanticSimulation.scenario_id)
    )
    simulations = result.scalars().all()
    return [SemanticSimulationResponse.model_validate(s) for s in simulations]


# --- Fixed: bulk routes MUST be defined before /{scenario_id} routes ---

@router.post("/simulation/bulk", response_model=BulkOperationResponse, status_code=201)
async def bulk_create_simulations(
    simulations: List[SemanticSimulationCreate],
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Bulk create semantic simulations with auto-generated embeddings (max 100 items per request)

    Returns success/failure counts and details for each operation.
    """
    if len(simulations) > 100:
        raise HTTPException(status_code=400, detail="Maximum 100 items per request")

    created_ids = []
    errors = []

    for index, simulation in enumerate(simulations):
        try:
            # Generate embedding
            combined_text = embedding_service.combine_text_for_embedding(
                scenario=simulation.scenario,
                data_phase_steps=simulation.data_phase_steps,
                data_phase_questions=simulation.data_phase_questions,
                calculation_phase_steps=simulation.calculation_phase_steps,
                simulator_phase_steps=simulation.simulator_phase_steps,
                simulation_methodology=simulation.simulation_methodology
            )

            embedding = None
            try:
                embedding = await embedding_service.generate_embedding(combined_text)
            except Exception as e:
                logger.warning(f"Failed to generate embedding for simulation at index {index}: {e}")

            db_simulation = SemanticSimulation(**simulation.model_dump(), embedding=embedding)
            db.add(db_simulation)
            await db.flush()
            created_ids.append(db_simulation.scenario_id)
        except Exception as e:
            errors.append({"index": index, "error": str(e)})

    await db.commit()

    return BulkOperationResponse(
        success_count=len(created_ids),
        failed_count=len(errors),
        created_ids=created_ids,
        errors=errors if errors else None
    )


@router.delete("/simulation/bulk", response_model=BulkOperationResponse)
async def bulk_delete_simulations(
    request: BulkDeleteRequest,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Bulk delete semantic simulations by IDs (max 100 IDs per request)

    Returns success/failure counts and details for each operation.
    """
    deleted_ids = []
    errors = []

    for scenario_id in request.ids:
        result = await db.execute(
            select(SemanticSimulation).where(SemanticSimulation.scenario_id == scenario_id)
        )
        simulation = result.scalar_one_or_none()

        if not simulation:
            errors.append({"id": scenario_id, "error": "Simulation not found"})
            continue

        await db.delete(simulation)
        deleted_ids.append(scenario_id)

    await db.commit()

    return BulkOperationResponse(
        success_count=len(deleted_ids),
        failed_count=len(errors),
        deleted_ids=deleted_ids,
        errors=errors if errors else None
    )


# --- Parameterized /{scenario_id} routes below (must come after /bulk) ---

@router.get("/simulation/{scenario_id}", response_model=SemanticSimulationResponse)
async def get_semantic_simulation(
    scenario_id: int,
    db: AsyncSession = Depends(get_db)
) -> SemanticSimulationResponse:
    """Get a specific semantic simulation by ID"""
    result = await db.execute(
        select(SemanticSimulation).where(SemanticSimulation.scenario_id == scenario_id)
    )
    simulation = result.scalar_one_or_none()
    if not simulation:
        raise HTTPException(status_code=404, detail=f"Simulation with ID {scenario_id} not found")
    return SemanticSimulationResponse.model_validate(simulation)


@router.put("/simulation/{scenario_id}", response_model=SemanticSimulationResponse)
async def update_semantic_simulation(
    scenario_id: int,
    simulation_update: SemanticSimulationUpdate,
    regenerate_embedding: bool = Query(True),
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> SemanticSimulationResponse:
    """Update a semantic simulation and optionally regenerate embedding"""
    result = await db.execute(
        select(SemanticSimulation).where(SemanticSimulation.scenario_id == scenario_id)
    )
    simulation = result.scalar_one_or_none()
    if not simulation:
        raise HTTPException(status_code=404, detail=f"Simulation with ID {scenario_id} not found")

    update_data = simulation_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(simulation, field, value)

    if regenerate_embedding:
        combined_text = embedding_service.combine_text_for_embedding(
            scenario=simulation.scenario,
            data_phase_steps=simulation.data_phase_steps,
            data_phase_questions=simulation.data_phase_questions,
            calculation_phase_steps=simulation.calculation_phase_steps,
            simulator_phase_steps=simulation.simulator_phase_steps,
            simulation_methodology=simulation.simulation_methodology
        )
        try:
            simulation.embedding = await embedding_service.generate_embedding(combined_text)
        except Exception as e:
            logger.warning(f"Failed to regenerate embedding: {e}")

    await db.commit()
    await db.refresh(simulation)
    return SemanticSimulationResponse.model_validate(simulation)


@router.delete("/simulation/{scenario_id}", response_model=MessageResponse)
async def delete_semantic_simulation(
    scenario_id: int,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> MessageResponse:
    """Delete a semantic simulation"""
    result = await db.execute(
        select(SemanticSimulation).where(SemanticSimulation.scenario_id == scenario_id)
    )
    simulation = result.scalar_one_or_none()
    if not simulation:
        raise HTTPException(status_code=404, detail=f"Simulation with ID {scenario_id} not found")
    await db.delete(simulation)
    await db.commit()
    return MessageResponse(message=f"Simulation with ID {scenario_id} deleted successfully")
