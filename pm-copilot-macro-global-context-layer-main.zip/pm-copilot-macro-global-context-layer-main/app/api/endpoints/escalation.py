"""
Escalation Management  CRUD endpoints for PM Copilot Global Context Layer
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import logging
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query


from fastapi import Security, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import secrets


from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text, func
from sqlalchemy.orm import selectinload
import numpy as np

from app.db.database import get_db, async_engine, Base
from app.core.config import settings
from app.models.semantic_models import (
    SemanticEscalation,
)
from app.schemas.semantic_schemas import (
    SemanticEscalationCreate,
    SemanticEscalationUpdate,
    SemanticEscalationResponse,
    MessageResponse,
    BulkDeleteRequest,
    BulkOperationResponse,
)
from app.services.embedding_service import embedding_service


security = HTTPBasic()
logger = logging.getLogger(__name__)
router = APIRouter(prefix="/escalation", tags=["Escalation Management [Dev Only]"])


DEV_PASSOWRD = "pwc_macro_team"

def verify_dev_password(credentials: HTTPBasicCredentials = Depends(security)):
    correct = secrets.compare_digest(credentials.password, "pwc_macro_team")
    if not correct:
        raise HTTPException(status_code=401, headers={"WWW-Authenticate": "Basic"})



@router.post("/escalation", response_model=SemanticEscalationResponse, status_code=201)
async def create_escalation(
    escalation: SemanticEscalationCreate,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> SemanticEscalationResponse:
    """Create a new semantic escalation with auto-generated embedding"""
    # Combine escalation fields for embedding
    combined_text = " ".join([
        escalation.escalation_type or "",
        " ".join(escalation.escalation_description) if escalation.escalation_description else ""
    ])

    embedding = None
    try:
        embedding = await embedding_service.generate_embedding(combined_text)
    except Exception as e:
        logger.warning(f"Failed to generate embedding: {e}")

    db_escalation = SemanticEscalation(**escalation.model_dump(), embedding=embedding)
    db.add(db_escalation)
    await db.commit()
    await db.refresh(db_escalation)
    return SemanticEscalationResponse.model_validate(db_escalation)


@router.get("/escalation", response_model=List[SemanticEscalationResponse])
async def list_escalations(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: AsyncSession = Depends(get_db)
) -> List[SemanticEscalationResponse]:
    """List all semantic escalations with pagination"""
    result = await db.execute(
        select(SemanticEscalation).offset(skip).limit(limit).order_by(SemanticEscalation.scenario_id)
    )
    escalations = result.scalars().all()
    return [SemanticEscalationResponse.model_validate(e) for e in escalations]


# --- Fixed: bulk routes MUST be defined before /{scenario_id} routes ---

@router.post("/escalation/bulk", response_model=BulkOperationResponse, status_code=201)
async def bulk_create_escalations(
    escalations: List[SemanticEscalationCreate],
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Bulk create semantic escalations with auto-generated embeddings (max 100 items per request)

    Returns success/failure counts and details for each operation.
    """
    if len(escalations) > 100:
        raise HTTPException(status_code=400, detail="Maximum 100 items per request")

    created_ids = []
    errors = []

    for index, escalation in enumerate(escalations):
        try:
            # Generate embedding from escalation fields
            combined_text = " ".join([
                escalation.escalation_type or "",
                " ".join(escalation.escalation_description) if escalation.escalation_description else ""
            ])

            embedding = None
            try:
                embedding = await embedding_service.generate_embedding(combined_text)
            except Exception as e:
                logger.warning(f"Failed to generate embedding for escalation at index {index}: {e}")

            db_escalation = SemanticEscalation(**escalation.model_dump(), embedding=embedding)
            db.add(db_escalation)
            await db.flush()
            created_ids.append(db_escalation.scenario_id)
        except Exception as e:
            errors.append({"index": index, "error": str(e)})

    await db.commit()

    return BulkOperationResponse(
        success_count=len(created_ids),
        failed_count=len(errors),
        created_ids=created_ids,
        errors=errors if errors else None
    )


@router.delete("/escalation/bulk", response_model=BulkOperationResponse)
async def bulk_delete_escalations(
    request: BulkDeleteRequest,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Bulk delete semantic escalations by IDs (max 100 IDs per request)

    Returns success/failure counts and details for each operation.
    """
    deleted_ids = []
    errors = []

    for scenario_id in request.ids:
        result = await db.execute(
            select(SemanticEscalation).where(SemanticEscalation.scenario_id == scenario_id)
        )
        escalation = result.scalar_one_or_none()

        if not escalation:
            errors.append({"id": scenario_id, "error": "Escalation not found"})
            continue

        await db.delete(escalation)
        deleted_ids.append(scenario_id)

    await db.commit()

    return BulkOperationResponse(
        success_count=len(deleted_ids),
        failed_count=len(errors),
        deleted_ids=deleted_ids,
        errors=errors if errors else None
    )


# --- Parameterized /{scenario_id} routes below (must come after /bulk) ---

@router.get("/escalation/{scenario_id}", response_model=SemanticEscalationResponse)
async def get_escalation(
    scenario_id: int,
    db: AsyncSession = Depends(get_db)
) -> SemanticEscalationResponse:
    """Get a specific semantic escalation by ID"""
    result = await db.execute(
        select(SemanticEscalation).where(SemanticEscalation.scenario_id == scenario_id)
    )
    escalation = result.scalar_one_or_none()
    if not escalation:
        raise HTTPException(status_code=404, detail=f"Escalation with ID {scenario_id} not found")
    return SemanticEscalationResponse.model_validate(escalation)


@router.put("/escalation/{scenario_id}", response_model=SemanticEscalationResponse)
async def update_escalation(
    scenario_id: int,
    escalation_update: SemanticEscalationUpdate,
    regenerate_embedding: bool = Query(True),
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> SemanticEscalationResponse:
    """Update a semantic escalation and optionally regenerate embedding"""
    result = await db.execute(
        select(SemanticEscalation).where(SemanticEscalation.scenario_id == scenario_id)
    )
    escalation = result.scalar_one_or_none()
    if not escalation:
        raise HTTPException(status_code=404, detail=f"Escalation with ID {scenario_id} not found")

    update_data = escalation_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(escalation, field, value)

    if regenerate_embedding:
        combined_text = " ".join([
            escalation.escalation_type or "",
            " ".join(escalation.escalation_description) if escalation.escalation_description else ""
        ])
        try:
            escalation.embedding = await embedding_service.generate_embedding(combined_text)
        except Exception as e:
            logger.warning(f"Failed to regenerate embedding: {e}")

    await db.commit()
    await db.refresh(escalation)
    return SemanticEscalationResponse.model_validate(escalation)


@router.delete("/escalation/{scenario_id}", response_model=MessageResponse)
async def delete_escalation(
    scenario_id: int,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> MessageResponse:
    """Delete a semantic escalation"""
    result = await db.execute(
        select(SemanticEscalation).where(SemanticEscalation.scenario_id == scenario_id)
    )
    escalation = result.scalar_one_or_none()
    if not escalation:
        raise HTTPException(status_code=404, detail=f"Escalation with ID {scenario_id} not found")
    await db.delete(escalation)
    await db.commit()
    return MessageResponse(message=f"Escalation with ID {scenario_id} deleted successfully")
