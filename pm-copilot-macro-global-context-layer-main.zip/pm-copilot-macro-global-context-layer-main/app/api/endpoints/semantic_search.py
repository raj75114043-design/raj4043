"""
Semantic Search endpoints with vector embeddings for PM Copilot Global Context Layer
Schema: pwc_semantic_information_schema
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import logging
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query

logger = logging.getLogger(__name__)
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text, func
from sqlalchemy.orm import selectinload
import numpy as np


from fastapi import Security, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import secrets

from app.db.database import get_db, async_engine, Base
from app.core.config import settings
from app.models.semantic_models import (
    SemanticKPI,
    SemanticQuestionBank,
    SemanticRCA,
    SemanticSimulation,
    SemanticKeyword,
)
from app.schemas.semantic_schemas import (
    SemanticSearchRequest,
    SemanticSearchResult,
    SemanticSearchResponse,
)
from app.schemas.semantic_schemas import MessageResponse
from app.services.embedding_service import embedding_service

router = APIRouter(prefix="/semantic", tags=["Semantic Search & Vector Operations"])

security = HTTPBasic()

DEV_PASSOWRD = "pwc_macro_team"

def verify_dev_password(credentials: HTTPBasicCredentials = Depends(security)):
    correct = secrets.compare_digest(credentials.password, "pwc_macro_team")
    if not correct:
        raise HTTPException(status_code=401, headers={"WWW-Authenticate": "Basic"})



def cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
    """Calculate cosine similarity between two vectors"""
    if not vec1 or not vec2:
        return 0.0
    a = np.array(vec1)
    b = np.array(vec2)
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))


@router.post("/search", response_model=SemanticSearchResponse)
async def semantic_search(
    request: SemanticSearchRequest,
    db: AsyncSession = Depends(get_db)
) -> SemanticSearchResponse:
    """
    Perform semantic search across all or specific tables

    Uses cosine similarity to find the most relevant records based on
    vector embeddings.

    Args:
        request: Search request with query, optional table filter, and top_k

    Returns:
        Ranked search results with similarity scores
    """
    # Generate embedding for the query
    try:
        query_embedding = await embedding_service.generate_embedding(request.query)
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate query embedding: {str(e)}"
        )

    if not query_embedding:
        raise HTTPException(
            status_code=400,
            detail="Could not generate embedding for the query"
        )

    results: List[SemanticSearchResult] = []
    tables_to_search = []

    # Determine which tables to search
    if request.table:
        table_mapping = {
            "kpi": SemanticKPI,
            "question_bank": SemanticQuestionBank,
            "rca": SemanticRCA,
            "simulation": SemanticSimulation
        }
        if request.table not in table_mapping:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid table name. Must be one of: {list(table_mapping.keys())}"
            )
        tables_to_search = [(request.table, table_mapping[request.table])]
    else:
        tables_to_search = [
            ("kpi", SemanticKPI),
            ("question_bank", SemanticQuestionBank),
            ("rca", SemanticRCA),
            ("simulation", SemanticSimulation)
        ]

    # Search each table
    for table_name, model_class in tables_to_search:
        query_result = await db.execute(select(model_class))
        records = query_result.scalars().all()

        for record in records:
            if record.embedding:
                similarity = cosine_similarity(query_embedding, record.embedding)

                # Build content dict excluding embedding
                content = {}
                for key, value in record.__dict__.items():
                    if not key.startswith("_") and key != "embedding":
                        if hasattr(value, "value"):  # Handle enums
                            content[key] = value.value
                        elif isinstance(value, list):
                            content[key] = value
                        else:
                            content[key] = str(value) if value is not None else None

                # Get primary key value
                if hasattr(record, "kpi_id"):
                    record_id = record.kpi_id
                elif hasattr(record, "question_id"):
                    record_id = record.question_id
                elif hasattr(record, "problem_id"):
                    record_id = record.problem_id
                elif hasattr(record, "scenario_id"):
                    record_id = record.scenario_id
                else:
                    record_id = 0

                results.append(SemanticSearchResult(
                    table=table_name,
                    id=record_id,
                    content=content,
                    similarity_score=round(similarity, 4)
                ))

    # Sort by similarity and limit to top_k
    results.sort(key=lambda x: x.similarity_score, reverse=True)
    results = results[:request.top_k]

    return SemanticSearchResponse(
        query=request.query,
        total_results=len(results),
        results=results
    )


@router.post("/regenerate-embeddings/{table_name}")
async def regenerate_embeddings(
    table_name: str,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> dict:
    """
    Regenerate embeddings for all records in a specific table

    Args:
        table_name: Table name (kpi, question_bank, rca, simulation)

    Returns:
        Status with count of updated records
    """
    table_mapping = {
        "kpi": SemanticKPI,
        "question_bank": SemanticQuestionBank,
        "rca": SemanticRCA,
        "simulation": SemanticSimulation
    }

    if table_name not in table_mapping:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid table name. Must be one of: {list(table_mapping.keys())}"
        )

    model_class = table_mapping[table_name]
    result = await db.execute(select(model_class))
    records = result.scalars().all()

    updated_count = 0
    failed_count = 0

    for record in records:
        try:
            if table_name == "kpi":
                combined_text = embedding_service.combine_text_for_embedding(
                    name=record.kpi_name,
                    description=record.description,
                    formula=record.formula,
                    logic=record.logic
                )
            elif table_name == "question_bank":
                combined_text = embedding_service.combine_text_for_embedding(
                    question=record.question,
                    sql=record.sql
                )
            elif table_name == "rca":
                combined_text = embedding_service.combine_text_for_embedding(
                    question=record.rca_question,
                    type=record.type_of_rca_question.value,
                    root_causes=record.root_causes,
                    relevant_kpis=record.relevant_kpis
                )
            elif table_name == "simulation":
                combined_text = embedding_service.combine_text_for_embedding(
                    scenario=record.scenario,
                    simulation_methodology=record.simulation_methodology
                )

            record.embedding = await embedding_service.generate_embedding(combined_text)
            updated_count += 1
        except Exception as e:
            logger.warning(f"Failed to regenerate embedding for record: {e}")
            failed_count += 1

    await db.commit()

    return {
        "table": table_name,
        "total_records": len(records),
        "updated": updated_count,
        "failed": failed_count,
        "message": f"Embeddings regenerated for {updated_count} records"
    }
