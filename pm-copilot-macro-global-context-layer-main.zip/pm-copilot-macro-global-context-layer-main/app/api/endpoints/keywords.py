"""
Keywords CRUD endpoints for PM Copilot Global Context Layer
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""
import logging
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, Body
from fastapi import Security, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import secrets

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text, func
from sqlalchemy.orm import selectinload
import numpy as np

from app.db.database import get_db, async_engine, Base
from app.core.config import settings
from app.models.semantic_models import (
    SemanticKeyword,
)
from app.schemas.semantic_schemas import (
    SemanticKeywordCreate,
    SemanticKeywordUpdate,
    SemanticKeywordResponse,
    MessageResponse,
    BulkDeleteRequest,
    BulkOperationResponse,
)
from app.services.embedding_service import embedding_service

logger = logging.getLogger(__name__)
security = HTTPBasic()
router = APIRouter(prefix="/keywords", tags=["Keywords Management [Dev Only]"])

DEV_PASSOWRD = "pwc_macro_team"

def verify_dev_password(credentials: HTTPBasicCredentials = Depends(security)):
    correct = secrets.compare_digest(credentials.password, "pwc_macro_team")
    if not correct:
        raise HTTPException(status_code=401, headers={"WWW-Authenticate": "Basic"})



@router.post("/keywords", response_model=SemanticKeywordResponse, status_code=201)
async def create_keyword(
    keyword: SemanticKeywordCreate,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> SemanticKeywordResponse:
    """Create a new keyword"""
    db_keyword = SemanticKeyword(**keyword.model_dump())
    db.add(db_keyword)
    await db.commit()
    await db.refresh(db_keyword)
    return SemanticKeywordResponse.model_validate(db_keyword)


@router.get("/keywords", response_model=List[SemanticKeywordResponse])
async def list_keywords(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: AsyncSession = Depends(get_db)
) -> List[SemanticKeywordResponse]:
    """List all keywords with pagination"""
    result = await db.execute(
        select(SemanticKeyword).offset(skip).limit(limit).order_by(SemanticKeyword.keyword_id)
    )
    keywords = result.scalars().all()
    return [SemanticKeywordResponse.model_validate(k) for k in keywords]


# --- Fixed: search & bulk routes MUST be defined before /{keyword_id} routes ---

@router.get("/keywords/search/by-name", response_model=List[SemanticKeywordResponse])
async def search_keyword_by_name(
    name: str = Query(..., min_length=1, description="Keyword name to search"),
    db: AsyncSession = Depends(get_db)
) -> List[SemanticKeywordResponse]:
    """Search keywords by name (partial match)"""
    result = await db.execute(
        select(SemanticKeyword).where(
            SemanticKeyword.keyword_name.ilike(f"%{name}%")
        ).order_by(SemanticKeyword.keyword_id)
    )
    keywords = result.scalars().all()
    return [SemanticKeywordResponse.model_validate(k) for k in keywords]


@router.get("/keywords/search/by-synonym", response_model=List[SemanticKeywordResponse])
async def search_keyword_by_synonym(
    synonym: str = Query(..., min_length=1, description="Synonym to search"),
    db: AsyncSession = Depends(get_db)
) -> List[SemanticKeywordResponse]:
    """Search keywords by synonym (partial match)"""
    result = await db.execute(
        select(SemanticKeyword).where(
            SemanticKeyword.synonyms.ilike(f"%{synonym}%")
        ).order_by(SemanticKeyword.keyword_id)
    )
    keywords = result.scalars().all()
    return [SemanticKeywordResponse.model_validate(k) for k in keywords]


@router.post("/keywords/bulk", response_model=BulkOperationResponse, status_code=201)
async def bulk_create_keywords(
    keywords: List[SemanticKeywordCreate] = Body(..., description="List of keywords to create (max 100)"),
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Bulk create keywords (max 100 items per request)

    Returns success/failure counts and details for each operation.
    """
    if len(keywords) > 100:
        raise HTTPException(status_code=400, detail="Maximum 100 items per request")

    created_ids = []
    errors = []

    for index, keyword in enumerate(keywords):
        try:
            db_keyword = SemanticKeyword(**keyword.model_dump())
            db.add(db_keyword)
            await db.flush()
            created_ids.append(db_keyword.keyword_id)
        except Exception as e:
            errors.append({"index": index, "error": str(e)})

    await db.commit()

    return BulkOperationResponse(
        success_count=len(created_ids),
        failed_count=len(errors),
        created_ids=created_ids,
        errors=errors if errors else None
    )


@router.delete("/keywords/bulk", response_model=BulkOperationResponse)
async def bulk_delete_keywords(
    request: BulkDeleteRequest,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Bulk delete keywords by IDs (max 100 IDs per request)

    Returns success/failure counts and details for each operation.
    """
    deleted_ids = []
    errors = []

    for keyword_id in request.ids:
        result = await db.execute(
            select(SemanticKeyword).where(SemanticKeyword.keyword_id == keyword_id)
        )
        keyword = result.scalar_one_or_none()

        if not keyword:
            errors.append({"id": keyword_id, "error": "Keyword not found"})
            continue

        await db.delete(keyword)
        deleted_ids.append(keyword_id)

    await db.commit()

    return BulkOperationResponse(
        success_count=len(deleted_ids),
        failed_count=len(errors),
        deleted_ids=deleted_ids,
        errors=errors if errors else None
    )


# --- Parameterized /{keyword_id} routes below (must come after /search and /bulk) ---

@router.get("/keywords/{keyword_id}", response_model=SemanticKeywordResponse)
async def get_keyword(
    keyword_id: int,
    db: AsyncSession = Depends(get_db)
) -> SemanticKeywordResponse:
    """Get a specific keyword by ID"""
    result = await db.execute(
        select(SemanticKeyword).where(SemanticKeyword.keyword_id == keyword_id)
    )
    keyword = result.scalar_one_or_none()
    if not keyword:
        raise HTTPException(status_code=404, detail=f"Keyword with ID {keyword_id} not found")
    return SemanticKeywordResponse.model_validate(keyword)


@router.put("/keywords/{keyword_id}", response_model=SemanticKeywordResponse)
async def update_keyword(
    keyword_id: int,
    keyword_update: SemanticKeywordUpdate,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> SemanticKeywordResponse:
    """Update a keyword"""
    result = await db.execute(
        select(SemanticKeyword).where(SemanticKeyword.keyword_id == keyword_id)
    )
    keyword = result.scalar_one_or_none()
    if not keyword:
        raise HTTPException(status_code=404, detail=f"Keyword with ID {keyword_id} not found")

    update_data = keyword_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(keyword, field, value)

    await db.commit()
    await db.refresh(keyword)
    return SemanticKeywordResponse.model_validate(keyword)


@router.delete("/keywords/{keyword_id}", response_model=MessageResponse)
async def delete_keyword(
    keyword_id: int,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> MessageResponse:
    """Delete a keyword"""
    result = await db.execute(
        select(SemanticKeyword).where(SemanticKeyword.keyword_id == keyword_id)
    )
    keyword = result.scalar_one_or_none()
    if not keyword:
        raise HTTPException(status_code=404, detail=f"Keyword with ID {keyword_id} not found")
    await db.delete(keyword)
    await db.commit()
    return MessageResponse(message=f"Keyword with ID {keyword_id} deleted successfully")
