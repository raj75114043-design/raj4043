"""
RCA CRUD endpoints for PM Copilot Global Context Layer
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""
import logging
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text, func
from sqlalchemy.orm import selectinload
import numpy as np

from fastapi import Security, HTTPException, status
from fastapi.security import HTTPBasic, HTTPBasicCredentials
import secrets


from app.db.database import get_db, async_engine, Base
from app.core.config import settings
from app.models.semantic_models import (
    SemanticRCA,
)
from app.schemas.semantic_schemas import (
    SemanticRCACreate,
    SemanticRCAUpdate,
    SemanticRCAResponse,
    MessageResponse,
    BulkDeleteRequest,
    BulkOperationResponse,
)
from app.services.embedding_service import embedding_service


security = HTTPBasic()

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/rca", tags=["RCA Management [Dev Only]"])

DEV_PASSOWRD = "pwc_macro_team"

def verify_dev_password(credentials: HTTPBasicCredentials = Depends(security)):
    correct = secrets.compare_digest(credentials.password, "pwc_macro_team")
    if not correct:
        raise HTTPException(status_code=401, headers={"WWW-Authenticate": "Basic"})



@router.post("/rca", response_model=SemanticRCAResponse, status_code=201)
async def create_semantic_rca(
    rca: SemanticRCACreate,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> SemanticRCAResponse:
    """Create a new semantic RCA with auto-generated embedding"""
    combined_text = embedding_service.combine_text_for_embedding(
        question=rca.rca_question,
        type=rca.type_of_rca_question.value,
        root_causes=rca.root_causes,
        relevant_kpis=rca.relevant_kpis,
        recommendation_area=rca.recommendation_area
    )

    embedding = None
    try:
        embedding = await embedding_service.generate_embedding(combined_text)
    except Exception as e:
        logger.warning(f"Failed to generate embedding: {e}")

    db_rca = SemanticRCA(**rca.model_dump(), embedding=embedding)
    db.add(db_rca)
    await db.commit()
    await db.refresh(db_rca)
    return SemanticRCAResponse.model_validate(db_rca)


@router.get("/rca", response_model=List[SemanticRCAResponse])
async def list_semantic_rcas(
    skip: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=1000),
    db: AsyncSession = Depends(get_db)
) -> List[SemanticRCAResponse]:
    """List all semantic RCAs with pagination"""
    result = await db.execute(
        select(SemanticRCA).offset(skip).limit(limit).order_by(SemanticRCA.problem_id)
    )
    rcas = result.scalars().all()
    return [SemanticRCAResponse.model_validate(r) for r in rcas]




@router.post("/rca/bulk", response_model=BulkOperationResponse, status_code=201)
async def bulk_create_rcas(
    rcas: List[SemanticRCACreate],
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Bulk create semantic RCAs with auto-generated embeddings (max 100 items per request)

    Returns success/failure counts and details for each operation.
    """
    if len(rcas) > 100:
        raise HTTPException(status_code=400, detail="Maximum 100 items per request")

    created_ids = []
    errors = []

    for index, rca in enumerate(rcas):
        try:
            # Generate embedding
            combined_text = embedding_service.combine_text_for_embedding(
                question=rca.rca_question,
                type=rca.type_of_rca_question.value,
                root_causes=rca.root_causes,
                relevant_kpis=rca.relevant_kpis,
                recommendation_area=rca.recommendation_area
            )

            embedding = None
            try:
                embedding = await embedding_service.generate_embedding(combined_text)
            except Exception as e:
                logger.warning(f"Failed to generate embedding for RCA at index {index}: {e}")

            db_rca = SemanticRCA(**rca.model_dump(), embedding=embedding)
            db.add(db_rca)
            await db.flush()
            created_ids.append(db_rca.problem_id)
        except Exception as e:
            errors.append({"index": index, "error": str(e)})

    await db.commit()

    return BulkOperationResponse(
        success_count=len(created_ids),
        failed_count=len(errors),
        created_ids=created_ids,
        errors=errors if errors else None
    )


@router.delete("/rca/bulk", response_model=BulkOperationResponse)
async def bulk_delete_rcas(
    request: BulkDeleteRequest,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> BulkOperationResponse:
    """
    Bulk delete semantic RCAs by IDs (max 100 IDs per request)

    Returns success/failure counts and details for each operation.
    """
    deleted_ids = []
    errors = []

    for problem_id in request.ids:
        result = await db.execute(
            select(SemanticRCA).where(SemanticRCA.problem_id == problem_id)
        )
        rca = result.scalar_one_or_none()

        if not rca:
            errors.append({"id": problem_id, "error": "RCA not found"})
            continue

        await db.delete(rca)
        deleted_ids.append(problem_id)

    await db.commit()

    return BulkOperationResponse(
        success_count=len(deleted_ids),
        failed_count=len(errors),
        deleted_ids=deleted_ids,
        errors=errors if errors else None
    )




@router.get("/rca/{problem_id}", response_model=SemanticRCAResponse)
async def get_semantic_rca(
    problem_id: int,
    db: AsyncSession = Depends(get_db)
) -> SemanticRCAResponse:
    """Get a specific semantic RCA by ID"""
    result = await db.execute(select(SemanticRCA).where(SemanticRCA.problem_id == problem_id))
    rca = result.scalar_one_or_none()
    if not rca:
        raise HTTPException(status_code=404, detail=f"RCA with ID {problem_id} not found")
    return SemanticRCAResponse.model_validate(rca)


@router.put("/rca/{problem_id}", response_model=SemanticRCAResponse)
async def update_semantic_rca(
    problem_id: int,
    rca_update: SemanticRCAUpdate,
    regenerate_embedding: bool = Query(True),
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> SemanticRCAResponse:
    """Update a semantic RCA and optionally regenerate embedding"""
    result = await db.execute(select(SemanticRCA).where(SemanticRCA.problem_id == problem_id))
    rca = result.scalar_one_or_none()
    if not rca:
        raise HTTPException(status_code=404, detail=f"RCA with ID {problem_id} not found")

    update_data = rca_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(rca, field, value)

    if regenerate_embedding:
        combined_text = embedding_service.combine_text_for_embedding(
            question=rca.rca_question,
            type=rca.type_of_rca_question.value,
            root_causes=rca.root_causes,
            relevant_kpis=rca.relevant_kpis,
            recommendation_area=rca.recommendation_area
        )
        try:
            rca.embedding = await embedding_service.generate_embedding(combined_text)
        except Exception as e:
            logger.warning(f"Failed to regenerate embedding: {e}")

    await db.commit()
    await db.refresh(rca)
    return SemanticRCAResponse.model_validate(rca)


@router.delete("/rca/{problem_id}", response_model=MessageResponse)
async def delete_semantic_rca(
    problem_id: int,
    db: AsyncSession = Depends(get_db),
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)
) -> MessageResponse:
    """Delete a semantic RCA"""
    result = await db.execute(select(SemanticRCA).where(SemanticRCA.problem_id == problem_id))
    rca = result.scalar_one_or_none()
    if not rca:
        raise HTTPException(status_code=404, detail=f"RCA with ID {problem_id} not found")
    await db.delete(rca)
    await db.commit()
    return MessageResponse(message=f"RCA with ID {problem_id} deleted successfully")
