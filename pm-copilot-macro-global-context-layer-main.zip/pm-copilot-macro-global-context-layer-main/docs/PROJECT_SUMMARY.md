# Project Summary

**PM Copilot Global Context Layer**

**Developer:** Venkatesh Manikantan, Senior Associate, PwC India
**Client:** Nokia
**Date:** January 2026

---

## Overview

The PM Copilot Global Context Layer is a centralized knowledge management API that serves as the backbone for Nokia's LLM-based Agent microservices. It provides comprehensive CRUD operations and advanced search capabilities across five key knowledge domains: KPIs, Keywords, Question Bank, RCA (Root Cause Analysis), and Simulation scenarios.

---

## Key Features

### 1. Comprehensive CRUD Operations
- Full Create, Read, Update, Delete operations for all tables
- Pagination support (configurable skip/limit)
- Bulk operations capability
- Data validation with Pydantic schemas

### 2. Advanced Search & Query
- **Global Search**: Search across all tables simultaneously
- **Table-Specific Search**: Targeted searches within individual tables
- **Semantic Search**: Keyword and synonym matching
- **Statistics**: Real-time counts and analytics

### 3. Database Management
- **Connection Pooling**: Optimized with configurable pool size
- **Async Operations**: High-performance async/await pattern
- **SQLAlchemy 2.0**: Modern ORM with type hints
- **PostgreSQL**: Robust, production-ready database

### 4. API Design
- **RESTful**: Standard HTTP methods and status codes
- **Auto-Documentation**: Swagger UI and ReDoc
- **CORS Support**: Configurable cross-origin access
- **Error Handling**: Comprehensive error responses

---

## Technology Stack

| Component | Technology | Version |
|-----------|------------|---------|
| Framework | FastAPI | 0.109.0 |
| Server | Uvicorn | 0.27.0 |
| Database | PostgreSQL | 14+ |
| ORM | SQLAlchemy | 2.0.25 |
| Async Driver | asyncpg | 0.29.0 |
| Validation | Pydantic | 2.5.3 |
| Containerization | Docker | Latest |
| Dependency Management | Poetry | 1.7.1 |
| Python | 3.11+ | 3.11 |

---

## Project Structure

```
Global Context Layer/
├── app/
│   ├── api/
│   │   ├── endpoints/
│   │   │   ├── kpi.py              # KPI CRUD endpoints
│   │   │   ├── keywords.py         # Keywords CRUD endpoints
│   │   │   ├── question_bank.py    # Question Bank CRUD
│   │   │   ├── rca.py              # RCA CRUD endpoints
│   │   │   ├── simulation.py       # Simulation CRUD endpoints
│   │   │   └── search.py           # Search & query endpoints
│   │   └── __init__.py
│   ├── core/
│   │   ├── config.py               # Configuration management
│   │   └── __init__.py
│   ├── db/
│   │   ├── database.py             # Database connection & pooling
│   │   └── __init__.py
│   ├── models/
│   │   ├── models.py               # SQLAlchemy models
│   │   └── __init__.py
│   ├── schemas/
│   │   ├── schemas.py              # Pydantic schemas
│   │   └── __init__.py
│   ├── main.py                     # FastAPI application
│   └── __init__.py
├── docs/
├── tests/
├── .env.example                    # Environment template
├── .gitignore                      # Git ignore rules
├── .dockerignore                   # Docker ignore rules
├── Dockerfile                      # Container definition
├── docker-compose.yml              # Multi-container setup
├── init-db.sql                     # Database initialization
├── pyproject.toml                  # Poetry configuration
├── test_api.py                     # API testing script
├── README.md                       # Project overview
├── API_DOCUMENTATION.md            # Complete API reference
├── DEPLOYMENT.md                   # Deployment guide
├── DEPENDENCIES.md                 # Installation guide
├── QUICKSTART.md                   # Quick start guide
└── PROJECT_SUMMARY.md              # This file
```

---

## Database Schema

### Schema: `pm_copilot_macro_semantic`

#### 1. KPI Table
- **kpi_id**: Integer (Primary Key)
- **kpi_name**: String (255)
- **description**: Text
- **formula**: Text
- **mapped_tables_columns**: Text
- **logic**: Text
- **root_cause_positive**: Text
- **root_cause_negative**: Text
- **created_at**: DateTime
- **updated_at**: DateTime

#### 2. Keywords Table
- **keyword_id**: Integer (Primary Key)
- **keyword_name**: String (255)
- **keyword_description**: Text
- **mapped_tables_columns**: Text
- **logic**: Text
- **synonyms**: Text
- **created_at**: DateTime
- **updated_at**: DateTime

#### 3. Question Bank Table
- **question_id**: Integer (Primary Key)
- **question**: Text
- **sql**: Text
- **created_at**: DateTime
- **updated_at**: DateTime

#### 4. RCA Table
- **problem_id**: Integer (Primary Key)
- **rca_question**: Text
- **type_of_rca_question**: Enum (General RCA, Recommendation, Escalation)
- **root_causes**: Array[Text]
- **root_cause_sudo_sql_schema**: Text
- **relevant_kpis**: Text
- **steps_to_get_data_sql**: Array[Text]
- **recommendation_area**: Text
- **output_preferred_template**: Text
- **created_at**: DateTime
- **updated_at**: DateTime

#### 5. Simulation Table
- **scenario_id**: Integer (Primary Key)
- **scenario**: String (500)
- **data_phase_steps**: Array[Text]
- **data_phase_questions**: Array[Text]
- **calculation_phase_steps**: Array[Text]
- **simulator_phase_steps**: Array[Text]
- **simulation_methodology**: Text
- **created_at**: DateTime
- **updated_at**: DateTime

---

## API Endpoints Summary

### Health & Status
- `GET /` - Root endpoint
- `GET /health` - Health check

### KPI Management (7 endpoints)
- `POST /api/v1/kpi` - Create
- `GET /api/v1/kpi` - List all
- `GET /api/v1/kpi/{id}` - Get by ID
- `PUT /api/v1/kpi/{id}` - Update
- `DELETE /api/v1/kpi/{id}` - Delete
- `GET /api/v1/kpi/search/by-name` - Search
- `GET /api/v1/kpi/count/total` - Count

### Keywords Management (8 endpoints)
- Similar CRUD + search by name/synonym

### Question Bank Management (7 endpoints)
- Similar CRUD + search by text

### RCA Management (9 endpoints)
- Similar CRUD + filter by type + count by type

### Simulation Management (7 endpoints)
- Similar CRUD + search by scenario

### Search & Query (3 endpoints)
- `GET /api/v1/search/global` - Global search
- `GET /api/v1/search/table/{name}` - Table search
- `GET /api/v1/search/statistics` - Statistics

**Total:** 41+ endpoints

---

## Configuration

### Database Configuration
- Host, port, database name
- User credentials
- Schema name
- Connection pool settings (size, overflow, timeout, recycle)

### Application Configuration
- App name, version
- API prefix
- Debug mode

### Server Configuration
- Host, port
- Worker count
- CORS origins

### Security
- Secret key
- API key (for future authentication)

---

## Deployment Options

### 1. Local Development
```bash
poetry install
poetry run uvicorn app.main:app --reload
```

### 2. Docker Single Container
```bash
docker build -t pm-copilot-api .
docker run -p 8000:8000 pm-copilot-api
```

### 3. Docker Compose (Recommended)
```bash
docker-compose up -d
```

### 4. Production (Kubernetes, Cloud)
- See DEPLOYMENT.md for detailed instructions

---

## Key Capabilities

### For LLM Agents
- Dynamic knowledge retrieval
- Semantic search across domains
- Question-to-SQL mapping
- RCA configuration lookup
- Simulation scenario access

### For Knowledge Management
- Centralized storage
- Version tracking (created_at, updated_at)
- Flexible schema
- Easy maintenance

### For Operations
- Health monitoring
- Connection pooling
- Async operations
- Auto-scaling ready

---

## Testing

### Manual Testing
```bash
python test_api.py
```

### Interactive Testing
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

### curl Examples
```bash
# Health check
curl http://localhost:8000/health

# Create KPI
curl -X POST http://localhost:8000/api/v1/kpi \
  -H "Content-Type: application/json" \
  -d '{"kpi_name": "Test KPI", "description": "Test"}'

# Global search
curl "http://localhost:8000/api/v1/search/global?query=network"
```

---

## Performance Characteristics

### Database Connection Pooling
- Pool Size: 20 (configurable)
- Max Overflow: 10 (configurable)
- Pool Timeout: 30 seconds
- Connection Recycling: 3600 seconds

### Async Operations
- Non-blocking I/O
- Concurrent request handling
- Efficient resource utilization

### Pagination
- Default: 100 records
- Maximum: 1000 records per request
- Prevents memory issues with large datasets

---

## Security Considerations

### Current Implementation
- Input validation with Pydantic
- SQL injection prevention (parameterized queries)
- CORS configuration
- Error message sanitization

### Production Recommendations
- Implement API key authentication
- Enable HTTPS/TLS
- Add rate limiting
- Use environment variables for secrets
- Regular security updates
- Database SSL connections
- Implement audit logging

---

## Future Enhancements

1. **Authentication & Authorization**
   - API key authentication
   - Role-based access control
   - JWT tokens

2. **Advanced Features**
   - Full-text search with PostgreSQL
   - Caching layer (Redis)
   - Bulk import/export
   - Version history tracking

3. **Monitoring**
   - Prometheus metrics
   - Grafana dashboards
   - ELK stack integration

4. **Performance**
   - Query optimization
   - Read replicas
   - CDN integration

5. **Testing**
   - Unit tests
   - Integration tests
   - Load testing

---

## Documentation Files

| File | Purpose |
|------|---------|
| [README.md](README.md) | Project overview and introduction |
| [QUICKSTART.md](QUICKSTART.md) | Get started in 5 minutes |
| [API_DOCUMENTATION.md](API_DOCUMENTATION.md) | Complete API reference |
| [DEPLOYMENT.md](DEPLOYMENT.md) | Deployment and operations guide |
| [DEPENDENCIES.md](DEPENDENCIES.md) | Installation and dependencies |
| [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md) | This document |

---

## Success Metrics

The API is designed to support:
- **High Throughput**: Thousands of requests per second
- **Low Latency**: Sub-100ms response times
- **High Availability**: 99.9% uptime target
- **Scalability**: Horizontal scaling with multiple instances
- **Maintainability**: Clean code, documentation, type hints

---

## Maintenance

### Regular Tasks
- Database backups
- Log rotation
- Security updates
- Performance monitoring
- Schema migrations (with Alembic)

### Monitoring Points
- API response times
- Database connection pool usage
- Error rates
- Request volume
- Resource utilization

---

## Support & Contact

**Developer:** Venkatesh Manikantan
**Role:** Senior Associate
**Organization:** PwC India
**Client:** Nokia
**Project:** PM Copilot for Nokia

---

## License

Proprietary - PwC India © 2026
Developed for Nokia

---

## Acknowledgments

This project leverages modern Python web development best practices and is built with production-ready, enterprise-grade technologies. Special attention has been paid to:

- Clean architecture
- Comprehensive documentation
- Type safety
- Performance optimization
- Security best practices
- Operational excellence

---

## Conclusion

The PM Copilot Global Context Layer provides a robust, scalable, and well-documented API for centralized knowledge management. It enables LLM-based agents to dynamically access and query critical information across multiple domains, supporting Nokia's PM Copilot initiative.

The system is production-ready, with comprehensive documentation, Docker support, and operational best practices built in from the ground up.

---

**End of Project Summary**
