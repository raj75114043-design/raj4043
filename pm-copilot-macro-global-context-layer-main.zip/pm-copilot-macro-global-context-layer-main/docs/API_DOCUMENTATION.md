# API Documentation

**PM Copilot Global Context Layer API**

**Developer:** Venkatesh Manikantan, Senior Associate, PwC India
**Client:** Nokia

## Base URL

```
http://localhost:8000/api/v1
```

## Authentication

Currently, the API does not require authentication. In production, implement API key authentication using the `API_KEY` environment variable.

## Response Format

All responses are in JSON format. Successful responses return the requested data, while errors return an error object.

### Success Response
```json
{
  "kpi_id": 1,
  "kpi_name": "Network Availability",
  "description": "Percentage of time the network is available"
}
```

### Error Response
```json
{
  "detail": "KPI with ID 999 not found"
}
```

## Endpoints

### 1. KPI Management

#### Create KPI
```http
POST /api/v1/kpi
Content-Type: application/json

{
  "kpi_name": "Network Availability",
  "description": "Percentage of time the network is available",
  "formula": "(Uptime / Total Time) * 100",
  "mapped_tables_columns": "network_stats.uptime, network_stats.total_time",
  "logic": "Calculate ratio of uptime to total time",
  "root_cause_positive": "Good infrastructure, proactive maintenance",
  "root_cause_negative": "Equipment failures, power outages"
}
```

**Response:** `201 Created`

#### List KPIs
```http
GET /api/v1/kpi?skip=0&limit=100
```

**Query Parameters:**
- `skip` (optional): Number of records to skip (default: 0)
- `limit` (optional): Maximum records to return (default: 100, max: 1000)

#### Get KPI by ID
```http
GET /api/v1/kpi/{kpi_id}
```

#### Update KPI
```http
PUT /api/v1/kpi/{kpi_id}
Content-Type: application/json

{
  "description": "Updated description"
}
```

#### Delete KPI
```http
DELETE /api/v1/kpi/{kpi_id}
```

**Response:** `200 OK`

#### Search KPI by Name
```http
GET /api/v1/kpi/search/by-name?name=availability
```

#### Count KPIs
```http
GET /api/v1/kpi/count/total
```

---

### 2. Keywords Management

#### Create Keyword
```http
POST /api/v1/keywords
Content-Type: application/json

{
  "keyword_name": "Throughput",
  "keyword_description": "Rate of successful data transmission",
  "mapped_tables_columns": "network_metrics.throughput",
  "logic": "Sum of bytes transmitted per second",
  "synonyms": "bandwidth, data rate, transfer rate"
}
```

#### List Keywords
```http
GET /api/v1/keywords?skip=0&limit=100
```

#### Get Keyword by ID
```http
GET /api/v1/keywords/{keyword_id}
```

#### Update Keyword
```http
PUT /api/v1/keywords/{keyword_id}
Content-Type: application/json

{
  "synonyms": "bandwidth, data rate, transfer rate, speed"
}
```

#### Delete Keyword
```http
DELETE /api/v1/keywords/{keyword_id}
```

#### Search Keyword by Name
```http
GET /api/v1/keywords/search/by-name?name=throughput
```

#### Search Keyword by Synonym
```http
GET /api/v1/keywords/search/by-synonym?synonym=bandwidth
```

#### Count Keywords
```http
GET /api/v1/keywords/count/total
```

---

### 3. Question Bank Management

#### Create Question
```http
POST /api/v1/question-bank
Content-Type: application/json

{
  "question": "What is the average network throughput for the last 7 days?",
  "sql": "SELECT AVG(throughput) FROM network_metrics WHERE date >= NOW() - INTERVAL '7 days'"
}
```

#### List Questions
```http
GET /api/v1/question-bank?skip=0&limit=100
```

#### Get Question by ID
```http
GET /api/v1/question-bank/{question_id}
```

#### Update Question
```http
PUT /api/v1/question-bank/{question_id}
Content-Type: application/json

{
  "sql": "SELECT AVG(throughput) FROM network_metrics WHERE date >= CURRENT_DATE - 7"
}
```

#### Delete Question
```http
DELETE /api/v1/question-bank/{question_id}
```

#### Search Question by Text
```http
GET /api/v1/question-bank/search/by-text?text=throughput
```

#### Count Questions
```http
GET /api/v1/question-bank/count/total
```

---

### 4. RCA Management

#### Create RCA
```http
POST /api/v1/rca
Content-Type: application/json

{
  "rca_question": "Why is network latency high?",
  "type_of_rca_question": "General RCA",
  "root_causes": ["Network congestion", "Hardware failure", "Configuration issues"],
  "root_cause_sudo_sql_schema": "SELECT * FROM network_issues WHERE latency > threshold",
  "relevant_kpis": "Latency, Packet Loss, Throughput",
  "steps_to_get_data_sql": [
    "SELECT AVG(latency) FROM network_metrics",
    "SELECT COUNT(*) FROM network_errors"
  ],
  "recommendation_area": "Network optimization",
  "output_preferred_template": "Root cause analysis indicates {root_cause} with {confidence}% confidence"
}
```

**RCA Types:**
- `General RCA`
- `Recommendation`
- `Escalation`

#### List RCA
```http
GET /api/v1/rca?skip=0&limit=100&rca_type=General%20RCA
```

**Query Parameters:**
- `skip` (optional): Number of records to skip
- `limit` (optional): Maximum records to return
- `rca_type` (optional): Filter by RCA type

#### Get RCA by ID
```http
GET /api/v1/rca/{problem_id}
```

#### Update RCA
```http
PUT /api/v1/rca/{problem_id}
Content-Type: application/json

{
  "root_causes": ["Network congestion", "Hardware failure", "Configuration issues", "Software bugs"]
}
```

#### Delete RCA
```http
DELETE /api/v1/rca/{problem_id}
```

#### Search RCA by Question
```http
GET /api/v1/rca/search/by-question?question=latency
```

#### Filter RCA by Type
```http
GET /api/v1/rca/filter/by-type/General%20RCA
```

#### Count RCA
```http
GET /api/v1/rca/count/total
```

#### Count RCA by Type
```http
GET /api/v1/rca/count/by-type
```

---

### 5. Simulation Management

#### Create Simulation
```http
POST /api/v1/simulation
Content-Type: application/json

{
  "scenario": "Network capacity expansion simulation",
  "data_phase_steps": [
    "Collect current network capacity data",
    "Gather historical traffic patterns",
    "Identify peak usage times"
  ],
  "data_phase_questions": [
    "What is current network utilization?",
    "What are the traffic growth projections?"
  ],
  "calculation_phase_steps": [
    "Calculate required capacity increase",
    "Estimate cost of expansion"
  ],
  "simulator_phase_steps": [
    "Model traffic with increased capacity",
    "Validate performance improvements"
  ],
  "simulation_methodology": "Monte Carlo simulation with historical data"
}
```

#### List Simulations
```http
GET /api/v1/simulation?skip=0&limit=100
```

#### Get Simulation by ID
```http
GET /api/v1/simulation/{scenario_id}
```

#### Update Simulation
```http
PUT /api/v1/simulation/{scenario_id}
Content-Type: application/json

{
  "simulation_methodology": "Monte Carlo simulation with historical data and predictive analytics"
}
```

#### Delete Simulation
```http
DELETE /api/v1/simulation/{scenario_id}
```

#### Search Simulation by Scenario
```http
GET /api/v1/simulation/search/by-scenario?scenario=capacity
```

#### Count Simulations
```http
GET /api/v1/simulation/count/total
```

---

### 6. Search & Query

#### Global Search
Search across all tables simultaneously.

```http
GET /api/v1/search/global?query=network&limit=50
```

**Query Parameters:**
- `query` (required): Search term
- `limit` (optional): Max results per table (default: 50, max: 500)

**Response:**
```json
{
  "kpis": [...],
  "keywords": [...],
  "questions": [...],
  "rca": [...],
  "simulations": [...],
  "summary": {
    "total_results": 125,
    "kpi_count": 25,
    "keyword_count": 30,
    "question_count": 40,
    "rca_count": 20,
    "simulation_count": 10
  }
}
```

#### Search by Table
Search within a specific table.

```http
GET /api/v1/search/table/{table_name}?query=network&skip=0&limit=100
```

**Valid Table Names:**
- `kpi`
- `keywords`
- `question_bank`
- `rca`
- `simulation`

#### Get Statistics
Get overall statistics for all tables.

```http
GET /api/v1/search/statistics
```

**Response:**
```json
{
  "total_kpis": 150,
  "total_keywords": 200,
  "total_questions": 300,
  "total_rca": 100,
  "total_simulations": 50,
  "rca_by_type": {
    "General RCA": 60,
    "Recommendation": 25,
    "Escalation": 15
  },
  "total_records": 800
}
```

---

### 7. Health & Status

#### Root Endpoint
```http
GET /
```

Returns basic API information.

#### Health Check
```http
GET /health
```

Returns detailed health status including database configuration.

---

## Error Codes

| Status Code | Description |
|-------------|-------------|
| 200 | OK - Request successful |
| 201 | Created - Resource created successfully |
| 400 | Bad Request - Invalid input |
| 404 | Not Found - Resource not found |
| 422 | Unprocessable Entity - Validation error |
| 500 | Internal Server Error - Server error |

---

## Pagination

All list endpoints support pagination using `skip` and `limit` parameters:

- `skip`: Number of records to skip (default: 0)
- `limit`: Maximum number of records to return (default: 100, max: 1000)

Example:
```http
GET /api/v1/kpi?skip=20&limit=10
```

---

## Best Practices

1. **Use pagination** for large datasets to improve performance
2. **Use global search** for quick lookups across all tables
3. **Use table-specific search** when you know which table contains the data
4. **Filter RCA by type** to narrow down results
5. **Use count endpoints** to get statistics without fetching full data
6. **Handle errors gracefully** by checking status codes

---

## Example Use Cases

### Use Case 1: LLM Agent Querying KPIs
```python
import httpx

async def get_kpi_by_name(name: str):
    async with httpx.AsyncClient() as client:
        response = await client.get(
            "http://localhost:8000/api/v1/kpi/search/by-name",
            params={"name": name}
        )
        return response.json()
```

### Use Case 2: Finding Related Keywords
```python
async def find_synonyms(keyword: str):
    async with httpx.AsyncClient() as client:
        response = await client.get(
            "http://localhost:8000/api/v1/keywords/search/by-synonym",
            params={"synonym": keyword}
        )
        return response.json()
```

### Use Case 3: Global Search from LLM Agent
```python
async def semantic_search(query: str):
    async with httpx.AsyncClient() as client:
        response = await client.get(
            "http://localhost:8000/api/v1/search/global",
            params={"query": query, "limit": 100}
        )
        return response.json()
```

---

## Rate Limiting

Currently, there is no rate limiting. In production, implement rate limiting to prevent abuse.

---

## Support

For issues, questions, or feature requests:
- **Developer:** Venkatesh Manikantan
- **Organization:** PwC India
- **Client:** Nokia

---

## Interactive Documentation

For interactive API documentation and testing:
- **Swagger UI:** http://localhost:8000/docs
- **ReDoc:** http://localhost:8000/redoc
