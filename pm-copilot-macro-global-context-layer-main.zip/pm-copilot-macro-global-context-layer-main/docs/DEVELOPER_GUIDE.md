# Developer Guide: Production-Grade FastAPI with Async SQLAlchemy

A practical guide explaining every pattern used in this project, written in plain English.
All code examples are taken directly from our codebase.

---

## Table of Contents

1. [Project Structure](#1-project-structure)
2. [How the Pieces Fit Together](#2-how-the-pieces-fit-together)
3. [Configuration: Settings & Environment Variables](#3-configuration-settings--environment-variables)
4. [Database Setup: Async SQLAlchemy](#4-database-setup-async-sqlalchemy)
5. [Models: Defining Your Database Tables](#5-models-defining-your-database-tables)
6. [Schemas: Controlling What Goes In and Out](#6-schemas-controlling-what-goes-in-and-out)
7. [Endpoints: Writing CRUD APIs](#7-endpoints-writing-crud-apis)
8. [Dependency Injection: How FastAPI Wires Things Together](#8-dependency-injection-how-fastapi-wires-things-together)
9. [Service Layer: Keeping Business Logic Separate](#9-service-layer-keeping-business-logic-separate)
10. [Common Gotchas & Mistakes](#10-common-gotchas--mistakes)
11. [Patterns Cheat Sheet](#11-patterns-cheat-sheet)

---

## 1. Project Structure

```
app/
├── core/
│   └── config.py              # All settings (DB, API keys, etc.)
├── db/
│   └── database.py            # Database engine, sessions, lifecycle
├── models/
│   └── semantic_models.py     # SQLAlchemy models (= database tables)
├── schemas/
│   └── semantic_schemas.py    # Pydantic schemas (= request/response shapes)
├── services/
│   └── embedding_service.py   # Business logic (embedding generation)
├── api/
│   └── endpoints/
│       ├── kpi.py             # KPI CRUD endpoints
│       ├── question_bank.py   # Question Bank CRUD endpoints
│       ├── rca.py             # RCA CRUD endpoints
│       ├── simulation.py      # Simulation CRUD endpoints
│       ├── keywords.py        # Keywords CRUD endpoints
│       ├── search.py          # Global text search endpoints
│       └── semantic_search.py # Vector/semantic search endpoints
```

**Why this structure?**

Each folder has exactly one job:

| Folder     | Job                                           | Think of it as...         |
|------------|-----------------------------------------------|---------------------------|
| `core/`    | App-wide configuration                        | The settings panel        |
| `db/`      | Database connections                           | The plumbing              |
| `models/`  | Define what tables look like in the database   | The blueprint             |
| `schemas/` | Define what data looks like in the API         | The security guard        |
| `services/`| Business logic (not tied to any endpoint)      | The worker                |
| `api/`     | HTTP endpoints that users call                 | The front desk            |

---

## 2. How the Pieces Fit Together

When a user sends a request like `POST /api/v1/kpi/kpi`, here is what happens step by step:

```
User sends JSON  --->  Schema validates it  --->  Endpoint runs logic  --->  Model saves to DB
                      (SemanticKPICreate)        (create_semantic_kpi)      (SemanticKPI)
                                                        |
                                                        v
                                                  Service generates
                                                  embedding vector
                                                  (embedding_service)
                                                        |
                                                        v
                                                  Schema shapes the  --->  User gets JSON back
                                                  response
                                                  (SemanticKPIResponse)
```

The key idea: **Models talk to the database. Schemas talk to the user. Endpoints connect them.**

---

## 3. Configuration: Settings & Environment Variables

**File:** `app/core/config.py`

### What it does

Instead of hardcoding values like database passwords or API keys, we load them from a `.env` file. This way, the same code works on your laptop, a staging server, and production -- just by changing the `.env` file.

### How it works

```python
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    """Application settings and configuration"""

    model_config = SettingsConfigDict(
        env_file=".env",          # Read from .env file
        env_file_encoding="utf-8",
        case_sensitive=False       # DB_HOST and db_host both work
    )

    db_host: str = Field(default="localhost")
    db_port: int = Field(default=5432)
    db_password: str = Field(default="")
```

### How to read this

- Each field (like `db_host`) automatically maps to an environment variable (`DB_HOST`).
- The `default=` value is used when the env var is not set.
- Pydantic validates the type: if `DB_PORT=abc`, it will throw an error because `db_port` expects an `int`.

### The `@property` trick for computed values

```python
@property
def database_url(self) -> str:
    """Construct async database URL"""
    return (
        f"postgresql+asyncpg://{self.db_user}:{quote_plus(self.db_password)}"
        f"@{self.db_host}:{self.db_port}/{self.db_name}"
    )
```

A `@property` looks like a regular attribute but runs a function. `settings.database_url` is computed every time you access it, built from the individual pieces. This avoids storing the full URL in `.env` and lets us change any part independently.

### Singleton pattern

```python
settings = Settings()  # Created once at module load

def get_settings() -> Settings:
    return settings
```

The `settings` object is created once when the app starts. Every file that imports it gets the same instance. This is called the **singleton pattern** -- one object shared everywhere.

---

## 4. Database Setup: Async SQLAlchemy

**File:** `app/db/database.py`

### Why "async"?

Normal (synchronous) code works like a queue at a bank: one person at a time. While one person is being served, everyone else waits.

Async code works like a restaurant: while the kitchen is cooking your food, the waiter takes another table's order. No one is blocked.

For a web API, this means while one request waits for the database, FastAPI can handle other requests. This is critical for production performance.

### The Engine: Your connection to the database

```python
async_engine = create_async_engine(
    settings.database_url,          # Where the DB is
    echo=settings.debug,            # Print SQL in debug mode
    pool_size=settings.db_pool_min_size,      # Keep 5 connections ready
    max_overflow=settings.db_pool_max_size - settings.db_pool_min_size,  # Allow up to 15 more if busy
    pool_pre_ping=True,             # Check if connection is alive before using it
)
```

**What is a connection pool?** Opening a database connection is slow (like starting a car engine). A pool keeps connections "running" and ready. When your code needs the DB, it borrows a connection from the pool, uses it, and returns it.

- `pool_size=5` means 5 connections are always ready.
- `max_overflow=15` means if all 5 are busy, up to 15 more can be created temporarily.
- `pool_pre_ping=True` means before handing you a connection, the pool sends a quick "are you alive?" check. This prevents errors from stale connections.

### The Session Factory

```python
AsyncSessionLocal = async_sessionmaker(
    async_engine,
    class_=AsyncSession,
    expire_on_commit=False,   # Keep data accessible after commit
    autocommit=False,         # You control when to commit
    autoflush=False,          # You control when to flush
)
```

A **session** is your workspace for interacting with the DB within one request. Think of it as a shopping cart:
- You add items (create records)
- You modify items (update records)
- You remove items (delete records)
- Then you "checkout" (commit) -- all changes go to the DB at once

**`expire_on_commit=False`** is important. Without it, after you commit, all your objects become "expired" and accessing any attribute would trigger another DB query. With it set to False, you can still read the data after committing.

### The `get_db` dependency

```python
async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()     # If everything went fine, save changes
        except Exception:
            await session.rollback()   # If anything failed, undo everything
            raise
```

This is a **dependency** that FastAPI calls automatically for each request. Here's what happens:

1. Request comes in -> FastAPI calls `get_db()`
2. A new session is created
3. `yield session` gives the session to your endpoint function
4. Your endpoint does its work
5. If no errors: `commit()` saves everything
6. If any error: `rollback()` undoes everything (no partial saves!)
7. Session is cleaned up automatically (`async with` handles this)

### Lifecycle: Startup and Shutdown

```python
async def init_db() -> None:
    """Called when the app starts"""
    # Test that we can reach the database
    async with async_engine.connect() as conn:
        await conn.execute(text("SELECT 1"))

async def close_db() -> None:
    """Called when the app shuts down"""
    await async_engine.dispose()  # Close all connections cleanly
```

Always test your DB connection at startup (fail fast!) and clean up on shutdown (don't leak connections).

---

## 5. Models: Defining Your Database Tables

**File:** `app/models/semantic_models.py`

### What is a Model?

A model is a Python class that represents a database table. Each attribute = one column.

```python
class SemanticKPI(Base):
    __tablename__ = "semantic_kpi"                       # Actual table name in the DB
    __table_args__ = {"schema": settings.db_schema}      # Which schema (like a folder for tables)

    # Columns
    kpi_id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    kpi_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
```

### How to read this

| Part | Meaning |
|------|---------|
| `Mapped[int]` | Python type hint: this attribute is an integer |
| `mapped_column(Integer, ...)` | SQLAlchemy column definition |
| `primary_key=True` | This is the unique ID for each row |
| `autoincrement=True` | Database generates the ID automatically (1, 2, 3...) |
| `nullable=False` | This column MUST have a value (cannot be empty) |
| `nullable=True` | This column CAN be empty |
| `index=True` | Create a database index for faster searches on this column |
| `String(255)` | Text with max 255 characters |
| `Text` | Unlimited-length text |
| `ARRAY(Float)` | A PostgreSQL array of floating-point numbers |

### `Mapped[Optional[str]]` vs `Mapped[str]`

- `Mapped[str]` = This column always has a value (NOT NULL)
- `Mapped[Optional[str]]` = This column can be `None` (NULL)

These must match your `nullable=` setting. If `nullable=True`, use `Optional`.

### The `__repr__` method

```python
def __repr__(self) -> str:
    return f"<SemanticKPI(kpi_id={self.kpi_id}, kpi_name='{self.kpi_name}')>"
```

This controls what you see when you `print()` the object. Useful for debugging:
```
<SemanticKPI(kpi_id=1, kpi_name='DL_User_Throughput')>
```
Without it, you'd just see `<SemanticKPI object at 0x7f...>`, which is useless.

### Enums for fixed choices

```python
class SemanticRCATypeEnum(str, enum.Enum):
    GENERAL_RCA = "General RCA"
    RECOMMENDATION = "Recommendation"
    ESCALATION = "Escalation"
```

An Enum restricts a column to specific values. If someone tries to set `type_of_rca_question = "Random Stuff"`, it will fail. This is data integrity at the database level.

Note: `(str, enum.Enum)` means this enum is also a string, so you can do `my_enum.value` to get `"General RCA"`.

### Timestamps

```python
created_at: Mapped[datetime] = mapped_column(
    DateTime, default=datetime.utcnow, nullable=False
)
updated_at: Mapped[datetime] = mapped_column(
    DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
)
```

- `default=datetime.utcnow` sets the value when a row is first created.
- `onupdate=datetime.utcnow` automatically updates the value whenever the row is modified.

Always use `utcnow` (not `now`) -- store everything in UTC and convert to local time in the frontend.

### The `Base` class

```python
from app.db.database import Base

class SemanticKPI(Base):
    ...
```

Every model inherits from `Base`. This is how SQLAlchemy knows about all your tables. When you create the database (`Base.metadata.create_all()`), it looks at every class that inherits from `Base` and creates the corresponding tables.

---

## 6. Schemas: Controlling What Goes In and Out

**File:** `app/schemas/semantic_schemas.py`

### Why do we need schemas if we already have models?

**Models** define what the database looks like. **Schemas** define what the API accepts and returns.

These are often different! For example:
- When creating a KPI, the user should NOT send `kpi_id` (the DB generates it) or `embedding` (the service generates it).
- When returning a KPI, we should NOT send the `embedding` (it's a huge array of 1536 floats that the user doesn't need).

### The pattern: Base -> Create -> Update -> Response

```python
# 1. BASE: Fields shared by create and update
class SemanticKPIBase(BaseModel):
    kpi_name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    formula: Optional[str] = None

# 2. CREATE: What the user sends to create a new record
class SemanticKPICreate(SemanticKPIBase):
    pass  # Same as base -- all base fields are required/optional as defined

# 3. UPDATE: What the user sends to update an existing record
class SemanticKPIUpdate(BaseModel):   # Note: NOT inheriting from Base!
    kpi_name: Optional[str] = None     # Everything is optional in an update
    description: Optional[str] = None
    formula: Optional[str] = None

# 4. RESPONSE: What the API sends back
class SemanticKPIResponse(SemanticKPIBase):
    model_config = ConfigDict(from_attributes=True)  # Can read from SQLAlchemy model

    kpi_id: int            # Include the DB-generated ID
    created_at: datetime   # Include timestamps
    updated_at: datetime
    # NO embedding field -- we don't want to expose this to the user
```

### How to read `Field(...)`

```python
kpi_name: str = Field(..., min_length=1, max_length=255, description="KPI name")
```

- `...` (three dots) means "required" -- the user MUST provide this.
- `min_length=1` means it can't be empty.
- `max_length=255` means it can't exceed 255 characters.
- `description=` shows up in the auto-generated API docs (Swagger UI).

Compare with:
```python
description: Optional[str] = Field(None, description="KPI description")
```

- `None` as default means "optional" -- if not provided, it's `None`.

### `model_config = ConfigDict(from_attributes=True)`

This tells Pydantic: "You can create this schema from a SQLAlchemy model object." Without this, `SemanticKPIResponse.model_validate(db_kpi)` would fail because Pydantic wouldn't know how to read attributes from a SQLAlchemy object.

### Why Update schemas don't inherit from Base

In `SemanticKPICreate`, `kpi_name` is required (you must give a name when creating).

In `SemanticKPIUpdate`, `kpi_name` is optional (you might only want to update the description, not the name). If Update inherited from Base, `kpi_name` would be required, which is wrong for partial updates.

---

## 7. Endpoints: Writing CRUD APIs

**File:** `app/api/endpoints/kpi.py` (and similar files)

### CRUD = Create, Read, Update, Delete

| Operation | HTTP Method | Example                           |
|-----------|-------------|-----------------------------------|
| Create    | POST        | `POST /kpi/kpi`                   |
| Read all  | GET         | `GET /kpi/kpi`                    |
| Read one  | GET         | `GET /kpi/kpi/5`                  |
| Update    | PUT         | `PUT /kpi/kpi/5`                  |
| Delete    | DELETE      | `DELETE /kpi/kpi/5`               |

### The Router

```python
router = APIRouter(prefix="/kpi", tags=["KPI Creations[Dev Only]"])
```

- `prefix="/kpi"` means all endpoints in this file start with `/kpi`.
- `tags=["..."]` groups endpoints in the Swagger docs.

### CREATE: Adding a new record

```python
@router.post("/kpi", response_model=SemanticKPIResponse, status_code=201)
async def create_semantic_kpi(
    kpi: SemanticKPICreate,                                    # Request body (validated by schema)
    db: AsyncSession = Depends(get_db),                        # Database session (injected)
    credentials: HTTPBasicCredentials = Depends(verify_dev_password)  # Auth check
) -> SemanticKPIResponse:

    # 1. Generate embedding (business logic in service)
    combined_text = embedding_service.combine_text_for_embedding(
        name=kpi.kpi_name,
        description=kpi.description,
        ...
    )

    embedding = None
    try:
        embedding = await embedding_service.generate_embedding(combined_text)
    except Exception as e:
        logger.warning(f"Failed to generate embedding: {e}")   # Log but don't fail

    # 2. Create DB object from schema + embedding
    db_kpi = SemanticKPI(**kpi.model_dump(), embedding=embedding)

    # 3. Save to database
    db.add(db_kpi)              # Add to session (like adding to cart)
    await db.commit()           # Save to DB (like checkout)
    await db.refresh(db_kpi)    # Reload from DB to get generated fields (kpi_id, timestamps)

    # 4. Return response shaped by schema
    return SemanticKPIResponse.model_validate(db_kpi)
```

Key points:
- `**kpi.model_dump()` converts the Pydantic schema to a dictionary and unpacks it as keyword arguments. If `kpi` has `kpi_name="X"` and `description="Y"`, this becomes `SemanticKPI(kpi_name="X", description="Y", embedding=...)`.
- `status_code=201` returns HTTP 201 (Created) instead of the default 200 (OK).
- `response_model=SemanticKPIResponse` tells FastAPI to validate and serialize the response using this schema. Any field not in the schema (like `embedding`) is automatically excluded.

### READ ALL: Listing records with pagination

```python
@router.get("/kpi", response_model=List[SemanticKPIResponse])
async def list_semantic_kpis(
    skip: int = Query(0, ge=0),                  # Query param: ?skip=0
    limit: int = Query(100, ge=1, le=1000),      # Query param: ?limit=100
    db: AsyncSession = Depends(get_db)
) -> List[SemanticKPIResponse]:

    result = await db.execute(
        select(SemanticKPI)             # SELECT * FROM semantic_kpi
        .offset(skip)                   # Skip first N rows
        .limit(limit)                   # Take only N rows
        .order_by(SemanticKPI.kpi_id)   # Sort by ID
    )
    kpis = result.scalars().all()       # Get all results as a list of objects
    return [SemanticKPIResponse.model_validate(kpi) for kpi in kpis]
```

**Pagination** means returning data in chunks. Without it, if you have 10,000 KPIs, you'd send all 10,000 in one response, which is slow and uses too much memory.

- `?skip=0&limit=100` returns the first 100 records.
- `?skip=100&limit=100` returns records 101-200.
- `ge=0` means "greater than or equal to 0" (no negative skip).
- `le=1000` means "less than or equal to 1000" (prevent someone from requesting 1 million records).

### READ ONE: Getting a single record

```python
@router.get("/kpi/{kpi_id}", response_model=SemanticKPIResponse)
async def get_semantic_kpi(
    kpi_id: int,                          # Path parameter from URL
    db: AsyncSession = Depends(get_db)
) -> SemanticKPIResponse:

    result = await db.execute(
        select(SemanticKPI).where(SemanticKPI.kpi_id == kpi_id)
    )
    kpi = result.scalar_one_or_none()     # Get one result or None

    if not kpi:
        raise HTTPException(status_code=404, detail=f"KPI with ID {kpi_id} not found")

    return SemanticKPIResponse.model_validate(kpi)
```

- `{kpi_id}` in the URL is a **path parameter**. `GET /kpi/kpi/5` sets `kpi_id=5`.
- `scalar_one_or_none()` returns the object if found, or `None` if not found. Use this for single-record lookups.
- `HTTPException(status_code=404)` returns a "Not Found" error to the user.

### UPDATE: Modifying an existing record

```python
@router.put("/kpi/{kpi_id}", response_model=SemanticKPIResponse)
async def update_semantic_kpi(
    kpi_id: int,
    kpi_update: SemanticKPIUpdate,        # Only the fields the user wants to change
    db: AsyncSession = Depends(get_db)
) -> SemanticKPIResponse:

    # 1. Find the record
    result = await db.execute(select(SemanticKPI).where(SemanticKPI.kpi_id == kpi_id))
    kpi = result.scalar_one_or_none()
    if not kpi:
        raise HTTPException(status_code=404, detail="Not found")

    # 2. Apply only the fields that were sent
    update_data = kpi_update.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(kpi, field, value)

    # 3. Save
    await db.commit()
    await db.refresh(kpi)
    return SemanticKPIResponse.model_validate(kpi)
```

The magic is in `exclude_unset=True`. If the user sends `{"description": "new desc"}`, only `description` is in the dict. `kpi_name` and other fields are NOT included (because the user didn't send them), so they stay unchanged.

Without `exclude_unset=True`, all fields not sent would be set to `None`, which would erase data!

### DELETE: Removing a record

```python
@router.delete("/kpi/{kpi_id}", response_model=MessageResponse)
async def delete_semantic_kpi(
    kpi_id: int,
    db: AsyncSession = Depends(get_db)
) -> MessageResponse:

    result = await db.execute(select(SemanticKPI).where(SemanticKPI.kpi_id == kpi_id))
    kpi = result.scalar_one_or_none()
    if not kpi:
        raise HTTPException(status_code=404, detail="Not found")

    await db.delete(kpi)
    await db.commit()
    return MessageResponse(message=f"KPI with ID {kpi_id} deleted successfully")
```

### BULK operations

```python
@router.post("/kpi/bulk", response_model=BulkOperationResponse, status_code=201)
async def bulk_create_kpis(kpis: List[SemanticKPICreate], db: AsyncSession = Depends(get_db)):
    if len(kpis) > 100:
        raise HTTPException(status_code=400, detail="Maximum 100 items per request")

    created_ids = []
    errors = []

    for index, kpi in enumerate(kpis):
        try:
            db_kpi = SemanticKPI(**kpi.model_dump(), embedding=embedding)
            db.add(db_kpi)
            await db.flush()                    # Write to DB but don't commit yet
            created_ids.append(db_kpi.kpi_id)   # ID is available after flush
        except Exception as e:
            errors.append({"index": index, "error": str(e)})

    await db.commit()  # Commit all at once (much faster than committing each one)
```

Key difference: `flush()` vs `commit()`:
- `flush()` sends the SQL to the database but doesn't finalize. You can still rollback. The ID is generated (because the DB assigned it) but the transaction isn't committed.
- `commit()` finalizes everything. No going back.

Use `flush()` in loops when you need generated IDs but want to commit all-or-nothing at the end.

---

## 8. Dependency Injection: How FastAPI Wires Things Together

### What is Dependency Injection?

Instead of creating things yourself inside your function, you declare what you need and FastAPI provides it.

```python
# WITHOUT dependency injection (bad)
async def create_kpi(kpi: SemanticKPICreate):
    session = AsyncSessionLocal()     # You create the session yourself
    try:
        # ... do work ...
        await session.commit()
    except:
        await session.rollback()
    finally:
        await session.close()         # You must remember to close it

# WITH dependency injection (good)
async def create_kpi(
    kpi: SemanticKPICreate,
    db: AsyncSession = Depends(get_db)   # FastAPI creates, manages, and cleans up
):
    # Just use `db` -- FastAPI handles the rest
```

### The `Depends()` function

```python
db: AsyncSession = Depends(get_db)
```

This tells FastAPI: "Before running this endpoint, call `get_db()` and pass the result as `db`." After the endpoint finishes, FastAPI also handles cleanup (closing the session).

You can chain dependencies:

```python
credentials: HTTPBasicCredentials = Depends(verify_dev_password)
```

This runs the `verify_dev_password` function before your endpoint. If it raises an exception (wrong password), your endpoint never runs.

### Query Parameters with `Query()`

```python
skip: int = Query(0, ge=0)
limit: int = Query(100, ge=1, le=1000)
query: str = Query(..., min_length=1, description="Search query")
```

These come from the URL: `GET /search?query=throughput&skip=0&limit=50`

- `Query(0, ...)` -- default value is 0
- `Query(..., ...)` -- required (no default)
- `ge=0` -- greater than or equal to 0
- `le=1000` -- less than or equal to 1000
- `min_length=1` -- can't be empty

---

## 9. Service Layer: Keeping Business Logic Separate

**File:** `app/services/embedding_service.py`

### Why a separate service?

The endpoint's job is to handle HTTP (receive request, return response). The service's job is business logic (generate embeddings, call external APIs).

This separation means:
1. You can test the embedding logic without running a web server.
2. Multiple endpoints can reuse the same service.
3. If the embedding API changes, you only change one file.

### The Singleton Pattern

```python
class EmbeddingService:
    def __init__(self):
        self.timeout = 30.0

    async def generate_embedding(self, text: str) -> Optional[List[float]]:
        ...

# One instance shared everywhere
embedding_service = EmbeddingService()
```

Every file that does `from app.services.embedding_service import embedding_service` gets the same object. This avoids creating a new HTTP client for every request.

### Retry logic with `tenacity`

```python
from tenacity import retry, stop_after_attempt, wait_exponential

@retry(
    stop=stop_after_attempt(3),                        # Try 3 times max
    wait=wait_exponential(multiplier=1, min=2, max=10), # Wait 2s, then 4s, then 8s (capped at 10s)
    reraise=True                                        # If all retries fail, raise the exception
)
async def generate_embedding(self, text: str):
    ...
```

External APIs can fail temporarily (network blips, rate limits). Retrying with exponential backoff (waiting longer each time) is a production best practice.

### Combining text fields for embedding

```python
def combine_text_for_embedding(self, **fields) -> str:
    parts = []
    for field_name, value in fields.items():
        if value:
            if isinstance(value, list):
                value = " ".join(str(v) for v in value if v)
            parts.append(f"{field_name}: {value}")
    return " | ".join(parts)
```

`**fields` accepts any keyword arguments. The `**` means "collect all named arguments into a dictionary."

```python
# Calling it:
embedding_service.combine_text_for_embedding(
    name="DL Throughput",
    description="Download throughput KPI"
)

# Inside the function, fields = {"name": "DL Throughput", "description": "Download throughput KPI"}
# Result: "name: DL Throughput | description: Download throughput KPI"
```

---

## 10. Common Gotchas & Mistakes

### 1. Calling `.scalar()` twice on the same result

```python
# BUG: .scalar() consumes the result. Second call returns None!
result = await db.execute(select(func.count()).select_from(SemanticKPI))
print(result.scalar())   # Returns 42
print(result.scalar())   # Returns None! The result is already consumed.

# FIX: Store the value first
result = await db.execute(select(func.count()).select_from(SemanticKPI))
count = result.scalar()  # Store it
print(count)              # 42
print(count)              # 42 (it's just a variable now)
```

This exact bug caused our `/statistics` endpoint to throw 500 errors. The `.scalar()` method reads from a cursor (like a bookmark in a book). Once you read it, the bookmark moves past the data.

### 2. Exposing internal fields in the API response

```python
# BAD: Embedding is a list of 1536 floats -- huge and useless to the user
class SemanticKPIResponse(SemanticKPIBase):
    embedding: Optional[List[float]] = None   # Don't include this!
    ...

# GOOD: Only include fields the user actually needs
class SemanticKPIResponse(SemanticKPIBase):
    kpi_id: int
    created_at: datetime
    updated_at: datetime
    # No embedding field
```

The `response_model` in your endpoint definition controls what gets serialized. If a field isn't in the response schema, it won't appear in the JSON response even if the SQLAlchemy object has it.

### 3. Forgetting `await` with async operations

```python
# BUG: Missing await -- result is a coroutine object, not actual data!
result = db.execute(select(SemanticKPI))

# FIX: Always await async operations
result = await db.execute(select(SemanticKPI))
```

If you forget `await`, your variable will contain a coroutine object instead of actual data, and you'll get confusing errors.

### 4. Not handling None values in arithmetic

```python
# BUG: If scalar() returns None, addition fails
total = kpi_count.scalar() + keyword_count.scalar()

# FIX: Default to 0
kpi_count = kpi_result.scalar() or 0
keyword_count = keyword_result.scalar() or 0
total = kpi_count + keyword_count
```

### 5. Using `model_dump()` without `exclude_unset`

```python
# BUG: Sets all unsent fields to None (erases data!)
update_data = kpi_update.model_dump()
# If user sent {"description": "new"}, this returns:
# {"kpi_name": None, "description": "new", "formula": None, ...}

# FIX: Only include fields the user actually sent
update_data = kpi_update.model_dump(exclude_unset=True)
# Returns: {"description": "new"}
```

### 6. Not using `index=True` on frequently searched columns

```python
# Without index: database scans EVERY row to find matches (slow)
kpi_name: Mapped[str] = mapped_column(String(255), nullable=False)

# With index: database uses a lookup table (fast)
kpi_name: Mapped[str] = mapped_column(String(255), nullable=False, index=True)
```

Add indexes on columns you search, filter, or sort by. Don't add them on columns you rarely query (they slow down inserts).

### 7. Logging errors but silently continuing

```python
# Sometimes appropriate (embedding is optional, don't block the whole operation):
try:
    embedding = await embedding_service.generate_embedding(combined_text)
except Exception as e:
    logger.warning(f"Failed to generate embedding: {e}")
    # Continue without embedding -- this is intentional

# Sometimes NOT appropriate (the operation depends on this):
try:
    query_embedding = await embedding_service.generate_embedding(request.query)
except Exception as e:
    raise HTTPException(status_code=500, detail=f"Failed: {str(e)}")
    # Re-raise because semantic search can't work without the query embedding
```

Decide per-case: is this failure recoverable or fatal? Log either way, but only swallow the error if the operation can still succeed without it.

---

## 11. Patterns Cheat Sheet

### SQLAlchemy Async Query Patterns

```python
# SELECT all with pagination
result = await db.execute(
    select(Model).offset(skip).limit(limit).order_by(Model.id)
)
items = result.scalars().all()

# SELECT one by ID
result = await db.execute(select(Model).where(Model.id == item_id))
item = result.scalar_one_or_none()

# SELECT with search (LIKE)
result = await db.execute(
    select(Model).where(
        or_(
            Model.name.ilike(f"%{query}%"),
            Model.description.ilike(f"%{query}%"),
        )
    )
)

# COUNT
result = await db.execute(select(func.count()).select_from(Model))
count = result.scalar()

# GROUP BY
result = await db.execute(
    select(Model.category, func.count())
    .group_by(Model.category)
)
groups = {category: count for category, count in result.all()}

# INSERT
db_item = Model(**data.model_dump())
db.add(db_item)
await db.commit()
await db.refresh(db_item)  # Get generated values (ID, timestamps)

# UPDATE
item.name = "new name"
await db.commit()
await db.refresh(item)

# DELETE
await db.delete(item)
await db.commit()
```

### Schema Conversion Patterns

```python
# Pydantic schema -> dict
data_dict = schema.model_dump()                    # All fields
data_dict = schema.model_dump(exclude_unset=True)  # Only fields the user sent

# dict -> SQLAlchemy model
db_item = Model(**data_dict)

# SQLAlchemy model -> Pydantic schema
response = ResponseSchema.model_validate(db_item)  # Requires from_attributes=True
```

### HTTP Status Codes to Use

| Status | Meaning              | When to use                              |
|--------|----------------------|------------------------------------------|
| 200    | OK                   | Successful GET, PUT, DELETE              |
| 201    | Created              | Successful POST that created something   |
| 400    | Bad Request          | Invalid input, validation errors         |
| 401    | Unauthorized         | Missing or wrong credentials             |
| 404    | Not Found            | Record doesn't exist                     |
| 500    | Internal Server Error| Unhandled exception (avoid this!)        |

---

## Quick Reference: Adding a New Table End-to-End

1. **Model** (`app/models/semantic_models.py`): Define the table with columns
2. **Schema** (`app/schemas/semantic_schemas.py`): Define Create, Update, and Response schemas
3. **Endpoint** (`app/api/endpoints/new_thing.py`): Write CRUD endpoints
4. **Register** the router in your main app file
5. **Test** with Swagger UI at `/docs`

Follow the existing pattern -- copy an existing endpoint file (like `kpi.py`) and modify it for your new table. Consistency is more important than cleverness.
