# Dependencies Installation Guide

## PM Copilot Global Context Layer - PwC India

This document provides detailed information about installing and managing dependencies for the PM Copilot API.

## Installation Methods

### Method 1: Using Poetry (Recommended)

Poetry is the recommended package manager for this project.

```bash
# Install Poetry if not already installed
curl -sSL https://install.python-poetry.org | python3 -

# Install project dependencies
poetry install

# Install only production dependencies (exclude dev dependencies)
poetry install --no-dev

# Activate the virtual environment
poetry shell

# Run the application
poetry run uvicorn app.main:app --reload
```

### Method 2: Manual Installation with pip

If you prefer to install dependencies manually without Poetry:

```bash
# Core dependencies
pip install fastapi==0.109.0
pip install "uvicorn[standard]==0.27.0"
pip install sqlalchemy==2.0.25
pip install asyncpg==0.29.0
pip install psycopg2-binary==2.9.9
pip install pydantic==2.5.3
pip install pydantic-settings==2.1.0
pip install python-dotenv==1.0.0
pip install alembic==1.13.1
pip install python-multipart==0.0.6
pip install email-validator==2.1.0
pip install httpx==0.26.0
pip install tenacity==8.2.3

# Development dependencies (optional)
pip install pytest==7.4.4
pip install pytest-asyncio==0.23.3
pip install pytest-cov==4.1.0
pip install black==24.1.0
pip install ruff==0.1.13
pip install mypy==1.8.0
pip install pre-commit==3.6.0
```

### Method 3: Using requirements.txt

```bash
# Generate requirements.txt from Poetry (if needed)
poetry export -f requirements.txt --output requirements.txt --without-hashes

# Install from requirements.txt
pip install -r requirements.txt
```

## Core Dependencies

### Web Framework
- **fastapi** (0.109.0): Modern, fast web framework for building APIs
- **uvicorn[standard]** (0.27.0): ASGI server for running FastAPI applications

### Database
- **sqlalchemy** (2.0.25): SQL toolkit and ORM
- **asyncpg** (0.29.0): Async PostgreSQL driver
- **psycopg2-binary** (2.9.9): PostgreSQL adapter for Python
- **alembic** (1.13.1): Database migration tool

### Data Validation
- **pydantic** (2.5.3): Data validation using Python type annotations
- **pydantic-settings** (2.1.0): Settings management using Pydantic
- **email-validator** (2.1.0): Email validation for Pydantic

### Utilities
- **python-dotenv** (1.0.0): Environment variable management
- **python-multipart** (0.0.6): Multipart form data parsing
- **httpx** (0.26.0): Async HTTP client
- **tenacity** (8.2.3): Retry logic and resilience patterns

## Development Dependencies

### Testing
- **pytest** (7.4.4): Testing framework
- **pytest-asyncio** (0.23.3): Async support for pytest
- **pytest-cov** (4.1.0): Code coverage reporting

### Code Quality
- **black** (24.1.0): Code formatter
- **ruff** (0.1.13): Fast Python linter
- **mypy** (1.8.0): Static type checker
- **pre-commit** (3.6.0): Git hook manager

## System Requirements

- **Python**: 3.11 or higher
- **PostgreSQL**: 14 or higher
- **Operating System**: Windows, Linux, or macOS

## PostgreSQL Setup

### Windows
```bash
# Download from https://www.postgresql.org/download/windows/
# Or use chocolatey
choco install postgresql
```

### Linux (Ubuntu/Debian)
```bash
sudo apt-get update
sudo apt-get install postgresql postgresql-contrib
```

### macOS
```bash
brew install postgresql
```

### Create Database and Schema

```sql
-- Connect to PostgreSQL
psql -U postgres

-- Create database
CREATE DATABASE pm_copilot_db;

-- Connect to the database
\c pm_copilot_db

-- Create schema
CREATE SCHEMA pm_copilot_macro_semantic;

-- Grant privileges (adjust username as needed)
GRANT ALL PRIVILEGES ON SCHEMA pm_copilot_macro_semantic TO your_username;
```

## Environment Setup

1. Copy the example environment file:
```bash
cp .env.example .env
```

2. Update the `.env` file with your database credentials and configuration

3. Ensure the PostgreSQL service is running:
```bash
# Windows
net start postgresql-x64-14

# Linux
sudo systemctl start postgresql

# macOS
brew services start postgresql
```

## Verification

Test your installation:

```bash
# Check Python version
python --version

# Check installed packages
poetry show  # or pip list

# Test database connection
python -c "import asyncpg; print('asyncpg installed successfully')"

# Run the application
poetry run uvicorn app.main:app --reload
```

## Troubleshooting

### Poetry Installation Issues
```bash
# Update Poetry
poetry self update

# Clear cache
poetry cache clear . --all
```

### PostgreSQL Connection Issues
- Verify PostgreSQL is running
- Check credentials in `.env` file
- Ensure database and schema exist
- Check firewall settings for port 5432

### Module Import Errors
```bash
# Reinstall dependencies
poetry install --no-cache

# Or with pip
pip install --force-reinstall -r requirements.txt
```

## Docker Alternative

If you prefer to avoid local installation, use Docker:

```bash
docker build -t pm-copilot-api .
docker run -p 8000:8000 --env-file .env pm-copilot-api
```

## Support

For issues or questions:
- Contact: Venkatesh Manikantan, Senior Associate, PwC India
- Project: PM Copilot for Nokia
