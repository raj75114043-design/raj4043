# Deployment Guide

**PM Copilot Global Context Layer**

**Developer:** Venkatesh Manikantan, Senior Associate, PwC India
**Client:** Nokia

## Table of Contents
1. [Local Development](#local-development)
2. [Docker Deployment](#docker-deployment)
3. [Production Deployment](#production-deployment)
4. [Database Setup](#database-setup)
5. [Environment Configuration](#environment-configuration)
6. [Monitoring & Logging](#monitoring--logging)
7. [Troubleshooting](#troubleshooting)

---

## Local Development

### Prerequisites
- Python 3.11+
- PostgreSQL 14+
- Poetry (or pip)

### Step 1: Clone and Setup

```bash
cd "d:\My-POC\Nokia_PM_Co_pilot\Global Context Layer"
```

### Step 2: Install Dependencies

**Using Poetry (Recommended):**
```bash
poetry install
poetry shell
```

**Using pip:**
```bash
pip install -r requirements.txt
```

### Step 3: Configure Environment

```bash
cp .env.example .env
```

Edit `.env` with your database credentials:
```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=pm_copilot_db
DB_USER=postgres
DB_PASSWORD=your_password
DB_SCHEMA=pm_copilot_macro_semantic
```

### Step 4: Setup Database

```bash
# Connect to PostgreSQL
psql -U postgres

# Create database
CREATE DATABASE pm_copilot_db;

# Connect to the database
\c pm_copilot_db

# Create schema
CREATE SCHEMA pm_copilot_macro_semantic;
```

### Step 5: Run Application

```bash
# With Poetry
poetry run uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# With Python directly
python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

### Step 6: Verify Installation

Open browser and navigate to:
- API: http://localhost:8000
- Swagger UI: http://localhost:8000/docs
- Health Check: http://localhost:8000/health

---

## Docker Deployment

### Single Container Deployment

#### Step 1: Build Docker Image

```bash
docker build -t pm-copilot-api:latest .
```

#### Step 2: Run Container

```bash
docker run -d \
  --name pm-copilot-api \
  -p 8000:8000 \
  --env-file .env \
  pm-copilot-api:latest
```

#### Step 3: Check Logs

```bash
docker logs -f pm-copilot-api
```

### Docker Compose Deployment (Recommended)

This method includes both the API and PostgreSQL database.

#### Step 1: Configure Environment

```bash
cp .env.example .env
```

Edit `.env` as needed.

#### Step 2: Start Services

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Check status
docker-compose ps
```

#### Step 3: Stop Services

```bash
docker-compose down

# To remove volumes as well
docker-compose down -v
```

#### Access Services
- API: http://localhost:8000
- PostgreSQL: localhost:5432

---

## Production Deployment

### Prerequisites
- Production PostgreSQL instance
- Container orchestration (Kubernetes, ECS, etc.) or VM
- Load balancer
- SSL certificates

### Step 1: Environment Configuration

Create production `.env` file:

```env
# Database Configuration (Use production values)
DB_HOST=prod-postgres.example.com
DB_PORT=5432
DB_NAME=pm_copilot_db
DB_USER=pm_copilot_user
DB_PASSWORD=strong_password_here
DB_SCHEMA=pm_copilot_macro_semantic

# Database Pool Configuration (Optimize for production)
DB_POOL_SIZE=50
DB_MAX_OVERFLOW=20
DB_POOL_TIMEOUT=30
DB_POOL_RECYCLE=3600

# Application Configuration
DEBUG=False
APP_NAME=PM Copilot Global Context Layer
APP_VERSION=1.0.0

# Server Configuration
HOST=0.0.0.0
PORT=8000
WORKERS=4

# CORS Configuration (Restrict to your domains)
CORS_ORIGINS=["https://your-domain.com", "https://api.your-domain.com"]

# Security
SECRET_KEY=generate-a-strong-secret-key-here
API_KEY=generate-an-api-key-for-authentication

# Logging
LOG_LEVEL=INFO
LOG_FORMAT=json
```

### Step 2: Database Setup

```sql
-- Create dedicated database user
CREATE USER pm_copilot_user WITH PASSWORD 'strong_password';

-- Create database
CREATE DATABASE pm_copilot_db OWNER pm_copilot_user;

-- Connect to database
\c pm_copilot_db

-- Create schema
CREATE SCHEMA pm_copilot_macro_semantic;

-- Grant privileges
GRANT ALL PRIVILEGES ON SCHEMA pm_copilot_macro_semantic TO pm_copilot_user;
```

### Step 3: Build Production Image

```bash
docker build -t pm-copilot-api:1.0.0 -t pm-copilot-api:latest .
```

### Step 4: Push to Container Registry

```bash
# Tag for your registry
docker tag pm-copilot-api:1.0.0 your-registry.com/pm-copilot-api:1.0.0

# Push
docker push your-registry.com/pm-copilot-api:1.0.0
```

### Step 5: Deploy to Production

**Kubernetes Example:**

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: pm-copilot-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: pm-copilot-api
  template:
    metadata:
      labels:
        app: pm-copilot-api
    spec:
      containers:
      - name: api
        image: your-registry.com/pm-copilot-api:1.0.0
        ports:
        - containerPort: 8000
        envFrom:
        - secretRef:
            name: pm-copilot-secrets
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 5
```

**Docker Swarm Example:**

```bash
docker stack deploy -c docker-compose.prod.yml pm-copilot
```

---

## Database Setup

### Schema Creation

The application automatically creates tables on startup. However, for production, use migrations.

### Using Alembic for Migrations

#### Step 1: Initialize Alembic

```bash
alembic init alembic
```

#### Step 2: Configure Alembic

Edit `alembic/env.py`:

```python
from app.core.config import settings
from app.db.database import Base
from app.models.models import *

config.set_main_option("sqlalchemy.url", settings.sync_database_url)
target_metadata = Base.metadata
```

#### Step 3: Create Migration

```bash
alembic revision --autogenerate -m "Initial migration"
```

#### Step 4: Apply Migration

```bash
alembic upgrade head
```

---

## Environment Configuration

### Required Variables

| Variable | Description | Required | Default |
|----------|-------------|----------|---------|
| DB_HOST | Database host | Yes | localhost |
| DB_PORT | Database port | Yes | 5432 |
| DB_NAME | Database name | Yes | pm_copilot_db |
| DB_USER | Database user | Yes | postgres |
| DB_PASSWORD | Database password | Yes | - |
| DB_SCHEMA | Schema name | Yes | pm_copilot_macro_semantic |

### Optional Variables

| Variable | Description | Default |
|----------|-------------|---------|
| DB_POOL_SIZE | Connection pool size | 20 |
| DB_MAX_OVERFLOW | Max overflow connections | 10 |
| DEBUG | Debug mode | False |
| WORKERS | Number of workers | 4 |
| LOG_LEVEL | Logging level | INFO |

---

## Monitoring & Logging

### Health Checks

The application provides health check endpoints:

- `/health` - Detailed health status
- `/` - Basic status

### Logging

Application uses structured JSON logging in production.

**Log Levels:**
- `DEBUG` - Development only
- `INFO` - General information
- `WARNING` - Warning messages
- `ERROR` - Error messages

### Metrics (Future Enhancement)

Consider integrating:
- Prometheus for metrics
- Grafana for dashboards
- ELK stack for log aggregation

---

## Troubleshooting

### Issue: Cannot connect to database

**Solution:**
1. Verify database is running: `pg_isready -h localhost -p 5432`
2. Check credentials in `.env`
3. Verify schema exists
4. Check firewall rules

### Issue: Tables not created

**Solution:**
```bash
# Connect to database
psql -U postgres -d pm_copilot_db

# Verify schema
\dn

# Check if tables exist
\dt pm_copilot_macro_semantic.*
```

### Issue: Connection pool exhausted

**Solution:**
Increase pool size in `.env`:
```env
DB_POOL_SIZE=50
DB_MAX_OVERFLOW=20
```

### Issue: High memory usage

**Solution:**
1. Reduce number of workers
2. Optimize queries
3. Implement pagination
4. Add caching layer

### Issue: Slow queries

**Solution:**
1. Add database indexes
2. Optimize search queries
3. Use connection pooling
4. Enable query caching

### View Application Logs

**Docker:**
```bash
docker logs -f pm-copilot-api
```

**Docker Compose:**
```bash
docker-compose logs -f api
```

**Kubernetes:**
```bash
kubectl logs -f deployment/pm-copilot-api
```

---

## Security Considerations

### Production Checklist

- [ ] Change default passwords
- [ ] Use strong SECRET_KEY
- [ ] Implement API authentication
- [ ] Enable HTTPS/TLS
- [ ] Restrict CORS origins
- [ ] Use environment variables for secrets
- [ ] Enable database SSL
- [ ] Implement rate limiting
- [ ] Set up firewall rules
- [ ] Regular security updates
- [ ] Implement logging and monitoring
- [ ] Use non-root user in containers
- [ ] Scan images for vulnerabilities

---

## Backup & Recovery

### Database Backup

```bash
# Backup
pg_dump -U postgres -d pm_copilot_db -F c -f backup.dump

# Restore
pg_restore -U postgres -d pm_copilot_db backup.dump
```

### Automated Backups

Set up automated backups using cron or cloud provider tools.

---

## Scaling

### Horizontal Scaling

- Run multiple API instances behind a load balancer
- Use container orchestration (Kubernetes, ECS)
- Implement session affinity if needed

### Database Scaling

- Use read replicas for read-heavy workloads
- Implement connection pooling
- Consider database sharding for very large datasets

---

## Support

For deployment issues or questions:
- **Developer:** Venkatesh Manikantan
- **Organization:** PwC India
- **Client:** Nokia

---

## Additional Resources

- [API Documentation](API_DOCUMENTATION.md)
- [Dependencies Guide](DEPENDENCIES.md)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
