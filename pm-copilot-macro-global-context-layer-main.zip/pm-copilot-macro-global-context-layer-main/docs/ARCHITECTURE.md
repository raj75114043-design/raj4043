# Architecture Overview

**PM Copilot Global Context Layer**

**Developer:** Venkatesh Manikantan, Senior Associate, PwC India
**Client:** Nokia

---

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     LLM-Based Agent Microservices                │
│        (Query Agent, RCA Agent, Simulation Agent, etc.)          │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ HTTP/REST API
                         │
┌────────────────────────▼────────────────────────────────────────┐
│                  PM Copilot Global Context Layer                 │
│                         FastAPI Application                       │
├──────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────────┐  ┌─────────────┐  ┌──────────────┐            │
│  │   KPI API   │  │ Keywords API│  │ Question Bank│            │
│  │  Endpoints  │  │  Endpoints  │  │   Endpoints  │            │
│  └─────────────┘  └─────────────┘  └──────────────┘            │
│                                                                   │
│  ┌─────────────┐  ┌─────────────┐  ┌──────────────┐            │
│  │   RCA API   │  │Simulation   │  │   Search &   │            │
│  │  Endpoints  │  │  Endpoints  │  │    Query     │            │
│  └─────────────┘  └─────────────┘  └──────────────┘            │
│                                                                   │
│  ┌────────────────────────────────────────────────────┐         │
│  │          Database Connection Pool Manager           │         │
│  │        (AsyncPG + SQLAlchemy 2.0 Async ORM)        │         │
│  └────────────────────────────────────────────────────┘         │
│                                                                   │
└────────────────────────┬────────────────────────────────────────┘
                         │
                         │ Async PostgreSQL Protocol
                         │
┌────────────────────────▼────────────────────────────────────────┐
│                     PostgreSQL Database                          │
│                  Schema: pm_copilot_macro_semantic               │
├──────────────────────────────────────────────────────────────────┤
│  ┌─────────┐  ┌──────────┐  ┌───────────────┐  ┌──────┐       │
│  │   KPI   │  │ Keywords │  │ Question Bank │  │ RCA  │       │
│  │  Table  │  │  Table   │  │     Table     │  │Table │       │
│  └─────────┘  └──────────┘  └───────────────┘  └──────┘       │
│                                                                   │
│  ┌─────────────┐                                                 │
│  │ Simulation  │                                                 │
│  │    Table    │                                                 │
│  └─────────────┘                                                 │
└──────────────────────────────────────────────────────────────────┘
```

---

## Layered Architecture

### 1. Presentation Layer (API Endpoints)

```
app/api/endpoints/
├── kpi.py           # KPI CRUD operations
├── keywords.py      # Keywords CRUD operations
├── question_bank.py # Question Bank CRUD operations
├── rca.py           # RCA CRUD operations
├── simulation.py    # Simulation CRUD operations
└── search.py        # Global search and statistics
```

**Responsibilities:**
- HTTP request/response handling
- Input validation
- Output serialization
- Error handling
- Route definitions

### 2. Business Logic Layer (Schemas & Validation)

```
app/schemas/schemas.py
├── KPICreate, KPIUpdate, KPIResponse
├── KeywordCreate, KeywordUpdate, KeywordResponse
├── QuestionBankCreate, QuestionBankUpdate, QuestionBankResponse
├── RCACreate, RCAUpdate, RCAResponse
├── SimulationCreate, SimulationUpdate, SimulationResponse
└── MessageResponse, PaginatedResponse
```

**Responsibilities:**
- Data validation
- Type checking
- Request/response models
- Business rules enforcement

### 3. Data Access Layer (Models & Database)

```
app/models/models.py
├── KPI (SQLAlchemy Model)
├── Keyword (SQLAlchemy Model)
├── QuestionBank (SQLAlchemy Model)
├── RCA (SQLAlchemy Model)
└── Simulation (SQLAlchemy Model)

app/db/database.py
├── Engine (with connection pooling)
├── AsyncSessionLocal (session factory)
├── get_db() (dependency injection)
└── init_db(), close_db()
```

**Responsibilities:**
- Database connection management
- ORM mapping
- Query execution
- Transaction management
- Connection pooling

### 4. Configuration Layer

```
app/core/config.py
└── Settings (Pydantic BaseSettings)
    ├── Database configuration
    ├── Application configuration
    ├── Server configuration
    ├── CORS configuration
    └── Security configuration
```

**Responsibilities:**
- Environment variable management
- Configuration validation
- Settings centralization

---

## Request Flow

```
┌────────┐
│ Client │
└───┬────┘
    │ 1. HTTP Request
    ▼
┌───────────────────┐
│ FastAPI Router    │
│ (app/main.py)     │
└───┬───────────────┘
    │ 2. Route to endpoint
    ▼
┌───────────────────┐
│ API Endpoint      │
│ (app/api/...)     │
└───┬───────────────┘
    │ 3. Validate with Pydantic
    ▼
┌───────────────────┐
│ Pydantic Schema   │
│ (app/schemas/)    │
└───┬───────────────┘
    │ 4. Get DB session
    ▼
┌───────────────────┐
│ Database Session  │
│ (dependency)      │
└───┬───────────────┘
    │ 5. Execute query
    ▼
┌───────────────────┐
│ SQLAlchemy Model  │
│ (app/models/)     │
└───┬───────────────┘
    │ 6. Database operation
    ▼
┌───────────────────┐
│ PostgreSQL        │
└───┬───────────────┘
    │ 7. Return data
    ▼
┌───────────────────┐
│ Serialize response│
│ (Pydantic)        │
└───┬───────────────┘
    │ 8. HTTP Response
    ▼
┌────────┐
│ Client │
└────────┘
```

---

## Database Schema Design

### Entity Relationship

```
┌─────────────────────────────────────────┐
│                   KPI                    │
├─────────────────────────────────────────┤
│ kpi_id (PK)                             │
│ kpi_name                                 │
│ description                              │
│ formula                                  │
│ mapped_tables_columns                    │
│ logic                                    │
│ root_cause_positive                      │
│ root_cause_negative                      │
│ created_at, updated_at                   │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│                Keywords                  │
├─────────────────────────────────────────┤
│ keyword_id (PK)                         │
│ keyword_name                             │
│ keyword_description                      │
│ mapped_tables_columns                    │
│ logic                                    │
│ synonyms                                 │
│ created_at, updated_at                   │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│             Question Bank                │
├─────────────────────────────────────────┤
│ question_id (PK)                        │
│ question                                 │
│ sql                                      │
│ created_at, updated_at                   │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│                  RCA                     │
├─────────────────────────────────────────┤
│ problem_id (PK)                         │
│ rca_question                             │
│ type_of_rca_question (ENUM)             │
│ root_causes (ARRAY)                      │
│ root_cause_sudo_sql_schema               │
│ relevant_kpis                            │
│ steps_to_get_data_sql (ARRAY)           │
│ recommendation_area                      │
│ output_preferred_template                │
│ created_at, updated_at                   │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│              Simulation                  │
├─────────────────────────────────────────┤
│ scenario_id (PK)                        │
│ scenario                                 │
│ data_phase_steps (ARRAY)                │
│ data_phase_questions (ARRAY)            │
│ calculation_phase_steps (ARRAY)         │
│ simulator_phase_steps (ARRAY)           │
│ simulation_methodology                   │
│ created_at, updated_at                   │
└─────────────────────────────────────────┘
```

### Indexes

All tables have:
- Primary key index (automatically created)
- Index on name/question fields for search performance
- Timestamp indexes for temporal queries

---

## Connection Pooling Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                    FastAPI Application                        │
│                      (Multiple Workers)                       │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐        │
│  │Worker 1 │  │Worker 2 │  │Worker 3 │  │Worker N │        │
│  └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘        │
│       │            │            │            │               │
│       └────────────┴────────────┴────────────┘               │
│                          │                                    │
│                          ▼                                    │
│       ┌──────────────────────────────────────────┐           │
│       │      SQLAlchemy Connection Pool          │           │
│       │                                           │           │
│       │  ┌──────┐  ┌──────┐  ┌──────┐          │           │
│       │  │Conn 1│  │Conn 2│  │Conn N│  ...     │           │
│       │  └──────┘  └──────┘  └──────┘          │           │
│       │                                           │           │
│       │  Pool Size: 20 (configurable)            │           │
│       │  Max Overflow: 10 (configurable)         │           │
│       │  Pool Timeout: 30s                       │           │
│       │  Pool Recycle: 3600s                     │           │
│       └──────────────────┬───────────────────────┘           │
│                          │                                    │
└──────────────────────────┼────────────────────────────────────┘
                           │
                           ▼
                ┌────────────────────┐
                │    PostgreSQL      │
                │     Database       │
                └────────────────────┘
```

**Benefits:**
- Reduced connection overhead
- Better resource utilization
- Automatic connection recycling
- Connection health checks (pre_ping)
- Configurable pool size based on load

---

## Async Architecture

```
┌─────────────────────────────────────────────────────┐
│              Async Request Handling                  │
├─────────────────────────────────────────────────────┤
│                                                      │
│  Request 1 ──┐                                      │
│              ├──▶ Async Handler ──▶ await DB ──┐   │
│  Request 2 ──┤                                  │   │
│              │                                  │   │
│  Request 3 ──┤                                  │   │
│              │                                  ▼   │
│  Request N ──┘                            Event Loop│
│                                                 │   │
│                    ┌────────────────────────────┘   │
│                    │                                │
│                    ▼                                │
│            PostgreSQL Database                      │
│                                                      │
└─────────────────────────────────────────────────────┘

Benefits:
- Non-blocking I/O operations
- High concurrency with low resource usage
- Efficient handling of multiple simultaneous requests
- Better scalability
```

---

## Deployment Architecture

### Docker Deployment

```
┌────────────────────────────────────────────────────┐
│                   Docker Host                       │
├────────────────────────────────────────────────────┤
│                                                     │
│  ┌──────────────────────┐  ┌──────────────────┐   │
│  │   API Container      │  │ PostgreSQL       │   │
│  │                      │  │  Container       │   │
│  │  ┌────────────────┐  │  │                  │   │
│  │  │ FastAPI App    │  │  │  ┌────────────┐  │   │
│  │  │ (Port 8000)    │  │  │  │ Database   │  │   │
│  │  └────────────────┘  │  │  │ (Port 5432)│  │   │
│  │                      │  │  └────────────┘  │   │
│  └──────────┬───────────┘  └──────────────────┘   │
│             │                                       │
│             │  pm-copilot-network (Bridge)          │
│             │                                       │
└─────────────┼───────────────────────────────────────┘
              │
              ▼
        External Access
      (http://localhost:8000)
```

### Production Deployment (Kubernetes)

```
┌────────────────────────────────────────────────────────┐
│                    Kubernetes Cluster                   │
├────────────────────────────────────────────────────────┤
│                                                         │
│  ┌─────────────────────────────────────────────────┐   │
│  │              Load Balancer / Ingress            │   │
│  └────────────────────┬────────────────────────────┘   │
│                       │                                 │
│       ┌───────────────┼───────────────┐                │
│       │               │               │                │
│  ┌────▼────┐    ┌────▼────┐    ┌────▼────┐           │
│  │  API    │    │  API    │    │  API    │           │
│  │  Pod 1  │    │  Pod 2  │    │  Pod 3  │           │
│  └─────────┘    └─────────┘    └─────────┘           │
│       │               │               │                │
│       └───────────────┼───────────────┘                │
│                       │                                 │
│                       ▼                                 │
│            ┌────────────────────┐                      │
│            │  PostgreSQL Service│                      │
│            │  (Managed/External)│                      │
│            └────────────────────┘                      │
│                                                         │
└────────────────────────────────────────────────────────┘
```

---

## Security Architecture

```
┌─────────────────────────────────────────────────────┐
│                Security Layers                       │
├─────────────────────────────────────────────────────┤
│                                                      │
│  1. Network Layer                                   │
│     ├─ HTTPS/TLS                                    │
│     ├─ Firewall rules                               │
│     └─ CORS configuration                           │
│                                                      │
│  2. Application Layer                               │
│     ├─ API key authentication (future)              │
│     ├─ Input validation (Pydantic)                  │
│     ├─ SQL injection prevention                     │
│     └─ Error message sanitization                   │
│                                                      │
│  3. Database Layer                                  │
│     ├─ Parameterized queries                        │
│     ├─ User privilege management                    │
│     ├─ SSL connections                              │
│     └─ Schema isolation                             │
│                                                      │
│  4. Container Layer                                 │
│     ├─ Non-root user                                │
│     ├─ Minimal base image                           │
│     ├─ Security scanning                            │
│     └─ Resource limits                              │
│                                                      │
└─────────────────────────────────────────────────────┘
```

---

## Monitoring Architecture

```
┌─────────────────────────────────────────────────────┐
│                  Observability Stack                 │
├─────────────────────────────────────────────────────┤
│                                                      │
│  ┌────────────────┐    ┌─────────────────┐         │
│  │   Metrics      │    │     Logs        │         │
│  │  (Prometheus)  │    │   (ELK Stack)   │         │
│  └────────┬───────┘    └────────┬────────┘         │
│           │                     │                   │
│           ▼                     ▼                   │
│  ┌─────────────────────────────────────────┐       │
│  │         Grafana Dashboard                │       │
│  │  - API response times                    │       │
│  │  - Request rates                         │       │
│  │  - Error rates                           │       │
│  │  - Database pool usage                   │       │
│  │  - Resource utilization                  │       │
│  └─────────────────────────────────────────┘       │
│                                                      │
│  ┌────────────────┐    ┌─────────────────┐         │
│  │   Tracing      │    │  Health Checks  │         │
│  │   (Jaeger)     │    │  (/health)      │         │
│  └────────────────┘    └─────────────────┘         │
│                                                      │
└─────────────────────────────────────────────────────┘
```

---

## Data Flow Patterns

### Create Operation
```
Client → POST /api/v1/kpi → Validate → Insert → Return 201
```

### Read Operation
```
Client → GET /api/v1/kpi → Query → Serialize → Return 200
```

### Update Operation
```
Client → PUT /api/v1/kpi/{id} → Find → Update → Return 200
```

### Delete Operation
```
Client → DELETE /api/v1/kpi/{id} → Find → Delete → Return 200
```

### Search Operation
```
Client → GET /api/v1/search/global → Query All Tables →
Aggregate → Return Results
```

---

## Scalability Considerations

### Horizontal Scaling
- Stateless API design
- Multiple application instances
- Load balancer distribution
- Session-less architecture

### Vertical Scaling
- Configurable connection pool
- Worker process optimization
- Resource allocation

### Database Scaling
- Read replicas for queries
- Write master for updates
- Connection pooling
- Query optimization

---

## Performance Optimizations

1. **Connection Pooling**: Reuse database connections
2. **Async Operations**: Non-blocking I/O
3. **Pagination**: Limit data transfer
4. **Indexes**: Fast data retrieval
5. **Caching**: (Future) Redis for frequent queries
6. **Query Optimization**: Efficient SQL queries
7. **Compression**: (Future) Response compression

---

## Conclusion

The PM Copilot Global Context Layer employs a modern, layered architecture with clear separation of concerns, async operations, connection pooling, and comprehensive error handling. The system is designed for high performance, scalability, and maintainability.

---

**Developer:** Venkatesh Manikantan, Senior Associate, PwC India
**Client:** Nokia
