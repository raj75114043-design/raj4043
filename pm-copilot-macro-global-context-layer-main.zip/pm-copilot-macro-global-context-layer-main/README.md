# PM Copilot - Global Context Layer

**Project by:** PwC India
**Primary Developer** Venkatesh Manikantan, Senior Associate, PwC India
**Secondary Developer & Maintainer** Advait Shah, Assocaite, PwC India
**Client:** Nokia

## Overview

PM Copilot Global Context Layer is a centralized knowledge management system designed to maintain and serve critical information for Nokia's LLM-based Agent microservices. This application provides a comprehensive API for managing KPIs, question banks, keywords/synonyms, RCA (Root Cause Analysis) semantics, and simulation agent configurations.

## Purpose

This centralized knowledge layer enables:
- **Unified Knowledge Management**: Single source of truth for KPIs, questions, keywords, RCA, and simulation configurations
- **Dynamic Search**: Advanced search capabilities for LLM-based agents to query semantic information
- **Scalability**: Supports growth and evolution of the knowledge base
- **Integration**: RESTful API for seamless integration with microservices

## Architecture

### Database Schema
- **Database**: PostgreSQL
- **Schema**: `pm_copilot_macro_semantic`
- **Tables**:
  - `kpi` - Key Performance Indicators
  - `keywords` - Keywords and synonyms mapping
  - `question_bank` - Question-to-SQL mappings
  - `rca` - Root Cause Analysis configurations
  - `simulation` - Simulation scenario definitions

### Technology Stack
- **Framework**: FastAPI (Python)
- **Database**: PostgreSQL with asyncpg
- **ORM**: SQLAlchemy 2.0
- **Dependency Management**: Poetry
- **Containerization**: Docker

## Features

### CRUD Operations
- Full Create, Read, Update, Delete operations for all tables
- Bulk operations support
- Data validation and error handling

### Search & Query
- Advanced search across all knowledge domains
- Filtering and pagination
- Semantic search capabilities

### API Documentation
- Auto-generated OpenAPI/Swagger documentation
- Interactive API testing interface
- Comprehensive endpoint descriptions

## Quick Start

### Prerequisites
- Python 3.11+
- PostgreSQL 14+
- Docker (optional)

### Installation

1. Clone the repository
2. Install dependencies (see DEPENDENCIES.md)
3. Configure environment variables (see .env.example)
4. Run the application

```bash
# Using Poetry
poetry install
poetry run uvicorn main:app --reload

# Using Docker
docker build -t pm-copilot-api .
docker run -p 8000:8000 pm-copilot-api
```

### Access API Documentation

Once running, access:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## Project Structure

```
Global Context Layer/
├── app/
│   ├── api/
│   │   └── endpoints/
│   ├── core/
│   ├── db/
│   ├── models/
│   ├── schemas/
│   └── main.py
├── Dockerfile
├── pyproject.toml
├── .env.example
└── README.md
```

## API Endpoints

### KPI Management
- `GET /api/v1/kpi` - List all KPIs
- `POST /api/v1/kpi` - Create new KPI
- `GET /api/v1/kpi/{kpi_id}` - Get KPI by ID
- `PUT /api/v1/kpi/{kpi_id}` - Update KPI
- `DELETE /api/v1/kpi/{kpi_id}` - Delete KPI

### Keywords Management
- `GET /api/v1/keywords` - List all keywords
- `POST /api/v1/keywords` - Create new keyword
- Similar CRUD operations

### Question Bank
- Complete CRUD operations for question-SQL mappings

### RCA Management
- Root Cause Analysis configuration endpoints

### Simulation Management
- Simulation scenario configuration endpoints

### Search
- `GET /api/v1/search/global` - Global search across all tables
- `GET /api/v1/search/table/{table_name}` - Table-specific search
- `GET /api/v1/search/statistics` - Get table statistics

### Semantic Search
- `POST /api/v1/semantic/search` - Vector-based semantic search
- `POST /api/v1/semantic/regenerate-embeddings/{table_name}` - Regenerate embeddings

---

## Search API Documentation (For Agent Microservices)

This section provides detailed documentation for integrating with the Global Context Layer search endpoints. These endpoints are designed for LLM-based agent microservices to query semantic information.

### Quick Reference

| Endpoint | Method | Use Case |
|----------|--------|----------|
| `/api/v1/search/global` | GET | Fast keyword search across all tables |
| `/api/v1/search/table/{table_name}` | GET | Keyword search in a specific table with pagination |
| `/api/v1/semantic/search` | POST | AI-powered semantic similarity search |

---

### 1. Global Search Endpoint

Search across all semantic tables (KPI, Keywords, Question Bank, RCA, Simulation) using keyword matching.

**Endpoint:** `GET /api/v1/search/global`

**Query Parameters:**

| Parameter | Type | Required | Default | Constraints | Description |
|-----------|------|----------|---------|-------------|-------------|
| `query` | string | Yes | - | min_length=1 | Search query string |
| `limit` | integer | No | 50 | 1-500 | Maximum results per table |

**Example Request:**
```bash
curl -X GET "http://localhost:8000/api/v1/search/global?query=customer%20churn&limit=20"
```

**Example Response:**
```json
{
    "kpis": [
        {
            "kpi_id": 1,
            "kpi_name": "Customer Churn Rate",
            "description": "Percentage of customers who stopped using the service",
            "formula": "(Lost Customers / Total Customers) * 100"
        }
    ],
    "keywords": [
        {
            "keyword_id": 5,
            "keyword_name": "churn",
            "keyword_description": "Customer attrition or turnover",
            "synonyms": "attrition, turnover, customer loss"
        }
    ],
    "questions": [
        {
            "question_id": 12,
            "question": "What is the monthly customer churn rate?",
            "sql": "SELECT month, churn_rate FROM customer_metrics..."
        }
    ],
    "rca": [
        {
            "problem_id": 3,
            "rca_question": "Why are customers churning?",
            "type_of_rca_question": "General RCA",
            "recommendation_area": "Customer Retention"
        }
    ],
    "simulations": [],
    "summary": {
        "total_results": 4,
        "kpi_count": 1,
        "keyword_count": 1,
        "question_count": 1,
        "rca_count": 1,
        "simulation_count": 0
    }
}
```

---

### 2. Table-Specific Search Endpoint

Search within a specific table with pagination support.

**Endpoint:** `GET /api/v1/search/table/{table_name}`

**Path Parameters:**

| Parameter | Type | Valid Values |
|-----------|------|--------------|
| `table_name` | string | `kpi`, `keywords`, `question_bank`, `rca`, `simulation` |

**Query Parameters:**

| Parameter | Type | Required | Default | Constraints | Description |
|-----------|------|----------|---------|-------------|-------------|
| `query` | string | Yes | - | min_length=1 | Search query string |
| `skip` | integer | No | 0 | >= 0 | Number of records to skip (offset) |
| `limit` | integer | No | 100 | 1-1000 | Maximum records to return |

**Searchable Fields by Table:**

| Table | Searchable Fields |
|-------|-------------------|
| `kpi` | kpi_name, description, formula, logic |
| `keywords` | keyword_name, keyword_description, synonyms, logic |
| `question_bank` | question, sql |
| `rca` | rca_question, recommendation_area, relevant_kpis |
| `simulation` | scenario, simulation_methodology |

**Example Request:**
```bash
curl -X GET "http://localhost:8000/api/v1/search/table/kpi?query=revenue&skip=0&limit=10"
```

**Example Response:**
```json
{
    "table": "kpi",
    "results": [
        {
            "kpi_id": 7,
            "kpi_name": "Average Revenue Per User",
            "description": "Mean revenue generated per active user",
            "formula": "Total Revenue / Active Users"
        }
    ],
    "count": 1
}
```

---

### 3. Semantic Search Endpoint (Recommended for LLM Agents)

Perform AI-powered semantic search using vector embeddings and cosine similarity. This endpoint is ideal for natural language queries where exact keyword matching may not capture intent.

**Endpoint:** `POST /api/v1/semantic/search`

**Request Body:**

| Field | Type | Required | Default | Constraints | Description |
|-------|------|----------|---------|-------------|-------------|
| `query` | string | Yes | - | min_length=1 | Natural language search query |
| `table` | string | No | null | `kpi`, `question_bank`, `rca`, `simulation` | Target table (null = search all) |
| `top_k` | integer | No | 10 | 1-100 | Number of results to return |

**Example Request:**
```bash
curl -X POST "http://localhost:8000/api/v1/semantic/search" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "What factors influence customer satisfaction and retention?",
    "table": null,
    "top_k": 5
  }'
```

**Example Response:**
```json
{
    "query": "What factors influence customer satisfaction and retention?",
    "total_results": 5,
    "results": [
        {
            "table": "rca",
            "id": 15,
            "content": {
                "problem_id": 15,
                "rca_question": "What are the main drivers of customer dissatisfaction?",
                "type_of_rca_question": "General RCA",
                "recommendation_area": "Customer Experience"
            },
            "similarity_score": 0.9234
        },
        {
            "table": "kpi",
            "id": 8,
            "content": {
                "kpi_id": 8,
                "kpi_name": "Net Promoter Score",
                "description": "Customer loyalty and satisfaction metric",
                "formula": "% Promoters - % Detractors"
            },
            "similarity_score": 0.8756
        }
    ]
}
```

**Python Integration Example:**
```python
import httpx

async def semantic_search(query: str, table: str = None, top_k: int = 10):
    """
    Search the Global Context Layer using semantic similarity.

    Args:
        query: Natural language search query
        table: Optional specific table to search (kpi, question_bank, rca, simulation)
        top_k: Number of results to return (default: 10)

    Returns:
        List of semantically similar results with similarity scores
    """
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "http://global-context-layer:8000/api/v1/semantic/search",
            json={
                "query": query,
                "table": table,
                "top_k": top_k
            }
        )
        return response.json()

# Usage
results = await semantic_search(
    query="How to improve network latency?",
    table="rca",
    top_k=5
)

for result in results["results"]:
    print(f"[{result['similarity_score']:.2f}] {result['table']}: {result['content']}")
```

---

### 4. Statistics Endpoint

Get record counts and statistics for all tables.

**Endpoint:** `GET /api/v1/search/statistics`

**Example Request:**
```bash
curl -X GET "http://localhost:8000/api/v1/search/statistics"
```

**Example Response:**
```json
{
    "total_kpis": 150,
    "total_keywords": 500,
    "total_questions": 200,
    "total_rca": 75,
    "total_simulations": 30,
    "rca_by_type": {
        "General RCA": 40,
        "Recommendation": 25,
        "Escalation": 10
    },
    "total_records": 955
}
```

---

### When to Use Which Endpoint

| Scenario | Recommended Endpoint |
|----------|---------------------|
| User asks a natural language question | `POST /semantic/search` |
| Looking for exact KPI names or keywords | `GET /search/global` or `/search/table/{table}` |
| Need paginated results from a specific table | `GET /search/table/{table_name}` |
| Initial discovery of what data exists | `GET /search/statistics` |
| Agent needs to find relevant SQL queries | `POST /semantic/search` with `table: "question_bank"` |
| Agent needs RCA recommendations | `POST /semantic/search` with `table: "rca"` |

---

### Error Handling

All endpoints return standard HTTP status codes:

| Status Code | Description |
|-------------|-------------|
| 200 | Success |
| 400 | Bad Request (invalid parameters) |
| 404 | Not Found (invalid table name) |
| 500 | Internal Server Error |

**Error Response Format:**
```json
{
    "detail": "Error message describing what went wrong"
}
```

---

## Contributing

This project is developed and maintained by PwC India for Nokia.

## License

Proprietary - PwC India © 2026

## Contact

For questions or support, please contact:
- **Venkatesh Manikantan** - Senior Associate, PwC India
