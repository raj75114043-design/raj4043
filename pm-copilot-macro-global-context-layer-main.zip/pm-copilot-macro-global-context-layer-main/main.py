"""
Main FastAPI application for PM Copilot Global Context Layer
Author: Venkatesh Manikantan, Senior Associate, PwC India
Client: Nokia
"""

import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.core.config import settings
from app.db.database import init_db, close_db
from app.api.endpoints import kpi, keywords, question_bank, rca, simulation, search, semantic_search, database, dev_utils, escalation
from app.services.embedding_service import embedding_service


# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Lifespan context manager for startup and shutdown events
    """
    # ==================== STARTUP ====================
    logger.info("=" * 60)
    logger.info("PM Copilot Global Context Layer - Starting Up")
    logger.info("=" * 60)
    logger.info(f"Application: {settings.app_name} v{settings.app_version}")
    logger.info(f"Debug Mode: {settings.debug}")
    logger.info("-" * 60)

    # Database configuration logging
    logger.info("Database Configuration:")
    logger.info(f"  Host: {settings.db_host}:{settings.db_port}")
    logger.info(f"  Database: {settings.db_name}")
    logger.info(f"  Schema: {settings.db_schema}")
    logger.info(f"  Pool Size: {settings.db_pool_min_size} (min) / {settings.db_pool_max_size} (max)")
    logger.info("-" * 60)

    # Initialize database connection pool
    logger.info("Initializing database connection pool...")
    await init_db()

    logger.info("-" * 60)
    logger.info("Startup complete - API ready to serve requests")
    logger.info("=" * 60)

    yield

    # ==================== SHUTDOWN ====================
    logger.info("=" * 60)
    logger.info("PM Copilot Global Context Layer - Shutting Down")
    logger.info("=" * 60)
    logger.info("Closing database connections...")
    await close_db()
    logger.info("Database connections closed")
    logger.info("Shutdown complete")
    logger.info("=" * 60)


# Initialize FastAPI application
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="""
    ## PM Copilot Global Context Layer API

    A centralized knowledge management system for Nokia's LLM-based Agent microservices.

    **Developed by:** Venkatesh Manikantan, Senior Associate, PwC India
    **Maintained by:** Advait Shah, Associate, PwC India

    ### Features:
    - **KPI Management**: Store and manage Key Performance Indicators with formulas and root causes
    - **Keywords & Synonyms**: Maintain keyword mappings and synonyms for semantic search
    - **Question Bank**: Map natural language questions to SQL queries
    - **RCA Configuration**: Root Cause Analysis scenarios and recommendations
    - **Simulation Scenarios**: Configure simulation methodologies and workflows
    - **Global Search**: Advanced search across all knowledge domains

    ### Key Capabilities:
    - Full CRUD operations for all knowledge domains
    - Connection pooling for optimal database performance
    - Pagination and filtering support
    - RESTful API design
    - Comprehensive error handling
    - Async/await for high concurrency

    ### Database:
    - PostgreSQL with schema: `pm_copilot_macro_semantic`
    - Optimized with connection pooling
    - Async operations with SQLAlchemy 2.0

    For more information, visit the [GitHub repository](https://gitlabe2.ext.net.nokia.com/aidigitalcentral/osdp-gsd/Solution/pm-copilot-macro-global-context-layer) or contact the development team.
    """,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Health check endpoint
@app.get("/", tags=["Health"])
async def root():
    """
    Root endpoint - API health check

    Returns basic API information and health status
    """
    return {
        "status": "healthy",
        "service": settings.app_name,
        "version": settings.app_version,
        "message": "PM Copilot Global Context Layer API is running",
        "developer": "Venkatesh Manikantan, Senior Associate, PwC India",
        "client": "Nokia",
        "docs": "/docs",
        "redoc": "/redoc"
    }


@app.get("/health", tags=["Health"])
async def health_check():
    """
    Detailed health check endpoint

    Returns comprehensive health status including database connectivity
    """

    ## Test Embedding Model ##
    try:
        embedding = await embedding_service.generate_embedding("test")
    except Exception as e:
        # Log but don't fail - embedding is optional
        logger.warning(f"Failed to generate embedding: {e}")

    if embedding:
        embedding_model_status = "OK"
    else:
        embedding_model_status = "Embedding Model Not Working!"

    return {
        "status": "healthy",
        "service": settings.app_name,
        "version": settings.app_version,
        "database": {
            "host": settings.db_host,
            "port": settings.db_port,
            "database": settings.db_name,
            "schema": settings.db_schema,
            "pool_min_size": settings.db_pool_min_size,
            "pool_max_size": settings.db_pool_max_size
        },
        "environment": {
            "debug": settings.debug,
            "host": settings.host,
            "port": settings.port
        },
        "embedding_model": {
            "embedding_model_url": settings.embed_api_url,
            "embedding_model_name": settings.embedding_model,
            "embedding_model_status": embedding_model_status,
            "embedding_model_workspace": settings.workspace_name
        }
    }


# Include routers with API v1 prefix
api_prefix = settings.api_v1_prefix

## CRUD API Routes ##
app.include_router(kpi.router, prefix=api_prefix)
app.include_router(keywords.router, prefix=api_prefix)
app.include_router(question_bank.router, prefix=api_prefix)
app.include_router(rca.router, prefix=api_prefix)
app.include_router(simulation.router, prefix=api_prefix)
app.include_router(escalation.router, prefix=api_prefix)

## Search Routes ##
app.include_router(search.router, prefix=api_prefix)
app.include_router(semantic_search.router, prefix=api_prefix)

## DataBase Management Routes ##
app.include_router(database.router, prefix=api_prefix)

## Dev Utility Tools ##
app.include_router(dev_utils.router, prefix=api_prefix)


# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """
    Global exception handler for unexpected errors
    """
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal Server Error",
            "detail": str(exc) if settings.debug else "An unexpected error occurred",
            "path": str(request.url)
        }
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        workers=1 if settings.debug else settings.workers
    )
