-- Migration 003: Project config table + dimension_key on KPI value tables
-- Enables per-project geo scoping and dynamic filter dimensions

BEGIN;

-- =========================================================================
-- 1. dim_project_config — per-project configuration
-- =========================================================================
CREATE TABLE IF NOT EXISTS pwc_derived_tables_schema.dim_project_config (
    project_id          VARCHAR(50) PRIMARY KEY,
    project_name        VARCHAR(200) NOT NULL,
    functions           TEXT[]       NOT NULL DEFAULT '{}',
    geo_codes           TEXT[]       NOT NULL DEFAULT '{}',
    filter_dimensions   JSONB        NOT NULL DEFAULT '{}',
    cross_filters       BOOLEAN      NOT NULL DEFAULT FALSE,
    is_active           BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE  pwc_derived_tables_schema.dim_project_config IS
    'Per-project configuration: applicable geos, functions, and filter dimensions';
COMMENT ON COLUMN pwc_derived_tables_schema.dim_project_config.geo_codes IS
    'Geo codes (natural keys) applicable to this project';
COMMENT ON COLUMN pwc_derived_tables_schema.dim_project_config.filter_dimensions IS
    'Dynamic filter dimensions, e.g. {"scope_of_work": ["NEW_BUILD","MODIFICATION"], "smp_name": ["SMP_ALPHA","SMP_BETA"]}';
COMMENT ON COLUMN pwc_derived_tables_schema.dim_project_config.cross_filters IS
    'If TRUE, calculation produces cartesian product of all dimension values; if FALSE, each dimension is independent';

-- =========================================================================
-- 2. Add dimension_key to kpi_values_live
-- =========================================================================
ALTER TABLE pwc_derived_tables_schema.kpi_values_live
    ADD COLUMN IF NOT EXISTS dimension_key VARCHAR(500) NOT NULL DEFAULT 'ALL';

-- Drop old unique constraint and recreate with dimension_key
ALTER TABLE pwc_derived_tables_schema.kpi_values_live
    DROP CONSTRAINT IF EXISTS uk_kpi_geo;

ALTER TABLE pwc_derived_tables_schema.kpi_values_live
    ADD CONSTRAINT uk_kpi_geo_dim UNIQUE (kpi_id, geo_id, dimension_key);

-- Index for fast dashboard lookups filtering by dimension
CREATE INDEX IF NOT EXISTS idx_live_dimension_key
    ON pwc_derived_tables_schema.kpi_values_live (dimension_key);

-- =========================================================================
-- 3. Add dimension_key to kpi_values_historical
-- =========================================================================
ALTER TABLE pwc_derived_tables_schema.kpi_values_historical
    ADD COLUMN IF NOT EXISTS dimension_key VARCHAR(500) NOT NULL DEFAULT 'ALL';

-- Index for comparison value prefetch queries
CREATE INDEX IF NOT EXISTS idx_hist_dimension_key
    ON pwc_derived_tables_schema.kpi_values_historical (dimension_key);

-- =========================================================================
-- 4. Seed initial project configs (adjust values to match your setup)
-- =========================================================================
INSERT INTO pwc_derived_tables_schema.dim_project_config
    (project_id, project_name, functions, geo_codes, filter_dimensions, cross_filters)
VALUES
    ('NTM', 'NTM', '{PDM,SECOE,HSE,DEC}', '{}', '{}', FALSE),
    ('NAS', 'NAS', '{PDM,SECOE,HSE}', '{}', '{}', FALSE),
    ('AHLOA', 'AHLOA', '{Phase}', '{}', '{}', FALSE)
ON CONFLICT (project_id) DO NOTHING;

COMMIT;