-- Migration 006: Add workflow configuration columns to dim_project_config
-- Enables per-project workflow-based site progress/status/phase calculation

ALTER TABLE pwc_derived_tables_schema.dim_project_config
    ADD COLUMN IF NOT EXISTS workflow_pipeline_name  VARCHAR(200) DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS workflow_join_key        VARCHAR(100) DEFAULT 'smp_id',
    ADD COLUMN IF NOT EXISTS workflow_selected_steps  JSONB        DEFAULT NULL;

COMMENT ON COLUMN pwc_derived_tables_schema.dim_project_config.workflow_pipeline_name
    IS 'Pipeline name from workflow API. NULL = workflow-based refresh disabled.';
COMMENT ON COLUMN pwc_derived_tables_schema.dim_project_config.workflow_join_key
    IS 'Column name for joining site_source_query to workflow step output tables (default: smp_id).';
COMMENT ON COLUMN pwc_derived_tables_schema.dim_project_config.workflow_selected_steps
    IS 'JSON array of selected step objects: [{"step_id": 0, "step_name": "...", "phase_name": "..."}].';
