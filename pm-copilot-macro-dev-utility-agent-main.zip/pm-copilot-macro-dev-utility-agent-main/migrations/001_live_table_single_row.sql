-----------------------------------------------------------------------------

BEGIN;

-- 1. Archive ALL current live rows to historical so nothing is lost.
INSERT INTO pwc_derived_tables_schema.kpi_values_historical (
    kpi_id, geo_id, geo_level,
    calculation_date, period_start_date, period_end_date,
    year, quarter, month, week,
    kpi_value, kpi_value_formatted,
    record_count, data_quality_score,
    previous_period_value, previous_year_value,
    period_on_period_change_pct, year_on_year_change_pct,
    calculation_job_id, calculated_at, archived_at
)
SELECT
    kpi_id, geo_id, geo_level,
    calculation_date, period_start_date, period_end_date,
    year, quarter, month, week,
    kpi_value, kpi_value_formatted,
    record_count, data_quality_score,
    previous_period_value, previous_year_value,
    period_on_period_change_pct, year_on_year_change_pct,
    calculation_job_id, calculated_at, CURRENT_TIMESTAMP
FROM pwc_derived_tables_schema.kpi_values_live
ON CONFLICT DO NOTHING;

-- 2. Keep only the most recent row per (kpi_id, geo_id) in live.
--    All older rows are already safely in historical.
DELETE FROM pwc_derived_tables_schema.kpi_values_live
WHERE (kpi_id, geo_id, calculation_date) NOT IN (
    SELECT kpi_id, geo_id, MAX(calculation_date)
    FROM pwc_derived_tables_schema.kpi_values_live
    GROUP BY kpi_id, geo_id
);

-- 3. Drop the old unique constraint on (kpi_id, geo_id, calculation_date).
ALTER TABLE pwc_derived_tables_schema.kpi_values_live
    DROP CONSTRAINT uk_kpi_geo_date;

-- 4. Add new unique constraint on (kpi_id, geo_id).
--    The application upserts use ON CONFLICT (kpi_id, geo_id) which requires this.
ALTER TABLE pwc_derived_tables_schema.kpi_values_live
    ADD CONSTRAINT uk_kpi_geo UNIQUE (kpi_id, geo_id);

COMMIT;
