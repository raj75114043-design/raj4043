

ALTER TABLE pwc_derived_tables_schema.kpi_master
    ADD COLUMN IF NOT EXISTS kpi_tag       VARCHAR(50)  DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS drilldown_sql TEXT         DEFAULT NULL;

COMMIT;
