-- ============================================================
-- Migration 004: dim_sites table + extend dim_project_config
-- ============================================================

BEGIN;

-- 1. Extend dim_project_config with site configuration columns
ALTER TABLE pwc_derived_tables_schema.dim_project_config
    ADD COLUMN IF NOT EXISTS site_source_query TEXT  DEFAULT NULL,
    ADD COLUMN IF NOT EXISTS site_columns      JSONB NOT NULL DEFAULT '{}',
    ADD COLUMN IF NOT EXISTS column_labels     JSONB NOT NULL DEFAULT '{}';

COMMENT ON COLUMN pwc_derived_tables_schema.dim_project_config.column_labels IS
    'UI display labels for site columns. Format: {"region_code": "Region", "area_code": "Area", "market_code": "Market", "phase": "Build Phase", "progress_pct": "% Complete", "status": "Site Status"}';

COMMENT ON COLUMN pwc_derived_tables_schema.dim_project_config.site_source_query IS
    'SQL query to pull raw site rows from source tables. Must return site_id at minimum. '
    'Optional fixed columns auto-detected: site_name, region_code, area_code, market_code, status, phase, progress_pct. '
    'Any extra columns listed in site_columns are stored in the attributes JSONB.';
COMMENT ON COLUMN pwc_derived_tables_schema.dim_project_config.site_columns IS
    'Column definitions for project-specific attributes stored in the attributes JSONB column. '
    'Format: {"col_name": {"type": "string|integer|numeric|boolean|date", "label": "...", "filterable": true|false}}';

-- 2. Create dim_sites materialized table
CREATE TABLE IF NOT EXISTS pwc_derived_tables_schema.dim_sites (
    site_id         VARCHAR(100)    NOT NULL,
    project_id      VARCHAR(50)     NOT NULL,
    region_code     VARCHAR(50),
    area_code       VARCHAR(50),
    market_code     VARCHAR(50),
    phase           VARCHAR(100),
    progress_pct    NUMERIC(5,2),
    status          VARCHAR(50),
    attributes      JSONB           NOT NULL DEFAULT '{}',
    last_refreshed  TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (project_id, site_id),
    CONSTRAINT fk_sites_project
        FOREIGN KEY (project_id)
        REFERENCES pwc_derived_tables_schema.dim_project_config(project_id)
        ON DELETE CASCADE
);

-- Indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_dim_sites_project
    ON pwc_derived_tables_schema.dim_sites (project_id);

CREATE INDEX IF NOT EXISTS idx_dim_sites_project_region
    ON pwc_derived_tables_schema.dim_sites (project_id, region_code);

CREATE INDEX IF NOT EXISTS idx_dim_sites_project_area
    ON pwc_derived_tables_schema.dim_sites (project_id, area_code);

CREATE INDEX IF NOT EXISTS idx_dim_sites_project_market
    ON pwc_derived_tables_schema.dim_sites (project_id, market_code);

CREATE INDEX IF NOT EXISTS idx_dim_sites_project_phase
    ON pwc_derived_tables_schema.dim_sites (project_id, phase);

CREATE INDEX IF NOT EXISTS idx_dim_sites_project_status
    ON pwc_derived_tables_schema.dim_sites (project_id, status);

CREATE INDEX IF NOT EXISTS idx_dim_sites_attributes
    ON pwc_derived_tables_schema.dim_sites USING GIN (attributes);

CREATE INDEX IF NOT EXISTS idx_dim_sites_project_progress
    ON pwc_derived_tables_schema.dim_sites (project_id, progress_pct);

COMMIT;
