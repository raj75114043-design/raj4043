-- Migration 005: Fix kpi_values_live primary key to include dimension_key
--
-- Problem: The original PK was (kpi_id, geo_id). Migration 003 added a
-- separate UNIQUE constraint (kpi_id, geo_id, dimension_key) but left the
-- PK unchanged. When the engine inserts multiple dimension combos for the
-- same (kpi_id, geo_id), the PK blocks the second row before the unique
-- constraint is even evaluated.
--
-- Fix: Drop the old PK and recreate it with dimension_key included.

BEGIN;

-- Drop the separate unique constraint added by migration 003 (redundant after PK change)
ALTER TABLE pwc_derived_tables_schema.kpi_values_live
    DROP CONSTRAINT IF EXISTS uk_kpi_geo_dim;

-- Drop old primary key
ALTER TABLE pwc_derived_tables_schema.kpi_values_live
    DROP CONSTRAINT IF EXISTS kpi_values_live_pkey;

-- New primary key includes dimension_key
ALTER TABLE pwc_derived_tables_schema.kpi_values_live
    ADD CONSTRAINT kpi_values_live_pkey
    PRIMARY KEY (kpi_id, geo_id, dimension_key);

COMMIT;
