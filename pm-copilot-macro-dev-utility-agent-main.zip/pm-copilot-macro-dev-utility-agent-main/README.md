# KPI Dashboard API

A production-grade async REST API for calculating, storing, and serving KPI data across a four-level geography hierarchy. Built with FastAPI, SQLAlchemy 2.x async, and PostgreSQL.

---

## What it does

- **Calculates KPIs** by executing parameterised SQL templates against source data tables, concurrently across every (KPI × geography) pair using `asyncio.gather` with a semaphore-bounded DB pool.
- **Serves dashboard data** — current value, period-on-period change, year-on-year change, and time-series history — in a single query via a `UNION ALL` of a single-row live table and a rolling historical table.
- **Builds KPI templates** via an LLM-assisted form: paste raw SQL, specify geo/date columns, and the LLM rewrites it into a fully parameterised template.
- **Drills down** into child geographies or detail rows through server-side SQL execution — no raw SQL is ever exposed to the frontend.

---

## Architecture

```
POST /calculate  →  KPICalculator
                       ├── prefetch comparison values (1 bulk query)
                       ├── asyncio.gather(N×M tasks, semaphore-bounded)
                       │     └── each task: own AsyncSession → executes sql_query_template
                       └── bulk upsert (1 statement) → archive old live row → write new live row

GET /dashboard/kpis  →  DashboardService
                           └── UNION ALL(kpi_values_live, kpi_values_historical)
                                 joined to kpi_master + dim_geography
```

### Geography hierarchy

```
OVERALL
  └── REGION  (e.g. South, Central)
        └── AREA  (~20)
              └── MARKET  (~40)
```

KPI SQL templates receive `:geo_code`, `:region_code`, `:area_code`, `:geo_level`, `:start_date`, `:end_date` at runtime, enabling one template to serve all levels.

### Live vs Historical tables

| Table | Rows per KPI/geo | Purpose |
|---|---|---|
| `kpi_values_live` | 1 (latest only) | Fast dashboard read |
| `kpi_values_historical` | 1 per calculation run | Time-series, prev-year lookup |

Before every upsert, the current live row is archived to historical — so history is never lost regardless of refresh frequency.

---

## API surface

| Group | Key endpoints |
|---|---|
| **Calculation** | `POST /api/v1/calculation/trigger` · `POST /full-refresh` · `POST /batch-refresh/markets` · `POST /batch-refresh/areas` |
| **Dashboard** | `GET /api/v1/dashboard/kpis` · `GET /kpi/{id}/drilldown` · `GET /kpi/{id}/detail` · `GET /geography/tree` |
| **KPI Builder** | `POST /api/v1/kpi-builder/generate` (LLM) · `POST /register` · `GET /form` (browser UI) |
| **Health** | `GET /health` · `GET /health/db` |

All endpoints require `X-API-Key`. Requests are rate-limited to 100/min per key.

Interactive docs: `/docs` (Swagger) · `/redoc` · `/scalar`

---

## Configuration (`.env`)

```env
DATABASE_URL=postgresql://user:pass@host:5432/dbname
SECRET_KEY=...
ALLOWED_API_KEYS=["key1","key2"]

# Schema / table overrides (default shown)
DB_SCHEMA=pwc_derived_tables_schema
TABLE_KPI_MASTER=homepage_kpi_master

# Calculation engine
MAX_CONCURRENT_KPI_QUERIES=10
ENABLE_PREV_PERIOD_COMPARISON=true
ENABLE_PREV_YEAR_COMPARISON=true
ENABLE_TIME_SERIES=true

# LLM (KPI Builder)
LLM_API_BASE_URL=https://...
LLM_GATEWAY_API_KEY=...
LLM_MODEL=gpt-4
```

All table names are resolved via `settings.TABLES` — never hardcoded. Changing `DB_SCHEMA` in `.env` propagates to every query.

---

## Stack

| Layer | Technology |
|---|---|
| Web framework | FastAPI 0.133 + Uvicorn |
| ORM / DB | SQLAlchemy 2.x async + asyncpg |
| Database | PostgreSQL |
| LLM integration | LangChain (OpenAI-compatible gateway) |
| Validation | Pydantic v2 |
| API docs | Swagger UI · ReDoc · Scalar |

---

## Running locally

```bash
pip install -r requirements.txt
cp .env.example .env   # fill in DATABASE_URL, SECRET_KEY, ALLOWED_API_KEYS
uvicorn app.main:app --reload
```

### Database migrations

```bash
# Single-row live table (required before first run if upgrading)
psql $DATABASE_URL -f migrations/001_live_table_single_row.sql

# Add kpi_tag + drilldown_sql columns to kpi_master
psql $DATABASE_URL -f migrations/002_kpi_master_tag_drilldown.sql
```

---

## KPI Builder workflow

1. Open `GET /api/v1/kpi-builder/form` in a browser.
2. Paste raw SQL with literal filter values, select geo columns and category.
3. Click **Generate Template** — the LLM rewrites the SQL with bind parameters.
4. Optionally add a **Drill-down SQL** (one query covers all geo levels via `:geo_level`).
5. Click **Register KPI** → triggers `POST /register`.
6. Trigger first calculation: `POST /api/v1/calculation/trigger` with `{"job_type": "SINGLE_KPI", "kpi_ids": ["<id>"]}`.
