from fastapi import Request, HTTPException
from typing import Dict
from datetime import datetime, timedelta
import asyncio

class RateLimiter:
    """
    Simple in-memory rate limiter
    For production, use Redis-based rate limiting
    """
    
    def __init__(self, requests_per_minute: int = 60):
        self.requests_per_minute = requests_per_minute
        self.requests: Dict[str, list] = {}
        self.cleanup_interval = 60  # seconds
        
    async def check_rate_limit(self, request: Request):
        """Check if request exceeds rate limit"""
        
        # Get client identifier (IP address or API key)
        client_id = request.client.host
        api_key = request.headers.get('X-API-Key')
        if api_key:
            client_id = f"api_key_{api_key[:8]}"
        
        now = datetime.now()
        
        # Initialize request history for this client
        if client_id not in self.requests:
            self.requests[client_id] = []
        
        # Remove requests older than 1 minute
        cutoff = now - timedelta(minutes=1)
        self.requests[client_id] = [
            req_time for req_time in self.requests[client_id]
            if req_time > cutoff
        ]
        
        # Check rate limit
        if len(self.requests[client_id]) >= self.requests_per_minute:
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded. Maximum {self.requests_per_minute} requests per minute."
            )
        
        # Record this request
        self.requests[client_id].append(now)

# Global rate limiter instance
rate_limiter = RateLimiter(requests_per_minute=100)