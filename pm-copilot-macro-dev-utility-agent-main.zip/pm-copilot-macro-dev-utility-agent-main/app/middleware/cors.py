from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings

def setup_cors(app: FastAPI):
    """
    Configure CORS middleware for cross-origin requests
    
    This is critical for web applications calling the API from browsers
    """
    
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,  # ["http://localhost:3000", "https://yourdomain.com"]
        allow_credentials=settings.CORS_CREDENTIALS,
        allow_methods=settings.CORS_METHODS,  # ["GET", "POST", "PUT", "DELETE"]
        allow_headers=settings.CORS_HEADERS,  # ["*"] or specific headers
        expose_headers=["X-Total-Count", "X-Request-ID"],  # Custom headers to expose
        max_age=3600,  # Cache preflight requests for 1 hour
    )