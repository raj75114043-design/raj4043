from datetime import date, datetime, timedelta
from typing import Dict, Tuple

def get_date_parts(target_date: date) -> Dict[str, int]:
    """
    Extract year, quarter, month, week from date
    
    Returns:
        Dictionary with date components
    """
    
    return {
        'year': target_date.year,
        'quarter': (target_date.month - 1) // 3 + 1,
        'month': target_date.month,
        'week': target_date.isocalendar()[1]
    }

def get_previous_period_date(current_date: date, period: str = 'day') -> date:
    """
    Get previous period date
    
    Args:
        current_date: Current date
        period: 'day', 'week', 'month', 'quarter', 'year'
    
    Returns:
        Previous period date
    """
    
    if period == 'day':
        return current_date - timedelta(days=1)
    elif period == 'week':
        return current_date - timedelta(weeks=1)
    elif period == 'month':
        # Go back one month
        year = current_date.year
        month = current_date.month - 1
        if month == 0:
            month = 12
            year -= 1
        return current_date.replace(year=year, month=month)
    elif period == 'quarter':
        return current_date - timedelta(days=90)
    elif period == 'year':
        return current_date.replace(year=current_date.year - 1)
    else:
        raise ValueError(f"Invalid period: {period}")

def get_date_range_for_period(
    end_date: date,
    period: str = 'month'
) -> Tuple[date, date]:
    """
    Get start and end dates for a period
    
    Args:
        end_date: End date of the period
        period: 'day', 'week', 'month', 'quarter', 'year'
    
    Returns:
        Tuple of (start_date, end_date)
    """
    
    if period == 'day':
        return end_date, end_date
    elif period == 'week':
        # Start of week (Monday)
        start = end_date - timedelta(days=end_date.weekday())
        return start, end_date
    elif period == 'month':
        # First day of month
        start = end_date.replace(day=1)
        return start, end_date
    elif period == 'quarter':
        # First day of quarter
        quarter_start_month = ((end_date.month - 1) // 3) * 3 + 1
        start = end_date.replace(month=quarter_start_month, day=1)
        return start, end_date
    elif period == 'year':
        # First day of year
        start = end_date.replace(month=1, day=1)
        return start, end_date
    else:
        raise ValueError(f"Invalid period: {period}")