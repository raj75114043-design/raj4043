from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from psycopg2 import sql

from .db import connection


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_HEADER_FONT = Font(bold=True, color="FFFFFF")
_HEADER_FILL = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")


def _style_header_row(ws):
    """Apply formatting to the first row of a worksheet."""
    for cell in ws[1]:
        cell.font = _HEADER_FONT
        cell.fill = _HEADER_FILL


def _auto_width(ws):
    """Adjust column widths to fit content."""
    for col in ws.columns:
        max_len = 0
        col_letter = col[0].column_letter
        for cell in col:
            if cell.value is not None:
                max_len = max(max_len, len(str(cell.value)))
        ws.column_dimensions[col_letter].width = min(max_len + 4, 60)


def _get_tables(cur, schema):
    cur.execute(
        """
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = %s AND table_type = 'BASE TABLE'
        ORDER BY table_name
        """,
        (schema,),
    )
    return [r[0] for r in cur.fetchall()]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def generate_report(schema, table_names=None, output_path="staging_report.xlsx",
                    sample_rows=5):
    """Generate an Excel report with one sheet per table.

    Each sheet contains column metadata (name, data type, nullable, default)
    plus sample values fetched from the actual data.

    Parameters
    ----------
    schema : str
        Schema to report on.
    table_names : list[str] or None
        Specific tables.  ``None`` means all tables in *schema*.
    output_path : str
        File path for the output ``.xlsx`` file.
    sample_rows : int
        Number of sample rows to fetch per column (default 5).

    Returns
    -------
    str
        The *output_path* that was written.
    """
    wb = Workbook()
    wb.remove(wb.active)  # Remove default sheet

    # Collect summary stats while building per-table sheets
    summary_rows = []

    with connection() as conn:
        cur = conn.cursor()
        tables = table_names if table_names else _get_tables(cur, schema)

        for tbl in tables:
            ws = wb.create_sheet(title=tbl[:31])

            # Fetch column metadata
            cur.execute(
                """
                SELECT column_name, data_type, is_nullable, column_default
                FROM information_schema.columns
                WHERE table_schema = %s AND table_name = %s
                ORDER BY ordinal_position
                """,
                (schema, tbl),
            )
            columns = cur.fetchall()
            col_count = len(columns)
            nullable_count = sum(1 for c in columns if c[2] == "YES")

            # Get row count
            qualified = sql.SQL("{}.{}").format(
                sql.Identifier(schema), sql.Identifier(tbl)
            )
            cur.execute(sql.SQL("SELECT COUNT(*) FROM {}").format(qualified))
            row_count = cur.fetchone()[0]

            # Get table size on disk
            cur.execute(
                "SELECT pg_size_pretty(pg_total_relation_size(%s))",
                (f"{schema}.{tbl}",),
            )
            table_size = cur.fetchone()[0]

            summary_rows.append({
                "table": tbl,
                "columns": col_count,
                "rows": row_count,
                "nullable_columns": nullable_count,
                "size": table_size,
            })

            # Build headers: fixed metadata columns + sample_1 .. sample_N
            headers = ["Column Name", "Data Type", "Is Nullable", "Column Default"]
            for i in range(1, sample_rows + 1):
                headers.append(f"Sample {i}")
            ws.append(headers)

            # Fetch sample data for this table
            cur.execute(
                sql.SQL("SELECT * FROM {} LIMIT %s").format(qualified),
                (sample_rows,),
            )
            sample_data = cur.fetchall()

            # Write one row per column
            for col_idx, (col_name, data_type, nullable, default) in enumerate(columns):
                row = [col_name, data_type, nullable, default]
                for sample_row in sample_data:
                    val = sample_row[col_idx]
                    row.append(str(val) if val is not None else None)
                while len(row) < len(headers):
                    row.append(None)
                ws.append(row)

            _style_header_row(ws)
            _auto_width(ws)

    # ---- Summary sheet (inserted as the first sheet) ----
    ws_summary = wb.create_sheet("Summary", 0)
    ws_summary.append([
        "Table Name", "Column Count", "Row Count",
        "Nullable Columns", "Table Size",
    ])
    total_rows = 0
    total_cols = 0
    for s in summary_rows:
        ws_summary.append([
            s["table"], s["columns"], s["rows"],
            s["nullable_columns"], s["size"],
        ])
        total_rows += s["rows"]
        total_cols += s["columns"]

    # Totals row
    ws_summary.append([])
    ws_summary.append([
        f"TOTAL ({len(summary_rows)} tables)",
        total_cols, total_rows, "", "",
    ])
    # Bold the totals row
    for cell in ws_summary[ws_summary.max_row]:
        cell.font = Font(bold=True)

    _style_header_row(ws_summary)
    _auto_width(ws_summary)

    if not wb.sheetnames:
        wb.create_sheet("Empty")

    wb.save(output_path)
    return output_path


def export_tables(schema, table_names=None, output_path="export.xlsx", row_limit=100_000):
    """Export table data to an Excel workbook (one sheet per table).

    Parameters
    ----------
    schema : str
        Schema to export from.
    table_names : list[str] or None
        Specific tables.  ``None`` means all tables in *schema*.
    output_path : str
        File path for the output ``.xlsx`` file.
    row_limit : int
        Maximum number of data rows per table (default 100 000).

    Returns
    -------
    str
        The *output_path* that was written.
    """
    wb = Workbook()
    # Remove the default sheet — we'll create one per table
    wb.remove(wb.active)

    with connection() as conn:
        cur = conn.cursor()
        tables = table_names if table_names else _get_tables(cur, schema)

        for tbl in tables:
            qualified = sql.SQL("{}.{}").format(
                sql.Identifier(schema), sql.Identifier(tbl)
            )

            # Get column names
            cur.execute(
                """
                SELECT column_name
                FROM information_schema.columns
                WHERE table_schema = %s AND table_name = %s
                ORDER BY ordinal_position
                """,
                (schema, tbl),
            )
            col_names = [r[0] for r in cur.fetchall()]

            ws = wb.create_sheet(title=tbl[:31])  # Excel sheet names max 31 chars
            ws.append(col_names)

            # Fetch data
            cur.execute(
                sql.SQL("SELECT * FROM {} LIMIT %s").format(qualified),
                (row_limit,),
            )
            for row in cur.fetchall():
                ws.append(list(row))

            _style_header_row(ws)
            _auto_width(ws)

    if not wb.sheetnames:
        wb.create_sheet("Empty")

    wb.save(output_path)
    return output_path
