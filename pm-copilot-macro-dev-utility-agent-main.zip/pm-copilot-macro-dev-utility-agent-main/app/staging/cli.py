import argparse
import json

from .config import SOURCE_SCHEMA, TARGET_SCHEMA, TABLE_PREFIX
from .core import create_staging_tables, sync_staging_tables, drop_staging_tables, get_schema_diff
from .report import generate_report, export_tables


def _parse_tables(value):
    """Split a comma-separated table list, or return None for 'all'."""
    if not value:
        return None
    return [t.strip() for t in value.split(",") if t.strip()]


# ---------------------------------------------------------------------------
# Subcommand handlers
# ---------------------------------------------------------------------------

def _warn_not_found(not_found):
    if not_found:
        print(f"\nWARNING: Tables not found in source schema: {', '.join(not_found)}")


def _cmd_create(args):
    tables = _parse_tables(args.tables)
    result = create_staging_tables(args.source_schema, args.target_schema,
                                   tables, args.prefix)
    for entry in result["created"]:
        print(f"  {entry['source_table']} -> {entry['staging_table']}")
    print(f"\nCreated {len(result['created'])} staging table(s).")
    _warn_not_found(result["not_found"])


def _cmd_sync(args):
    tables = _parse_tables(args.tables)
    result = sync_staging_tables(args.source_schema, args.target_schema,
                                 tables, args.prefix)
    synced_names = [e["staging_table"] if isinstance(e, dict) else e for e in result["synced"]]
    print(f"Synced  : {', '.join(synced_names) or '(none)'}")
    print(f"Skipped : {', '.join(result['skipped']) or '(none)'}")
    _warn_not_found(result["not_found"])
    if result["diffs"]:
        print("\nChanges detected:")
        print(json.dumps(result["diffs"], indent=2, default=str))


def _cmd_drop(args):
    tables = _parse_tables(args.tables)
    result = drop_staging_tables(args.target_schema, tables, args.prefix)
    print(f"Dropped {len(result['dropped'])} table(s): {', '.join(result['dropped']) or '(none)'}")
    _warn_not_found(result["not_found"])


def _cmd_diff(args):
    tables = _parse_tables(args.tables)
    result = get_schema_diff(args.source_schema, args.target_schema,
                             tables, args.prefix)
    _warn_not_found(result["not_found"])
    if result["diffs"]:
        print(json.dumps(result["diffs"], indent=2, default=str))
    else:
        print("No differences found.")


def _cmd_report(args):
    tables = _parse_tables(args.tables)
    schema = args.schema or TARGET_SCHEMA
    path = generate_report(schema, tables, args.output)
    print(f"Report saved to {path}")


def _cmd_export(args):
    tables = _parse_tables(args.tables)
    schema = args.schema or TARGET_SCHEMA
    path = export_tables(schema, tables, args.output, args.row_limit)
    print(f"Export saved to {path}")


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="staging",
        description="PostgreSQL staging-table pipeline",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # -- create ---------------------------------------------------------------
    p_create = sub.add_parser("create", help="Create staging tables from source schema")
    p_create.add_argument("--source-schema", default=None,
                          help=f"Client source schema (default: {SOURCE_SCHEMA})")
    p_create.add_argument("--target-schema", default=None,
                          help=f"Your staging schema (default: {TARGET_SCHEMA})")
    p_create.add_argument("--tables", default=None,
                          help="Comma-separated table names (default: config list)")
    p_create.add_argument("--prefix", default=None,
                          help=f"Staging table prefix (default: {TABLE_PREFIX!r})")

    # -- sync -----------------------------------------------------------------
    p_sync = sub.add_parser("sync", help="Sync staging tables with source schema")
    p_sync.add_argument("--source-schema", default=None)
    p_sync.add_argument("--target-schema", default=None)
    p_sync.add_argument("--tables", default=None)
    p_sync.add_argument("--prefix", default=None)

    # -- drop -----------------------------------------------------------------
    p_drop = sub.add_parser("drop", help="Drop staging tables")
    p_drop.add_argument("--target-schema", default=None)
    p_drop.add_argument("--tables", default=None,
                        help="Source table names (prefix applied automatically)")
    p_drop.add_argument("--prefix", default=None)

    # -- diff -----------------------------------------------------------------
    p_diff = sub.add_parser("diff", help="Show schema differences between source and staging")
    p_diff.add_argument("--source-schema", default=None)
    p_diff.add_argument("--target-schema", default=None)
    p_diff.add_argument("--tables", default=None)
    p_diff.add_argument("--prefix", default=None)

    # -- report ---------------------------------------------------------------
    p_report = sub.add_parser("report", help="Generate Excel metadata report")
    p_report.add_argument("--schema", default=None,
                          help=f"Schema to report on (default: {TARGET_SCHEMA})")
    p_report.add_argument("--tables", default=None)
    p_report.add_argument("--output", default="staging_report.xlsx")

    # -- export ---------------------------------------------------------------
    p_export = sub.add_parser("export", help="Export table data to Excel")
    p_export.add_argument("--schema", default=None)
    p_export.add_argument("--tables", default=None)
    p_export.add_argument("--output", default="export.xlsx")
    p_export.add_argument("--row-limit", type=int, default=100_000)

    args = parser.parse_args(argv)

    handlers = {
        "create": _cmd_create,
        "sync": _cmd_sync,
        "drop": _cmd_drop,
        "diff": _cmd_diff,
        "report": _cmd_report,
        "export": _cmd_export,
    }
    handlers[args.command](args)


if __name__ == "__main__":
    main()
