"""PostgreSQL staging-table pipeline — integrated as a submodule of the KPI Dashboard API."""

from .core import (
    create_staging_tables,
    sync_staging_tables,
    drop_staging_tables,
    get_schema_diff,
)
from .report import generate_report, export_tables
from .api import router

__all__ = [
    "create_staging_tables",
    "sync_staging_tables",
    "drop_staging_tables",
    "get_schema_diff",
    "generate_report",
    "export_tables",
    "router",
]
