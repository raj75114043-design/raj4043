"""Staging module configuration — delegates to the main app settings."""

from app.config import settings

SOURCE_SCHEMA = settings.STAGING_SOURCE_SCHEMA
TARGET_SCHEMA = settings.STAGING_TARGET_SCHEMA
TABLE_PREFIX = settings.STAGING_TABLE_PREFIX
DEFAULT_TABLES = settings.STAGING_DEFAULT_TABLES
