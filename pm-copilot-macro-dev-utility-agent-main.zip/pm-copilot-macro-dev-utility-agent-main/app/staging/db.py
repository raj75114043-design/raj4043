from contextlib import contextmanager

import psycopg2

from app.config import settings


def get_connection(autocommit=False):
    """Create a new psycopg2 connection using the main app's DATABASE_URL."""
    conn = psycopg2.connect(**settings.SYNC_DB_PARAMS)
    conn.autocommit = autocommit
    return conn


@contextmanager
def connection(autocommit=False):
    """Context manager that yields a connection and handles commit/rollback."""
    conn = get_connection(autocommit=autocommit)
    try:
        yield conn
        if not autocommit:
            conn.commit()
    except Exception:
        if not autocommit:
            conn.rollback()
        raise
    finally:
        conn.close()
