from psycopg2 import sql

from .config import SOURCE_SCHEMA, TARGET_SCHEMA, TABLE_PREFIX, DEFAULT_TABLES
from .db import connection


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _get_tables(cur, schema):
    """Return a list of table names in the given schema."""
    cur.execute(
        """
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = %s
          AND table_type = 'BASE TABLE'
        ORDER BY table_name
        """,
        (schema,),
    )
    return [row[0] for row in cur.fetchall()]


def _get_columns(cur, schema, table):
    """Return column metadata for a table as a list of dicts."""
    cur.execute(
        """
        SELECT column_name, data_type, is_nullable, column_default,
               character_maximum_length, numeric_precision, numeric_scale
        FROM information_schema.columns
        WHERE table_schema = %s AND table_name = %s
        ORDER BY ordinal_position
        """,
        (schema, table),
    )
    cols = []
    for row in cur.fetchall():
        cols.append({
            "column_name": row[0],
            "data_type": row[1],
            "is_nullable": row[2],
            "column_default": row[3],
            "character_maximum_length": row[4],
            "numeric_precision": row[5],
            "numeric_scale": row[6],
        })
    return cols


def _resolve_tables(cur, schema, table_names):
    """If *table_names* is None, use DEFAULT_TABLES (if set) or discover all."""
    if table_names:
        return list(table_names)
    if DEFAULT_TABLES:
        return list(DEFAULT_TABLES)
    return _get_tables(cur, schema)


def _validate_tables(cur, schema, requested):
    """Check which requested tables actually exist in *schema*.

    Returns (found, not_found) as two lists.
    """
    existing = set(_get_tables(cur, schema))
    found = [t for t in requested if t in existing]
    not_found = [t for t in requested if t not in existing]
    return found, not_found


def _prefixed(table_name, prefix=None):
    """Return the staging table name with the configured prefix."""
    pfx = prefix if prefix is not None else TABLE_PREFIX
    return f"{pfx}{table_name}"


def _ensure_schema(cur, schema):
    """Verify the target schema exists (we cannot create schemas)."""
    cur.execute(
        "SELECT 1 FROM information_schema.schemata WHERE schema_name = %s",
        (schema,),
    )
    if cur.fetchone() is None:
        raise RuntimeError(
            f"Schema '{schema}' does not exist. "
            "Please ask your DBA to create it before running staging operations."
        )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def create_staging_tables(source_schema=None, target_schema=None,
                          table_names=None, prefix=None):
    """Copy tables (structure + data) from *source_schema* into *target_schema*.

    Staging tables are named ``<prefix><original_name>`` (e.g. ``stg_orders``).

    Parameters
    ----------
    source_schema : str or None
        Client source schema.  Defaults to ``config.SOURCE_SCHEMA``.
    target_schema : str or None
        Your staging schema.  Defaults to ``config.TARGET_SCHEMA``.
    table_names : list[str] or None
        Specific source tables to copy.  Defaults to ``config.DEFAULT_TABLES``
        or all tables in *source_schema*.
    prefix : str or None
        Override the staging table prefix.  Defaults to ``config.TABLE_PREFIX``.

    Returns
    -------
    dict
        ``{"created": [...], "not_found": [...]}``
        Each entry in *created*: ``{"source_table": ..., "staging_table": ...}``.
    """
    src_schema = source_schema or SOURCE_SCHEMA
    tgt_schema = target_schema or TARGET_SCHEMA

    created = []
    not_found = []
    with connection() as conn:
        cur = conn.cursor()
        _ensure_schema(cur, tgt_schema)
        requested = _resolve_tables(cur, src_schema, table_names)
        tables, not_found = _validate_tables(cur, src_schema, requested)

        for tbl in tables:
            staging_name = _prefixed(tbl, prefix)

            target = sql.SQL("{}.{}").format(
                sql.Identifier(tgt_schema), sql.Identifier(staging_name)
            )
            source = sql.SQL("{}.{}").format(
                sql.Identifier(src_schema), sql.Identifier(tbl)
            )

            # Drop if already exists so the call is idempotent
            cur.execute(sql.SQL("DROP TABLE IF EXISTS {} CASCADE").format(target))

            # Create with data
            cur.execute(
                sql.SQL("CREATE TABLE {} AS SELECT * FROM {}").format(target, source)
            )

            # Re-apply NOT NULL constraints from the source
            src_cols = _get_columns(cur, src_schema, tbl)
            for col in src_cols:
                if col["is_nullable"] == "NO":
                    cur.execute(
                        sql.SQL("ALTER TABLE {} ALTER COLUMN {} SET NOT NULL").format(
                            target, sql.Identifier(col["column_name"])
                        )
                    )

            created.append({
                "source_table": tbl,
                "staging_table": staging_name,
            })

    return {"created": created, "not_found": not_found}


def get_schema_diff(source_schema=None, target_schema=None,
                    table_names=None, prefix=None):
    """Compare column definitions between source and staging tables.

    Returns
    -------
    dict
        ``{"diffs": {...}, "not_found": [...]}``
    """
    src_schema = source_schema or SOURCE_SCHEMA
    tgt_schema = target_schema or TARGET_SCHEMA

    diffs = {}
    not_found = []
    with connection() as conn:
        cur = conn.cursor()
        requested = _resolve_tables(cur, src_schema, table_names)
        source_tables, not_found = _validate_tables(cur, src_schema, requested)
        target_tables_set = set(_get_tables(cur, tgt_schema))

        for tbl in source_tables:
            staging_name = _prefixed(tbl, prefix)
            src_cols = {c["column_name"]: c for c in _get_columns(cur, src_schema, tbl)}

            if staging_name not in target_tables_set:
                diffs[tbl] = {
                    "staging_table": staging_name,
                    "added": list(src_cols.keys()),
                    "removed": [],
                    "type_changed": [],
                    "status": "missing_in_staging",
                }
                continue

            tgt_cols = {c["column_name"]: c for c in _get_columns(cur, tgt_schema, staging_name)}

            added = [c for c in src_cols if c not in tgt_cols]
            removed = [c for c in tgt_cols if c not in src_cols]
            type_changed = []
            for col_name in src_cols:
                if col_name in tgt_cols:
                    if src_cols[col_name]["data_type"] != tgt_cols[col_name]["data_type"]:
                        type_changed.append({
                            "column": col_name,
                            "source_type": src_cols[col_name]["data_type"],
                            "staging_type": tgt_cols[col_name]["data_type"],
                        })

            if added or removed or type_changed:
                diffs[tbl] = {
                    "staging_table": staging_name,
                    "added": added,
                    "removed": removed,
                    "type_changed": type_changed,
                    "status": "changed",
                }

    return {"diffs": diffs, "not_found": not_found}


def sync_staging_tables(source_schema=None, target_schema=None,
                        table_names=None, prefix=None):
    """Synchronise staging tables with the source schema.

    Tables that have column differences are dropped and re-created.
    Tables with no differences are skipped.

    Returns
    -------
    dict
        ``{"synced": [...], "skipped": [...], "not_found": [...], "diffs": {...}}``
    """
    src_schema = source_schema or SOURCE_SCHEMA
    tgt_schema = target_schema or TARGET_SCHEMA

    diff_result = get_schema_diff(src_schema, tgt_schema, table_names, prefix)
    diffs = diff_result["diffs"]
    not_found = diff_result["not_found"]

    with connection() as conn:
        cur = conn.cursor()
        requested = _resolve_tables(cur, src_schema, table_names)
        valid_tables, _ = _validate_tables(cur, src_schema, requested)

    tables_with_changes = set(diffs.keys())
    synced = []

    if tables_with_changes:
        result = create_staging_tables(src_schema, tgt_schema,
                                       list(tables_with_changes), prefix)
        synced = result["created"]

    skipped = [t for t in valid_tables if t not in tables_with_changes]

    return {"synced": synced, "skipped": skipped, "not_found": not_found, "diffs": diffs}


def drop_staging_tables(target_schema=None, table_names=None, prefix=None):
    """Drop staging tables from *target_schema*.

    Parameters
    ----------
    target_schema : str or None
        Defaults to ``config.TARGET_SCHEMA``.
    table_names : list[str] or None
        **Source** table names — the prefix is applied automatically.
        If ``None``, all tables in *target_schema* are dropped (no prefix
        logic, drops everything).
    prefix : str or None
        Override prefix.  Defaults to ``config.TABLE_PREFIX``.

    Returns
    -------
    dict
        ``{"dropped": [...], "not_found": [...]}``
    """
    tgt_schema = target_schema or TARGET_SCHEMA

    dropped = []
    not_found = []
    with connection() as conn:
        cur = conn.cursor()
        existing = set(_get_tables(cur, tgt_schema))

        if table_names:
            # Caller specified source names — apply prefix
            staging_names = [_prefixed(t, prefix) for t in table_names]
        else:
            # No names given — drop every table in the target schema
            staging_names = list(existing)

        for stg in staging_names:
            if stg not in existing:
                not_found.append(stg)
                continue

            target = sql.SQL("{}.{}").format(
                sql.Identifier(tgt_schema), sql.Identifier(stg)
            )
            cur.execute(sql.SQL("DROP TABLE IF EXISTS {} CASCADE").format(target))
            dropped.append(stg)

    return {"dropped": dropped, "not_found": not_found}
