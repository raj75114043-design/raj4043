import os
import logging
import tempfile
from typing import Optional

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import FileResponse
from pydantic import BaseModel

from .config import SOURCE_SCHEMA, TARGET_SCHEMA, TABLE_PREFIX, DEFAULT_TABLES
from .core import create_staging_tables, sync_staging_tables, drop_staging_tables, get_schema_diff
from .report import generate_report, export_tables

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/staging",
    tags=["Staging"],
)


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

class StagingRequest(BaseModel):
    source_schema: Optional[str] = None
    target_schema: Optional[str] = None
    table_names: Optional[list[str]] = None
    prefix: Optional[str] = None


class DropRequest(BaseModel):
    target_schema: Optional[str] = None
    table_names: Optional[list[str]] = None
    prefix: Optional[str] = None


class CreateResponse(BaseModel):
    created: list[dict]
    not_found: list[str]
    count: int


class SyncResponse(BaseModel):
    synced: list
    skipped: list[str]
    not_found: list[str]
    diffs: dict


class DropResponse(BaseModel):
    dropped: list[str]
    not_found: list[str]
    count: int


class DiffResponse(BaseModel):
    diffs: dict
    not_found: list[str]
    has_differences: bool


class DefaultsResponse(BaseModel):
    source_schema: str
    target_schema: str
    table_prefix: str
    default_tables: list[str]


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@router.get(
    "/config",
    response_model=DefaultsResponse,
    summary="Get active staging configuration",
)
def get_config():
    """Return the active staging configuration (schemas, prefix, default tables)."""
    return DefaultsResponse(
        source_schema=SOURCE_SCHEMA,
        target_schema=TARGET_SCHEMA,
        table_prefix=TABLE_PREFIX,
        default_tables=DEFAULT_TABLES,
    )


@router.post(
    "/tables",
    response_model=CreateResponse,
    summary="Create staging tables",
    status_code=201,
)
def create_tables(req: StagingRequest):
    """Copy table structure + data from the source schema into the staging schema."""
    try:
        result = create_staging_tables(
            req.source_schema, req.target_schema, req.table_names, req.prefix,
        )
        return CreateResponse(
            created=result["created"],
            not_found=result["not_found"],
            count=len(result["created"]),
        )
    except Exception as e:
        logger.exception("Failed to create staging tables")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/tables/sync",
    response_model=SyncResponse,
    summary="Sync staging tables with source",
)
def sync_tables(req: StagingRequest):
    """Re-create staging tables whose columns have drifted from the source."""
    try:
        result = sync_staging_tables(
            req.source_schema, req.target_schema, req.table_names, req.prefix,
        )
        return SyncResponse(**result)
    except Exception as e:
        logger.exception("Failed to sync staging tables")
        raise HTTPException(status_code=500, detail=str(e))


@router.post(
    "/tables/drop",
    response_model=DropResponse,
    summary="Drop staging tables",
)
def drop_tables(req: DropRequest):
    """Drop staging tables from the target schema."""
    try:
        result = drop_staging_tables(
            req.target_schema, req.table_names, req.prefix,
        )
        return DropResponse(
            dropped=result["dropped"],
            not_found=result["not_found"],
            count=len(result["dropped"]),
        )
    except Exception as e:
        logger.exception("Failed to drop staging tables")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/tables/diff",
    response_model=DiffResponse,
    summary="Compare source and staging schemas",
)
def get_table_diff(
    source_schema: Optional[str] = Query(None),
    target_schema: Optional[str] = Query(None),
    tables: Optional[str] = Query(None, description="Comma-separated source table names"),
    prefix: Optional[str] = Query(None),
):
    """Return column-level differences between source tables and their staging copies."""
    try:
        table_names = [t.strip() for t in tables.split(",") if t.strip()] if tables else None
        result = get_schema_diff(source_schema, target_schema, table_names, prefix)
        return DiffResponse(
            diffs=result["diffs"],
            not_found=result["not_found"],
            has_differences=bool(result["diffs"]),
        )
    except Exception as e:
        logger.exception("Failed to get schema diff")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/tables/report",
    summary="Download metadata report (Excel)",
)
def download_metadata_report(
    schema: Optional[str] = Query(None, description="Schema to inspect (defaults to staging)"),
    tables: Optional[str] = Query(None, description="Comma-separated table names"),
):
    """Generate and download an Excel metadata report for the staging schema."""
    try:
        resolved_schema = schema or TARGET_SCHEMA
        table_names = [t.strip() for t in tables.split(",") if t.strip()] if tables else None
        tmp = os.path.join(tempfile.gettempdir(), "staging_report.xlsx")
        generate_report(resolved_schema, table_names, tmp)
        return FileResponse(
            tmp,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            filename="staging_report.xlsx",
        )
    except Exception as e:
        logger.exception("Failed to generate report")
        raise HTTPException(status_code=500, detail=str(e))


@router.get(
    "/tables/export",
    summary="Export table data to Excel",
)
def export_table_data(
    schema: Optional[str] = Query(None, description="Schema to export from (defaults to staging)"),
    tables: Optional[str] = Query(None, description="Comma-separated table names"),
    row_limit: int = Query(100_000, description="Max rows per table"),
):
    """Export staging table data as a downloadable Excel workbook."""
    try:
        resolved_schema = schema or TARGET_SCHEMA
        table_names = [t.strip() for t in tables.split(",") if t.strip()] if tables else None
        tmp = os.path.join(tempfile.gettempdir(), "staging_export.xlsx")
        export_tables(resolved_schema, table_names, tmp, row_limit)
        return FileResponse(
            tmp,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            filename="staging_export.xlsx",
        )
    except Exception as e:
        logger.exception("Failed to export tables")
        raise HTTPException(status_code=500, detail=str(e))
