"""Allow running the package as ``python -m staging <command>``."""

from .cli import main

main()
