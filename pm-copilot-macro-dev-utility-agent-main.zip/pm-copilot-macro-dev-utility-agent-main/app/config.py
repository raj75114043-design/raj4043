from urllib.parse import urlparse, unquote

from pydantic_settings import BaseSettings
from functools import lru_cache
from typing import List


class Settings(BaseSettings):
    # Application
    APP_NAME: str = "KPI Dashboard API"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False

    # Database
    DATABASE_URL: str
    DB_POOL_SIZE: int = 5          # per-worker pool; keep small to avoid exhausting max_connections
    DB_MAX_OVERFLOW: int = 5       # temporary burst connections beyond pool_size
    DB_POOL_TIMEOUT: int = 30
    DB_POOL_RECYCLE: int = 1800    # recycle idle connections every 30 min

    # Database Schema & Table Configuration
    DB_SCHEMA: str = "pwc_derived_tables_schema"
    TABLE_KPI_MASTER: str = "homepage_kpi_master"
    TABLE_KPI_VALUES_LIVE: str = "kpi_values_live"
    TABLE_KPI_VALUES_HISTORICAL: str = "kpi_values_historical"
    TABLE_CALCULATION_JOBS: str = "kpi_calculation_jobs"
    TABLE_DIM_GEOGRAPHY: str = "dim_geography"
    TABLE_PROJECT_CONFIG: str = "dim_project_config"
    TABLE_DIM_SITES: str = "dim_sites"

    # Redis Cache (optional)
    REDIS_URL: str = "redis://localhost:6379/0"
    CACHE_ENABLED: bool = True

    # CORS
    CORS_ORIGINS: List[str] = ["*"]
    CORS_CREDENTIALS: bool = True
    CORS_METHODS: List[str] = ["*"]
    CORS_HEADERS: List[str] = ["*"]

    # Security
    SECRET_KEY: str
    API_KEY_HEADER: str = "X-API-Key"
    ALLOWED_API_KEYS: List[str] = []
    AUTH_ENABLED: bool = True

    # Calculation Engine
    MAX_CONCURRENT_CALCULATIONS: int = 10
    MAX_CONCURRENT_KPI_QUERIES: int = 5   # semaphore for concurrent KPI tasks; must be <= DB_POOL_SIZE
    CALCULATION_TIMEOUT_SECONDS: int = 300
    BATCH_SIZE: int = 100
    ENABLE_PREV_PERIOD_COMPARISON: bool = True   # period-on-period change
    PREV_PERIOD_DAYS_BACK: int = 1               # how many days back to look for the prev-period value (1 = yesterday, 7 = last week, 30 = last month)
    ENABLE_PREV_YEAR_COMPARISON: bool = True     # year-on-year change (same date last year)
    ENABLE_TIME_SERIES: bool = True              # include historical time series in dashboard response

    # Archival
    ARCHIVAL_RETENTION_DAYS: int = 90  # Keep 90 days in live table
    ARCHIVAL_BATCH_SIZE: int = 10000

    # Logging
    LOG_LEVEL: str = "INFO"
    LOG_FILE: str = "logs/kpi_dashboard.log"

    # Monitoring
    ENABLE_METRICS: bool = True
    METRICS_PORT: int = 9090

    # Reference / lookup data
    PROJECTS: List[str] = ["NTM", "NAS", "AHLOA"]
    PROJECT_FUNCTIONS: dict = {
        "NTM":   ["PDM", "SECOE", "HSE", "DEC"],
        "NAS":   [],
        "AHLOA": ["PDM", "SECOE", "HSE", "DEC"],
    }
    LEVELS: List[str] = ["HOME", "PHASE", "SITE"]

    # Staging schema pipeline
    STAGING_SOURCE_SCHEMA: str = "public"
    STAGING_TARGET_SCHEMA: str = "pwc_macro_staging_schema"
    STAGING_TABLE_PREFIX: str = "stg_"
    STAGING_DEFAULT_TABLES: List[str] = [
        "ndpd_mbt_tmobile_macro_combined",
        "ndpd_mbt_combine_site_wise_forecast",
        "tmo_rejections_master_file",
        "services_ndpc_answers_daily_from_sdb",
        "services_ndpc_sessions_daily_from_sdb",
        "tmo_ndpd_forms",
        "ndpd_hse_site_checklist",
        "tmo_hse_daily_tracker_v0_1",
        "nas_e2e_call_test_completion",
        "nas_e911_readiness_riot_validation",
        "nas_log_data",
        "nas_nest_db_sp",
        "nas_nest_ext_raw_by_session",
        "nas_planned_outage_activity",
        "nas_rejection_data_last_30_days",
        "nas_rf010_dashboard",
        "nas_session_level_combined_data",
        "tmo_nas_daily_dashboard",
        "tmo_copilot_se_rcm",
    ]

    # LLM / AI Gateway (used by KPI Builder endpoint)
    LLM_API_BASE_URL: str = ""
    LLM_GATEWAY_API_KEY: str = ""
    LLM_WORKSPACE_NAME: str = ""
    LLM_MODEL: str = "claude-sonnet-4-6"

    # Workflow API
    WORKFLOW_API_BASE_URL: str = "https://pm-workflow-chatbot-osdp-gsd-gsd-delivery-staging.aibi-americas-002.dyn.nesc.nokia.net"
    WORKFLOW_API_TIMEOUT: int = 30
    WORKFLOW_SCHEMA: str = "pwc_workflow_agent_schema"

    # Site Insights
    PM_COMMENT_COLUMNS: List[str] = [
        "pj_construction_complete_delay_code",
        "pj_construction_complete_delay_comments",
        "pj_construction_start_delay_code",
        "pj_construction_start_delay_comments",
        "pj_integration_comments",
        "pj_on_air_delay_code",
        "pj_on_air_delay_code_comments",
        "pj_project_comment_history",
        "pj_project_comments",
        "pj_ran_entitlement_complete_delay_code",
        "pj_ran_entitlement_complete_delay_comments",
        "site_remarks_from_pm_tracker",
    ]
    PM_COMMENTS_TABLE: str = "pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined"
    PM_COMMENTS_SITE_KEY: str = "smp_id"
    INSIGHTS_LLM_MAX_TOKENS: int = 2048
    INSIGHTS_MAX_RECENT_STEPS: int = 4

    # Scheduler (APScheduler)
    SCHEDULER_ENABLED: bool = True
    # Cron expressions (minute hour day month day_of_week)
    SCHEDULER_KPI_CRON: str = "0 2 * * *"    # 2:00 AM daily — full KPI refresh
    SCHEDULER_SITES_CRON: str = "0 4 * * *"  # 4:00 AM daily — all projects site refresh

    @property
    def ASYNC_DATABASE_URL(self) -> str:
        """Convert sync DATABASE_URL to asyncpg-compatible URL."""
        url = self.DATABASE_URL
        if url.startswith("postgres://"):
            url = "postgresql+asyncpg://" + url[len("postgres://"):]
        elif url.startswith("postgresql://"):
            url = "postgresql+asyncpg://" + url[len("postgresql://"):]
        return url

    @property
    def SYNC_DB_PARAMS(self) -> dict:
        """Parse DATABASE_URL into psycopg2-compatible connection params."""
        parsed = urlparse(self.DATABASE_URL)
        return {
            "host": parsed.hostname or "localhost",
            "port": parsed.port or 5432,
            "dbname": (parsed.path or "/postgres").lstrip("/"),
            "user": unquote(parsed.username or ""),
            "password": unquote(parsed.password or ""),
        }

    @property
    def TABLES(self) -> dict:
        """Fully-qualified table names keyed by short alias."""
        s = self.DB_SCHEMA
        return {
            "kpi_master":            f"{s}.{self.TABLE_KPI_MASTER}",
            "kpi_values_live":       f"{s}.{self.TABLE_KPI_VALUES_LIVE}",
            "kpi_values_historical": f"{s}.{self.TABLE_KPI_VALUES_HISTORICAL}",
            "calculation_jobs":      f"{s}.{self.TABLE_CALCULATION_JOBS}",
            "dim_geography":         f"{s}.{self.TABLE_DIM_GEOGRAPHY}",
            "project_config":        f"{s}.{self.TABLE_PROJECT_CONFIG}",
            "dim_sites":             f"{s}.{self.TABLE_DIM_SITES}",
        }

    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
