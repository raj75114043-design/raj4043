from langchain_openai import ChatOpenAI

from app.config import settings


def get_llm() -> ChatOpenAI:
    """
    Return a configured LangChain LLM client pointing at the project's AI gateway.

    Connection details are read from settings (LLM_API_BASE_URL, LLM_API_KEY,
    LLM_WORKSPACE_NAME, LLM_MODEL_NAME) so they can be changed via .env without
    touching code.
    """
    return ChatOpenAI(
        api_key="NONE",          # placeholder — real auth goes in the header below
        model=settings.LLM_MODEL,
        base_url=settings.LLM_API_BASE_URL,
        default_headers={
            "api-key": settings.LLM_GATEWAY_API_KEY,
            "workspacename": settings.LLM_WORKSPACE_NAME,
        },
        temperature=0,
    )
