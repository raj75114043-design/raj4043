from fastapi import HTTPException, Security, Header
from fastapi.security import APIKeyHeader
from typing import Optional

from app.config import settings

# API Key authentication scheme
api_key_header = APIKeyHeader(name=settings.API_KEY_HEADER, auto_error=False)

def verify_api_key(api_key: str = Security(api_key_header)) -> str:
    """
    Verify API key from request header.

    Disabled entirely when AUTH_ENABLED=False in config / .env.
    """
    if not settings.AUTH_ENABLED:
        return "auth-disabled"

    if not api_key:
        raise HTTPException(
            status_code=401,
            detail="Missing API key. Include 'X-API-Key' header in your request."
        )

    if settings.ALLOWED_API_KEYS and api_key not in settings.ALLOWED_API_KEYS:
        raise HTTPException(
            status_code=403,
            detail="Invalid API key"
        )

    return api_key

# Optional: JWT-based authentication for user-specific endpoints
from datetime import datetime, timedelta
from jose import JWTError, jwt
from typing import Optional

def create_access_token(data: dict, expires_delta: Optional[timedelta] = None):
    """Create JWT access token"""
    
    to_encode = data.copy()
    
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, settings.SECRET_KEY, algorithm="HS256")
    
    return encoded_jwt

def verify_token(token: str) -> dict:
    """Verify JWT token"""
    
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=["HS256"])
        return payload
    except JWTError:
        raise HTTPException(
            status_code=401,
            detail="Invalid authentication token"
        )