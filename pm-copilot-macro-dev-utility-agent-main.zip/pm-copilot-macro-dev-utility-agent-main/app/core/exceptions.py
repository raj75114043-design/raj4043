class KPIDashboardException(Exception):
    """Base exception for KPI Dashboard"""
    pass

class CalculationError(KPIDashboardException):
    """Raised when KPI calculation fails"""
    pass

class QueryExecutionError(KPIDashboardException):
    """Raised when SQL query execution fails"""
    pass

class DataValidationError(KPIDashboardException):
    """Raised when data validation fails"""
    pass

class GeographyNotFoundError(KPIDashboardException):
    """Raised when geography is not found"""
    pass

class KPINotFoundError(KPIDashboardException):
    """Raised when KPI is not found"""
    pass

class WorkflowAPIError(KPIDashboardException):
    """Raised when the external workflow API call fails"""
    pass

class WorkflowConfigError(KPIDashboardException):
    """Raised when workflow configuration is missing or invalid"""
    pass

class SiteInsightsError(KPIDashboardException):
    """Raised when site insights generation fails"""
    pass