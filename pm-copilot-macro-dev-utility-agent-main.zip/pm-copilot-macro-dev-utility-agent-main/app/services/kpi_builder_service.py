import json
import logging
import re
from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional

from langchain_core.messages import HumanMessage, SystemMessage
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.core.llm import get_llm

logger = logging.getLogger(__name__)

# ------------------------------------------------------------------ #
# System prompt — explains the KPI template contract to the LLM       #
# ------------------------------------------------------------------ #

_SYSTEM_PROMPT = """
You are an expert SQL developer building KPI templates for a geospatial KPI Dashboard.

A KPI template is a SQL query that MUST return exactly one row with two columns:
  • kpi_value   NUMERIC   — the aggregated metric value
  • record_count INTEGER  — number of source rows that contributed

These bind parameters are injected at runtime (use these exact names — no literals):
  :start_date   — period start date  (inclusive)
  :end_date     — period end date    (inclusive)
  :geo_code     — natural key of the target geography, UPPER-CASE  (maps to MARKET level)
  :region_code  — geo_code of the parent region  (NULL at OVERALL / REGION level)
  :area_code    — geo_code of the parent area    (NULL at OVERALL / REGION / AREA level)
  :geo_level    — 'OVERALL' | 'REGION' | 'AREA' | 'MARKET'

Geo column mapping (provided by the user — these are the actual column names in the source data):
{geo_column_map}

Transformation rules:
1. For each applicable geo level, replace the WHERE filter on the corresponding source
   column with the matching bind parameter:
     Source column for MARKET  → replace with :geo_code
     Source column for AREA    → replace with :area_code
     Source column for REGION  → replace with :region_code
     OVERALL level             → remove the geo filter entirely (aggregate everything)

   If the same column is used for multiple levels, or if the KPI applies to multiple
   levels with different columns, use CASE WHEN :geo_level = '...' THEN ... to switch
   the filter dynamically.

2. {date_filter_instruction}

3. Rename aggregate output columns to kpi_value and record_count.

4. Do NOT add a semicolon or trailing whitespace.

5. Geo filter case-insensitivity: the bind parameters :geo_code, :region_code, :area_code
   are always injected as UPPER-CASE strings by the engine. To ensure comparisons work
   regardless of how data is stored in the source table, always wrap the source column
   in UPPER() when comparing against a geo bind parameter:
     UPPER(source_column) = :geo_code
     UPPER(source_column) = :region_code
     UPPER(source_column) = :area_code
   Never apply UPPER() to the bind parameter itself — only to the source column.

6. Dimension filter case-insensitivity: dimension filters (e.g. :scope_of_work) are
   injected as-is from the user. Source data may store values in mixed case. Always
   make dimension comparisons case-insensitive using UPPER() on both sides:
     UPPER(source_column) = UPPER(:scope_of_work)
   The 'ALL' bypass pattern must also account for case:
     (:scope_of_work = 'ALL' OR UPPER(source_column) = UPPER(:scope_of_work))
   Apply this pattern for every dimension filter present in the SQL.
{dimension_hint}

6. After generating sql_template, also produce a preview_query: a standalone SQL snippet
   that is immediately runnable in pgAdmin to verify the logic. Replace every bind
   parameter with a concrete sample literal:
     :geo_code     → 'SAMPLE_MARKET'
     :region_code  → 'SAMPLE_REGION'
     :area_code    → 'SAMPLE_AREA'
     :geo_level    → 'MARKET'
     :start_date   → CURRENT_DATE - INTERVAL '30 days'
     :end_date     → CURRENT_DATE
   The preview_query must be syntactically valid SQL with no bind parameters remaining.

Return ONLY a valid JSON object — no markdown fences, no extra text:
{{
  "sql_template": "<the fully transformed SQL with bind parameters>",
  "preview_query": "<the same SQL with all bind params replaced by sample literals — ready to run in pgAdmin>",
  "kpi_id": "<KPI_SCREAMING_SNAKE, prefix KPI_, max 50 chars>",
  "kpi_code": "<SCREAMING_SNAKE, max 50 chars>",
  "kpi_description": "<one concise sentence describing what this KPI measures>",
  "notes": "<brief explanation of every transformation you made>"
}}
""".strip()


class KPIBuilderService:
    """
    LLM-assisted service that transforms a raw SQL query into a validated
    KPI template and registers it in the kpi_master table.
    """

    def __init__(self, db: AsyncSession) -> None:
        self.db = db
        self.llm = get_llm()

    # ------------------------------------------------------------------ #
    # LLM template generation                                             #
    # ------------------------------------------------------------------ #

    async def generate_template(
        self,
        raw_sql: str,
        kpi_name: str,
        applicable_geo_levels: List[str],
        time_column: Optional[str] = None,
        region_column: Optional[str] = None,
        area_column: Optional[str] = None,
        market_column: Optional[str] = None,
        filter_dimensions: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Ask the LLM to transform raw_sql into a proper KPI template.

        geo columns are specified per level so the LLM knows exactly which
        source column maps to which geography hierarchy level.

        Returns the parsed JSON dict from the LLM response with keys:
          sql_template, kpi_id, kpi_code, kpi_description, notes
        """
        # Build a readable column-map string for the prompt
        col_lines = []
        if "REGION" in applicable_geo_levels and region_column:
            col_lines.append(f"  REGION level  → source column: '{region_column}'  → bind param: :region_code")
        if "AREA" in applicable_geo_levels and area_column:
            col_lines.append(f"  AREA level    → source column: '{area_column}'  → bind param: :area_code")
        if "MARKET" in applicable_geo_levels and market_column:
            col_lines.append(f"  MARKET level  → source column: '{market_column}'  → bind param: :geo_code")
        if "OVERALL" in applicable_geo_levels:
            col_lines.append(f"  OVERALL level → no geo filter (aggregate across everything)")
        geo_column_map = "\n".join(col_lines) if col_lines else "  (no per-level columns specified — infer from SQL)"

        if time_column:
            date_filter_instruction = (
                f"Replace the date/time range condition on the user-specified time column with:\n"
                f"     {time_column} BETWEEN :start_date AND :end_date"
            )
        else:
            date_filter_instruction = (
                "No date/time filter column was specified. "
                "Do NOT add or modify any date conditions. "
                "The :start_date and :end_date parameters are available if the SQL already "
                "contains a date filter — replace its column and literals with the bind params — "
                "but if there is no date filter in the SQL, leave it out entirely."
            )

        # Build dimension hint for the LLM
        dims = filter_dimensions or {}
        if dims:
            dim_lines = ["\n\nProject dimension filters — these bind params will be injected at runtime:"]
            for dim, vals in dims.items():
                vals_str = ", ".join(f"'{v}'" for v in (vals or []))
                dim_lines.append(
                    f"  :{dim}  (possible values: {vals_str}, or 'ALL' meaning no filter)\n"
                    f"    → Use: (:{ dim} = 'ALL' OR UPPER(your_column) = UPPER(:{dim}))"
                )
            dimension_hint = "\n".join(dim_lines)
        else:
            dimension_hint = ""

        system_content = _SYSTEM_PROMPT.format(
            geo_column_map=geo_column_map,
            date_filter_instruction=date_filter_instruction,
            dimension_hint=dimension_hint,
        )

        system = SystemMessage(content=system_content)
        time_line = f"Time filter column: {time_column}\n" if time_column else "Time filter: none\n"
        user = HumanMessage(content=(
            f"Transform this SQL into a KPI template.\n\n"
            f"KPI name: {kpi_name}\n"
            f"{time_line}"
            f"Applicable geo levels: {', '.join(applicable_geo_levels)}\n\n"
            f"Raw SQL:\n{raw_sql}"
        ))

        response = await self.llm.ainvoke([system, user])
        raw = response.content.strip()

        # Strip accidental markdown code fences the LLM may add
        raw = re.sub(r"^```[a-z]*\n?", "", raw, flags=re.MULTILINE)
        raw = re.sub(r"```$", "", raw, flags=re.MULTILINE).strip()

        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            logger.error(f"LLM returned non-JSON:\n{raw}")
            raise ValueError(f"LLM response was not valid JSON: {exc}") from exc

    # ------------------------------------------------------------------ #
    # KPI listing & lookup                                                #
    # ------------------------------------------------------------------ #

    async def list_kpis(
        self,
        project_id: Optional[str] = None,
        is_active: Optional[bool] = None,
    ) -> List[Dict[str, Any]]:
        """Return all KPI definitions from kpi_master, optionally filtered."""
        table = settings.TABLES["kpi_master"]
        clauses = []
        params: Dict[str, Any] = {}

        if is_active is not None:
            clauses.append("is_active = :is_active")
            params["is_active"] = is_active
        if project_id:
            clauses.append(":project_id = ANY(project_ids)")
            params["project_id"] = project_id

        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        q = text(f"SELECT * FROM {table}{where} ORDER BY priority ASC, kpi_id ASC")
        rows = (await self.db.execute(q, params)).fetchall()
        return [dict(r._mapping) for r in rows]

    async def get_kpi(self, kpi_id: str) -> Optional[Dict[str, Any]]:
        """Return a single KPI definition by kpi_id."""
        table = settings.TABLES["kpi_master"]
        q = text(f"SELECT * FROM {table} WHERE kpi_id = :kpi_id")
        row = (await self.db.execute(q, {"kpi_id": kpi_id})).fetchone()
        return dict(row._mapping) if row else None

    async def delete_kpi(self, kpi_id: str) -> bool:
        """
        Delete a KPI definition and all its computed values.
        Cleans up kpi_values_live and kpi_values_historical first to
        avoid FK constraint violations, then removes the master record.
        """
        live_table = settings.TABLES["kpi_values_live"]
        hist_table = settings.TABLES["kpi_values_historical"]
        master_table = settings.TABLES["kpi_master"]

        await self.db.execute(
            text(f"DELETE FROM {live_table} WHERE kpi_id = :kpi_id"),
            {"kpi_id": kpi_id},
        )
        await self.db.execute(
            text(f"DELETE FROM {hist_table} WHERE kpi_id = :kpi_id"),
            {"kpi_id": kpi_id},
        )
        result = await self.db.execute(
            text(f"DELETE FROM {master_table} WHERE kpi_id = :kpi_id"),
            {"kpi_id": kpi_id},
        )
        await self.db.commit()
        return result.rowcount > 0

    # ------------------------------------------------------------------ #
    # KPI registration                                                    #
    # ------------------------------------------------------------------ #

    async def register_kpi(self, kpi_def: Dict[str, Any]) -> Dict[str, Any]:
        """
        Insert (or upsert) a KPI definition into kpi_master.

        Uses INSERT … ON CONFLICT DO UPDATE so re-running with the same
        kpi_id simply refreshes the definition rather than raising an error.
        Returns the saved row as a dict.
        """
        table = settings.TABLES["kpi_master"]
        now = datetime.now()

        q = text(f"""
            INSERT INTO {table} (
                kpi_id, kpi_code, kpi_name, kpi_description,
                kpi_category, kpi_tag,
                project_ids, level_ids, function_ids,
                applicable_geo_levels, sql_query_template, drilldown_sql,
                aggregation_method, aggregation_column,
                display_format, decimal_places, unit_symbol,
                source_tables, refresh_frequency,
                is_active, priority, parent_kpi_id,
                created_at, updated_at
            ) VALUES (
                :kpi_id, :kpi_code, :kpi_name, :kpi_description,
                :kpi_category, :kpi_tag,
                :project_ids, :level_ids, :function_ids,
                :applicable_geo_levels, :sql_query_template, :drilldown_sql,
                :aggregation_method, :aggregation_column,
                :display_format, :decimal_places, :unit_symbol,
                :source_tables, :refresh_frequency,
                :is_active, :priority, :parent_kpi_id,
                :created_at, :updated_at
            )
            ON CONFLICT (kpi_id) DO UPDATE SET
                kpi_code              = EXCLUDED.kpi_code,
                kpi_name              = EXCLUDED.kpi_name,
                kpi_description       = EXCLUDED.kpi_description,
                kpi_category          = EXCLUDED.kpi_category,
                kpi_tag               = EXCLUDED.kpi_tag,
                applicable_geo_levels = EXCLUDED.applicable_geo_levels,
                sql_query_template    = EXCLUDED.sql_query_template,
                drilldown_sql         = EXCLUDED.drilldown_sql,
                aggregation_method    = EXCLUDED.aggregation_method,
                aggregation_column    = EXCLUDED.aggregation_column,
                display_format        = EXCLUDED.display_format,
                decimal_places        = EXCLUDED.decimal_places,
                unit_symbol           = EXCLUDED.unit_symbol,
                source_tables         = EXCLUDED.source_tables,
                refresh_frequency     = EXCLUDED.refresh_frequency,
                project_ids           = EXCLUDED.project_ids,
                level_ids              = EXCLUDED.level_ids,
                function_ids          = EXCLUDED.function_ids,
                priority              = EXCLUDED.priority,
                is_active             = EXCLUDED.is_active,
                parent_kpi_id         = EXCLUDED.parent_kpi_id,
                updated_at            = EXCLUDED.updated_at
            RETURNING *
        """)

        row = (await self.db.execute(q, {
            "kpi_id":                kpi_def["kpi_id"],
            "kpi_code":              kpi_def["kpi_code"],
            "kpi_name":              kpi_def["kpi_name"],
            "kpi_description":       kpi_def.get("kpi_description"),
            "kpi_category":          kpi_def["kpi_category"],
            "project_ids":           kpi_def.get("project_ids") or [],
            "level_ids":              kpi_def.get("level_ids") or [],
            "function_ids":          kpi_def.get("function_ids") or [],
            "applicable_geo_levels": kpi_def["applicable_geo_levels"],
            "sql_query_template":    kpi_def["sql_query_template"],
            "aggregation_method":    kpi_def.get("aggregation_method", "SUM"),
            "aggregation_column":    kpi_def.get("aggregation_column"),
            "display_format":        kpi_def.get("display_format", "NUMBER"),
            "decimal_places":        kpi_def.get("decimal_places", 2),
            "unit_symbol":           kpi_def.get("unit_symbol"),
            "source_tables":         kpi_def.get("source_tables") or [],
            "refresh_frequency":     kpi_def.get("refresh_frequency", "DAILY"),
            "is_active":             kpi_def.get("is_active", True),
            "priority":              kpi_def.get("priority", 100),
            "parent_kpi_id":         kpi_def.get("parent_kpi_id"),
            "kpi_tag":               kpi_def.get("kpi_tag"),
            "drilldown_sql":         kpi_def.get("drilldown_sql"),
            "created_at":            now,
            "updated_at":            now,
        })).fetchone()

        await self.db.commit()
        return dict(row._mapping)

    # ------------------------------------------------------------------ #
    # Bulk upload: validate + register many KPIs in one operation         #
    # ------------------------------------------------------------------ #

    async def bulk_validate_and_register(
        self,
        kpi_rows: List[Dict[str, Any]],
        validation_geo_code: str,
        validation_date: Optional[date] = None,
    ) -> Dict[str, Any]:
        """
        Validate and register multiple KPI definitions.

        For each row:
          1. Validates required fields and enum values.
          2. Dry-runs the sql_query_template against validation_geo_code to confirm
             it returns exactly one row with kpi_value + record_count columns.
          3. Saves KPIs that pass validation; collects errors for the rest.

        Returns a report dict with keys: total_rows, saved, failed, results.
        """
        if validation_date is None:
            validation_date = date.today()

        # Standard bind params that every KPI template may reference
        _STANDARD_PARAMS = {
            "start_date", "end_date", "geo_code", "geo_level",
            "region_code", "area_code", "geo_id", "region_id", "area_id",
        }

        test_params = {
            "start_date":  validation_date - timedelta(days=30),
            "end_date":    validation_date,
            "geo_code":    validation_geo_code.upper(),
            "geo_level":   "MARKET",
            "region_code": None,
            "area_code":   None,
            "geo_id":      "",
            "region_id":   None,
            "area_id":     None,
        }

        results: List[Dict[str, Any]] = []
        saved_count = 0

        for idx, row in enumerate(kpi_rows, start=2):  # 1-based; row 1 = header
            row_result: Dict[str, Any] = {
                "row":      idx,
                "kpi_id":   row.get("kpi_id", ""),
                "kpi_name": row.get("kpi_name", ""),
            }

            # Step 1 — field validation
            error = self._validate_kpi_row(row)
            if error:
                row_result["status"] = "failed"
                row_result["error"]  = error
                results.append(row_result)
                continue

            # Step 2 — SQL dry-run
            sql = row["sql_query_template"].strip()
            # Detect dimension bind-params (e.g. :scope_of_work) that aren't
            # in the standard set and default them to 'ALL' so the
            # (:dim = 'ALL' OR col = :dim) pattern passes through cleanly.
            sql_params = set(re.findall(r":([a-zA-Z_]\w*)", sql))
            row_test_params = dict(test_params)
            for p in sql_params - _STANDARD_PARAMS:
                row_test_params[p] = "ALL"
            try:
                val_rows = (await self.db.execute(text(sql), row_test_params)).fetchall()
                if len(val_rows) != 1:
                    raise ValueError(
                        f"Query returned {len(val_rows)} row(s); expected exactly 1."
                    )
                val_row = dict(val_rows[0]._mapping)
                if "kpi_value" not in val_row or "record_count" not in val_row:
                    raise ValueError(
                        f"Query must return 'kpi_value' and 'record_count' columns. "
                        f"Got: {list(val_row.keys())}"
                    )
                row_result["validation_value"]        = float(val_row["kpi_value"]) if val_row["kpi_value"] is not None else None
                row_result["validation_record_count"] = val_row["record_count"]
            except Exception as exc:
                await self.db.rollback()
                row_result["status"] = "failed"
                row_result["error"]  = str(exc)
                results.append(row_result)
                continue

            # Step 3 — save to DB
            try:
                kpi_def = self._normalize_kpi_row(row)
                await self.register_kpi(kpi_def)
                row_result["status"] = "saved"
                saved_count += 1
            except Exception as exc:
                row_result["status"] = "failed"
                row_result["error"]  = f"DB insert failed: {exc}"

            results.append(row_result)

        return {
            "total_rows":          len(kpi_rows),
            "saved":               saved_count,
            "failed":              len(kpi_rows) - saved_count,
            "validation_geo_code": validation_geo_code,
            "results":             results,
        }

    # ------------------------------------------------------------------ #
    # Helpers for bulk upload                                             #
    # ------------------------------------------------------------------ #

    _VALID_CATEGORIES = {"HEALTH", "PERFORMANCE"}
    _VALID_METHODS    = {"SUM", "AVG", "COUNT", "MIN", "MAX", "WEIGHTED_AVG", "CUSTOM"}
    _VALID_FORMATS    = {"NUMBER", "PERCENTAGE", "CURRENCY", "DAYS"}
    _VALID_LEVELS     = {"OVERALL", "REGION", "AREA", "MARKET"}

    def _validate_kpi_row(self, row: Dict[str, Any]) -> Optional[str]:
        """Return an error string if the row has missing required fields or invalid enums."""
        required = [
            "kpi_id", "kpi_code", "kpi_name", "kpi_category",
            "applicable_geo_levels", "sql_query_template", "aggregation_method",
        ]
        for field in required:
            if not row.get(field):
                return f"Missing required field: '{field}'"

        if str(row["aggregation_method"]).upper() not in self._VALID_METHODS:
            return f"Invalid aggregation_method '{row['aggregation_method']}'. Must be one of: {self._VALID_METHODS}"

        if row.get("display_format") and str(row["display_format"]).upper() not in self._VALID_FORMATS:
            return f"Invalid display_format '{row['display_format']}'. Must be one of: {self._VALID_FORMATS}"

        levels = self._parse_list(row.get("applicable_geo_levels", ""))
        bad = [lv for lv in levels if lv.upper() not in self._VALID_LEVELS]
        if bad:
            return f"Invalid applicable_geo_levels: {bad}. Valid values: {self._VALID_LEVELS}"

        return None

    def _normalize_kpi_row(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """Parse and coerce a raw import row into the shape expected by register_kpi."""
        return {
            "kpi_id":                row["kpi_id"].strip(),
            "kpi_code":              row["kpi_code"].strip(),
            "kpi_name":              row["kpi_name"].strip(),
            "kpi_description":       row.get("kpi_description") or None,
            "kpi_category":          str(row["kpi_category"]).strip(),
            "kpi_tag":               row.get("kpi_tag") or None,
            "project_ids":           self._parse_list(row.get("project_ids")),
            "level_ids":              self._parse_list(row.get("level_ids")),
            "function_ids":          self._parse_list(row.get("function_ids")),
            "applicable_geo_levels": [lv.strip().upper() for lv in self._parse_list(row.get("applicable_geo_levels", ""))],
            "sql_query_template":    row["sql_query_template"].strip(),
            "aggregation_method":    str(row["aggregation_method"]).upper(),
            "aggregation_column":    row.get("aggregation_column") or None,
            "display_format":        str(row.get("display_format") or "NUMBER").upper(),
            "decimal_places":        int(row.get("decimal_places") or 2),
            "unit_symbol":           row.get("unit_symbol") or None,
            "source_tables":         self._parse_list(row.get("source_tables")),
            "refresh_frequency":     str(row.get("refresh_frequency") or "DAILY").upper(),
            "is_active":             self._parse_bool(row.get("is_active", True)),
            "priority":              int(row.get("priority") or 100),
            "parent_kpi_id":         row.get("parent_kpi_id") or None,
            "drilldown_sql":         row.get("drilldown_sql") or None,
        }

    @staticmethod
    def _parse_list(val: Any) -> List[str]:
        """Parse a comma-separated string or Python list into a list of stripped strings."""
        if not val:
            return []
        if isinstance(val, list):
            return [str(v).strip() for v in val if str(v).strip()]
        return [v.strip() for v in str(val).split(",") if v.strip()]

    @staticmethod
    def _parse_bool(val: Any) -> bool:
        if isinstance(val, bool):
            return val
        return str(val).strip().upper() in ("TRUE", "YES", "1", "Y")
