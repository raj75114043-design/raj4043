import logging
from typing import Any, Dict, List

import httpx

from app.config import settings
from app.core.exceptions import WorkflowAPIError

logger = logging.getLogger(__name__)


class WorkflowClient:
    """Async HTTP client for the external workflow pipeline API."""

    def __init__(self, base_url: str | None = None, timeout: int | None = None):
        self.base_url = (base_url or settings.WORKFLOW_API_BASE_URL).rstrip("/")
        self.timeout = timeout or settings.WORKFLOW_API_TIMEOUT

    async def list_pipelines(self) -> List[str]:
        """Return the list of available pipeline names."""
        url = f"{self.base_url}/api/v1/workflow/pipelines"
        try:
            async with httpx.AsyncClient(timeout=self.timeout, verify=False) as client:
                resp = await client.get(url)
                resp.raise_for_status()
                return resp.json()
        except httpx.HTTPStatusError as exc:
            raise WorkflowAPIError(
                f"Workflow API returned {exc.response.status_code} for GET {url}"
            ) from exc
        except httpx.RequestError as exc:
            raise WorkflowAPIError(
                f"Failed to reach workflow API at {url}: {exc}"
            ) from exc

    async def get_pipeline_steps(self, pipeline_name: str) -> Dict[str, Any]:
        """Return full pipeline details including step_results array."""
        url = f"{self.base_url}/api/v1/workflow/workflow_executed_pipeline/{pipeline_name}"
        try:
            async with httpx.AsyncClient(timeout=self.timeout, verify=False) as client:
                resp = await client.get(url)
                resp.raise_for_status()
                return resp.json()
        except httpx.HTTPStatusError as exc:
            raise WorkflowAPIError(
                f"Workflow API returned {exc.response.status_code} for pipeline '{pipeline_name}'"
            ) from exc
        except httpx.RequestError as exc:
            raise WorkflowAPIError(
                f"Failed to reach workflow API for pipeline '{pipeline_name}': {exc}"
            ) from exc

    @staticmethod
    def filter_enabled_steps(pipeline_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Extract enabled steps from pipeline response, sorted by step_id."""
        steps = pipeline_data.get("step_results", [])
        enabled = [
            {
                "step_id": s["step_id"],
                "step_name": s["step_name"],
                "phase_id": s.get("phase_id"),
                "phase_name": s.get("phase_name", ""),
                "depends_on": s.get("depends_on", []),
            }
            for s in steps
            if s.get("enabled", False)
        ]
        enabled.sort(key=lambda s: s["step_id"])
        return enabled
