import logging
from datetime import date, timedelta
from typing import Any, Dict

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings

logger = logging.getLogger(__name__)


class DataArchivalService:
    """
    Async service to move old data from the live table to the historical table.
    Maintains data retention policies; table names resolved from settings.TABLES.
    """

    def __init__(self, db: AsyncSession) -> None:
        self.db = db
        self.retention_days = settings.ARCHIVAL_RETENTION_DAYS
        self.batch_size = settings.ARCHIVAL_BATCH_SIZE

    async def archive_old_data(self) -> Dict[str, Any]:
        """
        Archive KPI rows older than the configured retention period.

        Returns:
            Summary dict with status, records_archived, and cutoff_date.
        """
        cutoff_date = date.today() - timedelta(days=self.retention_days)
        logger.info(f"Starting archival. Cutoff date: {cutoff_date}")

        live_table = settings.TABLES["kpi_values_live"]
        hist_table = settings.TABLES["kpi_values_historical"]

        try:
            # 1. Count records to archive
            count_q = text(f"""
                SELECT COUNT(*) AS total
                FROM {live_table}
                WHERE calculation_date < :cutoff_date
            """)
            total_records = (
                await self.db.execute(count_q, {"cutoff_date": cutoff_date})
            ).scalar()

            if not total_records:
                logger.info("No records to archive")
                return {
                    "status": "SUCCESS",
                    "records_archived": 0,
                    "cutoff_date": cutoff_date,
                }

            logger.info(f"Found {total_records} records to archive")

            # 2. Copy to historical table
            archive_q = text(f"""
                INSERT INTO {hist_table} (
                    kpi_id, geo_id, geo_level, dimension_key,
                    calculation_date, period_start_date, period_end_date,
                    year, quarter, month, week,
                    kpi_value, kpi_value_formatted,
                    record_count, data_quality_score,
                    previous_period_value, previous_year_value,
                    period_on_period_change_pct, year_on_year_change_pct,
                    calculation_job_id, calculated_at, archived_at
                )
                SELECT
                    kpi_id, geo_id, geo_level, dimension_key,
                    calculation_date, period_start_date, period_end_date,
                    year, quarter, month, week,
                    kpi_value, kpi_value_formatted,
                    record_count, data_quality_score,
                    previous_period_value, previous_year_value,
                    period_on_period_change_pct, year_on_year_change_pct,
                    calculation_job_id, calculated_at, CURRENT_TIMESTAMP
                FROM {live_table}
                WHERE calculation_date < :cutoff_date
                ON CONFLICT DO NOTHING
            """)
            await self.db.execute(archive_q, {"cutoff_date": cutoff_date})

            # 3. Delete from live table
            delete_q = text(f"""
                DELETE FROM {live_table}
                WHERE calculation_date < :cutoff_date
            """)
            result = await self.db.execute(delete_q, {"cutoff_date": cutoff_date})
            deleted_count = result.rowcount

            await self.db.commit()
            logger.info(f"Successfully archived {deleted_count} records")

            return {
                "status": "SUCCESS",
                "records_archived": deleted_count,
                "cutoff_date": cutoff_date,
                "total_found": total_records,
            }

        except Exception as e:
            await self.db.rollback()
            logger.error(f"Archival failed: {e}", exc_info=True)
            raise

    async def cleanup_old_jobs(self, retention_days: int = 90) -> int:
        """
        Delete old completed/failed job records.

        Returns:
            Number of job records deleted.
        """
        cutoff_date = date.today() - timedelta(days=retention_days)
        table = settings.TABLES["calculation_jobs"]

        q = text(f"""
            DELETE FROM {table}
            WHERE created_at < :cutoff_date
              AND status IN ('COMPLETED', 'FAILED')
        """)
        result = await self.db.execute(q, {"cutoff_date": cutoff_date})
        deleted = result.rowcount
        await self.db.commit()

        logger.info(f"Cleaned up {deleted} old job records")
        return deleted
