import asyncio
import json
import logging
import re
from datetime import datetime
from typing import Any, Dict, List, Optional

from langchain_core.messages import HumanMessage, SystemMessage
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.core.exceptions import SiteInsightsError
from app.core.llm import get_llm
from app.models.insights_models import (
    PMCommentEntry,
    SiteInsightsResponse,
    WorkflowInsight,
    WorkflowStepInsight,
)
from app.services.workflow_client import WorkflowClient
from app.services.workflow_dag import get_main_path_step_ids

logger = logging.getLogger(__name__)

_SAFE_IDENTIFIER_RE = re.compile(r"^[a-zA-Z0-9_]+$")

# ------------------------------------------------------------------ #
# LLM System Prompt                                                    #
# ------------------------------------------------------------------ #

_INSIGHTS_SYSTEM_PROMPT = """\
You are a telecom deployment project assistant writing a brief site status update for a Project Manager.

You will receive workflow step data and PM comments for a single site.
- "completed" steps = the site has already passed through these steps successfully.
- "failed" steps = the site is currently stuck at these steps and needs attention.
- PM comments are running commentary added by PMs over time. Timestamps like "9/13" mean September 13. Focus on the most recent entries only.

Write a short, clear update (3-6 sentences) in plain language a PM can act on:
- Start with where the site is right now (current step, phase, progress).
- Highlight any failures or delays — what step failed and why if error info is available.
- For PM comments: attribute them clearly (e.g. "The PM notes that..." or "Per PM remarks..."). Only correlate a PM comment with workflow status if there is an obvious logical connection (e.g. a delay comment matching a failed step). Otherwise, simply state what the PM has noted recently as a separate observation.
- Do not force-fit PM comments into the workflow narrative. If they are unrelated to the current status, present them as standalone PM observations.
- Keep it conversational and actionable. No headers, no bullet points, no markdown.
- Do not mention steps the site has not reached yet.
- Do not invent information not present in the data."""


class SiteInsightsService:
    """Generates deep, actionable insights for a single site."""

    def __init__(self, db: AsyncSession):
        self.db = db

    # ------------------------------------------------------------------ #
    # Public API                                                           #
    # ------------------------------------------------------------------ #

    async def get_insights(
        self, project_id: str, smp_id: str
    ) -> SiteInsightsResponse:
        """Orchestrate data gathering, analysis, and LLM narrative generation."""

        config = await self._get_project_config(project_id)
        if not config:
            raise SiteInsightsError(f"Project '{project_id}' not found.")

        pipeline_names = self._resolve_pipeline_names(config)

        # Gather workflow insights and PM comments in parallel
        workflow_coro = self._get_all_workflow_insights(
            smp_id, pipeline_names, config
        )
        comments_coro = self._get_pm_comments(smp_id)
        workflows, pm_comments = await asyncio.gather(
            workflow_coro, comments_coro
        )

        # Generate LLM narrative
        narrative = await self._generate_narrative(
            smp_id, project_id, workflows, pm_comments
        )

        structured_summary = self._build_structured_summary(workflows)

        return SiteInsightsResponse(
            smp_id=smp_id,
            project_id=project_id,
            workflows=workflows,
            pm_comments=pm_comments,
            narrative=narrative,
            structured_summary=structured_summary,
            generated_at=datetime.utcnow(),
        )

    # ------------------------------------------------------------------ #
    # Project Config                                                       #
    # ------------------------------------------------------------------ #

    async def _get_project_config(self, project_id: str) -> Optional[Dict[str, Any]]:
        table = settings.TABLES["project_config"]
        row = (
            await self.db.execute(
                text(f"SELECT * FROM {table} WHERE project_id = :pid"),
                {"pid": project_id},
            )
        ).fetchone()
        return dict(row._mapping) if row else None

    @staticmethod
    def _resolve_pipeline_names(config: Dict[str, Any]) -> List[str]:
        """Get pipeline name list from config, supporting both singular and list fields."""
        names_raw = config.get("workflow_pipeline_names")
        if isinstance(names_raw, str):
            try:
                names_raw = json.loads(names_raw)
            except (json.JSONDecodeError, TypeError):
                names_raw = None

        if names_raw and isinstance(names_raw, list):
            return [n for n in names_raw if n]

        singular = config.get("workflow_pipeline_name")
        if singular:
            return [singular]

        return []

    # ------------------------------------------------------------------ #
    # Workflow Insights                                                    #
    # ------------------------------------------------------------------ #

    async def _get_all_workflow_insights(
        self,
        smp_id: str,
        pipeline_names: List[str],
        config: Dict[str, Any],
    ) -> List[WorkflowInsight]:
        """Fetch and analyze workflow data for all pipelines concurrently."""
        if not pipeline_names:
            return []

        tasks = [
            self._get_single_workflow_insight(smp_id, name, config)
            for name in pipeline_names
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        insights = []
        for name, result in zip(pipeline_names, results):
            if isinstance(result, Exception):
                logger.error(
                    "Failed to get workflow insight for pipeline '%s': %s",
                    name, result,
                )
                continue
            insights.append(result)
        return insights

    async def _get_single_workflow_insight(
        self,
        smp_id: str,
        pipeline_name: str,
        config: Dict[str, Any],
    ) -> WorkflowInsight:
        """Analyze a single pipeline for a specific site.

        Only returns steps where the site was actually processed (completed
        or failed). Future/pending steps are excluded.
        Steps are classified as main-path or branch using DAG analysis.
        Current position is derived from the last main-path step.
        """
        client = WorkflowClient()
        pipeline_data = await client.get_pipeline_steps(pipeline_name)

        step_results = pipeline_data.get("step_results", [])
        enabled_steps = [s for s in step_results if s.get("enabled", False)]
        enabled_steps.sort(key=lambda s: s["step_id"])

        join_key = config.get("workflow_join_key") or "smp_id"

        # DAG classification: main-path vs branch
        main_path_ids = get_main_path_step_ids(enabled_steps)

        # Check table existence + site presence in one pass
        wf_schema = settings.WORKFLOW_SCHEMA
        step_table_map = self._build_step_table_map(pipeline_name, enabled_steps)
        existing_tables = await self._check_tables_exist(
            wf_schema, list(step_table_map.values())
        )

        site_statuses = await self._check_site_in_steps_bulk(
            smp_id, join_key, wf_schema, step_table_map, existing_tables
        )

        # Build insights only for steps where the site is present
        completed_steps: List[WorkflowStepInsight] = []
        failed_steps: List[WorkflowStepInsight] = []

        for step in enabled_steps:
            sid = step["step_id"]
            final_status = site_statuses.get(sid)
            if final_status is None:
                continue  # site not in this step — skip entirely

            is_failed = final_status == "fail"
            is_main = sid in main_path_ids
            insight = WorkflowStepInsight(
                step_id=sid,
                step_name=step.get("step_name", f"Step {sid}"),
                step_description=step.get("step_description"),
                phase_name=step.get("phase_name"),
                status="failed" if is_failed else "completed",
                is_main_path=is_main,
                error_message=step.get("error_message") if is_failed else None,
            )

            if is_failed:
                failed_steps.append(insight)
            else:
                completed_steps.append(insight)

        # Current position: last MAIN-PATH step the site reached
        all_site_steps = completed_steps + failed_steps
        all_site_steps.sort(key=lambda s: s.step_id)
        main_site_steps = [s for s in all_site_steps if s.is_main_path]
        current_position = (
            main_site_steps[-1] if main_site_steps
            else (all_site_steps[-1] if all_site_steps else None)
        )

        # Recent completed: last N passed main-path steps
        max_recent = settings.INSIGHTS_MAX_RECENT_STEPS
        main_completed = [s for s in completed_steps if s.is_main_path]
        recent_completed = main_completed[-max_recent:] if main_completed else []

        # Progress: all passed steps / total steps (same as bulk site list)
        total = len(enabled_steps)
        completed_count = len(completed_steps)
        completion_pct = round(completed_count / total * 100, 2) if total else 0.0

        return WorkflowInsight(
            workflow_name=pipeline_data.get("workflow_name", pipeline_name),
            total_steps=total,
            completed_steps=len(completed_steps),
            failed_steps=len(failed_steps),
            completion_pct=completion_pct,
            current_position=current_position,
            recent_completed=recent_completed,
            failed_step_details=failed_steps,
        )

    @staticmethod
    def _build_step_table_map(
        pipeline_name: str, steps: List[Dict[str, Any]]
    ) -> Dict[int, str]:
        """Map step_id -> expected output table name."""
        prefix = pipeline_name.strip().lower().replace(" ", "_")
        prefix = re.sub(r"[^a-zA-Z0-9_]", "", prefix)
        return {
            int(s["step_id"]): f"{prefix}_wf_step_{s['step_id']}_output"
            for s in steps
        }

    async def _check_tables_exist(
        self, schema: str, table_names: List[str]
    ) -> set:
        """Return the subset of table_names that exist in the given schema."""
        if not table_names:
            return set()
        result = await self.db.execute(
            text("""
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = :schema
                  AND table_name = ANY(:names)
            """),
            {"schema": schema, "names": table_names},
        )
        return {r[0] for r in result.fetchall()}

    async def _check_site_in_steps_bulk(
        self,
        smp_id: str,
        join_key: str,
        wf_schema: str,
        step_table_map: Dict[int, str],
        existing_tables: set,
    ) -> Dict[int, str]:
        """Check site presence across all step tables in a single UNION ALL query.

        Returns dict of step_id -> final_status ('pass'/'fail') for steps
        where the site is present.
        """
        if not _SAFE_IDENTIFIER_RE.match(join_key):
            raise SiteInsightsError(
                f"Invalid join key '{join_key}': only alphanumeric and underscore allowed."
            )

        # Build one UNION ALL instead of N separate queries
        # Each branch wrapped in parentheses so LIMIT 1 scopes correctly
        branches = []
        for step_id, table_name in step_table_map.items():
            if table_name not in existing_tables:
                continue
            fq_table = f"{wf_schema}.{table_name}"
            branches.append(
                f"(SELECT {step_id} AS step_id, "
                f"COALESCE(LOWER(final_status), 'pass') AS fs "
                f"FROM {fq_table} WHERE {join_key} = :smp_id LIMIT 1)"
            )

        if not branches:
            return {}

        union_sql = "\nUNION ALL\n".join(branches)
        try:
            rows = (
                await self.db.execute(text(union_sql), {"smp_id": smp_id})
            ).fetchall()
            return {r[0]: r[1] for r in rows}
        except Exception as exc:
            logger.warning(
                "Bulk step query failed for smp_id=%s: %s", smp_id, exc,
            )
            return {}

    # ------------------------------------------------------------------ #
    # PM Comments                                                          #
    # ------------------------------------------------------------------ #

    async def _get_pm_comments(self, smp_id: str) -> List[PMCommentEntry]:
        """Fetch PM comment columns from the staging table."""
        columns = settings.PM_COMMENT_COLUMNS
        table = settings.PM_COMMENTS_TABLE
        site_key = settings.PM_COMMENTS_SITE_KEY

        safe_columns = []
        for col in columns:
            if _SAFE_IDENTIFIER_RE.match(col):
                safe_columns.append(col)
            else:
                logger.warning("Skipping unsafe PM comment column name: %s", col)

        if not safe_columns:
            return []

        select_cols = ", ".join(safe_columns)
        query = f"SELECT {select_cols} FROM {table} WHERE {site_key} = :smp_id LIMIT 1"

        try:
            row = (await self.db.execute(text(query), {"smp_id": smp_id})).fetchone()
        except Exception as exc:
            logger.warning("Failed to fetch PM comments for smp_id=%s: %s", smp_id, exc)
            return []

        entries = []
        for col in safe_columns:
            label = col.replace("pj_", "").replace("_", " ").title()
            raw_text = None
            is_empty = True
            if row:
                val = dict(row._mapping).get(col)
                if val is not None and str(val).strip():
                    raw_text = str(val).strip()
                    is_empty = False
            entries.append(
                PMCommentEntry(
                    column_name=col,
                    column_label=label,
                    raw_text=raw_text,
                    is_empty=is_empty,
                )
            )
        return entries

    # ------------------------------------------------------------------ #
    # LLM Narrative                                                        #
    # ------------------------------------------------------------------ #

    async def _generate_narrative(
        self,
        smp_id: str,
        project_id: str,
        workflows: List[WorkflowInsight],
        pm_comments: List[PMCommentEntry],
    ) -> str:
        """Use the LLM to generate the primary insight narrative."""
        workflow_data = [w.model_dump() for w in workflows]
        comments_data = [
            {"column": c.column_label, "text": c.raw_text}
            for c in pm_comments
            if not c.is_empty
        ]

        user_content = json.dumps(
            {
                "smp_id": smp_id,
                "project_id": project_id,
                "workflows": workflow_data,
                "pm_comments": comments_data,
            },
            indent=2,
            default=str,
        )

        try:
            llm = get_llm()
            response = await llm.ainvoke(
                [
                    SystemMessage(content=_INSIGHTS_SYSTEM_PROMPT),
                    HumanMessage(content=user_content),
                ]
            )
            return response.content.strip()
        except Exception as exc:
            logger.error("LLM narrative generation failed: %s", exc)
            return self._fallback_narrative(smp_id, workflows, pm_comments)

    @staticmethod
    def _fallback_narrative(
        smp_id: str,
        workflows: List[WorkflowInsight],
        pm_comments: List[PMCommentEntry],
    ) -> str:
        """Generate a basic narrative when the LLM gateway is unavailable."""
        parts = [f"Site {smp_id}:"]

        if not workflows:
            parts.append("No workflow data available.")
        else:
            for wf in workflows:
                parts.append(
                    f"{wf.workflow_name} — "
                    f"{wf.completed_steps}/{wf.total_steps} steps done "
                    f"({wf.completion_pct}%)."
                )
                if wf.failed_step_details:
                    names = ", ".join(s.step_name for s in wf.failed_step_details)
                    parts.append(f"Currently stuck at: {names}.")
                if wf.current_position:
                    parts.append(f"Last position: {wf.current_position.step_name}.")

        non_empty = [c for c in pm_comments if not c.is_empty]
        if non_empty:
            parts.append("PM notes:")
            for c in non_empty:
                parts.append(f"  {c.column_label}: {c.raw_text}")

        return " ".join(parts)

    # ------------------------------------------------------------------ #
    # Structured Summary                                                   #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _build_structured_summary(
        workflows: List[WorkflowInsight],
    ) -> Dict[str, Any]:
        """Compute key metrics for UI summary cards."""
        total_steps = sum(w.total_steps for w in workflows)
        completed = sum(w.completed_steps for w in workflows)
        failed = sum(w.failed_steps for w in workflows)
        overall_pct = round(completed / total_steps * 100, 2) if total_steps else 0.0

        failed_names = []
        current_phases = []
        for wf in workflows:
            failed_names.extend(s.step_name for s in wf.failed_step_details)
            if wf.current_position and wf.current_position.phase_name:
                current_phases.append(wf.current_position.phase_name)

        return {
            "total_workflows": len(workflows),
            "total_steps": total_steps,
            "completed_steps": completed,
            "failed_steps": failed,
            "overall_completion_pct": overall_pct,
            "failed_step_names": failed_names,
            "current_phases": current_phases,
        }
