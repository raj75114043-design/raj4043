"""
Workflow DAG utilities — classify steps as main-path vs branch.

Main path = the critical path (longest chain from a root to a terminal node).
Branch    = any step NOT on the main path. Typically dead-end branches that
            don't reconnect to downstream main-path steps.

Both the bulk WorkflowSitesService and the SiteInsightsService use this
to determine a site's canonical status from the main workflow, not from
a parallel branch.
"""

from collections import defaultdict, deque
from typing import Any, Dict, List, Set


def classify_steps(
    steps: List[Dict[str, Any]],
) -> Dict[int, bool]:
    """Classify each step as main-path (True) or branch (False).

    Parameters
    ----------
    steps : list of dicts
        Each dict must have ``step_id: int`` and ``depends_on: list[int]``.

    Returns
    -------
    dict mapping step_id -> is_main_path (bool)

    Algorithm
    ---------
    1. Build a DAG from ``depends_on``.
    2. Topological sort (Kahn's) to assign depth to each node.
    3. Find the critical path (longest path) via DP.
    4. Mark steps on the critical path as main; everything else is branch.
    5. Dead-end detection: steps whose dependents never reach a terminal
       node on the main path are also flagged as branch (redundant with
       the critical-path approach, but makes intent explicit).
    """
    if not steps:
        return {}

    all_ids = {s["step_id"] for s in steps}
    step_deps: Dict[int, List[int]] = {}
    for s in steps:
        step_deps[s["step_id"]] = [d for d in s.get("depends_on", []) if d in all_ids]

    # forward: who I depend on; reverse: who depends on me
    reverse: Dict[int, List[int]] = defaultdict(list)
    in_degree: Dict[int, int] = {sid: 0 for sid in all_ids}

    for sid, deps in step_deps.items():
        in_degree[sid] = len(deps)
        for dep in deps:
            reverse[dep].append(sid)

    # Topological sort + depth
    depth: Dict[int, int] = {}
    queue: deque = deque()
    for sid in all_ids:
        if in_degree[sid] == 0:
            queue.append(sid)
            depth[sid] = 0

    topo_order: List[int] = []
    while queue:
        node = queue.popleft()
        topo_order.append(node)
        for dependent in reverse[node]:
            in_degree[dependent] -= 1
            depth[dependent] = max(depth.get(dependent, 0), depth[node] + 1)
            if in_degree[dependent] == 0:
                queue.append(dependent)

    # Handle any nodes not reached (cycles — shouldn't happen)
    for sid in all_ids:
        if sid not in depth:
            depth[sid] = 0
            topo_order.append(sid)

    # Critical path via DP: dp[node] = length of longest path ending at node
    dp: Dict[int, int] = {}
    parent: Dict[int, int | None] = {}
    for sid in topo_order:
        deps = step_deps[sid]
        if not deps:
            dp[sid] = 1
            parent[sid] = None
        else:
            best_dep = max(deps, key=lambda d: dp.get(d, 1))
            dp[sid] = dp.get(best_dep, 1) + 1
            parent[sid] = best_dep

    # Reconstruct critical path
    main_path_ids: Set[int] = set()
    if dp:
        end_node = max(dp, key=lambda k: dp[k])
        node: int | None = end_node
        while node is not None:
            main_path_ids.add(node)
            node = parent.get(node)

    return {sid: (sid in main_path_ids) for sid in all_ids}


def get_main_path_step_ids(steps: List[Dict[str, Any]]) -> Set[int]:
    """Convenience: return only the step_ids that are on the main path."""
    classification = classify_steps(steps)
    return {sid for sid, is_main in classification.items() if is_main}
