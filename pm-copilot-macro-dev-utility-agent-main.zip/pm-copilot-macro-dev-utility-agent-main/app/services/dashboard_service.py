import logging
from datetime import date, timedelta
from typing import Any, Dict, List, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.models.kpi_models import AggregatedKPIData, DashboardKPIData, DashboardQueryParams, GeoLevelAggregation, SubMetricData

logger = logging.getLogger(__name__)


class DashboardService:
    """
    Async service for querying pre-calculated KPI data for dashboard consumption.
    All DB operations are non-blocking; table names are resolved from settings.TABLES.
    """

    def __init__(self, db: AsyncSession) -> None:
        self.db = db

    async def get_dashboard_kpis(
        self,
        query_params: DashboardQueryParams,
    ) -> List[DashboardKPIData]:
        """
        Fetch KPIs for dashboard based on user persona (project, team, function, geo).

        Returns:
            List of formatted KPI data ready for dashboard rendering.
            Sub-metrics (companion KPIs) are nested inside their parent's `sub_metrics` field.
        """
        # 1. Resolve top-level KPI IDs (parent_kpi_id IS NULL only)
        top_level_ids = await self._get_applicable_kpis(
            project_ids=query_params.project_ids,
            level_ids=query_params.level_ids,
            function_ids=query_params.function_ids,
            kpi_ids=query_params.kpi_ids,
            kpi_category=query_params.kpi_category,
        )

        if not top_level_ids:
            logger.warning("No applicable KPIs found for query parameters")
            return []

        # 2. Auto-fetch sub-metrics for the top-level KPIs
        sub_metric_rows = await self._get_sub_metrics(top_level_ids)
        sub_metric_ids = [r["kpi_id"] for r in sub_metric_rows]

        # parent_kpi_id -> [kpi_id, ...] for grouping later
        sub_metrics_map: Dict[str, List[str]] = {}
        for r in sub_metric_rows:
            sub_metrics_map.setdefault(r["parent_kpi_id"], []).append(r["kpi_id"])

        all_kpi_ids = top_level_ids + sub_metric_ids

        # 3. Resolve geographies
        geo_codes = query_params.geo_codes or await self._get_default_geographies(query_params.geo_level)

        # 4. Determine date range
        date_from = query_params.date_from or (date.today() - timedelta(days=30))
        date_to = query_params.date_to or date.today()

        # 5. Fetch KPI values for top-level + sub-metrics in one query
        kpi_data = await self._fetch_kpi_values(
            kpi_ids=all_kpi_ids,
            geo_codes=geo_codes,
            date_from=date_from,
            date_to=date_to,
            geo_level=query_params.geo_level,
            dimension_key=query_params.dimension_key,
        )

        # 6. Format for dashboard, nesting sub-metrics under their parents
        return self._format_dashboard_response(kpi_data, top_level_ids, sub_metrics_map)

    async def _get_applicable_kpis(
        self,
        project_ids: Optional[List[str]],
        level_ids: Optional[List[str]],
        function_ids: Optional[List[str]],
        kpi_ids: Optional[List[str]],
        kpi_category: Optional[Any] = None,
    ) -> List[str]:
        """
        Get top-level KPI IDs (parent_kpi_id IS NULL) applicable to the user's context.

        Persona filters (project_ids, level_ids, function_ids) use AND (intersection):
        - Only KPIs that satisfy ALL supplied filters are returned.
        - KPIs with NULL in a filtered field are excluded (not treated as wildcard).
        """
        table = settings.TABLES["kpi_master"]
        sql = f"SELECT kpi_id FROM {table} WHERE is_active = TRUE AND parent_kpi_id IS NULL"
        params: Dict[str, Any] = {}

        # Direct ID override — applied first, independently
        if kpi_ids:
            sql += " AND kpi_id = ANY(:kpi_ids)"
            params["kpi_ids"] = kpi_ids

        # Persona filters — each appended with AND so all must match (intersection).
        # The && (array overlap) operator returns NULL when the column is NULL,
        # which is falsy in a WHERE clause, so NULL-valued rows are naturally excluded.
        if project_ids:
            sql += " AND project_ids && :project_ids"
            params["project_ids"] = project_ids

        if level_ids:
            sql += " AND level_ids && :level_ids"
            params["level_ids"] = level_ids

        if function_ids:
            sql += " AND function_ids && :function_ids"
            params["function_ids"] = function_ids

        if kpi_category:
            sql += " AND kpi_category = :kpi_category"
            params["kpi_category"] = kpi_category.value if hasattr(kpi_category, "value") else kpi_category

        sql += " ORDER BY priority ASC"

        results = (await self.db.execute(text(sql), params)).fetchall()
        return [row.kpi_id for row in results]

    async def _get_sub_metrics(self, parent_kpi_ids: List[str]) -> List[Dict[str, Any]]:
        """Fetch sub-metric KPIs (companion values) for the given parent KPI IDs."""
        if not parent_kpi_ids:
            return []
        table = settings.TABLES["kpi_master"]
        q = text(f"""
            SELECT kpi_id, parent_kpi_id
            FROM {table}
            WHERE is_active = TRUE
              AND parent_kpi_id = ANY(:parent_ids)
            ORDER BY priority ASC
        """)
        results = (await self.db.execute(q, {"parent_ids": parent_kpi_ids})).fetchall()
        return [dict(r._mapping) for r in results]

    async def _fetch_kpi_values(
        self,
        kpi_ids: List[str],
        geo_codes: List[str],
        date_from: date,
        date_to: date,
        geo_level: Optional[Any] = None,
        dimension_key: str = "ALL",
    ) -> List[Dict[str, Any]]:
        """
        Fetch KPI values for the dashboard.

        kpi_values_live holds exactly ONE row per (kpi_id, geo_id, dimension_key).
        kpi_values_historical holds every prior calculation, forming the time series.

        We UNION ALL both tables so the formatter receives:
          - The current value (from live, no date filter applied)
          - The historical time series (from historical, filtered by date_from/date_to)
        The formatter groups by (kpi_id, geo_id), sorts by date, and picks the latest
        as current_value — which will always be the live row.
        """
        live_table = settings.TABLES["kpi_values_live"]
        hist_table = settings.TABLES["kpi_values_historical"]
        kpi_table  = settings.TABLES["kpi_master"]
        geo_table  = settings.TABLES["dim_geography"]

        geo_level_filter = ""
        params: Dict[str, Any] = {
            "kpi_ids": kpi_ids,
            "geo_codes": [gc.upper() for gc in geo_codes],  # geo_code is always UPPER in DB
            "date_from": date_from,
            "date_to": date_to,
            "dimension_key": dimension_key,
        }
        if geo_level:
            geo_level_filter = "AND kv.geo_level = :geo_level"
            params["geo_level"] = geo_level.value if hasattr(geo_level, "value") else geo_level

        # Shared column list for both branches of the UNION ALL
        select_cols = """
                kv.kpi_id,
                kv.geo_id,
                kv.geo_level,
                kv.calculation_date,
                kv.kpi_value,
                kv.kpi_value_formatted,
                kv.previous_period_value,
                kv.previous_year_value,
                kv.period_on_period_change_pct,
                kv.year_on_year_change_pct,
                kv.record_count,
                km.kpi_name,
                km.kpi_category,
                km.kpi_tag,
                km.display_format,
                km.unit_symbol,
                km.project_ids,
                km.level_ids,
                km.function_ids,
                (km.drilldown_sql IS NOT NULL) AS has_drilldown,
                dg.geo_name,
                dg.geo_code"""

        joins = f"""
            JOIN {kpi_table} km ON kv.kpi_id = km.kpi_id
            JOIN {geo_table} dg ON kv.geo_id = dg.geo_id"""

        live_branch = f"""
            SELECT {select_cols}
            FROM {live_table} kv {joins}
            WHERE kv.kpi_id = ANY(:kpi_ids)
              AND dg.geo_code = ANY(:geo_codes)
              AND kv.dimension_key = :dimension_key
              {geo_level_filter}"""

        if settings.ENABLE_TIME_SERIES:
            hist_branch = f"""
            UNION ALL
            SELECT {select_cols}
            FROM {hist_table} kv {joins}
            WHERE kv.kpi_id = ANY(:kpi_ids)
              AND dg.geo_code = ANY(:geo_codes)
              AND kv.dimension_key = :dimension_key
              AND kv.calculation_date >= :date_from
              AND kv.calculation_date <= :date_to
              {geo_level_filter}"""
        else:
            hist_branch = ""

        q = text(f"""
            {live_branch}
            {hist_branch}
            ORDER BY kpi_id, geo_code, calculation_date DESC
        """)

        results = (await self.db.execute(q, params)).fetchall()
        return [dict(r._mapping) for r in results]

    def _format_dashboard_response(
        self,
        kpi_data: List[Dict[str, Any]],
        top_level_ids: List[str],
        sub_metrics_map: Dict[str, List[str]],
    ) -> List[DashboardKPIData]:
        """
        Format raw KPI rows into dashboard-ready DashboardKPIData objects.
        Sub-metrics are nested inside their parent's `sub_metrics` field.
        """
        # Group all rows by (kpi_id, geo_id)
        grouped: Dict[tuple, Dict] = {}
        for row in kpi_data:
            key = (row["kpi_id"], row["geo_id"])
            if key not in grouped:
                grouped[key] = {
                    "kpi_id": row["kpi_id"],
                    "kpi_name": row["kpi_name"],
                    "kpi_category": row["kpi_category"],
                    "kpi_tag": row["kpi_tag"],
                    "display_format": row["display_format"],
                    "unit_symbol": row["unit_symbol"],
                    "project_ids": row["project_ids"],
                    "level_ids": row["level_ids"],
                    "function_ids": row["function_ids"],
                    "has_drilldown": row["has_drilldown"],
                    "geo_id": row["geo_id"],
                    "geo_code": row["geo_code"],
                    "geo_name": row["geo_name"],
                    "geo_level": row["geo_level"],
                    "values": [],
                }
            grouped[key]["values"].append({
                "date": row["calculation_date"],
                "value": float(row["kpi_value"]) if row["kpi_value"] else 0,
                "formatted": row["kpi_value_formatted"],
                "previous_period_value": (
                    float(row["previous_period_value"])
                    if row["previous_period_value"] is not None else None
                ),
                "previous_year_value": (
                    float(row["previous_year_value"])
                    if row["previous_year_value"] is not None else None
                ),
                "period_change_pct": (
                    float(row["period_on_period_change_pct"])
                    if row["period_on_period_change_pct"] is not None else None
                ),
                "year_change_pct": (
                    float(row["year_on_year_change_pct"])
                    if row["year_on_year_change_pct"] is not None else None
                ),
            })

        def _to_latest(data: Dict) -> tuple:
            """Sort values, return (latest_dict, trend_str)."""
            data["values"].sort(key=lambda x: x["date"], reverse=True)
            latest = data["values"][0] if data["values"] else None
            if not latest:
                return None, "NEUTRAL"
            pct = latest["period_change_pct"]
            trend = "NEUTRAL" if not pct else ("UP" if pct > 0 else "DOWN")
            return latest, trend

        top_level_set = set(top_level_ids)
        dashboard_kpis: List[DashboardKPIData] = []

        # Build a geo-keyed lookup so we can attach sub-metrics per geo
        # grouped keys are (kpi_id, geo_id)
        for (kpi_id, geo_id), data in grouped.items():
            if kpi_id not in top_level_set:
                continue  # sub-metric — will be nested below

            latest, trend = _to_latest(data)
            if not latest:
                continue

            # Build sub_metrics for this (parent_kpi_id, geo_id) pair
            sub_metrics: List[SubMetricData] = []
            for child_kpi_id in sub_metrics_map.get(kpi_id, []):
                child_data = grouped.get((child_kpi_id, geo_id))
                if not child_data:
                    continue
                child_latest, child_trend = _to_latest(child_data)
                if not child_latest:
                    continue
                sub_metrics.append(SubMetricData(
                    kpi_id=child_kpi_id,
                    kpi_name=child_data["kpi_name"],
                    display_format=child_data["display_format"],
                    unit_symbol=child_data["unit_symbol"],
                    current_value=child_latest["value"],
                    current_value_formatted=child_latest["formatted"],
                    period_change_pct=child_latest["period_change_pct"],
                    trend=child_trend,
                ))

            dashboard_kpis.append(
                DashboardKPIData(
                    kpi_id=kpi_id,
                    kpi_name=data["kpi_name"],
                    kpi_category=data["kpi_category"],
                    kpi_tag=data["kpi_tag"],
                    display_format=data["display_format"],
                    unit_symbol=data["unit_symbol"],
                    project_ids=data["project_ids"],
                    level_ids=data["level_ids"],
                    function_ids=data["function_ids"],
                    has_drilldown=bool(data["has_drilldown"]),
                    geo_id=geo_id,
                    geo_code=data["geo_code"],
                    geo_name=data["geo_name"],
                    geo_level=data["geo_level"],
                    current_value=latest["value"],
                    current_value_formatted=latest["formatted"],
                    previous_period_value=latest["previous_period_value"],
                    previous_year_value=latest["previous_year_value"],
                    period_change_pct=latest["period_change_pct"],
                    year_change_pct=latest["year_change_pct"],
                    trend=trend,
                    time_series=data["values"],
                    sub_metrics=sub_metrics,
                )
            )

        # Restore priority order (top_level_ids is already ordered by priority ASC
        # from _get_applicable_kpis; the grouped dict may have broken that order)
        id_order = {kid: i for i, kid in enumerate(top_level_ids)}
        dashboard_kpis.sort(key=lambda x: id_order.get(x.kpi_id, len(top_level_ids)))

        return dashboard_kpis

    async def _get_default_geographies(self, geo_level: Optional[Any] = None) -> List[str]:
        """Return active geo_codes, optionally scoped to a specific geography level."""
        table = settings.TABLES["dim_geography"]
        if geo_level:
            level_val = geo_level.value if hasattr(geo_level, "value") else geo_level
            q = text(f"SELECT geo_code FROM {table} WHERE is_active = TRUE AND geo_level = :geo_level")
            results = (await self.db.execute(q, {"geo_level": level_val})).fetchall()
        else:
            q = text(f"SELECT geo_code FROM {table} WHERE is_active = TRUE")
            results = (await self.db.execute(q)).fetchall()
        return [row.geo_code for row in results]

    async def _fetch_aggregation_rows(
        self,
        kpi_ids: List[str],
        geo_codes: List[str],
        geo_level: Optional[str] = None,
        dimension_key: str = "ALL",
    ) -> List[Dict[str, Any]]:
        """Fetch raw rows from kpi_values_live for aggregation (shared by both endpoints)."""
        live_table = settings.TABLES["kpi_values_live"]
        kpi_table  = settings.TABLES["kpi_master"]
        geo_table  = settings.TABLES["dim_geography"]

        params: Dict[str, Any] = {
            "kpi_ids": kpi_ids,
            "geo_codes": [gc.upper() for gc in geo_codes],
            "dimension_key": dimension_key,
        }
        geo_level_filter = ""
        if geo_level:
            geo_level_filter = "AND kv.geo_level = :geo_level"
            params["geo_level"] = geo_level

        q = text(f"""
            SELECT
                kv.kpi_id,
                kv.geo_level,
                kv.kpi_value,
                kv.previous_period_value,
                kv.previous_year_value,
                kv.record_count,
                km.kpi_name,
                km.kpi_category,
                km.kpi_tag,
                km.display_format,
                km.unit_symbol,
                km.decimal_places,
                km.aggregation_method,
                km.priority,
                dg.geo_code
            FROM {live_table} kv
            JOIN {kpi_table} km ON kv.kpi_id = km.kpi_id
            JOIN {geo_table} dg ON kv.geo_id  = dg.geo_id
            WHERE kv.kpi_id = ANY(:kpi_ids)
              AND UPPER(dg.geo_code) = ANY(:geo_codes)
              AND kv.dimension_key = :dimension_key
              {geo_level_filter}
        """)

        rows = (await self.db.execute(q, params)).fetchall()
        return [dict(r._mapping) for r in rows]

    def _aggregate_rows(
        self,
        rows: List[Dict[str, Any]],
        aggregation_override: Optional[str] = None,
    ) -> List[AggregatedKPIData]:
        """
        Group rows by kpi_id and aggregate into AggregatedKPIData (without sub_metrics).
        Shared logic used by both aggregate_kpi_values and aggregate_project_kpis.
        """
        if not rows:
            return []

        groups: Dict[str, List[Dict]] = {}
        meta: Dict[str, Dict] = {}
        for row in rows:
            kid = row["kpi_id"]
            groups.setdefault(kid, []).append(row)
            meta[kid] = row

        results: List[AggregatedKPIData] = []

        for kpi_id, group_rows in sorted(groups.items(), key=lambda kv: meta[kv[0]].get("priority", 999)):
            m = meta[kpi_id]
            method = self._resolve_aggregation_method(
                m["aggregation_method"], m["display_format"], aggregation_override
            )

            values     = [r["kpi_value"]            for r in group_rows if r["kpi_value"]            is not None]
            prev_p     = [r["previous_period_value"] for r in group_rows if r["previous_period_value"] is not None]
            prev_y     = [r["previous_year_value"]   for r in group_rows if r["previous_year_value"]   is not None]
            rec_counts = [r["record_count"]           for r in group_rows if r["record_count"]           is not None]

            agg_value   = self._apply_aggregation(method, values, rec_counts)
            agg_prev_p  = self._apply_aggregation(method, prev_p, rec_counts)
            agg_prev_y  = self._apply_aggregation(method, prev_y, rec_counts)
            total_recs  = sum(rec_counts) if rec_counts else 0

            period_pct = self._change_pct(agg_value, agg_prev_p)
            year_pct   = self._change_pct(agg_value, agg_prev_y)
            trend = "NEUTRAL" if not period_pct else ("UP" if period_pct > 0 else "DOWN")

            formatted = self._format_value(agg_value, m["display_format"], m["decimal_places"], m["unit_symbol"])

            results.append(AggregatedKPIData(
                kpi_id=kpi_id,
                kpi_name=m["kpi_name"],
                kpi_category=m["kpi_category"],
                kpi_tag=m["kpi_tag"],
                display_format=m["display_format"],
                unit_symbol=m["unit_symbol"],
                aggregation_method=method,
                geo_codes_included=[r["geo_code"] for r in group_rows],
                geo_count=len(group_rows),
                current_value=agg_value,
                current_value_formatted=formatted,
                previous_period_value=agg_prev_p,
                previous_year_value=agg_prev_y,
                period_change_pct=period_pct,
                year_change_pct=year_pct,
                trend=trend,
                total_record_count=total_recs,
            ))

        return results

    async def _aggregate_with_sub_metrics(
        self,
        parent_kpi_ids: List[str],
        geo_codes: List[str],
        geo_level: Optional[str],
        aggregation_override: Optional[str],
        dimension_key: str = "ALL",
    ) -> List[AggregatedKPIData]:
        """
        Aggregate parent KPIs, then fetch + aggregate their sub-metrics and
        nest them under each parent's sub_metrics field.
        """
        # 1. Fetch and aggregate parent KPI rows
        parent_rows = await self._fetch_aggregation_rows(
            parent_kpi_ids, geo_codes, geo_level, dimension_key
        )
        parent_results = self._aggregate_rows(parent_rows, aggregation_override)
        if not parent_results:
            return []

        # 2. Find sub-metrics for these parents
        sub_metric_rows = await self._get_sub_metrics(parent_kpi_ids)
        if not sub_metric_rows:
            return parent_results

        # parent_kpi_id -> [child_kpi_id, ...]
        sub_map: Dict[str, List[str]] = {}
        for r in sub_metric_rows:
            sub_map.setdefault(r["parent_kpi_id"], []).append(r["kpi_id"])
        all_child_ids = [r["kpi_id"] for r in sub_metric_rows]

        # 3. Fetch and aggregate sub-metric rows
        child_rows = await self._fetch_aggregation_rows(
            all_child_ids, geo_codes, geo_level, dimension_key
        )
        child_results = self._aggregate_rows(child_rows, aggregation_override)
        child_by_id: Dict[str, AggregatedKPIData] = {c.kpi_id: c for c in child_results}

        # 4. Nest sub-metrics under their parent
        for parent in parent_results:
            child_ids = sub_map.get(parent.kpi_id, [])
            for cid in child_ids:
                child = child_by_id.get(cid)
                if not child:
                    continue
                parent.sub_metrics.append(SubMetricData(
                    kpi_id=child.kpi_id,
                    kpi_name=child.kpi_name,
                    display_format=child.display_format,
                    unit_symbol=child.unit_symbol,
                    current_value=child.current_value,
                    current_value_formatted=child.current_value_formatted,
                    period_change_pct=child.period_change_pct,
                    trend=child.trend,
                ))

        return parent_results

    @staticmethod
    def _apply_aggregation(method: str, vals: list, rec_counts: list) -> Optional[float]:
        if not vals:
            return None
        if method in ("SUM", "COUNT"):
            return sum(vals)
        if method == "AVG":
            return sum(vals) / len(vals)
        if method == "MIN":
            return min(vals)
        if method == "MAX":
            return max(vals)
        if method == "WEIGHTED_AVG":
            total_w = sum(rec_counts)
            if total_w:
                return sum(v * w for v, w in zip(vals, rec_counts)) / total_w
            return sum(vals) / len(vals)
        return sum(vals)

    @staticmethod
    def _change_pct(current, previous) -> Optional[float]:
        if current is None or previous is None or previous == 0:
            return None
        return ((current - previous) / abs(previous)) * 100

    async def aggregate_kpi_values(
        self,
        kpi_ids: List[str],
        geo_codes: List[str],
        geo_level: Optional[str] = None,
        aggregation_override: Optional[str] = None,
        dimension_key: str = "ALL",
    ) -> List[AggregatedKPIData]:
        """
        Fetch KPI values for the given KPIs + geographies from kpi_values_live
        and aggregate them into one result per KPI, including sub-metrics.

        Aggregation per KPI uses the KPI's configured aggregation_method unless
        aggregation_override is supplied (applies to all KPIs in the request).

        SUM / COUNT  → sum values across geos
        AVG          → average values across geos
        MIN          → minimum value across geos
        MAX          → maximum value across geos
        WEIGHTED_AVG → weighted average (weight = record_count)

        Change percentages are recalculated from the aggregated current and
        previous values rather than averaged from individual percentages.
        """
        return await self._aggregate_with_sub_metrics(
            parent_kpi_ids=kpi_ids,
            geo_codes=geo_codes,
            geo_level=geo_level,
            aggregation_override=aggregation_override,
            dimension_key=dimension_key,
        )

    async def aggregate_project_kpis(
        self,
        project_id: str,
        geo_codes: List[str],
        function_ids: Optional[List[str]] = None,
        level_ids: Optional[List[str]] = None,
        aggregation_override: Optional[str] = None,
        dimension_key: str = "ALL",
    ) -> tuple:
        """
        Aggregate all KPIs in a project across the requested geographies,
        including sub-metrics.

        Enforces level isolation: geo_codes are resolved to their geo_level first,
        then grouped. Aggregation only happens within the same level — MARKET values
        are never combined with AREA or REGION values.

        Returns (by_level: List[GeoLevelAggregation], unresolved: List[str])
        """
        geo_table  = settings.TABLES["dim_geography"]
        kpi_table  = settings.TABLES["kpi_master"]

        # 1. Resolve each requested geo_code to its level
        q = text(f"""
            SELECT geo_code, geo_level
            FROM {geo_table}
            WHERE UPPER(geo_code) = ANY(:geo_codes)
              AND is_active = TRUE
        """)
        resolved_rows = (await self.db.execute(
            q, {"geo_codes": [gc.upper() for gc in geo_codes]}
        )).fetchall()

        resolved_map: Dict[str, str] = {r.geo_code: r.geo_level for r in resolved_rows}
        unresolved = [gc for gc in geo_codes if gc.upper() not in {k.upper() for k in resolved_map}]

        if not resolved_map:
            return [], unresolved

        # 2. Group resolved geo_codes by level
        by_level_geos: Dict[str, List[str]] = {}
        for geo_code, geo_level in resolved_map.items():
            by_level_geos.setdefault(geo_level, []).append(geo_code)

        # 3. Fetch all project KPIs (top-level only)
        all_kpi_ids = await self._get_applicable_kpis(
            project_ids=[project_id],
            level_ids=level_ids,
            function_ids=function_ids,
            kpi_ids=None,
        )
        if not all_kpi_ids:
            return [], unresolved

        # 4. Fetch applicable_geo_levels for each KPI
        kpi_levels_q = text(f"""
            SELECT kpi_id, applicable_geo_levels
            FROM {kpi_table}
            WHERE kpi_id = ANY(:kpi_ids) AND is_active = TRUE
        """)
        kpi_level_rows = (await self.db.execute(kpi_levels_q, {"kpi_ids": all_kpi_ids})).fetchall()
        kpi_applicable: Dict[str, List[str]] = {
            r.kpi_id: r.applicable_geo_levels for r in kpi_level_rows
        }

        # 5. For each geo level group, aggregate KPIs + sub-metrics applicable to that level
        by_level_results: List[GeoLevelAggregation] = []

        for geo_level, level_geo_codes in by_level_geos.items():
            applicable_kpi_ids = [
                kid for kid, levels in kpi_applicable.items()
                if geo_level in levels
            ]
            if not applicable_kpi_ids:
                continue

            aggregated_kpis = await self._aggregate_with_sub_metrics(
                parent_kpi_ids=applicable_kpi_ids,
                geo_codes=level_geo_codes,
                geo_level=geo_level,
                aggregation_override=aggregation_override,
                dimension_key=dimension_key,
            )
            if not aggregated_kpis:
                continue

            by_level_results.append(GeoLevelAggregation(
                geo_level=geo_level,
                geo_codes_included=level_geo_codes,
                total_kpis=len(aggregated_kpis),
                kpis=aggregated_kpis,
            ))

        # Return levels in hierarchy order
        level_order = {"OVERALL": 0, "REGION": 1, "AREA": 2, "MARKET": 3}
        by_level_results.sort(key=lambda x: level_order.get(x.geo_level, 99))

        return by_level_results, unresolved

    @staticmethod
    def _resolve_aggregation_method(
        configured_method: str,
        display_format: str,
        aggregation_override: Optional[str],
    ) -> str:
        """
        Determine the effective aggregation method for a KPI.

        Rules (in priority order):
        1. Explicit caller override always wins.
        2. Percentage / rate KPIs (PERCENTAGE, DAYS display format) use WEIGHTED_AVG
           regardless of the configured method — summing or simple-averaging a rate
           produces a meaningless number.
        3. Everything else uses the KPI's configured aggregation_method.
        """
        if aggregation_override:
            return aggregation_override
        if display_format in ("PERCENTAGE", "DAYS"):
            return "WEIGHTED_AVG"
        return configured_method

    def _format_value(
        self,
        value: Optional[float],
        display_format: str,
        decimal_places: int,
        unit_symbol: Optional[str],
    ) -> str:
        if value is None:
            return "N/A"
        if display_format == "CURRENCY":
            return f"{unit_symbol or '$'}{value:,.{decimal_places}f}"
        if display_format == "PERCENTAGE":
            return f"{value:.{decimal_places}f}%"
        if display_format == "DAYS":
            return f"{value:.{decimal_places}f} days"
        formatted = f"{value:,.{decimal_places}f}"
        return f"{formatted} {unit_symbol}" if unit_symbol else formatted

    async def get_geography_drilldown(
        self,
        kpi_id: str,
        parent_geo_code: str,
        calculation_date: date,
    ) -> List[Dict[str, Any]]:
        """
        Get KPI values for child geographies (drill-down functionality).
        Example: Given a REGION geo_code (e.g. 'APAC'), returns KPI values for all AREAs under it.
        """
        live_table = settings.TABLES["kpi_values_live"]
        geo_table = settings.TABLES["dim_geography"]

        q = text(f"""
            SELECT
                dg.geo_code,
                dg.geo_name,
                dg.geo_level,
                kv.kpi_value,
                kv.kpi_value_formatted,
                kv.period_on_period_change_pct

            FROM {live_table} kv
            JOIN {geo_table} dg ON kv.geo_id = dg.geo_id

            WHERE kv.kpi_id = :kpi_id
              AND kv.calculation_date = :calculation_date
              AND dg.parent_geo_id = (
                  SELECT geo_id FROM {geo_table}
                  WHERE geo_code = :parent_geo_code
                  LIMIT 1
              )
              AND dg.is_active = TRUE

            ORDER BY kv.kpi_value DESC
        """)

        results = (
            await self.db.execute(
                q,
                {
                    "kpi_id": kpi_id,
                    "calculation_date": calculation_date,
                    "parent_geo_code": parent_geo_code,
                },
            )
        ).fetchall()

        return [dict(r._mapping) for r in results]
