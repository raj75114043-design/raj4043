import json
import logging
import math
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings

logger = logging.getLogger(__name__)


class SitesService:
    """
    Manages the dim_sites materialized table.

    Responsibilities:
    - config-driven daily refresh (one project at a time, independent)
    - paginated + filtered site queries
    - summary / distribution stats
    - filter-options for dropdown population
    """

    def __init__(self, db: AsyncSession):
        self.db = db

    # ------------------------------------------------------------------ #
    # Refresh                                                              #
    # ------------------------------------------------------------------ #

    async def refresh_project_sites(self, project_id: str) -> Dict[str, Any]:
        """
        Refresh dim_sites for one project using its site_source_query config.

        Flow:
          1. Load project config (source query, column defs, computed expressions)
          2. Build a full SELECT that wraps the source query and injects computed columns
          3. DELETE existing rows for this project
          4. Bulk INSERT new rows in batches of 5 000
          5. Return a result summary

        Raises ValueError if the project has no site_source_query configured.
        """
        config = await self._get_project_config(project_id)
        if not config:
            raise ValueError(f"Project '{project_id}' not found.")

        source_query = (config.get("site_source_query") or "").strip().rstrip(";")
        if not source_query:
            raise ValueError(
                f"Project '{project_id}' has no site_source_query configured. "
                "Set it via POST /api/v1/project-config before refreshing."
            )

        _raw_cols = config.get("site_columns") or {}
        col_config: Dict[str, Any] = json.loads(_raw_cols) if isinstance(_raw_cols, str) else _raw_cols

        # -------------------------------------------------------------- #
        # Probe source query to discover which columns are present        #
        # -------------------------------------------------------------- #
        probe_sql = f"SELECT * FROM ({source_query}) src WHERE false"
        try:
            probe_result = await self.db.execute(text(probe_sql))
            source_cols = set(probe_result.keys())
        except Exception as exc:
            raise ValueError(f"site_source_query failed: {exc}") from exc

        def _col(name: str) -> str:
            if name in source_cols:
                return f"src.{name}::VARCHAR"
            return "NULL::VARCHAR"

        # -------------------------------------------------------------- #
        # Build the enriched SELECT from the source query                 #
        # -------------------------------------------------------------- #
        # phase and progress_pct come from source query if present, else NULL
        phase_expr    = "src.phase::VARCHAR"        if "phase"        in source_cols else "NULL::VARCHAR"
        progress_expr = "src.progress_pct::NUMERIC" if "progress_pct" in source_cols else "NULL::NUMERIC"

        # Collect project-specific attribute columns
        attr_cols = list(col_config.keys())

        # Build JSONB object expression: jsonb_build_object('k1', src.k1, 'k2', src.k2, ...)
        if attr_cols:
            pairs = ", ".join(f"'{c}', src.{c}" for c in attr_cols)
            attributes_expr = f"jsonb_build_object({pairs})"
        else:
            attributes_expr = "'{}'::jsonb"

        enriched_sql = f"""
            SELECT
                src.site_id::VARCHAR   AS site_id,
                {_col('region_code')}  AS region_code,
                {_col('area_code')}    AS area_code,
                {_col('market_code')}  AS market_code,
                {_col('status')}       AS status,
                {phase_expr}           AS phase,
                {progress_expr}        AS progress_pct,
                {attributes_expr}      AS attributes
            FROM ({source_query}) src
            WHERE src.site_id IS NOT NULL
        """

        logger.info("Fetching source sites for project '%s'", project_id)
        try:
            rows = (await self.db.execute(text(enriched_sql))).fetchall()
        except Exception as exc:
            raise ValueError(f"site_source_query failed: {exc}") from exc

        total_fetched = len(rows)
        logger.info("Fetched %d source rows for project '%s'", total_fetched, project_id)

        # -------------------------------------------------------------- #
        # Swap: delete old rows, bulk insert new ones                     #
        # -------------------------------------------------------------- #
        sites_table = settings.TABLES["dim_sites"]
        now = datetime.utcnow()

        await self.db.execute(
            text(f"DELETE FROM {sites_table} WHERE project_id = :pid"),
            {"pid": project_id},
        )

        batch_size = 5_000
        inserted = 0
        for i in range(0, total_fetched, batch_size):
            batch = rows[i : i + batch_size]
            params = []
            for r in batch:
                rd = dict(r._mapping)
                attrs = rd.get("attributes")
                params.append({
                    "site_id":      str(rd["site_id"]),
                    "project_id":   project_id,
                    "region_code":  rd.get("region_code"),
                    "area_code":    rd.get("area_code"),
                    "market_code":  rd.get("market_code"),
                    "phase":        rd.get("phase"),
                    "progress_pct": rd.get("progress_pct"),
                    "status":       rd.get("status"),
                    "attributes":   json.dumps(attrs) if isinstance(attrs, dict) else (attrs or "{}"),
                    "last_refreshed": now,
                })

            await self.db.execute(
                text(f"""
                    INSERT INTO {sites_table} (
                        site_id, project_id,
                        region_code, area_code, market_code,
                        phase, progress_pct, status,
                        attributes, last_refreshed
                    ) VALUES (
                        :site_id, :project_id,
                        :region_code, :area_code, :market_code,
                        :phase, :progress_pct, :status,
                        CAST(:attributes AS jsonb), :last_refreshed
                    )
                    ON CONFLICT (project_id, site_id) DO UPDATE SET
                        region_code    = EXCLUDED.region_code,
                        area_code      = EXCLUDED.area_code,
                        market_code    = EXCLUDED.market_code,
                        phase          = EXCLUDED.phase,
                        progress_pct   = EXCLUDED.progress_pct,
                        status         = EXCLUDED.status,
                        attributes     = EXCLUDED.attributes,
                        last_refreshed = EXCLUDED.last_refreshed
                """),
                params,
            )
            inserted += len(batch)

        await self.db.commit()
        logger.info(
            "Site refresh complete for '%s': %d rows inserted", project_id, inserted
        )

        return {
            "project_id":    project_id,
            "rows_fetched":  total_fetched,
            "rows_inserted": inserted,
            "refreshed_at":  now.isoformat(),
        }

    # ------------------------------------------------------------------ #
    # Query                                                                #
    # ------------------------------------------------------------------ #

    _BRACKET_CONDITIONS: Dict[str, str] = {
        "100%":   "progress_pct = 100",
        "80-99%": "progress_pct >= 80 AND progress_pct < 100",
        "60-79%": "progress_pct >= 60 AND progress_pct < 80",
        "40-59%": "progress_pct >= 40 AND progress_pct < 60",
        "20-39%": "progress_pct >= 20 AND progress_pct < 40",
        "1-19%":  "progress_pct > 0  AND progress_pct < 20",
        "0%":     "progress_pct = 0",
        "n/a":    "progress_pct IS NULL",
    }

    async def list_sites(
        self,
        project_id: str,
        region_code: Optional[str] = None,
        area_code: Optional[str] = None,
        market_code: Optional[str] = None,
        phase: Optional[str] = None,
        status: Optional[str] = None,
        progress_bracket: Optional[str] = None,
        search: Optional[str] = None,
        page: int = 1,
        page_size: int = 500,
    ) -> Dict[str, Any]:
        """
        Return a paginated, filtered page of sites for a project.
        Uses COUNT(*) OVER() window function to avoid a separate count query.
        """
        table = settings.TABLES["dim_sites"]

        clauses = ["project_id = :project_id"]
        params: Dict[str, Any] = {"project_id": project_id}

        def _multi(col: str, val: Optional[str], upper: bool = False) -> None:
            if not val:
                return
            values = [v.strip().upper() if upper else v.strip() for v in val.split(",") if v.strip()]
            if not values:
                return
            if len(values) == 1:
                clauses.append(f"{col} = :{col}")
                params[col] = values[0]
            else:
                clauses.append(f"{col} = ANY(:{col})")
                params[col] = values

        _multi("region_code",  region_code,  upper=True)
        _multi("area_code",    area_code,    upper=True)
        _multi("market_code",  market_code,  upper=True)
        _multi("phase",        phase)
        _multi("status",       status)
        if progress_bracket:
            condition = self._BRACKET_CONDITIONS.get(progress_bracket.lower())
            if condition:
                clauses.append(f"({condition})")
        if search:
            clauses.append("""(
                site_id      ILIKE :search OR
                region_code  ILIKE :search OR
                area_code    ILIKE :search OR
                market_code  ILIKE :search OR
                phase        ILIKE :search OR
                status       ILIKE :search OR
                attributes::text ILIKE :search
            )""")
            params["search"] = f"%{search}%"

        where = " AND ".join(clauses)
        params["limit"]  = page_size
        params["offset"] = (page - 1) * page_size

        sql = f"""
            SELECT *, COUNT(*) OVER() AS _total_count
            FROM {table}
            WHERE {where}
            ORDER BY site_id
            LIMIT :limit OFFSET :offset
        """

        rows = (await self.db.execute(text(sql), params)).fetchall()

        total      = rows[0]._total_count if rows else 0
        last_ref   = rows[0].last_refreshed if rows else None
        data       = [self._row_to_dict(r) for r in rows]

        return {
            "total":          total,
            "page":           page,
            "page_size":      page_size,
            "pages":          math.ceil(total / page_size) if total else 0,
            "project_id":     project_id,
            "last_refreshed": last_ref,
            "data":           data,
        }

    async def get_site(self, project_id: str, site_id: str) -> Optional[Dict[str, Any]]:
        table = settings.TABLES["dim_sites"]
        row = (await self.db.execute(
            text(f"SELECT * FROM {table} WHERE project_id = :pid AND site_id = :sid"),
            {"pid": project_id, "sid": site_id},
        )).fetchone()
        return self._row_to_dict(row) if row else None

    async def get_summary(
        self,
        project_id: str,
        region_code: Optional[str] = None,
        area_code: Optional[str] = None,
        market_code: Optional[str] = None,
        phase: Optional[str] = None,
        status: Optional[str] = None,
        progress_bracket: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Aggregate stats for dashboard cards: total count, avg progress,
        distribution by phase and by status.
        All filters support comma-separated multi-values.
        """
        table = settings.TABLES["dim_sites"]

        clauses = ["project_id = :project_id"]
        params: Dict[str, Any] = {"project_id": project_id}

        def _multi(col: str, val: Optional[str], upper: bool = False) -> None:
            if not val:
                return
            values = [v.strip().upper() if upper else v.strip() for v in val.split(",") if v.strip()]
            if not values:
                return
            if len(values) == 1:
                clauses.append(f"{col} = :{col}")
                params[col] = values[0]
            else:
                clauses.append(f"{col} = ANY(:{col})")
                params[col] = values

        _multi("region_code",  region_code,  upper=True)
        _multi("area_code",    area_code,    upper=True)
        _multi("market_code",  market_code,  upper=True)
        _multi("phase",        phase)
        _multi("status",       status)
        if progress_bracket:
            condition = self._BRACKET_CONDITIONS.get(progress_bracket.lower())
            if condition:
                clauses.append(f"({condition})")

        where = " AND ".join(clauses)

        totals_row = (await self.db.execute(text(f"""
            SELECT
                COUNT(*)                    AS total_sites,
                MAX(last_refreshed)         AS last_refreshed
            FROM {table}
            WHERE {where}
        """), params)).fetchone()

        total = totals_row.total_sites if totals_row else 0

        progress_rows = (await self.db.execute(text(f"""
            SELECT
                CASE
                    WHEN progress_pct = 100                    THEN '100%'
                    WHEN progress_pct >= 80                    THEN '80-99%'
                    WHEN progress_pct >= 60                    THEN '60-79%'
                    WHEN progress_pct >= 40                    THEN '40-59%'
                    WHEN progress_pct >= 20                    THEN '20-39%'
                    WHEN progress_pct > 0                      THEN '1-19%'
                    WHEN progress_pct = 0                      THEN '0%'
                    ELSE 'N/A'
                END AS bracket,
                COUNT(*) AS cnt
            FROM {table}
            WHERE {where}
            GROUP BY bracket
            ORDER BY MIN(COALESCE(progress_pct, -1)) DESC
        """), params)).fetchall()

        phase_rows = (await self.db.execute(text(f"""
            SELECT phase, COUNT(*) AS cnt
            FROM {table}
            WHERE {where}
            GROUP BY phase
            ORDER BY phase
        """), params)).fetchall()

        status_rows = (await self.db.execute(text(f"""
            SELECT status, COUNT(*) AS cnt
            FROM {table}
            WHERE {where}
            GROUP BY status
            ORDER BY status
        """), params)).fetchall()

        by_progress = {
            r.bracket: {
                "count": r.cnt,
                "pct_of_total": round(r.cnt * 100.0 / total, 1) if total else 0.0,
            }
            for r in progress_rows
        }

        return {
            "project_id":     project_id,
            "total_sites":    total,
            "last_refreshed": totals_row.last_refreshed if totals_row else None,
            "by_progress":    by_progress,
            "by_phase":       {r.phase:  r.cnt for r in phase_rows  if r.phase},
            "by_status":      {r.status: r.cnt for r in status_rows if r.status},
        }

    async def get_filter_options(self, project_id: str) -> Dict[str, Any]:
        """
        Distinct values for each filterable column — used to populate dropdowns.
        Cached naturally by the daily refresh cycle.
        """
        table = settings.TABLES["dim_sites"]
        params = {"project_id": project_id}

        async def distinct(col: str) -> List[str]:
            rows = (await self.db.execute(text(f"""
                SELECT DISTINCT {col} FROM {table}
                WHERE project_id = :project_id AND {col} IS NOT NULL
                ORDER BY {col}
            """), params)).fetchall()
            return [r[0] for r in rows]

        # Load column config to know which attribute fields are filterable
        config     = await self._get_project_config(project_id)
        col_config = (config or {}).get("site_columns") or {}
        filterable = [k for k, v in col_config.items() if v.get("filterable")]

        attr_options: Dict[str, List] = {}
        for col in filterable:
            rows = (await self.db.execute(text(f"""
                SELECT DISTINCT attributes->>:col AS val
                FROM {table}
                WHERE project_id = :project_id
                  AND attributes->>:col IS NOT NULL
                ORDER BY val
            """), {"project_id": project_id, "col": col})).fetchall()
            attr_options[col] = [r[0] for r in rows]

        # Progress brackets that actually have sites
        bracket_rows = (await self.db.execute(text(f"""
            SELECT DISTINCT
                CASE
                    WHEN progress_pct = 100  THEN '100%'
                    WHEN progress_pct >= 80  THEN '80-99%'
                    WHEN progress_pct >= 60  THEN '60-79%'
                    WHEN progress_pct >= 40  THEN '40-59%'
                    WHEN progress_pct >= 20  THEN '20-39%'
                    WHEN progress_pct > 0   THEN '1-19%'
                    WHEN progress_pct = 0   THEN '0%'
                    ELSE 'N/A'
                END AS bracket
            FROM {table}
            WHERE project_id = :project_id
            ORDER BY bracket
        """), params)).fetchall()
        progress_brackets = [r[0] for r in bracket_rows]

        return {
            "project_id":       project_id,
            "region_codes":     await distinct("region_code"),
            "area_codes":       await distinct("area_code"),
            "market_codes":     await distinct("market_code"),
            "phases":           await distinct("phase"),
            "statuses":         await distinct("status"),
            "progress_brackets": progress_brackets,
            "attributes":       attr_options,
        }

    # ------------------------------------------------------------------ #
    # Helpers                                                              #
    # ------------------------------------------------------------------ #

    async def _get_project_config(self, project_id: str) -> Optional[Dict[str, Any]]:
        table = settings.TABLES["project_config"]
        row = (await self.db.execute(
            text(f"SELECT * FROM {table} WHERE project_id = :pid"),
            {"pid": project_id},
        )).fetchone()
        return dict(row._mapping) if row else None

    @staticmethod
    def _row_to_dict(row) -> Dict[str, Any]:
        d = dict(row._mapping)
        # Drop the window-function helper column if present
        d.pop("_total_count", None)
        return d

    @staticmethod
    def make_job_id() -> str:
        return f"SITE_REFRESH_{uuid.uuid4().hex[:12].upper()}"
