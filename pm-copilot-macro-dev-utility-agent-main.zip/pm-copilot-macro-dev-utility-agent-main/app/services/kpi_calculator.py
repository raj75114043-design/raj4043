import asyncio
import logging
import time
import uuid
from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.core.database import AsyncSessionLocal
from app.core.exceptions import CalculationError, QueryExecutionError
from app.models.kpi_models import JobStatus, JobType
from app.services.project_config_service import ProjectConfigService
from app.utils.date_utils import get_date_parts

logger = logging.getLogger(__name__)


class KPICalculator:
    """
    Async KPI Calculation Engine.

    Improvements over the original synchronous implementation:
    - All DB calls are async (non-blocking, asyncpg-backed).
    - Comparison values (previous period / previous year) are pre-fetched in a
      single bulk query instead of one query per (KPI, geo) pair.
    - Individual KPI queries run concurrently via asyncio.gather(), bounded by
      settings.MAX_CONCURRENT_KPI_QUERIES (DB-pool semaphore).
    - All computed rows are written in a single bulk upsert per job.
    - Table names are resolved from settings.TABLES (no hardcoding).
    - New entry-point execute_batch_by_level() supports batch-refresh for a
      single geo level (MARKET or AREA) without entity-by-entity iteration.
    """

    def __init__(self, db: AsyncSession) -> None:
        self.db = db
        self.job_id: Optional[str] = None

    # ------------------------------------------------------------------ #
    # Public API                                                           #
    # ------------------------------------------------------------------ #

    @staticmethod
    async def mark_stale_jobs_failed(db: AsyncSession) -> int:
        """
        Mark any RUNNING jobs as FAILED on startup.

        Jobs stuck in RUNNING state after a server restart will never complete.
        This is called once at app startup to clean up stale records.
        Returns the number of jobs marked as failed.
        """
        table = settings.TABLES["calculation_jobs"]
        q = text(f"""
            UPDATE {table}
            SET status = 'FAILED',
                error_message = 'Server restarted while job was running',
                completed_at = :now,
                updated_at = :now
            WHERE status = 'RUNNING'
        """)
        result = await db.execute(q, {"now": datetime.now()})
        await db.commit()
        return result.rowcount

    async def create_pending_job(
        self,
        job_type: JobType,
        calculation_date: date,
        triggered_by: str,
        kpi_ids: Optional[List[str]] = None,
        geo_ids: Optional[List[str]] = None,
    ) -> str:
        """
        Create a job record in RUNNING state and return its ID immediately.

        Called by fire-and-forget endpoints to register the job before the
        response is sent, so callers can poll GET /jobs/{job_id} for status.
        The heavy computation is dispatched separately as a background task.
        """
        self.job_id = self._generate_job_id()
        await self._create_job_record(
            job_type=job_type,
            kpi_ids=kpi_ids or [],
            geo_ids=geo_ids or [],
            calculation_date=calculation_date,
            triggered_by=triggered_by,
        )
        return self.job_id

    async def execute_calculation_job(
        self,
        job_type: JobType,
        kpi_ids: Optional[List[str]] = None,
        geo_ids: Optional[List[str]] = None,
        calculation_date: Optional[date] = None,
        triggered_by: str = "API",
        existing_job_id: Optional[str] = None,
        prev_period_days_back: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Main orchestrator for KPI calculation jobs.
        Supports FULL_REFRESH, INCREMENTAL, SINGLE_KPI, SINGLE_GEO.

        Pass existing_job_id when the job record was already created by
        create_pending_job() (fire-and-forget pattern) — skips DB insert.
        """
        calculation_date = calculation_date or date.today()
        self.job_id = existing_job_id or self._generate_job_id()
        start_time = time.time()

        try:
            if not existing_job_id:
                await self._create_job_record(
                    job_type=job_type,
                    kpi_ids=kpi_ids,
                    geo_ids=geo_ids,
                    calculation_date=calculation_date,
                    triggered_by=triggered_by,
                )

            kpi_definitions = await self._get_kpi_definitions(kpi_ids)
            logger.info(f"Job {self.job_id}: {len(kpi_definitions)} KPIs to calculate")

            geographies = await self._get_geographies(geo_ids)
            logger.info(f"Job {self.job_id}: {len(geographies)} geographies")

            project_configs = await self._load_project_configs(kpi_definitions)
            total_calculations = self._calculate_total_scope(
                kpi_definitions, geographies, project_configs
            )
            await self._update_job_scope(total_calculations)

            results = await self._execute_calculations(
                kpi_definitions=kpi_definitions,
                geographies=geographies,
                calculation_date=calculation_date,
                prev_period_days_back=prev_period_days_back,
            )

            duration = int(time.time() - start_time)
            await self._complete_job(
                status=JobStatus.COMPLETED,
                duration=duration,
                completed=results["completed"],
                failed=results["failed"],
            )

            return {
                "job_id": self.job_id,
                "status": "COMPLETED",
                "duration_seconds": duration,
                "calculations_completed": results["completed"],
                "calculations_failed": results["failed"],
                "total_planned": total_calculations,
            }

        except Exception as e:
            logger.error(f"Job {self.job_id} failed: {e}", exc_info=True)
            await self._complete_job(
                status=JobStatus.FAILED,
                duration=int(time.time() - start_time),
                error_message=str(e)[:2000],
            )
            raise CalculationError(f"Calculation job failed: {e}")

    async def execute_batch_by_level(
        self,
        geo_level: str,
        calculation_date: date,
        job_type: JobType,
        triggered_by: str,
        existing_job_id: Optional[str] = None,
        prev_period_days_back: Optional[int] = None,
    ) -> Dict[str, Any]:
        """
        Batch-refresh all KPIs for every active geography at *geo_level*.

        Unlike execute_calculation_job() this method:
        - Fetches only the relevant geo level in a single targeted query.
        - Filters KPI definitions to those applicable to that level upfront.
        - Pre-fetches comparison values across all (KPI, geo) pairs at once.
        - Executes all calculations concurrently (semaphore-bounded) and
          bulk-upserts results in a single statement.

        Pass existing_job_id when the job record was already created by
        create_pending_job() (fire-and-forget pattern) — skips DB insert.

        Used by: POST /batch-refresh/markets, POST /batch-refresh/areas
        """
        self.job_id = existing_job_id or self._generate_job_id()
        start_time = time.time()

        try:
            kpi_definitions = await self._get_kpi_definitions()
            kpi_definitions = [
                k for k in kpi_definitions if geo_level in k["applicable_geo_levels"]
            ]
            all_geos = await self._get_geographies_by_level(geo_level)

            logger.info(
                f"Batch job {self.job_id} [{geo_level}]: "
                f"{len(kpi_definitions)} KPIs x {len(all_geos)} geos"
            )

            if not existing_job_id:
                await self._create_job_record(
                    job_type=job_type,
                    kpi_ids=None,
                    geo_ids=[g["geo_id"] for g in all_geos],
                    calculation_date=calculation_date,
                    triggered_by=triggered_by,
                )
            await self._update_job_scope(len(kpi_definitions) * len(all_geos))

            results = await self._execute_calculations(
                kpi_definitions=kpi_definitions,
                geographies=all_geos,
                calculation_date=calculation_date,
                prev_period_days_back=prev_period_days_back,
            )

            duration = int(time.time() - start_time)
            await self._complete_job(
                status=JobStatus.COMPLETED,
                duration=duration,
                completed=results["completed"],
                failed=results["failed"],
            )

            return {
                "job_id": self.job_id,
                "status": "COMPLETED",
                "duration_seconds": duration,
                "calculations_completed": results["completed"],
                "calculations_failed": results["failed"],
                "total_planned": len(kpi_definitions) * len(all_geos),
            }

        except Exception as e:
            logger.error(f"Batch job {self.job_id} failed: {e}", exc_info=True)
            await self._complete_job(
                status=JobStatus.FAILED,
                duration=int(time.time() - start_time),
                error_message=str(e)[:2000],
            )
            raise CalculationError(f"Batch calculation job failed: {e}")

    # ------------------------------------------------------------------ #
    # Core execution                                                       #
    # ------------------------------------------------------------------ #

    async def _load_project_configs(
        self, kpi_definitions: List[Dict]
    ) -> Dict[str, Dict]:
        """
        For each project referenced by the KPI definitions, load its full
        config from dim_project_config.

        Returns {project_id: {
            "dimension_combos": [...],
            "geo_codes": [...] or None (None = all geos)
        }}
        """
        project_ids: set = set()
        for kpi_def in kpi_definitions:
            pids = kpi_def.get("project_ids") or []
            project_ids.update(pids)

        if not project_ids:
            return {}

        svc = ProjectConfigService(self.db)
        result: Dict[str, Dict] = {}
        for pid in project_ids:
            cfg = await svc.get_project(pid)
            if cfg:
                combos = ProjectConfigService.build_dimension_combos(
                    filter_dimensions=cfg.get("filter_dimensions") or {},
                    cross_filters=cfg.get("cross_filters", False),
                )
                # Empty geo_codes list = all geos (no restriction)
                geo_codes = cfg.get("geo_codes") or []
                result[pid] = {
                    "dimension_combos": combos,
                    "geo_codes": [gc.upper() for gc in geo_codes] if geo_codes else None,
                }
            else:
                result[pid] = {"dimension_combos": [{}], "geo_codes": None}

        return result

    def _get_dimension_combos_for_kpi(
        self,
        kpi_def: Dict,
        project_configs: Dict[str, Dict],
    ) -> List[Dict[str, str]]:
        """
        Determine which dimension combos apply to a single KPI.

        A KPI may belong to multiple projects. We union each project's
        combos (deduplicated by dimension_key) so the KPI gets calculated
        for every relevant dimension.
        """
        pids = kpi_def.get("project_ids") or []
        if not pids:
            return [{}]

        seen_keys: set = set()
        merged: List[Dict[str, str]] = []
        for pid in pids:
            cfg = project_configs.get(pid, {})
            for combo in cfg.get("dimension_combos", [{}]):
                dk = ProjectConfigService.dimension_key_from_params(combo)
                if dk not in seen_keys:
                    seen_keys.add(dk)
                    merged.append(combo)

        return merged or [{}]

    def _get_allowed_geo_codes_for_kpi(
        self,
        kpi_def: Dict,
        project_configs: Dict[str, Dict],
    ) -> Optional[set]:
        """
        Determine which geo_codes a KPI is allowed to run for, based on
        its projects' configurations.

        Returns None if no restriction (all geos allowed).
        Returns a set of UPPER-CASE geo_codes if restricted.

        A KPI belonging to multiple projects gets the UNION of their geo_codes.
        """
        pids = kpi_def.get("project_ids") or []
        if not pids:
            return None  # no project = no restriction

        allowed: set = set()
        any_unrestricted = False
        for pid in pids:
            cfg = project_configs.get(pid, {})
            geo_codes = cfg.get("geo_codes")
            if geo_codes is None:
                # This project has no geo restriction
                any_unrestricted = True
                break
            allowed.update(geo_codes)

        if any_unrestricted:
            return None

        return allowed if allowed else None

    async def _execute_calculations(
        self,
        kpi_definitions: List[Dict],
        geographies: List[Dict],
        calculation_date: date,
        prev_period_days_back: Optional[int] = None,
    ) -> Dict[str, int]:
        """
        Execute all KPI x geography x dimension combinations concurrently.

        Key optimisations:
        1. Single bulk query fetches all previous-period and previous-year
           comparison values upfront (replaces N*M individual DB calls).
        2. asyncio.gather() runs individual calculations concurrently;
           a semaphore keeps DB pool pressure bounded.
        3. Results are accumulated and written via a single bulk upsert.
        """
        kpi_ids = [k["kpi_id"] for k in kpi_definitions]
        geo_ids = [g["geo_id"] for g in geographies]

        days_back = prev_period_days_back if prev_period_days_back is not None else settings.PREV_PERIOD_DAYS_BACK

        # 0. Load per-project configs (dimension combos + geo scoping)
        project_configs = await self._load_project_configs(kpi_definitions)

        # 1. Pre-fetch all comparison values in ONE round-trip
        prev_period_map, prev_year_map = await self._prefetch_comparison_values(
            kpi_ids, geo_ids, calculation_date, days_back
        )

        semaphore = asyncio.Semaphore(settings.MAX_CONCURRENT_KPI_QUERIES)
        failed = 0

        async def _run_one(
            kpi_def: Dict, geo: Dict, dim_params: Dict[str, str]
        ) -> Optional[Dict]:
            async with semaphore:
                async with AsyncSessionLocal() as session:
                    return await self._calculate_single_kpi(
                        db=session,
                        kpi_def=kpi_def,
                        geo=geo,
                        calculation_date=calculation_date,
                        prev_period_map=prev_period_map,
                        prev_year_map=prev_year_map,
                        dim_params=dim_params,
                    )

        # 2. Build task list (KPI × geo × dimension_combo)
        #    Geos are scoped per KPI's project config; empty geo_codes = all geos.
        tasks = []
        task_keys: set = set()
        for kpi_def in kpi_definitions:
            combos = self._get_dimension_combos_for_kpi(kpi_def, project_configs)
            allowed_geos = self._get_allowed_geo_codes_for_kpi(kpi_def, project_configs)
            for geo in geographies:
                if geo["geo_level"] not in kpi_def["applicable_geo_levels"]:
                    continue
                if allowed_geos is not None and geo.get("geo_code", "").upper() not in allowed_geos:
                    continue
                for dim_params in combos:
                    task_key = (
                        kpi_def["kpi_id"],
                        geo["geo_id"],
                        ProjectConfigService.dimension_key_from_params(dim_params),
                    )
                    if task_key in task_keys:
                        logger.warning(
                            f"DUPLICATE TASK at build time: {task_key} — "
                            f"kpi_def project_ids={kpi_def.get('project_ids')} "
                            f"combos={combos} geo={geo['geo_code']}"
                        )
                    task_keys.add(task_key)
                    tasks.append(_run_one(kpi_def, geo, dim_params))

        logger.info(
            f"Job {self.job_id}: {len(tasks)} total calculation tasks "
            f"({len(kpi_definitions)} KPIs x {len(geographies)} geos x dimensions)"
        )

        # 3. Run concurrently in chunks — gather + upsert per chunk so memory
        #    stays bounded and duplicates within a chunk can't cause conflicts.
        #    A dict keyed by (kpi_id, geo_id, dimension_key) deduplicates across
        #    chunks in case the same combo appears more than once (e.g. a KPI
        #    belonging to multiple projects with overlapping geo scopes).
        CHUNK_SIZE = 200
        seen: Dict[tuple, Dict] = {}
        for chunk_start in range(0, len(tasks), CHUNK_SIZE):
            chunk = tasks[chunk_start: chunk_start + CHUNK_SIZE]
            raw_results = await asyncio.gather(*chunk, return_exceptions=True)
            chunk_rows: Dict[tuple, Dict] = {}
            for r in raw_results:
                if isinstance(r, Exception):
                    logger.error(f"Calculation task failed: {r}")
                    failed += 1
                elif r is not None:
                    key = (r["kpi_id"], r["geo_id"], r["dimension_key"])
                    if key in chunk_rows:
                        logger.warning(
                            f"DUPLICATE within same chunk: {key} — "
                            f"two tasks produced the same (kpi_id, geo_id, dimension_key). "
                            f"Check task-building loop for duplicate geo or dim combo entries."
                        )
                    if key in seen:
                        logger.warning(
                            f"DUPLICATE across chunks: {key} — "
                            f"already upserted in a previous chunk."
                        )
                    chunk_rows[key] = r
            # Upsert this chunk immediately — avoids building a huge list in RAM
            if chunk_rows:
                await self._bulk_upsert_kpi_values(list(chunk_rows.values()))
            seen.update(chunk_rows)

        completed = len(seen)

        # 4. Progress record update
        await self._update_job_progress(completed, failed)

        return {"completed": completed, "failed": failed}

    async def _calculate_single_kpi(
        self,
        db: AsyncSession,
        kpi_def: Dict,
        geo: Dict,
        calculation_date: date,
        prev_period_map: Dict[Tuple, Optional[float]],
        prev_year_map: Dict[Tuple, Optional[float]],
        dim_params: Optional[Dict[str, str]] = None,
    ) -> Dict:
        """
        Calculate a single KPI for one geography and one dimension combo.
        Returns a dict of upsert-ready column values (no DB writes here;
        all writes happen later via _bulk_upsert_kpi_values).
        """
        dim_params = dim_params or {}
        dimension_key = ProjectConfigService.dimension_key_from_params(dim_params)

        calc_start = time.time()
        period_start, period_end = self._get_period_range(calculation_date)

        # Build template params: geography + date + dimension params
        template_params = {
            "start_date": period_start,
            "end_date": period_end,
            # Surrogate keys (dim_geography.geo_id values)
            "geo_id":    geo["geo_id"],
            "region_id": geo.get("region_id"),
            "area_id":   geo.get("area_id"),
            # Natural / display keys (geo_code, always UPPER-CASE)
            # Use these in source-data filters: a.m_market = :geo_code
            "geo_code":    geo.get("geo_code"),
            "region_code": geo.get("region_code"),  # parent region's geo_code
            "area_code":   geo.get("area_code"),    # parent area's geo_code
            # Level discriminator
            "geo_level": geo["geo_level"],
        }
        # Inject dimension filter params — the SQL template uses these as
        # AND (:scope_of_work = 'ALL' OR scope_of_work = :scope_of_work)
        for dim_name, dim_value in dim_params.items():
            template_params[dim_name] = dim_value
        # For dimensions NOT in this combo, pass 'ALL' so the
        # (:dim = 'ALL' OR ...) pattern skips the filter
        if kpi_def.get("project_ids"):
            # We don't know all possible dimension names here, but the
            # template only references dimensions it cares about. Unreferenced
            # placeholders are harmless (they stay as :name literals which
            # would cause SQL errors). So we rely on templates only using
            # dimensions from their project's config.
            pass

        sql_query = self._prepare_sql_query(
            template=kpi_def["sql_query_template"],
            params=template_params,
        )

        logger.debug(
            "Executing KPI query | kpi_id=%s geo_id=%s dim_key=%s\n%s",
            kpi_def["kpi_id"], geo["geo_id"], dimension_key, sql_query,
        )

        result = (await db.execute(text(sql_query))).fetchone()

        if not result:
            raise QueryExecutionError(
                f"Query returned no results for KPI {kpi_def['kpi_id']} "
                f"/ geo {geo['geo_id']} / dim {dimension_key}"
            )

        kpi_value = float(result.kpi_value) if result.kpi_value is not None else 0.0
        record_count = int(result.record_count) if result.record_count is not None else 0

        formatted_value = self._format_kpi_value(
            value=kpi_value,
            display_format=kpi_def["display_format"],
            decimal_places=kpi_def["decimal_places"],
            unit_symbol=kpi_def.get("unit_symbol"),
        )

        key = (kpi_def["kpi_id"], geo["geo_id"], dimension_key)
        previous_period = prev_period_map.get(key) if settings.ENABLE_PREV_PERIOD_COMPARISON else None
        previous_year   = prev_year_map.get(key)   if settings.ENABLE_PREV_YEAR_COMPARISON   else None

        pop_change, pop_change_pct = self._calculate_change(kpi_value, previous_period)
        yoy_change, yoy_change_pct = self._calculate_change(kpi_value, previous_year)
        date_parts = get_date_parts(calculation_date)
        calc_duration_ms = int((time.time() - calc_start) * 1000)

        logger.debug(
            f"KPI {kpi_def['kpi_id']} / {geo['geo_id']} / {dimension_key}: "
            f"value={kpi_value}, records={record_count}, duration={calc_duration_ms}ms"
        )

        return {
            "kpi_id": kpi_def["kpi_id"],
            "geo_id": geo["geo_id"],
            "geo_level": geo["geo_level"],
            "dimension_key": dimension_key,
            "calculation_date": calculation_date,
            "period_start_date": period_start,
            "period_end_date": period_end,
            "year": date_parts["year"],
            "quarter": date_parts["quarter"],
            "month": date_parts["month"],
            "week": date_parts["week"],
            "kpi_value": kpi_value,
            "kpi_value_formatted": formatted_value,
            "record_count": record_count,
            "calculation_duration_ms": calc_duration_ms,
            "previous_period_value": previous_period,
            "previous_year_value": previous_year,
            "period_on_period_change": pop_change,
            "period_on_period_change_pct": pop_change_pct,
            "year_on_year_change": yoy_change,
            "year_on_year_change_pct": yoy_change_pct,
            "calculation_job_id": self.job_id,
            "calculated_at": datetime.now(),
        }

    # ------------------------------------------------------------------ #
    # Bulk helpers                                                         #
    # ------------------------------------------------------------------ #

    async def _prefetch_comparison_values(
        self,
        kpi_ids: List[str],
        geo_ids: List[str],
        calc_date: date,
        prev_period_days_back: int,
    ) -> Tuple[Dict, Dict]:
        """
        Fetch comparison values for all (kpi_id, geo_id, dimension_key) triples.

        Previous period:
          Queries kpi_values_historical for the most recent calculation on or
          before (calc_date - prev_period_days_back). Using DISTINCT ON ensures
          exactly one row per (kpi_id, geo_id, dimension_key) — the closest
          available data point up to that target date.

        Previous year:
          Queries kpi_values_historical for the closest record on or before
          (calc_date - 1 year), using the same DISTINCT ON pattern.

        Controlled by settings:
          ENABLE_PREV_PERIOD_COMPARISON
          ENABLE_PREV_YEAR_COMPARISON
        """
        want_period = settings.ENABLE_PREV_PERIOD_COMPARISON
        want_year   = settings.ENABLE_PREV_YEAR_COMPARISON

        if not want_period and not want_year:
            return {}, {}

        hist_table = settings.TABLES["kpi_values_historical"]
        prev_period_map: Dict[Tuple, float] = {}
        prev_year_map: Dict[Tuple, float] = {}

        if want_period:
            target_date = calc_date - timedelta(days=prev_period_days_back)
            q = text(f"""
                SELECT DISTINCT ON (kpi_id, geo_id, dimension_key)
                    kpi_id, geo_id, dimension_key, kpi_value
                FROM {hist_table}
                WHERE kpi_id = ANY(:kpi_ids)
                  AND geo_id = ANY(:geo_ids)
                  AND calculation_date <= :target_date
                ORDER BY kpi_id, geo_id, dimension_key, calculation_date DESC
            """)
            rows = (await self.db.execute(
                q, {"kpi_ids": kpi_ids, "geo_ids": geo_ids, "target_date": target_date}
            )).fetchall()
            for row in rows:
                if row.kpi_value is not None:
                    prev_period_map[(row.kpi_id, row.geo_id, row.dimension_key)] = float(row.kpi_value)
            logger.debug(
                f"Prev-period prefetch ({prev_period_days_back}d back, "
                f"target={target_date}): {len(prev_period_map)} values found"
            )

        if want_year:
            try:
                prev_year_date = calc_date.replace(year=calc_date.year - 1)
            except ValueError:
                prev_year_date = calc_date.replace(year=calc_date.year - 1, day=28)

            q = text(f"""
                SELECT DISTINCT ON (kpi_id, geo_id, dimension_key)
                    kpi_id, geo_id, dimension_key, kpi_value
                FROM {hist_table}
                WHERE kpi_id = ANY(:kpi_ids)
                  AND geo_id = ANY(:geo_ids)
                  AND calculation_date <= :prev_year_date
                ORDER BY kpi_id, geo_id, dimension_key, calculation_date DESC
            """)
            rows = (await self.db.execute(
                q, {"kpi_ids": kpi_ids, "geo_ids": geo_ids, "prev_year_date": prev_year_date}
            )).fetchall()
            for row in rows:
                if row.kpi_value is not None:
                    prev_year_map[(row.kpi_id, row.geo_id, row.dimension_key)] = float(row.kpi_value)

        return prev_period_map, prev_year_map

    async def _archive_before_upsert(self, rows: List[Dict]) -> None:
        """
        Copy existing live rows for the (kpi_id, geo_id, dimension_key) triples
        about to be overwritten.

        We snapshot them to historical before the upsert replaces them,
        preserving the full calculation history regardless of how often
        refreshes run.
        """
        kpi_ids = list({r["kpi_id"] for r in rows})
        geo_ids = list({r["geo_id"] for r in rows})
        dim_keys = list({r.get("dimension_key", "ALL") for r in rows})

        live_table = settings.TABLES["kpi_values_live"]
        hist_table = settings.TABLES["kpi_values_historical"]

        q = text(f"""
            INSERT INTO {hist_table} (
                kpi_id, geo_id, geo_level, dimension_key,
                calculation_date, period_start_date, period_end_date,
                year, quarter, month, week,
                kpi_value, kpi_value_formatted,
                record_count, data_quality_score,
                previous_period_value, previous_year_value,
                period_on_period_change_pct, year_on_year_change_pct,
                calculation_job_id, calculated_at, archived_at
            )
            SELECT
                kpi_id, geo_id, geo_level, dimension_key,
                calculation_date, period_start_date, period_end_date,
                year, quarter, month, week,
                kpi_value, kpi_value_formatted,
                record_count, data_quality_score,
                previous_period_value, previous_year_value,
                period_on_period_change_pct, year_on_year_change_pct,
                calculation_job_id, calculated_at, CURRENT_TIMESTAMP
            FROM {live_table}
            WHERE kpi_id = ANY(:kpi_ids)
              AND geo_id = ANY(:geo_ids)
              AND dimension_key = ANY(:dim_keys)
            ON CONFLICT DO NOTHING
        """)
        await self.db.execute(q, {
            "kpi_ids": kpi_ids, "geo_ids": geo_ids, "dim_keys": dim_keys,
        })
        logger.debug(
            f"Pre-upsert archival: snapshotted {len(kpi_ids)} KPIs x "
            f"{len(geo_ids)} geos x {len(dim_keys)} dims"
        )

    async def _bulk_upsert_kpi_values(self, rows: List[Dict]) -> None:
        """
        Insert/update all computed KPI rows, batched to stay within asyncpg's
        32,767 bind-parameter limit (23 columns × ~1,424 rows per batch).

        Existing live rows are archived to historical before each batch so no
        previous calculation is lost.
        """
        if not rows:
            return

        table = settings.TABLES["kpi_values_live"]

        columns = [
            "kpi_id", "geo_id", "geo_level", "dimension_key",
            "calculation_date", "period_start_date", "period_end_date",
            "year", "quarter", "month", "week",
            "kpi_value", "kpi_value_formatted",
            "record_count", "calculation_duration_ms",
            "previous_period_value", "previous_year_value",
            "period_on_period_change", "period_on_period_change_pct",
            "year_on_year_change", "year_on_year_change_pct",
            "calculation_job_id", "calculated_at",
        ]
        conflict_keys = {"kpi_id", "geo_id", "dimension_key"}
        update_set = ",\n                    ".join(
            f"{col} = EXCLUDED.{col}"
            for col in columns
            if col not in conflict_keys
        )

        # asyncpg hard limit: 32,767 bind params per statement
        max_rows_per_batch = 32767 // len(columns)

        for batch_start in range(0, len(rows), max_rows_per_batch):
            batch = rows[batch_start: batch_start + max_rows_per_batch]

            # Archive existing live rows before overwriting
            await self._archive_before_upsert(batch)

            value_placeholders = []
            params: Dict[str, Any] = {}
            for i, row in enumerate(batch):
                placeholders = ", ".join(f":{col}_{i}" for col in columns)
                value_placeholders.append(f"({placeholders})")
                for col in columns:
                    params[f"{col}_{i}"] = row.get(col)

            stmt = text(f"""
                INSERT INTO {table} ({', '.join(columns)})
                VALUES {', '.join(value_placeholders)}
                ON CONFLICT (kpi_id, geo_id, dimension_key)
                DO UPDATE SET
                    {update_set}
            """)

            await self.db.execute(stmt, params)

        await self.db.commit()

    # ------------------------------------------------------------------ #
    # Data-fetching helpers                                               #
    # ------------------------------------------------------------------ #

    async def _get_kpi_definitions(
        self, kpi_ids: Optional[List[str]] = None
    ) -> List[Dict]:
        """Fetch active KPI definitions from master table."""
        table = settings.TABLES["kpi_master"]
        select = f"""
            SELECT
                kpi_id, kpi_code, kpi_name, kpi_category,
                applicable_geo_levels, sql_query_template,
                aggregation_method, aggregation_column,
                display_format, decimal_places, unit_symbol,
                source_tables, project_ids
            FROM {table}
        """
        if kpi_ids:
            q = text(select + "WHERE kpi_id = ANY(:kpi_ids) AND is_active = TRUE ORDER BY priority ASC")
            results = (await self.db.execute(q, {"kpi_ids": kpi_ids})).fetchall()
        else:
            q = text(select + "WHERE is_active = TRUE ORDER BY priority ASC")
            results = (await self.db.execute(q)).fetchall()

        return [dict(r._mapping) for r in results]

    async def _get_geographies(
        self, geo_ids: Optional[List[str]] = None
    ) -> List[Dict]:
        """
        Fetch active geographies, ordered by hierarchy level.

        Self-joins resolve region_code and area_code (the geo_code of the
        parent region/area) so KPI templates can filter source data with
        natural keys: a.region = :region_code, a.m_market = :geo_code, etc.
        """
        t = settings.TABLES["dim_geography"]
        order_clause = """
            ORDER BY
                CASE g.geo_level
                    WHEN 'OVERALL' THEN 1
                    WHEN 'REGION'  THEN 2
                    WHEN 'AREA'    THEN 3
                    WHEN 'MARKET'  THEN 4
                END,
                g.display_order
        """
        select = f"""
            SELECT
                g.geo_id, g.geo_code, g.geo_name, g.geo_level,
                g.parent_geo_id, g.region_id, g.area_id,
                r.geo_code AS region_code,
                a.geo_code AS area_code
            FROM {t} g
            LEFT JOIN {t} r ON g.region_id = r.geo_id
            LEFT JOIN {t} a ON g.area_id   = a.geo_id
        """
        if geo_ids:
            q = text(select + "WHERE g.geo_id = ANY(:geo_ids) AND g.is_active = TRUE " + order_clause)
            results = (await self.db.execute(q, {"geo_ids": geo_ids})).fetchall()
        else:
            q = text(select + "WHERE g.is_active = TRUE " + order_clause)
            results = (await self.db.execute(q)).fetchall()

        return [dict(r._mapping) for r in results]

    async def _get_geographies_by_level(self, geo_level: str) -> List[Dict]:
        """
        Fetch all active geographies at a specific level.
        Includes region_code / area_code from parent self-joins.
        """
        t = settings.TABLES["dim_geography"]
        q = text(f"""
            SELECT
                g.geo_id, g.geo_code, g.geo_name, g.geo_level,
                g.parent_geo_id, g.region_id, g.area_id,
                r.geo_code AS region_code,
                a.geo_code AS area_code
            FROM {t} g
            LEFT JOIN {t} r ON g.region_id = r.geo_id
            LEFT JOIN {t} a ON g.area_id   = a.geo_id
            WHERE g.geo_level = :geo_level
              AND g.is_active = TRUE
            ORDER BY g.display_order
        """)
        results = (await self.db.execute(q, {"geo_level": geo_level})).fetchall()
        return [dict(r._mapping) for r in results]

    # ------------------------------------------------------------------ #
    # Job record management                                               #
    # ------------------------------------------------------------------ #

    async def _create_job_record(
        self,
        job_type: JobType,
        kpi_ids: Optional[List[str]],
        geo_ids: Optional[List[str]],
        calculation_date: date,
        triggered_by: str,
    ) -> None:
        table = settings.TABLES["calculation_jobs"]
        q = text(f"""
            INSERT INTO {table} (
                job_id, job_type, kpi_ids, geo_ids, calculation_date,
                status, started_at, triggered_by, created_at
            ) VALUES (
                :job_id, :job_type, :kpi_ids, :geo_ids, :calculation_date,
                :status, :started_at, :triggered_by, :created_at
            )
        """)
        await self.db.execute(q, {
            "job_id": self.job_id,
            "job_type": job_type.value,
            "kpi_ids": kpi_ids or [],
            "geo_ids": geo_ids or [],
            "calculation_date": calculation_date,
            "status": JobStatus.RUNNING.value,
            "started_at": datetime.now(),
            "triggered_by": triggered_by,
            "created_at": datetime.now(),
        })
        await self.db.commit()

    async def _update_job_scope(self, total_calculations: int) -> None:
        table = settings.TABLES["calculation_jobs"]
        q = text(f"""
            UPDATE {table}
            SET total_calculations_planned = :total
            WHERE job_id = :job_id
        """)
        await self.db.execute(q, {"total": total_calculations, "job_id": self.job_id})
        await self.db.commit()

    async def _update_job_progress(self, completed: int, failed: int) -> None:
        table = settings.TABLES["calculation_jobs"]
        q = text(f"""
            UPDATE {table}
            SET calculations_completed = :completed,
                calculations_failed = :failed,
                updated_at = :updated_at
            WHERE job_id = :job_id
        """)
        await self.db.execute(q, {
            "completed": completed,
            "failed": failed,
            "updated_at": datetime.now(),
            "job_id": self.job_id,
        })
        await self.db.commit()

    async def _complete_job(
        self,
        status: JobStatus,
        duration: int,
        completed: int = 0,
        failed: int = 0,
        error_message: Optional[str] = None,
    ) -> None:
        table = settings.TABLES["calculation_jobs"]
        q = text(f"""
            UPDATE {table}
            SET status = :status,
                completed_at = :completed_at,
                duration_seconds = :duration,
                calculations_completed = :completed,
                calculations_failed = :failed,
                error_message = :error_message,
                updated_at = :updated_at
            WHERE job_id = :job_id
        """)
        await self.db.execute(q, {
            "status": status.value,
            "completed_at": datetime.now(),
            "duration": duration,
            "completed": completed,
            "failed": failed,
            "error_message": error_message,
            "updated_at": datetime.now(),
            "job_id": self.job_id,
        })
        await self.db.commit()

    # ------------------------------------------------------------------ #
    # Pure-logic helpers (no I/O)                                         #
    # ------------------------------------------------------------------ #

    def _calculate_total_scope(
        self,
        kpi_definitions: List[Dict],
        geographies: List[Dict],
        project_configs: Optional[Dict[str, Dict]] = None,
    ) -> int:
        configs = project_configs or {}
        total = 0
        for kpi_def in kpi_definitions:
            combos = self._get_dimension_combos_for_kpi(kpi_def, configs)
            allowed_geos = self._get_allowed_geo_codes_for_kpi(kpi_def, configs)
            for geo in geographies:
                if geo["geo_level"] not in kpi_def["applicable_geo_levels"]:
                    continue
                if allowed_geos is not None and geo.get("geo_code", "").upper() not in allowed_geos:
                    continue
                total += len(combos)
        return total

    def _get_period_range(self, calculation_date: date) -> Tuple[date, date]:
        return calculation_date, calculation_date

    def _generate_job_id(self) -> str:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        unique_id = str(uuid.uuid4())[:8]
        return f"JOB_{timestamp}_{unique_id}"

    def _prepare_sql_query(self, template: str, params: Dict[str, Any]) -> str:
        """Replace :param_name placeholders with escaped literal values.

        Sorts keys longest-first so that e.g. :region_code is replaced before
        :region, preventing partial-match corruption.
        """
        query = template
        for key in sorted(params.keys(), key=len, reverse=True):
            value = params[key]
            placeholder = f":{key}"
            if value is None:
                replacement = "NULL"
            elif isinstance(value, str):
                replacement = f"'{value.replace(chr(39), chr(39) * 2)}'"
            elif isinstance(value, (date, datetime)):
                replacement = f"'{value}'"
            elif isinstance(value, bool):
                replacement = "TRUE" if value else "FALSE"
            else:
                replacement = str(value)
            query = query.replace(placeholder, replacement)
        return query

    def _format_kpi_value(
        self,
        value: float,
        display_format: str,
        decimal_places: int,
        unit_symbol: Optional[str],
    ) -> str:
        if display_format == "CURRENCY":
            symbol = unit_symbol or "$"
            return f"{symbol}{value:,.{decimal_places}f}"
        elif display_format == "PERCENTAGE":
            return f"{value:.{decimal_places}f}%"
        elif display_format == "DAYS":
            return f"{value:.{decimal_places}f} days"
        else:
            formatted = f"{value:,.{decimal_places}f}"
            if unit_symbol:
                formatted += f" {unit_symbol}"
            return formatted

    def _calculate_change(
        self, current: float, previous: Optional[float]
    ) -> Tuple[Optional[float], Optional[float]]:
        if previous is None or previous == 0:
            return None, None
        absolute_change = current - previous
        percentage_change = (absolute_change / abs(previous)) * 100
        return absolute_change, percentage_change
