from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class WorkflowStepInsight(BaseModel):
    """A workflow step where the site was actually processed."""

    step_id: int
    step_name: str
    step_description: Optional[str] = None
    phase_name: Optional[str] = None
    status: str  # "completed" | "failed"
    is_main_path: bool = True  # True = main workflow, False = parallel branch
    error_message: Optional[str] = None


class WorkflowInsight(BaseModel):
    """Insights for a single workflow/pipeline — only steps the site touched."""

    workflow_name: str
    total_steps: int = 0
    completed_steps: int = 0
    failed_steps: int = 0
    completion_pct: float = 0.0
    current_position: Optional[WorkflowStepInsight] = None  # last step the site reached
    recent_completed: List[WorkflowStepInsight] = []  # last 3-4 passed steps
    failed_step_details: List[WorkflowStepInsight] = []  # steps where site failed


class PMCommentEntry(BaseModel):
    """A single PM comment column value for a site."""

    column_name: str
    column_label: str
    raw_text: Optional[str] = None
    is_empty: bool = True


class SiteInsightsResponse(BaseModel):
    """Top-level response for the site insights endpoint."""

    smp_id: str
    project_id: str
    workflows: List[WorkflowInsight] = []
    pm_comments: List[PMCommentEntry] = []
    narrative: str = ""
    structured_summary: Dict[str, Any] = {}
    generated_at: datetime = Field(default_factory=datetime.utcnow)
