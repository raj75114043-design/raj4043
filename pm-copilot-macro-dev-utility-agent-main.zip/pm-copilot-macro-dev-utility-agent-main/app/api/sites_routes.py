import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import AsyncSessionLocal, get_db
from app.core.security import verify_api_key
from app.models.kpi_models import (
    SiteListResponse,
    SiteRefreshJobResponse,
    SiteResponse,
    SiteSummaryResponse,
    WorkflowPipelineInfo,
)
from app.services.sites_service import SitesService
from app.services.workflow_client import WorkflowClient
from app.services.workflow_sites_service import WorkflowSitesService

router = APIRouter(prefix="/api/v1/sites", tags=["Sites"])
logger = logging.getLogger(__name__)


# ------------------------------------------------------------------ #
# Background refresh worker                                            #
# ------------------------------------------------------------------ #

async def _run_site_refresh_background(job_id: str, project_id: str) -> None:
    """Runs the site refresh in the background with its own DB session.

    Smart dispatch: if the project has a workflow_pipeline_name configured,
    delegates to WorkflowSitesService; otherwise uses the standard SitesService.
    """
    async with AsyncSessionLocal() as db:
        try:
            config = await SitesService(db)._get_project_config(project_id)
            if config and config.get("workflow_pipeline_name"):
                svc = WorkflowSitesService(db)
                result = await svc.refresh_project_sites_from_workflow(project_id)
                logger.info(
                    "Workflow site refresh job %s completed for '%s': %d rows "
                    "(pipeline=%s, steps=%d/%d)",
                    job_id, project_id, result["rows_inserted"],
                    result["pipeline_name"],
                    result["steps_verified"], result["steps_total"],
                )
            else:
                svc = SitesService(db)
                result = await svc.refresh_project_sites(project_id)
                logger.info(
                    "Site refresh job %s completed for '%s': %d rows",
                    job_id, project_id, result["rows_inserted"],
                )
        except Exception as exc:
            logger.error(
                "Site refresh job %s failed for '%s': %s",
                job_id, project_id, exc, exc_info=True,
            )


# ------------------------------------------------------------------ #
# Endpoints                                                            #
# ------------------------------------------------------------------ #

@router.post(
    "/{project_id}/refresh",
    response_model=SiteRefreshJobResponse,
    status_code=202,
)
async def trigger_site_refresh(
    project_id: str,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Trigger a site data refresh for a project.**

    Runs asynchronously. Returns immediately with a job ID.
    The refresh:
    1. Executes the project's `site_source_query`
    2. Evaluates `site_computed` expressions (phase, progress_pct)
    3. Replaces all existing site rows for this project in `dim_sites`

    Requires `site_source_query` to be configured on the project first.
    """
    svc = SitesService(db)
    config = await svc._get_project_config(project_id)
    if not config:
        raise HTTPException(status_code=404, detail=f"Project '{project_id}' not found.")
    if not config.get("site_source_query"):
        raise HTTPException(
            status_code=400,
            detail=(
                f"Project '{project_id}' has no site_source_query configured. "
                "A site source query is required for both standard and workflow-based refreshes. "
                "Set it via POST /api/v1/project-config before refreshing."
            ),
        )

    job_id = SitesService.make_job_id()
    background_tasks.add_task(_run_site_refresh_background, job_id, project_id)

    return SiteRefreshJobResponse(
        job_id=job_id,
        project_id=project_id,
        status="RUNNING",
        message=f"Site refresh started for project '{project_id}'. Poll /api/v1/sites/{project_id}/summary to confirm completion.",
        started_at=datetime.utcnow(),
    )


# ------------------------------------------------------------------ #
# Workflow endpoints                                                    #
# ------------------------------------------------------------------ #

@router.get("/workflows/pipelines", response_model=List[str])
async def list_workflow_pipelines(
    _: str = Depends(verify_api_key),
):
    """List available workflow pipeline names from the external workflow API."""
    client = WorkflowClient()
    return await client.list_pipelines()


@router.get(
    "/workflows/pipelines/{pipeline_name}/steps",
    response_model=WorkflowPipelineInfo,
)
async def get_workflow_pipeline_steps(
    pipeline_name: str,
    _: str = Depends(verify_api_key),
):
    """Return enabled steps for a specific pipeline (for UI step selection)."""
    client = WorkflowClient()
    data = await client.get_pipeline_steps(pipeline_name)
    enabled = client.filter_enabled_steps(data)
    return WorkflowPipelineInfo(
        pipeline_name=pipeline_name,
        enabled_steps=enabled,
    )


# ------------------------------------------------------------------ #
# Site endpoints                                                       #
# ------------------------------------------------------------------ #

@router.get("/{project_id}/summary", response_model=SiteSummaryResponse)
async def get_site_summary(
    project_id: str,
    region_code: Optional[str] = Query(None, description="Single or comma-separated: US_WEST,US_EAST"),
    area_code: Optional[str] = Query(None, description="Single or comma-separated"),
    market_code: Optional[str] = Query(None, description="Single or comma-separated"),
    phase: Optional[str] = Query(None, description="Single or comma-separated"),
    status: Optional[str] = Query(None, description="Single or comma-separated"),
    progress_bracket: Optional[str] = Query(None, description="Filter by progress bracket: '100%', '80-99%', '60-79%', '40-59%', '20-39%', '1-19%', '0%', 'N/A'"),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Site summary stats for a project.**

    Returns total site count, average progress, and distribution
    by phase and status. All filters support comma-separated multi-values.

    This is a fast aggregation query (single pass, no pagination).
    Use this to power summary cards, pie charts, and progress bars.
    """
    svc = SitesService(db)
    return await svc.get_summary(
        project_id,
        region_code=region_code,
        area_code=area_code,
        market_code=market_code,
        phase=phase,
        status=status,
        progress_bracket=progress_bracket,
    )


@router.get("/{project_id}/filter-options")
async def get_filter_options(
    project_id: str,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Distinct filter values for a project's sites.**

    Returns distinct values for geo_code, region_code, phase, status,
    and any project-specific attributes marked `filterable: true` in
    `site_columns` config.

    Use this to populate filter dropdowns in the UI.
    Changes only when the daily refresh runs.
    """
    svc = SitesService(db)
    config = await svc._get_project_config(project_id)
    if not config:
        raise HTTPException(status_code=404, detail=f"Project '{project_id}' not found.")
    return await svc.get_filter_options(project_id)


@router.get("/{project_id}", response_model=SiteListResponse)
async def list_sites(
    project_id: str,
    region_code: Optional[str] = Query(None, description="Single or comma-separated: US_WEST,US_EAST"),
    area_code: Optional[str] = Query(None, description="Single or comma-separated"),
    market_code: Optional[str] = Query(None, description="Single or comma-separated"),
    phase: Optional[str] = Query(None, description="Single or comma-separated"),
    status: Optional[str] = Query(None, description="Single or comma-separated"),
    progress_bracket: Optional[str] = Query(None, description="Filter by progress bracket: '100%', '80-99%', '60-79%', '40-59%', '20-39%', '1-19%', '0%', 'N/A'"),
    search: Optional[str] = Query(None, description="Case-insensitive keyword search across site_id, region/area/market codes, phase, status, and all attribute values"),
    page: int = Query(1, ge=1),
    page_size: int = Query(500, ge=1, le=2000, description="Rows per page, max 2000"),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Paginated, filtered site list for a project.**

    All filter params are optional and combinable.
    Response includes `total` and `pages` so the UI can render pagination controls.

    Default page size is 500. Max is 2000.
    """
    svc = SitesService(db)
    return await svc.list_sites(
        project_id=project_id,
        region_code=region_code,
        area_code=area_code,
        market_code=market_code,
        phase=phase,
        status=status,
        progress_bracket=progress_bracket,
        search=search,
        page=page,
        page_size=page_size,
    )


@router.get("/{project_id}/sites/{site_id}", response_model=SiteResponse)
async def get_site(
    project_id: str,
    site_id: str,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """**Get a single site by ID.**"""
    svc = SitesService(db)
    site = await svc.get_site(project_id, site_id)
    if not site:
        raise HTTPException(
            status_code=404,
            detail=f"Site '{site_id}' not found in project '{project_id}'.",
        )
    return site
