import logging

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.database import get_db
from app.core.exceptions import SiteInsightsError, WorkflowAPIError
from app.core.security import verify_api_key
from app.models.insights_models import SiteInsightsResponse
from app.services.site_insights_service import SiteInsightsService

router = APIRouter(prefix="/api/v1/insights", tags=["Site Insights"])
logger = logging.getLogger(__name__)


@router.get(
    "/site/{project_id}/{smp_id}",
    response_model=SiteInsightsResponse,
    summary="Get deep insights for a specific site",
    description=(
        "Returns an LLM-generated narrative insight along with structured "
        "workflow analysis, PM comments, and dependency graph data for a "
        "single site identified by smp_id."
    ),
)
async def get_site_insights(
    project_id: str,
    smp_id: str,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    try:
        svc = SiteInsightsService(db)
        return await svc.get_insights(project_id, smp_id)
    except SiteInsightsError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except WorkflowAPIError as exc:
        raise HTTPException(
            status_code=502,
            detail=f"Workflow API error: {exc}",
        )
