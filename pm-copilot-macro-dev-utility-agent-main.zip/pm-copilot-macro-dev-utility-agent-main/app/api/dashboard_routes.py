from datetime import date, datetime
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.core.database import get_db
from app.core.security import verify_api_key
from app.models.kpi_models import (
    AggregationMethod, AggregatedKPIResponse, DisplayFormat, DashboardQueryParams,
    DashboardResponse, GeoLevel, KPICategory, KPITag, ProjectAggregationResponse,
)
from app.services.dashboard_service import DashboardService


def _substitute_params(template: str, params: Dict[str, Any]) -> str:
    """Replace :param_name placeholders with escaped literal values."""
    query = template
    for key, value in params.items():
        placeholder = f":{key}"
        if value is None:
            replacement = "NULL"
        elif isinstance(value, str):
            replacement = f"'{value.replace(chr(39), chr(39) * 2)}'"
        elif isinstance(value, (date, datetime)):
            replacement = f"'{value}'"
        elif isinstance(value, bool):
            replacement = "TRUE" if value else "FALSE"
        else:
            replacement = str(value)
        query = query.replace(placeholder, replacement)
    return query

router = APIRouter(prefix="/api/v1/dashboard", tags=["Dashboard"])


@router.get("/kpis", response_model=DashboardResponse)
async def get_dashboard_kpis(
    user_id: Optional[str] = Query(None, description="User ID for persona-based filtering"),
    project_ids: Optional[str] = Query(None, description="Comma-separated project IDs"),
    level_ids: Optional[str] = Query(None, description="Comma-separated level IDs (HOME, PHASE, SITE)"),
    function_ids: Optional[str] = Query(None, description="Comma-separated function IDs"),
    geo_codes: Optional[str] = Query(None, description="Comma-separated geography codes, e.g. 'US_WEST,APAC'"),
    geo_level: Optional[str] = Query(None, description="Geography level: OVERALL | REGION | AREA | MARKET"),
    kpi_ids: Optional[str] = Query(None, description="Comma-separated KPI IDs"),
    kpi_category: Optional[str] = Query(None, description="Filter by KPI category (any string, e.g. HEALTH, PERFORMANCE, Site_Count)"),
    dimension_key: str = Query("ALL", description="Dimension filter combo, e.g. 'scope_of_work:NEW_BUILD' or 'ALL'"),
    date_from: Optional[date] = Query(None, description="Start date (YYYY-MM-DD)"),
    date_to: Optional[date] = Query(None, description="End date (YYYY-MM-DD)"),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Get Dashboard KPIs**

    Fetch pre-calculated KPI data filtered by user persona (project, team, function, geography).

    **Authentication:** Requires valid API key

    **Query Parameters:**
    - `user_id`: Optional user ID for profile-based defaults
    - `project_ids`: Filter by projects (e.g., "PROJ001,PROJ002")
    - `level_ids`: Filter by levels (e.g., "HOME,PHASE,SITE")
    - `function_ids`: Filter by functions
    - `geo_ids`: Filter by geographies (e.g., "GEO_R001,GEO_M001")
    - `kpi_ids`: Specific KPIs to retrieve
    - `dimension_key`: Filter by dimension combo (default: "ALL", e.g. "scope_of_work:NEW_BUILD")
    - `date_from`: Start date for KPI values (default: 30 days ago)
    - `date_to`: End date for KPI values (default: today)

    **Example Response:**
    ```json
    {
        "query_params": {...},
        "total_kpis": 5,
        "kpis": [
            {
                "kpi_id": "KPI_REV_001",
                "kpi_name": "Total Revenue",
                "current_value": 1500000.00,
                "current_value_formatted": "$1,500,000.00",
                "period_change_pct": 5.2,
                "trend": "UP",
                "time_series": [...]
            }
        ]
    }
    ```
    """
    try:
        query_params = DashboardQueryParams(
            user_id=user_id,
            project_ids=project_ids.split(",") if project_ids else None,
            level_ids=level_ids.split(",") if level_ids else None,
            function_ids=function_ids.split(",") if function_ids else None,
            geo_codes=geo_codes.split(",") if geo_codes else None,
            geo_level=geo_level,
            kpi_ids=kpi_ids.split(",") if kpi_ids else None,
            kpi_category=kpi_category,
            dimension_key=dimension_key,
            date_from=date_from,
            date_to=date_to,
        )

        dashboard_service = DashboardService(db)
        kpis = await dashboard_service.get_dashboard_kpis(query_params)

        return DashboardResponse(
            query_params=query_params,
            total_kpis=len(kpis),
            kpis=kpis,
        )

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch dashboard data: {str(e)}")


@router.get("/kpis/aggregate", response_model=AggregatedKPIResponse)
async def get_aggregated_kpis(
    kpi_ids: str = Query(..., description="Comma-separated KPI IDs to aggregate"),
    geo_codes: str = Query(..., description="Comma-separated geo codes to combine, e.g. 'US_WEST,US_EAST,APAC'"),
    geo_level: Optional[str] = Query(None, description="Filter by geo level: OVERALL | REGION | AREA | MARKET"),
    aggregation_override: Optional[str] = Query(None, description="Override aggregation method for all KPIs: SUM | AVG | MIN | MAX | WEIGHTED_AVG"),
    dimension_key: str = Query("ALL", description="Dimension filter combo, e.g. 'scope_of_work:NEW_BUILD' or 'ALL'"),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Aggregate KPI Values Across Multiple Geographies**

    Combines KPI values from several geographies into a single result per KPI.
    Useful for custom rollups — e.g. sum revenue across US_WEST + US_EAST + APAC.

    **Aggregation logic per KPI:**
    - Uses each KPI's configured `aggregation_method` (SUM, AVG, MIN, MAX, WEIGHTED_AVG)
    - Supply `aggregation_override` to force the same method across all requested KPIs
    - Change percentages are recalculated from the aggregated current vs previous values

    **Example:**
    ```
    GET /dashboard/kpis/aggregate
        ?kpi_ids=KPI_REVENUE,KPI_SITES
        &geo_codes=US_WEST,US_EAST,APAC
        &aggregation_override=SUM
    ```
    """
    try:
        kpi_id_list  = [k.strip() for k in kpi_ids.split(",") if k.strip()]
        geo_code_list = [g.strip() for g in geo_codes.split(",") if g.strip()]

        if not kpi_id_list:
            raise HTTPException(status_code=422, detail="At least one kpi_id is required")
        if not geo_code_list:
            raise HTTPException(status_code=422, detail="At least one geo_code is required")

        dashboard_service = DashboardService(db)
        aggregated = await dashboard_service.aggregate_kpi_values(
            kpi_ids=kpi_id_list,
            geo_codes=geo_code_list,
            geo_level=geo_level,
            aggregation_override=aggregation_override,
            dimension_key=dimension_key,
        )

        return AggregatedKPIResponse(
            kpi_ids=kpi_id_list,
            geo_codes=geo_code_list,
            aggregation_method_override=aggregation_override,
            total_kpis=len(aggregated),
            kpis=aggregated,
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Aggregation failed: {str(e)}")


@router.get("/project/aggregate", response_model=ProjectAggregationResponse)
async def aggregate_project_kpis(
    project_id: str = Query(..., description="Project ID to aggregate KPIs for, e.g. 'NTM'"),
    geo_codes: str = Query(..., description="Comma-separated geo codes to combine, e.g. 'US_WEST,US_EAST,APAC'"),
    function_ids: Optional[str] = Query(None, description="Comma-separated function IDs to further filter KPIs"),
    level_ids: Optional[str] = Query(None, description="Comma-separated level IDs (HOME, PHASE, SITE) to further filter KPIs"),
    aggregation_override: Optional[str] = Query(None, description="Override aggregation method: SUM | AVG | MIN | MAX | WEIGHTED_AVG"),
    dimension_key: str = Query("ALL", description="Dimension filter combo, e.g. 'scope_of_work:NEW_BUILD' or 'ALL'"),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Aggregate All Project KPIs Across Selected Geographies**

    Fetches every active KPI belonging to a project and aggregates values
    across the requested geographies — strictly within the same geo level.

    **Level isolation rule:**
    Each geo_code is resolved to its level (MARKET / AREA / REGION / OVERALL).
    Results are returned grouped by level. A MARKET value is never combined
    with an AREA or REGION value — they appear in separate level buckets.

    **Example — mix of levels in one request:**
    ```
    GET /dashboard/project/aggregate
        ?project_id=NTM
        &geo_codes=US_WEST,US_EAST,APAC,EMEA_NORTH
    ```
    If US_WEST and US_EAST are MARKETs, and APAC and EMEA_NORTH are REGIONs,
    the response contains two buckets:
    - `MARKET`: US_WEST + US_EAST aggregated
    - `REGION`: APAC + EMEA_NORTH aggregated

    **`geo_codes_unresolved`** lists any geo codes not found in dim_geography.
    """
    try:
        geo_code_list   = [g.strip() for g in geo_codes.split(",") if g.strip()]
        function_id_list = [f.strip() for f in function_ids.split(",") if f.strip()] if function_ids else None
        level_id_list     = [t.strip() for t in level_ids.split(",") if t.strip()] if level_ids else None

        if not geo_code_list:
            raise HTTPException(status_code=422, detail="At least one geo_code is required")

        dashboard_service = DashboardService(db)
        by_level, unresolved = await dashboard_service.aggregate_project_kpis(
            project_id=project_id,
            geo_codes=geo_code_list,
            function_ids=function_id_list,
            level_ids=level_id_list,
            aggregation_override=aggregation_override,
            dimension_key=dimension_key,
        )

        return ProjectAggregationResponse(
            project_id=project_id,
            geo_codes_requested=geo_code_list,
            aggregation_method_override=aggregation_override,
            geo_codes_unresolved=unresolved,
            by_level=by_level,
        )

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Project aggregation failed: {str(e)}")


@router.get("/kpi/{kpi_id}/drilldown")
async def get_kpi_drilldown(
    kpi_id: str,
    parent_geo_code: str = Query(..., description="Parent geography code, e.g. 'APAC'"),
    calculation_date: date = Query(default_factory=date.today, description="Date for KPI values"),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Get KPI Drill-down**

    Drill down from a parent geography to child geographies.
    Example: From REGION → all AREAs, or from AREA → all MARKETs

    **Authentication:** Requires valid API key

    **Example:**
    - Parent: APAC (REGION level)
    - Returns: KPI values for all Areas under APAC
    """
    try:
        dashboard_service = DashboardService(db)
        drilldown_data = await dashboard_service.get_geography_drilldown(
            kpi_id=kpi_id,
            parent_geo_code=parent_geo_code,
            calculation_date=calculation_date,
        )

        if not drilldown_data:
            return {
                "kpi_id": kpi_id,
                "parent_geo_code": parent_geo_code,
                "calculation_date": calculation_date,
                "message": "No child geographies found or no data available",
                "drilldown": [],
            }

        return {
            "kpi_id": kpi_id,
            "parent_geo_code": parent_geo_code,
            "calculation_date": calculation_date,
            "total_children": len(drilldown_data),
            "drilldown": drilldown_data,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Drill-down failed: {str(e)}")


@router.get("/geography/tree")
async def get_geography_tree(
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Get Geography Hierarchy Tree**

    Returns the complete geography hierarchy in tree structure.
    Useful for building navigation/filter dropdowns.

    **Authentication:** Requires valid API key
    """
    try:
        geo_table = settings.TABLES["dim_geography"]
        q = text(f"""
            SELECT
                geo_id, geo_code, geo_name, geo_level,
                parent_geo_id, display_order
            FROM {geo_table}
            WHERE is_active = TRUE
            ORDER BY
                CASE geo_level
                    WHEN 'OVERALL' THEN 1
                    WHEN 'REGION'  THEN 2
                    WHEN 'AREA'    THEN 3
                    WHEN 'MARKET'  THEN 4
                END,
                display_order
        """)

        results = (await db.execute(q)).fetchall()
        geographies = [dict(row._mapping) for row in results]

        # Build tree structure
        geo_map = {
            geo["geo_id"]: {**geo, "children": []} for geo in geographies
        }
        tree = []
        for geo in geo_map.values():
            parent = geo.get("parent_geo_id")
            if parent and parent in geo_map:
                geo_map[parent]["children"].append(geo)
            else:
                tree.append(geo)

        return {"total_geographies": len(geographies), "tree": tree}

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch geography tree: {str(e)}")


@router.get("/kpi/definitions")
async def get_kpi_definitions(
    category: Optional[str] = None,
    project_id: Optional[str] = None,
    level_id: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Get KPI Definitions**

    Retrieve KPI metadata and definitions with optional filtering.

    **Authentication:** Requires valid API key
    """
    try:
        kpi_table = settings.TABLES["kpi_master"]
        query_parts = [f"SELECT * FROM {kpi_table} WHERE is_active = TRUE"]
        params = {}

        if category:
            query_parts.append("AND kpi_category = :category")
            params["category"] = category

        if project_id:
            query_parts.append("AND (project_ids IS NULL OR :project_id = ANY(project_ids))")
            params["project_id"] = project_id

        if level_id:
            query_parts.append("AND (level_ids IS NULL OR :level_id = ANY(level_ids))")
            params["level_id"] = level_id

        query_parts.append("ORDER BY priority ASC")

        results = (await db.execute(text(" ".join(query_parts)), params)).fetchall()

        return {
            "total_kpis": len(results),
            "kpis": [dict(row._mapping) for row in results],
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch KPI definitions: {str(e)}")


@router.get("/kpi/{kpi_id}/detail")
async def get_kpi_detail(
    kpi_id: str,
    date_from: Optional[date] = Query(None, description="Start date (YYYY-MM-DD)"),
    date_to: Optional[date] = Query(None, description="End date (YYYY-MM-DD)"),
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Get KPI Detail Table**

    Executes the `drilldown_sql` configured for this KPI and returns all rows
    as structured JSON — ready to render as a table in the frontend.

    There is one drill-down table per KPI (no geography filtering).

    Returns 404 if the KPI has no `drilldown_sql` configured.

    **Available bind params in drilldown_sql:**
    `:start_date`, `:end_date`
    """
    try:
        kpi_table = settings.TABLES["kpi_master"]

        # 1. Fetch drilldown_sql + kpi_name
        kpi_row = (await db.execute(
            text(f"SELECT kpi_name, drilldown_sql FROM {kpi_table} WHERE kpi_id = :kpi_id AND is_active = TRUE"),
            {"kpi_id": kpi_id},
        )).fetchone()

        if not kpi_row:
            raise HTTPException(status_code=404, detail=f"KPI '{kpi_id}' not found")
        if not kpi_row.drilldown_sql:
            raise HTTPException(status_code=404, detail=f"KPI '{kpi_id}' has no drilldown SQL configured")

        today = date.today()
        sql = _substitute_params(kpi_row.drilldown_sql, {
            "start_date":  date_from or today,
            "end_date":    date_to or today,
        })

        # 2. Execute and return all rows as JSON
        result = await db.execute(text(sql))
        columns = list(result.keys())
        rows = [dict(zip(columns, row)) for row in result.fetchall()]

        return {
            "kpi_id":    kpi_id,
            "kpi_name":  kpi_row.kpi_name,
            "date_from": date_from or today,
            "date_to":   date_to or today,
            "columns":   columns,
            "total_rows": len(rows),
            "rows":      rows,
        }

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Detail query failed: {str(e)}")


@router.get("/reference-data")
async def get_reference_data(
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Get Reference / Lookup Data**

    Returns all valid values for project configurations (including per-project
    functions, geo_codes, and filter dimensions), KPI categories, geography
    levels, display formats, and aggregation methods.

    Use this endpoint to populate filter dropdowns and multi-select components
    in the frontend without hardcoding values.
    """
    from app.services.project_config_service import ProjectConfigService

    svc = ProjectConfigService(db)
    project_rows = await svc.list_projects(is_active=True)

    # Build per-project config for frontend
    projects_config = {}
    for p in project_rows:
        pid = p["project_id"]
        projects_config[pid] = {
            "name": p["project_name"],
            "functions": [{"id": f, "name": f} for f in (p.get("functions") or [])],
            "geo_codes": p.get("geo_codes") or [],
            "filter_dimensions": p.get("filter_dimensions") or {},
            "cross_filters": p.get("cross_filters", False),
        }

    # Fallback: also include static config projects not yet in DB
    for p in settings.PROJECTS:
        if p not in projects_config:
            funcs = settings.PROJECT_FUNCTIONS.get(p, [])
            projects_config[p] = {
                "name": p,
                "functions": [{"id": f, "name": f} for f in funcs],
                "geo_codes": [],
                "filter_dimensions": {},
                "cross_filters": False,
            }

    return {
        "projects": projects_config,
        "levels": [{"id": l, "name": l} for l in settings.LEVELS],
        "kpi_categories": [{"id": c.value, "name": c.value} for c in KPICategory],
        "kpi_tags": [{"id": t.value, "name": t.value} for t in KPITag],
        "geo_levels": [{"id": g.value, "name": g.value} for g in GeoLevel],
        "display_formats": [{"id": d.value, "name": d.value} for d in DisplayFormat],
        "aggregation_methods": [{"id": a.value, "name": a.value} for a in AggregationMethod],
    }
