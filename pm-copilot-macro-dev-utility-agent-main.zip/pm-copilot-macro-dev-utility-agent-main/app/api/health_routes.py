from datetime import datetime

import psutil
from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.core.database import get_db

router = APIRouter(tags=["Health"])


@router.get("/health")
async def health_check(db: AsyncSession = Depends(get_db)):
    """
    **Health Check Endpoint**

    Returns application health status and system metrics.
    No authentication required.
    """
    try:
        await db.execute(text("SELECT 1"))
        db_status = "healthy"
    except Exception as e:
        db_status = f"unhealthy: {str(e)}"

    cpu_percent = psutil.cpu_percent(interval=1)
    memory = psutil.virtual_memory()
    disk = psutil.disk_usage("/")

    return {
        "status": "healthy" if db_status == "healthy" else "degraded",
        "timestamp": datetime.now().isoformat(),
        "app": {
            "name": settings.APP_NAME,
            "version": settings.APP_VERSION,
            "debug": settings.DEBUG,
        },
        "database": {
            "status": db_status,
            "pool_size": settings.DB_POOL_SIZE,
        },
        "system": {
            "cpu_percent": cpu_percent,
            "memory_percent": memory.percent,
            "memory_available_gb": round(memory.available / (1024 ** 3), 2),
            "disk_percent": disk.percent,
            "disk_free_gb": round(disk.free / (1024 ** 3), 2),
        },
    }


@router.get("/health/db")
async def database_health(db: AsyncSession = Depends(get_db)):
    """
    **Database Health Check**

    Detailed database connectivity and performance check.
    """
    try:
        start = datetime.now()
        kpi_table = settings.TABLES["kpi_master"]
        result = (await db.execute(text(f"SELECT COUNT(*) FROM {kpi_table}"))).scalar()
        query_time_ms = (datetime.now() - start).total_seconds() * 1000

        return {
            "status": "healthy",
            "query_time_ms": round(query_time_ms, 2),
            "total_kpis": result,
            "connection_pool": {
                "size": settings.DB_POOL_SIZE,
                "max_overflow": settings.DB_MAX_OVERFLOW,
            },
        }

    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}
