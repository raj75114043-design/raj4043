import logging
from datetime import date
from typing import List, Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.core.database import AsyncSessionLocal, get_db
from app.core.security import verify_api_key
from app.models.kpi_models import (
    CalculationJobCreate,
    CalculationJobResponse,
    JobStatus,
    JobType,
)
from app.services.data_archival import DataArchivalService
from app.services.kpi_calculator import KPICalculator

router = APIRouter(prefix="/api/v1/calculation", tags=["Calculation"])
logger = logging.getLogger(__name__)


# ------------------------------------------------------------------ #
# Background task runners (own their own DB session)                   #
# ------------------------------------------------------------------ #

async def _run_generic_job_background(
    job_id: str,
    job_type: JobType,
    kpi_ids: Optional[List[str]],
    geo_ids: Optional[List[str]],
    calculation_date: date,
    prev_period_days_back: Optional[int] = None,
) -> None:
    """
    Background worker for /trigger and /full-refresh.
    Creates its own DB session; auto-archives on completion.
    """
    async with AsyncSessionLocal() as db:
        try:
            calculator = KPICalculator(db)
            await calculator.execute_calculation_job(
                job_type=job_type,
                kpi_ids=kpi_ids,
                geo_ids=geo_ids,
                calculation_date=calculation_date,
                triggered_by="BACKGROUND",
                existing_job_id=job_id,
                prev_period_days_back=prev_period_days_back,
            )
            await DataArchivalService(db).archive_old_data()
            logger.info(f"Background job {job_id} completed with auto-archival")
        except Exception as e:
            logger.error(f"Background job {job_id} failed: {e}", exc_info=True)


async def _run_batch_background(
    job_id: str,
    geo_level: str,
    job_type: JobType,
    calculation_date: date,
    prev_period_days_back: Optional[int] = None,
) -> None:
    """
    Background worker for /batch-refresh/markets and /batch-refresh/areas.
    Creates its own DB session; auto-archives on completion.
    """
    async with AsyncSessionLocal() as db:
        try:
            calculator = KPICalculator(db)
            await calculator.execute_batch_by_level(
                geo_level=geo_level,
                calculation_date=calculation_date,
                job_type=job_type,
                triggered_by="BACKGROUND",
                existing_job_id=job_id,
                prev_period_days_back=prev_period_days_back,
            )
            await DataArchivalService(db).archive_old_data()
            logger.info(f"Background batch job {job_id} [{geo_level}] completed with auto-archival")
        except Exception as e:
            logger.error(f"Background batch job {job_id} [{geo_level}] failed: {e}", exc_info=True)


# ------------------------------------------------------------------ #
# Helper                                                               #
# ------------------------------------------------------------------ #

async def _get_job_row(db: AsyncSession, job_id: str) -> CalculationJobResponse:
    """Fetch a single job record and return as CalculationJobResponse."""
    q = text(f"SELECT * FROM {settings.TABLES['calculation_jobs']} WHERE job_id = :job_id")
    row = (await db.execute(q, {"job_id": job_id})).fetchone()
    if not row:
        raise HTTPException(status_code=500, detail="Job record not found after creation")
    return CalculationJobResponse(**dict(row._mapping))


# ------------------------------------------------------------------ #
# Endpoints                                                            #
# ------------------------------------------------------------------ #

@router.post("/trigger", response_model=CalculationJobResponse, status_code=202)
async def trigger_calculation(
    job_config: CalculationJobCreate,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    api_key: str = Depends(verify_api_key),
):
    """
    **Trigger KPI Calculation Job** *(fire-and-forget)*

    Returns **202 Accepted** immediately with the job record.
    Calculation runs in the background — poll `GET /jobs/{job_id}` for status.

    **Request Body:**
    - `job_type`: `FULL_REFRESH` | `INCREMENTAL` | `SINGLE_KPI` | `SINGLE_GEO`
    - `kpi_ids`: list of KPI IDs to calculate (`null` = all KPIs)
    - `geo_ids`: list of geography IDs (`null` = all geographies)
    - `calculation_date`: date for which to calculate KPIs
    - `prev_period_days_back`: how many days back to look for the comparison value (default: `PREV_PERIOD_DAYS_BACK` from config)

    **Auto-archive:** old KPI values are archived automatically on completion.
    """
    try:
        calc_date = job_config.calculation_date or date.today()
        calculator = KPICalculator(db)
        job_id = await calculator.create_pending_job(
            job_type=job_config.job_type,
            calculation_date=calc_date,
            triggered_by=f"API_KEY_{api_key[:8]}",
            kpi_ids=job_config.kpi_ids,
            geo_ids=job_config.geo_ids,
        )
        background_tasks.add_task(
            _run_generic_job_background,
            job_id=job_id,
            job_type=job_config.job_type,
            kpi_ids=job_config.kpi_ids,
            geo_ids=job_config.geo_ids,
            calculation_date=calc_date,
            prev_period_days_back=job_config.prev_period_days_back,
        )
        return await _get_job_row(db, job_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to queue calculation job: {str(e)}")


@router.post("/full-refresh", response_model=CalculationJobResponse, status_code=202)
async def trigger_full_refresh(
    background_tasks: BackgroundTasks,
    calculation_date: Optional[date] = None,
    prev_period_days_back: Optional[int] = None,
    db: AsyncSession = Depends(get_db),
    api_key: str = Depends(verify_api_key),
):
    """
    **Trigger Full Refresh of All KPIs** *(fire-and-forget)*

    Returns **202 Accepted** immediately. Recalculates all active KPIs across
    all geographies in the background. Poll `GET /jobs/{job_id}` for progress.

    **Auto-archive:** old KPI values are archived automatically on completion.
    """
    try:
        calc_date = calculation_date or date.today()
        calculator = KPICalculator(db)
        job_id = await calculator.create_pending_job(
            job_type=JobType.FULL_REFRESH,
            calculation_date=calc_date,
            triggered_by=f"API_KEY_{api_key[:8]}",
        )
        background_tasks.add_task(
            _run_generic_job_background,
            job_id=job_id,
            job_type=JobType.FULL_REFRESH,
            kpi_ids=None,
            geo_ids=None,
            calculation_date=calc_date,
            prev_period_days_back=prev_period_days_back,
        )
        return await _get_job_row(db, job_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to queue full refresh: {str(e)}")


@router.post("/batch-refresh/markets", response_model=CalculationJobResponse, status_code=202)
async def batch_refresh_markets(
    background_tasks: BackgroundTasks,
    calculation_date: Optional[date] = None,
    prev_period_days_back: Optional[int] = None,
    db: AsyncSession = Depends(get_db),
    api_key: str = Depends(verify_api_key),
):
    """
    **Batch Refresh — All Markets** *(fire-and-forget)*

    Returns **202 Accepted** immediately. Recalculates all KPIs for every
    active MARKET geography in the background. Poll `GET /jobs/{job_id}`.

    Optimisations:
    - Comparison values pre-fetched in one bulk query across all (KPI, market) pairs.
    - KPI queries run concurrently via `asyncio.gather()` with a DB semaphore.
    - All rows written in a single bulk upsert.

    **Auto-archive:** old KPI values are archived automatically on completion.
    """
    try:
        calc_date = calculation_date or date.today()
        calculator = KPICalculator(db)
        job_id = await calculator.create_pending_job(
            job_type=JobType.BATCH_MARKET_REFRESH,
            calculation_date=calc_date,
            triggered_by=f"API_KEY_{api_key[:8]}",
        )
        background_tasks.add_task(
            _run_batch_background,
            job_id=job_id,
            geo_level="MARKET",
            job_type=JobType.BATCH_MARKET_REFRESH,
            calculation_date=calc_date,
            prev_period_days_back=prev_period_days_back,
        )
        return await _get_job_row(db, job_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to queue batch market refresh: {str(e)}")


@router.post("/batch-refresh/areas", response_model=CalculationJobResponse, status_code=202)
async def batch_refresh_areas(
    background_tasks: BackgroundTasks,
    calculation_date: Optional[date] = None,
    prev_period_days_back: Optional[int] = None,
    db: AsyncSession = Depends(get_db),
    api_key: str = Depends(verify_api_key),
):
    """
    **Batch Refresh — All Areas** *(fire-and-forget)*

    Returns **202 Accepted** immediately. Recalculates all KPIs for every
    active AREA geography in the background. Poll `GET /jobs/{job_id}`.

    Same concurrency and bulk-upsert optimisations as the markets endpoint.

    **Auto-archive:** old KPI values are archived automatically on completion.
    """
    try:
        calc_date = calculation_date or date.today()
        calculator = KPICalculator(db)
        job_id = await calculator.create_pending_job(
            job_type=JobType.BATCH_AREA_REFRESH,
            calculation_date=calc_date,
            triggered_by=f"API_KEY_{api_key[:8]}",
        )
        background_tasks.add_task(
            _run_batch_background,
            job_id=job_id,
            geo_level="AREA",
            job_type=JobType.BATCH_AREA_REFRESH,
            calculation_date=calc_date,
            prev_period_days_back=prev_period_days_back,
        )
        return await _get_job_row(db, job_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to queue batch area refresh: {str(e)}")


@router.post("/archive")
async def trigger_archival(
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Trigger Manual Data Archival**

    Moves KPI values older than the configured retention period from
    `kpi_values_live` to `kpi_values_historical`.

    Note: archival also runs automatically after every batch/full refresh.
    """
    try:
        result = await DataArchivalService(db).archive_old_data()
        return {
            "status": "SUCCESS",
            "message": f"Archived {result['records_archived']} records",
            "details": result,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Archival failed: {str(e)}")


@router.get("/jobs", response_model=List[CalculationJobResponse])
async def get_calculation_jobs(
    status: Optional[JobStatus] = None,
    limit: int = 50,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **List Calculation Jobs**

    Returns job history ordered by creation time descending.
    Filter by `status`: `RUNNING` | `COMPLETED` | `FAILED` | `CANCELLED`.
    """
    table = settings.TABLES["calculation_jobs"]
    if status:
        q = text(f"""
            SELECT * FROM {table}
            WHERE status = :status
            ORDER BY created_at DESC
            LIMIT :limit
        """)
        results = (await db.execute(q, {"status": status.value, "limit": limit})).fetchall()
    else:
        q = text(f"SELECT * FROM {table} ORDER BY created_at DESC LIMIT :limit")
        results = (await db.execute(q, {"limit": limit})).fetchall()

    return [CalculationJobResponse(**dict(row._mapping)) for row in results]


@router.get("/jobs/{job_id}", response_model=CalculationJobResponse)
async def get_job_details(
    job_id: str,
    db: AsyncSession = Depends(get_db),
    _: str = Depends(verify_api_key),
):
    """
    **Get Job Status**

    Poll this endpoint after triggering any refresh to check progress.
    `status` transitions: `RUNNING` → `COMPLETED` | `FAILED`.
    """
    table = settings.TABLES["calculation_jobs"]
    result = (await db.execute(
        text(f"SELECT * FROM {table} WHERE job_id = :job_id"),
        {"job_id": job_id},
    )).fetchone()

    if not result:
        raise HTTPException(status_code=404, detail="Job not found")

    return CalculationJobResponse(**dict(result._mapping))
