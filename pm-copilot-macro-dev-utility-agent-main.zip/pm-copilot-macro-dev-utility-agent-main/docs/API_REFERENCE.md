# KPI Dashboard API — Reference Guide

> **Audience:** Node.js / frontend integration teams
> **Base URL:** `https://<your-host>`
> **API version prefix:** `/api/v1`

---

## Table of Contents

1. [Authentication](#1-authentication)
2. [Rate Limiting](#2-rate-limiting)
3. [Error Format](#3-error-format)
4. [Geography Hierarchy](#4-geography-hierarchy)
5. [Calculation Endpoints](#5-calculation-endpoints)
   - [POST /trigger](#51-post-apiv1calculationtrigger)
   - [POST /full-refresh](#52-post-apiv1calculationfull-refresh)
   - [POST /batch-refresh/markets](#53-post-apiv1calculationbatch-refreshmarkets)
   - [POST /batch-refresh/areas](#54-post-apiv1calculationbatch-refreshareas)
   - [POST /archive](#55-post-apiv1calculationarchive)
   - [GET /jobs](#56-get-apiv1calculationjobs)
   - [GET /jobs/{job_id}](#57-get-apiv1calculationjobsjob_id)
6. [Dashboard Endpoints](#6-dashboard-endpoints)
   - [GET /kpis](#61-get-apiv1dashboardkpis)
   - [GET /kpi/{kpi_id}/drilldown](#62-get-apiv1dashboardkpikpi_iddrilldown)
   - [GET /geography/tree](#63-get-apiv1dashboardgeographytree)
   - [GET /kpi/definitions](#64-get-apiv1dashboardkpidefinitions)
7. [Health Endpoints](#7-health-endpoints)
8. [Fire-and-Forget Workflow](#8-fire-and-forget-workflow)
9. [KPI Value Schema Reference](#9-kpi-value-schema-reference)
10. [Environment Configuration](#10-environment-configuration)
11. [KPI SQL Template Contract](#11-kpi-sql-template-contract)

---

## 1. Authentication

Every endpoint (except `/health`) requires an API key passed in the request header.

| Header | Value |
|---|---|
| `X-API-Key` | Your assigned API key |

**Node.js example (axios):**
```js
const axios = require('axios');

const client = axios.create({
  baseURL: 'https://<your-host>',
  headers: { 'X-API-Key': process.env.KPI_API_KEY },
});
```

A missing or invalid key returns:
```json
HTTP 403
{ "detail": "Invalid or missing API key" }
```

---

## 2. Rate Limiting

- **100 requests per minute** per API key
- Rate limit is enforced server-side per key; the `/health` endpoint is exempt
- Exceeding the limit returns **HTTP 429**

---

## 3. Error Format

All errors follow a consistent JSON shape:

```json
{
  "detail": "Human-readable error message",
  "message": "Optional secondary message (dev mode only)"
}
```

| Status | Meaning |
|---|---|
| `400` | Bad request / invalid query parameters |
| `403` | Missing or invalid API key |
| `404` | Resource not found |
| `422` | Request body validation failed |
| `429` | Rate limit exceeded |
| `500` | Internal server error |

**Validation error (422) shape:**
```json
{
  "detail": [
    {
      "loc": ["body", "job_type"],
      "msg": "value is not a valid enumeration member",
      "type": "type_error.enum"
    }
  ],
  "message": "Request validation failed"
}
```

---

## 4. Geography Hierarchy

The API uses a 4-level geography model:

```
OVERALL (1 record — global aggregate)
  └── REGION  (~3 records, e.g. South, Central, North)
        └── AREA  (~20 records, one per region subdivision)
              └── MARKET  (~40 records, the leaf-level nodes)
```

Each geography has two identifiers:

| Field | Type | Description | Example |
|---|---|---|---|
| `geo_id` | string | Surrogate key — use in all API filters | `GEO_M001` |
| `geo_code` | string | Natural key — matches raw source-data columns (always UPPER-CASE) | `US_WEST` |

**Always use `geo_id`** when filtering API requests (query params, request bodies).
`geo_code` is used internally by the KPI SQL engine when querying source tables.

---

## 5. Calculation Endpoints

All refresh/trigger endpoints are **fire-and-forget**:
- They return **HTTP 202 Accepted** immediately with a job record
- The actual calculation runs asynchronously in the background
- Poll `GET /jobs/{job_id}` to track progress

---

### 5.1 `POST /api/v1/calculation/trigger`

Trigger a targeted KPI calculation job (any job type, optional KPI/geo filters).

**Request body:**

```json
{
  "job_type": "INCREMENTAL",
  "kpi_ids": ["KPI_REV_001", "KPI_MARGIN_002"],
  "geo_ids": ["GEO_M001", "GEO_M002"],
  "calculation_date": "2024-01-15"
}
```

| Field | Type | Required | Default | Description |
|---|---|---|---|---|
| `job_type` | string (enum) | No | `INCREMENTAL` | See [Job Types](#job-types) |
| `kpi_ids` | string[] | No | `null` (all KPIs) | Limit to specific KPIs |
| `geo_ids` | string[] | No | `null` (all geos) | Limit to specific geographies |
| `calculation_date` | string (YYYY-MM-DD) | No | today | Date to calculate for |

**Response: HTTP 202**

```json
{
  "job_id": "JOB_20240115_143022_a1b2c3",
  "job_type": "INCREMENTAL",
  "status": "RUNNING",
  "kpi_ids": ["KPI_REV_001", "KPI_MARGIN_002"],
  "geo_ids": ["GEO_M001", "GEO_M002"],
  "calculation_date": "2024-01-15",
  "started_at": null,
  "completed_at": null,
  "duration_seconds": null,
  "total_calculations_planned": null,
  "calculations_completed": 0,
  "calculations_failed": 0,
  "error_message": null,
  "triggered_by": "API_KEY_abc12345",
  "created_at": "2024-01-15T14:30:22.000Z"
}
```

---

### 5.2 `POST /api/v1/calculation/full-refresh`

Recalculate **all active KPIs** across **all geographies**.

**Query parameters:**

| Parameter | Type | Required | Default | Description |
|---|---|---|---|---|
| `calculation_date` | string (YYYY-MM-DD) | No | today | Date to calculate for |

**Request body:** none

**Response: HTTP 202** — same `CalculationJobResponse` shape as above, `job_type: "FULL_REFRESH"`

**Node.js example:**
```js
const response = await client.post('/api/v1/calculation/full-refresh', null, {
  params: { calculation_date: '2024-01-15' },
});
const jobId = response.data.job_id;
// Poll until complete
await pollUntilDone(jobId);
```

---

### 5.3 `POST /api/v1/calculation/batch-refresh/markets`

Recalculate all active KPIs for every **MARKET-level** geography in a single optimised pass.

Uses `asyncio.gather` concurrency with a DB semaphore — significantly faster than triggering markets individually.

**Query parameters:**

| Parameter | Type | Required | Default |
|---|---|---|---|
| `calculation_date` | string (YYYY-MM-DD) | No | today |

**Response: HTTP 202** — `job_type: "BATCH_MARKET_REFRESH"`

---

### 5.4 `POST /api/v1/calculation/batch-refresh/areas`

Same as markets endpoint, but targets all **AREA-level** geographies.

**Query parameters:**

| Parameter | Type | Required | Default |
|---|---|---|---|
| `calculation_date` | string (YYYY-MM-DD) | No | today |

**Response: HTTP 202** — `job_type: "BATCH_AREA_REFRESH"`

---

### 5.5 `POST /api/v1/calculation/archive`

Manually trigger data archival — moves KPI values older than the configured retention window (default: 90 days) from the live table to the historical table.

> **Note:** Archival runs automatically after every refresh job completes. Manual trigger is for operational use only.

**Request body:** none

**Response: HTTP 200**

```json
{
  "status": "SUCCESS",
  "message": "Archived 1240 records",
  "details": {
    "records_archived": 1240,
    "cutoff_date": "2023-10-17"
  }
}
```

---

### 5.6 `GET /api/v1/calculation/jobs`

List recent calculation jobs.

**Query parameters:**

| Parameter | Type | Required | Default | Description |
|---|---|---|---|---|
| `status` | string (enum) | No | all | Filter: `PENDING` \| `RUNNING` \| `COMPLETED` \| `FAILED` \| `CANCELLED` |
| `limit` | integer | No | `50` | Max results to return |

**Response: HTTP 200** — array of `CalculationJobResponse` objects, newest first

```json
[
  {
    "job_id": "JOB_20240115_143022_a1b2c3",
    "job_type": "BATCH_MARKET_REFRESH",
    "status": "COMPLETED",
    "calculation_date": "2024-01-15",
    "started_at": "2024-01-15T14:30:23.000Z",
    "completed_at": "2024-01-15T14:31:45.000Z",
    "duration_seconds": 82,
    "calculations_completed": 320,
    "calculations_failed": 0,
    "triggered_by": "API_KEY_abc12345",
    "created_at": "2024-01-15T14:30:22.000Z"
  }
]
```

---

### 5.7 `GET /api/v1/calculation/jobs/{job_id}`

Get status and details for a specific job. Use this to poll after triggering a refresh.

**Path parameter:** `job_id` — the value returned by any trigger endpoint

**Response: HTTP 200** — single `CalculationJobResponse`

**Response: HTTP 404** if job not found

---

#### Job Types

| `job_type` | Description |
|---|---|
| `FULL_REFRESH` | All KPIs × all geographies |
| `INCREMENTAL` | Targeted subset via `kpi_ids` / `geo_ids` |
| `SINGLE_KPI` | One KPI across all/specified geographies |
| `SINGLE_GEO` | All KPIs for one geography |
| `BATCH_MARKET_REFRESH` | All KPIs × all MARKET-level geographies |
| `BATCH_AREA_REFRESH` | All KPIs × all AREA-level geographies |

#### Job Statuses

| `status` | Description |
|---|---|
| `PENDING` | Job created, background task not yet started |
| `RUNNING` | Calculations in progress |
| `COMPLETED` | All calculations finished successfully |
| `FAILED` | Job encountered an error (check `error_message`) |
| `CANCELLED` | Job was cancelled before completion |

---

## 6. Dashboard Endpoints

These endpoints serve **pre-calculated** KPI data. They are read-only and fast — no computation happens here.

---

### 6.1 `GET /api/v1/dashboard/kpis`

Fetch KPI values filtered by persona (project, team, function) and/or geography.

Returns all geographies and all active KPIs by default when no filters are supplied.

**Query parameters:**

| Parameter | Type | Required | Default | Description |
|---|---|---|---|---|
| `user_id` | string | No | — | User ID for future profile-based defaults |
| `project_ids` | string | No | all projects | Comma-separated, e.g. `PROJ001,PROJ002` |
| `team_ids` | string | No | all teams | Comma-separated, e.g. `SALES,OPS` |
| `function_ids` | string | No | all functions | Comma-separated function IDs |
| `geo_ids` | string | No | **all geographies** | Comma-separated geo_ids, e.g. `GEO_R001,GEO_M005` |
| `kpi_ids` | string | No | all KPIs | Comma-separated KPI IDs |
| `date_from` | string (YYYY-MM-DD) | No | 30 days ago | Start of date range |
| `date_to` | string (YYYY-MM-DD) | No | today | End of date range |

**Response: HTTP 200**

```json
{
  "query_params": {
    "user_id": null,
    "project_ids": null,
    "geo_ids": ["GEO_R001"],
    "kpi_ids": null,
    "date_from": "2023-12-17",
    "date_to": "2024-01-15"
  },
  "total_kpis": 2,
  "query_timestamp": "2024-01-15T14:45:00.000Z",
  "kpis": [
    {
      "kpi_id": "KPI_REV_001",
      "kpi_name": "Total Revenue",
      "kpi_category": "FINANCIAL",
      "display_format": "CURRENCY",
      "unit_symbol": "$",
      "geo_id": "GEO_R001",
      "geo_name": "South Region",
      "geo_level": "REGION",
      "current_value": 1500000.00,
      "current_value_formatted": "$1,500,000.00",
      "previous_period_value": null,
      "period_change_pct": 5.2,
      "trend": "UP",
      "time_series": [
        {
          "date": "2024-01-15",
          "value": 1500000.00,
          "formatted": "$1,500,000.00",
          "period_change_pct": 5.2,
          "year_change_pct": 12.7
        },
        {
          "date": "2024-01-14",
          "value": 1426000.00,
          "formatted": "$1,426,000.00",
          "period_change_pct": -1.1,
          "year_change_pct": 10.3
        }
      ]
    }
  ]
}
```

**Trend values:**

| `trend` | Meaning |
|---|---|
| `UP` | Period-on-period change is positive |
| `DOWN` | Period-on-period change is negative |
| `NEUTRAL` | No previous period data available |

**Node.js example:**
```js
// Fetch KPIs for a specific region over the last week
const { data } = await client.get('/api/v1/dashboard/kpis', {
  params: {
    geo_ids: 'GEO_R001',
    date_from: '2024-01-08',
    date_to: '2024-01-15',
  },
});

console.log(`Loaded ${data.total_kpis} KPI records`);
data.kpis.forEach(kpi => {
  console.log(`${kpi.kpi_name} @ ${kpi.geo_name}: ${kpi.current_value_formatted} (${kpi.trend})`);
});
```

---

### 6.2 `GET /api/v1/dashboard/kpi/{kpi_id}/drilldown`

Drill from a parent geography down to its children for a specific KPI.

**Examples:**
- Parent = `GEO_OVERALL` → returns all REGIONs
- Parent = `GEO_R001` (APAC Region) → returns all AREAs under APAC
- Parent = `GEO_A005` (Australia Area) → returns all MARKETs under Australia

**Path parameters:**

| Parameter | Type | Description |
|---|---|---|
| `kpi_id` | string | The KPI to drill into |

**Query parameters:**

| Parameter | Type | Required | Default | Description |
|---|---|---|---|---|
| `parent_geo_id` | string | **Yes** | — | geo_id of the parent node |
| `calculation_date` | string (YYYY-MM-DD) | No | today | Date to pull values for |

**Response: HTTP 200**

```json
{
  "kpi_id": "KPI_REV_001",
  "parent_geo_id": "GEO_R001",
  "calculation_date": "2024-01-15",
  "total_children": 5,
  "drilldown": [
    {
      "geo_id": "GEO_A001",
      "geo_name": "Northern Area",
      "geo_level": "AREA",
      "kpi_value": 320000.00,
      "kpi_value_formatted": "$320,000.00",
      "period_on_period_change_pct": 3.1
    }
  ]
}
```

When no children exist or no data is available:
```json
{
  "kpi_id": "KPI_REV_001",
  "parent_geo_id": "GEO_A999",
  "calculation_date": "2024-01-15",
  "message": "No child geographies found or no data available",
  "drilldown": []
}
```

---

### 6.3 `GET /api/v1/dashboard/geography/tree`

Returns the complete geography hierarchy as a nested tree. Useful for building navigation, filter dropdowns, or breadcrumbs.

**Response: HTTP 200**

```json
{
  "total_geographies": 65,
  "tree": [
    {
      "geo_id": "GEO_OVERALL",
      "geo_code": "OVERALL",
      "geo_name": "Global",
      "geo_level": "OVERALL",
      "parent_geo_id": null,
      "display_order": 1,
      "children": [
        {
          "geo_id": "GEO_R001",
          "geo_code": "SOUTH",
          "geo_name": "South Region",
          "geo_level": "REGION",
          "parent_geo_id": "GEO_OVERALL",
          "display_order": 1,
          "children": [
            {
              "geo_id": "GEO_A001",
              "geo_name": "Northern Area",
              "geo_level": "AREA",
              "children": [ ... ]
            }
          ]
        }
      ]
    }
  ]
}
```

---

### 6.4 `GET /api/v1/dashboard/kpi/definitions`

Retrieve KPI metadata (name, category, format, applicable geo levels, etc.) with optional filtering.

**Query parameters:**

| Parameter | Type | Required | Description |
|---|---|---|---|
| `category` | string | No | Filter by: `FINANCIAL` \| `OPERATIONAL` \| `QUALITY` \| `DELIVERY` |
| `project_id` | string | No | Filter by a single project ID |
| `team_id` | string | No | Filter by a single team ID |

**Response: HTTP 200**

```json
{
  "total_kpis": 12,
  "kpis": [
    {
      "kpi_id": "KPI_REV_001",
      "kpi_code": "TOTAL_REVENUE",
      "kpi_name": "Total Revenue",
      "kpi_description": "Sum of all revenue for the period",
      "kpi_category": "FINANCIAL",
      "applicable_geo_levels": ["OVERALL", "REGION", "AREA", "MARKET"],
      "display_format": "CURRENCY",
      "decimal_places": 2,
      "unit_symbol": "$",
      "aggregation_method": "SUM",
      "refresh_frequency": "DAILY",
      "priority": 10,
      "is_active": true,
      "created_at": "2024-01-01T00:00:00.000Z",
      "updated_at": "2024-01-15T00:00:00.000Z"
    }
  ]
}
```

---

## 7. Health Endpoints

No API key required for either health endpoint.

### `GET /health`

Returns overall application health and system metrics.

```json
{
  "status": "healthy",
  "timestamp": "2024-01-15T14:30:00.000Z",
  "app": {
    "name": "KPI Dashboard API",
    "version": "1.0.0",
    "debug": false
  },
  "database": {
    "status": "healthy",
    "pool_size": 20
  },
  "system": {
    "cpu_percent": 12.5,
    "memory_percent": 45.2,
    "memory_available_gb": 6.12,
    "disk_percent": 38.0,
    "disk_free_gb": 124.5
  }
}
```

`status` is `"degraded"` when the database ping fails.

### `GET /health/db`

Detailed database performance check. Runs a live `COUNT(*)` against the KPI master table.

```json
{
  "status": "healthy",
  "query_time_ms": 2.34,
  "total_kpis": 24,
  "connection_pool": {
    "size": 20,
    "max_overflow": 10
  }
}
```

---

## 8. Fire-and-Forget Workflow

All refresh/trigger endpoints return immediately (**HTTP 202**) with a job record in `RUNNING` status. The actual computation happens in a server-side background task.

**Recommended polling pattern (Node.js):**

```js
async function triggerAndWait(apiPath, params = {}) {
  // 1. Trigger — returns 202 immediately
  const { data: job } = await client.post(apiPath, null, { params });
  console.log(`Job created: ${job.job_id} (status: ${job.status})`);

  // 2. Poll until terminal state
  return await pollJob(job.job_id);
}

async function pollJob(jobId, intervalMs = 3000, maxWaitMs = 600_000) {
  const deadline = Date.now() + maxWaitMs;

  while (Date.now() < deadline) {
    const { data: job } = await client.get(`/api/v1/calculation/jobs/${jobId}`);

    if (job.status === 'COMPLETED') {
      console.log(`Job ${jobId} completed in ${job.duration_seconds}s`);
      console.log(`  ${job.calculations_completed} succeeded, ${job.calculations_failed} failed`);
      return job;
    }

    if (job.status === 'FAILED') {
      throw new Error(`Job ${jobId} failed: ${job.error_message}`);
    }

    if (job.status === 'CANCELLED') {
      throw new Error(`Job ${jobId} was cancelled`);
    }

    // Still PENDING or RUNNING — wait and retry
    await new Promise(resolve => setTimeout(resolve, intervalMs));
  }

  throw new Error(`Job ${jobId} did not complete within ${maxWaitMs / 1000}s`);
}

// Usage examples:
await triggerAndWait('/api/v1/calculation/full-refresh', { calculation_date: '2024-01-15' });
await triggerAndWait('/api/v1/calculation/batch-refresh/markets');
await triggerAndWait('/api/v1/calculation/batch-refresh/areas');
```

**Status transition diagram:**

```
PENDING → RUNNING → COMPLETED
                 ↘ FAILED
                 ↘ CANCELLED
```

**Auto-archival:** After every refresh job completes, the API automatically moves KPI values older than the retention window (default: 90 days) from the live table to the historical archive. No manual archival step is needed as part of your integration.

---

## 9. KPI Value Schema Reference

### `CalculationJobResponse`

| Field | Type | Description |
|---|---|---|
| `job_id` | string | Unique job identifier |
| `job_type` | string (enum) | One of the [Job Types](#job-types) |
| `status` | string (enum) | Current job state |
| `kpi_ids` | string[] \| null | KPIs targeted (null = all) |
| `geo_ids` | string[] \| null | Geographies targeted (null = all) |
| `calculation_date` | string (YYYY-MM-DD) | Date the KPIs were calculated for |
| `started_at` | datetime \| null | When the background task began |
| `completed_at` | datetime \| null | When the job finished |
| `duration_seconds` | integer \| null | Total elapsed time |
| `total_calculations_planned` | integer \| null | KPI × geo pairs planned |
| `calculations_completed` | integer | Successfully computed pairs |
| `calculations_failed` | integer | Failed pairs |
| `error_message` | string \| null | Populated on `FAILED` jobs |
| `triggered_by` | string | API key prefix that triggered the job |
| `created_at` | datetime | Record creation timestamp |

### `DashboardKPIData` (inside `GET /kpis` response)

| Field | Type | Description |
|---|---|---|
| `kpi_id` | string | KPI identifier |
| `kpi_name` | string | Human-readable name |
| `kpi_category` | string | `FINANCIAL` \| `OPERATIONAL` \| `QUALITY` \| `DELIVERY` |
| `display_format` | string | `NUMBER` \| `PERCENTAGE` \| `CURRENCY` \| `DAYS` |
| `unit_symbol` | string \| null | e.g. `$`, `%`, `days` |
| `geo_id` | string | Geography identifier |
| `geo_name` | string | Geography display name |
| `geo_level` | string | `OVERALL` \| `REGION` \| `AREA` \| `MARKET` |
| `current_value` | number \| null | Raw numeric value (latest date) |
| `current_value_formatted` | string | Pre-formatted string (e.g. `"$1,500,000.00"`) |
| `previous_period_value` | number \| null | Prior period raw value |
| `period_change_pct` | number \| null | % change from previous period |
| `trend` | string | `UP` \| `DOWN` \| `NEUTRAL` |
| `time_series` | object[] | Array of daily values, newest first (see below) |

### `time_series` item

| Field | Type | Description |
|---|---|---|
| `date` | string (YYYY-MM-DD) | Calculation date |
| `value` | number | Raw KPI value |
| `formatted` | string | Formatted display string |
| `period_change_pct` | number \| null | Day-on-day change % |
| `year_change_pct` | number \| null | Year-on-year change % |

---

## 10. Environment Configuration

The API is configured via a `.env` file. The following variables are relevant to integration teams:

| Variable | Default | Description |
|---|---|---|
| `DATABASE_URL` | — | PostgreSQL connection string (`postgresql://user:pass@host/db`) |
| `SECRET_KEY` | — | Application secret (not used by API clients) |
| `ALLOWED_API_KEYS` | `[]` | Comma-separated list of valid API keys |
| `API_KEY_HEADER` | `X-API-Key` | Header name for authentication |
| `DB_SCHEMA` | `pwc_derived_tables_schema` | PostgreSQL schema containing all tables |
| `ARCHIVAL_RETENTION_DAYS` | `90` | Days of data kept in the live table before archival |
| `MAX_CONCURRENT_KPI_QUERIES` | `10` | Semaphore limit for concurrent KPI calculations |
| `CALCULATION_TIMEOUT_SECONDS` | `300` | Per-calculation timeout |
| `CORS_ORIGINS` | `["*"]` | Allowed CORS origins |
| `LOG_LEVEL` | `INFO` | Logging verbosity |

**Table name overrides** (if the schema changes without renaming):

| Variable | Default table name |
|---|---|
| `TABLE_KPI_MASTER` | `homepage_kpi_master` |
| `TABLE_KPI_VALUES_LIVE` | `kpi_values_live` |
| `TABLE_KPI_VALUES_HISTORICAL` | `kpi_values_historical` |
| `TABLE_CALCULATION_JOBS` | `kpi_calculation_jobs` |
| `TABLE_DIM_GEOGRAPHY` | `dim_geography` |

---

## 11. KPI SQL Template Contract

> **For backend / data engineering teams** adding new KPIs. Node.js teams do not need to write SQL templates.

Every KPI stored in the master table has a `sql_query_template` field. The engine executes this template and passes the following bind parameters:

| Parameter | Type | Description |
|---|---|---|
| `:start_date` | date | Period start (for aggregation window) |
| `:end_date` | date | Period end (matches `calculation_date`) |
| `:geo_level` | string | `OVERALL` / `REGION` / `AREA` / `MARKET` |
| `:geo_code` | string | Natural key of the current geography (UPPER-CASE, matches source data) |
| `:region_code` | string \| NULL | `geo_code` of the parent region |
| `:area_code` | string \| NULL | `geo_code` of the parent area |
| `:geo_id` | string | Surrogate key of the current geography (rarely needed) |
| `:region_id` | string \| NULL | Surrogate key of the parent region |
| `:area_id` | string \| NULL | Surrogate key of the parent area |

**The template MUST return exactly one row with two columns:**

| Column | Type | Description |
|---|---|---|
| `kpi_value` | NUMERIC | The calculated KPI value |
| `record_count` | INTEGER | Number of source records contributing to the value |

**Minimal template example:**
```sql
SELECT
    SUM(revenue)   AS kpi_value,
    COUNT(*)       AS record_count
FROM sales_fact
WHERE
    transaction_date BETWEEN :start_date AND :end_date
    AND market_code = :geo_code
```

**Multi-level template example (handles all geo levels):**
```sql
SELECT
    SUM(revenue)   AS kpi_value,
    COUNT(*)       AS record_count
FROM sales_fact
WHERE
    transaction_date BETWEEN :start_date AND :end_date
    AND CASE :geo_level
            WHEN 'OVERALL' THEN TRUE
            WHEN 'REGION'  THEN region_code = :region_code
            WHEN 'AREA'    THEN area_code   = :area_code
            WHEN 'MARKET'  THEN market_code = :geo_code
        END
```

The `applicable_geo_levels` array on the KPI definition controls which levels this template is executed against. Levels not listed are skipped.

---

## Quick Reference Card

```
Authentication
  Header: X-API-Key: <your-key>
  Rate limit: 100 req/min

Trigger refresh (fire-and-forget → HTTP 202)
  POST /api/v1/calculation/trigger             body: { job_type, kpi_ids?, geo_ids?, calculation_date? }
  POST /api/v1/calculation/full-refresh        ?calculation_date=YYYY-MM-DD
  POST /api/v1/calculation/batch-refresh/markets
  POST /api/v1/calculation/batch-refresh/areas

Poll job status
  GET  /api/v1/calculation/jobs/{job_id}
  GET  /api/v1/calculation/jobs?status=RUNNING&limit=10

Dashboard data (read-only, fast)
  GET  /api/v1/dashboard/kpis
       ?geo_ids=GEO_R001&date_from=2024-01-01&date_to=2024-01-15
  GET  /api/v1/dashboard/kpi/{kpi_id}/drilldown?parent_geo_id=GEO_R001
  GET  /api/v1/dashboard/geography/tree
  GET  /api/v1/dashboard/kpi/definitions?category=FINANCIAL

Health (no auth)
  GET  /health
  GET  /health/db

Manual archive (rarely needed)
  POST /api/v1/calculation/archive

Interactive docs
  GET  /docs      (Swagger UI)
  GET  /redoc     (ReDoc)
  GET  /scalar    (Scalar UI)
```
