# KPI Dashboard API — Frontend Integration Guide

## Contents

1. [Base URL & Authentication](#1-base-url--authentication)
2. [Common Conventions](#2-common-conventions)
3. [Health Endpoints](#3-health-endpoints)
4. [Dashboard Endpoints](#4-dashboard-endpoints)
5. [Calculation / Refresh Endpoints](#5-calculation--refresh-endpoints)
6. [Job Polling Pattern](#6-job-polling-pattern)
7. [KPI Builder Endpoints](#7-kpi-builder-endpoints)
8. [Response Schemas](#8-response-schemas)
9. [Enum Reference](#9-enum-reference)
10. [Error Handling](#10-error-handling)

---

## 1. Base URL & Authentication

```
Base URL: http://<host>:8180
```

All endpoints (except `/health` and `/api/v1/kpi-builder/form`) require an API key sent in the request header:

```
X-API-Key: <your-api-key>
```

**Example (fetch):**
```js
const headers = {
  'Content-Type': 'application/json',
  'X-API-Key': 'your-api-key-here',
};
```

If authentication is disabled on the server, the header can be omitted entirely.

---

## 2. Common Conventions

| Convention | Detail |
|---|---|
| Dates | `YYYY-MM-DD` string (e.g. `"2024-03-01"`) |
| Comma-separated list params | `"GEO_R001,GEO_M001"` — split on comma server-side |
| Fire-and-forget endpoints | Return **HTTP 202** immediately; use the returned `job_id` to poll for completion |
| All timestamps | ISO-8601 string, e.g. `"2024-03-01T12:00:00.000"` |
| Null vs absent | Optional fields return `null` when not set |

---

## 3. Health Endpoints

### `GET /health`

No authentication required. Use for load-balancer or readiness probes.

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2024-03-01T12:00:00.000",
  "app": {
    "name": "KPI Dashboard API",
    "version": "1.0.0",
    "debug": false
  },
  "database": {
    "status": "healthy",
    "pool_size": 20
  },
  "system": {
    "cpu_percent": 12.5,
    "memory_percent": 45.2,
    "memory_available_gb": 6.3,
    "disk_percent": 60.1,
    "disk_free_gb": 120.4
  }
}
```

`status` is either `"healthy"` or `"degraded"`.

---

### `GET /health/db`

Detailed database connectivity check with query latency.

**Response:**
```json
{
  "status": "healthy",
  "query_time_ms": 3.21,
  "total_kpis": 42,
  "connection_pool": {
    "size": 20,
    "max_overflow": 10
  }
}
```

---

## 4. Dashboard Endpoints

These are the primary endpoints for rendering the dashboard UI.

---

### `GET /api/v1/dashboard/kpis`

Fetch pre-calculated KPI values with flexible filtering. This is the main endpoint for populating KPI cards, charts, and tables.

**Query Parameters:**

| Parameter | Type | Required | Description |
|---|---|---|---|
| `user_id` | string | No | User ID for persona-based defaults |
| `project_ids` | string | No | Comma-separated project IDs |
| `team_ids` | string | No | Comma-separated team IDs |
| `function_ids` | string | No | Comma-separated function IDs |
| `geo_ids` | string | No | Comma-separated geography IDs (e.g. `"GEO_R001,GEO_M001"`) |
| `geo_level` | string | No | Filter by level: `OVERALL` \| `REGION` \| `AREA` \| `MARKET` |
| `kpi_ids` | string | No | Comma-separated KPI IDs |
| `kpi_category` | string | No | `FINANCIAL` \| `OPERATIONAL` \| `QUALITY` \| `DELIVERY` |
| `date_from` | date | No | Start date `YYYY-MM-DD` (default: 30 days ago) |
| `date_to` | date | No | End date `YYYY-MM-DD` (default: today) |

**Example request:**
```
GET /api/v1/dashboard/kpis?geo_level=MARKET&kpi_category=FINANCIAL&date_from=2024-01-01&date_to=2024-01-31
```

**Response:**
```json
{
  "query_params": {
    "geo_level": "MARKET",
    "kpi_category": "FINANCIAL",
    "date_from": "2024-01-01",
    "date_to": "2024-01-31"
  },
  "total_kpis": 2,
  "query_timestamp": "2024-03-01T12:00:00.000",
  "kpis": [
    {
      "kpi_id": "KPI_TOTAL_REVENUE",
      "kpi_name": "Total Revenue",
      "kpi_category": "FINANCIAL",
      "display_format": "CURRENCY",
      "unit_symbol": "$",
      "geo_id": "GEO_M001",
      "geo_name": "US West",
      "geo_level": "MARKET",
      "current_value": 1500000.00,
      "current_value_formatted": "$1,500,000.00",
      "previous_period_value": 1425000.00,
      "period_change_pct": 5.26,
      "trend": "UP",
      "time_series": [
        { "date": "2024-01-01", "value": 1500000.00, "formatted": "$1,500,000.00" }
      ]
    }
  ]
}
```

**`trend` values:** `"UP"` | `"DOWN"` | `"NEUTRAL"`

---

### `GET /api/v1/dashboard/kpi/{kpi_id}/drilldown`

Drill down from a parent geography into its children. For example: REGION → all AREAs, or AREA → all MARKETs.

**Path parameter:** `kpi_id` — e.g. `KPI_TOTAL_REVENUE`

**Query Parameters:**

| Parameter | Type | Required | Description |
|---|---|---|---|
| `parent_geo_id` | string | **Yes** | Geography ID to drill into (e.g. `"GEO_R001"`) |
| `calculation_date` | date | No | Date for values (default: today) |

**Example request:**
```
GET /api/v1/dashboard/kpi/KPI_TOTAL_REVENUE/drilldown?parent_geo_id=GEO_R001
```

**Response:**
```json
{
  "kpi_id": "KPI_TOTAL_REVENUE",
  "parent_geo_id": "GEO_R001",
  "calculation_date": "2024-03-01",
  "total_children": 3,
  "drilldown": [
    {
      "geo_id": "GEO_A001",
      "geo_name": "North Area",
      "geo_level": "AREA",
      "kpi_value": 500000.00,
      "kpi_value_formatted": "$500,000.00",
      "period_on_period_change_pct": 3.1
    }
  ]
}
```

---

### `GET /api/v1/dashboard/geography/tree`

Returns the complete geography hierarchy as a nested tree. Use this to populate the geography filter/navigation dropdown.

**Response:**
```json
{
  "total_geographies": 50,
  "tree": [
    {
      "geo_id": "GEO_OVERALL",
      "geo_code": "OVERALL",
      "geo_name": "Global",
      "geo_level": "OVERALL",
      "parent_geo_id": null,
      "display_order": 1,
      "children": [
        {
          "geo_id": "GEO_R001",
          "geo_code": "APAC",
          "geo_name": "Asia Pacific",
          "geo_level": "REGION",
          "parent_geo_id": "GEO_OVERALL",
          "display_order": 1,
          "children": [
            {
              "geo_id": "GEO_A001",
              "geo_code": "INDIA",
              "geo_name": "India",
              "geo_level": "AREA",
              "children": [ ... ]
            }
          ]
        }
      ]
    }
  ]
}
```

---

### `GET /api/v1/dashboard/kpi/definitions`

Retrieve KPI metadata (name, category, display format, etc.) — useful for building filter dropdowns or a KPI catalogue page.

**Query Parameters:**

| Parameter | Type | Required | Description |
|---|---|---|---|
| `category` | string | No | `FINANCIAL` \| `OPERATIONAL` \| `QUALITY` \| `DELIVERY` |
| `project_id` | string | No | Filter KPIs that belong to a project |
| `team_id` | string | No | Filter KPIs that belong to a team |

**Response:**
```json
{
  "total_kpis": 10,
  "kpis": [
    {
      "kpi_id": "KPI_TOTAL_REVENUE",
      "kpi_code": "TOTAL_REVENUE",
      "kpi_name": "Total Revenue",
      "kpi_description": "Total revenue generated in the period.",
      "kpi_category": "FINANCIAL",
      "display_format": "CURRENCY",
      "unit_symbol": "$",
      "decimal_places": 2,
      "applicable_geo_levels": ["OVERALL", "REGION", "AREA", "MARKET"],
      "priority": 10,
      "is_active": true
    }
  ]
}
```

---

## 5. Calculation / Refresh Endpoints

These endpoints trigger background recalculation of KPI values. They all return **HTTP 202** immediately — use [job polling](#6-job-polling-pattern) to track completion.

> **Note:** After each refresh, old KPI values are automatically archived to the historical table.

---

### `POST /api/v1/calculation/trigger`

Trigger a targeted calculation job.

**Request body:**
```json
{
  "job_type": "SINGLE_KPI",
  "kpi_ids": ["KPI_TOTAL_REVENUE", "KPI_ORDER_COUNT"],
  "geo_ids": ["GEO_M001", "GEO_M002"],
  "calculation_date": "2024-03-01"
}
```

| Field | Type | Required | Description |
|---|---|---|---|
| `job_type` | string | No | Default: `INCREMENTAL`. See [JobType enum](#jobtype) |
| `kpi_ids` | string[] | No | `null` = all KPIs |
| `geo_ids` | string[] | No | `null` = all geographies |
| `calculation_date` | date | No | Default: today |

**Response:** `CalculationJobResponse` (HTTP 202) — see [schema](#calculationjobresponse).

---

### `POST /api/v1/calculation/full-refresh`

Recalculate all active KPIs across all geographies.

**Query parameter:** `calculation_date` (optional, default: today)

**Response:** `CalculationJobResponse` (HTTP 202)

---

### `POST /api/v1/calculation/batch-refresh/markets`

Recalculate all KPIs for every active **MARKET** geography only.

**Query parameter:** `calculation_date` (optional, default: today)

**Response:** `CalculationJobResponse` (HTTP 202)

---

### `POST /api/v1/calculation/batch-refresh/areas`

Recalculate all KPIs for every active **AREA** geography only.

**Query parameter:** `calculation_date` (optional, default: today)

**Response:** `CalculationJobResponse` (HTTP 202)

---

### `POST /api/v1/calculation/archive`

Manually move KPI values older than the retention window from the live table to historical.

> Archival runs automatically after every refresh job, so this endpoint is rarely needed.

**Response:**
```json
{
  "status": "SUCCESS",
  "message": "Archived 1200 records",
  "details": { "records_archived": 1200 }
}
```

---

### `GET /api/v1/calculation/jobs`

List recent calculation jobs.

**Query parameters:**

| Parameter | Type | Description |
|---|---|---|
| `status` | string | Optional filter: `PENDING` \| `RUNNING` \| `COMPLETED` \| `FAILED` |
| `limit` | int | Max results (default: 50) |

**Response:** Array of `CalculationJobResponse`

---

### `GET /api/v1/calculation/jobs/{job_id}`

Get status of a specific job. Use this to poll after triggering a refresh.

**Response:** `CalculationJobResponse`

---

## 6. Job Polling Pattern

All refresh endpoints are fire-and-forget (HTTP 202). Use this pattern to wait for completion:

```js
async function triggerAndWait(endpoint, body = null) {
  // 1. Trigger
  const res = await fetch(`${BASE_URL}${endpoint}`, {
    method: 'POST',
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  const job = await res.json();  // status: "RUNNING"

  // 2. Poll until done
  while (true) {
    await new Promise(r => setTimeout(r, 3000)); // wait 3s
    const poll = await fetch(`${BASE_URL}/api/v1/calculation/jobs/${job.job_id}`, { headers });
    const status = await poll.json();

    if (status.status === 'COMPLETED') return status;
    if (status.status === 'FAILED')    throw new Error(status.error_message);
  }
}

// Usage
const result = await triggerAndWait('/api/v1/calculation/batch-refresh/markets');
console.log(`Done: ${result.calculations_completed} KPIs calculated`);
```

`status` values: `PENDING` → `RUNNING` → `COMPLETED` | `FAILED`

---

## 7. KPI Builder Endpoints

Developer tool for creating new KPIs using an LLM. Not typically used in the end-user dashboard UI.

### `GET /api/v1/kpi-builder/form`

Opens a browser-based wizard for creating KPIs. No authentication required. Navigate to this URL directly in a browser.

---

### `POST /api/v1/kpi-builder/generate`

Ask the LLM to transform a raw SQL query into a KPI template.

**Request body:**
```json
{
  "kpi_name": "Total Revenue",
  "kpi_category": "FINANCIAL",
  "raw_sql": "SELECT SUM(revenue) AS val, COUNT(*) AS cnt FROM sales_fact WHERE market_code = 'US_WEST' AND txn_date BETWEEN '2024-01-01' AND '2024-01-31'",
  "time_column": "txn_date",
  "market_column": "market_code",
  "applicable_geo_levels": ["MARKET", "AREA", "OVERALL"],
  "display_format": "CURRENCY",
  "unit_symbol": "$",
  "decimal_places": 2
}
```

`time_column`, `market_column`, `area_column`, `region_column` are all optional — omit if not applicable.

**Response:**
```json
{
  "proposed_kpi": {
    "kpi_id": "KPI_TOTAL_REVENUE",
    "kpi_code": "TOTAL_REVENUE",
    "kpi_description": "Total revenue generated by the market in the period.",
    "sql_query_template": "SELECT SUM(revenue) AS kpi_value, COUNT(*) AS record_count FROM sales_fact WHERE market_code = :geo_code AND txn_date BETWEEN :start_date AND :end_date",
    "kpi_category": "FINANCIAL",
    "applicable_geo_levels": ["MARKET", "AREA", "OVERALL"],
    "display_format": "CURRENCY",
    "unit_symbol": "$"
  },
  "llm_notes": "Replaced market_code = 'US_WEST' with :geo_code; replaced date literals with :start_date/:end_date; renamed columns.",
  "next_step": "Review proposed_kpi, adjust if needed, then POST /api/v1/kpi-builder/register"
}
```

---

### `POST /api/v1/kpi-builder/register`

Save the reviewed KPI definition to the database. Safe to re-run — re-posting with the same `kpi_id` updates the existing record.

**Request body:** the `proposed_kpi` object from `/generate`, optionally edited.

**Response (HTTP 201):**
```json
{
  "message": "KPI 'KPI_TOTAL_REVENUE' registered successfully",
  "kpi": { ...saved kpi_master row... },
  "next_step": "Trigger first calculation: POST /api/v1/calculation/trigger with body {\"job_type\": \"SINGLE_KPI\", \"kpi_ids\": [\"KPI_TOTAL_REVENUE\"]}"
}
```

---

### `GET /api/v1/kpi-builder/template-params`

Reference list of all bind parameters available inside a `sql_query_template`.

---

## 8. Response Schemas

### `DashboardKPIData`

```
kpi_id                  string    KPI identifier
kpi_name                string    Display name
kpi_category            string    FINANCIAL | OPERATIONAL | QUALITY | DELIVERY
display_format          string    NUMBER | CURRENCY | PERCENTAGE | DAYS
unit_symbol             string?   e.g. "$", "%", "days"

geo_id                  string    Geography surrogate key
geo_name                string    Geography display name
geo_level               string    OVERALL | REGION | AREA | MARKET

current_value           number?   Raw numeric value
current_value_formatted string    Pre-formatted string (e.g. "$1,500,000.00")
previous_period_value   number?   Value from previous period
period_change_pct       number?   % change vs previous period (positive = improvement)
trend                   string    "UP" | "DOWN" | "NEUTRAL"

time_series             array     [ { date, value, formatted } ]
```

---

### `CalculationJobResponse`

```
job_id                      string    Unique job identifier
job_type                    string    See JobType enum
status                      string    PENDING | RUNNING | COMPLETED | FAILED
calculation_date            date
kpi_ids                     string[]? null = all KPIs
geo_ids                     string[]? null = all geographies
started_at                  datetime?
completed_at                datetime?
duration_seconds            int?
total_calculations_planned  int?      KPIs × geographies
calculations_completed      int
calculations_failed         int
error_message               string?   Populated on FAILED
triggered_by                string
created_at                  datetime
```

---

## 9. Enum Reference

### `GeoLevel`
| Value | Description |
|---|---|
| `OVERALL` | Global aggregate |
| `REGION` | Top-level region (e.g. APAC, EMEA) |
| `AREA` | Sub-region (e.g. India, Germany) |
| `MARKET` | Lowest-level market |

### `KPICategory`
`FINANCIAL` | `OPERATIONAL` | `QUALITY` | `DELIVERY`

### `DisplayFormat`
| Value | Example output |
|---|---|
| `NUMBER` | `1,234,567` |
| `CURRENCY` | `$1,234,567.00` |
| `PERCENTAGE` | `12.34%` |
| `DAYS` | `14.5 days` |

### `JobType`
| Value | Description |
|---|---|
| `FULL_REFRESH` | All KPIs, all geographies |
| `INCREMENTAL` | Changed data only |
| `SINGLE_KPI` | Specific KPIs, optionally specific geos |
| `SINGLE_GEO` | All KPIs for specific geographies |
| `BATCH_MARKET_REFRESH` | All KPIs for all MARKET geos |
| `BATCH_AREA_REFRESH` | All KPIs for all AREA geos |

### `JobStatus`
`PENDING` → `RUNNING` → `COMPLETED` | `FAILED` | `CANCELLED`

---

## 10. Error Handling

All errors follow this structure:

```json
{
  "detail": "Human-readable error message"
}
```

| HTTP Status | Meaning |
|---|---|
| `400` | Bad request / validation error |
| `401` | Missing API key |
| `403` | Invalid API key |
| `404` | Resource not found |
| `202` | Job accepted (fire-and-forget — not an error) |
| `500` | Internal server error |
| `502` | LLM gateway error (KPI Builder only) |

**Recommended error handler:**
```js
async function apiFetch(path, method = 'GET', body = null) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.detail || `HTTP ${res.status}`);
  }

  return res.json();
}
```
