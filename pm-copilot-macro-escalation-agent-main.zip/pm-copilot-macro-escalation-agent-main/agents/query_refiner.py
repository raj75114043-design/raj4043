
# Query Refiner Agent — Human-in-the-Loop node for the Escalation Agent.

# Analyses the user's raw query for completeness (required scope params present?).
# If the query is under-specified, the node suspends the graph via LangGraph's
# interrupt() mechanism and waits for the user to supply clarification.
from __future__ import annotations

import json
from loguru import logger
from typing import Any

from langchain_core.messages import SystemMessage, HumanMessage
from langgraph.types import interrupt

from models.state import EscalationState
from services.llm_provider import LLMProvider
from prompts.query_refiner_prompt import QUERY_REFINER_SYSTEM


_CYAN = "\033[96m"
_GREEN = "\033[92m"
_YELLOW = "\033[93m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_RESET = "\033[0m"


def _parse_refiner_response(content: str) -> dict:
    try:
        clean = content.strip()
        if clean.startswith("```"):
            clean = clean.split("```")[1]
            if clean.startswith("json"):
                clean = clean[4:]
        return json.loads(clean.strip())
    except (json.JSONDecodeError, IndexError):
        logger.warning("Query refiner LLM returned non-JSON; treating query as complete.")
        return {
            "is_complete": True,
            "clarification_questions": [],
            "assumptions": [],
            "refined_query": "",
        }


def query_refiner_node(state: EscalationState) -> dict[str, Any]:
    """
    LangGraph node: Query Refiner Agent (Human-in-the-Loop).

    Reads:  user_query
    Writes: refined_query, current_phase, messages
    May interrupt the graph to ask clarifying questions.
    """
    user_query = state.get("user_query", "")
    conversation_history = state.get("conversation_history", "")

    if not user_query:
        logger.error("QueryRefiner | user_query missing from state — checkpoint may have been lost")
        return {
            "refined_query": "",
            "current_phase": "error",
            "errors": ["Session expired or checkpoint lost. Please resend your query."],
            "messages": [{
                "agent": "query_refiner",
                "content": "Error: user_query not found in state. The session checkpoint may have been lost (server restart?).",
            }],
        }

    print(f"\n{_BOLD}{'=' * 70}")
    print(f"  QUERY REFINER — Evaluating query completeness")
    print(f"{'=' * 70}{_RESET}\n")
    print(f"  {_DIM}Query: {user_query}{_RESET}")
    if conversation_history:
        print(f"  {_DIM}History: {len(conversation_history.splitlines())} lines{_RESET}")
    print()

    provider = LLMProvider(model="gpt-5-mini")
    llm = provider.get_llm()

    # Build user message with conversation history for context
    user_content = user_query
    if conversation_history:
        user_content = (
            f"## Conversation History (prior turns in this session)\n"
            f"{conversation_history}\n\n"
            f"## Current Query\n{user_query}"
        )

    logger.debug("QueryRefiner | invoking LLM | query={!r}", user_query[:120])
    response = llm.invoke([
        SystemMessage(content=QUERY_REFINER_SYSTEM),
        HumanMessage(content=user_content),
    ])
    logger.debug("QueryRefiner | LLM raw response: {}", response.content[:500])

    parsed = _parse_refiner_response(response.content)
    is_complete: bool = parsed.get("is_complete", True)
    clarification_questions: list[str] = parsed.get("clarification_questions", [])
    assumptions: list[str] = parsed.get("assumptions", [])
    refined_query: str = parsed.get("refined_query", user_query) or user_query

    logger.info(
        "QueryRefiner | complete={} | questions={} | assumptions={} | refined={!r}",
        is_complete, len(clarification_questions), len(assumptions), refined_query[:120],
    )

    if assumptions:
        print(f"  {_DIM}Assumptions: {' | '.join(assumptions)}{_RESET}")

    if is_complete:
        print(f"  {_GREEN}OK Query is complete — proceeding to orchestrator.{_RESET}\n")
        return {
            "refined_query": refined_query,
            "current_phase": "orchestration",
            "messages": [{
                "agent": "query_refiner",
                "content": f"Query accepted as complete. Refined: {refined_query}",
            }],
        }

    # ── Query is incomplete → ask the user for clarification ──
    print(f"  {_YELLOW}Query needs clarification:{_RESET}")
    for q in clarification_questions:
        print(f"     - {q}")
    print()

    clarification_prompt = {
        "type": "clarification_needed",
        "original_query": user_query,
        "questions": clarification_questions,
        "assumptions_if_skipped": assumptions,
        "message": (
            "Your query needs a bit more detail to run a precise escalation investigation. "
            "Please answer the questions below (or press Enter to accept assumptions):"
        ),
    }

    user_clarification: str = interrupt(clarification_prompt)

    if user_clarification and user_clarification.strip():
        refined_query = (
            f"{user_query} — Additional context: {user_clarification.strip()}"
        )
        print(f"  {_GREEN}OK Clarification received. Refined query:{_RESET}")
        print(f"     {refined_query}\n")
    else:
        refined_query = refined_query or user_query
        print(f"  {_DIM}No clarification provided — proceeding with assumptions.{_RESET}\n")

    return {
        "refined_query": refined_query,
        "current_phase": "orchestration",
        "messages": [{
            "agent": "query_refiner",
            "content": f"Query refined after clarification. Final: {refined_query}",
        }],
    }