# Escalation Lookup Agent — Replaces the Planner Agent.

# Workflow:
#   1. Perform similarity search against semantic_escalation table to find
#      the best-matching escalation scenario for the user query.
#   2. Extract recommended_resolution steps as investigation sub-queries.
#   3. Use LLM to enrich terse steps into specific, data-focused sub-queries
#      grounded in the user's actual query and escalation context.
#   4. Execute each enriched step via the Traversal Agent concurrently (parallel).
#   5. Accumulate all traversal results and pass them to the Response Agent.
from __future__ import annotations

import asyncio
import json
import re
import warnings
from concurrent.futures import ThreadPoolExecutor
from typing import Any, List

from langchain_core.messages import SystemMessage, HumanMessage
from loguru import logger

from agents.traversal import atraversal_node
from models.state import EscalationState
from services.llm_provider import LLMProvider
from services.scenario_service import find_matching_scenario

_CYAN = "\033[96m"
_GREEN = "\033[92m"
_YELLOW = "\033[93m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_RESET = "\033[0m"

_MAX_PARALLEL_STEPS = 7
_STEP_MAX_TRAVERSAL_STEPS = 20
_STEP_TIMEOUT_SEC = 300


def _parse_resolution_steps(resolution_text: str | None | List) -> list[str]:
    """
    Parse the recommended_resolution text into individual investigation steps.
    Each numbered line or semicolon-separated item becomes a step.
    """
    if not resolution_text:
        return []

    steps = []
    # Split by newlines first, then by numbered patterns
    if isinstance(resolution_text, str):
        lines = resolution_text.replace("\r\n", "\n").split("\n")
    elif isinstance(resolution_text, list):
        lines = resolution_text
    else:
        lines = [str(resolution_text)]
    for line in lines:
        line = line.strip()
        if not line:
            continue
        # Remove leading numbering like "1.", "2)", "1 -", etc.
        cleaned = re.sub(r"^\d+[\.\)\-\s]+", "", line).strip()
        if cleaned:
            steps.append(cleaned)

    # If no newline-based steps found, try semicolon splitting (string input only)
    if not steps and isinstance(resolution_text, str) and ";" in resolution_text:
        parts = resolution_text.split(";")
        for part in parts:
            part = part.strip()
            if part:
                steps.append(part)

    # If still nothing, use the whole text as a single step
    if not steps:
        fallback = resolution_text.strip() if isinstance(resolution_text, str) else ""
        if fallback:
            steps = [fallback]

    return steps


_STEP_ENRICHMENT_PROMPT = """
You are a data investigation planner for a telecom escalation system.

You receive:
- The PM's original escalation query
- A matched escalation scenario (type, description, probable reasons, relevant KPIs)
- A list of terse resolution steps extracted from the scenario

Your job: rewrite each step into a **clear, actionable investigation sub-query** that a
data retrieval agent can execute against a knowledge graph and PostgreSQL database.

## CRITICAL SCOPE RULES — DO NOT VIOLATE

1. **ONLY use information the user actually provided.** those are your ONLY scope filters.
    Do NOT invent timeframes, regions, markets, vendors, or breakdowns the user never asked for.
2. **Do NOT expand scope beyond the original step's intent.** If the step says
   "Identify delay pattern", ask about delay patterns — do NOT add "by tool type",
   "by time of day", "by shift" unless the user or the step explicitly mentions those.
3. **Do NOT hallucinate dimensions.** Only break down by dimensions that are either:
   (a) explicitly mentioned by the user, or (b) directly named in the step itself, or
   (c) listed in the Relevant KPIs.
4. **Keep it concise** — one sentence per step is ideal, two max. Do not over-elaborate.

## WHAT TO DO

- Make the step self-contained so the traversal agent understands WHAT data to fetch.
- Carry forward the user's exact scope (region, market, timeframe, entity) into each step.
- If the step is vague (e.g., "Daily monitoring"), rewrite it to ask for the specific
  metric mentioned in the scenario's Relevant KPIs.
- Preserve the original step's intent — just make it specific enough to query data.

## OUTPUT

Keep the same number of steps — do not add or remove steps.
Respond with ONLY a JSON array of strings — no markdown fences, no extra text.
Example: ["Sub-query 1: ...", "Sub-query 2: ..."]
"""


def _enrich_steps_with_llm(
        raw_steps: list[str],
        user_query: str,
        scenario: dict,
) -> list[str]:
    """
    Use an LLM to expand terse resolution steps into specific, data-focused
    sub-queries grounded in the user's actual query.
    """
    provider = LLMProvider(model="gpt-5-mini")
    llm = provider.get_llm()

    human_content = (
        f"## User's Escalation Query\n{user_query}\n\n"
        f"## Matched Escalation Scenario\n"
        f"- Type: {scenario.get('escalation_type', 'N/A')}\n"
        f"- Description: {scenario.get('escalation_description', 'N/A')}\n"
        f"- Probable Reasons: {scenario.get('probable_reasons', 'N/A')}\n"
        f"- Relevant KPIs: {scenario.get('relevent_kpi_s', 'N/A')}\n\n"
        f"## Raw Resolution Steps to Enrich\n"
    )
    for i, step in enumerate(raw_steps, 1):
        human_content += f"{i}. {step}\n"

    try:
        response = llm.invoke([
            SystemMessage(content=_STEP_ENRICHMENT_PROMPT),
            HumanMessage(content=human_content),
        ])

        content = response.content.strip()
        # Strip markdown fences if present
        if content.startswith("```"):
            content = content.split("```")[1]
            if content.startswith("json"):
                content = content[4:]
        enriched = json.loads(content.strip())

        if isinstance(enriched, list) and len(enriched) == len(raw_steps):
            return [str(s) for s in enriched]

        logger.warning(
            "LLM returned {} enriched steps vs {} raw steps; falling back to raw.",
            len(enriched) if isinstance(enriched, list) else 0,
            len(raw_steps),
        )
    except Exception as e:
        logger.warning("Step enrichment failed (non-fatal, using raw steps): {}", e)

    return raw_steps


async def _run_traversal_step_async(
        step_query: str,
        base_state: EscalationState,
        step_idx: int,
        max_steps: int = _STEP_MAX_TRAVERSAL_STEPS,
) -> dict:
    """Run a single traversal step asynchronously."""
    warnings.filterwarnings("ignore", message=".*pandas only supports SQLAlchemy.*")
    step_state: EscalationState = {
        **base_state,
        "user_query": step_query,
        "max_traversal_steps": max_steps,
    }
    try:
        return await atraversal_node(step_state)
    except Exception as e:
        logger.error(
            "Traversal step %d failed for query '%s': %s",
            step_idx + 1, step_query[:80], e,
        )
        return {
            "traversal_findings": f"Step failed: {e}",
            "traversal_tool_calls": [],
            "traversal_steps_taken": 0,
            "errors": [f"Traversal step error: {e}"],
        }


async def _gather_traversals(steps: list[str], state: EscalationState) -> list:
    """Execute all traversal steps concurrently."""
    tasks = [
        asyncio.wait_for(
            _run_traversal_step_async(step, state, idx),
            timeout=float(_STEP_TIMEOUT_SEC),
        )
        for idx, step in enumerate(steps)
    ]
    return await asyncio.gather(*tasks, return_exceptions=True)


def escalation_lookup_node(state: EscalationState) -> dict[str, Any]:
    """
    LangGraph node: Escalation Lookup + Parallel Traversal.

    Reads:  refined_query, kg_schema, max_traversal_steps
    Writes: escalation_type, escalation_description, probable_reasons,
            recommended_resolution, expected_agent_output,
            draft_escalation_message_template, relevant_kpis,
            escalation_vertical, escalation_similarity_score,
            escalation_steps, escalation_step_results,
            current_phase, messages
    """
    refined_query = state.get("refined_query") or state["user_query"]

    print(f"\n{_BOLD}{'=' * 70}")
    print(f"  ESCALATION LOOKUP — Finding matching escalation scenario")
    print(f"{'=' * 70}{_RESET}\n")
    print(f"  {_DIM}Query: {refined_query}{_RESET}\n")

    # ── Step 1: Similarity search against semantic_escalation table ──
    logger.info(f"EscalationLookup | starting similarity search | query={refined_query}")
    matches = find_matching_scenario(refined_query, top_k=1)

    if not matches:
        logger.warning("EscalationLookup | no matching scenario found, using query as single step")
        print(f"  {_YELLOW}No matching escalation scenario found. Using query as single step.{_RESET}\n")
        return {
            "escalation_type": "Unknown",
            "escalation_description": "",
            "probable_reasons": "",
            "recommended_resolution": "",
            "expected_agent_output": "",
            "draft_escalation_message_template": "",
            "relevant_kpis": "",
            "escalation_vertical": "",
            "escalation_similarity_score": 0.0,
            "escalation_steps": [refined_query],
            "escalation_step_results": [],
            "current_phase": "response",
            "messages": [{
                "agent": "escalation_lookup",
                "content": "No matching scenario found. Proceeding with direct investigation.",
            }],
        }

    scenario = matches[0]
    similarity = scenario.get("similarity_score", 0)
    logger.info(
        "EscalationLookup | matched scenario | type={!r} | similarity={:.4f} | vertical={!r}",
        scenario.get("escalation_type", "N/A"), similarity, scenario.get("vertical", "N/A"),
    )
    logger.debug(
        "EscalationLookup | scenario details | description={!r} | kpis={!r} | resolution={!r}",
        str(scenario.get("escalation_description") or "")[:200],
        str(scenario.get("relevent_kpi_s") or "")[:200],
        str(scenario.get("recommended_resolution") or "")[:200],
    )

    print(f"  {_GREEN}Matched Scenario:{_RESET}")
    print(f"    Type: {scenario.get('escalation_type', 'N/A')}")
    print(f"    Similarity: {similarity:.2%}")
    print(f"    Description: {(scenario.get('escalation_description') or 'N/A')}")
    print(f"    Vertical: {scenario.get('vertical') or 'N/A'}")
    print()

    # ── Step 2: Extract and enrich investigation steps ──
    resolution_text = scenario.get("recommended_resolution") or ""
    raw_steps = _parse_resolution_steps(resolution_text)

    if not raw_steps:
        raw_steps = [refined_query]

    raw_steps = raw_steps[:_MAX_PARALLEL_STEPS]

    print(f"  {_DIM}Raw steps from scenario:{_RESET}")
    for i, step in enumerate(raw_steps, 1):
        print(f"    {_DIM}{i}. {step}{_RESET}")
    print()

    # Use LLM to expand terse steps into specific data-focused sub-queries
    logger.info("EscalationLookup | enriching {} raw steps via LLM", len(raw_steps))
    print(f"  {_BOLD}Enriching steps into data-focused sub-queries...{_RESET}")
    enriched_steps = _enrich_steps_with_llm(raw_steps, refined_query, scenario)
    logger.info("EscalationLookup | enrichment complete | {} enriched steps", len(enriched_steps))
    for i, step in enumerate(enriched_steps, 1):
        logger.debug("EscalationLookup | enriched step {} = {!r}", i, step[:200])

    print(f"\n  {_BOLD}Investigation Steps ({len(enriched_steps)} enriched sub-queries):{_RESET}")
    for i, step in enumerate(enriched_steps, 1):
        display = step
        if ": " in step:
            display = step.split(": ", 1)[1]
        print(f"    {_CYAN}Step {i}:{_RESET} {display}")
    print()

    # Keep raw steps for state (display), use enriched for traversal
    steps = raw_steps

    # ── Step 3: Execute each enriched step concurrently via traversal agent ──
    logger.info("EscalationLookup | launching {} parallel traversals", len(enriched_steps))
    print(f"  {_BOLD}Executing {len(enriched_steps)} traversal(s) in parallel...{_RESET}\n")

    with ThreadPoolExecutor(max_workers=1, thread_name_prefix="escalation-async") as executor:
        future = executor.submit(asyncio.run, _gather_traversals(enriched_steps, state))
        gathered = future.result(timeout=_STEP_TIMEOUT_SEC + 60)

    step_results: list[dict] = []
    for idx, result in enumerate(gathered):
        if isinstance(result, (asyncio.TimeoutError, TimeoutError)):
            logger.warning("Step {} timed out after {}s", idx + 1, _STEP_TIMEOUT_SEC)
            step_results.append({
                "traversal_findings": f"Step timed out after {_STEP_TIMEOUT_SEC}s",
                "traversal_tool_calls": [],
                "traversal_steps_taken": 0,
                "errors": [f"Step {idx + 1} timed out"],
            })
        elif isinstance(result, Exception):
            logger.error("Unexpected error in step {}: {}", idx + 1, result)
            step_results.append({
                "traversal_findings": f"Unexpected error: {result}",
                "traversal_tool_calls": [],
                "traversal_steps_taken": 0,
            })
        else:
            step_results.append(result)

    total_tool_calls = sum(
        r.get("traversal_steps_taken", 0) for r in step_results
    )
    print(f"\n  {_GREEN}All steps complete — {total_tool_calls} total tool calls{_RESET}\n")

    logger.info(
        "Escalation lookup completed: {} steps, {} total tool calls, similarity={:.4f}",
        len(steps), total_tool_calls, similarity,
    )

    def _str(val) -> str:
        """Coerce scenario field to string — some fields come back as lists."""
        if isinstance(val, list):
            return "; ".join(str(v) for v in val if v)
        return str(val).strip() if val else ""

    return {
        "escalation_type": _str(scenario.get("escalation_type")),
        "escalation_description": _str(scenario.get("escalation_description")),
        "probable_reasons": _str(scenario.get("probable_reasons")),
        "recommended_resolution": resolution_text,
        "expected_agent_output": _str(scenario.get("expected_agent_output")),
        "draft_escalation_message_template": _str(scenario.get("draft_escalation_message_template")),
        "relevant_kpis": _str(scenario.get("relevent_kpi_s")),
        "escalation_vertical": _str(scenario.get("vertical")),
        "escalation_similarity_score": similarity,
        "escalation_steps": steps[:_MAX_PARALLEL_STEPS],
        "escalation_step_results": step_results,
        "current_phase": "response",
        "messages": [{
            "agent": "escalation_lookup",
            "content": (
                f"Escalation scenario matched: '{scenario.get('escalation_type', 'Unknown')}' "
                f"(similarity: {similarity:.2%}). "
                f"{len(steps)} investigation steps executed in parallel, "
                f"{total_tool_calls} total traversal tool calls."
            ),
        }],
    }
