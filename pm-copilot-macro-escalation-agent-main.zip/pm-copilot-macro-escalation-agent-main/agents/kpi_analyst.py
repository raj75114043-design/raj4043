# KPI Analyst Agent — flat ReAct agent for escalation investigation.
#
# Flow:
#   1. User query -> main agent (SCOPE GUARD in prompt handles casual/vague).
#   2. Agent calls `search_kpis` to pick & score candidates (LLM matcher).
#   3. Agent calls `get_kpi_sqls` to pull pre-built SQL for the chosen KPIs
#      at the levels it inferred from the query scope.
#   4. Agent calls `batch_run_sqls` to execute all SQLs in parallel —
#      FULL rows returned, no truncation.
#   5. Agent writes the final report using the tabular results.
#
# Fallback tools (for KPIs without pre-built SQL, or ad-hoc drill-downs):
#   - `sql_query`     — raw SQL SELECT against Postgres
#   - `run_python`    — pandas post-processing
#   - `call_gcl`      — qualitative GCL context for Excel-sourced KPIs

from __future__ import annotations

import json
import re
import time
from datetime import date
from pathlib import Path
from typing import Any, Literal

import toons
from langchain.agents import create_agent
from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import SystemMessage, HumanMessage, ToolMessage
from loguru import logger

from models.state import EscalationState, ToolCallRecord, DrillDownLevel, AggregationSummary
from services.gcl_service import call_gcl
from services.kpi_bootstrap import (
    bootstrap_table_schemas as _bootstrap_table_schemas,
    bootstrap_kpi_embeddings as _bootstrap_kpi_embeddings,
    search_and_match_kpis,
)
from services.llm_provider import LLMProvider
from tools.langchain_tools import (
    run_python, _detect_aggregation,
    get_chart_data_store, clear_chart_data_store,
)
from tools.sql_query_tool import sql_query_tool
from tools.kpi_tools import search_kpis, get_kpi_sqls, batch_run_sqls
from tools.kpi_agg_catalog import available_levels as _agg_available_levels

# ── ANSI colors ──
_CYAN = "\033[96m"
_GREEN = "\033[92m"
_YELLOW = "\033[93m"
_RED = "\033[91m"
_DIM = "\033[2m"
_BOLD = "\033[1m"
_RESET = "\033[0m"

DEFAULT_MAX_STEPS = 25
_AGENT_MODEL = "gpt-5-mini"
_AGENT_TEMP = 0.1
_MAX_KPIS = 5

# Context window management
_KEEP_RECENT_PAIRS = 14
_SUMMARIZE_TOOL_CHARS = 600

# Escalation context fields extracted from EscalationState
_ESCALATION_CONTEXT_KEYS = (
    "escalation_type", "escalation_description", "probable_reasons",
    "recommended_resolution", "expected_agent_output",
    "draft_escalation_message_template", "relevant_kpis", "escalation_vertical",
)

# System prompt — loaded lazily to avoid import-time crash if file missing
_PROMPT_FILE = Path(__file__).resolve().parent.parent / "prompts" / "kpi_analyst_prompt.md"
_SYSTEM_PROMPT: str | None = None


def _get_system_prompt() -> str:
    global _SYSTEM_PROMPT
    if _SYSTEM_PROMPT is None:
        _SYSTEM_PROMPT = _PROMPT_FILE.read_text(encoding="utf-8")
    return _SYSTEM_PROMPT


def _parse_toon_or_json(raw: str) -> Any:
    try:
        return toons.loads(raw)
    except Exception:
        try:
            return json.loads(raw)
        except Exception:
            return None


# ─────────────────────────────────────────────────────────────────────
# Context trimmer middleware
# ─────────────────────────────────────────────────────────────────────

class ContextTrimmer(AgentMiddleware):
    """Summarize very old tool messages to keep the LLM context manageable.

    NEVER trims batch_run_sqls output — that's the data the report is built on.
    """

    _PROTECTED_TOOLS = {"batch_run_sqls"}

    def before_model(self, state, runtime):
        messages = state.get("messages", [])
        if len(messages) <= _KEEP_RECENT_PAIRS * 2 + 2:
            return None

        fixed = []
        conversation = []
        for msg in messages:
            if isinstance(msg, (SystemMessage, HumanMessage)) and not conversation:
                fixed.append(msg)
            else:
                conversation.append(msg)

        if len(conversation) <= _KEEP_RECENT_PAIRS * 2:
            return None

        cutoff = len(conversation) - _KEEP_RECENT_PAIRS * 2
        old = conversation[:cutoff]
        recent = conversation[cutoff:]

        trimmed_old = []
        for msg in old:
            if isinstance(msg, ToolMessage):
                if msg.name in self._PROTECTED_TOOLS:
                    trimmed_old.append(msg)
                    continue
                content = msg.content or ""
                if isinstance(content, list):
                    content = str(content)
                if len(content) > _SUMMARIZE_TOOL_CHARS:
                    if "error" in content.lower()[:200]:
                        trimmed_old.append(msg)
                    else:
                        short = content[:_SUMMARIZE_TOOL_CHARS] + f"... [{len(content)} chars total]"
                        trimmed_old.append(ToolMessage(
                            content=short,
                            tool_call_id=msg.tool_call_id,
                            name=msg.name,
                            id=msg.id,
                        ))
                else:
                    trimmed_old.append(msg)
            else:
                trimmed_old.append(msg)

        return {"messages": fixed + trimmed_old + recent}


# ─────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────

def _print_divider(char: str = "-", width: int = 70):
    print(f"{_DIM}{char * width}{_RESET}")


def _detect_tool_status(output: str) -> Literal["success", "error"]:
    parsed = _parse_toon_or_json(output)
    if isinstance(parsed, dict):
        if parsed.get("status") == "error":
            return "error"
        if "error" in parsed and "status" not in parsed:
            return "error"
        # batch_run_sqls shape: success if any result succeeded
        if "success_count" in parsed:
            return "success" if parsed.get("success_count", 0) > 0 else "error"
        return "success"
    if output and "error" in output.lower()[:200]:
        return "error"
    return "success"


def _extract_tool_output(raw_content) -> str:
    if isinstance(raw_content, list):
        return "\n".join(
            b.get("text", str(b)) if isinstance(b, dict) else str(b)
            for b in raw_content
        )
    return raw_content or ""


def _format_escalation_context(escalation_context: dict[str, str]) -> str:
    if not escalation_context or not any(escalation_context.values()):
        return "*No escalation scenario context provided — using query and vector search only.*"

    field_labels = [
        ("escalation_type", "Type"),
        ("escalation_description", "Description"),
        ("probable_reasons", "Probable Reasons"),
        ("recommended_resolution", "Recommended Resolution"),
        ("expected_agent_output", "Expected Agent Output"),
        ("relevant_kpis", "Relevant KPIs (from scenario)"),
        ("escalation_vertical", "Vertical"),
        ("draft_escalation_message_template", "Draft Escalation Message Template"),
    ]
    parts = []
    for key, label in field_labels:
        val = escalation_context.get(key, "")
        if isinstance(val, list):
            val = "; ".join(str(v) for v in val if v)
        val = str(val).strip() if val else ""
        if val:
            parts.append(f"**{label}**: {val}")
    return "\n".join(parts)


def _format_matched_kpis_slim(matched_kpis: list[dict]) -> str:
    """Slim KPI hint block — name, source, distance, vertical, description,
    and pre-built level availability. NO SQL text leaks into the prompt; the
    agent must call `get_kpi_sqls` to obtain SQL.
    """
    if not matched_kpis:
        return "*No KPIs matched — call `search_kpis` to discover candidates.*"

    lines: list[str] = []
    for m in matched_kpis:
        name = m.get("kpi_name", "")
        if not name:
            continue
        source = m.get("index", "") or m.get("source", "")
        distance = float(m.get("distance", 1.0))

        meta = m.get("metadata") or {}
        vertical = (meta.get("project_name") or "").strip()
        desc = (meta.get("description") or meta.get("kpi_description") or "").strip()
        if len(desc) > 140:
            desc = desc[:137] + "..."

        levels = _agg_available_levels(name)
        levels_text = ", ".join(levels) if levels else "none"

        parts = [
            f"`{name}`",
            f"source={source}",
            f"dist={distance:.4f}",
            f"prebuilt_levels=[{levels_text}]",
        ]
        if vertical:
            parts.append(f"vertical={vertical}")
        if desc:
            parts.append(f'desc="{desc}"')
        lines.append("- " + " | ".join(parts))
    return "\n".join(lines)


def _build_system_prompt(
        matched_kpis: list[dict] | None,
        escalation_context: dict[str, str],
        table_catalog: str,
) -> str:
    """Build the full system prompt with injected context."""
    kpis = matched_kpis or []
    matched_kpis_text = _format_matched_kpis_slim(kpis)


    escalation_text = _format_escalation_context(escalation_context)

    return (_get_system_prompt()
            .replace("{today_date}", date.today().isoformat())
            .replace("{escalation_context}", escalation_text)
            .replace("{matched_kpis}", matched_kpis_text)
            .replace("{table_catalog}", table_catalog))


def _print_ai_message(msg, step_num: int) -> int:
    """Print AI reasoning text + each tool call header. Returns updated step counter."""
    text = (getattr(msg, "content", "") or "").strip()
    if text:
        snippet = text if len(text) <= 500 else text[:500] + "..."
        logger.debug("KPIAnalyst | reasoning: {}", snippet)

    for tc in (getattr(msg, "tool_calls", None) or []):
        step_num += 1
        _print_divider()
        print(f"{_BOLD}{_CYAN}  Step {step_num}: {tc['name']}{_RESET}")
        for key, val in tc["args"].items():
            val_str = str(val)
            if len(val_str) > 200:
                val_str = val_str[:200] + "..."
            print(f"     {_DIM}{key}:{_RESET} {val_str}")
        logger.info("KPIAnalyst | step {} | tool={}", step_num, tc["name"])
    return step_num


def _print_tool_message(msg) -> None:
    output = _extract_tool_output(msg.content)
    status = _detect_tool_status(output)
    icon = "X" if status == "error" else "OK"
    color = _RED if status == "error" else _GREEN
    display = output[:300] + "..." if len(output) > 300 else output
    print(f"     {color}{icon}{_RESET} {display}")


def _process_messages(messages: list) -> dict:
    """Walk the agent message history and extract findings, tool calls, and
    SQL audit records. Pure data extraction — no console output (printing
    happens live during streaming via _print_ai_message / _print_tool_message).
    """
    step_num = 0
    findings_parts: list[str] = []
    tool_call_records: list[ToolCallRecord] = []
    errors: list[str] = []
    sql_queries: list[dict] = []
    pending: dict[str, dict] = {}

    for msg in messages:
        if msg.type == "ai":
            text = (getattr(msg, "content", "") or "").strip()
            if text:
                findings_parts.append(text)
            for tc in (getattr(msg, "tool_calls", None) or []):
                step_num += 1
                pending[tc["id"]] = {
                    "step": step_num,
                    "name": tc["name"],
                    "args": tc["args"],
                }

        elif msg.type == "tool":
            output = _extract_tool_output(msg.content)
            status = _detect_tool_status(output)

            call_info = pending.pop(
                getattr(msg, "tool_call_id", ""),
                {"step": step_num, "name": msg.name or "unknown", "args": {}},
            )
            tool_name = msg.name or call_info.get("name", "")

            tool_call_records.append(ToolCallRecord(
                tool_name=tool_name,
                tool_input=call_info.get("args", {}),
                tool_output=output[:5000],
                status=status,
                execution_time_ms=0,
            ))

            if status == "error":
                errors.append(f"Tool {tool_name}: {output[:200]}")

            if tool_name == "batch_run_sqls":
                for item in call_info.get("args", {}).get("items", []) or []:
                    sql_queries.append({
                        "step": call_info.get("step", step_num),
                        "tool": tool_name,
                        "kpi_name": item.get("kpi_name", ""),
                        "kpi_id": item.get("kpi_id"),
                        "level": item.get("level", ""),
                        "code": item.get("sql", ""),
                        "output_preview": output[:2000],
                        "has_aggregation": True,
                        "status": status,
                    })
            elif tool_name in ("sql_query", "run_sql_python", "run_python"):
                args = call_info.get("args", {})
                code = args.get("code") or args.get("query", "")
                is_agg = _detect_aggregation(code)
                preview_limit = 3000 if is_agg else 1000
                sql_queries.append({
                    "step": call_info.get("step", step_num),
                    "tool": tool_name,
                    "code": code,
                    "output_preview": output[:preview_limit],
                    "has_aggregation": is_agg,
                    "status": status,
                })

    return {
        "step_num": step_num,
        "findings_parts": findings_parts,
        "tool_call_records": tool_call_records,
        "errors": errors,
        "sql_queries": sql_queries,
    }


def _friendly_agent_error(exc: Exception) -> str:
    """Translate an LLM/gateway exception into a user-facing message.

    The Nokia gateway emits NGINX-style HTML pages (`<html>...500 - The
    request timed out...`) under load. Surfacing that raw blob to the PM is
    noisy; collapse known timeout/5xx patterns into a short instruction.
    """
    raw = str(exc)
    low = raw.lower()
    is_html = "<html" in low or "<body" in low
    is_timeout = any(
        tok in low
        for tok in ("request timed out", "timeout", "timed out", "504", "502", "500")
    )
    if is_html or is_timeout:
        return (
            "The LLM gateway timed out or returned a 5xx while processing this "
            "investigation. Please retry the query in a moment — if the issue "
            "persists, narrow the scope (shorter time range, fewer KPIs)."
        )
    # Non-gateway failures: keep the original message but cap the length so a
    # stack-trace blob doesn't blow up the chat bubble.
    return f"Investigation failed: {raw[:400]}"


def _stream_agent(agent, human_message: str, max_steps: int) -> list:
    """Run the agent via .stream(); print live progress; return final messages.

    Uses stream_mode="values" — each event yields the full state, so we track
    how many messages we've seen and only print the new ones. This surfaces
    tool calls + outputs in real time instead of waiting for .invoke() to
    return at the end.
    """
    seen = 0
    step_num = 0
    final_messages: list = []
    for state in agent.stream(
        {"messages": [("human", human_message)]},
        config={"recursion_limit": max_steps * 3 + 10},
        stream_mode="values",
    ):
        msgs = state.get("messages", []) if isinstance(state, dict) else []
        for msg in msgs[seen:]:
            if msg.type == "ai":
                step_num = _print_ai_message(msg, step_num)
            elif msg.type == "tool":
                _print_tool_message(msg)
        seen = len(msgs)
        final_messages = msgs
    return final_messages


def _print_sql_audit_log(
        sql_queries: list[dict],
        charts: list[dict],
        tool_call_records: list[dict],
) -> None:
    if not sql_queries:
        return

    print(f"\n{_BOLD}{'─' * 70}")
    print(f"  SQL / PYTHON QUERY AUDIT LOG ({len(sql_queries)} queries)")
    print(f"{'─' * 70}{_RESET}")

    for i, sq in enumerate(sql_queries, 1):
        tags = []
        sq_status = sq.get("status", "success")
        if sq_status == "error":
            tags.append(f"{_RED}ERROR{_RESET}")
        if sq.get("has_aggregation"):
            tags.append(f"{_CYAN}AGGREGATION{_RESET}")

        tool_label = sq.get("tool", "sql")
        header_extras = []
        if sq.get("kpi_name"):
            header_extras.append(sq["kpi_name"])
        if sq.get("level"):
            header_extras.append(f"level={sq['level']}")
        extras = f" — {' '.join(header_extras)}" if header_extras else ""
        print(f"\n  {_BOLD}Query #{i} (Step {sq['step']}) "
              f"[{tool_label}]{extras}{_RESET}  [{' | '.join(tags)}]")
        for line in sq["code"].strip().splitlines()[:30]:
            print(f"    {_DIM}{line}{_RESET}")
        if sq["code"].count("\n") > 30:
            print(f"    {_DIM}... ({sq['code'].count(chr(10)) - 30} more lines){_RESET}")

    n_failed = sum(1 for sq in sql_queries if sq.get("status") == "error")
    n_agg = sum(1 for sq in sql_queries if sq.get("has_aggregation"))
    gcl_calls = sum(1 for tc in tool_call_records if tc["tool_name"] == "call_gcl")

    print(f"\n  {_BOLD}Summary:{_RESET}")
    print(f"    Total queries: {len(sql_queries)} | "
          f"Success: {len(sql_queries) - n_failed} | "
          f"Failed: {n_failed} | "
          f"Aggregations: {n_agg} | "
          f"Charts: {len(charts)}")
    if gcl_calls:
        print(f"    GCL tool calls: {gcl_calls}")


# ─────────────────────────────────────────────────────────────────────
# Aggregation summary
# ─────────────────────────────────────────────────────────────────────

_LEVEL_PERIOD = {"national": 6, "region": 4, "market": 4, "gc_vendor": 4}

# tool-level string -> aggregation-summary canonical level
_LEVEL_NORMALIZE = {
    "national": "national",
    "region": "region",
    "market": "market",
    "gc": "gc_vendor",
    "gc_vendor": "gc_vendor",
}


def _row_count_from_output(output: str) -> int:
    """Best-effort row count extraction from a tool output preview."""
    if not output:
        return 0
    m = re.search(r'"row_count"\s*:\s*(\d+)', output)
    if m:
        return int(m.group(1))
    m = re.search(r"(\d+)\s*rows?", output.lower())
    return int(m.group(1)) if m else 0


def _build_aggregation_summary(
        sql_queries: list[dict],
        charts: list[dict],
        matched_kpis: list[dict] | None,
        escalation_context: dict[str, str],
) -> AggregationSummary:
    """Build the structured aggregation summary the FE consumes."""
    kpi_names_set: set[str] = {
        sq["kpi_name"] for sq in sql_queries if sq.get("kpi_name")
    }
    for m in matched_kpis or []:
        if m.get("kpi_name"):
            kpi_names_set.add(m["kpi_name"])

    levels: list[DrillDownLevel] = []
    levels_seen: set[str] = set()
    paths_seen: set[str] = set()

    for sq in sql_queries:
        if sq.get("status") == "error":
            continue
        level = _LEVEL_NORMALIZE.get((sq.get("level") or "").lower())
        if not level:
            continue  # ad-hoc sql_query / run_python — not a KPI drill-down

        # Source comes from the per-KPI source we tagged in batch_run_sqls,
        # else inferred from the SQL text.
        code = sq.get("code", "") or ""
        data_path = "B" if "gc_capacity" in code.lower() else "A"
        paths_seen.add(data_path)
        levels_seen.add(level)

        levels.append(DrillDownLevel(
            level=level,
            period_months=_LEVEL_PERIOD.get(level, 4),
            table_used="",
            data_path=data_path,
            row_count=_row_count_from_output(sq.get("output_preview", "")),
            kpi_name=sq.get("kpi_name", ""),
            status="success",
            query_step=sq.get("step", 0),
        ))

    if len(paths_seen) > 1:
        overall_path = "mixed"
    elif paths_seen:
        overall_path = paths_seen.pop()
    else:
        overall_path = "A"

    return AggregationSummary(
        kpi_names=list(kpi_names_set),
        drill_down_levels=levels,
        levels_completed=len(levels_seen),
        total_queries=len(sql_queries),
        total_charts=len(charts),
        data_path=overall_path,
        vertical=escalation_context.get("escalation_vertical", ""),
        time_coverage={
            lv: _LEVEL_PERIOD[lv] if lv in levels_seen else 0
            for lv in ("national", "region", "market", "gc_vendor")
        },
    )


# ─────────────────────────────────────────────────────────────────────
# Public API — flat ReAct agent
# ─────────────────────────────────────────────────────────────────────

def warmup() -> None:
    """Pre-warm caches at app startup so the first request doesn't pay the
    bootstrap cost. Safe to call multiple times — every loader is idempotent.
    """
    try:
        _bootstrap_table_schemas()
    except Exception as e:
        logger.error("KPIAnalyst | table-schema warmup failed: {}", e)
    try:
        _bootstrap_kpi_embeddings()
    except Exception as e:
        logger.error("KPIAnalyst | embedding warmup failed: {}", e)
    # KPI aggregation catalog loads at module import — nothing to warm up.


def _build_human_message(
        query: str,
        conversation_history: str,
        matched_kpis: list[dict] | None,
) -> str:
    parts = []
    if conversation_history:
        parts.append(f"## Conversation History\n{conversation_history}")
    parts.append(f"## Current Query\n{query}")
    if matched_kpis:
        hint_lines = "\n".join(
            f"  - {k.get('kpi_name', '?')} "
            f"(distance={k.get('distance', 0):.4f}, source={k.get('index', '')})"
            for k in matched_kpis[:_MAX_KPIS]
        )
        parts.append(
            "## Pre-matched KPIs (hint — call `search_kpis` again if weak)\n"
            + hint_lines
        )
    return "\n\n".join(parts)


def run_kpi_analyst(
        query: str,
        conversation_history: str = "",
        matched_kpis: list[dict] | None = None,
        escalation_context: dict[str, str] | None = None,
        max_steps: int = DEFAULT_MAX_STEPS,
) -> dict[str, Any]:
    """Run the KPI Analyst as a flat ReAct agent (streaming).

    Tools exposed to the agent:
      - search_kpis       (LLM match + score 1–10)
      - get_kpi_sqls      (pre-built SQL from aggregation catalog)
      - batch_run_sqls    (parallel SQL execution, FULL results, auto-charts)
      - sql_query         (ad-hoc SELECT — fallback)
      - run_python        (pandas post-processing)
      - call_gcl          (qualitative GCL context)
    """
    warmup()
    table_catalog = _bootstrap_table_schemas()

    system_prompt = _build_system_prompt(
        matched_kpis=matched_kpis,
        escalation_context=escalation_context or {},
        table_catalog=table_catalog,
    )

    tools = [
        search_kpis, get_kpi_sqls, batch_run_sqls,
        sql_query_tool, run_python, call_gcl,
    ]

    llm = LLMProvider(model=_AGENT_MODEL, temperature=_AGENT_TEMP).get_llm()
    agent = create_agent(
        model=llm,
        tools=tools,
        system_prompt=system_prompt,
        middleware=[ContextTrimmer()],
    )

    print(f"\n{_BOLD}{'=' * 70}")
    print(f"  KPI ANALYST — Flat ReAct Agent (streaming)")
    print(f"{'=' * 70}{_RESET}")
    print(f"  {_DIM}Query: {query[:100]}{_RESET}")
    for i, kpi in enumerate((matched_kpis or [])[:5], 1):
        print(f"  {_DIM}{i}. {kpi['kpi_name']} "
              f"(dist={kpi.get('distance', 0):.4f}){_RESET}")
    print()

    human_message = _build_human_message(query, conversation_history, matched_kpis)
    clear_chart_data_store()
    start_time = time.perf_counter()

    try:
        final_messages = _stream_agent(agent, human_message, max_steps)
    except Exception as e:
        logger.error("KPIAnalyst | main agent failed: {}", e)
        return {
            "findings": _friendly_agent_error(e),
            "findings_all": [],
            "tool_calls": [],
            "charts": [],
            "sql_queries": [],
            "steps_taken": 0,
            "errors": [str(e)[:500]],
            "elapsed_s": round(time.perf_counter() - start_time, 1),
            "aggregation_summary": {},
        }

    elapsed_s = round(time.perf_counter() - start_time, 1)
    processed = _process_messages(final_messages)
    findings_parts = processed["findings_parts"]
    findings = findings_parts[-1] if findings_parts else ""

    charts = list(get_chart_data_store())
    clear_chart_data_store()

    agg_summary = _build_aggregation_summary(
        sql_queries=processed["sql_queries"],
        charts=charts,
        matched_kpis=matched_kpis,
        escalation_context=escalation_context or {},
    )

    _print_sql_audit_log(
        sql_queries=processed["sql_queries"],
        charts=charts,
        tool_call_records=processed["tool_call_records"],
    )
    _print_divider("=")
    print(f"  {_BOLD}Complete: {processed['step_num']} steps, "
          f"{len(charts)} charts, {elapsed_s}s{_RESET}")
    _print_divider("=")
    print()

    logger.info("KPIAnalyst | done | {} steps | {} charts | {:.1f}s",
                processed["step_num"], len(charts), elapsed_s)

    return {
        "findings": findings,
        "findings_all": findings_parts,
        "tool_calls": processed["tool_call_records"],
        "charts": charts,
        "sql_queries": processed["sql_queries"],
        "steps_taken": processed["step_num"],
        "errors": processed["errors"],
        "elapsed_s": elapsed_s,
        "aggregation_summary": agg_summary,
    }


# ─────────────────────────────────────────────────────────────────────
# LangGraph node wrapper
# ─────────────────────────────────────────────────────────────────────

def kpi_analyst_node(state: EscalationState) -> dict[str, Any]:
    """LangGraph node — drop-in replacement for traversal_node."""
    query = state.get("refined_query") or state.get("user_query", "")
    conversation_history = state.get("conversation_history", "")
    max_steps = state.get("max_traversal_steps", DEFAULT_MAX_STEPS)

    escalation_context = {k: state.get(k, "") for k in _ESCALATION_CONTEXT_KEYS}

    if not query:
        return {
            "traversal_findings": "",
            "traversal_steps_taken": 0,
            "current_phase": "error",
            "errors": ["KPI Analyst received empty query."],
            "messages": [{"agent": "kpi_analyst", "content": "Empty query — skipped."}],
        }

    # Pre-match KPIs to give the agent a starting hint. warmup() inside
    # run_kpi_analyst handles bootstrap; we just need embeddings ready first.
    warmup()
    relevant_kpis_text = escalation_context.get("relevant_kpis", "")
    vertical = escalation_context.get("escalation_vertical", "")
    matched_kpis = search_and_match_kpis(query, relevant_kpis_text, vertical=vertical)

    if matched_kpis:
        logger.info("KPIAnalystNode | best match: {} (dist={})",
                    matched_kpis[0]["kpi_name"], matched_kpis[0]["distance"])

    result = run_kpi_analyst(
        query=query,
        conversation_history=conversation_history,
        matched_kpis=matched_kpis,
        escalation_context=escalation_context,
        max_steps=max_steps,
    )

    return {
        "traversal_findings": result["findings"],
        "traversal_tool_calls": result["tool_calls"],
        "traversal_steps_taken": result["steps_taken"],
        "charts": result["charts"],
        "sql_queries": result["sql_queries"],
        "current_phase": "response",
        "errors": result["errors"],
        "messages": [{
            "agent": "kpi_analyst",
            "content": (
                f"KPI Analyst complete: {result['steps_taken']} steps, "
                f"{len(result['sql_queries'])} SQL queries, "
                f"{result['elapsed_s']}s."
            ),
        }],
    }
