# Response Agent — ReAct agent that analyzes traversal findings, performs
# data-backed calculations via Python sandbox, and generates a PM-readable
# escalation report.

# Handles two upstream paths:
#   - Direct traversal path: reads traversal_findings + traversal_tool_calls
#   - Escalation lookup path: reads escalation_steps + escalation_step_results
#     (N parallel traversals) + expected_agent_output + draft_escalation_message_template
from __future__ import annotations

import json
import time
from typing import Any

from langgraph.prebuilt import create_react_agent
from loguru import logger

from models.state import EscalationState
from prompts.response_prompt import RESPONSE_SYSTEM
from services.llm_provider import LLMProvider
from tools.langchain_tools import get_analysis_tools

DEFAULT_MAX_ANALYSIS_STEPS = 15


def _extract_chart(tool_output: str) -> dict | None:
    """Extract chart metadata from a create_visualization tool result.

    The tool returns a TOON (or JSON) string containing chart_url, chart_type,
    title, and row_count.  We parse it and return a dict with HTTP URL only
    (no local file paths).
    """
    if not tool_output or ("chart_path" not in tool_output and "chart_url" not in tool_output):
        return None
    try:
        parsed = json.loads(tool_output)
    except (json.JSONDecodeError, TypeError):
        try:
            import toons
            parsed = toons.loads(tool_output)
        except Exception:
            return None

    if not isinstance(parsed, dict):
        return None

    # Build chart_url: prefer existing chart_url, fall back to extracting from chart_path
    chart_url = parsed.get("chart_url", "")
    if not chart_url:
        path = parsed.get("chart_path", "")
        if not path:
            return None
        from pathlib import Path as _P
        filename = _P(path).name
        chart_url = f"/api/v1/charts/{filename}"

    return {
        "chart_url": chart_url,
        "chart_type": parsed.get("chart_type", ""),
        "title": parsed.get("title", ""),
        "row_count": parsed.get("row_count", 0),
    }


# ── ANSI colors for terminal output ──
_CYAN = "\033[96m"
_GREEN = "\033[92m"
_YELLOW = "\033[93m"
_RED = "\033[91m"
_DIM = "\033[2m"
_BOLD = "\033[1m"
_RESET = "\033[0m"


def _format_traversal_data(state: EscalationState) -> str:
    """
    Format traversal findings into a context string for the response agent.
    """
    escalation_steps = state.get("escalation_steps", [])
    escalation_results = state.get("escalation_step_results", [])

    # ── Escalation lookup path (parallel steps) ──
    if escalation_steps and escalation_results:
        lines = [f"## Investigation Execution — {len(escalation_steps)} Parallel Steps\n"]

        for idx, (step, result) in enumerate(zip(escalation_steps, escalation_results), 1):
            findings = result.get("traversal_findings", "No findings.")
            tool_calls = result.get("traversal_tool_calls", [])
            steps_taken = result.get("traversal_steps_taken", 0)
            step_errors = result.get("errors", [])

            lines.append(f"### Step {idx}: {step}")
            lines.append(f"*Tool calls: {steps_taken}*\n")
            lines.append(findings)

            if step_errors:
                lines.append("\n*Errors in this step:*")
                for err in step_errors:
                    lines.append(f"- {err}")

            # Include raw successful tool outputs for analysis
            successful_data = []
            for tc in tool_calls:
                if tc["status"] == "success" and tc["tool_output"]:
                    successful_data.append({
                        "tool": tc["tool_name"],
                        "input": tc["tool_input"],
                        "output": tc["tool_output"],
                    })

            if successful_data:
                lines.append(f"\n**Raw Data from Step {idx}** ({len(successful_data)} successful calls):")
                for sd in successful_data:
                    lines.append(f"\n`{sd['tool']}` result:")
                    output = sd["output"]
                    if len(str(output)) > 8000:
                        output = str(output)[:8000] + "\n... (truncated)"
                    lines.append(f"```json\n{output}\n```")

            lines.append("")

        return "\n".join(lines)

    # ── Direct traversal path ──
    lines = ["## Traversal Agent Findings\n"]

    findings = state.get("traversal_findings", "")
    lines.append(findings if findings else "No findings were recorded by the traversal agent.")

    tool_calls = state.get("traversal_tool_calls", [])
    if tool_calls:
        successful_data = []
        for tc in tool_calls:
            if tc["status"] == "success" and tc["tool_output"]:
                successful_data.append({
                    "tool": tc["tool_name"],
                    "input": tc["tool_input"],
                    "output": tc["tool_output"],
                })

        if successful_data:
            lines.append(f"\n**Raw Data** ({len(successful_data)} successful calls):")
            for sd in successful_data:
                lines.append(f"\n`{sd['tool']}` result:")
                output = sd["output"]
                if len(str(output)) > 8000:
                    output = str(output)[:8000] + "\n... (truncated)"
                lines.append(f"```json\n{output}\n```")

    return "\n".join(lines)


def _format_escalation_context(state: EscalationState) -> str:
    """
    Format the matched escalation scenario context for the response agent,
    including expected_agent_output and draft_escalation_message_template.
    """
    lines = []

    esc_type = state.get("escalation_type", "")
    if esc_type:
        lines.append("## Matched Escalation Scenario")
        lines.append(f"- **Escalation Type**: {esc_type}")
        lines.append(f"- **Description**: {state.get('escalation_description', 'N/A')}")
        lines.append(f"- **Probable Reasons**: {state.get('probable_reasons', 'N/A')}")
        lines.append(f"- **Recommended Resolution**: {state.get('recommended_resolution', 'N/A')}")
        lines.append(f"- **Relevant KPIs**: {state.get('relevant_kpis', 'N/A')}")
        lines.append(f"- **Vertical**: {state.get('escalation_vertical', 'N/A')}")
        lines.append(f"- **Similarity Score**: {state.get('escalation_similarity_score', 0):.2%}")
        lines.append("")

    expected_output = state.get("expected_agent_output", "")
    if expected_output:
        lines.append("## Expected Agent Output (Reference Structure)")
        lines.append("Follow this structure closely — fill placeholders with ACTUAL data:")
        lines.append(f"\n{expected_output}")
        lines.append("")

    draft_template = state.get("draft_escalation_message_template", "")
    if draft_template:
        lines.append("## Draft Escalation Message Template (MUST FILL)")
        lines.append(
            "You MUST produce a **Draft Escalation Message** section in your report. "
            "Use the template below as the structural skeleton. Replace every placeholder "
            "(XX, ___, [placeholder], TBD, etc.) with ACTUAL numbers, dates, vendors, "
            "markets, and metrics computed from the investigation data via run_python. "
            "Do NOT leave any placeholder unfilled — if data is unavailable, state "
            "\"Data not available\" instead of the placeholder."
        )
        lines.append(f"\n{draft_template}")
        lines.append("")

    return "\n".join(lines)


def _print_divider(char: str = "-", width: int = 70):
    print(f"{_DIM}{char * width}{_RESET}")


def _print_tool_call(step_num: int, tool_name: str, tool_input: dict):
    _print_divider()
    print(f"{_BOLD}{_CYAN}  Analysis Step {step_num}: {tool_name}{_RESET}")
    for key, val in tool_input.items():
        val_str = str(val)
        if key == "code":
            print(f"     {_DIM}{key}:{_RESET}")
            for line in val_str.splitlines():
                print(f"       {_DIM}{line}{_RESET}")
        else:
            if len(val_str) > 200:
                val_str = val_str[:200] + "..."
            print(f"     {_DIM}{key}:{_RESET} {val_str}")


def _print_tool_result(status: str, output: str):
    if status == "error":
        icon, color = "X", _RED
    else:
        icon, color = "OK", _GREEN

    display = output
    try:
        parsed = json.loads(output)
        if isinstance(parsed, dict):
            if "error" in parsed:
                display = f"Error: {parsed['error']}"
                status = "error"
            elif "status" in parsed and parsed["status"] == "success":
                result_val = parsed.get("result", parsed.get("output", ""))
                display = f"Success: {json.dumps(result_val, default=str)[:500]}"
            else:
                display = json.dumps(parsed, indent=2, default=str)
                if len(display) > 1000:
                    display = display[:1000] + "\n     ...(truncated)"
        else:
            display = str(parsed)
            if len(display) > 1000:
                display = display[:1000] + "...(truncated)"
    except (json.JSONDecodeError, TypeError):
        if len(display) > 1000:
            display = display[:1000] + "...(truncated)"

    color_out = _RED if status == "error" else _GREEN
    print(f"     {color_out}{icon} Result:{_RESET} {display}")


def _print_agent_thinking(content: str):
    if not content.strip():
        return
    text = content.strip()
    if len(text) > 500:
        text = text[:500] + "..."
    print(f"  {_YELLOW}Analysis:{_RESET} {text}")


def response_node(state: EscalationState) -> dict[str, Any]:
    """
    LangGraph node: Response Agent (ReAct) for Escalation.

    Uses run_python tool to perform calculations on traversal data,
    then generates a comprehensive, data-backed escalation report.

    Reads: refined_query (or user_query), traversal/escalation data,
           expected_agent_output, draft_escalation_message_template, errors
    Writes: final_response, calculations, data_summary, current_phase, messages
    """
    provider = LLMProvider(model="gpt-5-mini", temperature=0.0)
    llm = provider.get_llm()

    user_query = state.get("refined_query") or state["user_query"]
    data_context = _format_traversal_data(state)
    escalation_context = _format_escalation_context(state)
    errors = state.get("errors", [])
    logger.info(
        "Response | starting | query={!r} | data_context_len={} | escalation_context_len={} | errors={}",
        user_query[:120], len(data_context), len(escalation_context), len(errors),
    )
    logger.debug("Response | escalation_type={} | steps={} | step_results={}",
                 state.get("escalation_type", ""), len(state.get("escalation_steps", [])),
                 len(state.get("escalation_step_results", [])),
                 )

    # Build the human message with all context
    conversation_history = state.get("conversation_history", "")
    user_message_parts = []

    if conversation_history:
        user_message_parts.append(
            f"## Conversation History (prior turns in this session)\n{conversation_history}"
        )

    user_message_parts.append(f"## Original User Query\n{user_query}")

    if escalation_context:
        user_message_parts.append(f"\n{escalation_context}")

    user_message_parts.append(f"\n{data_context}")

    if errors:
        user_message_parts.append(
            "\n## Errors Encountered\n" +
            "\n".join(f"- {e}" for e in errors)
        )

    user_message_parts.append(
        "\nProduce a **PMO-ready escalation report** from the investigation data above."
        "\n\n1. Use run_python for ALL calculations — metrics, RAG classification, variances, "
        "percentages, rankings, and trend analysis. Never compute in your head."
        "\n2. Follow the PMO Report Structure from your system prompt:"
        "\n   - Executive Summary with RAG status and scope"
        "\n   - KPI Dashboard table (Current | Target | Variance | Trend | RAG)"
        "\n   - Data Retrieved section with raw data in Markdown tables"
        "\n   - Impact Assessment across schedule/scope/quality/cost/safety"
        "\n   - Concentration Analysis with ranked table + chart"
        "\n   - Root Cause Analysis"
        "\n   - Action Tracker with Owner, Due Date, Priority, Status"
        "\n   - Preventive Actions"
        "\n   - Draft Escalation Message (ready to copy-paste and send)"
        "\n3. Follow the Expected Agent Output structure as the base — wrap it in the PMO framework."
        "\n4. Replace all placeholders (XX, ___, etc.) with actual computed data."
        "\n5. Create at least one chart for the most impactful finding."
        "\n6. The output must be directly usable in a program review or stakeholder email."
    )

    human_message = "\n".join(user_message_parts)

    # Build the ReAct agent with python sandbox tool
    tools = get_analysis_tools()
    agent = create_react_agent(
        model=llm,
        tools=tools,
        prompt=RESPONSE_SYSTEM,
    )

    max_steps = DEFAULT_MAX_ANALYSIS_STEPS

    # ── Live-streaming execution ──
    print(f"\n{_BOLD}{'=' * 70}")
    print(f"  RESPONSE AGENT — Generating Data-Backed Escalation Report")
    print(f"{'=' * 70}{_RESET}")
    print(f"  {_DIM}Query: {user_query[:80]}{_RESET}\n")

    start_time = time.perf_counter()
    step_num = 0
    final_response = ""
    charts: list[dict] = []

    try:
        for chunk in agent.stream(
                {"messages": [("human", human_message)]},
                config={"recursion_limit": max_steps * 3 + 10},
                stream_mode="updates",
        ):
            for node_name, node_output in chunk.items():
                messages = node_output.get("messages", [])

                for msg in messages:
                    # ── AI message: thinking or tool call ──
                    if msg.type == "ai":
                        text = getattr(msg, "content", "") or ""

                        if text.strip() and not getattr(msg, "tool_calls", None):
                            _print_agent_thinking(text)
                            final_response = text
                            logger.debug("Response | agent reasoning: {}", text[:800])

                        if hasattr(msg, "tool_calls") and msg.tool_calls:
                            for tc in msg.tool_calls:
                                step_num += 1
                                _print_tool_call(step_num, tc["name"], tc["args"])
                                logger.info(
                                    "Response | step {} | tool={} | input_keys={}",
                                    step_num, tc["name"], list(tc["args"].keys()),
                                )
                                for key, val in tc["args"].items():
                                    val_str = str(val)
                                    if len(val_str) > 2000:
                                        val_str = val_str[:2000] + "...(truncated)"
                                    logger.debug("Response | step {} | {}={}", step_num, key, val_str)

                    # ── Tool result message ──
                    elif msg.type == "tool":
                        output = msg.content or ""
                        status = "error" if "error" in output.lower()[:200] else "success"
                        _print_tool_result(status, output)
                        logger.info(
                            "Response | tool result | status={} | output_len={}",
                            status, len(output),
                        )
                        if status == "error":
                            logger.warning("Response | tool FAILED | output={}", output[:1000])
                        else:
                            logger.debug("Response | tool output={}", output[:2000])

                        # Capture chart paths from create_visualization results
                        chart = _extract_chart(output)
                        if chart:
                            charts.append(chart)
                            logger.info("Response | chart extracted: {}", chart)

        elapsed = time.perf_counter() - start_time

        _print_divider("=")
        print(f"  {_BOLD}Analysis complete: {step_num} calculations performed in {elapsed:.1f}s{_RESET}")
        if charts:
            print(f"  {_BOLD}Charts generated: {len(charts)}{_RESET}")
        _print_divider("=")
        print()

        logger.info(
            "Response agent completed: {} calculations, {} charts in {:.1f}s",
            step_num, len(charts), elapsed,
        )

        return {
            "final_response": final_response,
            "calculations": f"{step_num} python calculations executed",
            "data_summary": {},
            "charts": charts,
            "current_phase": "complete",
            "messages": [{
                "agent": "response",
                "content": (
                    f"Analysis complete: {step_num} calculations, "
                    f"{len(charts)} charts, {elapsed:.1f}s elapsed"
                ),
            }],
        }

    except Exception as e:
        elapsed = time.perf_counter() - start_time
        print(f"\n  {_RED}Analysis failed after {elapsed:.1f}s: {e}{_RESET}\n")
        logger.error("Response agent failed after {:.1f}s: {}", elapsed, e, exc_info=True)
        return {
            "final_response": f"Analysis failed: {e}",
            "calculations": "",
            "data_summary": {},
            "charts": charts,
            "current_phase": "complete",
            "errors": [f"Response agent error: {e}"],
            "messages": [{
                "agent": "response",
                "content": f"Analysis failed after {elapsed:.1f}s: {e}",
            }],
        }
