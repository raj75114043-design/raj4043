# Orchestrator Agent — Routing node for the Escalation Agent.

# Receives the finalised query from the Query Refiner and decides which
# downstream pipeline to activate:

#   - "greeting"    → Sets final_response directly; graph terminates immediately.
#   - "traversal"   → Simple data lookup; routes to schema discovery → traversal → response.
#   - "escalation"  → Full escalation investigation; routes to schema discovery → escalation_lookup → response.

# The orchestrator does NOT retrieve any data itself — it only classifies and routes.
from __future__ import annotations

import json
from typing import Any

from langchain_core.messages import SystemMessage, HumanMessage
from loguru import logger

from models.state import EscalationState
from prompts.orchestrator_prompt import ORCHESTRATOR_SYSTEM
from services.llm_provider import LLMProvider

_CYAN = "\033[96m"
_GREEN = "\033[92m"
_YELLOW = "\033[93m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_RESET = "\033[0m"

_VALID_ROUTES = {"greeting", "traversal", "escalation"}


def _parse_orchestrator_response(content: str) -> dict:
    """
    Parse the LLM's JSON routing decision.
    Falls back to "escalation" on any parse error (safest default).
    """
    try:
        clean = content.strip()
        if clean.startswith("```"):
            clean = clean.split("```")[1]
            if clean.startswith("json"):
                clean = clean[4:]
        return json.loads(clean.strip())
    except (json.JSONDecodeError, IndexError):
        logger.warning("Orchestrator LLM returned non-JSON; defaulting to escalation route.")
        return {
            "routing_decision": "escalation",
            "reasoning": "Could not parse routing decision; defaulting to escalation.",
            "direct_response": None,
        }


def orchestrator_node(state: EscalationState) -> dict[str, Any]:
    """
    LangGraph node: Orchestrator Agent.

    Reads:  refined_query
    Writes: routing_decision, routing_context (greeting only),
            final_response (greeting only), current_phase, messages
    """
    refined_query = state.get("refined_query") or state["user_query"]
    conversation_history = state.get("conversation_history", "")

    print(f"\n{_BOLD}{'=' * 70}")
    print(f"  ORCHESTRATOR — Routing query to the right pipeline")
    print(f"{'=' * 70}{_RESET}\n")
    print(f"  {_DIM}Query: {refined_query}{_RESET}\n")

    provider = LLMProvider(model="gpt-5-mini")
    llm = provider.get_llm()

    # Include conversation history so orchestrator understands follow-up queries
    user_content = refined_query
    if conversation_history:
        user_content = (
            f"## Conversation History (prior turns in this session)\n"
            f"{conversation_history}\n\n"
            f"## Current Query\n{refined_query}"
        )

    logger.debug("Orchestrator | invoking LLM | query={!r}", refined_query[:120])
    response = llm.invoke([
        SystemMessage(content=ORCHESTRATOR_SYSTEM),
        HumanMessage(content=user_content),
    ])
    logger.debug("Orchestrator | LLM raw response: {}", response.content[:500])

    parsed = _parse_orchestrator_response(response.content)
    routing_decision: str = parsed.get("routing_decision", "escalation")
    reasoning: str = parsed.get("reasoning", "")
    direct_response: str | None = parsed.get("direct_response")

    logger.info(
        "Orchestrator | route={} | reason={!r}",
        routing_decision, reasoning[:150],
    )
    if routing_decision not in _VALID_ROUTES:
        routing_decision = "escalation"

    route_color = {
        "greeting": _YELLOW,
        "traversal": _CYAN,
        "escalation": _GREEN,
    }.get(routing_decision, _GREEN)

    print(f"  {route_color}-> Route: {routing_decision.upper()}{_RESET}")
    print(f"  {_DIM}Reason: {reasoning}{_RESET}\n")

    result: dict[str, Any] = {
        "routing_decision": routing_decision,
        "routing_context": direct_response or "",
        "current_phase": "orchestration",
        "messages": [{
            "agent": "orchestrator",
            "content": f"Routed to '{routing_decision}'. Reason: {reasoning}",
        }],
    }

    if routing_decision == "greeting" and direct_response:
        result["final_response"] = direct_response
        result["current_phase"] = "complete"

    return result
