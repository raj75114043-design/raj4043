# Context Gatherer — small ReAct agent that collects the minimum scope fields
# needed before the main KPI Analyst runs.
#
# Required fields:
#   - vertical      (e.g. "NTM", "AHLOA", "MB")
#   - kpi_name      (the KPI or metric the user wants to investigate)
#   - time_range    (e.g. "last 6 months", "Q1 2026")
#   - scope         (national / region / market / gc_vendor — or a specific entity)
#
# The agent has exactly two stop-tools:
#   - ask_user(question, example_answers)   — emit one clarifying question
#   - finalize(vertical, kpi_name, ...)     — signal enough context is gathered
#
# The caller (`_run_kpi_analysis`) inspects the return dict:
#   {"status": "need_info", "question": "...", "example_answers": [...]}
#   {"status": "ready",     "vertical": ..., "kpi_name": ..., ...}
from __future__ import annotations

import json
from typing import Any

import toons
from langchain.agents import create_agent
from langchain_core.tools import tool
from loguru import logger

from services.llm_provider import LLMProvider


def _to_toons(obj: Any) -> str:
    """Serialize *obj* to a TOON string (with a JSON-string fallback for
    non-serializable values — same pattern as `tools.langchain_tools._to_toons`)."""
    try:
        return toons.dumps(obj)
    except Exception:
        safe = json.loads(json.dumps(obj, default=str))
        return toons.dumps(safe)

_MODEL = "gpt-5-mini"
_MAX_STEPS = 3

_SYSTEM_PROMPT = """\
You are a context-gathering assistant for a T-Mobile MACRO KPI investigation system.

Your ONLY job is to decide whether the user has supplied enough scope for a KPI
investigation to run, and either:
  - call `ask_user` with ONE question to fill the biggest gap, OR
  - call `finalize` when all four required fields are known.

## Required fields
1. vertical       — one of: NTM, AHLOA, NAS, or "any" if the user is cross-vertical
2. kpi_name       — the KPI / metric to investigate (e.g. "Swap FTR", "COP cycle time")
3. time_range     — e.g. "last 6 months", "Q1 2026", "last 30 days"
4. scope          — one of: national, region, market, gc_vendor (+ entity if applicable)

{scenario_block}
## Rules
- Read the conversation history carefully — fields may already be answered in prior turns.
- When a MATCHED ESCALATION SCENARIO block is present above, treat its fields as
  prefilled defaults (see the block's own instructions). When you must ask a
  question, draw examples from the scenario's description / relevant_kpis /
  probable_reasons so the question feels grounded, not generic.
- Ask ONE question at a time, targeting the single most important missing field.
- When asking, include 3–5 concrete example answers so the user can reply fast.
- Never ask a question the user already answered — and never ask a question whose
  answer is obvious from the matched scenario.
- When finalizing, `refined_query` MUST be a single clear sentence that merges the
  user's intent with the gathered fields. Example:
    "Investigate Swap FTR for NTM vertical at market level over the last 6 months."
- If the user's query is already specific enough (all four fields clearly present,
  whether directly stated or inherited from the scenario), skip straight to `finalize`.
  Do NOT ask redundant questions.
- Exactly ONE tool call per response. No plain text, no multiple tools.
"""


def _format_scenario_block(scenario: dict[str, str] | None) -> str:
    """Render the matched escalation scenario as a TOON-encoded prompt section.

    We push TOON (not JSON / markdown) into the LLM because it is the
    house-standard structured format for this codebase (see
    `tools.langchain_tools._to_toons`). Empty fields are stripped so the
    payload stays compact. Returns '' when no useful scenario fields exist so
    the `{scenario_block}` slot collapses cleanly.
    """
    if not scenario:
        return ""

    def _clip(val: Any, n: int) -> str:
        s = (str(val) if val is not None else "").strip().replace("\n", " ")
        return (s[: n - 1] + "…") if len(s) > n else s

    # Field order / clip lengths chosen to keep the payload under ~1.3k chars.
    payload: dict[str, str] = {}
    for key, n in (
        ("escalation_type", 120),
        ("escalation_vertical", 40),
        ("relevant_kpis", 300),
        ("escalation_description", 300),
        ("probable_reasons", 400),
        ("recommended_resolution", 400),
    ):
        clipped = _clip(scenario.get(key, ""), n)
        if clipped:
            payload[key] = clipped

    if not payload:
        return ""

    toon_body = _to_toons(payload)
    return (
        "## MATCHED ESCALATION SCENARIO (TOON — use as defaults)\n"
        "Treat `escalation_vertical` as prefilled `vertical` (do NOT re-ask).\n"
        "Treat `relevant_kpis` as candidate `kpi_name`(s) (do NOT re-ask unless\n"
        "the user clearly names a different KPI).\n"
        f"```toon\n{toon_body}\n```\n"
    )


@tool
def ask_user(question: str, example_answers: list[str] | None = None) -> str:
    """Ask the user ONE clarifying question to fill a missing scope field.

    Args:
        question: The question to show the user (one sentence, direct).
        example_answers: 3–5 short example answers to help the user reply quickly.
    """
    # Tool body is a no-op; the caller reads tool-call args from message history.
    return "QUESTION_EMITTED"


@tool
def finalize(
        vertical: str,
        kpi_name: str,
        time_range: str,
        scope: str,
        refined_query: str,
) -> str:
    """Signal that all required fields are gathered and the main pipeline can run.

    Args:
        vertical: NTM | AHLOA | MB | SRAN | GC-Ops | any
        kpi_name: The KPI or metric to investigate.
        time_range: e.g. "last 6 months", "Q1 2026".
        scope: national | region | market | gc_vendor (+ entity if applicable).
        refined_query: One-sentence merged query for the main agent.
    """
    return "CONTEXT_FINALIZED"


def _extract_decision(messages: list) -> dict[str, Any] | None:
    """Walk the agent message history and return the first stop-tool call."""
    for msg in messages:
        if getattr(msg, "type", "") != "ai":
            continue
        for tc in (getattr(msg, "tool_calls", None) or []):
            name = tc.get("name")
            args = tc.get("args", {}) or {}
            if name == "ask_user":
                return {
                    "status": "need_info",
                    "question": str(args.get("question", "")).strip(),
                    "example_answers": list(args.get("example_answers") or []),
                }
            if name == "finalize":
                return {
                    "status": "ready",
                    "vertical": str(args.get("vertical", "")).strip(),
                    "kpi_name": str(args.get("kpi_name", "")).strip(),
                    "time_range": str(args.get("time_range", "")).strip(),
                    "scope": str(args.get("scope", "")).strip(),
                    "refined_query": str(args.get("refined_query", "")).strip(),
                }
    return None


def gather_context(
        query: str,
        conversation_history: str = "",
        scenario_context: dict[str, str] | None = None,
) -> dict[str, Any]:
    """Run the context-gathering ReAct agent.

    Args:
        query: The current user message.
        conversation_history: Prior turns in the session (may be empty).
        scenario_context: Matched escalation scenario (from `_lookup_escalation_context`).
            When present, its `escalation_vertical` / `relevant_kpis` act as
            prefilled defaults so the gatherer doesn't re-ask questions the
            scenario already answers.

    Returns either:
        {"status": "need_info", "question": str, "example_answers": list[str]}
        {"status": "ready", "vertical": str, "kpi_name": str, "time_range": str,
         "scope": str, "refined_query": str}

    On any failure, returns {"status": "ready", "refined_query": query, ...empty}
    so the main pipeline still runs rather than blocking the user.
    """
    # Low reasoning: this is a simple routing decision (ask vs finalize),
    # not an analysis task. Default "medium" reasoning was adding ~30s latency.
    llm = LLMProvider(model=_MODEL, temperature=0.0, reasoning_effort="low").get_llm()
    scenario_block = _format_scenario_block(scenario_context)
    system_prompt = _SYSTEM_PROMPT.format(scenario_block=scenario_block)
    agent = create_agent(
        model=llm,
        tools=[ask_user, finalize],
        system_prompt=system_prompt,
    )

    human_parts: list[str] = []
    if conversation_history.strip():
        human_parts.append(f"## Conversation History\n{conversation_history}")
    human_parts.append(f"## Current User Message\n{query}")
    human_message = "\n\n".join(human_parts)

    try:
        result = agent.invoke(
            {"messages": [("human", human_message)]},
            config={"recursion_limit": _MAX_STEPS * 2 + 4},
        )
    except Exception as e:
        logger.warning("ContextGatherer | agent failed, defaulting to ready: {}", e)
        return _fallback_ready(query)

    decision = _extract_decision(result.get("messages", []))
    if not decision:
        logger.warning("ContextGatherer | no stop-tool call detected, defaulting to ready")
        return _fallback_ready(query)

    if decision["status"] == "need_info" and not decision["question"]:
        logger.warning("ContextGatherer | ask_user fired without a question, defaulting to ready")
        return _fallback_ready(query)

    logger.info("ContextGatherer | decision={}", decision["status"])
    return decision


def _fallback_ready(query: str) -> dict[str, Any]:
    """Used when the gatherer errors or stalls — let the main pipeline try anyway."""
    return {
        "status": "ready",
        "vertical": "",
        "kpi_name": "",
        "time_range": "",
        "scope": "",
        "refined_query": query,
    }
