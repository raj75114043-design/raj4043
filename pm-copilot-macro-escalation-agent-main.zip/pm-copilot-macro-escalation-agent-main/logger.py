"""
Central logging setup using loguru.

Import and call setup_logging() once at startup (done by the API entry point).
All other modules just do `from loguru import logger` and use it directly.

Log files land in logs/ with daily rotation and 7-day retention.
"""

import os
import sys
from pathlib import Path

from loguru import logger


def setup_logging(level: str | None = None) -> None:
    level = level or os.environ.get("LOG_LEVEL", "INFO").upper()

    logger.remove()  # remove default stderr handler

    # console — clean, coloured
    logger.add(
        sys.stderr,
        level=level,
        format=(
            "<green>{time:HH:mm:ss}</green> | <level>{level:<8}</level> | "
            "<cyan>{name}</cyan>:<cyan>{line}</cyan> — <level>{message}</level>"
        ),
        colorize=False,
    )

    # file — full detail, rotates daily
    log_dir = Path(__file__).parent / "logs"
    log_dir.mkdir(exist_ok=True)
    logger.add(
        log_dir / "agent_{time:YYYY-MM-DD}.log",
        level="DEBUG",
        format=(
            "{time:YYYY-MM-DD HH:mm:ss.SSS} | {level:<8} | "
            "{name}:{line} | {extra[request_id]} — {message}"
        ),
        rotation="00:00",
        retention="7 days",
        encoding="utf-8",
    )

    # Set default request_id so logs outside request context don't crash
    logger.configure(extra={"request_id": "-"})

    logger.info("Logging initialised — level={}", level)