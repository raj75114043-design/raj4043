# Shared state models for the LangGraph Escalation Agent system.
# All agents read/write to this shared state as it flows through the graph.
from __future__ import annotations

import operator
from typing import Any, Literal, Optional, TypedDict, Annotated


# ─────────────────────────────────────────────
# Traversal Agent output types
# ─────────────────────────────────────────────

class ToolCallRecord(TypedDict):
    """Record of a single tool invocation by the traversal agent."""
    tool_name: str
    tool_input: dict[str, Any]
    tool_output: Any
    status: Literal["success", "error"]
    execution_time_ms: float


class DrillDownLevel(TypedDict, total=False):
    """One level of the mandatory drill-down hierarchy.

    Tracks what was queried at each granularity level so the frontend
    can display share/period data without parsing the report text.
    """
    level: Literal["national", "region", "market", "gc_vendor"]
    period_months: int  # 6 for national, 4 for others
    table_used: str  # which table or GCL source
    data_path: Literal["A", "B"]  # Path A (pre-built SQL) or B (GCL)
    row_count: int  # rows returned
    kpi_name: str
    status: Literal["success", "error", "skipped"]
    query_step: int  # step number in sql_queries


class AggregationSummary(TypedDict, total=False):
    """Aggregation metadata for the full KPI investigation.

    Returned alongside findings so the frontend can show drill-down
    completeness, time period coverage, and share breakdowns.
    """
    kpi_names: list[str]  # KPIs analyzed
    drill_down_levels: list[DrillDownLevel]
    levels_completed: int  # 0-4 (national/region/market/gc)
    total_queries: int
    total_charts: int
    data_path: str  # "A", "B", or "mixed"
    vertical: str  # escalation vertical filter used
    time_coverage: dict[str, int]  # e.g. {"national": 6, "region": 4, ...}


class ChartColumnMeta(TypedDict):
    """Column metadata for frontend rendering hints."""
    name: str
    dtype: str
    kind: Literal["numeric", "categorical", "datetime", "boolean"]
    nunique: int


class ChartDataRecord(TypedDict, total=False):
    """Frontend-renderable chart payload.

    Contains cleaned data + chart spec so the frontend can render
    using any charting library (Plotly.js, Chart.js, ECharts, etc.).
    Stored as JSONB in the DB alongside the query record.
    """
    # Chart specification
    chart_type: str  # bar, line, pie, donut, scatter, etc.
    title: str
    x_column: str
    y_column: str
    color_column: str  # grouping / secondary axis column
    orientation: str  # "v" or "h"
    bar_mode: Optional[str]  # "relative", "stack", "group" (bar charts only)
    threshold: Optional[float]  # target/SLA line value
    threshold_label: str  # label for threshold line

    # Data payload
    data: list[dict[str, Any]]  # cleaned, chart-ready records
    columns: list[ChartColumnMeta]  # column metadata (types, cardinality)
    row_count: int  # original row count before bucketing

    # Identity (used by _extract_chart to detect chart output)
    chart_url: str  # "frontend://<chart_id>" identifier


# ─────────────────────────────────────────────
# Main Graph State  (shared across all nodes)
# ─────────────────────────────────────────────

class EscalationState(TypedDict):
    """
    The shared state that flows through the LangGraph.
    Uses Annotated + operator.add for list fields so that
    each node *appends* rather than overwrites.
    """
    # ── Input ──
    user_query: str
    refined_query: str
    conversation_history: str  # Compact summary of prior turns in the session

    # ── Phase tracking ──
    current_phase: Literal[
        "query_refinement", "orchestration", "discovery",
        "escalation_lookup", "traversal", "response", "complete", "error"
    ]

    # ── Orchestrator routing ──
    routing_decision: str  # "greeting" | "escalation" | "traversal"
    routing_context: str  # For greeting: direct response text

    # ── Escalation Scenario (from semantic_escalation table) ──
    escalation_type: str
    escalation_description: str
    probable_reasons: str
    recommended_resolution: str
    expected_agent_output: str
    draft_escalation_message_template: str
    relevant_kpis: str
    escalation_vertical: str
    escalation_similarity_score: float

    # ── Escalation Steps (derived from recommended_resolution) ──
    escalation_steps: list[str]
    escalation_step_results: Annotated[list[dict], operator.add]

    # ── Knowledge Graph Schema (discovered once) ──
    kg_schema: str

    # ── Traversal Agent ──
    traversal_findings: str
    traversal_tool_calls: Annotated[list[ToolCallRecord], operator.add]
    traversal_steps_taken: int
    max_traversal_steps: int  # Safety ceiling (default 20)

    # ── SQL Query Audit ──
    sql_queries: Annotated[list[dict], operator.add]  # successful SQL queries for validation

    # ── Response Agent ──
    final_response: str
    calculations: str
    data_summary: dict[str, Any]
    charts: Annotated[list[dict], operator.add]  # list[ChartDataRecord]

    # ── Error handling ──
    errors: Annotated[list[str], operator.add]

    # ── Metadata ──
    created_at: str
    messages: Annotated[list[dict], operator.add]
