"""
tools/chart_data_tool.py
------------------------
Frontend-renderable chart data tool.

Returns a JSON payload containing:
  - Cleaned, chart-ready records
  - Chart specification (type, axes, orientation, threshold, bar_mode)
  - Series metadata (for multi-Y charts) + per-column summary stats
  - Pre-computed stats for box plots (quartiles / whiskers / outliers)
  - Automatic handling of complex inputs:
      * multi-series (y_column as list)
      * duplicate-row aggregation (auto groupby)
      * dense time-series downsampling (W / M / Q / Y)
      * 100% stacked normalisation
      * pareto (sorted + cumulative %)
      * heatmap auto-pivot
      * top-N bucketing for bars / pies

Supported chart types:
  bar | stacked_bar | grouped_bar | line | pie | donut | scatter |
  histogram | area | box | funnel | heatmap | waterfall | combo |
  pareto | auto
"""
from __future__ import annotations

import json
import re
from typing import Any

import pandas as pd
import toons
from langchain_core.tools import tool
from loguru import logger

from tools.chart_tools import (
    _resolve_column,
    _clean_dataframe,
    _bucket_others,
    _sort_bar_data,
    _auto_select_chart,
    _is_date_column,
    _TOP_N_BAR,
    _TOP_N_PIE,
)

# ── Tunables ──────────────────────────────────────────────────────────
_MAX_POINTS_BEFORE_RESAMPLE = 200
_MAX_BOX_OUTLIERS = 50
_MAX_PARETO = 12
_NUMERIC_ROUND = 4


# ─────────────────────────────────────────────────────────────────────
# Small helpers
# ─────────────────────────────────────────────────────────────────────

def _as_list(val) -> list[str]:
    """Normalize a str | list | None into a clean list[str]."""
    if val is None:
        return []
    if isinstance(val, str):
        return [val] if val.strip() else []
    if isinstance(val, (list, tuple, set)):
        return [str(v).strip() for v in val if v is not None and str(v).strip()]
    return []


def _numeric_cols(df: pd.DataFrame, candidates: list[str]) -> list[str]:
    return [
        c for c in candidates
        if c in df.columns and pd.api.types.is_numeric_dtype(df[c])
    ]


def _pick_resample_freq(span_days: float, max_points: int) -> str | None:
    """Return a pandas resample rule (W/M/Q/Y) so series length <= max_points."""
    if span_days <= 0:
        return None
    for freq, days_per_bin in (("W", 7), ("M", 30), ("Q", 91), ("Y", 365)):
        if span_days / days_per_bin <= max_points:
            return freq
    return "Y"


def _coerce_numeric_series(s: pd.Series) -> pd.Series:
    if pd.api.types.is_numeric_dtype(s):
        return s
    return pd.to_numeric(s, errors="coerce")


def _round_numeric(df: pd.DataFrame, decimals: int = _NUMERIC_ROUND) -> pd.DataFrame:
    for c in df.columns:
        if pd.api.types.is_float_dtype(df[c]):
            df[c] = df[c].round(decimals)
    return df


# ─────────────────────────────────────────────────────────────────────
# Aggregation / resampling / transforms
# ─────────────────────────────────────────────────────────────────────

def _aggregate_duplicates(
        df: pd.DataFrame,
        x_col: str,
        y_cols: list[str],
        color_col: str | None,
        method: str = "auto",
) -> tuple[pd.DataFrame, bool]:
    """Group-by on (x, color) and aggregate numeric y columns.

    Returns (df, aggregated_flag).
    """
    if method == "none":
        return df, False
    if x_col not in df.columns:
        return df, False

    group_cols = [x_col]
    if color_col and color_col in df.columns and color_col != x_col:
        group_cols.append(color_col)

    try:
        if df.groupby(group_cols, dropna=False).size().max() <= 1:
            return df, False
    except Exception:
        return df, False

    numeric_y = _numeric_cols(df, y_cols)
    if not numeric_y:
        return df, False

    agg_fn = method if method in ("sum", "mean", "max", "min", "median") else "sum"
    carry = [c for c in df.columns if c not in group_cols and c not in numeric_y]
    out = df.groupby(group_cols, as_index=False, dropna=False)[numeric_y].agg(agg_fn)
    if carry:
        first = df.groupby(group_cols, as_index=False, dropna=False)[carry].first()
        out = out.merge(first, on=group_cols, how="left")
    return out, True


def _resample_time_series(
        df: pd.DataFrame,
        x_col: str,
        y_cols: list[str],
        color_col: str | None,
        max_points: int,
) -> tuple[pd.DataFrame, str | None]:
    """Downsample dense datetime series to W/M/Q/Y. Returns (df, freq_used)."""
    if x_col not in df.columns or not _is_date_column(df[x_col]):
        return df, None
    try:
        dates = pd.to_datetime(df[x_col], errors="coerce")
    except Exception:
        return df, None
    if dates.isna().all():
        return df, None
    if len(df) <= max_points:
        return df, None

    span = (dates.max() - dates.min()).total_seconds() / 86400.0
    freq = _pick_resample_freq(span, max_points)
    if not freq:
        return df, None

    numeric_y = _numeric_cols(df, y_cols)
    if not numeric_y:
        return df, None

    working = df.copy()
    working[x_col] = dates

    if color_col and color_col in working.columns:
        out_frames = []
        for key, grp in working.groupby(color_col, dropna=False):
            g = (
                grp.set_index(x_col)[numeric_y]
                .resample(freq).mean()
                .dropna(how="all")
                .reset_index()
            )
            g[color_col] = key
            out_frames.append(g)
        out = pd.concat(out_frames, ignore_index=True) if out_frames else working
    else:
        out = (
            working.set_index(x_col)[numeric_y]
            .resample(freq).mean()
            .dropna(how="all")
            .reset_index()
        )
    return out, freq


def _pareto_transform(df: pd.DataFrame, x_col: str, y_col: str) -> pd.DataFrame:
    """Sort descending by y and append `cumulative_pct`. Caps at _MAX_PARETO + Others."""
    d = df[[x_col, y_col]].copy()
    d[y_col] = _coerce_numeric_series(d[y_col])
    d = d.dropna(subset=[y_col]).sort_values(y_col, ascending=False)

    if len(d) > _MAX_PARETO:
        head = d.head(_MAX_PARETO - 1)
        tail_total = d.tail(len(d) - (_MAX_PARETO - 1))[y_col].sum()
        others = pd.DataFrame([{x_col: "Others", y_col: tail_total}])
        d = pd.concat([head, others], ignore_index=True)

    total = float(d[y_col].sum())
    d["cumulative_pct"] = (
        (d[y_col].cumsum() / total * 100.0).round(2) if total else 0.0
    )
    return d


def _box_stats(df: pd.DataFrame, x_col: str, y_col: str) -> list[dict]:
    """Pre-compute quartiles / whiskers / outliers per x group."""
    if x_col not in df.columns or y_col not in df.columns:
        return []

    stats: list[dict] = []
    for name, grp in df.groupby(x_col, dropna=False):
        vals = _coerce_numeric_series(grp[y_col]).dropna()
        if vals.empty:
            continue
        q1, median, q3 = [float(v) for v in vals.quantile([0.25, 0.5, 0.75])]
        iqr = q3 - q1
        lower_fence = q1 - 1.5 * iqr
        upper_fence = q3 + 1.5 * iqr
        inliers = vals[(vals >= lower_fence) & (vals <= upper_fence)]
        whisker_low = float(inliers.min()) if not inliers.empty else float(vals.min())
        whisker_high = float(inliers.max()) if not inliers.empty else float(vals.max())
        outliers = vals[(vals < lower_fence) | (vals > upper_fence)].tolist()
        if len(outliers) > _MAX_BOX_OUTLIERS:
            outliers = sorted(
                outliers, key=lambda v: abs(v - median), reverse=True,
            )[:_MAX_BOX_OUTLIERS]
        stats.append({
            "group": None if pd.isna(name) else name,
            "count": int(len(vals)),
            "min": float(vals.min()),
            "max": float(vals.max()),
            "mean": round(float(vals.mean()), _NUMERIC_ROUND),
            "q1": round(q1, _NUMERIC_ROUND),
            "median": round(median, _NUMERIC_ROUND),
            "q3": round(q3, _NUMERIC_ROUND),
            "whisker_low": round(whisker_low, _NUMERIC_ROUND),
            "whisker_high": round(whisker_high, _NUMERIC_ROUND),
            "outliers": [round(float(v), _NUMERIC_ROUND) for v in outliers],
        })
    return stats


def _heatmap_pivot(
        df: pd.DataFrame,
        x_col: str,
        y_col: str,
        color_col: str | None,
) -> tuple[list[dict] | None, list[str], str | None]:
    """Pivot into an x x color matrix. Auto-picks a second categorical when
    color_col is blank. Returns (records, column_names_after_pivot, error).
    """
    if not color_col:
        for c in df.columns:
            if c in (x_col, y_col):
                continue
            if not pd.api.types.is_numeric_dtype(df[c]):
                color_col = c
                break
    if not color_col:
        return None, [], (
            "Heatmap requires a categorical color_column "
            "(or a second non-numeric column)."
        )
    try:
        pivot = df.pivot_table(
            index=x_col, columns=color_col, values=y_col,
            aggfunc="sum", fill_value=0,
        )
    except Exception as e:
        return None, [], f"Heatmap pivot failed: {e}"

    records: list[dict] = []
    for idx_val in pivot.index:
        row: dict[str, Any] = {x_col: idx_val}
        for col_name in pivot.columns:
            row[str(col_name)] = pivot.loc[idx_val, col_name]
        records.append(row)
    return records, [str(c) for c in pivot.columns], None


def _normalize_stacked(
        df: pd.DataFrame, x_col: str, y_cols: list[str],
) -> pd.DataFrame:
    """Scale each x group so its y_cols sum to 100 (for 100% stacked bar)."""
    if x_col not in df.columns:
        return df
    numeric_y = _numeric_cols(df, y_cols)
    if not numeric_y:
        return df
    out = df.copy()
    totals = out.groupby(x_col, dropna=False)[numeric_y].transform("sum").sum(axis=1)
    safe = totals.replace(0, pd.NA)
    for c in numeric_y:
        out[c] = (out[c] / safe) * 100.0
    return out


# ─────────────────────────────────────────────────────────────────────
# Metadata
# ─────────────────────────────────────────────────────────────────────

def _col_meta(df: pd.DataFrame) -> list[dict]:
    """Per-column type, cardinality, null ratio + numeric/date summary."""
    meta: list[dict] = []
    for col in df.columns:
        s = df[col]
        dtype = str(s.dtype)
        if "datetime" in dtype:
            kind = "datetime"
        elif pd.api.types.is_bool_dtype(s):
            kind = "boolean"
        elif pd.api.types.is_numeric_dtype(s):
            kind = "numeric"
        else:
            kind = "categorical"

        info: dict[str, Any] = {
            "name": col,
            "dtype": dtype,
            "kind": kind,
            "nunique": int(s.nunique(dropna=True)),
            "null_pct": round(float(s.isna().mean()) * 100.0, 2),
        }
        if kind == "numeric" and not s.dropna().empty:
            n = s.dropna()
            info.update({
                "min": round(float(n.min()), _NUMERIC_ROUND),
                "max": round(float(n.max()), _NUMERIC_ROUND),
                "mean": round(float(n.mean()), _NUMERIC_ROUND),
                "sum": round(float(n.sum()), _NUMERIC_ROUND),
            })
        elif kind == "datetime" and not s.dropna().empty:
            info.update({
                "min": pd.to_datetime(s.min()).isoformat(),
                "max": pd.to_datetime(s.max()).isoformat(),
            })
        meta.append(info)
    return meta


def _build_series(df: pd.DataFrame, y_cols: list[str]) -> list[dict]:
    """Describe each y series for the frontend (axis hints included)."""
    series: list[dict] = []
    for i, y in enumerate(y_cols):
        if y not in df.columns:
            continue
        kind = "numeric" if pd.api.types.is_numeric_dtype(df[y]) else "categorical"
        series.append({
            "name": y,
            "kind": kind,
            "axis": "right" if i >= 1 and len(y_cols) >= 2 else "left",
        })
    return series


# ─────────────────────────────────────────────────────────────────────
# Main: prepare_chart_data
# ─────────────────────────────────────────────────────────────────────

def prepare_chart_data(
        df: pd.DataFrame,
        chart_type: str,
        x_column: str,
        y_column: str,
        title: str,
        color_column: str = "",
        orientation: str = "v",
        threshold: float | None = None,
        threshold_label: str = "",
        y_columns: list[str] | None = None,
        aggregate: str = "auto",
        downsample: bool = True,
        normalize: bool = False,
        top_n: int | None = None,
) -> dict[str, Any]:
    """Prepare chart-ready data + spec for frontend rendering.

    Complex-data handling beyond the basic cleaner:
      - `y_columns` extends `y_column` into a multi-series chart.
      - `aggregate` auto-groups duplicate (x, color) rows.
      - `downsample=True` resamples dense datetime x to W/M/Q/Y.
      - `normalize=True` converts a stacked_bar to a 100% stacked.
      - `chart_type="pareto"` returns sorted bars + `cumulative_pct`.
      - Box plots return pre-computed stats so the FE doesn't re-bin.
      - Heatmap auto-selects a pivot column if none was given.

    Returns a dict with `error` on failure, or the chart payload on success.
    """
    notes: list[str] = []

    if df.empty:
        return {"error": "No data to visualise."}

    # ── Resolve column names (fuzzy) ──
    x_column = _resolve_column(df, x_column)
    y_column = _resolve_column(df, y_column)
    color_resolved = _resolve_column(df, color_column) if color_column else ""

    # Normalize y_columns (str | list | None) into a deduped list preserving order
    extra_y = [_resolve_column(df, c) for c in _as_list(y_columns)]
    all_y = [y for y in ([y_column] + extra_y) if y]
    seen: set[str] = set()
    all_y = [y for y in all_y if not (y in seen or seen.add(y))]
    extra_y = [y for y in all_y if y != y_column]

    missing = []
    if x_column and x_column not in df.columns:
        missing.append(f"x_column='{x_column}'")
    for y in all_y:
        if y not in df.columns:
            missing.append(f"y_column='{y}'")
    if missing:
        return {
            "error": (
                f"Column(s) not found: {', '.join(missing)}. "
                f"Available: {', '.join(df.columns.tolist())}"
            )
        }

    # ── Clean (drop nulls in x + primary y, coerce numerics) ──
    df = _clean_dataframe(df, x_column, y_column)
    if df.empty:
        return {"error": "No data remaining after cleaning (all nulls?)."}

    original_count = len(df)
    color = color_resolved if color_resolved and color_resolved in df.columns else None
    ct = (chart_type or "auto").lower().strip()
    bar_mode: str | None = None
    downsampled_to: str | None = None
    aggregated = False
    box_plot_stats: list[dict] = []
    heatmap_matrix_columns: list[str] = []

    # ── Auto-detect chart type ──
    if ct == "auto":
        ct, orientation = _auto_select_chart(df, x_column, y_column, orientation, color)
        if ct == "bar" and orientation == "h":
            x_column, y_column = y_column, x_column
            all_y = [y_column] + extra_y

    # ── Aggregation — only where stacking/summing makes sense ──
    if ct in ("bar", "stacked_bar", "grouped_bar", "line", "area", "combo", "pareto"):
        df, aggregated = _aggregate_duplicates(df, x_column, all_y, color, method=aggregate)
        if aggregated:
            color_note = f", {color}" if color else ""
            notes.append(f"aggregated duplicate ({x_column}{color_note}) rows")

    # ── Time-series downsampling for line/area/combo ──
    if (
        downsample
        and ct in ("line", "area", "combo")
        and len(df) > _MAX_POINTS_BEFORE_RESAMPLE
    ):
        df, downsampled_to = _resample_time_series(
            df, x_column, all_y, color, _MAX_POINTS_BEFORE_RESAMPLE,
        )
        if downsampled_to:
            notes.append(f"downsampled time series to {downsampled_to}")

    # ── Chart-type specific prep ──
    if ct in ("bar", "stacked_bar", "grouped_bar"):
        bar_mode = {
            "bar": "relative", "stacked_bar": "stack", "grouped_bar": "group",
        }[ct]
        value_col = x_column if orientation == "h" else y_column
        cat_col = y_column if orientation == "h" else x_column
        if not color and value_col in df.columns:
            df = _bucket_others(df, cat_col, value_col, top_n or _TOP_N_BAR)
            if pd.api.types.is_numeric_dtype(df[value_col]):
                df = _sort_bar_data(df, value_col, cat_col, orientation)
        if normalize and bar_mode == "stack" and len(all_y) >= 2:
            df = _normalize_stacked(df, x_column, all_y)
            bar_mode = "stack_100"
            notes.append("normalized stacked bars to 100%")
        ct = "bar"

    elif ct == "pareto":
        df = _pareto_transform(df, x_column, y_column)

    elif ct == "line":
        if x_column in df.columns and _is_date_column(df[x_column]):
            df[x_column] = pd.to_datetime(df[x_column])
            df = df.sort_values(x_column)

    elif ct in ("pie", "donut"):
        df = _bucket_others(df, x_column, y_column, top_n or _TOP_N_PIE)
        ct = "pie" if ct == "pie" else "donut"

    elif ct == "area":
        if x_column in df.columns and _is_date_column(df[x_column]):
            df[x_column] = pd.to_datetime(df[x_column])
            df = df.sort_values(x_column)

    elif ct == "box":
        box_plot_stats = _box_stats(df, x_column, y_column)

    elif ct == "heatmap":
        records, pivot_cols, err = _heatmap_pivot(df, x_column, y_column, color)
        if err:
            return {"error": err}
        df = pd.DataFrame(records)
        heatmap_matrix_columns = pivot_cols
        color = None  # consumed by the pivot

    elif ct == "combo":
        # Combo is dual-axis: either (bar + line via color_column) OR two y series
        if not color and len(all_y) < 2:
            return {
                "error": (
                    "combo chart requires either a color_column or a second "
                    "y column (pass y_columns=[secondary_col])."
                )
            }

    elif ct in ("scatter", "histogram", "funnel", "waterfall"):
        pass

    else:
        return {
            "error": (
                f"Unsupported chart_type '{chart_type}'. Use: auto, bar, "
                f"stacked_bar, grouped_bar, line, pie, donut, scatter, "
                f"histogram, area, box, funnel, waterfall, heatmap, combo, pareto."
            )
        }

    # ── Serialize datetimes + null-safe + round floats ──
    for col in df.columns:
        if pd.api.types.is_datetime64_any_dtype(df[col]):
            df[col] = df[col].dt.strftime("%Y-%m-%dT%H:%M:%S")
    df = df.where(pd.notna(df), None)
    df = _round_numeric(df)

    # ── Build response ──
    slug = re.sub(r"[^a-z0-9]+", "_", title.lower())[:40].strip("_") or "chart"
    chart_id = f"{slug}_{ct}"

    payload: dict[str, Any] = {
        "chart_url": f"frontend://{chart_id}",
        "chart_type": ct,
        "title": title,
        "x_column": x_column,
        "y_column": y_column,
        "y_columns": extra_y,
        "color_column": color or "",
        "orientation": orientation,
        "bar_mode": bar_mode,
        "threshold": threshold,
        "threshold_label": threshold_label or (
            f"Target: {threshold:,.1f}" if threshold is not None else ""
        ),
        "data": df.to_dict(orient="records"),
        "columns": _col_meta(df),
        "series": _build_series(df, all_y) if len(all_y) > 1 else [],
        "row_count": original_count,
        "row_count_after_prep": len(df),
        "aggregated": aggregated,
        "downsampled_to": downsampled_to,
        "notes": notes,
    }
    if box_plot_stats:
        payload["box_stats"] = box_plot_stats
    if heatmap_matrix_columns:
        payload["matrix_columns"] = heatmap_matrix_columns
    return payload


# ─────────────────────────────────────────────────────────────────────
# LangChain tool wrapper
# ─────────────────────────────────────────────────────────────────────

def make_chart_data_tool() -> list:
    """Return the frontend-renderable chart data tool."""

    @tool
    def create_visualization(
            data_json: str,
            chart_type: str,
            x_column: str,
            y_column: str,
            title: str,
            color_column: str = "",
            orientation: str = "v",
            threshold: float | None = None,
            threshold_label: str = "",
            y_columns: list[str] | None = None,
            aggregate: str = "auto",
            downsample: bool = True,
            normalize: bool = False,
            top_n: int | None = None,
    ) -> str:
        """Prepare chart-ready data for frontend rendering.

        Handles complex inputs natively — multi-series, duplicate rows, dense
        time series, 100% stacked, pareto, heatmap pivots, box-plot stats.

        Args:
            data_json       : TOON or JSON string from run_sql_query (expects a
                              'data' key or a raw list of records).
            chart_type      : auto | bar | stacked_bar | grouped_bar | line |
                              pie | donut | scatter | histogram | area | box |
                              funnel | waterfall | heatmap | combo | pareto
            x_column        : Column for X axis (or labels for pie).
            y_column        : Primary Y column. Use '' for histogram (x only).
            title           : Chart title.
            color_column    : Optional series/grouping column. For combo it's
                              the secondary Y column.
            orientation     : 'v' (default) or 'h' for bar/box.
            threshold       : Optional reference line value (e.g. SLA target).
            threshold_label : Label for the threshold line.
            y_columns       : Extra Y columns for multi-series charts. Left
                              axis is `y_column`; each extra goes on the right
                              axis (see `series[*].axis`).
            aggregate       : auto | sum | mean | max | min | median | none —
                              how to merge duplicate (x, color) rows before
                              plotting. 'auto' sums when duplicates exist.
            downsample      : When True (default), dense datetime line/area
                              charts are resampled to W/M/Q/Y to stay under
                              ~200 points.
            normalize       : For stacked_bar with 2+ y columns, scales each
                              x group so its bars sum to 100 (100% stacked).
            top_n           : Override top-N bucketing (default 15 bars / 8 pie).

        Returns:
            TOON payload with `chart_type`, `data`, `columns`, `series`,
            `row_count`, `aggregated`, `downsampled_to`, `notes`, and chart-
            specific extras (`box_stats`, `matrix_columns`, `bar_mode`).
            On error: TOON with an `error` key.
        """
        # ── Parse input data ──
        try:
            payload = json.loads(data_json)
        except (json.JSONDecodeError, TypeError):
            try:
                payload = toons.loads(data_json)
            except Exception:
                return toons.dumps({
                    "error": (
                        "Could not parse data_json. Pass the raw output from "
                        "run_sql_query."
                    ),
                })

        if not isinstance(payload, dict):
            payload = {"data": payload}

        records = payload.get("data", payload)
        if isinstance(records, dict) and "result" in records:
            records = records["result"]

        if not isinstance(records, list):
            return toons.dumps({
                "error": f"Expected a list of records, got {type(records).__name__}.",
            })
        if len(records) == 0:
            return toons.dumps({"error": "No records in data to visualise."})

        df = pd.DataFrame(records)
        result = prepare_chart_data(
            df=df,
            chart_type=chart_type,
            x_column=x_column,
            y_column=y_column,
            title=title,
            color_column=color_column,
            orientation=orientation,
            threshold=threshold,
            threshold_label=threshold_label,
            y_columns=y_columns,
            aggregate=aggregate,
            downsample=downsample,
            normalize=normalize,
            top_n=top_n,
        )
        if "error" in result:
            logger.warning("ChartData | error: {}", result["error"])
        return toons.dumps(result)

    return [create_visualization]
