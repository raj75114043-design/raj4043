# Unified pre-built SQL catalog from both aggregation JSONL files.
#
# The two JSONL files are parsed ONCE at module import and stored as Python
# dicts. Every accessor is an O(1) dict lookup — no file I/O, no parsing,
# no lazy-load state machine at runtime.
#
# JSONL remains the canonical edit source — restart the process to pick up
# changes. Source paths (fixed per business requirement):
#   - tools/kpi_aggregations_db_stable.jsonl   (source: "db")
#   - outputs/kpi_aggregations_gcl.jsonl       (source: "gcl")

from __future__ import annotations

import json
from pathlib import Path
from typing import Literal

from loguru import logger

Level = Literal["national", "region", "market", "gc"]
_VALID_LEVELS: tuple[str, ...] = ("national", "region", "market", "gc")

_REPO_ROOT = Path(__file__).resolve().parent.parent
_DB_JSONL = _REPO_ROOT / "tools" / "kpi_aggregations_db_stable.jsonl"
_GCL_JSONL = _REPO_ROOT / "outputs" / "kpi_aggregations_gcl.jsonl"


def _normalize(name: str) -> str:
    return (name or "").strip().lower()


def _build_catalog() -> tuple[dict[str, dict], dict[int, dict]]:
    """Parse both JSONL files and return (by_name, by_id) dicts.

    First occurrence wins when the same kpi_name appears in both files, so DB
    entries take precedence over GCL entries if there's overlap.
    """
    by_name: dict[str, dict] = {}
    by_id: dict[int, dict] = {}
    totals: dict[str, int] = {}

    for path, source_tag in ((_DB_JSONL, "db"), (_GCL_JSONL, "gcl")):
        if not path.exists():
            logger.warning("KPIAggCatalog | {} missing — skipped", path)
            totals[source_tag] = 0
            continue

        count = 0
        with path.open(encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError as e:
                    logger.warning("KPIAggCatalog | bad line in {}: {}", path.name, e)
                    continue

                rec.setdefault("source", source_tag)
                name_key = _normalize(rec.get("kpi_name", ""))
                if not name_key:
                    continue

                if name_key not in by_name:
                    by_name[name_key] = rec
                kpi_id = rec.get("kpi_id")
                if isinstance(kpi_id, int) and kpi_id not in by_id:
                    by_id[kpi_id] = rec
                count += 1
        totals[source_tag] = count

    logger.info(
        "KPIAggCatalog | loaded db={} gcl={} (unique names={})",
        totals.get("db", 0), totals.get("gcl", 0), len(by_name),
    )
    return by_name, by_id


# ── Parse at import. Runtime only sees Python dicts. ──────────────────
_BY_NAME, _BY_ID = _build_catalog()


def load_catalog() -> int:
    """No-op kept for callers that want to force-touch the module. Returns
    the number of unique KPI names indexed.
    """
    return len(_BY_NAME)


def get_record(kpi_name: str) -> dict | None:
    return _BY_NAME.get(_normalize(kpi_name))


def get_record_by_id(kpi_id: int) -> dict | None:
    return _BY_ID.get(kpi_id)


def list_names() -> list[str]:
    return [rec.get("kpi_name", "") for rec in _BY_NAME.values()]


def get_sql(kpi_name: str, level: str) -> dict | None:
    """Return {sql, months, validation_status, validation_error, kpi_id, source}
    for the given KPI at the given level, or None if missing.
    """
    rec = get_record(kpi_name)
    if not rec:
        return None
    level_data = rec.get("levels", {}).get(level)
    if not level_data or not level_data.get("sql"):
        return None

    validation = level_data.get("validation") or {}
    return {
        "kpi_id": rec.get("kpi_id"),
        "kpi_name": rec.get("kpi_name"),
        "source": rec.get("source", ""),
        "vertical": rec.get("vertical", ""),
        "level": level,
        "months": level_data.get("months"),
        "sql": level_data["sql"],
        "validation_status": validation.get("status", "unknown"),
        "validation_error": validation.get("error", ""),
    }


def available_levels(kpi_name: str) -> list[str]:
    """Return levels for which a non-empty SQL exists in the catalog."""
    rec = get_record(kpi_name)
    if not rec:
        return []
    return [
        lv for lv in _VALID_LEVELS
        if (rec.get("levels", {}).get(lv) or {}).get("sql")
    ]
