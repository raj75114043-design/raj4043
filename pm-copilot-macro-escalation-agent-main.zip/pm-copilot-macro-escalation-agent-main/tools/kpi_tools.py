# LangChain tools for the flat ReAct KPI analyst.
#
# Three tools the main agent calls:
#   - search_kpis(query, vertical)        -> LLM picks top matches, scored 1..10
#   - get_kpi_sqls(kpi_names, levels)     -> pre-built SQL from aggregation catalog
#   - batch_run_sqls(items)               -> parallel SQL execution, FULL results
#
# The matcher source (search_kpis) is kept separate from the SQL source
# (kpi_agg_catalog) per business decision: a matched KPI may not have pre-built
# SQL, in which case the agent falls back to sql_query / run_sql_python.

from __future__ import annotations

import concurrent.futures
import time
from typing import Any

import pandas as pd
import psycopg2
from langchain_core.tools import tool
from loguru import logger

from tools.chart_data_tool import prepare_chart_data
from tools.kpi_agg_catalog import (
    available_levels,
    get_record,
    get_sql,
)
from tools.langchain_tools import _chart_data_store, _llm_pick_chart_params
from tools.sql_query_tool import _conn as _sql_conn, _coerce, _FORBIDDEN

_DEFAULT_SQL_TIMEOUT = 600
_BATCH_MAX_WORKERS = 6
_CHART_MAX_WORKERS = 4
_CHART_MIN_ROWS = 2
_VALID_LEVELS = ("national", "region", "market", "gc")


# ─────────────────────────────────────────────────────────────────────
# search_kpis — wrapper over services.kpi_bootstrap.search_and_match_kpis
# ─────────────────────────────────────────────────────────────────────

@tool
def search_kpis(query: str, vertical: str = "") -> list[dict]:
    """Pick the most relevant KPIs for a user query using an LLM matcher.

    Returns a list of candidates sorted best-first, each with a `score` from
    1 (weak) to 10 (perfect match). Use these names verbatim when calling
    `get_kpi_sqls` or when writing SQL.

    Args:
        query: The user question or escalation description.
        vertical: Optional vertical filter (e.g. "NTM", "AHLOA", "MB"). Pass
                  empty string to search all verticals.
    """
    # Local import to avoid a circular import at module-load time.
    from services.kpi_bootstrap import search_and_match_kpis, bootstrap_kpi_embeddings

    try:
        bootstrap_kpi_embeddings()
    except Exception as e:
        logger.warning("search_kpis | bootstrap failed: {}", e)

    try:
        matches = search_and_match_kpis(query=query, vertical=vertical or "")
    except Exception as e:
        logger.error("search_kpis | matcher failed: {}", e)
        return [{"error": f"matcher failed: {e}"}]

    results: list[dict] = []
    for m in matches:
        distance = float(m.get("distance", 1.0))
        confidence = max(0.0, min(1.0, 1.0 - distance))
        score = max(1, min(10, round(confidence * 10)))
        results.append({
            "kpi_name": m.get("kpi_name", ""),
            "source": m.get("index", ""),      # "db" or "excel"
            "score": score,
            "confidence": round(confidence, 3),
            "reason": m.get("document", "")[:160],
            "has_prebuilt_sql": bool(available_levels(m.get("kpi_name", ""))),
        })
    return results


# ─────────────────────────────────────────────────────────────────────
# get_kpi_sqls — lookup pre-built SQL from the aggregation catalog
# ─────────────────────────────────────────────────────────────────────

@tool
def get_kpi_sqls(kpi_names: list[str], levels: list[str] | None = None) -> dict:
    """Fetch pre-built SQL for one or more KPIs at the requested levels.

    Pass the exact kpi_name values from `search_kpis`. Levels default to all
    four (national, region, market, gc) — pass a subset to scope tightly
    (e.g. ["market", "gc"] for a market-scoped query).

    Returns a dict with:
      - `results`: list of {kpi_name, source, vertical, levels: {level: {sql, months, validation_status, validation_error?}}}
      - `missing`: list of {kpi_name, reason} for KPIs not in the pre-built
                   catalog — the agent must fall back to output tables +
                   kpi_id JOIN (via sql_query / run_sql_python).
      - `skipped_levels`: list of {kpi_name, level, reason} for per-level gaps.

    The agent should ignore `validation_status == "error"` only when an
    alternative pre-built level exists; otherwise run the SQL anyway and
    surface any runtime error in the report.
    """
    if not isinstance(kpi_names, list) or not kpi_names:
        return {"error": "kpi_names must be a non-empty list."}

    req_levels = levels or list(_VALID_LEVELS)
    bad = [lv for lv in req_levels if lv not in _VALID_LEVELS]
    if bad:
        return {"error": f"invalid levels {bad}; allowed: {list(_VALID_LEVELS)}"}

    results: list[dict] = []
    missing: list[dict] = []
    skipped: list[dict] = []

    for name in kpi_names:
        rec = get_record(name)
        if not rec:
            missing.append({
                "kpi_name": name,
                "reason": "not in pre-built SQL catalog — use output tables + kpi_id JOIN",
            })
            continue

        level_map: dict[str, dict] = {}
        for lv in req_levels:
            sql_info = get_sql(name, lv)
            if not sql_info:
                skipped.append({
                    "kpi_name": rec.get("kpi_name"),
                    "level": lv,
                    "reason": "no pre-built SQL for this level",
                })
                continue
            level_map[lv] = {
                "sql": sql_info["sql"],
                "months": sql_info["months"],
                "validation_status": sql_info["validation_status"],
                "validation_error": sql_info["validation_error"] or None,
            }

        results.append({
            "kpi_name": rec.get("kpi_name"),
            "kpi_id": rec.get("kpi_id"),
            "source": rec.get("source", ""),
            "vertical": rec.get("vertical", ""),
            "levels": level_map,
        })

    return {
        "results": results,
        "missing": missing,
        "skipped_levels": skipped,
    }


# ─────────────────────────────────────────────────────────────────────
# batch_run_sqls — parallel executor, FULL results, no truncation
# ─────────────────────────────────────────────────────────────────────

def _run_one_sql(item: dict, timeout_seconds: int) -> dict:
    """Execute one pre-built SQL. Returns full rows + columns (no truncation)."""
    sql = (item.get("sql") or "").strip().rstrip(";")
    kpi_name = item.get("kpi_name", "")
    kpi_id = item.get("kpi_id")
    level = item.get("level", "")

    if not sql:
        return {
            "kpi_name": kpi_name, "kpi_id": kpi_id, "level": level,
            "status": "error", "error": "empty sql",
            "rows": [], "columns": [], "row_count": 0, "elapsed_ms": 0,
        }

    first_word = sql.split()[0].lower() if sql else ""
    if first_word in _FORBIDDEN:
        return {
            "kpi_name": kpi_name, "kpi_id": kpi_id, "level": level,
            "status": "error",
            "error": f"'{first_word.upper()}' not allowed — SELECT only",
            "rows": [], "columns": [], "row_count": 0, "elapsed_ms": 0,
        }

    statement_timeout_ms = max(1, int(timeout_seconds)) * 1000
    t0 = time.perf_counter()
    try:
        with _sql_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(f"SET statement_timeout = {statement_timeout_ms}")
                cur.execute(sql)
                raw_rows = cur.fetchall()
                columns = [d[0] for d in (cur.description or [])]
    except psycopg2.Error as e:
        elapsed_ms = int((time.perf_counter() - t0) * 1000)
        return {
            "kpi_name": kpi_name, "kpi_id": kpi_id, "level": level,
            "status": "error", "error": f"DB Error: {e}",
            "rows": [], "columns": [], "row_count": 0,
            "elapsed_ms": elapsed_ms,
        }
    except Exception as e:
        elapsed_ms = int((time.perf_counter() - t0) * 1000)
        return {
            "kpi_name": kpi_name, "kpi_id": kpi_id, "level": level,
            "status": "error", "error": f"Unexpected error: {e}",
            "rows": [], "columns": [], "row_count": 0,
            "elapsed_ms": elapsed_ms,
        }

    elapsed_ms = int((time.perf_counter() - t0) * 1000)
    rows = [
        {col: _coerce(val) for col, val in zip(columns, row)}
        for row in raw_rows
    ]
    return {
        "kpi_name": kpi_name, "kpi_id": kpi_id, "level": level,
        "status": "success",
        "rows": rows, "columns": columns, "row_count": len(rows),
        "elapsed_ms": elapsed_ms,
    }


_DATEISH_HINTS = ("date", "month", "week", "year", "period", "time", "_at")


def _heuristic_chart_params(rows: list[dict], kpi_name: str, level: str) -> dict | None:
    """Deterministic chart params from row schema. Handles ~90% of KPI
    aggregations without an LLM call. Returns None only if no numeric column
    can be found.
    """
    cols = list(rows[0].keys())
    numeric_cols: list[str] = []
    text_cols: list[str] = []
    date_cols: list[str] = []

    for c in cols:
        sample = next((r.get(c) for r in rows if r.get(c) is not None), None)
        if isinstance(sample, bool):
            text_cols.append(c)
        elif isinstance(sample, (int, float)):
            numeric_cols.append(c)
        else:
            text_cols.append(c)
        if any(h in c.lower() for h in _DATEISH_HINTS):
            date_cols.append(c)

    if not numeric_cols:
        return None

    # Prefer the numeric column that best matches the KPI name; otherwise
    # the column with the largest spread (most informative axis).
    y_column = numeric_cols[0]
    if len(numeric_cols) > 1:
        kpi_low = kpi_name.lower()
        kpi_tokens = [t for t in kpi_low.replace("_", " ").split() if len(t) > 2]
        scored = [
            (c, sum(1 for t in kpi_tokens if t in c.lower()))
            for c in numeric_cols
        ]
        scored.sort(key=lambda t: t[1], reverse=True)
        y_column = scored[0][0] if scored[0][1] else numeric_cols[0]

    if date_cols:
        x_column = date_cols[0]
        chart_type = "line"
    elif text_cols:
        # Pick the text column with the most distinct values (best x-axis)
        x_column = max(
            text_cols,
            key=lambda c: len({r.get(c) for r in rows if r.get(c) is not None}),
        )
        chart_type = "bar"
    else:
        # All numeric (rare) — bar with index
        x_column = numeric_cols[0]
        y_column = numeric_cols[1] if len(numeric_cols) > 1 else numeric_cols[0]
        chart_type = "bar"

    # Optional color: a second text column with low cardinality (≤8 distinct)
    color_column = ""
    other_text = [c for c in text_cols if c != x_column]
    for c in other_text:
        distinct = len({r.get(c) for r in rows if r.get(c) is not None})
        if 2 <= distinct <= 8:
            color_column = c
            break

    title_bits = [y_column.replace("_", " ").title(), "by", x_column.replace("_", " ").title()]
    if level:
        title_bits.append(f"({level})")
    title = " ".join(title_bits)

    return {
        "chart_type": chart_type,
        "x_column": x_column,
        "y_column": y_column,
        "color_column": color_column,
        "title": title,
    }


def _build_one_chart(result: dict) -> dict | None:
    """Generate one chart payload from a successful batch_run_sqls result.

    Tries the deterministic heuristic first; falls back to the LLM picker only
    when the heuristic can't choose. Logs the reason on every skip.
    """
    tag = f"{result.get('kpi_name', '?')}/{result.get('level', '?')}"
    rows = result.get("rows") or []

    if len(rows) < _CHART_MIN_ROWS:
        logger.info("chart skip [{}] rows={} (min {})", tag, len(rows), _CHART_MIN_ROWS)
        return None
    if not isinstance(rows[0], dict):
        logger.info("chart skip [{}] rows[0] not a dict", tag)
        return None

    kpi_name = result.get("kpi_name", "")
    level = result.get("level", "")
    sql_text = result.get("_sql", "")

    params = _heuristic_chart_params(rows, kpi_name, level)
    picker_used = "heuristic"
    if not params:
        try:
            params = _llm_pick_chart_params(rows, sql_text)
            picker_used = "llm"
        except Exception as e:
            logger.warning("chart skip [{}] LLM picker raised: {}", tag, e)
            return None
        if not params:
            logger.warning("chart skip [{}] no numeric column + LLM picker returned None", tag)
            return None

    try:
        df = pd.DataFrame(rows)
        chart = prepare_chart_data(
            df=df,
            chart_type=params.get("chart_type", "auto"),
            x_column=params.get("x_column", ""),
            y_column=params.get("y_column", ""),
            title=params.get("title", ""),
            color_column=params.get("color_column", ""),
        )
    except Exception as e:
        logger.warning("chart skip [{}] prepare raised: {} | params={}", tag, e, params)
        return None

    if not isinstance(chart, dict) or "error" in chart:
        err = chart.get("error", "unknown") if isinstance(chart, dict) else "non-dict"
        logger.warning("chart skip [{}] prepare returned error ({}): {} | params={}",
                       tag, picker_used, err, params)
        return None

    chart["kpi_name"] = kpi_name
    chart["level"] = level
    chart["picker"] = picker_used
    return chart


def _generate_charts(results: list[dict]) -> int:
    """Spawn LLM-backed chart generation in parallel; push payloads to the
    shared _chart_data_store. Returns the count of charts produced.
    """
    candidates = [r for r in results if r and r.get("status") == "success"]
    if not candidates:
        logger.info("chart pass | no successful results to chart")
        return 0

    logger.info("chart pass | {} candidates", len(candidates))
    produced = 0
    with concurrent.futures.ThreadPoolExecutor(max_workers=_CHART_MAX_WORKERS) as pool:
        for chart in pool.map(_build_one_chart, candidates):
            if chart is not None:
                _chart_data_store.append(chart)
                produced += 1
    logger.info("chart pass | produced {}/{}", produced, len(candidates))
    return produced


def _coerce_batch_items(
        items: Any = None,
        sqls: Any = None,
        queries: Any = None,
        tool_uses: Any = None,
) -> list[dict]:
    """Pick the first non-empty items list across common aliases.

    Some LLM gateways wrap tool calls in the Anthropic `tool_uses` envelope:
      {"tool_uses": [{"recipient_name": "...", "parameters": {"items"|"sqls": [...]}}]}
    Others rename `items` to `sqls` / `queries`. Accept all and normalize.
    """
    if isinstance(tool_uses, list) and tool_uses:
        first = tool_uses[0] if isinstance(tool_uses[0], dict) else {}
        params = first.get("parameters") or first.get("arguments") or {}
        if isinstance(params, dict):
            for key in ("items", "sqls", "queries", "batch"):
                val = params.get(key)
                if isinstance(val, list) and val:
                    return val
    for candidate in (items, sqls, queries):
        if isinstance(candidate, list) and candidate:
            return candidate
    return []


@tool
def batch_run_sqls(
        items: list[dict] | None = None,
        timeout_seconds: int = _DEFAULT_SQL_TIMEOUT,
        generate_charts: bool = True,
        **kwargs: Any,
) -> dict:
    """Execute many SQLs in parallel and return FULL results (no truncation).

    Every item must be a dict with at least `sql`. Include `kpi_name`,
    `kpi_id`, `level` so the agent can key results back. Typical flow:

        sqls = get_kpi_sqls(["KPI A"], ["national", "region"])
        batch = []
        for r in sqls["results"]:
            for lv, info in r["levels"].items():
                batch.append({
                    "kpi_name": r["kpi_name"],
                    "kpi_id": r["kpi_id"],
                    "level": lv,
                    "sql": info["sql"],
                })
        batch_run_sqls(batch)

    Set `generate_charts=False` to skip the LLM chart-pick post-pass (e.g. for
    quick metadata pulls). Default is True — charts are pushed to the shared
    chart store and surfaced to the FE in the response payload.

    Returns:
      {"results": [{kpi_name, kpi_id, level, status, rows, columns,
                    row_count, elapsed_ms, error?}, ...],
       "success_count": int, "error_count": int, "charts_generated": int}
    """
    items = _coerce_batch_items(
        items=items,
        sqls=kwargs.get("sqls"),
        queries=kwargs.get("queries"),
        tool_uses=kwargs.get("tool_uses"),
    )
    if kwargs:
        unused = [k for k in kwargs if k not in ("sqls", "queries", "tool_uses")]
        if unused:
            logger.warning("batch_run_sqls | ignoring unexpected kwargs: {}", unused)
    if not items:
        return {"error": "items must be a non-empty list"}

    logger.info("batch_run_sqls | dispatching {} queries", len(items))

    out: list[dict | None] = [None] * len(items)
    with concurrent.futures.ThreadPoolExecutor(max_workers=_BATCH_MAX_WORKERS) as pool:
        futs = {
            pool.submit(_run_one_sql, item, timeout_seconds): idx
            for idx, item in enumerate(items)
        }
        for fut in concurrent.futures.as_completed(futs):
            idx = futs[fut]
            try:
                result = fut.result()
                # Stash sql text on the result for the chart picker.
                result["_sql"] = items[idx].get("sql", "")
                out[idx] = result
            except Exception as e:
                item = items[idx]
                out[idx] = {
                    "kpi_name": item.get("kpi_name", ""),
                    "kpi_id": item.get("kpi_id"),
                    "level": item.get("level", ""),
                    "status": "error", "error": f"executor error: {e}",
                    "rows": [], "columns": [], "row_count": 0, "elapsed_ms": 0,
                }

    success = sum(1 for r in out if r and r.get("status") == "success")
    errors = sum(1 for r in out if r and r.get("status") == "error")

    charts_generated = 0
    if generate_charts:
        try:
            charts_generated = _generate_charts([r for r in out if r is not None])
        except Exception as e:
            logger.warning("batch_run_sqls | chart generation failed: {}", e)

    # Strip the internal _sql field from the response payload.
    final_results: list[dict] = []
    for r in out:
        if r is None:
            continue
        r.pop("_sql", None)
        final_results.append(r)

    logger.info("batch_run_sqls | done | success={} error={} charts={}",
                success, errors, charts_generated)

    return {
        "results": final_results,
        "success_count": success,
        "error_count": errors,
        "charts_generated": charts_generated,
    }


# ─────────────────────────────────────────────────────────────────────
# Plain-Python helpers (for direct use in agent wiring, not via ReAct)
# ─────────────────────────────────────────────────────────────────────

def batch_run_sqls_direct(items: list[dict], timeout_seconds: int = _DEFAULT_SQL_TIMEOUT) -> dict:
    """Non-tool version of batch_run_sqls for internal callers."""
    return batch_run_sqls.invoke({"items": items, "timeout_seconds": timeout_seconds})
