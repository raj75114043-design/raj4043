
# Python Sandbox tool for executing data analysis code.
# Used by the Traversal Agent and Response Agent for calculations,
# SQL queries, and data analysis against PostgreSQL.
#
# Safety model: The DB connection is READ-ONLY (enforced at Postgres level).
# The sandbox blocks file-system access and arbitrary OS commands but is
# otherwise permissive so agents can run any analytical Python/pandas/numpy
# code without hitting false-positive validation errors.
from __future__ import annotations

import ast
import time
from loguru import logger
import traceback
from typing import Any
from io import StringIO
import contextlib
import math
import json
import statistics
import re
import decimal
import warnings

import psycopg2
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
import sqlglot
import concurrent.futures
import config


# ── Import allow-list ─────────────────────────────────────────────────────────
# Modules that agent-generated code may import at runtime.
# Only truly dangerous modules (os, subprocess, socket, etc.) are blocked;
# everything useful for data analysis is allowed.

ALLOWED_IMPORT_MODULES = {
    # math / stats
    "math", "statistics", "decimal", "fractions", "random",
    # data structures
    "collections", "heapq", "bisect", "operator", "copy",
    # date / time
    "datetime", "calendar", "time", "zoneinfo",
    # strings / text
    "re", "string", "textwrap", "unicodedata", "difflib",
    # itertools / functools
    "itertools", "functools", "contextlib",
    # serialization
    "json", "csv", "io", "toons",
    # typing / abc
    "typing", "abc", "dataclasses", "enum",
    # hashing (useful for dedup)
    "hashlib", "uuid",
    # data-science stack (pre-imported but agents may still write import lines)
    "numpy", "pandas", "plotly", "psycopg2",
    # SQL parsing
    "sqlglot",
    # warnings suppression (pandas emits many)
    "warnings", "pprint"
}

# ── Blocked builtins ──────────────────────────────────────────────────────────
# Only block things that could escape the sandbox or cause damage.
# getattr/setattr/delattr are needed by pandas/numpy internals.
BLOCKED_BUILTINS = {
    "exec", "eval", "compile", "open",
    "breakpoint", "exit", "quit",
    "__import__",
}

# ── Pre-injected modules for the basic (non-SQL) sandbox ──────────────────────
SAFE_MODULES = {
    "math": math,
    "json": json,
    "statistics": statistics,
    "numpy": np,
    "pandas": pd,
    "re": re,
    "decimal": decimal,
}

# Limits
_MAX_STDOUT_CHARS = 50_000
_DEFAULT_TIMEOUT_SEC = 30


def _normalize_code(code: str) -> str:
    """Fix code strings where the LLM sent literal backslash-n instead of real newlines.

    gpt-5 (and other models) sometimes emit code as a single line with escaped
    ``\\n`` / ``\\t`` sequences.  ``ast.parse`` chokes on these because Python
    sees ``\\`` as a line-continuation character followed by ``n``, which is
    invalid syntax.  This function converts the common escape sequences back to
    real whitespace so the rest of the pipeline works normally.
    """
    # Only fix if the code looks like it has literal \n but no real newlines
    if "\n" not in code and "\\n" in code:
        code = code.replace("\\n", "\n").replace("\\t", "\t")
    return code


def _safe_import(name, globals=None, locals=None, fromlist=(), level=0):
    """Restricted __import__ that only allows whitelisted modules."""
    top_level = name.split(".")[0]
    if top_level not in ALLOWED_IMPORT_MODULES:
        raise ImportError(
            f"Import of '{name}' is not allowed. "
            f"Available: {', '.join(sorted(ALLOWED_IMPORT_MODULES))}"
        )
    return (__builtins__["__import__"](name, globals, locals, fromlist, level)
            if isinstance(__builtins__, dict)
            else __builtins__.__dict__["__import__"](name, globals, locals, fromlist, level))


# ── Blocked AST patterns (modules that could escape the sandbox) ─────────────
_DANGEROUS_MODULES = {
    "os", "sys", "subprocess", "shutil", "signal", "socket",
    "http", "urllib", "requests", "pathlib", "glob",
    "multiprocessing", "threading", "ctypes", "importlib",
    "code", "codeop", "compileall", "py_compile",
    "webbrowser", "antigravity", "turtle",
    "pickle", "shelve", "marshal",
}


def _validate_code(code: str) -> tuple[bool, str]:
    """Validate code for syntax and basic safety.

    Keeps validation minimal to avoid false positives. Blocks:
    - Syntax errors
    - Imports of dangerous modules (os, subprocess, etc.)
    - Unbounded while-True loops without break
    - Direct calls to exec/eval/compile/open
    """
    # Phase 1: syntax check
    # Suppress SyntaxWarning for invalid escape sequences (e.g. "\s" in regex)
    # — LLM-generated code often writes "\s" instead of r"\s" or "\\s".
    # The code still works; the warning is just noise.
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", SyntaxWarning)
            tree = ast.parse(code)
    except SyntaxError as e:
        return False, f"Syntax error at line {e.lineno}: {e.msg}"

    # Phase 2: compile check (catches f-string errors, etc.)
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", SyntaxWarning)
            compile(code, "<sandbox>", "exec")
    except SyntaxError as e:
        return False, f"Compile error at line {e.lineno}: {e.msg}"

    # Phase 3: targeted safety checks
    for node in ast.walk(tree):
        # Block imports of dangerous modules
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            module = ""
            if isinstance(node, ast.ImportFrom) and node.module:
                module = node.module.split(".")[0]
            elif isinstance(node, ast.Import):
                module = node.names[0].name.split(".")[0]

            if module in _DANGEROUS_MODULES:
                return False, (
                    f"Import of '{module}' is not allowed (security). "
                    f"If you need this for analysis, use the pre-imported libraries."
                )

        # Block direct calls to exec/eval/compile/open by name
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id in BLOCKED_BUILTINS:
                return False, f"Call to '{node.func.id}' is not allowed in sandbox."

        # Detect unbounded while loops (while True / while 1 with no break)
        if isinstance(node, ast.While):
            test = node.test
            is_constant_true = (
                (isinstance(test, ast.Constant) and test.value)
                or (isinstance(test, ast.NameConstant) and test.value)  # py3.7
            )
            if is_constant_true:
                has_break = any(isinstance(n, ast.Break) for n in ast.walk(node))
                if not has_break:
                    return False, "Unbounded 'while True' loop without break is not allowed."

    return True, "OK"


def _cap_stdout(captured: str) -> str:
    """Truncate stdout to prevent context overflow."""
    if len(captured) <= _MAX_STDOUT_CHARS:
        return captured
    return captured[:_MAX_STDOUT_CHARS] + f"\n... (stdout truncated at {_MAX_STDOUT_CHARS} chars)"


def _clean_traceback(tb: str) -> str:
    """Strip internal file paths from tracebacks so they're safe for LLM consumption."""
    lines = []
    for line in tb.splitlines():
        if 'File "<sandbox>"' in line or not line.strip().startswith("File "):
            lines.append(line)
    return "\n".join(lines) if lines else tb


def _normalize_result(result: Any) -> Any:
    """Convert DataFrames, Series, and other analytical types to JSON-safe types."""
    if result is None:
        return None
    if isinstance(result, pd.DataFrame):
        return result.to_dict(orient="records")
    if isinstance(result, pd.Series):
        return result.to_dict()
    if isinstance(result, (pd.Timestamp, pd.Timedelta)):
        return str(result)
    if isinstance(result, np.integer):
        return int(result)
    if isinstance(result, np.floating):
        return float(result)
    if isinstance(result, np.bool_):
        return bool(result)
    if isinstance(result, np.ndarray):
        return result.tolist()
    if isinstance(result, decimal.Decimal):
        return float(result)
    if isinstance(result, (set, frozenset)):
        return list(result)
    if isinstance(result, tuple):
        return list(result)
    if isinstance(result, dict):
        return {str(k): _normalize_result(v) for k, v in result.items()}
    if isinstance(result, list):
        return [_normalize_result(v) for v in result]
    # Catch-all for datetime and other stringifiable types
    try:
        json.dumps(result)
        return result
    except (TypeError, ValueError):
        return str(result)


def _detect_auto_capture(code: str) -> tuple[str, bool]:
    """Check if last line is a bare expression that can be auto-captured as result."""
    lines = code.strip().splitlines()
    last_line = lines[-1].strip() if lines else ""
    if not last_line:
        return last_line, False

    _NON_CAPTURE_PREFIXES = (
        "result", "#", "print", "import", "from", "if ", "for ",
        "while ", "def ", "class ", "return", "try", "except", "with ",
        "raise", "assert", "del ", "pass", "break", "continue",
    )
    if any(last_line.startswith(k) for k in _NON_CAPTURE_PREFIXES):
        return last_line, False

    try:
        ast.parse(last_line, mode="eval")
        return last_line, True
    except SyntaxError:
        return last_line, False


def _build_safe_builtins() -> dict:
    """Build a builtins dict that blocks only truly dangerous functions."""
    builtins_dict = __builtins__.__dict__ if hasattr(__builtins__, "__dict__") else __builtins__
    safe = {k: v for k, v in builtins_dict.items() if k not in BLOCKED_BUILTINS}
    safe["__import__"] = _safe_import
    return safe


def execute_python(code: str, context: dict[str, Any] | None = None) -> dict:
    """
    Execute Python code in a sandbox (no DB access).

    Args:
        code: Python code string
        context: Variables to inject into the execution namespace

    Returns:
        dict with status, output (stdout), result (last expression), error
    """
    code = _normalize_code(code)
    is_safe, reason = _validate_code(code)
    if not is_safe:
        logger.warning("Sandbox:execute_python | validation failed: {}", reason)
        return {
            "status": "error",
            "error": f"Code validation failed: {reason}",
            "output": "",
            "result": None,
        }
    logger.debug("Sandbox:execute_python | validation passed | code_len={}", len(code))

    namespace = {
        "__builtins__": _build_safe_builtins(),
        **SAFE_MODULES,
        "np": np,
        "pd": pd,
    }

    if context:
        namespace.update(context)

    stdout_capture = StringIO()
    last_line, auto_capture = _detect_auto_capture(code)

    def _run():
        with contextlib.redirect_stdout(stdout_capture):
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", SyntaxWarning)
                exec(code, namespace)  # noqa: S102

    start = time.perf_counter()
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(_run)
            future.result(timeout=_DEFAULT_TIMEOUT_SEC)

        elapsed_ms = (time.perf_counter() - start) * 1000

        result = namespace.get("result", None)

        if result is None and auto_capture:
            try:
                result = eval(last_line, namespace)  # noqa: S307
            except Exception:
                pass

        if result is None and stdout_capture.getvalue().strip():
            result = stdout_capture.getvalue().strip()

        result = _normalize_result(result)

        return {
            "status": "success",
            "output": _cap_stdout(stdout_capture.getvalue()),
            "result": result,
            "elapsed_ms": round(elapsed_ms, 2),
        }

    except concurrent.futures.TimeoutError:
        elapsed_ms = (time.perf_counter() - start) * 1000
        return {
            "status": "error",
            "error": f"Execution timed out after {_DEFAULT_TIMEOUT_SEC}s. "
                     f"Try adding LIMIT to SQL or reducing data size.",
            "output": _cap_stdout(stdout_capture.getvalue()),
            "result": None,
            "elapsed_ms": round(elapsed_ms, 2),
        }
    except Exception as e:
        elapsed_ms = (time.perf_counter() - start) * 1000
        return {
            "status": "error",
            "error": f"{type(e).__name__}: {e}",
            "traceback": _clean_traceback(traceback.format_exc()),
            "output": _cap_stdout(stdout_capture.getvalue()),
            "result": None,
            "elapsed_ms": round(elapsed_ms, 2),
        }


# ── PostgreSQL-backed sandbox ────────────────────────────────────────────────

class PythonSandbox:
    """
    PostgreSQL-backed execution sandbox for data analysis.

    Provides `conn` (psycopg2, read-only), `pd`, `np`, `go`, `px`, `json`,
    `re`, `warnings`, and `execute_query` helper in the execution namespace.
    User code sets a `result` variable to return structured data.

    Safety: The DB connection uses `default_transaction_read_only=on` at the
    Postgres level, so no DML/DDL can execute regardless of what code runs.
    """

    def __init__(self):
        self.conn = None
        self.session_vars = {}
        self._connect()

    def _connect(self):
        """Lazily connect to Postgres. Gracefully handles missing DB."""
        if self.conn is not None:
            return
        try:
            self.conn = psycopg2.connect(
                host=config.PG_HOST,
                port=config.PG_PORT,
                database=config.PG_DATABASE,
                user=config.PG_USER,
                password=config.PG_PASSWORD,
                options="-c default_transaction_read_only=on",
            )
            self.conn.autocommit = True
        except Exception as e:
            logger.warning("Postgres not available: {}", e)
            self.conn = None

    def _ensure_conn(self):
        """Reconnect if connection was lost or closed."""
        if self.conn is not None:
            try:
                with self.conn.cursor() as cur:
                    cur.execute("SELECT 1")
            except Exception:
                logger.warning("Postgres connection stale - reconnecting")
                try:
                    self.conn.close()
                except Exception:
                    pass
                self.conn = None
        if self.conn is None:
            self._connect()
        if self.conn is None:
            raise ConnectionError(
                "Cannot connect to PostgreSQL. Check PG_HOST/PG_PORT/PG_DATABASE "
                "in config. Use run_python for non-DB calculations."
            )

    def _is_raw_sql(self, code: str) -> bool:
        """Detect if code is raw SQL rather than Python using sqlglot."""
        try:
            stmts = sqlglot.parse(code, error_level=sqlglot.ErrorLevel.IGNORE)
            if not stmts or stmts[0] is None:
                return False
            # If sqlglot parsed at least one statement and the first is a
            # SELECT / UNION / WITH / EXPLAIN, treat as raw SQL.
            first = stmts[0]
            return first.key in ("select", "union", "intersect", "except", "with", "command")
        except Exception:
            # Fallback: simple prefix check
            first_line = code.strip().split("\n")[0].strip().rstrip(";").upper()
            return first_line.startswith(("SELECT ", "WITH ", "EXPLAIN "))

    @staticmethod
    def _validate_sql_readonly(sql: str) -> tuple[bool, str]:
        """Use sqlglot to verify that a SQL string contains only read-only statements.

        Returns (is_safe, reason). Blocks INSERT, UPDATE, DELETE, DROP, CREATE,
        ALTER, TRUNCATE, GRANT, REVOKE, and similar write operations.
        """
        _WRITE_TYPES = {
            "insert", "update", "delete", "drop", "create", "alter",
            "truncate", "grant", "revoke", "merge", "copy",
        }
        try:
            stmts = sqlglot.parse(sql, error_level=sqlglot.ErrorLevel.IGNORE)
            for stmt in stmts:
                if stmt is None:
                    continue
                if stmt.key in _WRITE_TYPES:
                    return False, (
                        f"Write operation '{stmt.key.upper()}' is not allowed. "
                        f"This is a read-only connection — only SELECT queries are permitted."
                    )
            return True, "OK"
        except Exception:
            # If sqlglot can't parse it, let Postgres enforce read-only
            return True, "OK"

    def execute(self, code: str, timeout_seconds: int = 30) -> dict:
        """Execute Python/SQL code with access to a read-only PostgreSQL connection.

        The namespace includes: conn, pd, np, go, px, json, re, warnings,
        sqlglot, execute_query, math, statistics, and session (persistent dict).

        Set `result = <value>` to return data. DataFrames and Series are
        auto-converted to dicts/records. If no result is set, the last
        expression or stdout is captured as fallback.
        """
        try:
            self._ensure_conn()
        except ConnectionError as e:
            return {"status": "error", "error": str(e)}

        code = _normalize_code(code)

        # Auto-wrap raw SQL so exec() doesn't choke on it
        if self._is_raw_sql(code):
            # Validate raw SQL is read-only before wrapping
            is_safe, reason = self._validate_sql_readonly(code)
            if not is_safe:
                logger.warning("Sandbox:PythonSandbox | SQL blocked: {}", reason)
                return {"status": "error", "error": reason}
            # Use a raw string variable to avoid triple-quote escaping issues
            code = (
                f"_sql = {repr(code)}\n"
                f"result = pd.read_sql(_sql, conn).to_dict(orient='records')"
            )

        # Pre-validate syntax and safety
        is_safe, reason = _validate_code(code)
        if not is_safe:
            logger.warning("Sandbox:PythonSandbox | validation failed: {}", reason)
            return {"status": "error", "error": f"Code validation failed: {reason}"}
        logger.debug("Sandbox:PythonSandbox | validation passed | code_len={} | is_raw_sql={}", len(code), False)

        def _execute_query(sql, params=None, db=None, max_rows=None):
            """Helper: run SQL and return list[dict] (not a DataFrame)."""
            df = pd.read_sql(sql, self.conn, params=params)
            if max_rows is not None:
                df = df.head(max_rows)
            return df.to_dict(orient="records")

        stdout_capture = StringIO()

        namespace = {
            "__builtins__": _build_safe_builtins(),
            "conn": self.conn,
            "pd": pd,
            "np": np,
            "go": go,
            "px": px,
            "json": json,
            "re": re,
            "math": math,
            "statistics": statistics,
            "warnings": warnings,
            "sqlglot": sqlglot,
            "execute_query": _execute_query,
            "session": self.session_vars,
            "result": None,
        }

        last_line, auto_capture = _detect_auto_capture(code)

        def _run():
            with contextlib.redirect_stdout(stdout_capture):
                # Suppress noisy pandas/psycopg2 warnings and LLM-generated
                # invalid escape sequences ("\s" instead of r"\s") inside sandbox
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore", category=UserWarning)
                    warnings.simplefilter("ignore", category=SyntaxWarning)
                    exec(code, namespace)  # noqa: S102
            return namespace

        start = time.perf_counter()
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
                future = executor.submit(_run)
                try:
                    result_ns = future.result(timeout=timeout_seconds)
                except concurrent.futures.TimeoutError:
                    raise TimeoutError(
                        f"Execution timed out after {timeout_seconds}s. "
                        f"Add LIMIT to your SQL query or reduce the dataset."
                    )

            elapsed_ms = (time.perf_counter() - start) * 1000

            if "session" in result_ns:
                self.session_vars = result_ns["session"]

            result = result_ns.get("result", None)

            # Auto-capture: if no result set, try to capture last expression
            if result is None and auto_capture:
                try:
                    result = eval(last_line, result_ns)  # noqa: S307
                except Exception:
                    pass

            # Fallback: capture stdout as result
            if result is None and stdout_capture.getvalue().strip():
                result = stdout_capture.getvalue().strip()

            result = _normalize_result(result)

            # Warn on empty results to help the agent self-correct
            if result is None or result == {} or result == []:
                stdout_val = stdout_capture.getvalue().strip()
                if not stdout_val:
                    return {
                        "status": "success",
                        "result": result if result is not None else {},
                        "elapsed_ms": round(elapsed_ms, 2),
                        "empty_result_warning": (
                            "No data returned. Possible causes: "
                            "(1) WHERE clause too restrictive - try removing filters. "
                            "(2) Wrong table/column name - verify with "
                            "SELECT column_name FROM information_schema.columns "
                            "WHERE table_name='...' "
                            "(3) result variable not set - end code with result = <value>."
                        ),
                    }

            response = {
                "status": "success",
                "result": result,
                "elapsed_ms": round(elapsed_ms, 2),
            }
            stdout_val = stdout_capture.getvalue()
            if stdout_val.strip():
                response["output"] = _cap_stdout(stdout_val)
            return response

        except Exception as e:
            elapsed_ms = (time.perf_counter() - start) * 1000
            error_msg = f"{type(e).__name__}: {e}"

            # Add actionable hints for common errors
            hints = []
            err_str = str(e).lower()
            if "relation" in err_str and "does not exist" in err_str:
                hints.append(
                    "Table not found. Use schema prefix: "
                    "pwc_macro_staging_schema.<table_name> "
                    "(or public.<table_name> for gc_capacity)."
                )
            elif "column" in err_str and "does not exist" in err_str:
                hints.append(
                    "Column not found. Verify columns with: "
                    "SELECT column_name FROM information_schema.columns "
                    "WHERE table_name='<table>';"
                )
            elif "permission denied" in err_str or "read-only" in err_str:
                hints.append("This is a read-only connection. Only SELECT queries are allowed.")
            elif "connection" in err_str or "closed" in err_str:
                hints.append("Database connection lost. Retry the query - it will auto-reconnect.")
                # Reset connection so next call reconnects
                try:
                    self.conn.close()
                except Exception:
                    pass
                self.conn = None
            elif "timeout" in err_str:
                hints.append("Query too slow. Add LIMIT, use aggregations, or narrow WHERE clause.")

            return {
                "status": "error",
                "error": error_msg,
                "traceback": _clean_traceback(traceback.format_exc()),
                "output": _cap_stdout(stdout_capture.getvalue()),
                "elapsed_ms": round(elapsed_ms, 2),
                **({"hints": hints} if hints else {}),
            }

    def close(self):
        if self.conn:
            self.conn.close()