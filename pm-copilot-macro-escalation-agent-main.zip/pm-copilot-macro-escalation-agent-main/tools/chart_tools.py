"""
tools/chart_tools.py
---------------------
Plotly chart generation tool for the Data Analyst sub-agent.
One tool: create_visualization
  - Accepts query results (TOON or JSON string from run_sql_query)
  - Accepts chart_type, axis column names, and a title
  - Renders an interactive Plotly figure
  - Saves it as self-contained HTML to outputs/charts/
  - Returns the saved file path

Supported chart types
---------------------
  bar | stacked_bar | grouped_bar | line | pie | donut | scatter |
  histogram | area | box | funnel | heatmap | waterfall | auto

Smart features
--------------
  - Column name fuzzy matching (tolerates case/whitespace mismatches)
  - Auto data cleaning (nulls, duplicates, type coercion)
  - Pie/donut auto-bucketing: groups small slices into "Others" when >8 categories
  - Bar chart top-N limiting when too many categories (shows top 15 + "Others")
  - Smart auto-select considers data shape, cardinality, and time-series detection
  - Consistent color palette with telecom-friendly colors
  - Dual-axis support via combo chart (bar + line overlay)
"""
from __future__ import annotations

import json
import re
from datetime import datetime
from difflib import get_close_matches
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import toons
from langchain_core.tools import tool
from loguru import logger

from config.settings import config

_CHART_DIR: Path = config.charts_dir
_CHART_DIR.mkdir(parents=True, exist_ok=True)

_CHART_URL_PREFIX = "/api/v1/charts"

# ── Consistent color palette ──────────────────────────────────────────
_COLOR_PALETTE = [
    "#E20074",  # T-Mobile magenta
    "#2196F3",  # blue
    "#4CAF50",  # green
    "#FF9800",  # orange
    "#9C27B0",  # purple
    "#00BCD4",  # teal
    "#F44336",  # red
    "#795548",  # brown
    "#607D8B",  # blue-grey
    "#CDDC39",  # lime
    "#FF5722",  # deep orange
    "#3F51B5",  # indigo
]

_TOP_N_BAR = 15  # max bars before bucketing into "Others"
_TOP_N_PIE = 8  # max pie slices before bucketing into "Others"


# ─────────────────────────────────────────────
# URL helpers
# ─────────────────────────────────────────────

def chart_paths_to_urls(chart_paths: list | None) -> list[str]:
    """Convert chart metadata dicts or legacy path strings to HTTP URLs.

    Handles all formats produced over time:
    - New dicts with 'chart_url' key  → use directly
    - Legacy dicts with only 'chart_path' (absolute file path) → extract filename
    - Bare string paths → extract filename
    Always returns a list of '/api/v1/charts/{filename}' URLs.
    """
    if not chart_paths:
        return []
    urls: list[str] = []
    for item in chart_paths:
        if isinstance(item, dict):
            url = item.get("chart_url", "")
            if not url:
                path = item.get("chart_path", "")
                if path:
                    filename = path.replace("\\", "/").rsplit("/", 1)[-1]
                    url = f"{_CHART_URL_PREFIX}/{filename}"
            if url:
                urls.append(url)
        elif isinstance(item, str):
            filename = item.replace("\\", "/").rsplit("/", 1)[-1]
            urls.append(f"{_CHART_URL_PREFIX}/{filename}")
    return urls


# ─────────────────────────────────────────────
# Save
# ─────────────────────────────────────────────

def save_figure(fig: go.Figure, title: str) -> dict:
    """Save a Plotly figure to HTML and return path + URL metadata."""
    slug = re.sub(r"[^a-z0-9]+", "_", title.lower())[:40].strip("_")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{slug}_{timestamp}.html"
    path = _CHART_DIR / filename
    html = fig.to_html(include_plotlyjs="inline", full_html=False)
    path.write_text(html, encoding="utf-8")
    return {
        "file_path": str(path),
        "filename": filename,
        "chart_url": f"/api/v1/charts/{filename}",
    }


# ─────────────────────────────────────────────
# Data cleaning & column resolution
# ─────────────────────────────────────────────

def _resolve_column(df: pd.DataFrame, requested: str) -> str:
    """Fuzzy-match a requested column name against actual DataFrame columns.

    Handles case mismatches, extra whitespace, and minor typos.
    Returns the best matching actual column name, or the original if no match.
    """
    if not requested or requested in df.columns:
        return requested

    col_map = {c.lower().strip(): c for c in df.columns}

    # Exact case-insensitive match
    key = requested.lower().strip()
    if key in col_map:
        return col_map[key]

    # Underscore/space normalization: "vendor name" → "vendor_name"
    normalized = key.replace(" ", "_")
    for k, v in col_map.items():
        if k.replace(" ", "_") == normalized:
            return v

    # Fuzzy match
    matches = get_close_matches(key, list(col_map.keys()), n=1, cutoff=0.6)
    if matches:
        resolved = col_map[matches[0]]
        logger.info("Chart | fuzzy-matched column '{}' → '{}'", requested, resolved)
        return resolved

    return requested


def _clean_dataframe(df: pd.DataFrame, x_col: str, y_col: str) -> pd.DataFrame:
    """Clean DataFrame for charting: drop nulls in key columns, coerce numeric y."""
    if df.empty:
        return df

    # Drop rows where key columns are null
    subset = [c for c in [x_col, y_col] if c and c in df.columns]
    if subset:
        df = df.dropna(subset=subset)

    # Coerce y_column to numeric if it looks like numbers stored as strings
    if y_col and y_col in df.columns and df[y_col].dtype == object:
        coerced = pd.to_numeric(df[y_col], errors="coerce")
        if coerced.notna().sum() > len(df) * 0.5:
            df[y_col] = coerced
            df = df.dropna(subset=[y_col])

    # Remove full duplicate rows
    df = df.drop_duplicates()

    return df.reset_index(drop=True)


def _bucket_others(
        df: pd.DataFrame, cat_col: str, val_col: str, top_n: int,
) -> pd.DataFrame:
    """Keep top-N categories by value, bucket the rest into "Others"."""
    if cat_col not in df.columns or val_col not in df.columns:
        return df
    if not pd.api.types.is_numeric_dtype(df[val_col]):
        return df
    if df[cat_col].nunique() <= top_n:
        return df

    grouped = df.groupby(cat_col, as_index=False)[val_col].sum()
    grouped = grouped.sort_values(val_col, ascending=False).reset_index(drop=True)

    top = grouped.head(top_n)
    others_val = grouped.iloc[top_n:][val_col].sum()

    others_row = pd.DataFrame([{cat_col: "Others", val_col: others_val}])
    result = pd.concat([top, others_row], ignore_index=True)
    return result


# ─────────────────────────────────────────────
# Chart helpers
# ─────────────────────────────────────────────

def _add_bar_labels(fig: go.Figure, df: pd.DataFrame, value_col: str, orientation: str) -> None:
    """Add data labels with count and percentage to bar charts."""
    if value_col not in df.columns or not pd.api.types.is_numeric_dtype(df[value_col]):
        return
    total = df[value_col].sum()
    if total == 0:
        fig.update_traces(texttemplate="%{value}", textposition="outside")
        return
    labels = []
    for v in df[value_col]:
        pct = (v / total * 100) if total else 0
        labels.append(f"{v:,.0f} ({pct:.0f}%)" if isinstance(v, (int, float)) else str(v))

    text_pos = "outside" if len(df) <= 20 else "inside"
    fig.update_traces(
        text=labels,
        textposition=text_pos,
        textfont_size=11 if len(df) <= 20 else 9,
        cliponaxis=False,
    )


def _sort_bar_data(
        df: pd.DataFrame, value_col: str, cat_col: str, orientation: str,
) -> pd.DataFrame:
    """Sort bar chart data descending by value for quick scanning."""
    if value_col not in df.columns or not pd.api.types.is_numeric_dtype(df[value_col]):
        return df
    return df.sort_values(value_col, ascending=(orientation == "h")).reset_index(drop=True)


def _is_date_column(series: pd.Series) -> bool:
    """Check if a Series contains date/datetime data."""
    if pd.api.types.is_datetime64_any_dtype(series):
        return True
    if series.dtype == object:
        sample = series.dropna().head(10)
        if len(sample) == 0:
            return False
        try:
            pd.to_datetime(sample)
            return True
        except (ValueError, TypeError):
            return False
    return False


def _auto_select_chart(
        df: pd.DataFrame, x_column: str, y_column: str, orientation: str,
        color_column: str | None = None,
) -> tuple[str, str]:
    """Pick the best chart type and orientation from the data shape.

    Returns (chart_type, orientation).
    """
    x_series = df[x_column] if x_column in df.columns else None
    y_series = df[y_column] if y_column in df.columns else None

    is_x_date = x_series is not None and _is_date_column(x_series)
    is_x_numeric = x_series is not None and pd.api.types.is_numeric_dtype(x_series)
    is_y_numeric = y_series is not None and pd.api.types.is_numeric_dtype(y_series)
    x_nunique = x_series.nunique() if x_series is not None else 0

    # Date on X axis → line chart (multi-line if color present)
    if is_x_date:
        return "line", "v"

    # Both numeric → scatter
    if is_x_numeric and is_y_numeric:
        return "scatter", "v"

    # Categorical X
    if x_series is not None and not is_x_numeric:
        # Very few categories → pie/donut
        if x_nunique <= 5 and not color_column:
            return "pie", "v"

        # With color grouping → grouped bar
        if color_column:
            return "grouped_bar", "v"

        # Long labels → horizontal bar
        if x_series.astype(str).str.len().mean() > 15:
            return "bar", "h"

        # Many categories → bar (will be bucketed)
        return "bar", orientation

    return "bar", orientation


def _apply_common_layout(fig: go.Figure, title: str, row_count: int) -> None:
    """Apply consistent layout styling to all charts."""
    total_label = f" ({row_count:,} records)" if row_count > 1 else ""
    fig.update_layout(
        title=f"{title}{total_label}",
        font=dict(family="Arial, sans-serif", size=13),
        title_font_size=16,
        margin=dict(l=60, r=30, t=70, b=60),
        bargap=0.15,
        colorway=_COLOR_PALETTE,
        template="plotly_white",
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=-0.25,
            xanchor="center",
            x=0.5,
        ) if row_count > 5 else {},
    )


def _add_threshold_line(
        fig: go.Figure, threshold: float, label: str,
        orientation: str, chart_type: str,
) -> None:
    """Add a target/threshold dashed line to the chart."""
    label = label or f"Target: {threshold:,.1f}"
    is_y_axis = orientation == "v" or chart_type in ("line", "scatter", "area")
    if is_y_axis:
        fig.add_hline(
            y=threshold, line_dash="dash", line_color="red", line_width=2,
            annotation_text=label,
            annotation_position="top right",
            annotation_font_color="red",
        )
    else:
        fig.add_vline(
            x=threshold, line_dash="dash", line_color="red", line_width=2,
            annotation_text=label,
            annotation_position="top right",
            annotation_font_color="red",
        )


# ─────────────────────────────────────────────
# Main render function
# ─────────────────────────────────────────────

def render_chart(
        df: pd.DataFrame,
        chart_type: str,
        x_column: str,
        y_column: str,
        title: str,
        color_column: str = "",
        orientation: str = "v",
        threshold: float | None = None,
        threshold_label: str = "",
) -> dict:
    """Render a Plotly chart from a DataFrame and save as HTML.

    Smart features:
      - Fuzzy column name matching (tolerates case/typos)
      - Auto data cleaning (nulls, type coercion)
      - Top-N bucketing for bars (>15 categories) and pie (>8 slices)
      - Auto chart type selection from data shape
      - Consistent color palette
      - Stacked/grouped bar support
      - Donut and waterfall chart types

    Returns dict with chart_path, chart_url, chart_type, title, row_count.
    """
    if df.empty:
        return {"error": "No data to visualise.", "chart_path": None}

    # ── Resolve column names (fuzzy match) ──
    x_column = _resolve_column(df, x_column)
    y_column = _resolve_column(df, y_column)
    color_column_resolved = _resolve_column(df, color_column) if color_column else ""

    # Validate columns exist
    missing = []
    if x_column and x_column not in df.columns:
        missing.append(f"x_column='{x_column}'")
    if y_column and y_column not in df.columns:
        missing.append(f"y_column='{y_column}'")
    if missing:
        available = ", ".join(df.columns.tolist())
        return {"error": f"Column(s) not found: {', '.join(missing)}. Available: {available}"}

    # ── Clean data ──
    df = _clean_dataframe(df, x_column, y_column)
    if df.empty:
        return {"error": "No data remaining after cleaning (all nulls?)."}

    original_count = len(df)
    color = color_column_resolved if color_column_resolved and color_column_resolved in df.columns else None
    ct = chart_type.lower().strip()

    # ── Auto-detect best chart type ──
    if ct == "auto":
        ct, orientation = _auto_select_chart(df, x_column, y_column, orientation, color)
        if ct == "bar" and orientation == "h":
            x_column, y_column = y_column, x_column

    # ── Build chart ──
    fig = None

    if ct in ("bar", "stacked_bar", "grouped_bar"):
        barmode = "stack" if ct == "stacked_bar" else ("group" if ct == "grouped_bar" else "relative")
        value_col = x_column if orientation == "h" else y_column
        cat_col = y_column if orientation == "h" else x_column

        # Bucket into top-N + Others for non-grouped bars
        if not color and value_col in df.columns:
            df = _bucket_others(df, cat_col, value_col, _TOP_N_BAR)
            if pd.api.types.is_numeric_dtype(df[value_col]):
                df = _sort_bar_data(df, value_col, cat_col, orientation)

        fig = px.bar(df, x=x_column, y=y_column, color=color,
                     orientation=orientation, barmode=barmode)
        if not color and value_col in df.columns:
            _add_bar_labels(fig, df, value_col, orientation)
        ct = "bar"  # normalize for metadata

    elif ct == "line":
        # Convert x to datetime if it looks like dates
        if x_column in df.columns and _is_date_column(df[x_column]):
            df[x_column] = pd.to_datetime(df[x_column])
            df = df.sort_values(x_column)

        fig = px.line(df, x=x_column, y=y_column, color=color, markers=True)

        # Only add text labels if few enough points to be readable
        if len(df) <= 30:
            fig.update_traces(
                texttemplate="%{y:,.0f}", textposition="top center", textfont_size=10,
            )

    elif ct in ("pie", "donut"):
        # Bucket small slices into "Others"
        df = _bucket_others(df, x_column, y_column, _TOP_N_PIE)
        hole = 0.4 if ct == "donut" else 0

        fig = px.pie(df, names=x_column, values=y_column, hole=hole)
        fig.update_traces(
            textinfo="label+percent+value", textposition="inside",
            insidetextorientation="radial",
        )
        ct = "pie"

    elif ct == "scatter":
        try:
            fig = px.scatter(df, x=x_column, y=y_column, color=color,
                             trendline="ols" if len(df) >= 5 else None)
        except (ImportError, Exception):
            # trendline="ols" requires statsmodels — fall back without it
            fig = px.scatter(df, x=x_column, y=y_column, color=color)

    elif ct == "histogram":
        fig = px.histogram(df, x=x_column, color=color)
        fig.update_traces(texttemplate="%{y}", textposition="outside")

    elif ct == "area":
        if x_column in df.columns and _is_date_column(df[x_column]):
            df[x_column] = pd.to_datetime(df[x_column])
            df = df.sort_values(x_column)
        fig = px.area(df, x=x_column, y=y_column, color=color)

    elif ct == "box":
        fig = px.box(df, x=x_column, y=y_column, color=color,
                     orientation=orientation, points="outliers")

    elif ct == "funnel":
        fig = px.funnel(df, x=y_column, y=x_column, color=color)

    elif ct == "waterfall":
        # Waterfall: x = categories, y = values (positive/negative deltas)
        fig = go.Figure(go.Waterfall(
            x=df[x_column].tolist(),
            y=df[y_column].tolist(),
            textposition="outside",
            connector={"line": {"color": "#607D8B"}},
        ))

    elif ct == "heatmap":
        if not color and len(df.columns) < 3:
            return {"error": "Heatmap requires a color_column or at least 3 columns."}
        pivot_col = color or df.columns[2]
        try:
            pivot = df.pivot_table(
                index=x_column, columns=pivot_col,
                values=y_column, aggfunc="sum", fill_value=0,
            )
            fig = px.imshow(pivot, aspect="auto",
                            color_continuous_scale="Blues", text_auto=True)
        except Exception as e:
            return {"error": f"Heatmap pivot failed: {e}. Check column types."}

    elif ct == "combo":
        # Dual-axis: bar (primary y) + line (secondary y) overlay
        # color_column is used as the secondary y-axis column
        if not color or color not in df.columns:
            return {"error": "combo chart requires color_column set to the secondary Y-axis column."}

        fig = go.Figure()
        fig.add_trace(go.Bar(
            x=df[x_column], y=df[y_column], name=y_column,
            marker_color=_COLOR_PALETTE[0], yaxis="y",
        ))
        fig.add_trace(go.Scatter(
            x=df[x_column], y=df[color], name=color, mode="lines+markers",
            marker_color=_COLOR_PALETTE[1], yaxis="y2",
        ))
        fig.update_layout(
            yaxis=dict(title=y_column, side="left"),
            yaxis2=dict(title=color, side="right", overlaying="y"),
        )
        color = None  # already used

    else:
        return {"error": f"Unsupported chart_type '{chart_type}'. "
                         f"Use: auto, bar, stacked_bar, grouped_bar, line, pie, donut, "
                         f"scatter, histogram, area, box, funnel, waterfall, heatmap, combo."}

    # ── Threshold line ──
    if threshold is not None and fig is not None:
        _add_threshold_line(fig, threshold, threshold_label, orientation, ct)

    # ── Apply consistent layout ──
    _apply_common_layout(fig, title, original_count)

    saved = save_figure(fig, title)
    return {
        "chart_path": saved["file_path"],
        "chart_url": saved["chart_url"],
        "filename": saved["filename"],
        "chart_type": ct,
        "title": title,
        "row_count": original_count,
    }


# ─────────────────────────────────────────────
# LangChain tool wrapper
# ─────────────────────────────────────────────

def make_chart_tool(output_dir: Path | None = None) -> list:
    """Return the chart tool. `output_dir` overrides the default output path."""
    global _CHART_DIR
    if output_dir:
        _CHART_DIR = output_dir
        _CHART_DIR.mkdir(parents=True, exist_ok=True)

    @tool
    def create_visualization(
            data_json: str,
            chart_type: str,
            x_column: str,
            y_column: str,
            title: str,
            color_column: str = "",
            orientation: str = "v",
            threshold: float | None = None,
            threshold_label: str = "",
    ) -> str:
        """
        Create an interactive Plotly chart from SQL query results and save as HTML.

        Smart features:
        - Fuzzy column name matching (tolerates case mismatches and minor typos)
        - Auto data cleaning (drops nulls, coerces numeric strings, deduplicates)
        - Top-N bucketing: bars >15 categories and pie >8 slices auto-group into "Others"
        - Auto chart selection when chart_type="auto" (analyzes data shape)
        - Consistent color palette with data labels showing count + percentage

        Args:
            data_json       : TOON or JSON string from run_sql_query (contains 'data' key).
            chart_type      : One of: auto, bar, stacked_bar, grouped_bar, line, pie,
                              donut, scatter, histogram, area, box, funnel, waterfall,
                              heatmap, combo. Use "auto" to let the system pick.
                              "combo" creates a dual-axis bar + line overlay
                              (set color_column to the secondary Y-axis column).
            x_column        : Column name for the X axis (or labels for pie).
            y_column        : Column name for the Y axis (or values for pie).
                              Use '' for histogram (only x_column needed).
            title           : Chart title shown in the figure and used in filename.
            color_column    : Optional column for colour-encoding (grouping).
                              For combo charts: the secondary Y-axis column name.
            orientation     : 'v' (vertical, default) or 'h' (horizontal) for bar/box.
            threshold       : Optional numeric target/threshold value. Draws a red
                              dashed line on the chart (e.g., 85 for "85% SLA target").
            threshold_label : Label for the threshold line (e.g., "SLA Target: 85%").
                              Auto-generated from threshold value if omitted.

        Returns:
            TOON string with keys: chart_path, chart_url, row_count, chart_type, title.
            On error: TOON string with 'error' key explaining the issue.
        """
        # ── Parse input data ──
        try:
            payload = json.loads(data_json)
        except (json.JSONDecodeError, TypeError):
            try:
                payload = toons.loads(data_json)
            except Exception:
                return toons.dumps({
                    "error": "Could not parse data_json. Pass the raw output from run_sql_query.",
                })

        if not isinstance(payload, dict):
            payload = {"data": payload}

        records = payload.get("data", payload)  # tolerate bare list too

        # Handle nested result structures
        if isinstance(records, dict) and "result" in records:
            records = records["result"]

        if not isinstance(records, list):
            return toons.dumps({"error": f"Expected a list of records, got {type(records).__name__}."})

        if len(records) == 0:
            return toons.dumps({"error": "No records in data to visualise."})

        df = pd.DataFrame(records)

        result = render_chart(
            df, chart_type, x_column, y_column, title,
            color_column, orientation, threshold, threshold_label,
        )

        if "error" in result:
            logger.warning("Chart | error: {}", result["error"])

        return toons.dumps(result)

    return [create_visualization]
