"""LangChain tool: look up the SQL query for a KPI at a given aggregation level.

Loads kpi_aggregation_db_stable.jsonl once at import time.
The agent passes a KPI name (or partial/fuzzy name) and a level
(national | region | market | gc) — defaults to national.
"""

from __future__ import annotations

import difflib
import json
import textwrap
from pathlib import Path
from typing import Literal, Type

from langchain_core.tools import BaseTool
from pydantic import BaseModel, Field

# ── load data ─────────────────────────────────────────────────────────────────

_JSONL_PATH = Path(__file__).parent.parent / "kpi_aggregations_db_stable.jsonl"

_RECORDS: list[dict] = []

with _JSONL_PATH.open() as _f:
    for _line in _f:
        _line = _line.strip()
        if _line:
            _RECORDS.append(json.loads(_line))

# search corpus: one string per record combining name + description
_CORPUS: list[str] = [
    f"{r['kpi_name']} {r.get('description', '')}".lower()
    for r in _RECORDS
]

Level = Literal["national", "region", "market", "gc"]
_VALID_LEVELS = {"national", "region", "market", "gc"}


# ── search helpers ────────────────────────────────────────────────────────────

def _find_best_match(query: str, top_n: int = 3) -> list[dict]:
    """Return top-N records whose name/description best match the query."""
    query_lower = query.lower()

    # exact substring hit first
    exact = [r for r, corpus in zip(_RECORDS, _CORPUS) if query_lower in corpus]
    if exact:
        return exact[:top_n]

    # fuzzy fallback via difflib
    close = difflib.get_close_matches(query_lower, _CORPUS, n=top_n, cutoff=0.3)
    return [_RECORDS[_CORPUS.index(c)] for c in close]


def _format_result(record: dict, level: str) -> str:
    level_data = record.get("levels", {}).get(level)

    lines: list[str] = [
        f"KPI      : {record['kpi_name']}",
        f"KPI ID   : {record['kpi_id']}",
        f"Vertical : {record['vertical']}",
        f"Level    : {level}",
    ]

    if not level_data:
        available = list(record.get("levels", {}).keys())
        lines.append(f"SQL      : NOT AVAILABLE at '{level}' level.")
        lines.append(f"Available levels: {', '.join(available)}")
        return "\n".join(lines)

    sql = level_data.get("sql", "")
    months = level_data.get("months", "N/A")
    validation = level_data.get("validation", {})
    val_status = validation.get("status", "unknown")

    lines.append(f"Window   : last {months} months")
    lines.append(f"Validated: {val_status}")
    lines.append("")
    lines.append("SQL:")
    lines.append("```sql")
    lines.append(sql)
    lines.append("```")

    if val_status == "error":
        lines.append("")
        lines.append(f"Validation warning: {validation.get('error', '')}")

    return "\n".join(lines)


# ── input schema ─────────────────────────────────────────────────────────────

class KpiSqlInput(BaseModel):
    kpi_name: str = Field(
        description=(
            "Name or partial name of the KPI to look up. "
            "Fuzzy matching is applied — use natural language if unsure of exact name."
        )
    )
    level: str = Field(
        default="national",
        description=(
            "Aggregation level for the SQL query. "
            "One of: national, region, market, gc. Defaults to national."
        ),
    )
    top_n: int = Field(
        default=1,
        description="How many candidate KPIs to return when the match is ambiguous (max 3).",
    )


# ── tool ─────────────────────────────────────────────────────────────────────

class KpiSqlLookupTool(BaseTool):
    """Look up the SQL query for a KPI at national / region / market / gc level."""

    name: str = "kpi_sql_lookup"
    description: str = textwrap.dedent("""\
        Retrieve the pre-built SQL query for a KPI at a specified aggregation
        level (national, region, market, or gc).

        Provide the KPI name (exact or fuzzy) and the desired aggregation level.
        Returns the SQL query, the lookback window in months, and validation
        status.  If multiple KPIs match, returns the top candidates so you can
        ask the user to clarify.

        Use this tool whenever the user asks about a KPI metric and wants to
        see data at a specific aggregation level.
    """)
    args_schema: Type[BaseModel] = KpiSqlInput

    def _run(self, kpi_name: str, level: str = "national", top_n: int = 1) -> str:
        level = level.lower().strip()
        if level not in _VALID_LEVELS:
            return (
                f"Invalid level '{level}'. "
                f"Choose one of: {', '.join(sorted(_VALID_LEVELS))}."
            )

        top_n = max(1, min(top_n, 3))
        matches = _find_best_match(kpi_name, top_n=top_n)

        if not matches:
            return (
                f"No KPI found matching '{kpi_name}'. "
                "Try a different name or keyword from the KPI description."
            )

        if len(matches) == 1:
            return _format_result(matches[0], level)

        # multiple candidates — return all so the agent can clarify
        parts = [f"Found {len(matches)} matching KPIs for '{kpi_name}':\n"]
        for i, record in enumerate(matches, 1):
            parts.append(f"--- Match {i} ---")
            parts.append(_format_result(record, level))
        return "\n".join(parts)

    async def _arun(self, kpi_name: str, level: str = "national", top_n: int = 1) -> str:
        return self._run(kpi_name, level, top_n)


kpi_sql_lookup_tool = KpiSqlLookupTool()