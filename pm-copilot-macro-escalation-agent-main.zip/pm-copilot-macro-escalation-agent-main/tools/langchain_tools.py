# LangChain tool wrappers for the autonomous Traversal Agent.

# Wraps existing tools (neo4j_tool, bkg_tool, python_sandbox, chart_tools) as
# @tool functions that the ReAct agent can call.
from __future__ import annotations

import json
import time
from typing import Any, Optional

import pandas as _pd
import toons
from langchain_core.tools import tool
from loguru import logger

from tools.bkg_tool import BKGTool
from tools.chart_data_tool import make_chart_data_tool, prepare_chart_data
from tools.neo4j_tool import neo4j_tool
from tools.python_sandbox import execute_python, PythonSandbox


# ── Safe TOON serialization ───────────────────────────────────────────────────

def _to_toons(obj: Any) -> str:
    """Serialize *obj* to a TOON string.

    toons.dumps has no ``default=`` fallback, so non-serializable types (e.g.
    datetime, neo4j types, numpy scalars) would raise. We pre-sanitize via a
    JSON round-trip (which stringifies unknowns) before handing to toons.
    """
    try:
        return toons.dumps(obj)
    except Exception:
        safe = json.loads(json.dumps(obj, default=str))
        return toons.dumps(safe)


# ── Per-tool character limits (context overflow defense) ─────────────────────

_TOOL_CHAR_LIMITS = {
    "get_kpi": 80000,
    "get_node": 80000,
    "find_relevant": 12000,
    "traverse_graph": 12000,
    "run_sql_python": 10000,
    "run_python": 10000,
    "sql_query": 10000,
    "run_cypher": 12000,
    "create_visualization": 4000,
}


def _truncate_tool_output(tool_name: str, raw: str) -> str:
    """
    Truncate a tool's output to fit within the tool's char budget.
    Preserves structure: for list results, keeps first N rows + total count.
    For errors, always returns full output (errors are small and needed for retry).
    All output is serialized as TOON for the LLM.
    """
    limit = _TOOL_CHAR_LIMITS.get(tool_name, 3000)

    if len(raw) <= limit:
        return raw

    # Try to parse as TOON first, fall back to JSON
    try:
        parsed = toons.loads(raw)
    except Exception:
        try:
            parsed = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return raw[:limit] + "\n... (truncated by tool trimmer)"

    if isinstance(parsed, dict):
        if parsed.get("status") == "error" or "error" in parsed:
            return raw

        # run_sql_python / run_python: smart truncation for result lists
        if "result" in parsed and isinstance(parsed["result"], list):
            rows = parsed["result"]
            total = len(rows)

            if total == 0:
                return raw

            # Detect if this is already aggregated data (few rows, likely GROUP BY)
            # vs raw row-level data (many rows, no aggregation)
            is_aggregated = total <= 30
            columns = list(rows[0].keys()) if rows and isinstance(rows[0], dict) else []

            if is_aggregated:
                # Aggregated results: keep all rows — they're the actual findings
                keep = total
                while keep > 0:
                    parsed["result"] = rows[:keep]
                    if keep < total:
                        parsed["_truncated"] = {
                            "total_rows": total,
                            "rows_shown": keep,
                        }
                    candidate = _to_toons(parsed)
                    if len(candidate) <= limit:
                        return candidate
                    keep = keep // 2
            else:
                # Raw rows: LLM doesn't need these. Show schema + sample + stats.
                sample_rows = rows[:3] + (rows[-2:] if total > 5 else [])

                # Compute basic stats for numeric columns
                stats = {}
                for col in columns:
                    vals = [r.get(col) for r in rows if r.get(col) is not None]
                    if vals and isinstance(vals[0], (int, float)):
                        numeric = [v for v in vals if isinstance(v, (int, float))]
                        if numeric:
                            stats[col] = {
                                "min": min(numeric),
                                "max": max(numeric),
                                "avg": round(sum(numeric) / len(numeric), 2),
                            }

                # Collect distinct values for low-cardinality string columns
                distinct_vals = {}
                for col in columns:
                    vals = [r.get(col) for r in rows if r.get(col) is not None]
                    if vals and isinstance(vals[0], str):
                        uniques = list(set(vals))
                        if len(uniques) <= 20:
                            distinct_vals[col] = uniques

                parsed["result"] = sample_rows
                parsed["_data_summary"] = {
                    "total_rows": total,
                    "columns": columns,
                    "sample_rows_shown": len(sample_rows),
                    "numeric_stats": stats,
                    "distinct_values": distinct_vals,
                    "message": (
                        f"{total} raw rows returned. Showing {len(sample_rows)} samples + stats. "
                        f"Use aggregations (GROUP BY, groupby, pivot) to extract findings — "
                        f"do NOT read raw rows for analysis."
                    ),
                }
                candidate = _to_toons(parsed)
                if len(candidate) <= limit:
                    return candidate
                # If still too big, drop distinct_values
                parsed["_data_summary"].pop("distinct_values", None)
                candidate = _to_toons(parsed)
                if len(candidate) <= limit:
                    return candidate
                # Last resort: just schema + count
                parsed["result"] = []
                parsed["_data_summary"] = {
                    "total_rows": total,
                    "columns": columns,
                    "numeric_stats": stats,
                    "message": f"{total} rows returned. Use aggregations to analyze.",
                }
                return _to_toons(parsed)[:limit]

        # run_cypher: truncate 'records' list
        if "records" in parsed and isinstance(parsed["records"], list):
            rows = parsed["records"]
            total = len(rows)
            keep = total
            while keep > 0:
                parsed["records"] = rows[:keep]
                parsed["count"] = total
                parsed["_truncated"] = f"Showing {keep} of {total} records"
                candidate = _to_toons(parsed)
                if len(candidate) <= limit:
                    return candidate
                keep = keep // 2

        # get_kpi / get_node / find_relevant: truncate large string fields
        compact = _to_toons(parsed)
        if len(compact) <= limit:
            return compact
        return compact[:limit] + "\n... (truncated by tool trimmer)"

    return raw[:limit] + "\n... (truncated by tool trimmer)"


# ── Aggregation detection + auto chart data ──────────────────────────────────

# Module-level chart store: run_sql_python pushes chart data here so the agent
# only sees a short summary while the FE gets the full payload.
# Cleared at the start of each investigation run.
_chart_data_store: list[dict] = []


def get_chart_data_store() -> list[dict]:
    """Return accumulated chart data records (for FE rendering)."""
    return _chart_data_store


def clear_chart_data_store() -> None:
    """Reset chart data store at the start of each investigation."""
    _chart_data_store.clear()


def _detect_aggregation(code: str) -> bool:
    """Detect if code performs a real aggregation (GROUP BY, groupby, pivot, etc.)."""
    code_upper = code.upper()
    if "GROUP BY" in code_upper:
        return True
    # SQL aggregate functions without GROUP BY (e.g., SELECT AVG(...) FROM ...)
    if any(fn in code_upper for fn in ("SUM(", "AVG(", "COUNT(", "MIN(", "MAX(")):
        return True
    if any(kw in code for kw in ("groupby", ".agg(", "aggregate", "pivot",
                                 "pivot_table", "crosstab", "resample",
                                 "value_counts", "nlargest", "nsmallest")):
        return True
    # Window functions also produce aggregated/analytical output
    if "OVER (" in code_upper or "OVER(" in code_upper:
        return True
    if "merge(" in code or "concat(" in code:
        return True
    return False


def _extract_rows(result_payload: dict) -> list[dict] | None:
    """Extract list-of-dicts rows from a sandbox result payload."""
    rows = None
    if isinstance(result_payload, dict):
        rows = result_payload.get("result", result_payload.get("data"))
    elif isinstance(result_payload, list):
        rows = result_payload

    if not isinstance(rows, list) or len(rows) == 0:
        return None
    if not isinstance(rows[0], dict):
        return None
    return rows


def _extract_all_row_sets(result_payload: dict) -> list[tuple[str, list[dict]]]:
    """Extract all list-of-dicts from a sandbox result, including nested dicts.

    When the agent returns result = {"national": [...], "region": [...], ...},
    each sub-key is a separate dataset that should get its own chart.

    Returns list of (label, rows) tuples. For flat results, returns one entry.
    """
    result = None
    if isinstance(result_payload, dict):
        result = result_payload.get("result", result_payload.get("data"))

    if result is None:
        return []

    # Case 1: result is a flat list of dicts → single dataset
    if isinstance(result, list) and result and isinstance(result[0], dict):
        return [("result", result)]

    # Case 2: result is a dict of sub-keys → check each for list-of-dicts
    if isinstance(result, dict):
        datasets = []
        for key, val in result.items():
            if isinstance(val, list) and val and isinstance(val[0], dict):
                datasets.append((key, val))
        return datasets

    return []


def _build_chart_llm_input(
        columns: list[str],
        distinct_info: dict,
        sample: list[dict],
        rows: list[dict],
        code: str,
) -> str:
    """Build CSV-formatted input for the chart LLM picker."""
    col_desc = ", ".join(
        f"{col} ({info.get('type', '?')}, {info.get('distinct', '?')} distinct)"
        for col, info in distinct_info.items()
    )
    header = ",".join(columns)
    csv_rows = "\n".join(
        ",".join(str(r.get(c, "")) for c in columns)
        for r in sample
    )
    return (
        f"Columns: {col_desc}\n\n"
        f"Sample data ({len(rows)} rows total):\n"
        f"{header}\n{csv_rows}\n\n"
    )


def _llm_pick_chart_params(rows: list[dict], code: str) -> dict | None:
    """Pick chart params: try heuristics first, fall back to LLM call.

    Returns dict with chart_type, x_column, y_column, title or None on failure.
    """
    from services.llm_provider import LLMProvider
    from langchain_core.messages import SystemMessage, HumanMessage

    columns = list(rows[0].keys())
    sample = rows[:3]

    # Compute distinct counts per column to help LLM pick better axes
    distinct_info = {}
    for col in columns:
        vals = [str(r.get(col, "")) for r in rows]
        uniques = set(vals)
        distinct_info[col] = {
            "distinct": len(uniques),
            "sample_values": list(uniques)[:5],
            "type": "numeric" if isinstance(rows[0].get(col), (int, float)) else "text",
        }

    try:
        llm = LLMProvider(model="gpt-5-mini", temperature=0).get_llm()
        response = llm.invoke([
            SystemMessage(content=(
                "You pick the best chart configuration for KPI data.\n"
                "Respond with ONLY valid JSON, no markdown, no explanation.\n"
                "Keys: chart_type, x_column, y_column, title, color_column (optional).\n\n"
                "RULES:\n"
                "- chart_type: bar, line, pie, donut, scatter, area, stacked_bar, grouped_bar\n"
                "- x_column: the axis with the MOST meaningful distinct values (e.g., market names, GC names, time periods).\n"
                "  NEVER pick a column with only 1 distinct value as x_column.\n"
                "- y_column: the numeric metric column (the KPI value being measured).\n"
                "- color_column: optional grouping column for multi-series charts.\n"
                "- title: short, descriptive. Include the KPI metric name. "
                "  Example: 'Swap FTR (%) by Market' not 'avg_days by rgn_region'.\n"
                "  Use human-readable names, not raw column names."
                '''**RULE: Every aggregation (GROUP BY, groupby, pivot, ranking, trend, variance, SUM/AVG/COUNT) MUST produce a chart via `create_visualization`. No exceptions.**

| Data pattern | Chart type |
|-------------|------------|
| Comparison / ranking | `bar` |
| Time-series trend | `line` |
| Share / concentration | `pie` or `donut` |
| Volume + rate overlay | `combo` |
| Multi-dimensional breakdown | `stacked_bar` |
| Cross-tabulation | `heatmap` |
| Unsure | `chart_type="auto"` |

For trend analysis, produce at least 3 charts:
1. Line: market-level KPI over time
2. Line/grouped bar: GC-level within markets
3. Heatmap/grouped bar: phase averages per market and per GC
4. Optional: bar chart of capacity changes over the same period for context

'''
            )),
            HumanMessage(content=_build_chart_llm_input(columns, distinct_info, sample, rows, code)),
        ])
        text = response.content.strip()
        # Strip markdown fences if present
        if text.startswith("```"):
            text = text.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
        params = json.loads(text)
        # Validate required keys
        if all(k in params for k in ("chart_type", "x_column", "y_column", "title")):
            return params
    except Exception as e:
        logger.debug("LLM chart param pick failed: {}", e)

    return None


def _build_chart_summary(chart_data: dict) -> str:
    """Build a short summary of chart data for the agent's context."""
    return (
        f"[Chart auto-generated: {chart_data.get('chart_type', '?')} | "
        f"title: {chart_data.get('title', '?')} | "
        f"x: {chart_data.get('x_column', '?')} | "
        f"y: {chart_data.get('y_column', '?')} | "
        f"{chart_data.get('row_count', '?')} rows]"
    )


# ── LLM-based code fix for run_sql_python errors ────────────────────────────

_MAX_CODE_FIX_RETRIES = 5


def _extract_table_names(code: str, error: str) -> list[str]:
    """Extract table names referenced in code and error message."""
    import re
    tables = set()
    # FROM / JOIN table references in SQL
    for match in re.finditer(
            r'(?:FROM|JOIN|INTO|UPDATE)\s+(?:public\.)?(\w+)', code + " " + error, re.IGNORECASE
    ):
        name = match.group(1).lower()
        if name not in ("select", "where", "set", "values", "as", "on", "and", "or"):
            tables.add(name)
    # pd.read_sql references
    for match in re.finditer(r'read_sql\s*\(\s*["\'].*?(?:FROM|from)\s+(?:public\.)?(\w+)', code):
        tables.add(match.group(1).lower())
    return list(tables)


def _fetch_live_table_schema(table_names: list[str]) -> str:
    """Query information_schema directly from DB for exact column definitions.

    Returns formatted schema text for the requested tables.
    """
    if not table_names:
        return ""
    sandbox = _get_sandbox()
    if not sandbox or not sandbox.conn:
        return ""

    schema_parts = []
    try:
        import psycopg2
        for table_name in table_names[:5]:  # Cap at 5 tables to avoid huge prompts
            try:
                cursor = sandbox.conn.cursor()
                cursor.execute(
                    """
                    SELECT column_name, data_type, is_nullable
                    FROM information_schema.columns
                    WHERE table_schema = 'public' AND table_name = %s
                    ORDER BY ordinal_position
                    """,
                    (table_name,)
                )
                rows = cursor.fetchall()
                cursor.close()
                if rows:
                    cols = "\n".join(
                        f"  - {r[0]} ({r[1]}, nullable={r[2]})" for r in rows
                    )
                    schema_parts.append(f"### public.{table_name}\n{cols}")
                else:
                    schema_parts.append(f"### public.{table_name}\n  (table not found)")
            except Exception as e:
                logger.debug("Live schema fetch failed for {}: {}", table_name, e)
                try:
                    sandbox.conn.rollback()
                except Exception:
                    pass
    except Exception as e:
        logger.debug("Live schema fetch failed: {}", e)

    if not schema_parts:
        return ""
    return "\n\n## Live Table Schemas (from DB)\n" + "\n\n".join(schema_parts)


def _llm_fix_code(code: str, error: str, retry_num: int = 0) -> str | None:
    """LLM call to fix Python/SQL code that failed in the sandbox.

    Given the original code and the error message, returns corrected code.
    - Retries 0-1: uses cached table catalog for schema context.
    - Retries 2+: queries the live DB (information_schema) for exact column
      definitions of tables referenced in the code/error.
    Returns None if the LLM call fails or produces empty output.
    """
    from services.llm_provider import LLMProvider
    from services.kpi_bootstrap import get_table_catalog, is_schema_cache_warm
    from langchain_core.messages import SystemMessage, HumanMessage

    # Schema context — escalate to live DB on later retries
    schema_context = ""
    if retry_num >= 2:
        # Pull exact column definitions from the live database
        table_names = _extract_table_names(code, error)
        live_schema = _fetch_live_table_schema(table_names)
        if live_schema:
            schema_context = live_schema
            logger.info("LLM code fix | retry {} | using live DB schema for tables: {}",
                        retry_num, table_names)

    if not schema_context and is_schema_cache_warm():
        catalog = get_table_catalog()
        # Truncate to avoid blowing up the prompt
        if len(catalog) > 4000:
            catalog = catalog[:4000] + "\n... (truncated)"
        schema_context = f"\n\n## Available Table Schemas\n{catalog}"

    try:
        llm = LLMProvider(model="gpt-5-mini", temperature=0).get_llm()
        response = llm.invoke([
            SystemMessage(content=(
                "You are a Python/SQL code fixer. You receive code that failed in a "
                "PostgreSQL-connected Python sandbox and the error message.\n"
                "Return ONLY the corrected Python code — no markdown fences, no explanation, "
                "no commentary. The code must be complete and ready to execute.\n"
                "The sandbox has pre-imported: conn (psycopg2 read-only), pd (pandas), "
                "np (numpy), json, re, math, statistics, execute_query(sql) -> list[dict].\n"
                "The code must end with `result = <value>` to return data.\n"
                "Common fixes:\n"
                "- Column not found → check the table schemas below and use correct column name\n"
                "- Table not found → check the table schemas below\n"
                "- Type mismatch → use CAST(col AS type) or pd.to_numeric(…, errors='coerce')\n"
                "- Syntax error → fix SQL syntax\n"
                "- Timeout → simplify query (add LIMIT, remove unnecessary JOINs)\n"
                "If you cannot fix the code, return it unchanged."
                f"{schema_context}"
            )),
            HumanMessage(content=(
                f"## Failed Code\n```python\n{code}\n```\n\n"
                f"## Error\n{error}"
            )),
        ])
        fixed = response.content.strip()
        # Strip markdown fences if present
        if fixed.startswith("```"):
            fixed = fixed.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
        if fixed and fixed != code.strip():
            return fixed
    except Exception as e:
        logger.debug("LLM code fix failed: {}", e)

    return None


# Lazy singleton for BKGTool
_bkg: BKGTool | None = None
_sandbox: PythonSandbox | None = None


def _get_bkg() -> BKGTool:
    global _bkg
    if _bkg is None:
        _bkg = BKGTool()
    return _bkg


def _get_sandbox() -> PythonSandbox:
    global _sandbox
    if _sandbox is None:
        _sandbox = PythonSandbox()
    return _sandbox


# ── Neo4j Tools ──────────────────────────────────────────────────────────────

@tool
def run_cypher(query: str) -> str:
    """Execute a read-only Cypher query against the Neo4j Business Knowledge Graph.
    Use this for custom queries when the higher-level BKG tools don't cover your needs.
    Returns TOON with 'status', 'records', 'count', and 'elapsed_ms'.
    Only READ operations are allowed — no CREATE, MERGE, DELETE, SET, or REMOVE.
    All nodes use the BKGNode label with node_id property. Relationships use RELATES_TO
    with relationship_type property.
    """
    logger.debug("Tool:run_cypher | query={!r}", query[:300])
    t0 = time.perf_counter()
    result = neo4j_tool.run_cypher_safe(query)
    elapsed = (time.perf_counter() - t0) * 1000
    logger.info("Tool:run_cypher | {:.0f}ms | status={} | records={}",
                elapsed, result.get("status", "?"), result.get("count", "?"))
    return _truncate_tool_output("run_cypher", _to_toons(result))


# ── BKG High-Level Tools ─────────────────────────────────────────────────────

@tool
def get_node(node_id: str) -> str:
    """Fetch a single BKGNode from the Knowledge Graph by its node_id.
    Returns all properties plus incoming and outgoing relationships.
    Supports aliases like 'GC' for general_contractor, 'NAS' for nas_session, etc.
    Large properties (map_python_function, map_contract, kpi_python_function, etc.)
    are excluded — use get_kpi to fetch KPI details explicitly.
    Use this when you know the exact node you want to inspect.
    """
    logger.debug("Tool:get_node | node_id={!r}", node_id)
    t0 = time.perf_counter()
    result = _get_bkg().query({"mode": "get_node", "node_id": node_id})
    elapsed = (time.perf_counter() - t0) * 1000
    logger.info("Tool:get_node | {:.0f}ms | node_id={!r}", elapsed, node_id)
    return _truncate_tool_output("get_node", _to_toons(result))


@tool
def find_relevant(question: str) -> str:
    """Keyword search across all BKGNodes in the Knowledge Graph.
    Searches across node_id, name, label, definition, nl_description, entity_type,
    kpi_name, kpi_description, and kpi_formula_description fields.
    Returns up to 10 nodes ranked by relevance score, with entity_type indicating
    whether each is a core, context, transaction, reference, or kpi node.
    Use this as your FIRST tool when you don't know which nodes to look at.
    """
    logger.debug("Tool:find_relevant | question={!r}", question[:200])
    t0 = time.perf_counter()
    result = _get_bkg().query({"mode": "find_relevant", "question": question})
    elapsed = (time.perf_counter() - t0) * 1000
    node_count = len(result.get("relevant_nodes", [])) if isinstance(result, dict) else "?"
    logger.info("Tool:find_relevant | {:.0f}ms | nodes_found={}", elapsed, node_count)
    return _truncate_tool_output("find_relevant", _to_toons(result))


@tool
def traverse_graph(start: str, depth: int = 2, rel_type: Optional[str] = None) -> str:
    """Walk the Knowledge Graph starting from a BKGNode, following RELATES_TO
    relationships up to a given depth (1-4). Optionally filter by relationship_type
    property on the edges.
    Returns discovered paths and node details (label, entity_type, definition,
    map_table_name, kpi_name).
    Use this to explore the neighborhood of a concept — e.g., to find what tables,
    KPIs, or related entities connect to a starting node.
    """
    logger.debug("Tool:traverse_graph | start={!r} | depth={} | rel_type={!r}", start, depth, rel_type)
    t0 = time.perf_counter()
    req: dict = {"mode": "traverse", "start": start, "depth": depth}
    if rel_type:
        req["rel_type"] = rel_type
    result = _get_bkg().query(req)
    elapsed = (time.perf_counter() - t0) * 1000
    path_count = len(result.get("paths", [])) if isinstance(result, dict) else "?"
    logger.info("Tool:traverse_graph | {:.0f}ms | start={!r} | paths={}", elapsed, start, path_count)
    return _truncate_tool_output("traverse_graph", _to_toons(result))


@tool
def get_kpi(node_id: str) -> str:
    """Get detailed information about a KPI node including its definition,
    formula description, business logic, Python function, source tables/columns,
    dimensions, filters, output schema, and related core nodes.
    Use this when you need to understand how a KPI metric is computed or what drives it.
    If called on a non-KPI node, returns KPIs that reference that node.
    """
    logger.debug("Tool:get_kpi | node_id={!r}", node_id)
    t0 = time.perf_counter()
    result = _get_bkg().query({"mode": "get_kpi", "node_id": node_id})
    elapsed = (time.perf_counter() - t0) * 1000
    logger.info("Tool:get_kpi | {:.0f}ms | node_id={!r}", elapsed, node_id)
    return _truncate_tool_output("get_kpi", _to_toons(result))


# ── Python Sandbox Tools ─────────────────────────────────────────────────────

@tool
def run_python(code: str) -> str:
    """Execute Python code in a sandboxed environment for calculations and data analysis.
    Pre-imported: math, json, statistics, re, decimal, numpy (np), pandas (pd).
    Also available via import: collections, datetime, itertools, functools, csv, io,
    copy, operator, hashlib, uuid, random, calendar, typing, dataclasses, enum.
    Set a variable named 'result' to return structured data.
    Print statements will be captured as 'output'.
    DataFrames and Series are auto-converted to dicts.
    Use this for arithmetic, aggregations, data transformations, or any computation
    that should not be done in your head.
    """
    logger.debug("Tool:run_python | code_len={} | code=\n{}", len(code), code[:500])
    result = execute_python(code)
    logger.info("Tool:run_python | status={} | elapsed_ms={} | result_len={}",
                result.get("status", "?"), result.get("elapsed_ms", "?"),
                len(str(result.get("result", ""))))
    if result.get("status") == "error":
        logger.warning("Tool:run_python FAILED | error={}", result.get("error", "")[:500])
    return _truncate_tool_output("run_python", _to_toons(result))


@tool
def run_sql_python(code: str, timeout_seconds: int = 30) -> str:
    """Execute Python code with full data analysis capabilities and PostgreSQL access.
    Pre-imported: conn (psycopg2 read-only), pd (pandas), np (numpy),
    go (plotly.graph_objects), px (plotly.express), json, re, math, statistics,
    warnings, sqlglot (SQL parser/transpiler), execute_query (helper: execute_query(sql) -> list[dict]).
    Also available via import: datetime, collections, itertools, functools, csv,
    io, copy, operator, decimal, hashlib, uuid, random, calendar, typing.

    You can also write raw SQL directly (e.g. "SELECT * FROM table") and it will
    be auto-wrapped in pd.read_sql().

    Set result = <value> to return data. DataFrames are auto-converted to records.
    If result is empty, you'll get hints on how to fix the query.
    Use this when you need to query PostgreSQL for actual operational data
    (as opposed to the Neo4j Knowledge Graph which describes the data model).
    """
    logger.debug("Tool:run_sql_python | code_len={} | timeout={}s | code=\n{}", len(code), timeout_seconds, code[:500])
    sandbox = _get_sandbox()
    current_code = code
    result = sandbox.execute(current_code, timeout_seconds)
    logger.info("Tool:run_sql_python | status={} | elapsed_ms={} | result_len={}",
                result.get("status", "?"), result.get("elapsed_ms", "?"),
                len(str(result.get("result", ""))))

    # ── Auto-fix loop: use small LLM to fix errors before returning to agent ──
    retries = 0
    while result.get("status") == "error" and retries < _MAX_CODE_FIX_RETRIES:
        error_msg = result.get("error", "")
        logger.info("Tool:run_sql_python | auto-fix attempt {}/{} | error={}",
                    retries + 1, _MAX_CODE_FIX_RETRIES, error_msg[:300])

        fixed_code = _llm_fix_code(current_code, error_msg, retry_num=retries)
        if not fixed_code:
            logger.info("Tool:run_sql_python | LLM could not fix code, returning error")
            break

        retries += 1
        current_code = fixed_code
        logger.debug("Tool:run_sql_python | retrying with fixed code:\n{}", current_code[:500])
        result = sandbox.execute(current_code, timeout_seconds)
        logger.info("Tool:run_sql_python | retry {} status={} | elapsed_ms={}",
                    retries, result.get("status", "?"), result.get("elapsed_ms", "?"))

    if result.get("status") == "error":
        logger.warning("Tool:run_sql_python FAILED | error={} | retries={}",
                       result.get("error", "")[:500], retries)
        if retries > 0:
            result["auto_fix_retries"] = retries
            result["original_code"] = code
        return _truncate_tool_output("run_sql_python", _to_toons(result))

    if retries > 0:
        result["auto_fix_retries"] = retries
        result["auto_fixed_code"] = current_code
        logger.info("Tool:run_sql_python | auto-fixed after {} retries", retries)

    # ── Auto chart pipeline for aggregated results ──
    # Handles both flat results (result = [rows]) and nested dicts
    # (result = {"national": [rows], "region": [rows], ...}).
    # Each dataset gets its own chart for the frontend.
    if _detect_aggregation(current_code):
        chart_summaries = []
        row_sets = _extract_all_row_sets(result)

        if not row_sets:
            # Fallback: try flat extraction for backward compat
            flat_rows = _extract_rows(result)
            if flat_rows:
                row_sets = [("result", flat_rows)]

        for label, rows in row_sets:
            if not rows or len(list(rows[0].keys())) < 2:
                continue
            chart_params = _llm_pick_chart_params(rows, code)
            if not chart_params:
                continue
            # For nested results, prefix the title with the sub-key label
            if label != "result" and label not in chart_params.get("title", "").lower():
                chart_params["title"] = f"{label.replace('_', ' ').title()} — {chart_params['title']}"
            try:
                df = _pd.DataFrame(rows)
                chart_data = prepare_chart_data(
                    df,
                    chart_type=chart_params["chart_type"],
                    x_column=chart_params["x_column"],
                    y_column=chart_params["y_column"],
                    title=chart_params["title"],
                    color_column=chart_params.get("color_column", ""),
                )
                if "error" not in chart_data:
                    _chart_data_store.append(chart_data)
                    chart_summaries.append(_build_chart_summary(chart_data))
                    logger.info("Tool:run_sql_python | chart stored for FE | label={} | type={} | rows={}",
                                label, chart_data.get("chart_type"), chart_data.get("row_count"))
                else:
                    logger.debug("Tool:run_sql_python | chart prep failed for '{}': {}",
                                 label, chart_data.get("error"))
            except Exception as e:
                logger.debug("Tool:run_sql_python | chart pipeline failed for '{}': {}", label, e)

        if chart_summaries:
            result["chart_summary"] = " | ".join(chart_summaries)

    return _truncate_tool_output("run_sql_python", _to_toons(result))


# ── Chart Data Tool (frontend-renderable) ────────────────────────────────────

_chart_tools = make_chart_data_tool()
create_visualization = _chart_tools[0]


# ── Tool registry ─────────────────────────────────────────────────────────────

def get_all_tools() -> list:
    """Return all tools for the traversal agent."""
    return [
        run_cypher,
        get_node,
        find_relevant,
        traverse_graph,
        get_kpi,
        run_python,
        run_sql_python,
        create_visualization,
    ]


def get_analysis_tools() -> list:
    """Return tools for the analysis agent (python sandbox + chart generation)."""
    return [
        run_python,
        create_visualization,
    ]
