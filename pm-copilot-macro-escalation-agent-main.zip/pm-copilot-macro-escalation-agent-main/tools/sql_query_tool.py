"""LangChain tool: run a SQL SELECT and return results in the same
`{status, result, elapsed_ms}` TOON shape as `run_sql_python`."""

from __future__ import annotations

import textwrap
import time
from typing import Any, Type

import psycopg2
from langchain_core.tools import BaseTool
from loguru import logger
from pydantic import BaseModel, Field

import config
from tools.langchain_tools import _to_toons, _truncate_tool_output


# ── connection ────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT_SECONDS = 600
_CONNECT_TIMEOUT_SECONDS = 1500


def _conn() -> psycopg2.extensions.connection:
    """Open a fresh read-only psycopg2 connection."""
    return psycopg2.connect(
        host=config.PG_HOST,
        port=config.PG_PORT,
        database=config.PG_DATABASE,
        user=config.PG_USER,
        password=config.PG_PASSWORD,
        connect_timeout=_CONNECT_TIMEOUT_SECONDS,
    )


_FORBIDDEN = {"insert", "update", "delete", "drop", "truncate", "alter", "create"}


def _coerce(value: Any) -> Any:
    """Make psycopg2 values JSON/TOON-serializable."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    return str(value)


# ── input schema ─────────────────────────────────────────────────────────────

class SQLQueryInput(BaseModel):
    query: str = Field(description="Valid SQL SELECT statement to execute.")
    timeout_seconds: int = Field(
        default=_DEFAULT_TIMEOUT_SECONDS,
        description=(
            "Server-side statement timeout (seconds). Applied via Postgres "
            "`SET statement_timeout`. Defaults to 120."
        ),
    )


# ── tool ─────────────────────────────────────────────────────────────────────

class SQLQueryTool(BaseTool):
    """Execute a SQL SELECT and return results in `run_sql_python`-compatible form."""

    name: str = "sql_query"
    description: str = textwrap.dedent("""\
        Execute a SQL SELECT against PostgreSQL and return rows as a list of
        dicts wrapped in `{status, result, elapsed_ms}` (TOON-encoded) — the
        same shape as run_sql_python, so downstream consumers can parse it
        identically.

        Only SELECT statements are allowed. Pass the raw SQL via `query`.
    """)
    args_schema: Type[BaseModel] = SQLQueryInput

    def _run(self, query: str, timeout_seconds: int = _DEFAULT_TIMEOUT_SECONDS) -> str:
        query = query.strip().rstrip(";")
        first_word = query.split()[0].lower() if query else ""

        timeout_seconds = max(1, int(timeout_seconds))
        statement_timeout_ms = timeout_seconds * 1000

        t0 = time.perf_counter()

        if first_word in _FORBIDDEN:
            payload = {
                "status": "error",
                "error": f"'{first_word.upper()}' is not allowed. Only SELECT queries.",
                "result": None,
                "elapsed_ms": 0,
            }
            return _truncate_tool_output("sql_query", _to_toons(payload))

        try:
            with _conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(f"SET statement_timeout = {statement_timeout_ms}")
                    cur.execute(query)
                    raw_rows = cur.fetchall()
                    columns = [desc[0] for desc in (cur.description or [])]
        except psycopg2.Error as exc:
            elapsed_ms = int((time.perf_counter() - t0) * 1000)
            logger.warning("Tool:sql_query DB error | {}", str(exc)[:300])
            payload = {
                "status": "error",
                "error": f"DB Error: {exc}",
                "result": None,
                "elapsed_ms": elapsed_ms,
            }
            return _truncate_tool_output("sql_query", _to_toons(payload))
        except Exception as exc:
            elapsed_ms = int((time.perf_counter() - t0) * 1000)
            logger.warning("Tool:sql_query unexpected error | {}", str(exc)[:300])
            payload = {
                "status": "error",
                "error": f"Unexpected error: {exc}",
                "result": None,
                "elapsed_ms": elapsed_ms,
            }
            return _truncate_tool_output("sql_query", _to_toons(payload))

        elapsed_ms = int((time.perf_counter() - t0) * 1000)
        rows = [
            {col: _coerce(val) for col, val in zip(columns, row)}
            for row in raw_rows
        ]

        payload = {
            "status": "success",
            "result": rows,
            "elapsed_ms": elapsed_ms,
            "columns": columns,
            "row_count": len(rows),
        }
        logger.info("Tool:sql_query | status=success | rows={} | {}ms",
                    len(rows), elapsed_ms)
        return _truncate_tool_output("sql_query", _to_toons(payload))

    async def _arun(self, query: str, timeout_seconds: int = _DEFAULT_TIMEOUT_SECONDS) -> str:
        return self._run(query, timeout_seconds)


sql_query_tool = SQLQueryTool()
