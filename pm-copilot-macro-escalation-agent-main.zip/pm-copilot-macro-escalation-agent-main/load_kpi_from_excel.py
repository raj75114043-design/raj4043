#!/usr/bin/env python3
"""
Load KPI metadata from an Excel file into both ChromaDB and Tantivy indexes.

Usage:
    uv run python scripts/load_kpi_from_excel.py path/to/kpi_data.xlsx

Expected columns (case-insensitive, partial match):
    KPI Id, KPI Name, Description, Formula, Mapped Tables / Cols,
    Logic, Project Name, PM Name, Date, SQL Query

The script will:
  1. Read the Excel file
  2. Normalize column names
  3. Build ChromaDB embeddings (KPI name + description)
  4. Build Tantivy full-text index (name, description, formula, tables, logic, SQL)
  5. Print summary
"""
from __future__ import annotations

import sys
from pathlib import Path


import pandas as pd
from loguru import logger

from services.kpi_search_service import bootstrap_excel_kpi_indexes
from services.kpi_bootstrap import refresh_kpi_embeddings

# Column name mapping: Excel header → internal key
_COLUMN_MAP = {
    "kpi id": "id",
    "kpi_id": "id",
    "kpi name": "kpi_name",
    "kpi_name": "kpi_name",
    "name": "kpi_name",
    "description": "description",
    "kpi description": "description",
    "kpi_description": "description",
    "formula": "formula",
    "kpi_formula": "formula",
    "mapped tables / cols": "mapped_tables_cols",
    "mapped tables": "mapped_tables_cols",
    "mapped_tables_cols": "mapped_tables_cols",
    "tables": "mapped_tables_cols",
    "logic": "logic",
    "business logic": "logic",
    "business_logic": "logic",
    "project name": "project_name",
    "project_name": "project_name",
    "smp_name": "project_name",
    "pm name": "pm_name",
    "pm_name": "pm_name",
    "date": "date",
    "sql query": "sql_query",
    "sql_query": "sql_query",
    "kpi_sql_query": "sql_query",
    "category": "category",
    "kpi_category": "category",
    "kpi category": "category",
}


def _normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Map Excel column names to internal keys."""
    renamed = {}
    for col in df.columns:
        key = col.replace("\xa0", " ").strip().lower()
        if key in _COLUMN_MAP.keys():
            renamed[col] = _COLUMN_MAP[key]
        elif "unnamed" in key or "unkown" in key:
            pass  # skip junk columns

    df = df.rename(columns=renamed)
    return df


def load_from_excel(file_path: str | Path) -> list[dict]:
    """Read KPI data from Excel and return as list of dicts."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Excel file not found: {path}")

    logger.info("Reading KPI data from {}", path)

    # Read all sheets, take the first one with data
    xls = pd.ExcelFile(path)
    df = None
    for sheet in xls.sheet_names:
        candidate = pd.read_excel(xls, sheet_name=sheet)
        if len(candidate) > 0:
            df = candidate
            logger.info("Using sheet '{}' ({} rows)", sheet, len(df))
            break

    if df is None or df.empty:
        raise ValueError(f"No data found in {path}")

    # Normalize columns
    df = _normalize_columns(df)

    # Ensure kpi_name exists
    if "kpi_name" not in df.columns:
        raise ValueError(
            f"Could not find 'KPI Name' column. Found columns: {list(df.columns)}"
        )

    # Drop rows without a KPI name
    df["kpi_name"] = df["kpi_name"].astype(str)
    df = df.dropna(subset=["kpi_name"])
    df = df[df["kpi_name"].str.strip().ne("").ne("nan")]

    # Convert to list of dicts, cleaning NaN
    rows = []
    for _, row in df.iterrows():
        record = {}
        for col in df.columns:
            val = row[col]
            if pd.notna(val):
                record[col] = str(val).strip() if isinstance(val, str) else val
        rows.append(record)

    logger.info("Loaded {} KPIs from Excel", len(rows))
    return rows


def main():
    if len(sys.argv) < 2:
        print("Usage: uv run python scripts/load_kpi_from_excel.py <excel_file>")
        print("\nExpected columns: KPI Id, KPI Name, Description, Formula,")
        print("  Mapped Tables / Cols, Logic, Project Name, PM Name, Date, SQL Query")
        sys.exit(1)

    file_path = sys.argv[1]
    rows = load_from_excel(file_path)

    if not rows:
        print("No KPI data found in the Excel file.")
        sys.exit(1)

    print(f"\nLoaded {len(rows)} KPIs from Excel:")
    for i, r in enumerate(rows[:5], 1):
        print(f"  {i}. {r.get('kpi_name', '?')} — {r.get('description', '')[:60]}")
    if len(rows) > 5:
        print(f"  ... and {len(rows) - 5} more")

    print("\nBuilding Excel indexes (ChromaDB).")
    excel_count = bootstrap_excel_kpi_indexes(kpi_rows=rows, force=True)
    print(f"Indexed {excel_count} Excel KPIs into ChromaDB and Tantivy.")

    print("\nBuilding DB indexes (tmo_macro_kpi_master_details)...")
    db_count = refresh_kpi_embeddings()
    print(f"Indexed {db_count} DB KPIs.")

    print(f"\nDone. Total: {excel_count + db_count} KPIs indexed (Excel: {excel_count}, DB: {db_count}).")


if __name__ == "__main__":
    main()
