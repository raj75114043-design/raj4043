"""FastAPI entrypoint for the Escalation Analytics Agent.

Run with:
    uvicorn main:app --host 0.0.0.0 --port 8000
"""

from __future__ import annotations

import logging
import sys
import uuid
from contextlib import asynccontextmanager
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger
from starlette.middleware.base import BaseHTTPMiddleware

# Ensure app/ is on sys.path so internal imports resolve correctly
# whether we run `uvicorn main:app` from the project root or inside app/.
_APP_DIR = str(Path(__file__).resolve().parent)
if _APP_DIR not in sys.path:
    sys.path.insert(0, _APP_DIR)

from api.v1.deps import get_build_duration, is_ready, start_build
from api.v1.router import router as v1_router
from logger import setup_logging

load_dotenv()
setup_logging()

# Silence noisy third-party loggers
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Start heavy work in background — API is responsive immediately
    start_build()
    logger.info("lifespan | background build started")
    yield


app = FastAPI(
    title="Escalation Analytics Agent",
    description="T-Mobile MACRO — session management, chat, streaming, and charts.",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class RequestIDMiddleware(BaseHTTPMiddleware):
    """Attach a unique request ID to every log line within a request."""

    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("X-Request-ID") or uuid.uuid4().hex[:12]
        request.state.request_id = request_id
        with logger.contextualize(request_id=request_id):
            response = await call_next(request)
            response.headers["X-Request-ID"] = request_id
            return response


app.add_middleware(RequestIDMiddleware)

app.include_router(v1_router, prefix="/api")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/readiness")
def readiness():
    """Returns 200 when the agent is fully initialized, 503 otherwise."""
    from fastapi.responses import JSONResponse

    if is_ready():
        duration = get_build_duration()
        return {
            "status": "ready",
            "startup_duration_sec": round(duration, 2) if duration else None,
        }
    return JSONResponse({"status": "initializing"}, status_code=503)

@app.get("/")
def health_root():
    return {"status": "ok"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        log_level="info",
        timeout_keep_alive=5000,
    )
