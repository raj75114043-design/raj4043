#!/usr/bin/env python3
"""
AI KPI Investigator — iterate every KPI in tmo_macro_kpi_master_details,
LLM-generate per-level aggregation SQL (National 6mo / Region 4mo / Market 4mo /
GC 4mo), validate each query via PG probe, persist as JSONL.

Usage:
    uv run python scripts/ai_kpi_investigator.py
    uv run python scripts/ai_kpi_investigator.py --out outputs/kpi_aggregations.jsonl
    uv run python scripts/ai_kpi_investigator.py --limit 5
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Sequence, TypedDict

import psycopg2
import tqdm
from langgraph.graph import StateGraph, START, END
from loguru import logger
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import config
from services.llm_provider import LLMProvider

DEFAULT_OUT = ROOT / "outputs" / "kpi_aggregations.jsonl"

# ── Domain constants ──────────────────────────────────────────────────────

SCOPE_CASCADE: dict[str, list[tuple[str, int]]] = {
    "general": [("national", 6), ("region", 4), ("market", 4), ("gc", 4)],
    "region": [("region", 4), ("market", 4), ("gc", 4)],
    "market": [("market", 4), ("gc", 4)],
    "gc": [("gc", 4)],
}

PROJECT_RULES = """
## Abbreviations
COP = Close-out Package | SCOP = Site Close-out Package | CW = Civil Work | TW = Tower Work
GC = General Contractor | AHLOA = AHLOB Modernization | MB = Magenta Build
NDPd = Nokia data | FTR = First Time Right | PP = Punch Point
NTP = Notice To Proceed | SPO = Service PO | CPO = Customer PO

## Verticals (smp_name values)
NTM, AHLOA, AHLOB, NSD, MB

## Project rules
1.  pj_p_*   = planned / forecast dates (Magenta)
2.  pj_a_*   = actual   / completion dates (Magenta)
3.  Forecast accuracy: same-week forecast & actual → 100% accurate
4.  Initial forecast → ndpd_mbt_combine_site_wise_forecast
5.  Forecast accuracy tables:
        tmo_macro_copilot_short_construction_start_forecast
        tmo_macro_copilot_short_construction_complete_forecast
6.  "Completed": AHLOA swap → pj_a_5175 actual; NTM install → ms_1555 actual
7.  "Past due": pj_a_* IS NOT NULL AND pj_p_* < CURRENT_DATE
8.  Respect explicit source mentions (Magenta / NDPd / MB)
9.  NDPd = Nokia (ndpd_*, stg_ndpd_*); Magenta = T-Mobile (tmo_retro_mbt_*, pm_tracker)
10. NDPd ↔ Magenta milestone map:
        ms_1549→pj_a_4250  ms_1310→pj_a_3800  ms_1316→pj_a_3825  ms_1321→pj_a_3825
        ms_1406→pj_a_4075  ms_1461→pj_a_3925  ms_1507→pj_a_4100  ms_1550→pj_a_4225
        ms_1555→pj_a_5175  ms_1557→pj_a_5500  ms_1559→pj_a_5525  ms_1899→pj_a_5275
        ms_1551→pj_a_4750
11. Pre-requisites = mandatory inputs for swap/install/integration scheduling
12. GC assignment: survey (ms_1321_module_spo_vendor_name),
    construction (construction_gc / ms_1555_module_spo_vendor_name),
    integration (ci_gc / ms_1559_module_spo_vendor_name)
13. AHLOA vendor metrics: swap/install cycle, PPs, SCOP cycle, HSE/H&S FTR%
14. NTM   vendor metrics: swap/install cycle, PPs, SCOP cycle, SCOP FTR%
15. Entitlement, NTP, Material → Magenta tracker fields only
16. Magenta synonyms: "Magenta built", "Magenta", "MB", "Magenta build", "Magenta tracker"
17. CW = Civil Work   |   TW = Tower Work
18. AHLOA E2E Magenta milestones: 3710, 1015, 4100, 3850, 3875, 3925, 4225, 5175, 1970, 5525
19. AHLOA E2E NDPd   milestones:  3710, 1313, 1407, 1331, 1461, 1507, 1550, 1555, 1557, 1559, 1970
20. SCOP Session = NDPc Session = Talon view Session
21. Milestone / ms / MS are equivalent
22. "AHLOB Modernization" = "AHLOA"
23. Vertical filter: smp_name = 'NTM' | 'AHLOA' | ...

## Schema conventions (authoritative — override JSON if they conflict)
- `pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined` — ALWAYS fully qualified.
  (JSON catalog frequently misspells as `stg_ndpd_mbt_tmobile_macro_combine` — correct it.)
- `gc_capacity_market_trial` — bare table (no schema prefix, no `stg_` prefix).
- `s_24x7_site_access` — column (JSON often misspells as `s_24x7_site_acces`).
- Trust these corrections over the JSON `tables_involved` / `mapped_tables_columns` list.
- World-view JSONs sometimes list wrong column names (e.g., `fe_company` instead of
  `gc_company`). Prefer the conventional name; flag in a comment if unsure.

## Column types (actual DB types — DO NOT trust JSON hints)
- `ms_*_actual`, `ms_*_start`, `ms_*_complete*`, `pj_*_finish`, `pj_*_date` →
  `timestamp without time zone`. Cast with `::date` directly. NEVER wrap in
  `TRIM(...)` or `NULLIF(..., '')` — that throws `btrim(timestamp) does not exist`.
- Flag / text columns (`isdeleted`, `level_N_status`, `hse_staus`,
  `s_24x7_site_access`, SO/SPO header columns) → `character varying`.
  Use `COALESCE(LOWER(TRIM(col::text)), '') <> 'true'` style, never boolean.
- There are no real booleans in this schema. `COALESCE(col, FALSE) = FALSE` FAILS
  because the column is text — use string comparison instead.
- Past-due predicate on timestamp: `pj_a_X IS NULL AND pj_p_X::date < CURRENT_DATE`.

## Cascade pattern (the 4 aggregation levels)
- national: last 6 months, NO geographic GROUP BY, single-row summary.
- region:   last 4 months, GROUP BY rgn_region.
- market:   last 4 months, GROUP BY rgn_region, m_market.
- gc:       last 4 months, GROUP BY rgn_region, m_market, construction_gc.
- Window anchor defaults to the END event (complete / actual date), not the start —
  aligns with closed-cycle reporting.
- Join keys across sources: `m_market ↔ market`, `construction_gc ↔ gc_company`.
- National total may be ≥ sum of lower-level totals when joins drop unmatched rows;
  that's expected, not a bug.

## KPI-shape selection (pick the right aggregation from the formula)
- Count KPIs (sites ready, WIP, scrapped) → `COUNT(DISTINCT s_site_id)`
  plus optional days-pending stats (AVG/MAX of `CURRENT_DATE - anchor::date`).
- Rate / percentage KPIs (FTR%, approval%, utilization%) → `FILTER` clauses
  for numerator / denominator, one `ROUND(100.0 * num::numeric / NULLIF(den, 0), 2)`.
- Cycle-time KPIs (civil Cx, integration) → distribution stats:
  count, avg, median (PERCENTILE_CONT(0.5)), p90 (PERCENTILE_CONT(0.9)),
  min, max, plus a `data_quality_flag_negative` counter for rows where
  `complete < start`. (`PERCENTILE_CONT(...) FILTER (...)` requires PG 11+.)
- Default ORDER BY: severity-first (worst performers at top) — useful for
  escalation agent narratives.

## Judgment calls (apply silently, flag only if non-obvious)
- If JSON lists a table in `tables_involved` but supplies no columns from it for
  the KPI math (e.g., `pm_tracker`), SKIP the join — don't hallucinate a predicate.
- Mixed prerequisite lists: dates → `GREATEST(d1::date, d2::date, ...)`;
  flags → `col IS NOT NULL` / `LOWER(TRIM(col::text)) = 'yes'`.
- When multiple milestone columns could back one concept (three different
  integration-complete columns), pick the one the KPI formula names verbatim;
  flag alternatives in a short SQL comment.
"""


@dataclass
class KPIRecord:
    id: int
    kpi_name: str
    description: str = ""
    formula: str = ""
    mapped_tables_cols: str = ""
    logic: str = ""
    vertical: str = ""
    status: str = ""
    source: str = "db"  # "db" (master_details) or "gcl" (gcl_kpi.json)
    existing_national: str = ""
    existing_region: str = ""
    existing_market: str = ""
    existing_market_with_gc: str = ""
    gcl_context: dict = field(default_factory=dict)

    @classmethod
    def from_row(cls, row: dict) -> "KPIRecord":
        return cls(
            id=row["id"],
            kpi_name=row.get("kpi_name") or "",
            description=row.get("description") or "",
            formula=row.get("formula") or "",
            mapped_tables_cols=row.get("mapped_tables_cols") or "",
            logic=row.get("logic") or "",
            vertical=row.get("vertical") or "",
            status=row.get("status") or "",
            source="db",
            existing_national=row.get("national") or "",
            existing_region=row.get("region") or "",
            existing_market=row.get("market") or "",
            existing_market_with_gc=row.get("market_with_gc") or "",
        )

    @classmethod
    def from_gcl_item(cls, item: dict) -> "KPIRecord":
        return cls(
            id=item.get("kpi_id") or 0,
            kpi_name=item.get("kpi_name") or "",
            description=item.get("description") or "",
            formula=item.get("formula") or "",
            mapped_tables_cols=item.get("mapped_tables_columns") or "",
            logic=item.get("logic") or "",
            vertical=item.get("project_name") or item.get("vertical") or "",
            status="",
            source="gcl",
        )


@dataclass
class ValidationResult:
    status: str = "ok"  # ok | error
    error: str | None = None
    plan: str | None = None
    sample_row_count: int = 0
    sample: list[dict] | None = None


@dataclass
class LevelQuery:
    level: str
    months: int
    sql: str
    validation: ValidationResult = field(default_factory=ValidationResult)


@dataclass
class GenerationResult:
    """SQL per level + optional pre-computed validations (set by repairing generator)."""
    level_sqls: dict[str, str]
    validations: dict[str, ValidationResult] = field(default_factory=dict)


@dataclass
class KPIAggregation:
    kpi_id: int
    kpi_name: str
    vertical: str
    status: str
    description: str
    source: str  # "db" or "gcl"
    levels: dict[str, LevelQuery]
    scope_cascades: dict[str, list[str]]
    generated_at: str
    gcl_context: dict = field(default_factory=dict)


DEFAULT_SEARCH_PATH = "pwc_macro_staging_schema,public"


@dataclass
class PGConfig:
    """PostgreSQL connection params. Falls back to config.PG_* for unset fields."""
    host: str | None = None
    port: int | None = None
    database: str | None = None
    user: str | None = None
    password: str | None = None
    search_path: str | None = None

    def resolved(self) -> dict:
        return {
            "host": self.host or config.PG_HOST,
            "port": self.port or config.PG_PORT,
            "database": self.database or config.PG_DATABASE,
            "user": self.user or config.PG_USER,
            "password": self.password or config.PG_PASSWORD,
        }


class DatabaseClient:
    """Thin PG wrapper — manages one connection, exposes query primitives."""

    def __init__(self, pg: PGConfig | None = None, autocommit: bool = True):
        self._pg = pg or PGConfig()
        # libpq parses whitespace as option separator — strip spaces from search_path.
        search_path = (self._pg.search_path or DEFAULT_SEARCH_PATH).replace(" ", "")
        self._conn = psycopg2.connect(
            connect_timeout=30,
            **self._pg.resolved(),
            options=f"-c search_path={search_path}",
        )
        self._conn.autocommit = autocommit

    def fetch_all(self, sql: str, params: tuple = ()) -> list[dict]:
        with self._conn.cursor() as cur:
            cur.execute(sql, params)
            cols = [c[0] for c in (cur.description or [])]
            return [dict(zip(cols, r)) for r in cur.fetchall()]

    def fetch_many(self, sql: str, n: int, params: tuple = ()) -> list[dict]:
        with self._conn.cursor() as cur:
            cur.execute(sql, params)
            cols = [c[0] for c in (cur.description or [])]
            return [dict(zip(cols, r)) for r in cur.fetchmany(n)]

    def explain(self, sql: str) -> str:
        with self._conn.cursor() as cur:
            cur.execute("EXPLAIN " + sql)
            return "\n".join(r[0] for r in cur.fetchall())

    def close(self) -> None:
        self._conn.close()


class LLMClient:
    """Wraps LLMProvider. Offers raw + Pydantic-structured completion."""

    _FENCE_RE = re.compile(r"```(?:json|sql)?\s*(.*?)\s*```", re.DOTALL)

    def __init__(self, model: str = "gpt-5-mini", temperature: float = 0.0):
        self._llm = LLMProvider(model=model, temperature=temperature).get_llm()

    def complete(self, prompt: str) -> str:
        resp = self._llm.invoke(prompt)
        return getattr(resp, "content", str(resp))

    def complete_json(self, prompt: str) -> dict:
        raw = self.complete(prompt)
        m = self._FENCE_RE.search(raw)
        payload = m.group(1).strip() if m else raw.strip()
        return json.loads(payload)

    def complete_structured(self, prompt: str, schema: type[BaseModel]) -> BaseModel:
        """Return a Pydantic instance via LangChain structured output."""
        structured = self._llm.with_structured_output(schema)
        return structured.invoke(prompt)


class LevelQueriesOutput(BaseModel):
    """LLM returns all 4 per-level SQL strings in one shot."""
    national: str = Field(description=(
        "PostgreSQL for national level: last 6 months, NO geographic GROUP BY, "
        "single-row summary. No LIMIT, no trailing semicolon."
    ))
    region: str = Field(description=(
        "PostgreSQL for region level: last 4 months, GROUP BY rgn_region. "
        "No LIMIT, no trailing semicolon."
    ))
    market: str = Field(description=(
        "PostgreSQL for market level: last 4 months, GROUP BY rgn_region, m_market. "
        "No LIMIT, no trailing semicolon."
    ))
    gc: str = Field(description=(
        "PostgreSQL for gc level: last 4 months, "
        "GROUP BY rgn_region, m_market, construction_gc. No LIMIT, no trailing semicolon."
    ))


class SingleSQLOutput(BaseModel):
    """LLM returns a single repaired SQL string."""
    sql: str = Field(description="Corrected PostgreSQL query. No LIMIT, no trailing semicolon.")


class KPISource(ABC):
    """Abstract KPI origin — DB master_details, GCL JSON, etc."""

    @abstractmethod
    def list_all(self) -> list[KPIRecord]: ...


class DBKPISource(KPISource):
    """KPIs from public.tmo_macro_kpi_master_details (with pre-built per-level SQL)."""

    _SQL_FETCH_ALL = """
        SELECT id, kpi_name, description, formula, mapped_tables_cols, logic,
               national, region, market, market_with_gc, area,
               COALESCE(project_name, '') AS vertical, status
        FROM public.tmo_macro_kpi_master_details
        ORDER BY id
    """

    def __init__(self, db: DatabaseClient):
        self._db = db

    def list_all(self) -> list[KPIRecord]:
        rows = self._db.fetch_all(self._SQL_FETCH_ALL)
        return [KPIRecord.from_row(r) for r in rows]


class GCLKPISource(KPISource):
    """KPIs from the Excel catalog (gcl_kpi.json). Context fetched lazily via GCL."""

    def __init__(self, json_path: Path):
        self._json_path = json_path

    def list_all(self) -> list[KPIRecord]:
        data = json.loads(self._json_path.read_text())
        if not isinstance(data, list):
            raise ValueError(f"{self._json_path} must be a JSON list")
        return [KPIRecord.from_gcl_item(item) for item in data]


class GCLClient:
    """Wraps services.gcl_service.call_gcl with robust response parsing."""

    def __init__(self):
        from services.gcl_service import call_gcl  # lazy (LangChain heavy import)
        self._call_gcl = call_gcl

    def fetch(self, kpi_name: str) -> dict:
        """Invoke call_gcl, parse response, return world_view dict (or {} on failure)."""
        try:
            raw = self._call_gcl(kpi_name)
        except Exception as e:
            logger.warning(f"GCL call failed for '{kpi_name}': {e}")
            return {}

        parsed = self._parse(raw)
        if not parsed.get("success"):
            logger.debug(f"GCL returned non-success for '{kpi_name}': {parsed}")
        return parsed.get("world_view") or {}

    @staticmethod
    def _parse(raw: object) -> dict:
        if isinstance(raw, dict):
            return raw
        if not isinstance(raw, str):
            return {}
        text = raw.strip()
        # gcl_service.call_gcl returns TOONS — try that first
        try:
            import toons
            return toons.loads(text)
        except Exception:
            pass
        try:
            return json.loads(text)
        except (json.JSONDecodeError, TypeError):
            return {}


class GCLContextEnricher:
    """Populates kpi.gcl_context by calling GCL. Skips DB-source KPIs."""

    def __init__(self, gcl: GCLClient):
        self._gcl = gcl

    def enrich(self, kpi: KPIRecord) -> None:
        if kpi.source != "gcl":
            return
        kpi.gcl_context = self._gcl.fetch(kpi.kpi_name)


class QueryGenerator(ABC):
    """Strategy: turn a KPI into per-level SQL (and optionally validations)."""

    LEVELS = ("national", "region", "market", "gc")
    LEVEL_MONTHS = {"national": 6, "region": 4, "market": 4, "gc": 4}

    @abstractmethod
    def generate(self, kpi: KPIRecord) -> GenerationResult: ...


class LLMQueryGenerator(QueryGenerator):
    """Uses an LLM with Pydantic structured output to emit one SQL per level."""

    def __init__(self, llm: LLMClient):
        self._llm = llm

    def generate(self, kpi: KPIRecord) -> GenerationResult:
        prompt = self._build_prompt(kpi)
        try:
            out = self._llm.complete_structured(prompt, LevelQueriesOutput)
            assert isinstance(out, LevelQueriesOutput)
        except Exception as e:
            logger.error(f"LLM generation failed (kpi_id={kpi.id}): {e}")
            return GenerationResult(level_sqls={lvl: "" for lvl in self.LEVELS})
        return GenerationResult(level_sqls={
            "national": out.national.strip(),
            "region": out.region.strip(),
            "market": out.market.strip(),
            "gc": out.gc.strip(),
        })

    def _build_prompt(self, kpi: KPIRecord) -> str:
        context_block = self._context_block_gcl(kpi) if kpi.source == "gcl" \
            else self._context_block_db(kpi)
        return f"""Generate 4 PostgreSQL queries for this KPI — one per granularity level.

{PROJECT_RULES}

KPI CONTEXT
- id:          {kpi.id}
- name:        {kpi.kpi_name}
- vertical:    {kpi.vertical or '(none)'}
- status:      {kpi.status or '(none)'}
- description: {kpi.description or '(none)'}

FORMULA / LOGIC
{kpi.formula or kpi.logic or '(none provided — derive from name+description)'}

MAPPED TABLES / COLS
{kpi.mapped_tables_cols or '(none)'}

{context_block}

LEVEL REQUIREMENTS (per abcd.md rule matrix)
- national: last 6 months. NO geographic GROUP BY. Single-row summary.
- region:   last 4 months. GROUP BY rgn_region.
- market:   last 4 months. GROUP BY rgn_region, m_market.
- gc:       last 4 months. GROUP BY rgn_region, m_market, construction_gc.

SQL CONSTRAINTS
- Valid PostgreSQL. No LIMIT clause (added at test time by the harness).
- No trailing semicolon. search_path includes pwc_macro_staging_schema + public.
- Use actual date columns (pj_a_*, ms_*_actual, result_date_time) for time filter.
  These are timestamps — cast with `::date`, never wrap in TRIM/NULLIF.
- Text/flag columns (level_N_status, s_24x7_site_access, isdeleted, etc.) need
  `COALESCE(LOWER(TRIM(col::text)), '')` comparisons — no booleans.
- Apply vertical filter via smp_name when the KPI is vertical-specific.
- Reuse / adapt the EXISTING SQL above when useful — ensure GROUP BY matches the level.
- Geographic columns (rgn_region, m_market, construction_gc) come from
  pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined. Join there if missing.
- Pick the KPI shape intentionally: Count → COUNT(DISTINCT); Rate → FILTER + ROUND;
  Cycle-time → distribution stats + data_quality_flag_negative counter.
- Default ORDER BY: severity-first (worst performers on top).

Emit one query per level via the structured output schema (national / region / market / gc).
"""

    @staticmethod
    def _context_block_db(kpi: KPIRecord) -> str:
        return "\n".join(
            f"### EXISTING SQL — {label}:\n{sql}\n" if sql else
            f"### EXISTING SQL — {label}: (empty)\n"
            for label, sql in (
                ("national", kpi.existing_national),
                ("region", kpi.existing_region),
                ("market", kpi.existing_market),
                ("market_with_gc", kpi.existing_market_with_gc),
            )
        )

    @staticmethod
    def _context_block_gcl(kpi: KPIRecord) -> str:
        """Format the GCL world_view response into a prompt-friendly block."""
        wv = kpi.gcl_context or {}
        if not wv:
            return "### GCL CONTEXT: (unavailable — GCL returned no world_view)\n"

        parts: list[str] = ["### GCL CONTEXT"]
        if schema := wv.get("schema_name"):
            parts.append(f"- schema_name: {schema}")

        # KPI-level context (reference SQL lives here)
        for ctx in (wv.get("kpi_contexts") or [])[:3]:
            if logic := ctx.get("logic"):
                parts.append(f"\n#### REFERENCE SQL (from GCL logic):\n{logic}")
            if tabs := ctx.get("tables_involved"):
                parts.append(f"- tables_involved: {', '.join(tabs)}")
            if mc := ctx.get("matched_columns_by_table"):
                parts.append("- matched_columns_by_table:")
                for tbl, cols in mc.items():
                    if isinstance(cols, str):
                        parts.append(f"    {tbl}: {cols}")
                    elif isinstance(cols, (list, tuple)):
                        parts.append(f"    {tbl}: {', '.join(cols)}")

        # Primary focused table (full referenced columns)
        for tbl, info in (wv.get("focused_tables") or {}).items():
            refs = info.get("referenced_columns") or []
            ref_names = [
                (c if isinstance(c, str) else c.get("name", "") or "")
                for c in refs
            ]
            ref_names = [n for n in ref_names if n]
            if ref_names:
                parts.append(f"\n#### FOCUSED TABLE: {tbl}")
                parts.append(f"- total_columns_in_table: {info.get('total_columns_in_table')}")
                parts.append(f"- referenced_columns: {', '.join(ref_names[:40])}")

        # Top related tables (highest affinity first)
        related = wv.get("related_tables") or {}
        ranked = sorted(related.items(),
                        key=lambda kv: kv[1].get("affinity_score", 0), reverse=True)[:3]
        if ranked:
            parts.append("\n#### RELATED TABLES (by affinity):")
            for tbl, info in ranked:
                shared = info.get("shared_columns") or []
                names = [c if isinstance(c, str) else c.get("name", "") for c in shared][:10]
                parts.append(
                    f"- {tbl} (affinity={info.get('affinity_score', 0):.2f}): "
                    f"shared={', '.join(n for n in names if n)}"
                )

        # Example Q&A → reference SQL patterns
        for eq in (wv.get("example_questions") or [])[:3]:
            q = eq.get("question") or ""
            ref = eq.get("reference_sql") or ""
            if q and ref:
                parts.append(f"\n#### EXAMPLE: {q}\n{ref}")

        return "\n".join(parts) + "\n"


class QueryValidator:
    """Runs EXPLAIN + wrapped LIMIT-N probe against PG."""

    def __init__(self, db: DatabaseClient, sample_size: int = 2):
        self._db = db
        self._sample_size = sample_size

    @property
    def db(self) -> DatabaseClient:
        return self._db

    def validate(self, sql: str) -> ValidationResult:
        if not sql.strip():
            return ValidationResult(status="error", error="empty SQL from LLM")

        result = ValidationResult()
        try:
            result.plan = self._db.explain(sql)[:1500]
        except Exception as e:
            return ValidationResult(status="error", error=f"EXPLAIN: {e}")

        try:
            rows = self._db.fetch_many(self._wrap(sql), self._sample_size)
            result.sample_row_count = len(rows)
            result.sample = rows
        except Exception as e:
            return ValidationResult(status="error", error=f"EXEC: {e}", plan=result.plan)

        return result

    @staticmethod
    def _wrap(sql: str) -> str:
        return f"SELECT * FROM (\n{sql.strip().rstrip(';')}\n) AS __probe"


class _RepairState(TypedDict):
    """LangGraph state carried through the generate → validate → repair loop."""
    kpi: KPIRecord
    level_sqls: dict[str, str]
    validations: dict[str, ValidationResult]
    iteration: int
    max_iterations: int


class RepairingQueryGenerator(QueryGenerator):
    """Decorator: wraps a base QueryGenerator with a LangGraph repair loop.

    Flow:
        generate_all → validate_all → (errors? → repair_failing → validate_all)*
                                    → END (on all-ok OR iteration cap)
    """

    def __init__(
            self,
            base: QueryGenerator,
            llm: LLMClient,
            validator: QueryValidator,
            max_iterations: int = 2,
    ):
        self._base = base
        self._llm = llm
        self._validator = validator
        self._max_iterations = max_iterations
        self._graph = self._build_graph()

    def generate(self, kpi: KPIRecord) -> GenerationResult:
        initial: _RepairState = {
            "kpi": kpi,
            "level_sqls": {},
            "validations": {},
            "iteration": 0,
            "max_iterations": self._max_iterations,
        }
        final = self._graph.invoke(initial)
        return GenerationResult(
            level_sqls=final["level_sqls"],
            validations=final["validations"],
        )

    # ── node implementations ────────────────────────────────────────────

    def _node_generate(self, state: _RepairState) -> _RepairState:
        base_result = self._base.generate(state["kpi"])
        return {**state, "level_sqls": base_result.level_sqls}

    def _node_validate(self, state: _RepairState) -> _RepairState:
        validations = {
            lvl: self._validator.validate(sql)
            for lvl, sql in state["level_sqls"].items()
        }
        return {**state, "validations": validations}

    def _node_repair(self, state: _RepairState) -> _RepairState:
        kpi = state["kpi"]
        updated = dict(state["level_sqls"])
        for lvl, val in state["validations"].items():
            if val.status == "ok":
                continue
            try:
                out = self._llm.complete_structured(
                    self._build_repair_prompt(kpi, lvl, updated[lvl], val.error or ""),
                    SingleSQLOutput,
                )
                assert isinstance(out, SingleSQLOutput)
                updated[lvl] = out.sql.strip()
                logger.info(f"Repair kpi_id={kpi.id} level={lvl} (iter {state['iteration'] + 1})")
            except Exception as e:
                logger.error(f"Repair LLM failed kpi={kpi.id} level={lvl}: {e}")
        return {**state, "level_sqls": updated, "iteration": state["iteration"] + 1}

    def _route_after_validate(self, state: _RepairState) -> str:
        has_err = any(v.status == "error" for v in state["validations"].values())
        if has_err and state["iteration"] < state["max_iterations"]:
            return "repair"
        return END

    _TABLE_RE = re.compile(r'(?:FROM|JOIN)\s+([a-zA-Z_][\w.]*)', re.IGNORECASE)

    _IDENT_RE = re.compile(r"^[A-Za-z_][\w.]*$")

    def _probe_tables(self, sql: str) -> str:
        """Extract tables from sql, SELECT * LIMIT 1 each, return column listing."""
        tables = list({m.group(1) for m in self._TABLE_RE.finditer(sql)})
        probes: list[str] = []
        for tbl in tables:
            if not self._IDENT_RE.match(tbl):
                probes.append(f"- {tbl}: SKIPPED (invalid identifier)")
                continue
            try:
                cols = self._validator.db.fetch_many(
                    f"SELECT * FROM {tbl} LIMIT 1", 1,
                )
                col_names = list(cols[0].keys()) if cols else []
                probes.append(f"- {tbl}: {', '.join(col_names) or '(no rows)'}")
            except Exception as e:
                probes.append(f"- {tbl}: PROBE ERROR — {e}")
        return "\n".join(probes) or "(no tables detected in SQL)"

    def _build_repair_prompt(
            self, kpi: KPIRecord, level: str, bad_sql: str, error: str,
    ) -> str:
        level_req = {
            "national": "last 6 months, NO geographic GROUP BY",
            "region": "last 4 months, GROUP BY rgn_region",
            "market": "last 4 months, GROUP BY rgn_region, m_market",
            "gc": "last 4 months, GROUP BY rgn_region, m_market, construction_gc",
        }[level]
        live_probes = self._probe_tables(bad_sql)
        return f"""Fix this PostgreSQL query based on the error.

{PROJECT_RULES}

KPI: {kpi.kpi_name} (id={kpi.id}, vertical={kpi.vertical})
Level: {level} — {level_req}

FAILING SQL:
{bad_sql}

POSTGRES ERROR:
{error}

LIVE COLUMN PROBES (SELECT * LIMIT 1 on tables in the failing SQL):
{live_probes}

Fix rules:
- Use columns that EXIST in the live probes above — do not invent names.
- If a table in the SQL is missing/wrong, swap it for the closest match mentioned in rules.
- Preserve query intent (same time window, same scope, same GROUP BY grain).
- Respect NDPd↔Magenta milestone map (rule 10) when column names are wrong.
- No LIMIT. No trailing semicolon.

Return corrected SQL via the structured output schema.
"""

    def _build_graph(self):
        g = StateGraph(_RepairState)
        g.add_node("generate", self._node_generate)
        g.add_node("validate", self._node_validate)
        g.add_node("repair", self._node_repair)

        g.add_edge(START, "generate")
        g.add_edge("generate", "validate")
        g.add_edge("repair", "validate")
        g.add_conditional_edges("validate", self._route_after_validate,
                                {"repair": "repair", END: END})
        return g.compile()


class JsonlWriter:
    """Streaming JSONL sink — one aggregation per line."""

    def __init__(self, out_path: Path):
        self._path = out_path
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = open(self._path, "w")

    def write(self, agg: KPIAggregation) -> None:
        self._fh.write(json.dumps(asdict(agg), default=str) + "\n")
        self._fh.flush()

    def close(self) -> None:
        self._fh.close()

    def __enter__(self) -> "JsonlWriter":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # noqa: ANN001
        del exc_type, exc_val, exc_tb
        self.close()


# ── Orchestrator ──────────────────────────────────────────────────────────

@dataclass
class RunSummary:
    kpis: int = 0
    levels_ok: int = 0
    levels_err: int = 0
    out: str = ""


class KPIAggregationPipeline:
    """Top-level flow: fetch → (enrich) → generate → validate → persist."""

    def __init__(
            self,
            source: KPISource,
            generator: QueryGenerator,
            validator: QueryValidator,
            writer: JsonlWriter,
            enricher: GCLContextEnricher | None = None,
    ):
        self._source = source
        self._generator = generator
        self._validator = validator
        self._writer = writer
        self._enricher = enricher

    def run(self, limit: int | None = None) -> RunSummary:
        kpis = self._source.list_all()
        if limit:
            kpis = kpis[:limit]
        logger.info(f"Processing {len(kpis)} KPIs")

        summary = RunSummary(kpis=len(kpis), out=str(self._writer._path))
        for kpi in tqdm.tqdm(kpis, desc="KPIs"):
            agg = self._process(kpi)
            self._tally(agg, summary)
            self._writer.write(agg)

        logger.info(f"Done: {asdict(summary)}")
        return summary

    def _process(self, kpi: KPIRecord) -> KPIAggregation:
        if self._enricher is not None:
            self._enricher.enrich(kpi)
        result = self._generator.generate(kpi)
        levels: dict[str, LevelQuery] = {}
        for level in QueryGenerator.LEVELS:
            sql = result.level_sqls.get(level, "")
            validation = result.validations.get(level) or self._validator.validate(sql)
            levels[level] = LevelQuery(
                level=level,
                months=QueryGenerator.LEVEL_MONTHS[level],
                sql=sql,
                validation=validation,
            )
        return KPIAggregation(
            kpi_id=kpi.id,
            kpi_name=kpi.kpi_name,
            vertical=kpi.vertical,
            status=kpi.status,
            description=kpi.description,
            source=kpi.source,
            levels=levels,
            scope_cascades={k: [lvl for lvl, _ in v] for k, v in SCOPE_CASCADE.items()},
            generated_at=datetime.now(timezone.utc).isoformat(),
            gcl_context=kpi.gcl_context if kpi.source == "gcl" else {},
        )

    @staticmethod
    def _tally(agg: KPIAggregation, summary: RunSummary) -> None:
        for lq in agg.levels.values():
            if lq.validation.status == "ok":
                summary.levels_ok += 1
            else:
                summary.levels_err += 1


# ── CLI ───────────────────────────────────────────────────────────────────

DEFAULT_GCL_JSON = ROOT / "gcl_kpi.json"


def _build_cli() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="LLM-generated KPI aggregation queries → JSONL")
    p.add_argument("--source", choices=("db", "gcl"), default="db",
                   help="db = master_details (pre-built SQL); "
                        "gcl = gcl_kpi.json (context fetched via call_gcl per KPI)")
    p.add_argument("--gcl-json", type=Path, default=DEFAULT_GCL_JSON,
                   help=f"Path to Excel KPI catalog JSON (default: {DEFAULT_GCL_JSON})")
    p.add_argument("--out", type=Path, default=None,
                   help="Output JSONL path. Defaults to outputs/kpi_aggregations_<source>.jsonl")
    p.add_argument("--limit", type=int, default=None,
                   help="Only process first N KPIs (smoke test)")
    p.add_argument("--model", default="gpt-5-mini", help="LLM model")
    p.add_argument("--sample-size", type=int, default=2,
                   help="Rows fetched during probe (default 2)")
    p.add_argument("--max-repairs", type=int, default=1,
                   help="Max LangGraph repair iterations per KPI (default 1). "
                        "Set 0 to disable. Each iteration = one LLM call per failing level.")

    # ── PG connection overrides (default to config.PG_*) ────────────────
    p.add_argument("--pg-database", default=None,
                   help="Override PG database for BOTH metadata fetch + SQL probes.")
    p.add_argument("--pg-schema", default=None,
                   help="Set search_path on BOTH connections "
                        "(e.g. 'pwc_macro_staging_schema, public').")
    p.add_argument("--probe-database", default=None,
                   help="Separate PG database used ONLY by the validator/probe. "
                        "Overrides --pg-database for probes; leaves metadata fetch untouched.")
    p.add_argument("--probe-schema", default=None,
                   help="search_path for the probe connection only.")
    return p


def _build_pg_clients(args) -> tuple[DatabaseClient, DatabaseClient]:  # noqa: ANN001
    """Return (metadata_db, probe_db). If probe overrides are set, open a 2nd connection."""
    meta_cfg = PGConfig(database=args.pg_database, search_path=args.pg_schema)
    meta_db = DatabaseClient(meta_cfg)

    uses_separate_probe = args.probe_database or args.probe_schema
    if not uses_separate_probe:
        return meta_db, meta_db

    probe_cfg = PGConfig(
        database=args.probe_database or args.pg_database,
        search_path=args.probe_schema or args.pg_schema,
    )
    probe_db = DatabaseClient(probe_cfg)
    return meta_db, probe_db


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_cli().parse_args(argv)

    out_path = args.out or Path(f"kpi_aggregations_{args.source}.jsonl")

    meta_db, probe_db = _build_pg_clients(args)
    try:
        llm = LLMClient(model=args.model)
        validator = QueryValidator(probe_db, sample_size=args.sample_size)

        source: KPISource
        enricher: GCLContextEnricher | None
        if args.source == "db":
            source = DBKPISource(meta_db)
            enricher = None
        else:
            source = GCLKPISource(args.gcl_json)
            enricher = GCLContextEnricher(GCLClient())

        generator: QueryGenerator = LLMQueryGenerator(llm)
        if args.max_repairs > 0:
            generator = RepairingQueryGenerator(
                base=generator, llm=llm, validator=validator,
                max_iterations=args.max_repairs,
            )

        with JsonlWriter(out_path) as writer:
            pipeline = KPIAggregationPipeline(
                source=source, generator=generator, validator=validator,
                writer=writer, enricher=enricher,
            )
            summary = pipeline.run(limit=args.limit)
        print(json.dumps(asdict(summary), indent=2))
    finally:
        meta_db.close()
        if probe_db is not meta_db:
            probe_db.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
