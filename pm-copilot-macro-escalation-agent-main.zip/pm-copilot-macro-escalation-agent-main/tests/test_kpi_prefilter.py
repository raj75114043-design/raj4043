"""Prefilter tests for `services.kpi_bootstrap._build_prefiltered_catalog`.

Hits the real DB via `load_db_kpis()` and the real `gcl_kpi.json`. Requires
DB credentials (config.PG_*) to be reachable — otherwise `load_db_kpis`
returns 0 rows and the DB-specific tests are skipped.

Run just the tests:
    pytest tests/test_kpi_prefilter.py -v

Run as a script to SEE the scored picks for the target query:
    python -m tests.test_kpi_prefilter
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from services import kpi_bootstrap
from services import kpi_search_service


TARGET_QUERY = (
    "Post AHLOA Swap Completion 48 Hrs KPI Monitoring Pending "
    "in SOUTH region for 3 days"
)
TARGET_VERTICAL = "AHLOA"


@pytest.fixture(autouse=True, scope="module")
def _load_catalog_once():
    """Load real DB + Excel KPI catalogs once per test module."""
    kpi_search_service.load_db_kpis()
    kpi_search_service.load_excel_kpis_from_json()
    yield


@pytest.fixture
def stub_db_rows():
    """Real DB rows loaded via `load_db_kpis()` — no mocking."""
    rows = kpi_search_service.get_db_kpi_metadata_rows()
    if not rows:
        pytest.skip("DB KPI catalog is empty — check config.PG_* credentials")
    return rows


# ── Tests ────────────────────────────────────────────────────────────────────


def test_prefilter_keeps_ahloa_vertical_and_drops_other_verticals(stub_db_rows):
    """Vertical filter should drop non-AHLOA DB rows when vertical=AHLOA.

    Only checks the `[db:*]` portion — Excel rows aren't vertical-filtered
    (they carry no `project_name`) so their names may legitimately contain
    "MB" or "NTM" tokens.
    """
    catalog, counts = kpi_bootstrap._build_prefiltered_catalog(
        query=TARGET_QUERY,
        hints_text="",
        vertical=TARGET_VERTICAL,
    )
    db_lines = [ln for ln in catalog.splitlines() if ln.startswith("[db:")]

    assert db_lines, "expected at least one DB row in catalog"
    # Every DB line must either carry AHLOA in its vertical tag or be blank
    # (rows with no project_name pass the filter unconditionally).
    for line in db_lines:
        tag = line.rsplit("vertical:", 1)[-1].strip()
        assert tag == "" or "AHLOA" in tag.upper(), (
            f"non-AHLOA DB line leaked: {line}"
        )
    assert counts["db"] >= 1


def test_prefilter_surfaces_swap_and_48hr_kpis(stub_db_rows):
    """A KPI matching swap / 48 / hrs / monitoring / pending / completion should
    rank near the top of the scored DB pool."""
    scored = _score_all_db_rows(stub_db_rows, TARGET_QUERY, vertical=TARGET_VERTICAL)
    assert scored, "no DB rows scored — is the DB catalog empty?"

    # At least the #1 pick should share more than one non-stopword token with the query.
    top_score, top_row = scored[0]
    assert top_score > 0, (
        f"top DB pick has zero lexical score — prefilter is dead.\n"
        f"top row: {top_row.get('kpi_name')!r}"
    )

    top_10 = [row["kpi_name"] for _, row in scored[:10]]
    overlap_keywords = ("swap", "48", "hrs", "hr", "completion", "monitoring", "pending")
    hits = [n for n in top_10 if any(kw in n.lower() for kw in overlap_keywords)]
    assert hits, (
        f"no swap/48hr/monitoring/pending KPI in top-10 DB picks.\n"
        f"top 10: {top_10}"
    )


def test_prefilter_excel_surfaces_48hrs_kpi():
    """Real Excel KPI '...48 hrs Alarm clearance pending' should score above most peers."""
    excel_rows = kpi_search_service.get_excel_kpi_metadata_rows()
    assert excel_rows, "gcl_kpi.json must be loaded"

    q_tokens = kpi_bootstrap._tokenize(TARGET_QUERY)
    scored = sorted(
        (
            (kpi_bootstrap._score_row(r, q_tokens, set(), TARGET_QUERY.lower()), i, r)
            for i, r in enumerate(excel_rows)
            if r.get("kpi_name")
        ),
        key=lambda t: t[0],
        reverse=True,
    )
    top_names = [r["kpi_name"].strip() for _, _, r in scored[:5]]

    # The 48 hrs clearance KPI is the single best lexical match in the Excel catalog.
    assert any("48 hrs" in n.lower() for n in top_names), (
        f"expected a 48-hrs KPI in top 5 Excel picks; got {top_names}"
    )


def test_prefilter_catalog_format_preserves_indices(stub_db_rows):
    """`[db:i]` / `[excel:i]` tags must be preserved so _convert_llm_matches can look rows back up."""
    catalog, _ = kpi_bootstrap._build_prefiltered_catalog(
        query=TARGET_QUERY,
        hints_text="",
        vertical=TARGET_VERTICAL,
    )
    lines = [ln for ln in catalog.splitlines() if ln.strip()]
    for line in lines:
        assert line.startswith("[db:") or line.startswith("[excel:"), (
            f"malformed catalog line: {line!r}"
        )


def test_prefilter_empty_on_nonsense_query_still_returns_something(stub_db_rows):
    """When no lexical overlap exists, prefilter still returns a small pool (top-N)."""
    catalog, counts = kpi_bootstrap._build_prefiltered_catalog(
        query="zzzz nothing matches here",
        hints_text="",
        vertical=TARGET_VERTICAL,
    )
    # Fallback branch in _build_prefiltered_catalog keeps up to TOP_DB rows even when score=0.
    assert counts["db"] >= 1 or counts["excel"] == 0, catalog


# ── Helpers ──────────────────────────────────────────────────────────────────


def _score_all_db_rows(
    db_rows: list[dict], query: str, vertical: str,
) -> list[tuple[float, dict]]:
    """Score every DB row individually (post vertical filter) for inspection."""
    v_upper = vertical.strip().upper() if vertical else ""
    q_tokens = kpi_bootstrap._tokenize(query)
    q_lower = query.lower()

    scored: list[tuple[float, dict]] = []
    for row in db_rows:
        proj = str(row.get("project_name", "")).strip().upper()
        if v_upper and proj and v_upper not in proj and proj not in v_upper:
            continue
        scored.append(
            (kpi_bootstrap._score_row(row, q_tokens, set(), q_lower), row),
        )
    scored.sort(key=lambda t: t[0], reverse=True)
    return scored


# ── Script mode: print the scored picks so a human can eyeball them ──────────


def _main() -> None:
    """Print scored top-N DB + Excel picks for the target query."""
    n_db = kpi_search_service.load_db_kpis()
    n_excel = kpi_search_service.load_excel_kpis_from_json()
    print(f"QUERY:    {TARGET_QUERY}")
    print(f"VERTICAL: {TARGET_VERTICAL}")
    print(f"LOADED:   {n_db} DB KPIs, {n_excel} Excel KPIs")
    print("=" * 80)

    db_rows = kpi_search_service.get_db_kpi_metadata_rows()
    if not db_rows:
        print("!! DB catalog is empty — check config.PG_* credentials.")

    # DB side — print top 20 by score (full list may be 180+).
    print("\n### DB picks (top 20 after AHLOA vertical filter) ###")
    for score, row in _score_all_db_rows(db_rows, TARGET_QUERY, TARGET_VERTICAL)[:20]:
        name = str(row.get("kpi_name", ""))[:60]
        proj = str(row.get("project_name", ""))
        print(f"  {score:5.2f}  {name:<60}  [{proj}]")

    # Excel side — print top 15 scored rows.
    print("\n### Excel picks (top 15 by lexical score) ###")
    q_tokens = kpi_bootstrap._tokenize(TARGET_QUERY)
    q_lower = TARGET_QUERY.lower()
    excel_rows = kpi_search_service.get_excel_kpi_metadata_rows()
    excel_scored = sorted(
        (
            (kpi_bootstrap._score_row(r, q_tokens, set(), q_lower), i, r)
            for i, r in enumerate(excel_rows)
            if r.get("kpi_name")
        ),
        key=lambda t: t[0],
        reverse=True,
    )
    for score, i, row in excel_scored[:15]:
        name = row["kpi_name"].strip()
        print(f"  {score:5.2f}  [excel:{i:>3}]  {name}")

    # Final catalog that would actually be sent to the LLM.
    catalog, counts = kpi_bootstrap._build_prefiltered_catalog(
        query=TARGET_QUERY,
        hints_text="",
        vertical=TARGET_VERTICAL,
    )
    print(f"\n### Final catalog sent to LLM (db={counts['db']}, excel={counts['excel']}) ###")
    print(catalog)


if __name__ == "__main__":
    _main()
