# Escalation Agent — Main LangGraph definition.

# Graph Flow:
#     START
#       -> query_refiner  [HITL — may interrupt for clarification]
#             -> orchestrator  [classifies and routes]
#                   |-> END                                      (greeting — response set directly)
#                   |-> discover_schema
#                         |-> traversal -> response -> END       (simple data lookup)
#                         |-> escalation_lookup
#                               |-> response -> END              (high-confidence match)
#                               |-> traversal -> response -> END (low-confidence fallback)
#
# Smart features:
#   - Schema caching: skips Neo4j schema fetch on follow-up queries in same session
#   - Low-confidence fallback: escalation_lookup routes to traversal if similarity < threshold
#   - Error guard: skips response node if all upstream steps failed (returns clean error)
#   - Retry-aware: nodes surface errors cleanly instead of crashing the pipeline
from __future__ import annotations

import time
import urllib
from datetime import datetime

from langgraph.checkpoint.memory import MemorySaver
from langgraph.checkpoint.postgres import PostgresSaver
from langgraph.graph import END, START, StateGraph
from loguru import logger

import config
from agents.escalation_lookup import escalation_lookup_node
from agents.orchestrator import orchestrator_node
from agents.query_refiner import query_refiner_node
from agents.response import response_node
from agents.schema_discovery import discover_schema_node
from agents.traversal import traversal_node
from models.state import EscalationState

# ── Thresholds ──────────────────────────────────────────
_LOW_CONFIDENCE_THRESHOLD = (
    0.40  # below this, escalation_lookup falls back to traversal
)
_ALL_STEPS_FAILED_MSG = (
    "All investigation steps failed or returned no data. "
    "Please try rephrasing your query or providing more specific details."
)


# ─────────────────────────────────────────────
# Smart nodes (wrappers that add intelligence)
# ─────────────────────────────────────────────


def _smart_schema_discovery(state: EscalationState) -> dict:
    """Skip schema fetch if we already have it from a previous turn in this session."""
    existing_schema = state.get("kg_schema", "")
    if existing_schema and not existing_schema.startswith("Schema discovery failed"):
        logger.info(
            "Graph | schema cache HIT — skipping Neo4j schema fetch ({} chars cached)",
            len(existing_schema),
        )
        return {
            "current_phase": "traversal",
            "messages": [
                {
                    "agent": "schema_discovery",
                    "content": f"Schema cache hit — reusing {len(existing_schema)} chars from prior turn.",
                }
            ],
        }
    return discover_schema_node(state)


def _smart_error_response(state: EscalationState) -> dict:
    """Generate a clean error response when all upstream data gathering failed."""
    errors = state.get("errors", [])
    logger.warning(
        "Graph | error_response node triggered | {} errors accumulated", len(errors)
    )
    error_summary = "\n".join(f"- {e}" for e in errors) if errors else "- Unknown error"
    return {
        "final_response": (
            f"## Investigation Could Not Be Completed\n\n"
            f"The agent encountered errors during data gathering and could not "
            f"produce a reliable report.\n\n"
            f"**Errors:**\n{error_summary}\n\n"
            f"**Suggestions:**\n"
            f"- Try rephrasing your query with more specific details\n"
            f"- Ensure the vendor/GC/market name is spelled correctly\n"
            f"- Check if the requested timeframe has data available"
        ),
        "current_phase": "complete",
        "messages": [
            {
                "agent": "error_response",
                "content": f"Investigation failed with {len(errors)} errors. Returned clean error response.",
            }
        ],
    }


# ─────────────────────────────────────────────
# Routing functions (conditional edges)
# ─────────────────────────────────────────────


def _route_after_query_refiner(state: EscalationState) -> str:
    """Route to orchestrator, or short-circuit to END if query_refiner hit a fatal error."""
    phase = state.get("current_phase", "")
    if phase == "error":
        logger.info("Graph | query_refiner returned error phase -> error_response")
        return "error_response"
    return "orchestrator"


def _route_after_orchestrator(state: EscalationState) -> str:
    decision = state.get("routing_decision", "escalation")
    if decision == "greeting":
        logger.info("Graph | routing after orchestrator -> END (greeting)")
        return "__end__"
    if decision == "compose":
        logger.info("Graph | routing after orchestrator -> response (compose — no investigation needed)")
        return "response"
    logger.info(
        "Graph | routing after orchestrator -> discover_schema (decision={})", decision
    )
    return "discover_schema"


def _route_after_discovery(state: EscalationState) -> str:
    decision = state.get("routing_decision", "traversal")
    if decision == "escalation":
        logger.info("Graph | routing after discovery -> escalation_lookup")
        return "escalation_lookup"
    logger.info("Graph | routing after discovery -> traversal")
    return "traversal"


def _route_after_escalation_lookup(state: EscalationState) -> str:
    """Smart routing after escalation lookup:
    - Low confidence match → fall back to direct traversal
    - All steps failed → skip to error response
    - Otherwise → proceed to response agent
    """
    similarity = state.get("escalation_similarity_score", 0.0)
    step_results = state.get("escalation_step_results", [])

    # Check if all steps failed
    if step_results:
        all_failed = all(
            r.get("errors")
            or r.get("traversal_findings", "").startswith(
                ("Step failed:", "Step timed out", "Unexpected error:")
            )
            for r in step_results
        )
        if all_failed:
            logger.warning(
                "Graph | all {} escalation steps failed -> error_response",
                len(step_results),
            )
            return "error_response"

    # Low confidence → fall back to traversal for a broader investigation
    if similarity < _LOW_CONFIDENCE_THRESHOLD and similarity > 0:
        logger.info(
            "Graph | low confidence match ({:.2%} < {:.0%}) -> fallback to traversal",
            similarity,
            _LOW_CONFIDENCE_THRESHOLD,
        )
        return "traversal"

    return "response"


def _route_after_traversal(state: EscalationState) -> str:
    """Skip response if traversal produced no usable data."""
    findings = state.get("traversal_findings", "")
    tool_calls = state.get("traversal_tool_calls", [])
    errors = state.get("errors", [])

    has_data = bool(findings.strip()) or any(
        tc.get("status") == "success" for tc in tool_calls
    )
    if not has_data and errors:
        logger.warning(
            "Graph | traversal produced no data and has errors -> error_response"
        )
        return "error_response"

    return "response"


# ─────────────────────────────────────────────
# Graph builder
# ─────────────────────────────────────────────


def build_escalation_graph() -> StateGraph:
    graph = StateGraph(EscalationState)

    # ── Nodes ──
    graph.add_node("query_refiner", query_refiner_node)
    graph.add_node("orchestrator", orchestrator_node)
    graph.add_node("discover_schema", _smart_schema_discovery)
    graph.add_node("traversal", traversal_node)
    graph.add_node("escalation_lookup", escalation_lookup_node)
    graph.add_node("response", response_node)
    graph.add_node("error_response", _smart_error_response)

    # ── Edges ──
    graph.add_edge(START, "query_refiner")

    graph.add_conditional_edges(
        "query_refiner",
        _route_after_query_refiner,
        {"orchestrator": "orchestrator", "error_response": "error_response"},
    )

    graph.add_conditional_edges(
        "orchestrator",
        _route_after_orchestrator,
        {"__end__": END, "discover_schema": "discover_schema", "response": "response"},
    )

    graph.add_conditional_edges(
        "discover_schema",
        _route_after_discovery,
        {"escalation_lookup": "escalation_lookup", "traversal": "traversal"},
    )

    graph.add_conditional_edges(
        "escalation_lookup",
        _route_after_escalation_lookup,
        {
            "response": "response",
            "traversal": "traversal",
            "error_response": "error_response",
        },
    )

    graph.add_conditional_edges(
        "traversal",
        _route_after_traversal,
        {"response": "response", "error_response": "error_response"},
    )

    graph.add_edge("response", END)
    graph.add_edge("error_response", END)

    checkpointer = _build_checkpointer()
    compiled = graph.compile(checkpointer=checkpointer)
    logger.info(
        "Escalation graph compiled successfully (checkpointer={})",
        type(checkpointer).__name__,
    )

    return compiled


def _build_checkpointer():
    """Build a persistent PostgresSaver checkpointer, falling back to MemorySaver.

    PostgresSaver.from_conn_string() is a @contextmanager that yields a
    PostgresSaver — we can't use it directly because the connection would
    close when the with-block exits. Instead, open a psycopg Connection
    manually and keep it alive for the process lifetime.
    """
    try:
        from psycopg import Connection
        from psycopg.rows import dict_row

        conn_string = (
            f"postgresql://{config.PG_USER}:{urllib.parse.quote_plus(config.PG_PASSWORD)}"
            f"@{config.PG_HOST}:{config.PG_PORT}/{config.PG_DATABASE}"
        )
        conn = Connection.connect(
            conn_string,
            autocommit=True,
            prepare_threshold=0,
            row_factory=dict_row,
        )
        checkpointer = PostgresSaver(conn)
        checkpointer.setup()  # creates checkpoint tables if they don't exist
        logger.info("Using PostgresSaver checkpointer for persistent HITL state")
        return checkpointer
    except Exception as e:
        logger.warning(
            "PostgresSaver setup failed ({}), falling back to MemorySaver — "
            "HITL resume will NOT survive server restarts",
            e,
        )
        return MemorySaver()


# Module-level singleton
_graph = build_escalation_graph()


def _print_phase_timings(timings: dict[str, float], total_ms: float) -> None:
    print("" + "-" * 52)
    print("  Phase Timing Summary")
    print("-" * 52)
    for node, ms in timings.items():
        secs = ms / 1000
        print(f"  {node:<22} {secs:>7.2f} s")
    print("-" * 52)
    print(f"  {'TOTAL':<22} {total_ms / 1000:>7.2f} s")
    print("-" * 52 + "")


def _make_initial_state(
    query: str, max_steps: int, conversation_history: str = ""
) -> EscalationState:
    return {
        "user_query": query,
        "refined_query": "",
        "conversation_history": conversation_history,
        "current_phase": "query_refinement",
        "routing_decision": "",
        "routing_context": "",
        # Escalation scenario fields
        "escalation_type": "",
        "escalation_description": "",
        "probable_reasons": "",
        "recommended_resolution": "",
        "expected_agent_output": "",
        "draft_escalation_message_template": "",
        "relevant_kpis": "",
        "escalation_vertical": "",
        "escalation_similarity_score": 0.0,
        "escalation_steps": [],
        "escalation_step_results": [],
        # KG and traversal fields
        "kg_schema": "",
        "traversal_findings": "",
        "traversal_tool_calls": [],
        "traversal_steps_taken": 0,
        "max_traversal_steps": max_steps,
        # Response fields
        "final_response": "",
        "calculations": "",
        "data_summary": {},
        "charts": [],
        # Metadata
        "errors": [],
        "created_at": datetime.now().isoformat(),
        "messages": [],
        "sql_queries": [],
    }


def run_escalation(
    query: str,
    max_steps: int = 20,
    thread_id: str = "default",
    conversation_history: str = "",
) -> dict:
    """Start a new escalation investigation end-to-end."""
    thread_config = {"configurable": {"thread_id": thread_id}}
    initial_state = _make_initial_state(query, max_steps, conversation_history)

    logger.info("Starting Escalation [thread={}]: {}", thread_id, query)

    timings: dict[str, float] = {}
    t_start = time.perf_counter()
    t_prev = t_start

    for chunk in _graph.stream(
        initial_state, config=thread_config, stream_mode="updates"
    ):
        t_now = time.perf_counter()
        for node_name in chunk:
            node_ms = round((t_now - t_prev) * 1000, 1)
            timings[node_name] = node_ms
            logger.info("Graph | node={} completed in {:.1f}ms", node_name, node_ms)
        t_prev = t_now

    total_ms = round((time.perf_counter() - t_start) * 1000, 1)
    _print_phase_timings(timings, total_ms)

    graph_state = _graph.get_state(thread_config)
    final_state = dict(graph_state.values)

    # Attach interrupt info so the service layer can detect HITL pauses
    for task in graph_state.tasks:
        if task.interrupts:
            final_state["__interrupt__"] = task.interrupts
            logger.info("Graph | HITL interrupt detected [thread={}]", thread_id)
            break

    logger.info(
        "Escalation complete [thread={}] | total={:.1f}ms | phases={}",
        thread_id,
        total_ms,
        list(timings.keys()),
    )

    return final_state


def resume_escalation(
    user_clarification: str,
    thread_id: str,
) -> dict:
    """Resume an escalation that was interrupted by the query_refiner node."""
    from langgraph.types import Command

    thread_config = {"configurable": {"thread_id": thread_id}}

    logger.info(
        "Resuming Escalation [thread={}] with clarification: {}",
        thread_id,
        user_clarification[:80],
    )

    timings: dict[str, float] = {}
    t_start = time.perf_counter()
    t_prev = t_start

    for chunk in _graph.stream(
        Command(resume=user_clarification), config=thread_config, stream_mode="updates"
    ):
        t_now = time.perf_counter()
        for node_name in chunk:
            timings[node_name] = round((t_now - t_prev) * 1000, 1)
        t_prev = t_now

    total_ms = round((time.perf_counter() - t_start) * 1000, 1)
    _print_phase_timings(timings, total_ms)

    graph_state = _graph.get_state(thread_config)
    final_state = dict(graph_state.values)

    for task in graph_state.tasks:
        if task.interrupts:
            final_state["__interrupt__"] = task.interrupts
            break

    logger.info("Escalation resumed and complete [thread={}]", thread_id)

    return final_state


# ─────────────────────────────────────────────
# SSE streaming helpers
# ─────────────────────────────────────────────

_NODE_TO_EVENT: dict[str, str] = {
    "query_refiner": "query_refiner_complete",
    "orchestrator": "orchestrator_complete",
    "discover_schema": "schema_complete",
    "escalation_lookup": "escalation_lookup_complete",
    "traversal": "traversal_complete",
    "response": "response_complete",
    "error_response": "response_complete",
}


def _emit_node_event(query_id: str, node_name: str, state_delta: dict, mgr) -> None:
    event_name = _NODE_TO_EVENT.get(node_name)
    if not event_name:
        return

    data: dict = {}
    if node_name == "query_refiner":
        data = {"refined_query": state_delta.get("refined_query", "")}
    elif node_name == "orchestrator":
        data = {"routing_decision": state_delta.get("routing_decision", "")}
    elif node_name == "escalation_lookup":
        data = {
            "escalation_type": state_delta.get("escalation_type", ""),
            "escalation_steps": state_delta.get("escalation_steps", []),
        }
    elif node_name == "traversal":
        data = {"traversal_steps": state_delta.get("traversal_steps_taken", 0)}
    elif node_name in ("response", "error_response"):
        data = {
            "final_response": state_delta.get("final_response", ""),
            "charts": state_delta.get("charts", []),
        }

    mgr.put_sync(query_id, event_name, data)


def stream_escalation(
    query: str,
    query_id: str,
    thread_id: str,
    mgr,
    max_steps: int = 20,
    on_hitl=None,
    conversation_history: str = "",
) -> dict:
    """Stream the escalation graph end-to-end, pushing SSE events via mgr."""
    thread_config = {"configurable": {"thread_id": thread_id}}
    initial_state = _make_initial_state(query, max_steps, conversation_history)

    logger.info(
        "Streaming Escalation [thread={} query={}]: {:.80}",
        thread_id,
        query_id,
        query,
    )

    # ── Phase 1: initial run ──
    timings: dict[str, float] = {}
    t_start = time.perf_counter()
    t_prev = t_start

    for chunk in _graph.stream(
        initial_state, config=thread_config, stream_mode="updates"
    ):
        t_now = time.perf_counter()
        for node_name, state_delta in chunk.items():
            timings[node_name] = round((t_now - t_prev) * 1000, 1)
            _emit_node_event(query_id, node_name, state_delta, mgr)
        t_prev = t_now

    # ── Check for HITL interrupt ──
    graph_state = _graph.get_state(thread_config)
    interrupt_payload = None
    for task in graph_state.tasks:
        if task.interrupts:
            interrupt_payload = task.interrupts[0].value
            break

    if interrupt_payload:
        if on_hitl:
            on_hitl(interrupt_payload)
        mgr.put_sync(query_id, "hitl_start", interrupt_payload)

        hitl_event = mgr.create_hitl_event(thread_id)
        logger.info("HITL pause — blocking stream thread [thread={}]", thread_id)
        hitl_event.wait()
        logger.info("HITL unblocked [thread={}]", thread_id)

        answer = mgr.get_resume_answer(thread_id)

        # If the client disconnected during HITL, the cleanup set a
        # cancellation sentinel.  Bail out — the sync resume endpoint
        # will handle the actual graph resume independently.
        if answer == "__cancelled__":
            logger.info(
                "Stream thread cancelled (client disconnected during HITL) [thread={}]",
                thread_id,
            )
            return dict(_graph.get_state(thread_config).values)

        mgr.put_sync(query_id, "hitl_complete", {"answer": answer})

        # ── Phase 2: resume ──
        from langgraph.types import Command

        t_prev = time.perf_counter()
        for chunk in _graph.stream(
            Command(resume=answer),
            config=thread_config,
            stream_mode="updates",
        ):
            t_now = time.perf_counter()
            for node_name, state_delta in chunk.items():
                timings[node_name] = round((t_now - t_prev) * 1000, 1)
                _emit_node_event(query_id, node_name, state_delta, mgr)
            t_prev = t_now

    total_ms = round((time.perf_counter() - t_start) * 1000, 1)
    _print_phase_timings(timings, total_ms)

    final_state = dict(_graph.get_state(thread_config).values)
    logger.info("Streaming complete [thread={} query={}]", thread_id, query_id)
    return final_state


def get_pending_interrupt(thread_id: str) -> dict | None:
    thread_config = {"configurable": {"thread_id": thread_id}}
    state = _graph.get_state(thread_config)

    for task in state.tasks:
        if task.interrupts:
            return task.interrupts[0].value

    return None
