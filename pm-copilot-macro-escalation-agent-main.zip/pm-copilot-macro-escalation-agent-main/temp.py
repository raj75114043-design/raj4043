from dotenv import load_dotenv

from agents.kpi_analyst import run_kpi_analyst

load_dotenv()
# refresh_kpi_embeddings()
result = run_kpi_analyst(
    query="Extended outage during swap activities without prior approval from TMO, causing Network disruptions for GC wise and region wise",
    escalation_context={
        "escalation_type": "AHLOA Swap MW / Outage Approval Extended (>8 hrs) Without TMO Approval",
        "escalation_description": "Extended outage during swap activities without prior approval from TMO, causing Network disruptions.",
        "probable_reasons": "Lack of CR Process, Lack of timely communication with TMO. Delay in obtaining necessary approvals.",
        "recommended_resolution": "Ensure TMO approval is obtained before extending swap activities. Implement automated reminders for CR approval processes.",
        "expected_agent_output": 'Agent: "The outage has exceeded 8 hours / Approved MW without TMO approval. Please ensure all necessary approvals are obtained before proceeding further."',
        "draft_escalation_message_template": '''Subject: Escalation - Outage Extended Beyond MW (8 Hours) Without TMO Approval
Dear [Recipient],
The swap activity has resulted in an outage exceeding MW (8 hours) without prior TMO approval. Immediate action is required to take neccessory approval to prevent further Network Outage.
Regards, [Your Name]''',
        "relevant_kpis": "Outage duration (TAT). Approval turnaround time.",
        "escalation_vertical": "AHLOA",
    },
)

print(result['findings'])
