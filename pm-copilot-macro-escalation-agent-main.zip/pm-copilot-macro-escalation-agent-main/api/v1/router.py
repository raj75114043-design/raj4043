
# v1 router — aggregates all v1 endpoint routers under the /v1 prefix.
from fastapi import APIRouter

from api.v1.endpoints import health, escalation, bkg, threads, sse_escalation, sessions, charts, kpi_sessions

router = APIRouter(prefix="/v1")

router.include_router(health.router)
# router.include_router(sessions.router)
router.include_router(charts.router)
router.include_router(sse_escalation.router)
router.include_router(escalation.router)
router.include_router(bkg.router)
router.include_router(threads.router)
router.include_router(kpi_sessions.router)
