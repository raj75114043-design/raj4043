# Pydantic request / response schemas for the v1 API — Escalation Agent.
from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field


# ── Analyze (Escalation) ─────────────────────────────────────────────────────

class AnalyzeRequest(BaseModel):
    user_id: str
    query: str
    thread_id: Optional[str] = None

    model_config = {
        "json_schema_extra": {
            "example": {
                "user_id": "user-001",
                "query": "SLA adherence has dropped below 90% in SOUTH region for 3 days",
                "thread_id": "session-abc-123",
            }
        }
    }


class ClarificationPayload(BaseModel):
    type: str
    original_query: str
    questions: list[str]
    assumptions_if_skipped: list[str]
    message: str


class AnalyzeResponse(BaseModel):
    status: str  # "complete" | "clarification_needed"
    thread_id: str
    final_response: str
    errors: list[str]
    traversal_steps: int
    routing_decision: str  # "greeting" | "traversal" | "escalation"
    escalation_type: str
    escalation_steps: list[str]
    clarification: Optional[ClarificationPayload] = None
    # Scenario context fields
    escalation_description: str = ""
    probable_reasons: str = ""
    recommended_resolution: str = ""
    expected_agent_output: str = ""
    draft_escalation_message_template: str = ""
    relevant_kpis: str = ""
    escalation_vertical: str = ""
    escalation_similarity_score: float = 0.0
    charts: list[Any] = []
    compacted: str = ""


# ── Resume (HITL) ────────────────────────────────────────────────────────────

class ResumeRequest(BaseModel):
    thread_id: str
    clarification: str

    model_config = {
        "json_schema_extra": {
            "example": {
                "thread_id": "session-abc-123",
                "clarification": "Analyze for the last 90 days across all regions.",
            }
        }
    }


# ── BKG ──────────────────────────────────────────────────────────────────────

class BKGQueryRequest(BaseModel):
    mode: str
    node_id: Optional[str] = None
    question: Optional[str] = None
    start: Optional[str] = None
    depth: Optional[int] = 2
    rel_type: Optional[str] = None
    table_name: Optional[str] = None

    model_config = {
        "json_schema_extra": {
            "examples": [
                {"mode": "get_node", "node_id": "general_contractor"},
                {"mode": "find_relevant", "question": "H&S compliance"},
                {"mode": "traverse", "start": "general_contractor", "depth": 2},
                {"mode": "get_kpi", "node_id": "on_air_cycle_time"},
                {"mode": "schema"},
            ]
        }
    }


# ── Threads ──────────────────────────────────────────────────────────────────

class CreateThreadRequest(BaseModel):
    user_id: str
    thread_name: str

    model_config = {
        "json_schema_extra": {
            "example": {
                "user_id": "user-001",
                "thread_name": "SLA breach escalation investigation",
            }
        }
    }


class ThreadSummary(BaseModel):
    thread_id: str
    user_id: str
    thread_name: Optional[str] = None
    created_at: Any
    last_active_at: Any
    status: str
    total_queries: int


class MessageRecord(BaseModel):
    query_id: str
    thread_id: str
    user_id: str
    original_query: str
    refined_query: Optional[str] = None
    routing_decision: Optional[str] = None
    escalation_steps: Optional[Any] = None
    final_response: Optional[str] = None
    chart_paths: Optional[list[dict]] = None
    started_at: Any
    completed_at: Optional[Any] = None
    duration_ms: Optional[float] = None
    status: str


class ChatMessage(BaseModel):
    """A single message in chat history (user or assistant)."""
    role: str  # "user" | "assistant"
    content: str
    compacted: str = ""  # LLM-summarized version of content
    charts: list[Any] = []  # full ChartDataRecord dicts for frontend rendering
    sql_queries: list[Any] = []  # SQL/Python queries executed during investigation
    aggregation_summary: Optional[AggregationInfo] = None  # drill-down + share period metadata
    query_id: Optional[str] = None
    routing_decision: Optional[str] = None
    escalation_steps: Optional[Any] = None
    status: Optional[str] = None
    started_at: Optional[Any] = None
    completed_at: Optional[Any] = None
    duration_ms: Optional[float] = None


class SessionHistory(BaseModel):
    """Full chat history for a session."""
    session_id: str
    messages: list[ChatMessage]


class ClarificationStatus(BaseModel):
    is_paused: bool
    clarification_id: Optional[str] = None
    query_id: Optional[str] = None
    questions_asked: Optional[list[str]] = None
    assumptions_offered: Optional[list[str]] = None
    asked_at: Optional[Any] = None


# ── Sessions ─────────────────────────────────────────────────────────────────

class SessionCreate(BaseModel):
    user_id: str = Field(..., min_length=1, description="User who owns this session.")
    session_id: Optional[str] = Field(None, description="Optional custom session ID. Auto-generated when omitted.")

    model_config = {
        "json_schema_extra": {
            "example": {"user_id": "user-001"}
        }
    }


class SessionSummary(BaseModel):
    session_id: str
    user_id: str = ""
    first_message: str = ""


class SessionInfo(BaseModel):
    session_id: str
    user_id: str = ""
    message_count: int
    active_sessions: list[str]


class SessionList(BaseModel):
    sessions: list[SessionSummary]


class ChatRequest(BaseModel):
    user_id: str = Field(..., min_length=1, description="User sending the message.")
    message: str = Field(..., min_length=1, description="User message text.")

    model_config = {
        "json_schema_extra": {
            "example": {
                "user_id": "user-001",
                "message": "SLA adherence has dropped below 90% in SOUTH region for 3 days",
            }
        }
    }


# ── Aggregation Summary (KPI drill-down metadata for FE) ────────────

class DrillDownLevelInfo(BaseModel):
    """One level of the mandatory drill-down hierarchy."""
    level: str = ""  # national | region | market | gc_vendor
    period_months: int = 0  # 6 for national, 4 for others
    table_used: str = ""
    data_path: str = ""  # A or B
    row_count: int = 0
    kpi_name: str = ""
    status: str = ""  # success | error | skipped
    query_step: int = 0


class AggregationInfo(BaseModel):
    """Aggregation metadata for a KPI investigation — sent to FE."""
    kpi_names: list[str] = []
    drill_down_levels: list[DrillDownLevelInfo] = []
    levels_completed: int = 0  # 0-4
    total_queries: int = 0
    total_charts: int = 0
    data_path: str = ""  # A, B, or mixed
    vertical: str = ""
    time_coverage: dict[str, int] = Field(
        default_factory=dict,
        description="Period months per level: {national: 6, region: 4, ...}",
    )


# ── Sandbox ──────────────────────────────────────────────────────────────────

class SandboxRequest(BaseModel):
    code: str
    timeout_seconds: int = 30

    model_config = {
        "json_schema_extra": {
            "example": {
                "code": (
                    "df = pd.read_sql('SELECT 1 AS test', conn)\n"
                    "result = {'data': df.to_dict(orient='records')}"
                ),
                "timeout_seconds": 30,
            }
        }
    }
