# KPI Analyst Sessions — standalone KPI investigation endpoint.
#
#   POST   /api/v1/kpi/sessions                             — Create session
#   GET    /api/v1/kpi/sessions                             — List sessions
#   GET    /api/v1/kpi/sessions/{session_id}                — Get session info
#   DELETE /api/v1/kpi/sessions/{session_id}                — Delete session
#   GET    /api/v1/kpi/sessions/{session_id}/history        — Chat history
#   POST   /api/v1/kpi/sessions/{session_id}/chat           — SSE with keep-alive
#   POST   /api/v1/kpi/sessions/{session_id}/chat/stream    — Granular SSE stream
#
# Bypasses the full escalation graph and directly invokes run_kpi_analyst()
# with optional escalation context from scenario lookup.
from __future__ import annotations

import asyncio
import json
import time
import uuid
from typing import AsyncGenerator, Callable, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from loguru import logger

import services.db_service as db_svc
from agents.context_gatherer import gather_context
from agents.kpi_analyst import run_kpi_analyst
from services.kpi_bootstrap import KPI_SIMILARITY_THRESHOLD
from api.v1.deps import require_ready
from api.v1.schemas import (
    AggregationInfo,
    ChatMessage,
    ChatRequest,
    SessionCreate,
    SessionHistory,
    SessionInfo,
    SessionList,
    SessionSummary,
)
from services.compaction_service import compact_response
from services.escalation_service import build_conversation_history
from services.kpi_bootstrap import search_and_match_kpis
from services.scenario_service import find_matching_scenario

router = APIRouter(prefix="/kpi/sessions", tags=["KPI Analyst"])

_CHAT_TIMEOUT_SEC = 6000000000.0  # KPI analysis can take longer
_KEEPALIVE_INTERVAL_SEC = 20
_SCENARIO_SIMILARITY_THRESHOLD = 0.3  # minimum to use scenario context


def _sse(event: str, data: dict) -> str:
    """Format a single Server-Sent Event."""
    return f"event: {event}\ndata: {json.dumps(data, default=str)}\n\n"


def _chat_error(exc: Exception, session_id: str) -> HTTPException:
    """Convert agent/LLM exceptions into clean HTTP errors."""
    err_str = str(exc)
    err_type = type(exc).__name__

    if "openai" in (getattr(type(exc), "__module__", "") or "").lower():
        if "authentication" in err_str.lower() or "signing key" in err_str.lower():
            logger.error("KPI /chat | session={} | LLM auth error: {}", session_id, err_str[:200])
            return HTTPException(status_code=502, detail="LLM gateway authentication failed.")
        if "rate" in err_str.lower() and "limit" in err_str.lower():
            return HTTPException(status_code=429, detail="LLM gateway rate limit reached.")
        if "timeout" in err_str.lower():
            return HTTPException(status_code=504, detail="LLM gateway timed out.")
        return HTTPException(status_code=502, detail=f"LLM gateway error: {err_str[:200]}")

    if any(k in err_type.lower() for k in ("psycopg", "sqlalchemy", "operationalerror")):
        return HTTPException(status_code=503, detail="Database connection error.")

    logger.exception("KPI /chat | session={} | unexpected error ({}): {}", session_id, err_type, err_str[:300])
    return HTTPException(status_code=500, detail=f"An unexpected error occurred: {err_str[:200]}")


def _lookup_escalation_context(query: str) -> dict[str, str]:
    """Try to match the query against the semantic_escalation table.

    Returns a dict with escalation context fields, or empty dict if no match.
    """
    try:
        matches = find_matching_scenario(query, top_k=1)
        if not matches:
            return {}

        scenario = matches[0]
        similarity = scenario.get("similarity_score", 0)

        if similarity < _SCENARIO_SIMILARITY_THRESHOLD:
            logger.info("KPI | scenario similarity {:.4f} below threshold, skipping", similarity)
            return {}

        logger.info("KPI | matched escalation scenario: {} (sim={:.4f})",
                    scenario.get("escalation_type", "?"), similarity)

        def _str(val) -> str:
            """Coerce scenario field to string — some fields come back as lists."""
            if isinstance(val, list):
                return "; ".join(str(v) for v in val if v)
            return str(val).strip() if val else ""

        return {
            "escalation_type": _str(scenario.get("escalation_type")),
            "escalation_description": _str(scenario.get("escalation_description")),
            "probable_reasons": _str(scenario.get("probable_reasons")),
            "recommended_resolution": _str(scenario.get("recommended_resolution")),
            "expected_agent_output": _str(scenario.get("expected_agent_output")),
            "draft_escalation_message_template": _str(scenario.get("draft_escalation_message_template")),
            "relevant_kpis": _str(scenario.get("relevent_kpi_s")),
            "escalation_vertical": _str(scenario.get("vertical")),
        }
    except Exception as e:
        logger.warning("KPI | escalation scenario lookup failed (non-fatal): {}", e)
        return {}


def _thread_to_session_info(thread: dict) -> SessionInfo:
    """Convert a db thread dict to SessionInfo."""
    session_id = thread["thread_id"]
    pending = db_svc.get_pending_clarification(session_id)
    active = [session_id] if pending else []
    return SessionInfo(
        session_id=session_id,
        user_id=thread.get("user_id", ""),
        message_count=thread.get("total_queries", 0),
        active_sessions=active,
    )


def _thread_to_session_summary(thread: dict) -> SessionSummary:
    messages = db_svc.get_messages_by_thread(thread["thread_id"])
    first_message = messages[0]["original_query"] if messages else ""
    return SessionSummary(
        session_id=thread["thread_id"],
        user_id=thread.get("user_id", ""),
        first_message=first_message,
    )


# ── Session CRUD ──────────────────────────────────────────────────────────────

@router.post("", response_model=SessionInfo, status_code=201)
def create_session(req: SessionCreate, _=Depends(require_ready)):
    """Create a new KPI analyst session."""
    session_id = req.session_id or str(uuid.uuid4())
    db_svc.upsert_thread(session_id, req.user_id)
    thread = db_svc.get_thread(session_id)
    if not thread:
        raise HTTPException(status_code=500, detail="Failed to create session")
    return _thread_to_session_info(thread)


@router.get("", response_model=SessionList)
def list_sessions(
        user_id: Optional[str] = Query(None, description="Filter sessions by user."),
        _=Depends(require_ready),
):
    """List all sessions, optionally filtered by user."""
    threads = db_svc.get_threads_by_user(user_id)
    summaries = [_thread_to_session_summary(t) for t in threads]
    return SessionList(sessions=summaries)


@router.get("/{session_id}", response_model=SessionInfo)
def get_session(session_id: str, _=Depends(require_ready)):
    """Get metadata for a single session."""
    thread = db_svc.get_thread(session_id)
    if not thread:
        raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")
    return _thread_to_session_info(thread)


@router.delete("/{session_id}", status_code=204)
def delete_session(session_id: str, _=Depends(require_ready)):
    """Permanently delete a session and all its messages."""
    deleted = db_svc.delete_thread(session_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")


@router.get("/{session_id}/history", response_model=SessionHistory)
def get_session_history(session_id: str, _=Depends(require_ready)):
    """Return all messages for a session as a chat-style conversation."""
    thread = db_svc.get_thread(session_id)
    if not thread:
        raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")

    rows = db_svc.get_messages_by_thread(session_id)
    messages: list[ChatMessage] = []

    for row in rows:
        messages.append(ChatMessage(
            role="user",
            content=row.get("original_query", ""),
            charts=[],
            query_id=row.get("query_id"),
            started_at=row.get("started_at"),
        ))

        final_response = row.get("final_response") or ""
        if final_response or row.get("status") in ("complete", "error"):
            # Parse aggregation_summary from stored data if present. Schema can
            # drift between writer (kpi_analyst TypedDict) and reader (Pydantic),
            # so guard against ValidationError rather than 500-ing the history.
            raw_agg = row.get("aggregation_summary")
            agg_info: Optional[AggregationInfo] = None
            if isinstance(raw_agg, dict):
                try:
                    agg_info = AggregationInfo(**raw_agg)
                except Exception as exc:
                    logger.warning(
                        "KPI /history | session={} query_id={} | agg_summary parse failed: {}",
                        session_id, row.get("query_id"), exc,
                    )

            messages.append(ChatMessage(
                role="assistant",
                content=final_response,
                compacted=row.get("compacted") or "",
                charts=row.get("chart_paths") or [],
                sql_queries=row.get("sql_queries") or [],
                aggregation_summary=agg_info,
                query_id=row.get("query_id"),
                routing_decision=row.get("routing_decision"),
                escalation_steps=row.get("escalation_steps"),
                status=row.get("status"),
                started_at=row.get("started_at"),
                completed_at=row.get("completed_at"),
                duration_ms=row.get("duration_ms"),
            ))

    return SessionHistory(session_id=session_id, messages=messages)


def _run_kpi_analysis(
        query: str,
        query_id: str,
        session_id: str,
        user_id: str,
        conversation_history: str = "",
        emit: "Callable[[str, dict], None] | None" = None,
) -> dict:
    """Run full KPI analyst pipeline: scenario lookup → vector search → analysis.

    Also handles DB persistence (create_query, update_query_complete/error)
    so all blocking DB calls stay off the async event loop.

    Args:
        emit: Optional callback ``emit(event_name, data_dict)`` for streaming
              SSE events. When None, no events are emitted (batch mode).

    Returns a shaped response dict ready for the API.
    """


    t0 = time.perf_counter()

    # ── DB setup (must run in thread, not async loop) ──
    db_svc.create_query(query_id, session_id, user_id, query)
    db_svc.auto_name_thread(session_id, query)

    try:
        # ── Step 0: Short-circuit greetings / off-topic before heavy pipeline ──
        query_lower = query.strip().lower().rstrip("!?.,")
        _GREETINGS = {"hello", "hi", "hey", "howdy", "greetings", "good morning",
                      "good afternoon", "good evening", "hola", "yo", "sup"}
        if query_lower in _GREETINGS or (len(query_lower.split()) <= 2 and
                                         any(g in query_lower for g in _GREETINGS)):
            greeting_response = (
                "Hello! I can help with T-Mobile MACRO KPIs, escalations, "
                "GC/market performance, and data-backed reports. "
                "What would you like to look into?"
            )
            duration_ms = round((time.perf_counter() - t0) * 1000, 1)
            db_svc.update_query_complete(
                query_id=query_id, refined_query=query,
                routing_decision="greeting", escalation_steps=[],
                final_response=greeting_response, duration_ms=duration_ms,
            )
            response = {
                "status": "complete", "query_id": query_id,
                "final_response": greeting_response,
                "sql_queries": [], "charts": [], "errors": [],
                "steps_taken": 0, "elapsed_s": 0,
            }
            return response

        # ── Step 0.5: Escalation scenario lookup (cheap — one embed + one DB row) ──
        # Run BEFORE the context gatherer so the gatherer can use the matched
        # scenario's vertical / relevant_kpis as defaults instead of asking the
        # user things the scenario already answers.
        escalation_context = _lookup_escalation_context(query)

        # ── Step 0.6: Context gathering (small ReAct agent) ──
        # Gathers vertical / kpi / time_range / scope before firing the heavy
        # pipeline. If anything is missing, short-circuit with a clarification
        # question — the next user turn (with this question in conversation
        # history) will advance the state machine.
        gathered = gather_context(
            query,
            conversation_history,
            scenario_context=escalation_context or None,
        )
        if gathered.get("status") == "need_info":
            question = gathered.get("question") or "Could you share a bit more detail about what you'd like to investigate?"
            examples = gathered.get("example_answers") or []
            if examples:
                question = question.rstrip() + "\n\n_Examples:_ " + ", ".join(examples)
            duration_ms = round((time.perf_counter() - t0) * 1000, 1)
            db_svc.update_query_complete(
                query_id=query_id, refined_query=query,
                routing_decision="context_gathering", escalation_steps=[],
                final_response=question, duration_ms=duration_ms,
            )
            return {
                "status": "complete",
                "query_id": query_id,
                "final_response": question,
                "routing_decision": "context_gathering",
                "sql_queries": [], "charts": [], "errors": [],
                "steps_taken": 0, "elapsed_s": 0,
                "duration_ms": duration_ms,
                "matched_kpis": [],
                "escalation_context": {},
                "aggregation_summary": {},
            }

        # Gathered context may refine the query and supply a vertical hint even
        # when escalation lookup whiffs.
        refined_query = gathered.get("refined_query") or query
        gathered_vertical = gathered.get("vertical", "")
        gathered_kpi_name = gathered.get("kpi_name", "")

        # Escalation scenario was already resolved in Step 0.5 above (using the raw
        # query). Re-resolving against refined_query is rarely informative — the
        # semantic match almost always returns the same scenario because the raw
        # query already carries the high-signal tokens (KPI / vertical / action).

        # Merge gathered fields into the escalation context so downstream
        # consumers (KPI search + KPI analyst prompt) see a unified view.
        # Scenario rows with an empty relevent_kpi_s column no longer blank
        # out the hint — we fall back to the KPI the user specified.
        if not escalation_context.get("relevant_kpis") and gathered_kpi_name:
            escalation_context["relevant_kpis"] = gathered_kpi_name
            logger.info("KPI | scenario had no KPI hints — using gathered kpi_name={!r}",
                        gathered_kpi_name)
        if not escalation_context.get("escalation_vertical") and gathered_vertical:
            escalation_context["escalation_vertical"] = gathered_vertical

        # ── Step 2: KPI search (filtered by vertical from escalation context) ──
        relevant_text = escalation_context.get("relevant_kpis", "")
        vertical = escalation_context.get("escalation_vertical", "")
        matched_kpis = search_and_match_kpis(refined_query, relevant_text, vertical=vertical)

        # ── Step 3: Run KPI analyst agent (filter to strong matches first) ──
        strong = [
            m for m in (matched_kpis or [])
            if m.get("distance", 1) < KPI_SIMILARITY_THRESHOLD
        ][:5] or (matched_kpis or [])[:5]
        result = run_kpi_analyst(
            query=refined_query,
            conversation_history=conversation_history,
            matched_kpis=strong or None,
            escalation_context=escalation_context if escalation_context else None,
        )


        duration_ms = round((time.perf_counter() - t0) * 1000, 1)

        # ── Compact + persist to DB ──
        compacted = compact_response(
            response=result.get("findings", ""),
            user_query=query,
            routing_decision="kpi_analyst",
        )

        db_svc.update_query_complete(
            query_id=query_id,
            refined_query=query,
            routing_decision="kpi_analyst",
            escalation_steps=[],
            final_response=result.get("findings", ""),
            duration_ms=duration_ms,
            chart_paths=result.get("charts", []),
            compacted=compacted,
            sql_queries=result.get("sql_queries", []),
            aggregation_summary=result.get("aggregation_summary"),
        )

        # ── Shape response ──
        response = {
            "status": "complete",
            "query_id": query_id,
            "final_response": result.get("findings", ""),
            "compacted": compacted,
            "findings_all": result.get("findings_all", []),
            "sql_queries": result.get("sql_queries", []),
            "charts": result.get("charts", []),
            "steps_taken": result.get("steps_taken", 0),
            "errors": result.get("errors", []),
            "elapsed_s": result.get("elapsed_s", 0),
            "duration_ms": duration_ms,
            "matched_kpis": [
                {
                    "kpi_name": m.get("kpi_name", ""),
                    "distance": float(m.get("distance", 1.0)),
                }
                for m in (matched_kpis or [])
                if m.get("kpi_name")
            ],
            "escalation_context": escalation_context,
            "aggregation_summary": result.get("aggregation_summary", {}),
        }
        return response

    except Exception as e:
        duration_ms = round((time.perf_counter() - t0) * 1000, 1)
        db_svc.update_query_error(query_id, duration_ms)
        raise


# ── Chat (SSE with keep-alive) ──────────────────────────────────────────────

@router.post("/{session_id}/chat")
async def kpi_chat(session_id: str, req: ChatRequest, _=Depends(require_ready)):
    """
    Run a KPI investigation and return results as SSE with keep-alive heartbeats.

    This endpoint directly invokes the KPI Analyst agent (bypassing the full
    escalation graph). It:
    1. Looks up matching escalation scenario for context
    2. Searches KPI embeddings (seeded from scenario + query expansion)
    3. Runs the ReAct agent loop (SQL → analysis → charts → report)
    4. Returns findings, SQL audit log, charts, and escalation context

    The response includes `sql_queries` — every SQL/Python query executed
    by the agent, with code, output preview, status, and aggregation flag.
    Charts are auto-generated for aggregated queries and returned in `charts`.
    """
    if not req.message or not req.message.strip():
        raise HTTPException(status_code=422, detail="Message cannot be empty.")

    logger.info("POST /kpi/chat | session={} | msg={!r}", session_id, req.message[:80])

    loop = asyncio.get_running_loop()

    thread = await loop.run_in_executor(None, db_svc.get_thread, session_id)
    if not thread:
        await loop.run_in_executor(
            None, db_svc.upsert_thread, session_id, req.user_id,
        )

    async def generate():
        query_id = str(uuid.uuid4())

        # Build conversation history in executor (blocking DB call)
        conversation_history = await loop.run_in_executor(
            None, build_conversation_history, session_id,
        )

        # All DB writes + heavy agent work run in the executor thread
        chat_task = asyncio.ensure_future(
            asyncio.wait_for(
                loop.run_in_executor(
                    None,
                    _run_kpi_analysis,
                    req.message, query_id, session_id, req.user_id,
                    conversation_history,
                ),
                timeout=_CHAT_TIMEOUT_SEC,
            )
        )

        # Keep-alive loop while agent works
        elapsed = 0.0
        since_ping = 0.0
        while not chat_task.done():
            await asyncio.sleep(1.0)
            elapsed += 1.0
            since_ping += 1.0
            if since_ping >= _KEEPALIVE_INTERVAL_SEC:
                since_ping = 0.0
                yield ": keep-alive\n\n"

        # Retrieve result (DB persistence already handled inside _run_kpi_analysis)
        try:
            result = chat_task.result()
        except asyncio.TimeoutError:
            logger.error("KPI /chat | session={} | timed out after {:.0f}s", session_id, _CHAT_TIMEOUT_SEC)
            # wait_for already cancelled the awaitable; the underlying executor
            # thread cannot be stopped mid-run, but calling cancel() on the
            # chat_task releases our future handle. Warn so the dangling thread
            # is visible in logs.
            chat_task.cancel()
            logger.warning(
                "KPI /chat | session={} query_id={} | executor thread still running after timeout",
                session_id, query_id,
            )
            # Timeout is raised by wait_for, not by _run_kpi_analysis — update DB off event loop
            try:
                await loop.run_in_executor(
                    None, db_svc.update_query_error, query_id, round(elapsed * 1000, 1),
                )
            except Exception:
                pass
            yield _sse("error", {"message": f"Request timed out after {_CHAT_TIMEOUT_SEC:.0f}s"})
            return
        except Exception as exc:
            # _run_kpi_analysis already called update_query_error before re-raising
            err = _chat_error(exc, session_id)
            yield _sse("error", {"message": err.detail})
            return

        payload = {
            "session_id": session_id,
            "query_id": result.get("query_id", query_id),
            "reply": result.get("final_response", ""),
            "compacted": result.get("compacted", ""),
            "status": result.get("status", "complete"),
            "sql_queries": result.get("sql_queries", []),
            "charts": result.get("charts", []),
            "matched_kpis": result.get("matched_kpis", []),
            "escalation_context": result.get("escalation_context", {}),
            "aggregation_summary": result.get("aggregation_summary", {}),
            "steps_taken": result.get("steps_taken", 0),
            "errors": result.get("errors", []),
            "elapsed_s": result.get("elapsed_s", 0),
        }
        yield _sse("done", payload)
        logger.info("KPI /chat | session={} | completed in {:.1f}s | {} steps | {} charts | {} queries",
                    session_id, elapsed, result.get("steps_taken", 0),
                    len(result.get("charts", [])), len(result.get("sql_queries", [])))

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ── Chat stream (granular SSE events) ────────────────────────────────────────

@router.post("/{session_id}/chat/stream")
async def kpi_chat_stream(session_id: str, req: ChatRequest, _=Depends(require_ready)):
    """
    Stream KPI investigation with granular SSE events.

    Events emitted:
    - stream_started    — initial ack with query_id
    - bootstrap         — schema + embedding bootstrap complete
    - kpi_matched       — matched KPIs from vector search
    - investigation     — agent loop started
    - sql_query         — each successful SQL query (for real-time validation)
    - chart_created     — each chart generated
    - complete          — final results with all data
    - error             — exception occurred
    """
    if not req.message or not req.message.strip():
        raise HTTPException(status_code=422, detail="Message cannot be empty.")

    logger.info("POST /kpi/chat/stream | session={} | msg={!r}", session_id, req.message[:80])

    loop = asyncio.get_running_loop()

    # Ensure thread exists (once — _run_in_thread will NOT duplicate this)
    thread = await loop.run_in_executor(None, db_svc.get_thread, session_id)
    if not thread:
        await loop.run_in_executor(
            None, db_svc.upsert_thread, session_id, req.user_id,
        )

    query_id = str(uuid.uuid4())
    event_queue: asyncio.Queue = asyncio.Queue()

    def _put(event: str, data: dict):
        """Thread-safe put into the async queue."""
        loop.call_soon_threadsafe(event_queue.put_nowait, {"event": event, "data": data})

    def _run_in_thread():
        conversation_history = build_conversation_history(session_id)
        try:
            _run_kpi_analysis(
                query=req.message,
                query_id=query_id,
                session_id=session_id,
                user_id=req.user_id,
                conversation_history=conversation_history,
                emit=_put,
            )
        except Exception as exc:
            logger.exception("KPI stream failed [query={} session={}]", query_id, session_id)
            _put("error", {"message": str(exc)})
        finally:
            _put("__done__", {})

    # Launch background thread
    loop.run_in_executor(None, _run_in_thread)

    async def _stream() -> AsyncGenerator[str, None]:
        yield _sse("stream_started", {"query_id": query_id, "session_id": session_id})

        last_event_time = loop.time()
        while True:
            try:
                item = await asyncio.wait_for(event_queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                now = loop.time()
                if now - last_event_time >= _KEEPALIVE_INTERVAL_SEC:
                    yield ": keep-alive\n\n"
                    last_event_time = now
                continue

            last_event_time = loop.time()
            event_name = item["event"]
            if event_name == "__done__":
                break
            yield _sse(event_name, item["data"])
            if event_name == "error":
                break

    return StreamingResponse(
        _stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
