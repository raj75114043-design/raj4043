
# Charts endpoints.
#
#   GET    /api/v1/charts               — List chart files
#   GET    /api/v1/charts/latest/view   — Serve the most recently created chart
#   GET    /api/v1/charts/{filename}    — Serve a specific chart file
#   DELETE /api/v1/charts/{filename}    — Delete a chart file
from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import HTMLResponse

from config.settings import config

router = APIRouter(prefix="/charts", tags=["Charts"])

_CHARTS_DIR: Path = config.charts_dir


def _chart_dir() -> Path:
    """Return the charts directory, creating it if necessary."""
    _CHARTS_DIR.mkdir(parents=True, exist_ok=True)
    return _CHARTS_DIR


def _list_chart_files(limit: int) -> list[dict]:
    d = _chart_dir()
    files = sorted(
        (f for f in d.iterdir() if f.suffix == ".html"),
        key=lambda f: f.stat().st_mtime,
        reverse=True,
    )[:limit]
    return [
        {
            "filename": f.name,
            "url": f"/api/v1/charts/{f.name}",
            "size_bytes": f.stat().st_size,
            "created_at": datetime.fromtimestamp(f.stat().st_mtime).isoformat(),
        }
        for f in files
    ]


# ── Routes ────────────────────────────────────────────────────────────────────

@router.get("")
def list_charts(limit: int = Query(default=20, ge=1, le=100)):
    """List available chart files, newest first."""
    return {"charts": _list_chart_files(limit)}


@router.get("/latest/view", response_class=HTMLResponse)
def get_latest_chart():
    """Serve the most recently created chart as HTML."""
    files = _list_chart_files(limit=1)
    if not files:
        raise HTTPException(status_code=404, detail="No charts available")
    path = _chart_dir() / files[0]["filename"]
    return HTMLResponse(content=path.read_text(encoding="utf-8"))


@router.get("/{filename}", response_class=HTMLResponse)
def get_chart(filename: str):
    """Serve a specific chart file as HTML."""
    # Prevent path traversal
    if "/" in filename or "\\" in filename or ".." in filename:
        raise HTTPException(status_code=400, detail="Invalid filename")
    path = _chart_dir() / filename
    if not path.exists() or path.suffix != ".html":
        raise HTTPException(status_code=404, detail=f"Chart '{filename}' not found")
    return HTMLResponse(content=path.read_text(encoding="utf-8"))


@router.delete("/{filename}", status_code=204)
def delete_chart(filename: str):
    """Delete a chart file."""
    if "/" in filename or "\\" in filename or ".." in filename:
        raise HTTPException(status_code=400, detail="Invalid filename")
    path = _chart_dir() / filename
    if not path.exists() or path.suffix != ".html":
        raise HTTPException(status_code=404, detail=f"Chart '{filename}' not found")
    path.unlink()
