# Sessions endpoints.
#
#   POST   /api/v1/sessions                              — Create a new session
#   GET    /api/v1/sessions                              — List sessions (optional user filter)
#   GET    /api/v1/sessions/{session_id}                 — Get session info
#   DELETE /api/v1/sessions/{session_id}                 — Delete session
#   GET    /api/v1/sessions/{session_id}/history         — Get message history
#   POST   /api/v1/sessions/{session_id}/chat            — Send a message (SSE with keep-alive)
#   POST   /api/v1/sessions/{session_id}/chat/stream     — Send a message (SSE stream)
from __future__ import annotations

import asyncio
import json
import time
import uuid
from typing import AsyncGenerator, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from loguru import logger

import services.db_service as db_svc
import services.escalation_service as escalation_svc
from api.v1.deps import require_ready
from api.v1.schemas import (
    ChatMessage,
    ChatRequest,
    SessionCreate,
    SessionHistory,
    SessionInfo,
    SessionList,
    SessionSummary,
)
from graph import stream_escalation
from services.compaction_service import compact_response
from services.escalation_service import build_conversation_history
from services.sse_manager import sse_manager

router = APIRouter(prefix="/sessions", tags=["Sessions"])

_CHAT_TIMEOUT_SEC = 360.0
_KEEPALIVE_INTERVAL_SEC = 15


# ── Helpers ──────────────────────────────────────────────────────────────────

def _sse(event: str, data: dict) -> str:
    """Format a single Server-Sent Event."""
    return f"event: {event}\ndata: {json.dumps(data, default=str)}\n\n"


def _chat_error(exc: Exception, session_id: str) -> HTTPException:
    """Convert agent/LLM exceptions into clean HTTP errors."""
    err_str = str(exc)
    err_type = type(exc).__name__

    # LLM provider errors (OpenAI, gateway)
    if "openai" in (getattr(type(exc), "__module__", "") or "").lower():
        if "authentication" in err_str.lower() or "signing key" in err_str.lower():
            logger.error("POST /chat | session={} | LLM auth error: {}", session_id, err_str[:200])
            return HTTPException(
                status_code=502,
                detail="LLM gateway authentication failed. The API key or signing token may have expired.",
            )
        if "rate" in err_str.lower() and "limit" in err_str.lower():
            logger.warning("POST /chat | session={} | LLM rate limited: {}", session_id, err_str[:200])
            return HTTPException(
                status_code=429,
                detail="LLM gateway rate limit reached. Please retry after a short wait.",
            )
        if "timeout" in err_str.lower():
            logger.error("POST /chat | session={} | LLM timeout: {}", session_id, err_str[:200])
            return HTTPException(
                status_code=504,
                detail="LLM gateway timed out. Please try again.",
            )
        logger.error("POST /chat | session={} | LLM error ({}): {}", session_id, err_type, err_str[:300])
        return HTTPException(
            status_code=502,
            detail=f"LLM gateway error: {err_str[:200]}",
        )

    # Database errors
    if any(k in err_type.lower() for k in ("psycopg", "sqlalchemy", "operationalerror")):
        logger.error("POST /chat | session={} | DB error ({}): {}", session_id, err_type, err_str[:300])
        return HTTPException(
            status_code=503,
            detail="Database connection error. Please try again.",
        )

    # Catch-all
    logger.exception("POST /chat | session={} | unexpected error ({}): {}", session_id, err_type, err_str[:300])
    return HTTPException(
        status_code=500,
        detail=f"An unexpected error occurred: {err_str[:200]}",
    )


def _thread_to_session_info(thread: dict) -> SessionInfo:
    """Convert a db thread dict to SessionInfo, checking for active HITL pauses."""
    session_id = thread["thread_id"]
    pending = db_svc.get_pending_clarification(session_id)
    active = [session_id] if pending else []
    return SessionInfo(
        session_id=session_id,
        user_id=thread.get("user_id", ""),
        message_count=thread.get("total_queries", 0),
        active_sessions=active,
    )


def _thread_to_session_summary(thread: dict) -> SessionSummary:
    messages = db_svc.get_messages_by_thread(thread["thread_id"])
    first_message = messages[0]["original_query"] if messages else ""
    return SessionSummary(
        session_id=thread["thread_id"],
        user_id=thread.get("user_id", ""),
        first_message=first_message,
    )


# ── Session CRUD ─────────────────────────────────────────────────────────────

@router.post("", response_model=SessionInfo, status_code=201)
def create_session(req: SessionCreate, _=Depends(require_ready)):
    """Create a new conversation session."""
    session_id = req.session_id or str(uuid.uuid4())
    db_svc.upsert_thread(session_id, req.user_id)
    thread = db_svc.get_thread(session_id)
    if not thread:
        raise HTTPException(status_code=500, detail="Failed to create session")
    return _thread_to_session_info(thread)


@router.get("", response_model=SessionList)
def list_sessions(
        user_id: Optional[str] = Query(None, description="Filter sessions by user."),
        _=Depends(require_ready),
):
    """List all sessions, optionally filtered by user."""
    threads = db_svc.get_threads_by_user(user_id)
    summaries = [_thread_to_session_summary(t) for t in threads]
    return SessionList(sessions=summaries)


@router.get("/{session_id}", response_model=SessionInfo)
def get_session(session_id: str, _=Depends(require_ready)):
    """Get metadata for a single session."""
    thread = db_svc.get_thread(session_id)
    if not thread:
        raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")
    return _thread_to_session_info(thread)


@router.delete("/{session_id}", status_code=204)
def delete_session(session_id: str, _=Depends(require_ready)):
    """Permanently delete a session and all its messages."""
    deleted = db_svc.delete_thread(session_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")


@router.get("/{session_id}/history", response_model=SessionHistory)
def get_session_history(session_id: str, _=Depends(require_ready)):
    """Return all messages for a session as a chat-style conversation.

    Each DB row (one agent query) is expanded into a user message + assistant
    message pair. Chart paths are converted to HTTP URLs. All important
    metadata (query_id, routing_decision, escalation_steps, timing) is
    preserved on the assistant message.
    """
    thread = db_svc.get_thread(session_id)
    if not thread:
        raise HTTPException(status_code=404, detail=f"Session '{session_id}' not found")

    rows = db_svc.get_messages_by_thread(session_id)
    messages: list[ChatMessage] = []

    for row in rows:
        # User message
        messages.append(ChatMessage(
            role="user",
            content=row.get("original_query", ""),
            charts=[],
            query_id=row.get("query_id"),
            started_at=row.get("started_at"),
        ))

        # Assistant message (only if there's a response)
        final_response = row.get("final_response") or ""
        if final_response or row.get("status") in ("complete", "error"):
            messages.append(ChatMessage(
                role="assistant",
                content=final_response,
                compacted=row.get("compacted") or "",
                charts=row.get("chart_paths") or [],
                query_id=row.get("query_id"),
                routing_decision=row.get("routing_decision"),
                escalation_steps=row.get("escalation_steps"),
                status=row.get("status"),
                started_at=row.get("started_at"),
                completed_at=row.get("completed_at"),
                duration_ms=row.get("duration_ms"),
            ))

    return SessionHistory(session_id=session_id, messages=messages)


# ── Chat (SSE with keep-alive) ──────────────────────────────────────────────

@router.post("/{session_id}/chat")
async def chat(session_id: str, req: ChatRequest, _=Depends(require_ready)):
    """
    Send a message and get a reply as SSE with keep-alive heartbeats.

    The agent call can take minutes (SQL execution, LLM calls). To prevent
    proxies/load balancers from killing the connection, this endpoint streams
    SSE with periodic keep-alive pings while the agent works in a background thread.
    """
    logger.info("POST /chat | session={} | msg={!r}", session_id, req.message[:80])

    thread = db_svc.get_thread(session_id)
    if not thread:
        db_svc.upsert_thread(session_id, req.user_id)

    async def generate():
        loop = asyncio.get_event_loop()

        pending = db_svc.get_pending_clarification(session_id)
        if pending:
            chat_task = asyncio.ensure_future(
                asyncio.wait_for(
                    loop.run_in_executor(
                        None, escalation_svc.resume_query, req.message, session_id,
                    ),
                    timeout=_CHAT_TIMEOUT_SEC,
                )
            )
        else:
            chat_task = asyncio.ensure_future(
                asyncio.wait_for(
                    loop.run_in_executor(
                        None, escalation_svc.run_query, req.message, session_id, req.user_id,
                    ),
                    timeout=_CHAT_TIMEOUT_SEC,
                )
            )

        # Keep-alive loop while agent works
        elapsed = 0.0
        since_ping = 0.0
        while not chat_task.done():
            await asyncio.sleep(1.0)
            elapsed += 1.0
            since_ping += 1.0
            if since_ping >= _KEEPALIVE_INTERVAL_SEC:
                since_ping = 0.0
                logger.debug("POST /chat | session={} | keep-alive ping at {:.0f}s", session_id, elapsed)
                yield ": keep-alive\n\n"

        # Retrieve result
        try:
            result = chat_task.result()
        except asyncio.TimeoutError:
            logger.error("POST /chat | session={} | timed out after {:.0f}s", session_id, _CHAT_TIMEOUT_SEC)
            yield _sse("error", {"message": f"Request timed out after {_CHAT_TIMEOUT_SEC:.0f}s"})
            return
        except Exception as exc:
            err = _chat_error(exc, session_id)
            yield _sse("error", {"message": err.detail})
            return

        payload = {
            "session_id": session_id,
            "reply": result.get("final_response", ""),
            "compacted": result.get("compacted", ""),
            "status": result.get("status", "complete"),
            "routing_decision": result.get("routing_decision", ""),
            "escalation_type": result.get("escalation_type", ""),
            "escalation_steps": result.get("escalation_steps", []),
            "charts": result.get("charts", []),
            "errors": result.get("errors", []),
        }
        if result.get("clarification"):
            payload["clarification"] = result["clarification"]
        yield _sse("done", payload)
        logger.info("POST /chat | session={} | completed in {:.1f}s", session_id, elapsed)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


# ── Chat stream (SSE) ─────────────────────────────────────────────────────────

def _run_stream_thread(
        query: str,
        query_id: str,
        session_id: str,
        user_id: str,
        conversation_history: str = "",
) -> None:
    t0 = time.perf_counter()

    db_svc.upsert_thread(session_id, user_id)
    db_svc.create_query(query_id, session_id, user_id, query)

    def _on_hitl(payload: dict) -> None:
        db_svc.update_query_paused(query_id)
        db_svc.create_hitl_clarification(
            query_id=query_id,
            thread_id=session_id,
            questions_asked=payload.get("questions", []),
            assumptions_offered=payload.get("assumptions_if_skipped", []),
        )

    try:
        final_state = stream_escalation(
            query=query,
            query_id=query_id,
            thread_id=session_id,
            mgr=sse_manager,
            on_hitl=_on_hitl,
            conversation_history=conversation_history,
        )
        duration_ms = round((time.perf_counter() - t0) * 1000, 1)

        compacted = compact_response(
            response=final_state.get("final_response", ""),
            user_query=query,
            routing_decision=final_state.get("routing_decision", ""),
        )

        db_svc.update_query_complete(
            query_id=query_id,
            refined_query=final_state.get("refined_query", ""),
            routing_decision=final_state.get("routing_decision", ""),
            escalation_steps=final_state.get("escalation_steps", []),
            final_response=final_state.get("final_response", ""),
            duration_ms=duration_ms,
            chart_paths=final_state.get("charts", []),
            compacted=compacted,
        )
        sse_manager.put_sync(query_id, "complete", {
            "final_response": final_state.get("final_response", ""),
            "compacted": compacted,
            "routing_decision": final_state.get("routing_decision", ""),
            "escalation_type": final_state.get("escalation_type", ""),
            "escalation_steps": final_state.get("escalation_steps", []),
            "traversal_steps": final_state.get("traversal_steps_taken", 0),
            "charts": final_state.get("charts", []),
            "errors": final_state.get("errors", []),
        })

    except Exception as exc:
        duration_ms = round((time.perf_counter() - t0) * 1000, 1)
        logger.exception("stream_escalation failed [query={} session={}]", query_id, session_id)
        db_svc.update_query_error(query_id, duration_ms)
        sse_manager.put_sync(query_id, "error", {"message": str(exc)})

    finally:
        sse_manager.put_sync(query_id, "__done__", {})


async def _event_generator(
        queue: asyncio.Queue,
        query_id: str,
        session_id: str,
) -> AsyncGenerator[str, None]:
    last_event_time = asyncio.get_event_loop().time()
    try:
        while True:
            try:
                item = await asyncio.wait_for(queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                now = asyncio.get_event_loop().time()
                if now - last_event_time >= _KEEPALIVE_INTERVAL_SEC:
                    yield ": keep-alive\n\n"
                    last_event_time = now
                continue

            last_event_time = asyncio.get_event_loop().time()
            event_name = item["event"]
            if event_name == "__done__":
                break
            yield _sse(event_name, item["data"])
            if event_name == "error":
                break
    finally:
        sse_manager.cleanup(query_id, session_id)


@router.post("/{session_id}/chat/stream")
async def chat_stream(session_id: str, req: ChatRequest, _=Depends(require_ready)):
    """
    Stream agent work as Server-Sent Events with keep-alive heartbeats.

    Sends periodic keep-alive pings between tool calls to prevent
    proxy/load balancer timeouts during long-running SQL or LLM operations.

    If the session has a pending HITL pause with an active stream, the message
    is forwarded as a resume signal. Otherwise a new stream is started.
    """
    logger.info("POST /chat/stream | session={} | msg={!r}", session_id, req.message[:80])

    # If there's an active SSE stream waiting for HITL, signal resume
    signaled = sse_manager.signal_resume(session_id, req.message)
    if signaled:
        query_id = db_svc.get_paused_query_id(session_id)
        clarification = req.message.strip() or "Accept stated assumptions"
        was_skipped = clarification == "Accept stated assumptions"
        if query_id:
            db_svc.update_hitl_answered(query_id, clarification, was_skipped)
        db_svc.touch_thread(session_id)

        async def _ack():
            yield _sse("hitl_resumed", {"session_id": session_id})

        return StreamingResponse(
            _ack(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
        )

    query_id = str(uuid.uuid4())
    conversation_history = build_conversation_history(session_id)
    loop = asyncio.get_running_loop()
    queue = sse_manager.register(query_id, loop)

    loop.run_in_executor(
        None,
        _run_stream_thread,
        req.message, query_id, session_id, req.user_id, conversation_history,
    )

    async def _stream_with_preamble() -> AsyncGenerator[str, None]:
        yield _sse("stream_started", {"query_id": query_id, "session_id": session_id})
        async for chunk in _event_generator(queue, query_id, session_id):
            yield chunk

    return StreamingResponse(
        _stream_with_preamble(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
