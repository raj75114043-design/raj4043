# SSE Escalation endpoints.

#   GET  /api/v1/analyze/stream         — start a streaming escalation investigation
#   POST /api/v1/analyze/stream/resume  — resume a paused (HITL) stream
from __future__ import annotations

import asyncio
import json
import time
import uuid
from typing import AsyncGenerator

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from loguru import logger
from pydantic import BaseModel

import services.db_service as db_svc
from api.v1.deps import require_ready
from graph import stream_escalation
from services.compaction_service import compact_response
from services.escalation_service import build_conversation_history
from services.sse_manager import sse_manager

router = APIRouter(prefix="/analyze", tags=["SSE Stream"])

_KEEPALIVE_INTERVAL_SEC = 15


class StreamResumeRequest(BaseModel):
    thread_id: str
    clarification: str

    model_config = {
        "json_schema_extra": {
            "example": {
                "thread_id": "session-abc-123",
                "clarification": "Analyze for last 90 days across all regions.",
            }
        }
    }


def _sse(event: str, data: dict) -> str:
    """Format a single Server-Sent Event."""
    return f"event: {event}\ndata: {json.dumps(data, default=str)}\n\n"


def _run_stream_thread(
        query: str,
        query_id: str,
        thread_id: str,
        user_id: str,
        conversation_history: str = "",
) -> None:
    t0 = time.perf_counter()

    db_svc.upsert_thread(thread_id, user_id)
    db_svc.create_query(query_id, thread_id, user_id, query)

    def _on_hitl(payload: dict) -> None:
        db_svc.update_query_paused(query_id)
        db_svc.create_hitl_clarification(
            query_id=query_id,
            thread_id=thread_id,
            questions_asked=payload.get("questions", []),
            assumptions_offered=payload.get("assumptions_if_skipped", []),
        )

    try:
        final_state = stream_escalation(
            query=query,
            query_id=query_id,
            thread_id=thread_id,
            mgr=sse_manager,
            on_hitl=_on_hitl,
            conversation_history=conversation_history,
        )
        duration_ms = round((time.perf_counter() - t0) * 1000, 1)

        compacted = compact_response(
            response=final_state.get("final_response", ""),
            user_query=query,
            routing_decision=final_state.get("routing_decision", ""),
        )

        db_svc.update_query_complete(
            query_id=query_id,
            refined_query=final_state.get("refined_query", ""),
            routing_decision=final_state.get("routing_decision", ""),
            escalation_steps=final_state.get("escalation_steps", []),
            final_response=final_state.get("final_response", ""),
            duration_ms=duration_ms,
            chart_paths=final_state.get("charts", []),
            compacted=compacted,
        )
        sse_manager.put_sync(query_id, "complete", {
            "final_response": final_state.get("final_response", ""),
            "compacted": compacted,
            "routing_decision": final_state.get("routing_decision", ""),
            "escalation_type": final_state.get("escalation_type", ""),
            "escalation_steps": final_state.get("escalation_steps", []),
            "traversal_steps": final_state.get("traversal_steps_taken", 0),
            "charts": final_state.get("charts", []),
            "errors": final_state.get("errors", []),
        })

    except Exception as exc:
        duration_ms = round((time.perf_counter() - t0) * 1000, 1)
        logger.exception("stream_escalation failed [query={} thread={}]", query_id, thread_id)
        db_svc.update_query_error(query_id, duration_ms)
        sse_manager.put_sync(query_id, "error", {"message": str(exc)})

    finally:
        sse_manager.put_sync(query_id, "__done__", {})


async def _event_generator(
        queue: asyncio.Queue,
        query_id: str,
        thread_id: str,
) -> AsyncGenerator[str, None]:
    last_event_time = asyncio.get_event_loop().time()
    try:
        while True:
            try:
                item = await asyncio.wait_for(queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                now = asyncio.get_event_loop().time()
                if now - last_event_time >= _KEEPALIVE_INTERVAL_SEC:
                    yield ": keep-alive\n\n"
                    last_event_time = now
                continue

            last_event_time = asyncio.get_event_loop().time()
            event_name = item["event"]
            if event_name == "__done__":
                break
            yield _sse(event_name, item["data"])
            if event_name == "error":
                break
    finally:
        sse_manager.cleanup(query_id, thread_id)


@router.get("/stream")
async def stream_analyze(
        query: str = Query(..., description="The escalation query"),
        user_id: str = Query(..., description="User identifier"),
        thread_id: str = Query(None, description="Conversation thread ID"),
        _=Depends(require_ready),
):
    """Start a streaming escalation investigation. Returns text/event-stream."""
    logger.info("GET /analyze/stream | thread={} | query={!r}", thread_id, query[:80])

    if not query.strip():
        raise HTTPException(status_code=422, detail="query cannot be empty")
    if not user_id.strip():
        raise HTTPException(status_code=422, detail="user_id cannot be empty")

    if not thread_id:
        thread_id = str(uuid.uuid4())
    query_id = str(uuid.uuid4())
    conversation_history = build_conversation_history(thread_id)

    loop = asyncio.get_running_loop()
    queue = sse_manager.register(query_id, loop)

    loop.run_in_executor(
        None,
        _run_stream_thread,
        query, query_id, thread_id, user_id, conversation_history,
    )

    async def _stream_with_preamble() -> AsyncGenerator[str, None]:
        yield _sse("stream_started", {"query_id": query_id, "thread_id": thread_id})
        async for chunk in _event_generator(queue, query_id, thread_id):
            yield chunk

    return StreamingResponse(
        _stream_with_preamble(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/stream/resume", status_code=200)
def resume_stream(req: StreamResumeRequest, _=Depends(require_ready)):
    """Resume a paused SSE stream after HITL clarification."""
    if not req.thread_id.strip():
        raise HTTPException(status_code=422, detail="thread_id cannot be empty")

    clarification = req.clarification.strip() or "Accept stated assumptions"
    was_skipped = (clarification == "Accept stated assumptions")

    query_id = db_svc.get_paused_query_id(req.thread_id)
    if query_id:
        db_svc.update_hitl_answered(query_id, clarification, was_skipped)
    db_svc.touch_thread(req.thread_id)

    signaled = sse_manager.signal_resume(req.thread_id, clarification)
    if not signaled:
        raise HTTPException(
            status_code=404,
            detail=f"No active stream found for thread '{req.thread_id}'.",
        )

    return {"status": "resumed", "thread_id": req.thread_id}
