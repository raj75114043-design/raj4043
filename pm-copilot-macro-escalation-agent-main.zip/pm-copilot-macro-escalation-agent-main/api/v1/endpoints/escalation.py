# Escalation endpoints.

#   POST /api/v1/analyze        — Start a new escalation investigation
#   POST /api/v1/analyze/resume — Resume a paused investigation with user clarification
import uuid

from fastapi import APIRouter, Depends, HTTPException

import services.escalation_service as escalation_svc
from api.v1.deps import require_ready
from api.v1.schemas import AnalyzeRequest, AnalyzeResponse, ResumeRequest

router = APIRouter(tags=["Escalation Agent"])


@router.post("/analyze", response_model=AnalyzeResponse)
def analyze(req: AnalyzeRequest, _=Depends(require_ready)):
    """
    Run a natural-language query through the Escalation Agent pipeline.

    Pipeline:
      1. Query Refiner — validates completeness; may pause for clarification.
      2. Orchestrator  — routes to the right downstream pipeline.
      3a. (greeting)   → response directly.
      3b. (traversal)  → schema discovery → traversal → response.
      3c. (escalation) → schema discovery → escalation lookup (parallel steps) → response.
    """
    thread_id = req.thread_id or str(uuid.uuid4())
    try:
        result = escalation_svc.run_query(req.query, thread_id=thread_id, user_id=req.user_id)
        return AnalyzeResponse(thread_id=thread_id, **result)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/analyze/resume", response_model=AnalyzeResponse)
def analyze_resume(req: ResumeRequest, _=Depends(require_ready)):
    """Resume an escalation investigation that paused for user clarification."""
    try:
        result = escalation_svc.resume_query(req.clarification, thread_id=req.thread_id)
        return AnalyzeResponse(thread_id=req.thread_id, **result)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
