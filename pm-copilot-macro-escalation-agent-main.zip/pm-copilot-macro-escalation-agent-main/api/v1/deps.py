"""Shared FastAPI dependencies — background startup and readiness gate.

The graph is compiled at module import time (graph.py singleton), but
heavier startup work (DB table creation, service warm-up) runs in a
background thread so the API server becomes responsive immediately
(health + readiness endpoints).  Chat/session endpoints wait for
readiness or return 503.
"""

from __future__ import annotations

import threading
import time

from fastapi import HTTPException
from loguru import logger

_ready = threading.Event()
_startup_error: Exception | None = None
_build_duration: float | None = None


def _build() -> None:
    """Heavy startup work — runs in a background thread."""
    global _startup_error, _build_duration

    t0 = time.perf_counter()
    try:
        logger.info("startup | ========== BACKGROUND BUILD STARTED ==========")

        import services.db_service as db_svc

        db_svc.ensure_tables()
        logger.info("startup | DB tables verified")

        # Force graph module import (compiles the LangGraph state machine)
        from graph import _graph

        logger.info("startup | graph compiled")

        # Bootstrap KPI table schemas + vector store (ChromaDB embeddings).
        # These are idempotent and cached — doing it here means the first
        # /kpi/sessions/chat request doesn't pay the cold-start penalty.
        try:
            from services.kpi_bootstrap import bootstrap_table_schemas as _bootstrap_table_schemas, bootstrap_kpi_embeddings as _bootstrap_kpi_embeddings

            _bootstrap_table_schemas()
            logger.info("startup | KPI table schemas bootstrapped")

            kpi_count = _bootstrap_kpi_embeddings()
            logger.info("startup | KPI embeddings bootstrapped ({} KPIs)", kpi_count)
        except Exception as exc:
            # Non-fatal — the agent will retry on first request
            logger.warning("startup | KPI bootstrap failed (non-fatal): {}", exc)

        _build_duration = time.perf_counter() - t0
        logger.info(
            "startup | ========== READY — total startup: {:.2f}s ==========",
            _build_duration,
        )
    except Exception as exc:
        _build_duration = time.perf_counter() - t0
        _startup_error = exc
        logger.error(
            "startup | ========== BUILD FAILED after {:.2f}s: {} ==========",
            _build_duration,
            exc,
        )
    finally:
        _ready.set()


def start_build() -> None:
    """Kick off startup work in a daemon thread."""
    t = threading.Thread(target=_build, name="agent-builder", daemon=True)
    t.start()
    logger.info("startup | background builder thread launched")


def is_ready() -> bool:
    """True once the build has completed (or failed)."""
    return _ready.is_set()


def get_build_duration() -> float | None:
    """Return total build duration in seconds, or None if not yet finished."""
    return _build_duration


def require_ready():
    """FastAPI dependency — blocks briefly then returns or raises 503."""
    if not _ready.wait(timeout=0.5):
        logger.warning("require_ready | not ready yet — returning 503")
        raise HTTPException(
            status_code=503,
            detail="Agent is still initializing. Try again shortly.",
        )

    if _startup_error is not None:
        logger.error("require_ready | init failed — returning 503: {}", _startup_error)
        raise HTTPException(
            status_code=503,
            detail=f"Agent failed to initialize: {_startup_error}",
        )
