from __future__ import annotations

from dotenv import load_dotenv

load_dotenv()

import pandas as pd
import requests
from pydantic import BaseModel, Field, SecretStr, field_validator, model_validator

# ══════════════════════════════════════════════════════════════════════════════
#  Constants
# ══════════════════════════════════════════════════════════════════════════════

EXCEL_PATH = "Escalation_Types_All23.xlsx"
SHEET_NAME = "Escalation Types"

API_BASE_URL = (
    "https://pm-copilot-macro-gcl-osdp-gsd-gsd-delivery-staging"
    ".aibi-americas-002.dyn.nesc.nokia.net"
)
BULK_ENDPOINT = f"{API_BASE_URL}/api/v1/escalation/escalation/bulk"

# Batch size for bulk API calls
BATCH_SIZE = 10


# ══════════════════════════════════════════════════════════════════════════════
#  Pydantic Models — matches the API schema
# ══════════════════════════════════════════════════════════════════════════════


class EscalationPayload(BaseModel):
    """
    Pydantic model matching the bulk API request schema.
    Note: the API expects list[str] for several fields — we split
    multi-line Excel text into lists by newline / bullet points.
    """

    escalation_type: str
    escalation_description: list[str] = Field(default_factory=list)
    probable_reasons: list[str] = Field(default_factory=list)
    recommended_resolution: list[str] = Field(default_factory=list)
    expected_agent_output: list[str] = Field(default_factory=list)
    draft_escalation_message_template: str = ""
    relevent_kpi_s: list[str] = Field(default_factory=list)
    vertical: str = ""

    @field_validator("*", mode="before")
    @classmethod
    def clean_value(cls, v, info):
        """Coerce NaN / 'nan' / blanks → appropriate empty default."""
        if v is None:
            return None
        if isinstance(v, (int, float)):
            if pd.isna(v):
                return None
            return str(v).strip() or None
        if isinstance(v, list):
            return v
        s = str(v).strip()
        if not s or s.lower() in ("nan", "none", "null", "nat"):
            return None
        return s

    @model_validator(mode="before")
    @classmethod
    def split_list_fields(cls, data: dict) -> dict:
        """
        Convert multi-line text fields into list[str] for the API.
        Splits on newlines, bullet points (•, -, *), and numbered items (1., 2.).
        """
        import re

        list_fields = [
            "escalation_description",
            "probable_reasons",
            "recommended_resolution",
            "expected_agent_output",
            "relevent_kpi_s",
        ]

        for field_name in list_fields:
            val = data.get(field_name)
            if val is None or (isinstance(val, list)):
                continue
            if isinstance(val, (int, float)):
                if pd.isna(val):
                    data[field_name] = []
                    continue
                val = str(val)

            raw = str(val).strip()
            if not raw or raw.lower() in ("nan", "none", "null", "nat"):
                data[field_name] = []
                continue

            # Split on: newlines, bullet chars (• - *), numbered items (1. 2.)
            items = re.split(r"\n|(?:^|\n)\s*[•\-\*]\s*|(?:^|\n)\s*\d+\.\s*", raw)
            # Clean and filter empty
            items = [item.strip() for item in items if item.strip()]
            data[field_name] = items if items else [raw]

        # Ensure string fields have defaults
        for str_field in ["escalation_type", "draft_escalation_message_template", "vertical"]:
            val = data.get(str_field)
            if val is None or (isinstance(val, float) and pd.isna(val)):
                data[str_field] = ""
            elif isinstance(val, str):
                s = val.strip()
                data[str_field] = "" if s.lower() in ("nan", "none", "null", "nat") else s

        return data

    @model_validator(mode="after")
    def must_have_content(self) -> "EscalationPayload":
        """At least escalation_type or escalation_description must be present."""
        if not self.escalation_type and not self.escalation_description:
            raise ValueError("Row is empty — no escalation_type or escalation_description")
        return self


class IngestionSummary(BaseModel):
    """Summary of the ingestion run."""

    total_rows: int = 0
    validated: int = 0
    pushed: int = 0
    skipped_validation_error: int = 0
    skipped_api_error: int = 0
    api_errors: list[str] = Field(default_factory=list)

    @property
    def total_skipped(self) -> int:
        return self.skipped_validation_error + self.skipped_api_error

    def print_report(self):
        print(f"\n{'═' * 60}")
        print(f"  Ingestion Summary")
        print(f"  {'Total rows in Excel':<35} {self.total_rows}")
        print(f"  {'Passed Pydantic validation':<35} {self.validated}")
        print(f"  {'Successfully pushed to API':<35} {self.pushed}")
        print(f"  {'Skipped (validation error)':<35} {self.skipped_validation_error}")
        print(f"  {'Skipped (API error)':<35} {self.skipped_api_error}")
        print(f"  {'Total skipped':<35} {self.total_skipped}")
        if self.api_errors:
            print(f"\n  API Errors:")
            for err in self.api_errors[:10]:
                print(f"    • {err}")
            if len(self.api_errors) > 10:
                print(f"    ... and {len(self.api_errors) - 10} more")
        print(f"{'═' * 60}")


class APIConfig(BaseModel):
    """Validated API authentication configuration."""

    username: str = Field(min_length=1, description="API username")
    password: SecretStr = Field(min_length=1, description="API password")

    @property
    def basic_auth(self) -> tuple[str, str]:
        """Return (username, password) tuple for requests auth parameter."""
        return (self.username, self.password.get_secret_value())


# ══════════════════════════════════════════════════════════════════════════════
#  Header normalisation (Excel → canonical field names)
# ══════════════════════════════════════════════════════════════════════════════

HEADER_ALIASES: dict[str, str] = {
    # escalation_type
    "escalation_type": "escalation_type",
    "escalation type": "escalation_type",
    "escalation_types": "escalation_type",
    "escalation types": "escalation_type",
    "type": "escalation_type",
    # escalation_description
    "escalation_description": "escalation_description",
    "escalation description": "escalation_description",
    "description": "escalation_description",
    # probable_reasons
    "probable_reasons": "probable_reasons",
    "probable reasons": "probable_reasons",
    "probable_reason": "probable_reasons",
    "probable reason": "probable_reasons",
    "reasons": "probable_reasons",
    # recommended_resolution
    "recommended_resolution": "recommended_resolution",
    "recommended resolution": "recommended_resolution",
    "resolution": "recommended_resolution",
    # expected_agent_output
    "expected_agent_output": "expected_agent_output",
    "expected agent output": "expected_agent_output",
    "agent_output": "expected_agent_output",
    "agent output": "expected_agent_output",
    # draft_escalation_message_template
    "draft_escalation_message_template": "draft_escalation_message_template",
    "draft escalation message template": "draft_escalation_message_template",
    "draft_escalation_message_template": "draft_escalation_message_template",
    "draft escalation message yemplate": "draft_escalation_message_template",
    "message_template": "draft_escalation_message_template",
    "message template": "draft_escalation_message_template",
    # relevent_kpi_s
    "relevent_kpi_s": "relevent_kpi_s",
    "relevant_kpi_s": "relevent_kpi_s",
    "relevent_kpi(s)": "relevent_kpi_s",
    "relevant_kpi(s)": "relevent_kpi_s",
    "relevent kpi(s)": "relevent_kpi_s",
    "relevant kpi(s)": "relevent_kpi_s",
    "relevent kpi s": "relevent_kpi_s",
    "relevant kpi s": "relevent_kpi_s",
    "relevant kpi's": "relevent_kpi_s",
    "relevent kpi's": "relevent_kpi_s",
    "kpi": "relevent_kpi_s",
    "kpis": "relevent_kpi_s",
    "kpi's": "relevent_kpi_s",
    "kpi(s)": "relevent_kpi_s",
    # vertical
    "vertical": "vertical",
    "verticals": "vertical",
}


# ══════════════════════════════════════════════════════════════════════════════
#  Excel Helpers
# ══════════════════════════════════════════════════════════════════════════════


def _normalise_header(raw: str) -> str:
    return " ".join(str(raw).strip().lower().split())


def _resolve_header(raw: str) -> str | None:
    norm = _normalise_header(raw)
    for candidate in [norm, norm.replace(" ", "_"), norm.replace("_", " ")]:
        if candidate in HEADER_ALIASES:
            return HEADER_ALIASES[candidate]
    return None


def _is_serial_column(series: pd.Series, header: str) -> bool:
    h = str(header).strip().lower()
    if h in ("", "unnamed", "sr", "sr.", "s.no", "s.no.", "sl", "sl.",
             "sl.no", "sl.no.", "#", "no", "no.", "sno", "sno.", "index"):
        return True
    if h.startswith("unnamed:"):
        return True
    try:
        int(h)
        return True
    except ValueError:
        pass
    try:
        vals = series.dropna().astype(int).tolist()
        if len(vals) >= 2 and vals == list(range(vals[0], vals[0] + len(vals))):
            return True
    except (ValueError, TypeError):
        pass
    return False


# ══════════════════════════════════════════════════════════════════════════════
#  API Client
# ══════════════════════════════════════════════════════════════════════════════


def push_bulk(
        payloads: list[EscalationPayload],
        auth: tuple[str, str],
        batch_size: int = BATCH_SIZE,
) -> tuple[int, list[str]]:
    """
    Push escalation payloads to the bulk API endpoint in batches.
    Uses HTTP Basic Auth (username, password) on each request.
    Returns (success_count, error_messages).
    """
    total_pushed = 0
    errors: list[str] = []

    for batch_start in range(0, len(payloads), batch_size):
        batch = payloads[batch_start: batch_start + batch_size]
        batch_num = (batch_start // batch_size) + 1
        batch_end = min(batch_start + batch_size, len(payloads))

        print(
            f"  Batch {batch_num}: Pushing rows {batch_start + 1}–{batch_end}...",
            end=" ", flush=True,
        )

        json_body = [item.model_dump() for item in batch]

        try:
            resp = requests.post(
                BULK_ENDPOINT,
                json=json_body,
                auth=auth,
                headers={
                    "accept": "application/json",
                    "Content-Type": "application/json",
                },
                timeout=60,
            )

            if resp.status_code in (200, 201):
                print(f"OK ({resp.status_code})")
                total_pushed += len(batch)
            else:
                err_msg = (
                    f"Batch {batch_num} (rows {batch_start + 1}–{batch_end}): "
                    f"HTTP {resp.status_code} — {resp.text[:200]}"
                )
                print(f"FAILED ({resp.status_code})")
                errors.append(err_msg)

        except requests.RequestException as e:
            err_msg = (
                f"Batch {batch_num} (rows {batch_start + 1}–{batch_end}): "
                f"Request failed — {e}"
            )
            print(f"FAILED ({e})")
            errors.append(err_msg)

    return total_pushed, errors


# ══════════════════════════════════════════════════════════════════════════════
#  Main Ingestion
# ══════════════════════════════════════════════════════════════════════════════


def ingest(
        username: str,
        password: str,
        batch_size: int = BATCH_SIZE,
) -> IngestionSummary:
    """
    Read the Escalation Scenarios Excel file, validate each row with Pydantic,
    and push to the bulk API endpoint with Basic Auth.
    """
    summary = IngestionSummary()

    # ── Validate API credentials ─────────────────────────────────────────────

    api_config = APIConfig(username=username, password=password)
    print(f"  API auth: {api_config.username}@{BULK_ENDPOINT}")

    # ══════════════════════════════════════════════════════════════════════════
    #  STEP 1: Load & map Excel
    # ══════════════════════════════════════════════════════════════════════════

    print(f"Loading Excel: {EXCEL_PATH} (sheet: '{SHEET_NAME}')")
    df_raw = pd.read_excel(EXCEL_PATH, header=0, sheet_name=SHEET_NAME)

    summary.total_rows = len(df_raw)
    print(f"  Excel shape : {df_raw.shape[0]} rows × {df_raw.shape[1]} columns")
    print(f"  Excel headers: {list(df_raw.columns)}")

    # Drop serial/index columns
    serial_cols = [
        col for col in df_raw.columns
        if _is_serial_column(df_raw[col], col)
    ]
    if serial_cols:
        print(f"  Detected serial/index columns (dropping): {serial_cols}")
        df_raw = df_raw.drop(columns=serial_cols)

    # Map headers
    header_map: dict[str, str] = {}
    unmapped: list[str] = []
    for raw_header in df_raw.columns:
        db_col = _resolve_header(str(raw_header))
        if db_col:
            header_map[raw_header] = db_col
        else:
            unmapped.append(str(raw_header))

    print(f"\n  Header mapping ({len(header_map)} matched):")
    for excel_h, db_c in header_map.items():
        print(f"    '{excel_h}'  →  {db_c}")
    if unmapped:
        print(f"  Unmapped Excel columns (ignored): {unmapped}")

    if not header_map:
        print("\n  ERROR: Could not map ANY Excel header. Aborting.")
        return summary

    # Rename to canonical field names
    df = df_raw[list(header_map.keys())].rename(columns=header_map)
    df = df.loc[:, ~df.columns.duplicated(keep="first")]
    print(f"\n  Mapped columns: {list(df.columns)}")

    # ══════════════════════════════════════════════════════════════════════════
    #  STEP 2: Validate all rows with Pydantic
    # ══════════════════════════════════════════════════════════════════════════

    validated: list[EscalationPayload] = []
    print(f"\n  Validating {len(df)} rows...")

    for row_idx, row_series in df.iterrows():
        raw_dict = row_series.to_dict()
        try:
            parsed = EscalationPayload(**raw_dict)
            validated.append(parsed)
        except Exception as e:
            summary.skipped_validation_error += 1
            if summary.skipped_validation_error <= 5:
                print(f"    Row {row_idx + 1}: Validation failed — {e}")

    summary.validated = len(validated)
    print(
        f"  Validated: {len(validated)} OK, "
        f"{summary.skipped_validation_error} failed"
    )

    if not validated:
        print("  ERROR: No valid rows. Aborting.")
        summary.print_report()
        return summary

    # Dry-run: show first validated payload as JSON
    first = validated[0]
    print(f"\n  ── DRY RUN (Row 1 → API payload) ──")
    import json
    print(json.dumps(first.model_dump(), indent=2, default=str)[:600])
    if len(json.dumps(first.model_dump())) > 600:
        print("  ...")
    print()

    # ══════════════════════════════════════════════════════════════════════════
    #  STEP 3: Push to bulk API
    # ══════════════════════════════════════════════════════════════════════════

    print(f"  Pushing {len(validated)} rows to API in batches of {batch_size}...")
    print(f"  Endpoint: {BULK_ENDPOINT}\n")

    pushed, errors = push_bulk(validated, auth=api_config.basic_auth, batch_size=batch_size)
    summary.pushed = pushed
    summary.skipped_api_error = len(validated) - pushed
    summary.api_errors = errors

    summary.print_report()
    return summary


if __name__ == "__main__":
    ingest(
        username="abcd",
        password="pwc_macro_team",
        batch_size=5,
    )
