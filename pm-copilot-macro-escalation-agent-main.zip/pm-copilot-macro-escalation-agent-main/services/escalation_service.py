# Escalation Service — business logic layer for the LangGraph Escalation Agent pipeline.

# Exposes three operations:
#   - run_query(query, thread_id, user_id)    — start a new escalation investigation
#   - resume_query(clarification, thread_id)  — resume after HITL clarification
#   - get_interrupt_status(thread_id)         — check if a thread is paused
from __future__ import annotations

import time
import uuid

from loguru import logger

import services.db_service as db_svc
from graph import run_escalation, resume_escalation, get_pending_interrupt
from services.compaction_service import compact_response

# ── Conversation history ─────────────────────────────────────────────────────

_MAX_HISTORY_TURNS = 8  # keep last N exchanges (GPT-5 context)
_MAX_RESPONSE_CHARS = 500  # fallback truncation for non-compacted turns
_MAX_HISTORY_TOTAL_CHARS = 6000  # hard cap on total conversation history length


def build_conversation_history(thread_id: str) -> str:
    """Build a compact conversation summary from past turns in this thread.

    Returns a formatted string ready to inject into agent prompts.
    Only includes completed queries (not the current one being processed).
    Uses LLM-compacted summaries when available, falls back to truncation.
    """
    rows = db_svc.get_messages_by_thread(thread_id)
    if not rows:
        logger.debug("ConversationHistory | no rows for thread={}", thread_id)
        return ""

    # Only include completed turns that have a response
    completed = [
        r for r in rows
        if r.get("status") == "complete" and r.get("final_response")
    ]

    if not completed:
        return ""

    # Take the most recent N turns
    recent = completed[-_MAX_HISTORY_TURNS:]

    lines = []
    for i, row in enumerate(recent, 1):
        user_msg = row.get("original_query", "").strip()

        # Prefer compacted summary; fall back to truncated raw response
        assistant_msg = (row.get("compacted") or "").strip()
        if not assistant_msg:
            assistant_msg = (row.get("final_response") or "").strip()
            if len(assistant_msg) > _MAX_RESPONSE_CHARS:
                assistant_msg = assistant_msg[:_MAX_RESPONSE_CHARS] + "..."

        routing = row.get("routing_decision", "")
        routing_tag = f" [{routing}]" if routing else ""

        lines.append(f"Turn {i}{routing_tag}:")
        lines.append(f"  User: {user_msg}")
        lines.append(f"  Assistant: {assistant_msg}")

    result = "\n".join(lines)

    # Hard cap: truncate from the front (oldest turns) if total is too long
    if len(result) > _MAX_HISTORY_TOTAL_CHARS:
        result = "... (older turns trimmed)\n" + result[-_MAX_HISTORY_TOTAL_CHARS:]

    logger.info(
        "ConversationHistory | thread={} | total_rows={} | completed={} | used={} | output_len={}",
        thread_id, len(rows), len(completed), len(recent), len(result),
    )
    return result


def _shape_response(state: dict) -> dict:
    """Convert a raw EscalationState dict into the API response shape.

    Chart paths are always converted to HTTP URLs so every consumer
    (chat, stream, escalation endpoint) gets clean URLs.
    """
    interrupts = state.get("__interrupt__", [])
    if interrupts:
        raw = interrupts[0]
        interrupt_payload = raw.value if hasattr(raw, "value") else raw
        return {
            "status": "clarification_needed",
            "clarification": interrupt_payload,
            "final_response": "",
            "errors": [],
            "traversal_steps": 0,
            "routing_decision": "",
            "escalation_type": "",
            "escalation_steps": [],
            "charts": [],
        }

    return {
        "status": "complete",
        "clarification": None,
        "final_response": state.get("final_response", ""),
        "errors": state.get("errors", []),
        "traversal_steps": state.get("traversal_steps_taken", 0),
        "routing_decision": state.get("routing_decision", ""),
        "escalation_type": state.get("escalation_type", ""),
        "escalation_steps": state.get("escalation_steps", []),
        "escalation_description": state.get("escalation_description", ""),
        "probable_reasons": state.get("probable_reasons", ""),
        "recommended_resolution": state.get("recommended_resolution", ""),
        "expected_agent_output": state.get("expected_agent_output", ""),
        "draft_escalation_message_template": state.get("draft_escalation_message_template", ""),
        "relevant_kpis": state.get("relevant_kpis", ""),
        "escalation_vertical": state.get("escalation_vertical", ""),
        "escalation_similarity_score": state.get("escalation_similarity_score", 0.0),
        "charts": state.get("charts", []),
    }


def run_query(
        query: str,
        thread_id: str = "default",
        user_id: str = "anonymous",
) -> dict:
    """Start a new escalation investigation."""
    if not query.strip():
        raise ValueError("Query cannot be empty")

    query_id = str(uuid.uuid4())
    t0 = time.perf_counter()

    db_svc.upsert_thread(thread_id, user_id)
    db_svc.create_query(query_id, thread_id, user_id, query)
    db_svc.auto_name_thread(thread_id, query)

    conversation_history = build_conversation_history(thread_id)

    logger.info("Starting escalation query [thread={} query={}]: {:.80}", thread_id, query_id, query)

    try:
        state = run_escalation(query, thread_id=thread_id, conversation_history=conversation_history)
    except Exception:
        duration_ms = round((time.perf_counter() - t0) * 1000, 1)
        db_svc.update_query_error(query_id, duration_ms)
        raise

    duration_ms = round((time.perf_counter() - t0) * 1000, 1)
    response = _shape_response(state)

    if response["status"] == "clarification_needed":
        clarification = response.get("clarification", {})
        db_svc.update_query_paused(query_id)
        db_svc.create_hitl_clarification(
            query_id=query_id,
            thread_id=thread_id,
            questions_asked=clarification.get("questions", []),
            assumptions_offered=clarification.get("assumptions_if_skipped", []),
        )
    else:
        # Generate compacted summary for conversation history
        t_compact = time.perf_counter()
        compacted = compact_response(
            response=state.get("final_response", ""),
            user_query=query,
            routing_decision=state.get("routing_decision", ""),
        )
        compact_ms = round((time.perf_counter() - t_compact) * 1000, 1)
        logger.info(
            "Compaction | query={} | response_len={} | compacted_len={} | {:.0f}ms",
            query_id, len(state.get("final_response", "")), len(compacted), compact_ms,
        )
        response["compacted"] = compacted

        db_svc.update_query_complete(
            query_id=query_id,
            refined_query=state.get("refined_query", ""),
            routing_decision=state.get("routing_decision", ""),
            escalation_steps=state.get("escalation_steps", []),
            final_response=state.get("final_response", ""),
            duration_ms=duration_ms,
            chart_paths=state.get("charts", []),
            compacted=compacted,
        )

    return response


def resume_query(clarification: str, thread_id: str) -> dict:
    """Resume a paused escalation with the user's clarification answer."""
    if not clarification.strip():
        raise ValueError("Clarification cannot be empty")
    if not thread_id.strip():
        raise ValueError("thread_id is required to resume")

    was_skipped = clarification.strip() == "Accept stated assumptions"

    query_id = db_svc.get_paused_query_id(thread_id)
    if query_id:
        db_svc.update_hitl_answered(query_id, clarification, was_skipped)

    db_svc.touch_thread(thread_id)

    logger.info("Resuming escalation query [thread={}]", thread_id)

    t0 = time.perf_counter()
    state = resume_escalation(clarification, thread_id)
    duration_ms = round((time.perf_counter() - t0) * 1000, 1)

    response = _shape_response(state)

    if query_id:
        if response["status"] == "complete":
            t_compact = time.perf_counter()
            compacted = compact_response(
                response=state.get("final_response", ""),
                user_query=clarification,
                routing_decision=state.get("routing_decision", ""),
            )
            compact_ms = round((time.perf_counter() - t_compact) * 1000, 1)
            logger.info(
                "Compaction (resume) | query={} | response_len={} | compacted_len={} | {:.0f}ms",
                query_id, len(state.get("final_response", "")), len(compacted), compact_ms,
            )
            response["compacted"] = compacted

            db_svc.update_query_complete(
                query_id=query_id,
                refined_query=state.get("refined_query", ""),
                routing_decision=state.get("routing_decision", ""),
                escalation_steps=state.get("escalation_steps", []),
                final_response=state.get("final_response", ""),
                duration_ms=duration_ms,
                chart_paths=state.get("charts", []),
                compacted=compacted,
            )
        else:
            db_svc.update_query_error(query_id, duration_ms)

    return response


def get_interrupt_status(thread_id: str) -> dict | None:
    return get_pending_interrupt(thread_id)
