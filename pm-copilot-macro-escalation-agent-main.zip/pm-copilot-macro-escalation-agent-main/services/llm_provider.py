from langchain_openai import ChatOpenAI


class LLMProvider:
    LLM_API_KEY_URL = "https://llmgateway-qa-api.nokia.com/v1.2/"

    # Client-side timeout per request. Set higher than the Nokia gateway's
    # upstream timeout so we don't give up before it does. Each retry starts a
    # fresh HTTP request, so a single slow upstream doesn't burn the budget.
    _DEFAULT_TIMEOUT_S = 300.0
    # The Nokia gateway returns HTML 500s under load; bumping retries past the
    # OpenAI SDK default (2) lets the SDK's exponential backoff ride out a
    # transient spike instead of surfacing raw "request timed out" HTML.
    _DEFAULT_MAX_RETRIES = 5

    def __init__(
            self,
            model="gpt-5-mini",
            temperature=0.0,
            reasoning_effort="medium",
            timeout: float | None = None,
            max_retries: int | None = None,
    ):
        self.llm = ChatOpenAI(
            api_key="NONE",
            model=model,
            base_url=self.LLM_API_KEY_URL,
            default_headers={
                'api-key': "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyTmFtZSI6IlJvbGxvdXRBZ2VudERldlRvb2wiLCJPYmplY3RJRCI6IjNGRUY4NzI0LUE5RTItNDMyQy1COTk4LTU0NDMwMEZBQjcxMyIsIndvcmtTcGFjZU5hbWUiOiJWUjE4NTdSb2xsb3V0QWdlbnREZXZTcGFjZSIsIm5iZiI6MTc3MDg4NTYyNCwiZXhwIjoxODAyNDIxNjI0LCJpYXQiOjE3NzA4ODU2MjR9.HvO_kB6UNwcNSV4B_MXuh9OK54rYtRRDMPH5Y1EuOhc",
                'workspacename': "VR1857RolloutAgentDevSpace"
            },
            temperature=temperature,
            verbose=True,
            reasoning_effort=reasoning_effort,
            timeout=timeout if timeout is not None else self._DEFAULT_TIMEOUT_S,
            max_retries=(
                max_retries if max_retries is not None else self._DEFAULT_MAX_RETRIES
            ),
        )

    def get_llm(self):
        return self.llm

    def invoke(self, messages):
        return self.llm.invoke(messages)

    def stream(self, messages):
        return self.llm.stream(messages)

    async def ainvoke(self, messages):
        return await self.llm.ainvoke(messages)
