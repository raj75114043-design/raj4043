# GCL Service — LangChain tool for the KPI Analyst ReAct agent.
#
# When an Excel-loaded KPI matches strongly (search 2), the agent calls
# this tool to get a SQL query for trend analysis.
#

from __future__ import annotations

import requests
import toons
from loguru import logger
from pydantic import BaseModel, Field, SecretStr

GCL_API_URL = (
    "https://pm-copilot-macro-gcl-osdp-gsd-gsd-delivery-staging"
    ".aibi-americas-002.dyn.nesc.nokia.net/api/v1/dev/schema-world-view"
)

GCL_HEADERS = {
    "accept": "application/json",
    "Content-Type": "application/json",
}


class APIConfig(BaseModel):
    """Validated API authentication configuration."""

    username: str = Field(min_length=1, description="API username")
    password: SecretStr = Field(min_length=1, description="API password")

    @property
    def basic_auth(self) -> tuple[str, str]:
        """Return (username, password) tuple for requests auth parameter."""
        return (self.username, self.password.get_secret_value())


def call_gcl(kpi_name: str) -> str:
    """Call the GCL API to get a SQL world view for a KPI.

    Returns a TOONS string containing the SQL world view — tables, columns,
    and a base query for trend analysis. The output is injected directly into
    the agent's context.

    Args:
        kpi_name: The KPI name to look up.

    Returns:
        TOONS string with the SQL world view or an error message.
    """
    payload = {
        "kpi_names": [kpi_name],
        "question_texts": [""],
        "keyword_names": [""],
    }

    logger.info(f"[GCL] POST {GCL_API_URL} | payload={payload}")

    try:
        response = requests.post(
            GCL_API_URL,
            auth=APIConfig(username="escalation", password="pwc_macro_team").basic_auth,
            headers=GCL_HEADERS,
            json=payload,
            timeout=30,
        )
        response.raise_for_status()

        return toons.dumps(response.json())

    except requests.exceptions.HTTPError as exc:
        logger.error(f"[GCL] HTTP error: {exc} | response: {exc.response.text}")
        return toons.dumps(
            {
                "status": "error",
                "kpi_name": kpi_name,
                "message": f"HTTP {exc.response.status_code}: {exc.response.text}",
            }
        )

    except requests.exceptions.RequestException as exc:
        logger.error(f"[GCL] Request failed: {exc}")
        return toons.dumps(
            {
                "status": "error",
                "kpi_name": kpi_name,
                "message": (
                    f"GCL request failed: {exc}. "
                    "Fall back to Path A (pre-built SQL or output tables with kpi_id JOIN)."
                ),
            }
        )
