# KPI Search Service — LLM-based KPI matching.
#
# TWO data sources loaded at startup:
#   1. DB KPIs  — from tmo_macro_kpi_master_details table
#   2. Excel KPIs — from gcl_kpi.json
#
# KPI catalog built from both sources, pushed into LLM prompt for matching.
# No vector embeddings or ChromaDB required.
#
# Usage:
#     from services.kpi_search_service import (
#         load_db_kpis, load_excel_kpis_from_json,
#         build_kpi_catalog, get_kpi_metadata_rows,
#     )
#     load_db_kpis()                          # once at startup
#     load_excel_kpis_from_json()             # once at startup
#     catalog = build_kpi_catalog(vertical="NTM")

from __future__ import annotations

import json
from pathlib import Path
from services.db_service import _conn

from loguru import logger

# ── Paths ──
_BASE_DIR = Path(__file__).resolve().parent.parent

# ── Singletons — DB KPIs ──
_db_kpi_rows: list[dict] = []

# ── Singletons — Excel KPIs ──
_excel_kpi_rows: list[dict] = []

# ── Catalog cache ──
_kpi_catalog_cache: str | None = None


# ═══════════════════════════════════════════════════════════════════════
# Data loading — DB KPIs
# ═══════════════════════════════════════════════════════════════════════

def load_db_kpis(force: bool = False) -> int:
    """Load DB KPIs from tmo_macro_kpi_master_details into memory.

    Returns number of KPIs loaded.
    """
    global _db_kpi_rows, _kpi_catalog_cache

    if not force and _db_kpi_rows:
        return len(_db_kpi_rows)

    _db_kpi_rows = _load_kpis_from_db()
    _kpi_catalog_cache = None  # invalidate cache
    logger.info("KPIData | loaded {} DB KPIs", len(_db_kpi_rows))
    return len(_db_kpi_rows)


def _load_kpis_from_db() -> list[dict]:
    """Pull KPI metadata from the database."""
    sql = '''SELECT *
    FROM public.tmo_macro_kpi_master_details
    ORDER BY kpi_name'''
    try:
        with _conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql)
                columns = [desc[0] for desc in cur.description]
                rows = cur.fetchall()
        return [dict(zip(columns, row)) for row in rows]
    except Exception as e:
        logger.error("KPIData | DB load failed: {}", e)
        return []


# ═══════════════════════════════════════════════════════════════════════
# Data loading — Excel KPIs (from gcl_kpi.json)
# ═══════════════════════════════════════════════════════════════════════

def load_excel_kpis_from_json(force: bool = False) -> int:
    """Load Excel KPIs from gcl_kpi.json into memory.

    Returns number of KPIs loaded.
    """
    global _excel_kpi_rows, _kpi_catalog_cache

    if not force and _excel_kpi_rows:
        return len(_excel_kpi_rows)

    path = _BASE_DIR / "gcl_kpi.json"
    try:
        with open(path) as f:
            _excel_kpi_rows = json.load(f)
        _kpi_catalog_cache = None  # invalidate cache
        logger.info("KPIData | loaded {} Excel KPIs from {}", len(_excel_kpi_rows), path.name)
    except Exception as e:
        logger.error("KPIData | Excel load failed: {}", e)
        _excel_kpi_rows = []

    return len(_excel_kpi_rows)


# ═══════════════════════════════════════════════════════════════════════
# KPI catalog — compact text for LLM prompt injection
# ═══════════════════════════════════════════════════════════════════════

def build_kpi_catalog(vertical: str = "") -> str:
    """Build compact KPI catalog string for LLM matching.

    Format per line:
      [db:N] KPI Name | description (truncated) | cat:Category | vertical:Project
      [excel:N] KPI Name | description (truncated)

    Pre-filters by vertical when provided (only includes matching KPIs).
    Cached when no vertical filter applied.
    """
    global _kpi_catalog_cache

    if not vertical and _kpi_catalog_cache is not None:
        return _kpi_catalog_cache

    v_upper = vertical.strip().upper() if vertical else ""
    lines: list[str] = []

    for i, row in enumerate(_db_kpi_rows):
        name = row.get("kpi_name", "")
        if not name:
            continue
        proj = str(row.get("project_name", "")).strip()
        # Filter by vertical if provided and KPI has a project_name
        if v_upper and proj and v_upper not in proj.upper() and proj.upper() not in v_upper:
            continue
        desc = str(row.get("kpi_description", row.get("description", ""))).strip()[:100]
        cat = str(row.get("kpi_category", row.get("category", ""))).strip()
        lines.append(f"[db:{i}] {name} | {desc} | cat:{cat} | vertical:{proj}")

    for i, row in enumerate(_excel_kpi_rows):
        name = row.get("kpi_name", "")
        if not name:
            continue
        desc = str(row.get("description", "")).strip()[:100]
        lines.append(f"[excel:{i}] {name} | {desc}")

    catalog = "\n".join(lines)
    if not vertical:
        _kpi_catalog_cache = catalog
    return catalog


# ═══════════════════════════════════════════════════════════════════════
# Convenience accessors
# ═══════════════════════════════════════════════════════════════════════

def get_all_db_kpi_names() -> list[str]:
    """Return all DB KPI names."""
    return [r.get("kpi_name", "") for r in _db_kpi_rows if r.get("kpi_name")]


def get_all_excel_kpi_names() -> list[str]:
    """Return all Excel KPI names."""
    return [r.get("kpi_name", "") for r in _excel_kpi_rows if r.get("kpi_name")]


def get_all_kpi_names() -> list[str]:
    """Return all KPI names (DB + Excel, deduplicated)."""
    seen = set()
    names = []
    for r in _db_kpi_rows + _excel_kpi_rows:
        name = r.get("kpi_name", "")
        if name and name not in seen:
            seen.add(name)
            names.append(name)
    return names


def get_db_kpi_metadata_rows() -> list[dict]:
    """Return full DB KPI metadata rows."""
    return _db_kpi_rows


def get_excel_kpi_metadata_rows() -> list[dict]:
    """Return full Excel KPI metadata rows."""
    return _excel_kpi_rows


def get_kpi_metadata_rows() -> list[dict]:
    """Return all KPI metadata rows (DB + Excel)."""
    return _db_kpi_rows + _excel_kpi_rows


def refresh_db_kpis() -> int:
    """Force reload DB KPIs."""
    return load_db_kpis(force=True)


def refresh_excel_kpis() -> int:
    """Force reload Excel KPIs."""
    return load_excel_kpis_from_json(force=True)


# ═══════════════════════════════════════════════════════════════════════
# Backward compatibility — legacy API
# ═══════════════════════════════════════════════════════════════════════

def bootstrap_db_kpi_indexes(force: bool = False) -> int:
    """Legacy: load DB KPIs (no embedding)."""
    return load_db_kpis(force=force)


def restore_excel_indexes() -> int:
    """Legacy: load Excel KPIs from JSON."""
    return load_excel_kpis_from_json()


def bootstrap_excel_kpi_indexes(kpi_rows: list[dict], force: bool = False) -> int:
    """Legacy: load Excel KPIs from provided rows."""
    global _excel_kpi_rows, _kpi_catalog_cache
    if not force and _excel_kpi_rows:
        return len(_excel_kpi_rows)
    _excel_kpi_rows = kpi_rows
    _kpi_catalog_cache = None
    return len(_excel_kpi_rows)


def bootstrap_kpi_indexes(kpi_rows: list[dict] | None = None, force: bool = False) -> int:
    """Legacy: bootstrap either DB or Excel KPIs."""
    if kpi_rows is not None:
        return bootstrap_excel_kpi_indexes(kpi_rows, force=force)
    return load_db_kpis(force=force)


def hybrid_search(query: str, top_k: int = 10) -> list[dict]:
    """Legacy: no-op (vector search removed). Use search_and_match_kpis instead."""
    logger.warning("hybrid_search() called — vector search removed. Use search_and_match_kpis().")
    return []


def refresh_indexes() -> int:
    """Legacy: refresh DB KPIs."""
    return refresh_db_kpis()
