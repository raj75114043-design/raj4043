# Scenario Service — similarity search against the semantic_escalation table.

# Uses OpenAI embeddings + cosine similarity to find the best-matching
# escalation scenario for a given user query.
from __future__ import annotations

import math

import psycopg2
from langchain_openai import OpenAIEmbeddings
from loguru import logger

import config

_SCHEMA = "pwc_semantic_information_schema"
_TABLE = f"{_SCHEMA}.semantic_escalation"
_EMBEDDING_MODEL = "text-embedding-ada-002"

_COLUMNS = [
    "scenario_id",
    "escalation_type",
    "escalation_description",
    "probable_reasons",
    "recommended_resolution",
    "expected_agent_output",
    "draft_escalation_message_template",
    "relevent_kpi_s",
    "vertical",
]


def find_matching_scenario(query: str, top_k: int = 1) -> list[dict]:
    """
    Embed the query and perform cosine similarity search against the
    semantic_escalation table. Returns up to `top_k` matching scenarios
    sorted by similarity (descending).
    """
    client = OpenAIEmbeddings(
        api_key="NONE",
        base_url="https://llmgateway-qa-api.nokia.com/v1.2/",
        default_headers={
            "api-key": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyTmFtZSI6IlJvbGxvdXRBZ2VudERldlRvb2wiLCJPYmplY3RJRCI6IjNGRUY4NzI0LUE5RTItNDMyQy1COTk4LTU0NDMwMEZBQjcxMyIsIndvcmtTcGFjZU5hbWUiOiJWUjE4NTdSb2xsb3V0QWdlbnREZXZTcGFjZSIsIm5iZiI6MTc3MDg4NTYyNCwiZXhwIjoxODAyNDIxNjI0LCJpYXQiOjE3NzA4ODU2MjR9.HvO_kB6UNwcNSV4B_MXuh9OK54rYtRRDMPH5Y1EuOhc",
            "workspacename": "VR1857RolloutAgentDevSpace",
        },
        model="text-embedding-ada-002",
    )
    query_embedding = client.embed_query(query)

    # Compute the query-vector magnitude once; avoids recomputing per-row in SQL
    # and lets us short-circuit the query when the embedding is degenerate.
    query_norm = math.sqrt(sum(v * v for v in query_embedding))
    if not query_norm:
        logger.warning("scenario_service | query embedding has zero magnitude — returning []")
        return []

    rows: list = []
    conn = psycopg2.connect(
        host=config.PG_HOST,
        port=config.PG_PORT,
        database=config.PG_DATABASE,
        user=config.PG_USER,
        password=config.PG_PASSWORD,
    )
    try:
        with conn.cursor() as cur:
            # Cosine similarity: dot(a, b) / (|a| * |b|).
            # NULLIF on the row magnitude prevents divide-by-zero for any stored
            # zero-vector row; the query magnitude is computed in Python.
            col_list = ", ".join(_COLUMNS)
            sql = f"""
                SELECT {col_list},
                       (
                           SELECT SUM(a * b)
                           FROM UNNEST(embedding, %s::float8[]) AS t(a, b)
                       ) / NULLIF(
                           SQRT((SELECT SUM(a * a) FROM UNNEST(embedding) AS t(a))) * %s,
                           0
                       ) AS similarity_score
                FROM {_TABLE}
                WHERE embedding IS NOT NULL
                ORDER BY similarity_score DESC NULLS LAST
                LIMIT %s
            """
            cur.execute(sql, (query_embedding, query_norm, top_k))
            rows = cur.fetchall()
    except Exception as e:
        logger.error("scenario_service | similarity search failed: {}", e)
        return []
    finally:
        conn.close()

    results = []
    for row in rows:
        record = {}
        for i, col in enumerate(_COLUMNS):
            record[col] = row[i]
        record["similarity_score"] = row[len(_COLUMNS)]
        results.append(record)

    def _fmt(val, empty_label: str = "N/A", limit: int = 120) -> str:
        """Collapse list/None scenario values into a single-line preview."""
        if val is None or val == "" or val == []:
            return empty_label
        if isinstance(val, list):
            val = "; ".join(str(v).strip() for v in val if v)
        text = str(val).strip()
        return text[:limit] if text else empty_label

    if results:
        print(f"\n{'=' * 60}")
        print(f"  MATCHING ESCALATION SCENARIO(S): {len(results)} result(s)")
        print(f"{'=' * 60}")
        for i, r in enumerate(results, 1):
            kpi_label = _fmt(r.get("relevent_kpi_s"), empty_label="(none listed — will use gathered KPI)")
            print(f"\n  [{i}] Similarity: {r['similarity_score']:.4f}")
            print(f"      Type:        {_fmt(r.get('escalation_type'))}")
            print(f"      Description: {_fmt(r.get('escalation_description'))}")
            print(f"      Vertical:    {_fmt(r.get('vertical'))}")
            print(f"      Probable Reasons: {_fmt(r.get('probable_reasons'))}")
            print(f"      Resolution:  {_fmt(r.get('recommended_resolution'))}")
            print(f"      KPIs:        {kpi_label}")
        print(f"\n{'=' * 60}\n")
    else:
        print("\n  No matching escalation scenarios found.\n")

    logger.info(
        "Scenario search returned {} results (top similarity: {:.4f})",
        len(results),
        results[0]["similarity_score"] if results else 0.0,
    )
    return results
