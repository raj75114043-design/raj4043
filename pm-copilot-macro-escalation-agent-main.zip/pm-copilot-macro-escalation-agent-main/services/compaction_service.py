# Compaction Service — summarizes long assistant responses into compact
# summaries for conversation history context.
#
# The compacted summary is stored in the DB alongside the full response
# and fed to agents instead of the raw (often 2000+ word) response.
# This prevents LLM context overflow on multi-turn sessions.
from __future__ import annotations

from langchain_core.messages import SystemMessage, HumanMessage
from loguru import logger

from services.llm_provider import LLMProvider

_COMPACTION_SYSTEM = """\
You are a concise summarizer for a telecom escalation agent system.

Given an assistant response from an escalation investigation, produce a compact
summary that preserves:
- Key findings (specific numbers, percentages, vendor names, market/region)
- Escalation type and routing decision
- Action items or recommendations
- Any charts or visualizations mentioned

Rules:
- Maximum 3-4 sentences
- Keep all specific data points (numbers, dates, vendor names, KPI values)
- Drop formatting, markdown tables, headers, and verbose explanations
- Write in third person past tense ("Investigation found...", "Analysis showed...")
- If the response is a simple greeting or short answer, return it as-is
"""

# Responses shorter than this don't need compaction
_MIN_COMPACTION_LENGTH = 500


def compact_response(
        response: str,
        user_query: str = "",
        routing_decision: str = "",
) -> str:
    """Summarize a long assistant response into a compact form for history.

    Returns the original response unchanged if it's already short enough.
    Uses gpt-5-mini for fast, cheap summarization.
    """
    if not response or len(response) <= _MIN_COMPACTION_LENGTH:
        return response.strip() if response else ""

    try:
        provider = LLMProvider(model="gpt-5-mini", temperature=0.0)
        llm = provider.get_llm()

        user_content = f"User query: {user_query}\n\n" if user_query else ""
        if routing_decision:
            user_content += f"Route: {routing_decision}\n\n"
        user_content += f"Assistant response to summarize:\n{response}"

        result = llm.invoke([
            SystemMessage(content=_COMPACTION_SYSTEM),
            HumanMessage(content=user_content),
        ])

        compacted = result.content.strip()
        logger.debug(
            "Compacted response: {} chars -> {} chars",
            len(response), len(compacted),
        )
        return compacted

    except Exception as e:
        logger.warning("Compaction failed, falling back to truncation: {}", e)
        # Fallback: first 300 chars
        return response[:300] + "..." if len(response) > 300 else response
