# KPI Bootstrap & Search — schema bootstrap + LLM-based KPI matching.
#
# Extracted from agents/kpi_analyst.py to keep the agent focused on
# investigation (ReAct loop + report generation).
#
# LLM-based matching pipeline (replaces vector embeddings):
#   1. Load all KPIs (DB + Excel) into memory at startup
#   2. Build compact catalog → push into LLM prompt
#   3. LLM picks top 3 matching KPIs per query + vertical
#
# Decision logic (TWO paths):
#   DB match strong  → Path A: use DB KPIs (pre-built SQL or output tables)
#   Excel match strong → Path B: Excel KPIs → agent calls GCL → trend analysis
#   Both weak          → Path A fallback: use DB KPIs as best-effort
#
# Public API:
#   bootstrap_table_schemas()       — query information_schema, cache table catalogs
#   bootstrap_kpi_embeddings()      — load all KPI data into memory
#   search_and_match_kpis()         — LLM-based matching pipeline
#   format_matched_kpis()           — format results for system prompt
#   get_table_catalog()             — formatted table catalog string

from __future__ import annotations

import json
import re

from langchain_core.messages import SystemMessage, HumanMessage
from loguru import logger

from services.kpi_search_service import (
    load_db_kpis,
    load_excel_kpis_from_json,
    build_kpi_catalog,
    get_db_kpi_metadata_rows,
    get_excel_kpi_metadata_rows,
    refresh_db_kpis,
)
from services.llm_provider import LLMProvider

_MATCH_MODEL = "gpt-5-mini"
_MATCH_TEMP = 0.1

# Keep only the top-scoring KPIs before handing the catalog to the LLM.
# 186 KPIs × ~22 KB catalog → 50s latency with gpt-5. Pruning to the top
# ~40 lexical matches drops that to a few seconds without losing recall,
# because weak lexical matches never win the LLM reranker anyway.
_PREFILTER_TOP_DB = 25
_PREFILTER_TOP_EXCEL = 15
_PREFILTER_STOPWORDS = frozenset({
    "a", "an", "and", "are", "as", "at", "be", "but", "by", "for", "from",
    "has", "have", "in", "is", "it", "its", "not", "of", "on", "or", "so",
    "that", "the", "this", "to", "was", "what", "when", "where", "which",
    "who", "why", "will", "with", "you", "your", "we", "our", "i", "me",
    "my", "how", "can", "do", "does", "did", "please", "tell", "show",
    "need", "want",
})

# ─────────────────────────────────────────────────────────────────────
# Tables this agent knows about
# ─────────────────────────────────────────────────────────────────────

TABLES = [
    {"schema": "public", "table": "tmo_macro_kpi_master_details",
     "purpose": "KPI definitions — PK: id. Contains kpi_name, formulas, thresholds, units, categories. All output tables JOIN to this via kpi_id = id."},
    {"schema": "public", "table": "tmo_macro_kpi_market_gc_output_details_trial",
     "purpose": "GC-level KPI history per market — most granular. FK: kpi_id → master_details.id. JOIN to get kpi_name. Timestamp: result_date_time."},
    {"schema": "public", "table": "tmo_macro_kpi_market_output_details_trial",
     "purpose": "Market-level KPI history — aggregated across GCs. FK: kpi_id → master_details.id. JOIN to get kpi_name. Timestamp: result_date_time."},
    {"schema": "public", "table": "tmo_macro_kpi_region_output_details_trial",
     "purpose": "Region-level KPI history — aggregated across markets. FK: kpi_id → master_details.id. Filter by region_name. Timestamp: result_date_time."},
    {"schema": "public", "table": "tmo_macro_kpi_national_output_details_trial",
     "purpose": "National-level KPI history — top-level program view. FK: kpi_id → master_details.id. JOIN to get kpi_name. Timestamp: result_date_time."},
    {"schema": "public", "table": "tmo_macro_copilot_short_construction_complete_forecast",
     "purpose": "CxC (Construction Complete) short-range forecast. Dimensions: market, region, gc_company, forecast_date, target_date."},
    {"schema": "public", "table": "tmo_macro_copilot_short_construction_start_forecast",
     "purpose": "CxS (Construction Start) short-range forecast. Dimensions: market, region, gc_company, forecast_date, target_date."},
    {"schema": "public", "table": "gc_capacity_market_trial",
     "purpose": "GC daily capacity per market. day_wise_gc_capacity = sites/day. Weekly capacity = day_wise_gc_capacity * 5."},
]

# ─────────────────────────────────────────────────────────────────────
# Schema bootstrap
# ─────────────────────────────────────────────────────────────────────

_schema_cache: dict[str, list[dict]] | None = None

_TIMESTAMP_TYPES = {
    "timestamp without time zone", "timestamp with time zone",
    "timestamp", "timestamptz", "date",
}


def _get_sandbox():
    from tools.python_sandbox import PythonSandbox
    return PythonSandbox()


def detect_timestamp_columns(columns: list[dict]) -> list[str]:
    """Find columns that are timestamp/date types."""
    return [
        col["column_name"]
        for col in columns
        if col.get("data_type", "").lower() in _TIMESTAMP_TYPES
           or "date" in col.get("column_name", "").lower()
           or "period" in col.get("column_name", "").lower()
           or "timestamp" in col.get("column_name", "").lower()
    ]


def bootstrap_table_schemas() -> str:
    """Query information_schema for every table and build a complete catalog.

    This runs ONCE (cached), so the LLM starts with full column knowledge
    and never has to guess or discover schemas itself.

    Returns a formatted string ready to inject into the system prompt.
    """
    global _schema_cache

    if _schema_cache is not None:
        return _format_schema_cache(_schema_cache)

    sandbox = _get_sandbox()

    _schema_cache = {}

    for tbl in TABLES:
        schema = tbl["schema"]
        table = tbl["table"]
        fqn = f"{schema}.{table}"

        code = f"""
result = execute_query(\"\"\"
    SELECT column_name, data_type, is_nullable
    FROM information_schema.columns
    WHERE table_schema = '{schema}'
      AND table_name = '{table}'
    ORDER BY ordinal_position
\"\"\")
"""
        try:
            out = sandbox.execute(code, timeout_seconds=10)
            columns = out.get("result", [])
            if isinstance(columns, list) and columns:
                _schema_cache[fqn] = columns
                logger.info("Bootstrap | {} → {} columns", fqn, len(columns))
            else:
                _schema_cache[fqn] = []
                logger.warning("Bootstrap | {} → no columns found", fqn)
        except Exception as e:
            _schema_cache[fqn] = []
            logger.error("Bootstrap | {} → failed: {}", fqn, e)

    # Grab GC companies
    try:
        out = sandbox.execute("""
result = execute_query(\"\"\"
    SELECT DISTINCT gc_company
    FROM public.gc_capacity_market_trial
    ORDER BY gc_company
    LIMIT 50
\"\"\")
""", timeout_seconds=10)
        gcs = out.get("result", [])
        if isinstance(gcs, list) and gcs:
            _schema_cache["__gc_companies__"] = gcs
            logger.info("Bootstrap | discovered {} GC companies", len(gcs))
    except Exception as e:
        logger.warning("Bootstrap | GC company discovery failed: {}", e)

    # Grab clean market names
    try:
        out = sandbox.execute("""
result = execute_query(\"\"\"
    SELECT DISTINCT market
    FROM public.gc_capacity_market_trial
    WHERE market IS NOT NULL AND market != ''
    ORDER BY market
\"\"\")
""", timeout_seconds=10)
        markets = out.get("result", [])
        if isinstance(markets, list) and markets:
            _schema_cache["__markets__"] = [
                r for r in markets
                if isinstance(r.get("market"), str) and r["market"].strip()
            ]
            logger.info("Bootstrap | discovered {} markets", len(_schema_cache["__markets__"]))
    except Exception as e:
        logger.warning("Bootstrap | market discovery failed: {}", e)

    # Grab distinct regions
    try:
        out = sandbox.execute("""
result = execute_query(\"\"\"
    SELECT DISTINCT region_name
    FROM public.tmo_macro_kpi_region_output_details_trial
    WHERE region_name IS NOT NULL
      AND region_name IN ('WEST', 'SOUTH', 'CENTRAL')
    ORDER BY region_name
\"\"\")
""", timeout_seconds=10)
        regions = out.get("result", [])
        if isinstance(regions, list) and regions:
            _schema_cache["__regions__"] = regions
            logger.info("Bootstrap | discovered {} regions", len(regions))
    except Exception as e:
        logger.warning("Bootstrap | region discovery failed: {}", e)

    return _format_schema_cache(_schema_cache)


def _format_schema_cache(cache: dict[str, list[dict]]) -> str:
    """Format cached schemas into a readable catalog for the system prompt."""
    sections = []

    for tbl in TABLES:
        fqn = f"{tbl['schema']}.{tbl['table']}"
        columns = cache.get(fqn, [])
        purpose = tbl["purpose"]

        section = f"### `{fqn}`\n**Purpose**: {purpose}\n"

        if columns:
            section += f"**Columns** ({len(columns)}):\n"
            section += "| Column | Type | Nullable |\n|---|---|---|\n"
            for col in columns:
                name = col.get("column_name", "?")
                dtype = col.get("data_type", "?")
                nullable = col.get("is_nullable", "?")
                section += f"| `{name}` | {dtype} | {nullable} |\n"

            ts_cols = detect_timestamp_columns(columns)
            if ts_cols:
                section += (
                    f"\n**Latest record column(s)**: `{'`, `'.join(ts_cols)}`\n"
                    f"→ Filter with: `WHERE {ts_cols[0]} = "
                    f"(SELECT MAX({ts_cols[0]}) FROM {fqn})`\n"
                )
        else:
            section += "*Schema not available — use information_schema to discover columns.*\n"

        sections.append(section)

    # Known GC companies
    gcs = cache.get("__gc_companies__", [])
    if gcs:
        names = [r.get("gc_company", "") for r in gcs if r.get("gc_company")]
        if names:
            sections.append(
                f"### Known GC Companies ({len(names)} total)\n"
                f"`{'`, `'.join(names)}`\n"
            )

    # Known markets
    markets = cache.get("__markets__", [])
    if markets:
        names = sorted(set(
            r["market"].strip() for r in markets
            if isinstance(r.get("market"), str) and r["market"].strip()
        ))
        if names:
            sections.append(
                f"### Known Markets ({len(names)} total)\n"
                f"`{'`, `'.join(names)}`\n"
            )

    # Known regions
    regions = cache.get("__regions__", [])
    if regions:
        names = sorted(set(
            r["region_name"].strip() for r in regions
            if isinstance(r.get("region_name"), str) and r["region_name"].strip()
        ))
        if names:
            sections.append(
                f"### Known Regions ({len(names)} total)\n"
                f"`{'`, `'.join(names)}`\n"
                f"Filter by `region_name` column in output tables.\n"
            )

    return "\n".join(sections)


def get_table_catalog() -> str:
    """Return the formatted table catalog (bootstraps if needed)."""
    return bootstrap_table_schemas()


def is_schema_cache_warm() -> bool:
    """Check if schema cache has been bootstrapped (without triggering bootstrap)."""
    return _schema_cache is not None


def get_schema_cache() -> dict[str, list[dict]]:
    """Return raw schema cache. Bootstraps if needed."""
    if _schema_cache is None:
        bootstrap_table_schemas()
    return _schema_cache or {}


# ─────────────────────────────────────────────────────────────────────
# KPI index bootstrap
# ─────────────────────────────────────────────────────────────────────

def bootstrap_kpi_embeddings() -> int:
    """Load all KPI data into memory (DB + Excel). No vector embeddings.

    Returns total number of KPIs loaded.
    """
    db_count = load_db_kpis()
    excel_count = load_excel_kpis_from_json()
    # Pre-build the unfiltered catalog cache
    build_kpi_catalog()
    return db_count + excel_count


def refresh_kpi_embeddings() -> int:
    """Force reload DB KPIs. Call when KPI master data changes."""
    return refresh_db_kpis()


# ─────────────────────────────────────────────────────────────────────
# KPI search pipeline — dual search (DB + Excel)
# ─────────────────────────────────────────────────────────────────────

# Threshold for "strong" match (cosine distance — lower = better)
# Used by both kpi_bootstrap (dual-search decision) and kpi_analyst (HITL trigger).
KPI_SIMILARITY_THRESHOLD = 0.45

# ─────────────────────────────────────────────────────────────────────
# LLM-based KPI matching prompt
# ─────────────────────────────────────────────────────────────────────

_MATCH_SYSTEM_PROMPT = """You are a strict KPI matching engine for T-Mobile MACRO network operations.

Your job is to pick ONLY the KPIs that *directly* answer the user's query. You are
being explicitly told NOT to blindly pick 3 KPIs just because the RULES allow up
to 3. Picking an irrelevant KPI wastes the downstream agent's time and misleads
the PM — it is strictly worse than picking fewer KPIs.

Abbreviations:
- COP  = Close-out Package
- SCOP = Site Close-out Package

## CATALOG
{catalog}

## SELECTION RULES

1. **Pick 0–3 KPIs.** Zero is a valid answer. One is often the right answer.
   Only return 2–3 when each additional KPI genuinely adds a distinct angle
   (e.g. the query asks about a metric AND its underlying driver).

2. **Direct match required.** A KPI is a match only when its NAME or
   DESCRIPTION clearly measures the exact thing the user is asking about.
   Topic overlap ("both involve GCs", "both mention swap") is NOT enough.

3. **Confidence scale (be harsh):**
   - 0.90–1.00 — the KPI's definition is the user's question restated.
   - 0.70–0.89 — the KPI measures the user's topic with a slight scope mismatch.
   - 0.50–0.69 — adjacent / proxy metric; only include if the user has no
                 better option and the proxy is commonly used for this question.
   - < 0.50    — DO NOT INCLUDE. Leave it out.

4. **Minimum bar: 0.60.** Any KPI scored below 0.60 must be dropped from the
   output. If nothing passes 0.60, return an empty array `[]`.

5. **Vertical filter.** If a vertical is given, only pick KPIs whose
   `vertical` matches it. A strong KPI from the wrong vertical is still a
   wrong answer.

6. **Escalation-context hints.** When KPI hints are supplied, prefer them *if*
   they also pass rule 2 and rule 4. A hint that doesn't directly measure the
   user's question is not a free pass.

7. **No hallucinations.** `kpi_name` must be copied VERBATIM from the catalog.
   Do not rename, pluralise, abbreviate, or merge KPI names.

## REJECTION CHECKLIST (common traps — do NOT fall into these)

- Do not pick a KPI just because it shares a noun with the query.
- Do not pick "closest topic" when the real answer is "none of these fit".
- Do not pick a coarser KPI ("overall cycle time") when the user asked about
  a specific sub-metric ("swap cycle time").
- Do not pad to 3 results — **fewer is better than wrong.**
- Do not pick Excel-source KPIs unless DB-source KPIs cannot answer the
  question.

## REASON FIELD

`reason` must be 1 sentence that:
  (a) quotes the exact phrase from the query the KPI is matching, and
  (b) names the KPI concept being matched.

#### for excel KPIs all of the KPIs unless written AHLOA or NTM belong to both
Weak reason:  "Related to swap performance."
Strong reason: '"swap cycle time is trending up" → directly measured by Swap Cycle Time KPI.'

## OUTPUT

Return ONLY valid JSON array — no markdown fences, no prose, no explanation.
Return `[]` when nothing passes the 0.60 bar.

## RESPONSE FORMAT
[
  {{"ref": "[db:0]", "kpi_name": "Swap FTR", "confidence": 0.95, "reason": "\\"swap first-time-right\\" → directly measured by Swap FTR."}},
  {{"ref": "[excel:5]", "kpi_name": "Vendor Utilization", "confidence": 0.72, "reason": "\\"GC capacity usage\\" → Vendor Utilization measures GC capacity consumption."}}
]
"""


# ─────────────────────────────────────────────────────────────────────
# Lexical prefilter — prune the catalog before the LLM reranks it
# ─────────────────────────────────────────────────────────────────────

def _tokenize(text: str) -> set[str]:
    """Lowercase, split on non-alphanumerics, drop stopwords + 1-char tokens."""
    if not text:
        return set()
    toks = re.split(r"[^a-z0-9]+", text.lower())
    return {t for t in toks if len(t) > 1 and t not in _PREFILTER_STOPWORDS}


def _score_row(
        row: dict,
        query_tokens: set[str],
        hint_tokens: set[str],
        query_lower: str,
) -> float:
    """Token-overlap score for one KPI row. Hints count double, exact phrase bonus."""
    name = str(row.get("kpi_name", "")).strip()
    if not name:
        return -1.0
    desc = str(row.get("description") or row.get("kpi_description") or "")
    cat = str(row.get("kpi_category") or row.get("category") or "")
    name_tokens = _tokenize(name)
    doc_tokens = name_tokens | _tokenize(desc) | _tokenize(cat)

    score = 0.0
    score += 2.0 * len(query_tokens & name_tokens)  # name matches are strongest
    score += 1.0 * len(query_tokens & (doc_tokens - name_tokens))
    score += 3.0 * len(hint_tokens & name_tokens)  # escalation hints dominate
    score += 1.5 * len(hint_tokens & (doc_tokens - name_tokens))

    # Phrase bonus: exact KPI name substring appears in the query
    if len(name) >= 4 and name.lower() in query_lower:
        score += 5.0
    return score


def _build_prefiltered_catalog(
        query: str,
        hints_text: str,
        vertical: str,
) -> tuple[str, dict[str, int]]:
    """Return (catalog_str, counts_by_source). Indices [db:i] / [excel:i] are
    preserved so _convert_llm_matches can still look up the original row.
    """
    q_lower = (query or "").lower()
    q_tokens = _tokenize(query)
    h_tokens = _tokenize(hints_text)
    v_upper = vertical.strip().upper() if vertical else ""

    db_rows = get_db_kpi_metadata_rows()
    excel_rows = get_excel_kpi_metadata_rows()

    def _vertical_ok(proj: str) -> bool:
        if not v_upper or not proj:
            return True
        p = proj.upper()
        return v_upper in p or p in v_upper

    # Score DB rows (respect vertical filter)
    db_scored: list[tuple[float, int, dict]] = []
    for i, row in enumerate(db_rows):
        if not row.get("kpi_name"):
            continue
        proj = str(row.get("project_name", "")).strip()
        if not _vertical_ok(proj):
            continue
        db_scored.append((_score_row(row, q_tokens, h_tokens, q_lower), i, row))
    db_scored.sort(key=lambda t: t[0], reverse=True)
    db_keep = [(i, r) for s, i, r in db_scored[:_PREFILTER_TOP_DB] if s > 0] \
        or [(i, r) for s, i, r in db_scored[:_PREFILTER_TOP_DB]]

    # Score Excel rows (no vertical metadata on Excel rows, so skip the filter)
    excel_scored: list[tuple[float, int, dict]] = []
    for i, row in enumerate(excel_rows):
        if not row.get("kpi_name"):
            continue
        excel_scored.append((_score_row(row, q_tokens, h_tokens, q_lower), i, row))
    excel_scored.sort(key=lambda t: t[0], reverse=True)
    excel_keep = [(i, r) for s, i, r in excel_scored[:_PREFILTER_TOP_EXCEL] if s > 0]

    lines: list[str] = []
    for i, row in db_keep:
        name = row["kpi_name"]
        desc = str(row.get("kpi_description", row.get("description", ""))).strip()[:100]
        cat = str(row.get("kpi_category", row.get("category", ""))).strip()
        proj = str(row.get("project_name", "")).strip()
        lines.append(f"[db:{i}] {name} | {desc} | cat:{cat} | vertical:{proj}")
    for i, row in excel_keep:
        name = row["kpi_name"]
        desc = str(row.get("description", "")).strip()[:100]
        lines.append(f"[excel:{i}] {name} | {desc}")

    return "\n".join(lines), {"db": len(db_keep), "excel": len(excel_keep)}


def search_and_match_kpis(
        query: str,
        relevant_kpis_text: str = "",
        llm=None,
        vertical: str = "",
) -> list[dict]:
    """LLM-based KPI matching: pushes catalog to LLM, picks top 3.

    Decision logic (TWO paths):
        DB match strong  → Path A: use DB KPIs (pre-built SQL or output tables)
        Excel match strong → Path B: Excel KPIs → agent calls GCL tool → trend analysis
        Both weak          → Path A fallback: use DB results as best-effort

    Each result dict has an 'index' field ('db' or 'excel') to identify source.
    Excel results above threshold have 'needs_gcl' = True.

    Args:
        query: The user/escalation query.
        relevant_kpis_text: Dot-separated KPI hints from escalation context.
        llm: LLM for matching. Created internally if None.
        vertical: Escalation vertical (e.g. "NTM", "AHLOA") to filter results.

    Returns:
        Matched KPI dicts sorted by distance (best first).
    """
    if llm is None:
        llm = LLMProvider(
            model=_MATCH_MODEL, temperature=0.0, reasoning_effort="low",
        ).get_llm()

    # Lexical prefilter: prune ~186 KPIs down to ~40 before calling the LLM.
    # Preserves [db:i] / [excel:i] indices that _convert_llm_matches relies on.
    catalog, prefilter_counts = _build_prefiltered_catalog(
        query=query,
        hints_text=relevant_kpis_text,
        vertical=vertical,
    )
    if not catalog:
        logger.warning("LLMMatch | empty KPI catalog after prefilter")
        return []

    logger.info(
        "LLMMatch | prefilter kept db={} excel={} (from 86/100)",
        prefilter_counts["db"], prefilter_counts["excel"],
    )

    # Build user message
    user_parts = [f"Query: {query}"]
    if relevant_kpis_text and relevant_kpis_text.strip():
        user_parts.append(f"KPI hints from escalation context: {relevant_kpis_text}")
    if vertical and vertical.strip():
        user_parts.append(f"Vertical filter: {vertical}")
    user_msg = "\n".join(user_parts)

    system_msg = _MATCH_SYSTEM_PROMPT.format(catalog=catalog)

    try:
        response = llm.invoke([
            SystemMessage(content=system_msg),
            HumanMessage(content=user_msg),
        ])
        raw = response.content.strip()
        # Strip markdown fences if present
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[1].rsplit("```", 1)[0].strip()
        matches = json.loads(raw)
        if not isinstance(matches, list):
            logger.error("LLMMatch | expected list, got {}", type(matches).__name__)
            return []
    except Exception as e:
        logger.error("LLMMatch | LLM call or parse failed: {}", e)
        return []

    # Convert LLM response to canonical format
    results = _convert_llm_matches(matches)

    # Apply db/excel decision logic
    db_results = [r for r in results if r["index"] == "db"]
    excel_results = [r for r in results if r["index"] == "excel"]

    db_strong = db_results and db_results[0]["distance"] < KPI_SIMILARITY_THRESHOLD
    excel_strong = excel_results and excel_results[0]["distance"] < KPI_SIMILARITY_THRESHOLD

    def _fmt(bucket: list[dict], is_strong: bool) -> str:
        if not bucket:
            return "none"
        return f"best={bucket[0]['distance']:.4f}, {'STRONG' if is_strong else 'WEAK'}"

    logger.info(
        "LLMMatch | DB: {} results ({}) | Excel: {} results ({})",
        len(db_results), _fmt(db_results, db_strong),
        len(excel_results), _fmt(excel_results, excel_strong),
    )

    if db_strong:
        logger.info("LLMMatch | Decision: DB STRONG → using DB KPIs")
        return db_results

    if excel_strong:
        logger.info("LLMMatch | Decision: Excel STRONG → agent will use call_gcl tool")
        for r in excel_results:
            if r["distance"] < KPI_SIMILARITY_THRESHOLD:
                r["needs_gcl"] = True
        return [r for r in excel_results if r.get("needs_gcl")]

    logger.info("LLMMatch | Decision: BOTH WEAK → using DB KPIs (Path A fallback)")
    return db_results if db_results else results


def _convert_llm_matches(matches: list[dict]) -> list[dict]:
    """Convert LLM match response to the canonical KPI result format."""
    db_rows = get_db_kpi_metadata_rows()
    excel_rows = get_excel_kpi_metadata_rows()

    results = []
    for m in matches:
        ref = m.get("ref", "")
        confidence = float(m.get("confidence", 0))
        distance = round(1.0 - confidence, 4)
        kpi_name = m.get("kpi_name", "")

        # Parse ref to get source + index
        row: dict = {}
        index_tag = "db"
        try:
            if ref.startswith("[db:"):
                idx = int(ref.split(":")[1].rstrip("]"))
                if 0 <= idx < len(db_rows):
                    row = db_rows[idx]
                index_tag = "db"
            elif ref.startswith("[excel:"):
                idx = int(ref.split(":")[1].rstrip("]"))
                if 0 <= idx < len(excel_rows):
                    row = excel_rows[idx]
                index_tag = "excel"
            else:
                # Fallback: search by name
                row, index_tag = _find_row_by_name(kpi_name)
        except (ValueError, IndexError):
            row, index_tag = _find_row_by_name(kpi_name)

        if not row:
            logger.warning("LLMMatch | KPI '{}' (ref={}) not found in data", kpi_name, ref)
            continue

        metadata = {k: str(v) for k, v in row.items() if v is not None}

        results.append({
            "kpi_name": row.get("kpi_name", kpi_name),
            "distance": distance,
            "source": "llm",
            "index": index_tag,
            "metadata": metadata,
            "document": f"KPI: {kpi_name}",
        })

    results.sort(key=lambda r: r["distance"])
    return results


def _find_row_by_name(kpi_name: str) -> tuple[dict, str]:
    """Find a KPI row by name across DB and Excel sources."""
    name_lower = kpi_name.lower().strip()
    for row in get_db_kpi_metadata_rows():
        if row.get("kpi_name", "").lower().strip() == name_lower:
            return row, "db"
    for row in get_excel_kpi_metadata_rows():
        if row.get("kpi_name", "").lower().strip() == name_lower:
            return row, "excel"
    return {}, "db"


# ─────────────────────────────────────────────────────────────────────
# KPI result formatting (for system prompt injection)
# ─────────────────────────────────────────────────────────────────────

def get_tables_with_kpi_id() -> list[dict]:
    """Return tables from schema cache that have a kpi_id column."""
    cache = get_schema_cache()
    if not cache:
        return []

    result = []
    for tbl in TABLES:
        fqn = f"{tbl['schema']}.{tbl['table']}"
        columns = cache.get(fqn, [])
        col_names = [c.get("column_name", "") for c in columns]

        if "kpi_id" in col_names:
            ts_cols = detect_timestamp_columns(columns)
            result.append({
                "fqn": fqn,
                "purpose": tbl["purpose"],
                "timestamp_cols": ts_cols,
                "columns": col_names,
            })
    return result


def format_matched_kpis(matched: list[dict]) -> str:
    """Format matched KPIs into a readable section for the system prompt.

    Enriches each KPI with:
    - Metadata fields (category, unit, threshold, etc.)
    - Pre-built SQL query if available
    - Which tables contain this KPI + their timestamp columns
    """
    if not matched:
        return "*No KPIs matched from vector search.*"

    kpi_tables = get_tables_with_kpi_id()

    sections = []
    for m in matched:
        meta = m["metadata"]
        kpi_name = m["kpi_name"]
        dist = m["distance"]
        source = m.get("source", "")

        source_tag = f" [{source}]" if source else ""
        header = f"#### `{kpi_name}` (distance: {dist:.4f}{source_tag})"

        # Collect metadata fields
        meta_parts = []
        for key in ["kpi_category", "category", "kpi_unit", "unit",
                    "kpi_threshold", "threshold", "kpi_formula", "formula",
                    "kpi_description", "description"]:
            val = meta.get(key)
            if val and str(val).strip():
                meta_parts.append(f"- **{key}**: {val}")

        # Pre-built SQL queries by granularity level
        level_queries = {}
        for level in ["national", "region", "market", "market_with_gc", "area"]:
            sql = meta.get(level, "")
            if sql and str(sql).strip():
                level_queries[level] = str(sql).strip()

        sql_query = meta.get("sql_query", "")

        if level_queries:
            priority = ["market_with_gc", "market", "area", "region", "national"]
            shown = [lv for lv in priority if lv in level_queries][:3]
            available_not_shown = [lv for lv in level_queries if lv not in shown]

            meta_parts.append(
                "\n**Pre-built SQL queries by granularity level** "
                "(these query SOURCE tables directly — no kpi_id JOIN needed):"
            )
            for level in shown:
                label = level.replace("_", " ").title()
                meta_parts.append(f"\n**{label}**:\n```sql\n{level_queries[level]}\n```")
            if available_not_shown:
                meta_parts.append(
                    f"\n*Also available at: {', '.join(available_not_shown)} "
                    f"— adapt a shown query by changing GROUP BY.*"
                )
        elif sql_query and str(sql_query).strip():
            meta_parts.append(
                f"\n**Pre-built SQL query** (USE THIS FIRST — queries source tables directly, "
                f"no kpi_id JOIN needed):\n"
                f"```sql\n{sql_query.strip()}\n```"
            )

        # Project name (vertical)
        project = meta.get("project_name", "")
        if project and str(project).strip():
            meta_parts.append(f"- **project_name (vertical)**: {str(project).strip()}")

        # Available output tables + JOIN pattern
        if kpi_tables:
            table_hints = []
            for t in kpi_tables:
                ts_hint = ""
                if t["timestamp_cols"]:
                    tc = t["timestamp_cols"][0]
                    ts_hint = (
                        f"\n    Latest: `WHERE t1.{tc} >= "
                        f"(SELECT MAX({tc}) - INTERVAL '90 days' FROM {t['fqn']})`"
                    )
                table_hints.append(f"  - `{t['fqn']}`{ts_hint}")

            join_example = (
                    f"\n**JOIN pattern** (output tables have `kpi_id`, NOT `kpi_name`):\n"
                    f"```sql\n"
                    f"SELECT t1.*, t2.kpi_name\n"
                    f"FROM <output_table> AS t1\n"
                    f"JOIN public.tmo_macro_kpi_master_details AS t2\n"
                    f"  ON t1.kpi_id = t2.id\n"
                    f"WHERE t2.kpi_name = '{kpi_name.replace(chr(39), chr(39) * 2)}'\n"
                    f"```\n"
                    f"**Available output tables:**\n" + "\n".join(table_hints)
            )
            meta_parts.append(join_example)

        detail = "\n".join(meta_parts) if meta_parts else "- No additional metadata"
        sections.append(f"{header}\n{detail}")

    return "\n\n".join(sections)
