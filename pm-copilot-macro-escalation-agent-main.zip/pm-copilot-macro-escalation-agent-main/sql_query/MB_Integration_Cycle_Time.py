MB_Integration_Cycle_Time = '''

## Q1 — National MB Integration Cycle Time (6-month window)

```sql
-- National MB Integration Cycle Time: 6-month window
WITH integ_cycle AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id, smp_id, smp_name,
    pj_a_5270_integration_start_finish::date     AS integ_start_date,
    pj_a_5275_integration_complete_finish::date  AS integ_complete_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  -- LEFT JOIN pm_tracker pm ON pm.project_id = pj_project_id   -- optional enrichment
  WHERE pj_a_5270_integration_start_finish    IS NOT NULL
    AND pj_a_5275_integration_complete_finish IS NOT NULL
),
integ_windowed AS (
  SELECT *, (integ_complete_date - integ_start_date) AS cycle_days
  FROM integ_cycle
  WHERE integ_complete_date >= CURRENT_DATE - INTERVAL '6 months'
)
SELECT
  COUNT(*)                                                          AS projects_count,
  COUNT(*) FILTER (WHERE cycle_days < 0)                            AS data_quality_flag_negative,
  ROUND(AVG(cycle_days) FILTER (WHERE cycle_days >= 0)::numeric, 2) AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days)
    FILTER (WHERE cycle_days >= 0)                                  AS median_cycle_days,
  MIN(cycle_days) FILTER (WHERE cycle_days >= 0)                    AS min_cycle_days,
  MAX(cycle_days) FILTER (WHERE cycle_days >= 0)                    AS max_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycle_days)
    FILTER (WHERE cycle_days >= 0)                                  AS p90_cycle_days
FROM integ_windowed;
```

## Q2 — Region MB Integration Cycle Time (4-month window)

```sql
-- Region-level MB Integration Cycle Time: 4-month window
WITH integ_cycle AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id, smp_id, smp_name,
    pj_a_5270_integration_start_finish::date     AS integ_start_date,
    pj_a_5275_integration_complete_finish::date  AS integ_complete_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE pj_a_5270_integration_start_finish    IS NOT NULL
    AND pj_a_5275_integration_complete_finish IS NOT NULL
    AND rgn_region IS NOT NULL
    -- AND rgn_region = :region
),
integ_windowed AS (
  SELECT *, (integ_complete_date - integ_start_date) AS cycle_days
  FROM integ_cycle
  WHERE integ_complete_date >= CURRENT_DATE - INTERVAL '4 months'
)
SELECT
  rgn_region AS region,
  COUNT(*) AS projects_count,
  COUNT(*) FILTER (WHERE cycle_days < 0) AS data_quality_flag_negative,
  ROUND(AVG(cycle_days) FILTER (WHERE cycle_days >= 0)::numeric, 2) AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days) FILTER (WHERE cycle_days >= 0) AS median_cycle_days,
  MIN(cycle_days) FILTER (WHERE cycle_days >= 0) AS min_cycle_days,
  MAX(cycle_days) FILTER (WHERE cycle_days >= 0) AS max_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycle_days) FILTER (WHERE cycle_days >= 0) AS p90_cycle_days
FROM integ_windowed
GROUP BY rgn_region
ORDER BY avg_cycle_days DESC NULLS LAST;
```

## Q3 — Market MB Integration Cycle Time (4-month window)

```sql
-- Market-level MB Integration Cycle Time: 4-month window
WITH integ_cycle AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id, smp_id, smp_name,
    pj_a_5270_integration_start_finish::date     AS integ_start_date,
    pj_a_5275_integration_complete_finish::date  AS integ_complete_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE pj_a_5270_integration_start_finish    IS NOT NULL
    AND pj_a_5275_integration_complete_finish IS NOT NULL
    AND m_market IS NOT NULL
    -- AND rgn_region = :region
    -- AND m_market   = :market
),
integ_windowed AS (
  SELECT *, (integ_complete_date - integ_start_date) AS cycle_days
  FROM integ_cycle
  WHERE integ_complete_date >= CURRENT_DATE - INTERVAL '4 months'
)
SELECT
  rgn_region AS region, m_area AS area, m_market AS market,
  COUNT(*) AS projects_count,
  COUNT(*) FILTER (WHERE cycle_days < 0) AS data_quality_flag_negative,
  ROUND(AVG(cycle_days) FILTER (WHERE cycle_days >= 0)::numeric, 2) AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days) FILTER (WHERE cycle_days >= 0) AS median_cycle_days,
  MIN(cycle_days) FILTER (WHERE cycle_days >= 0) AS min_cycle_days,
  MAX(cycle_days) FILTER (WHERE cycle_days >= 0) AS max_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycle_days) FILTER (WHERE cycle_days >= 0) AS p90_cycle_days
FROM integ_windowed
GROUP BY rgn_region, m_area, m_market
ORDER BY avg_cycle_days DESC NULLS LAST;
```

## Q4 — GC / Vendor MB Integration Cycle Time (4-month window)

```sql
-- GC / Vendor-level MB Integration Cycle Time: 4-month window
WITH integ_cycle AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id, smp_id, smp_name,
    pj_a_5270_integration_start_finish::date     AS integ_start_date,
    pj_a_5275_integration_complete_finish::date  AS integ_complete_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE pj_a_5270_integration_start_finish    IS NOT NULL
    AND pj_a_5275_integration_complete_finish IS NOT NULL
    AND construction_gc IS NOT NULL
    AND m_market        IS NOT NULL
    -- AND rgn_region      = :region
    -- AND m_market        = :market
    -- AND construction_gc = :gc
),
integ_windowed AS (
  SELECT *, (integ_complete_date - integ_start_date) AS cycle_days
  FROM integ_cycle
  WHERE integ_complete_date >= CURRENT_DATE - INTERVAL '4 months'
)
SELECT
  m_market AS market, construction_gc AS gc,
  COUNT(*) AS projects_count,
  COUNT(*) FILTER (WHERE cycle_days < 0) AS data_quality_flag_negative,
  ROUND(AVG(cycle_days) FILTER (WHERE cycle_days >= 0)::numeric, 2) AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days) FILTER (WHERE cycle_days >= 0) AS median_cycle_days,
  MIN(cycle_days) FILTER (WHERE cycle_days >= 0) AS min_cycle_days,
  MAX(cycle_days) FILTER (WHERE cycle_days >= 0) AS max_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycle_days) FILTER (WHERE cycle_days >= 0) AS p90_cycle_days
FROM integ_windowed
GROUP BY m_market, construction_gc
ORDER BY avg_cycle_days DESC NULLS LAST;
```
'''