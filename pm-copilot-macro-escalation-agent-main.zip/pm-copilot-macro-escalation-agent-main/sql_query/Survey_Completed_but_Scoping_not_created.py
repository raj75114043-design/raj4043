Survey_Completed_but_Scoping_not_created='''
## Q1 — National: Survey Completed but Scoping not Created (6-month window)

```sql
-- National: Survey Completed but Scoping not Created (NTM Active) — 6-month window
WITH survey_no_scoping AS (
  SELECT
    rgn_region,
    m_area,
    m_market,
    construction_gc,
    pj_project_id,
    s_site_id,
    ms_1310_pre_construction_package_received_actual,
    ms_1316_pre_con_site_walk_completed_actual,
    ms_1321_talon_view_drone_svcs_actual,
    GREATEST(
      ms_1316_pre_con_site_walk_completed_actual::date,
      ms_1321_talon_view_drone_svcs_actual::date
    ) AS survey_complete_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name    = 'NTM'
    AND smp_status  = 'Active'
    AND ntm_project_type NOT IN ('E2E06 - NSD Cx Mgmt','E2E07 - OL/MOD Cx Mgmt')
    AND ms_1331_scoping_package_submitted_actual            IS NULL
    AND ms_1310_pre_construction_package_received_actual    IS NOT NULL
    AND (
          ms_1316_pre_con_site_walk_completed_actual IS NOT NULL
       OR ms_1321_talon_view_drone_svcs_actual       IS NOT NULL
        )
    AND GREATEST(
          ms_1316_pre_con_site_walk_completed_actual::date,
          ms_1321_talon_view_drone_svcs_actual::date
        ) >= CURRENT_DATE - INTERVAL '6 months'
)
SELECT
  COUNT(DISTINCT pj_project_id)                                       AS backlog_projects,
  COUNT(DISTINCT s_site_id)                                           AS backlog_sites,
  COUNT(*)                                                            AS backlog_records,
  ROUND(AVG(CURRENT_DATE - survey_complete_date)::numeric, 1)         AS avg_aging_days,
  MAX(CURRENT_DATE - survey_complete_date)                            AS max_aging_days
FROM survey_no_scoping;
```

## Q2 — Region: Survey Completed but Scoping not Created (4-month window)

```sql
-- Region-level: Survey Completed but Scoping not Created — 4-month window
WITH survey_no_scoping AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    GREATEST(
      ms_1316_pre_con_site_walk_completed_actual::date,
      ms_1321_talon_view_drone_svcs_actual::date
    ) AS survey_complete_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name    = 'NTM'
    AND smp_status  = 'Active'
    AND ntm_project_type NOT IN ('E2E06 - NSD Cx Mgmt','E2E07 - OL/MOD Cx Mgmt')
    AND ms_1331_scoping_package_submitted_actual            IS NULL
    AND ms_1310_pre_construction_package_received_actual    IS NOT NULL
    AND (
          ms_1316_pre_con_site_walk_completed_actual IS NOT NULL
       OR ms_1321_talon_view_drone_svcs_actual       IS NOT NULL
        )
    AND GREATEST(
          ms_1316_pre_con_site_walk_completed_actual::date,
          ms_1321_talon_view_drone_svcs_actual::date
        ) >= CURRENT_DATE - INTERVAL '4 months'
    AND rgn_region IS NOT NULL
    -- AND rgn_region = :region   -- uncomment when region is the entry point
)
SELECT
  rgn_region                                                          AS region,
  COUNT(DISTINCT pj_project_id)                                       AS backlog_projects,
  COUNT(DISTINCT s_site_id)                                           AS backlog_sites,
  COUNT(*)                                                            AS backlog_records,
  ROUND(AVG(CURRENT_DATE - survey_complete_date)::numeric, 1)         AS avg_aging_days,
  MAX(CURRENT_DATE - survey_complete_date)                            AS max_aging_days
FROM survey_no_scoping
GROUP BY rgn_region
ORDER BY backlog_projects DESC NULLS LAST;
```

## Q3 — Market: Survey Completed but Scoping not Created (4-month window)

```sql
-- Market-level: Survey Completed but Scoping not Created — 4-month window
WITH survey_no_scoping AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    GREATEST(
      ms_1316_pre_con_site_walk_completed_actual::date,
      ms_1321_talon_view_drone_svcs_actual::date
    ) AS survey_complete_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name    = 'NTM'
    AND smp_status  = 'Active'
    AND ntm_project_type NOT IN ('E2E06 - NSD Cx Mgmt','E2E07 - OL/MOD Cx Mgmt')
    AND ms_1331_scoping_package_submitted_actual            IS NULL
    AND ms_1310_pre_construction_package_received_actual    IS NOT NULL
    AND (
          ms_1316_pre_con_site_walk_completed_actual IS NOT NULL
       OR ms_1321_talon_view_drone_svcs_actual       IS NOT NULL
        )
    AND GREATEST(
          ms_1316_pre_con_site_walk_completed_actual::date,
          ms_1321_talon_view_drone_svcs_actual::date
        ) >= CURRENT_DATE - INTERVAL '4 months'
    AND m_market IS NOT NULL
    -- AND rgn_region = :region   -- when drilling from Region
    -- AND m_market   = :market   -- when market is the entry point
)
SELECT
  rgn_region                                                          AS region,
  m_area                                                              AS area,
  m_market                                                            AS market,
  COUNT(DISTINCT pj_project_id)                                       AS backlog_projects,
  COUNT(DISTINCT s_site_id)                                           AS backlog_sites,
  COUNT(*)                                                            AS backlog_records,
  ROUND(AVG(CURRENT_DATE - survey_complete_date)::numeric, 1)         AS avg_aging_days,
  MAX(CURRENT_DATE - survey_complete_date)                            AS max_aging_days
FROM survey_no_scoping
GROUP BY rgn_region, m_area, m_market
ORDER BY backlog_projects DESC NULLS LAST;
```

## Q4 — GC / Vendor: Survey Completed but Scoping not Created (4-month window)

```sql
-- GC / Vendor-level: Survey Completed but Scoping not Created — 4-month window
WITH survey_no_scoping AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    GREATEST(
      ms_1316_pre_con_site_walk_completed_actual::date,
      ms_1321_talon_view_drone_svcs_actual::date
    ) AS survey_complete_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name    = 'NTM'
    AND smp_status  = 'Active'
    AND ntm_project_type NOT IN ('E2E06 - NSD Cx Mgmt','E2E07 - OL/MOD Cx Mgmt')
    AND ms_1331_scoping_package_submitted_actual            IS NULL
    AND ms_1310_pre_construction_package_received_actual    IS NOT NULL
    AND (
          ms_1316_pre_con_site_walk_completed_actual IS NOT NULL
       OR ms_1321_talon_view_drone_svcs_actual       IS NOT NULL
        )
    AND GREATEST(
          ms_1316_pre_con_site_walk_completed_actual::date,
          ms_1321_talon_view_drone_svcs_actual::date
        ) >= CURRENT_DATE - INTERVAL '4 months'
    AND construction_gc IS NOT NULL
    AND m_market        IS NOT NULL
    -- AND rgn_region      = :region   -- when drilling from Region
    -- AND m_market        = :market   -- when drilling from Market
    -- AND construction_gc = :gc       -- when GC is the entry point
)
SELECT
  m_market                                                            AS market,
  construction_gc                                                     AS gc,
  COUNT(DISTINCT pj_project_id)                                       AS backlog_projects,
  COUNT(DISTINCT s_site_id)                                           AS backlog_sites,
  COUNT(*)                                                            AS backlog_records,
  ROUND(AVG(CURRENT_DATE - survey_complete_date)::numeric, 1)         AS avg_aging_days,
  MAX(CURRENT_DATE - survey_complete_date)                            AS max_aging_days
FROM survey_no_scoping
GROUP BY m_market, construction_gc
ORDER BY backlog_projects DESC NULLS LAST;
```

'''