L2_Compliance_Count = '''

## Q1 — National L2 Compliance Count (6-month window)

```sql
-- National L2 Compliance Count: 6-month window
SELECT
  COUNT(DISTINCT smp_id) FILTER (
    WHERE LOWER(TRIM(level_2_status)) = 'resolved'
  )                                                                   AS l2_resolved_sites,
  COUNT(DISTINCT smp_id)                                              AS total_sites,
  ROUND(
    100.0 * COUNT(DISTINCT smp_id) FILTER (
      WHERE LOWER(TRIM(level_2_status)) = 'resolved'
    )
    / NULLIF(COUNT(DISTINCT smp_id), 0),
    2
  )                                                                   AS l2_compliance_pct
FROM pwc_macro_staging_schema.stg_tmo_hse_daily_tracker_v0_1
WHERE review_date IS NOT NULL
  AND review_date::date >= CURRENT_DATE - INTERVAL '6 months'
  AND smp_id IS NOT NULL
  -- AND smp_name = :smp_name   -- e.g. 'AHLOB Modernization'
;
```

## Q2 — Region L2 Compliance Count (4-month window)

```sql
-- Region-level L2 Compliance Count: 4-month window
SELECT
  region                                                              AS region,
  COUNT(DISTINCT smp_id) FILTER (
    WHERE LOWER(TRIM(level_2_status)) = 'resolved'
  )                                                                   AS l2_resolved_sites,
  COUNT(DISTINCT smp_id)                                              AS total_sites,
  ROUND(
    100.0 * COUNT(DISTINCT smp_id) FILTER (
      WHERE LOWER(TRIM(level_2_status)) = 'resolved'
    )
    / NULLIF(COUNT(DISTINCT smp_id), 0),
    2
  )                                                                   AS l2_compliance_pct
FROM pwc_macro_staging_schema.stg_tmo_hse_daily_tracker_v0_1
WHERE review_date IS NOT NULL
  AND review_date::date >= CURRENT_DATE - INTERVAL '4 months'
  AND smp_id IS NOT NULL
  AND region IS NOT NULL
  -- AND region   = :region
  -- AND smp_name = :smp_name
GROUP BY region
ORDER BY l2_resolved_sites DESC NULLS LAST;
```

## Q3 — Market L2 Compliance Count (4-month window)

```sql
-- Market-level L2 Compliance Count: 4-month window
SELECT
  region                                                              AS region,
  market                                                              AS market,
  COUNT(DISTINCT smp_id) FILTER (
    WHERE LOWER(TRIM(level_2_status)) = 'resolved'
  )                                                                   AS l2_resolved_sites,
  COUNT(DISTINCT smp_id)                                              AS total_sites,
  ROUND(
    100.0 * COUNT(DISTINCT smp_id) FILTER (
      WHERE LOWER(TRIM(level_2_status)) = 'resolved'
    )
    / NULLIF(COUNT(DISTINCT smp_id), 0),
    2
  )                                                                   AS l2_compliance_pct
FROM pwc_macro_staging_schema.stg_tmo_hse_daily_tracker_v0_1
WHERE review_date IS NOT NULL
  AND review_date::date >= CURRENT_DATE - INTERVAL '4 months'
  AND smp_id IS NOT NULL
  AND market IS NOT NULL
  -- AND region   = :region
  -- AND market   = :market
  -- AND smp_name = :smp_name
GROUP BY region, market
ORDER BY l2_resolved_sites DESC NULLS LAST;
```

## Q4 — GC / Vendor L2 Compliance Count (4-month window)

```sql
-- GC / Vendor-level L2 Compliance Count: 4-month window
SELECT
  market                                                              AS market,
  gc_name                                                             AS gc,
  COUNT(DISTINCT smp_id) FILTER (
    WHERE LOWER(TRIM(level_2_status)) = 'resolved'
  )                                                                   AS l2_resolved_sites,
  COUNT(DISTINCT smp_id)                                              AS total_sites,
  ROUND(
    100.0 * COUNT(DISTINCT smp_id) FILTER (
      WHERE LOWER(TRIM(level_2_status)) = 'resolved'
    )
    / NULLIF(COUNT(DISTINCT smp_id), 0),
    2
  )                                                                   AS l2_compliance_pct
FROM pwc_macro_staging_schema.stg_tmo_hse_daily_tracker_v0_1
WHERE review_date IS NOT NULL
  AND review_date::date >= CURRENT_DATE - INTERVAL '4 months'
  AND smp_id  IS NOT NULL
  AND gc_name IS NOT NULL
  AND market  IS NOT NULL
  -- AND region   = :region
  -- AND market   = :market
  -- AND gc_name  = :gc
  -- AND smp_name = :smp_name
GROUP BY market, gc_name
ORDER BY l2_resolved_sites DESC NULLS LAST;
```
'''