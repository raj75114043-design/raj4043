NDPd_Cycle_Time_CPO_received_to_Cx_Start = '''
## Q1 — National (all CPO candidates)

```sql
-- National NDPd Cycle Time: all CPO candidates side-by-side, 6-month window
WITH cycle_base AS (
  SELECT
    ms_15500_gc_construction_start_actual::date           AS cx_start_date,
    base_cpo_received::date                               AS cpo_base,
    ms_1506_rfds_generation_service_actual::date          AS cpo_ms_1506_rfds,
    ms_1507_tower_ntp_approved_actual::date               AS cpo_ms_1507_ntp_approved,
    ms_1406_tower_ntp_received_actual::date               AS cpo_ms_1406_ntp_received,
    construction_gc_assigned_date::date                   AS cpo_gc_assigned,
    confirm_receipt_of_base_pos_and_spos_generated::date  AS cpo_confirm_base_pos
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE ms_15500_gc_construction_start_actual IS NOT NULL
    AND ms_15500_gc_construction_start_actual::date
        >= CURRENT_DATE - INTERVAL '6 months'
),
per_candidate AS (
  SELECT 'base_cpo_received'                               AS cpo_source,
         cx_start_date, cpo_base AS cpo_date
  FROM cycle_base WHERE cpo_base IS NOT NULL AND cx_start_date >= cpo_base
  UNION ALL
  SELECT 'ms_1506_rfds_generation_service_actual',
         cx_start_date, cpo_ms_1506_rfds
  FROM cycle_base WHERE cpo_ms_1506_rfds IS NOT NULL AND cx_start_date >= cpo_ms_1506_rfds
  UNION ALL
  SELECT 'ms_1507_tower_ntp_approved_actual',
         cx_start_date, cpo_ms_1507_ntp_approved
  FROM cycle_base WHERE cpo_ms_1507_ntp_approved IS NOT NULL AND cx_start_date >= cpo_ms_1507_ntp_approved
  UNION ALL
  SELECT 'ms_1406_tower_ntp_received_actual',
         cx_start_date, cpo_ms_1406_ntp_received
  FROM cycle_base WHERE cpo_ms_1406_ntp_received IS NOT NULL AND cx_start_date >= cpo_ms_1406_ntp_received
  UNION ALL
  SELECT 'construction_gc_assigned_date',
         cx_start_date, cpo_gc_assigned
  FROM cycle_base WHERE cpo_gc_assigned IS NOT NULL AND cx_start_date >= cpo_gc_assigned
  UNION ALL
  SELECT 'confirm_receipt_of_base_pos_and_spos_generated',
         cx_start_date, cpo_confirm_base_pos
  FROM cycle_base WHERE cpo_confirm_base_pos IS NOT NULL AND cx_start_date >= cpo_confirm_base_pos
)
SELECT
  cpo_source,
  COUNT(*)                                                              AS sample_size,
  ROUND(AVG(cx_start_date - cpo_date)::numeric, 2)                      AS avg_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cx_start_date - cpo_date)::numeric  AS median_days,
  MIN(cx_start_date - cpo_date)                                         AS min_days,
  MAX(cx_start_date - cpo_date)                                         AS max_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cx_start_date - cpo_date)::numeric  AS p90_days
FROM per_candidate
GROUP BY cpo_source
ORDER BY sample_size DESC;
```

## Q2 — Region (all CPO candidates)

```sql
-- Region-level NDPd Cycle Time: all CPO candidates, 4-month window
WITH cycle_base AS (
  SELECT
    rgn_region,
    ms_15500_gc_construction_start_actual::date           AS cx_start_date,
    base_cpo_received::date                               AS cpo_base,
    ms_1506_rfds_generation_service_actual::date          AS cpo_ms_1506_rfds,
    ms_1507_tower_ntp_approved_actual::date               AS cpo_ms_1507_ntp_approved,
    ms_1406_tower_ntp_received_actual::date               AS cpo_ms_1406_ntp_received,
    construction_gc_assigned_date::date                   AS cpo_gc_assigned,
    confirm_receipt_of_base_pos_and_spos_generated::date  AS cpo_confirm_base_pos
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE ms_15500_gc_construction_start_actual IS NOT NULL
    AND ms_15500_gc_construction_start_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND rgn_region IS NOT NULL
    -- AND rgn_region = :region
),
per_candidate AS (
  SELECT 'base_cpo_received' AS cpo_source, rgn_region, cx_start_date, cpo_base AS cpo_date
  FROM cycle_base WHERE cpo_base IS NOT NULL AND cx_start_date >= cpo_base
  UNION ALL
  SELECT 'ms_1506_rfds_generation_service_actual', rgn_region, cx_start_date, cpo_ms_1506_rfds
  FROM cycle_base WHERE cpo_ms_1506_rfds IS NOT NULL AND cx_start_date >= cpo_ms_1506_rfds
  UNION ALL
  SELECT 'ms_1507_tower_ntp_approved_actual', rgn_region, cx_start_date, cpo_ms_1507_ntp_approved
  FROM cycle_base WHERE cpo_ms_1507_ntp_approved IS NOT NULL AND cx_start_date >= cpo_ms_1507_ntp_approved
  UNION ALL
  SELECT 'ms_1406_tower_ntp_received_actual', rgn_region, cx_start_date, cpo_ms_1406_ntp_received
  FROM cycle_base WHERE cpo_ms_1406_ntp_received IS NOT NULL AND cx_start_date >= cpo_ms_1406_ntp_received
  UNION ALL
  SELECT 'construction_gc_assigned_date', rgn_region, cx_start_date, cpo_gc_assigned
  FROM cycle_base WHERE cpo_gc_assigned IS NOT NULL AND cx_start_date >= cpo_gc_assigned
  UNION ALL
  SELECT 'confirm_receipt_of_base_pos_and_spos_generated', rgn_region, cx_start_date, cpo_confirm_base_pos
  FROM cycle_base WHERE cpo_confirm_base_pos IS NOT NULL AND cx_start_date >= cpo_confirm_base_pos
)
SELECT
  cpo_source,
  rgn_region                                                            AS region,
  COUNT(*)                                                              AS sample_size,
  ROUND(AVG(cx_start_date - cpo_date)::numeric, 2)                      AS avg_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cx_start_date - cpo_date)::numeric  AS median_days,
  MIN(cx_start_date - cpo_date)                                         AS min_days,
  MAX(cx_start_date - cpo_date)                                         AS max_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cx_start_date - cpo_date)::numeric  AS p90_days
FROM per_candidate
GROUP BY cpo_source, rgn_region
ORDER BY cpo_source, avg_days DESC NULLS LAST;
```

## Q3 — Market (all CPO candidates)

```sql
-- Market-level NDPd Cycle Time: all CPO candidates, 4-month window
WITH cycle_base AS (
  SELECT
    rgn_region, m_area, m_market,
    ms_15500_gc_construction_start_actual::date           AS cx_start_date,
    base_cpo_received::date                               AS cpo_base,
    ms_1506_rfds_generation_service_actual::date          AS cpo_ms_1506_rfds,
    ms_1507_tower_ntp_approved_actual::date               AS cpo_ms_1507_ntp_approved,
    ms_1406_tower_ntp_received_actual::date               AS cpo_ms_1406_ntp_received,
    construction_gc_assigned_date::date                   AS cpo_gc_assigned,
    confirm_receipt_of_base_pos_and_spos_generated::date  AS cpo_confirm_base_pos
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE ms_15500_gc_construction_start_actual IS NOT NULL
    AND ms_15500_gc_construction_start_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m_market IS NOT NULL
    -- AND rgn_region = :region
    -- AND m_market   = :market
),
per_candidate AS (
  SELECT 'base_cpo_received' AS cpo_source, rgn_region, m_area, m_market, cx_start_date, cpo_base AS cpo_date
  FROM cycle_base WHERE cpo_base IS NOT NULL AND cx_start_date >= cpo_base
  UNION ALL
  SELECT 'ms_1506_rfds_generation_service_actual', rgn_region, m_area, m_market, cx_start_date, cpo_ms_1506_rfds
  FROM cycle_base WHERE cpo_ms_1506_rfds IS NOT NULL AND cx_start_date >= cpo_ms_1506_rfds
  UNION ALL
  SELECT 'ms_1507_tower_ntp_approved_actual', rgn_region, m_area, m_market, cx_start_date, cpo_ms_1507_ntp_approved
  FROM cycle_base WHERE cpo_ms_1507_ntp_approved IS NOT NULL AND cx_start_date >= cpo_ms_1507_ntp_approved
  UNION ALL
  SELECT 'ms_1406_tower_ntp_received_actual', rgn_region, m_area, m_market, cx_start_date, cpo_ms_1406_ntp_received
  FROM cycle_base WHERE cpo_ms_1406_ntp_received IS NOT NULL AND cx_start_date >= cpo_ms_1406_ntp_received
  UNION ALL
  SELECT 'construction_gc_assigned_date', rgn_region, m_area, m_market, cx_start_date, cpo_gc_assigned
  FROM cycle_base WHERE cpo_gc_assigned IS NOT NULL AND cx_start_date >= cpo_gc_assigned
  UNION ALL
  SELECT 'confirm_receipt_of_base_pos_and_spos_generated', rgn_region, m_area, m_market, cx_start_date, cpo_confirm_base_pos
  FROM cycle_base WHERE cpo_confirm_base_pos IS NOT NULL AND cx_start_date >= cpo_confirm_base_pos
)
SELECT
  cpo_source,
  rgn_region                                                            AS region,
  m_area                                                                AS area,
  m_market                                                              AS market,
  COUNT(*)                                                              AS sample_size,
  ROUND(AVG(cx_start_date - cpo_date)::numeric, 2)                      AS avg_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cx_start_date - cpo_date)::numeric  AS median_days,
  MIN(cx_start_date - cpo_date)                                         AS min_days,
  MAX(cx_start_date - cpo_date)                                         AS max_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cx_start_date - cpo_date)::numeric  AS p90_days
FROM per_candidate
GROUP BY cpo_source, rgn_region, m_area, m_market
ORDER BY cpo_source, avg_days DESC NULLS LAST;
```

## Q4 — GC / Vendor (all CPO candidates)

```sql
-- GC / Vendor-level NDPd Cycle Time: all CPO candidates, 4-month window
WITH cycle_base AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    ms_15500_gc_construction_start_actual::date           AS cx_start_date,
    base_cpo_received::date                               AS cpo_base,
    ms_1506_rfds_generation_service_actual::date          AS cpo_ms_1506_rfds,
    ms_1507_tower_ntp_approved_actual::date               AS cpo_ms_1507_ntp_approved,
    ms_1406_tower_ntp_received_actual::date               AS cpo_ms_1406_ntp_received,
    construction_gc_assigned_date::date                   AS cpo_gc_assigned,
    confirm_receipt_of_base_pos_and_spos_generated::date  AS cpo_confirm_base_pos
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE ms_15500_gc_construction_start_actual IS NOT NULL
    AND ms_15500_gc_construction_start_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND construction_gc IS NOT NULL
    AND m_market        IS NOT NULL
    -- AND rgn_region      = :region
    -- AND m_market        = :market
    -- AND construction_gc = :gc
),
per_candidate AS (
  SELECT 'base_cpo_received' AS cpo_source, m_market, construction_gc, cx_start_date, cpo_base AS cpo_date
  FROM cycle_base WHERE cpo_base IS NOT NULL AND cx_start_date >= cpo_base
  UNION ALL
  SELECT 'ms_1506_rfds_generation_service_actual', m_market, construction_gc, cx_start_date, cpo_ms_1506_rfds
  FROM cycle_base WHERE cpo_ms_1506_rfds IS NOT NULL AND cx_start_date >= cpo_ms_1506_rfds
  UNION ALL
  SELECT 'ms_1507_tower_ntp_approved_actual', m_market, construction_gc, cx_start_date, cpo_ms_1507_ntp_approved
  FROM cycle_base WHERE cpo_ms_1507_ntp_approved IS NOT NULL AND cx_start_date >= cpo_ms_1507_ntp_approved
  UNION ALL
  SELECT 'ms_1406_tower_ntp_received_actual', m_market, construction_gc, cx_start_date, cpo_ms_1406_ntp_received
  FROM cycle_base WHERE cpo_ms_1406_ntp_received IS NOT NULL AND cx_start_date >= cpo_ms_1406_ntp_received
  UNION ALL
  SELECT 'construction_gc_assigned_date', m_market, construction_gc, cx_start_date, cpo_gc_assigned
  FROM cycle_base WHERE cpo_gc_assigned IS NOT NULL AND cx_start_date >= cpo_gc_assigned
  UNION ALL
  SELECT 'confirm_receipt_of_base_pos_and_spos_generated', m_market, construction_gc, cx_start_date, cpo_confirm_base_pos
  FROM cycle_base WHERE cpo_confirm_base_pos IS NOT NULL AND cx_start_date >= cpo_confirm_base_pos
)
SELECT
  cpo_source,
  m_market                                                              AS market,
  construction_gc                                                       AS gc,
  COUNT(*)                                                              AS sample_size,
  ROUND(AVG(cx_start_date - cpo_date)::numeric, 2)                      AS avg_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cx_start_date - cpo_date)::numeric  AS median_days,
  MIN(cx_start_date - cpo_date)                                         AS min_days,
  MAX(cx_start_date - cpo_date)                                         AS max_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cx_start_date - cpo_date)::numeric  AS p90_days
FROM per_candidate
GROUP BY cpo_source, m_market, construction_gc
ORDER BY cpo_source, avg_days DESC NULLS LAST;
```
'''