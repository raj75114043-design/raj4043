Construction_complete_to_Integration_pending='''
## Q1 — National Construction-Complete → Integration-Pending (6-month window)

```sql
-- National Construction Complete to Integration Pending (NTM): 6-month window
WITH pending_sites AS (
  SELECT
    rgn_region,
    m_area,
    m_market,
    construction_gc,
    pj_project_id,
    s_site_id,
    ms_1555_construction_complete_actual::date      AS construction_complete_date,
    CURRENT_DATE - ms_1555_construction_complete_actual::date AS days_pending
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name   = 'NTM'
    AND smp_status = 'Active'
    AND COALESCE(ntm_project_type, '') NOT IN
        ('E2E06 - NSD Cx Mgmt', 'E2E07 - OL/MOD Cx Mgmt')
    AND ms_1555_construction_complete_actual IS NOT NULL
    AND ms_1899_all_planned_technologies_integrated_actual IS NULL
    AND ms_1555_construction_complete_actual::date
        >= CURRENT_DATE - INTERVAL '6 months'
)
SELECT
  COUNT(DISTINCT pj_project_id)                   AS pending_projects,
  COUNT(DISTINCT s_site_id)                       AS pending_sites,
  COUNT(*)                                        AS pending_records,
  ROUND(AVG(days_pending)::numeric, 1)            AS avg_days_pending,
  MAX(days_pending)                               AS max_days_pending,
  MIN(days_pending)                               AS min_days_pending,
  COUNT(*) FILTER (WHERE days_pending > 30)       AS pending_gt_30d,
  COUNT(*) FILTER (WHERE days_pending > 60)       AS pending_gt_60d,
  COUNT(*) FILTER (WHERE days_pending > 90)       AS pending_gt_90d
FROM pending_sites;
```

## Q2 — Region (4-month window)

```sql
-- Region-level Construction Complete to Integration Pending (NTM): 4-month window
WITH pending_sites AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    ms_1555_construction_complete_actual::date      AS construction_complete_date,
    CURRENT_DATE - ms_1555_construction_complete_actual::date AS days_pending
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name   = 'NTM'
    AND smp_status = 'Active'
    AND COALESCE(ntm_project_type, '') NOT IN
        ('E2E06 - NSD Cx Mgmt', 'E2E07 - OL/MOD Cx Mgmt')
    AND ms_1555_construction_complete_actual IS NOT NULL
    AND ms_1899_all_planned_technologies_integrated_actual IS NULL
    AND ms_1555_construction_complete_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND rgn_region IS NOT NULL
    -- AND rgn_region = :region    -- uncomment when region is the entry point
)
SELECT
  rgn_region                                      AS region,
  COUNT(DISTINCT pj_project_id)                   AS pending_projects,
  COUNT(DISTINCT s_site_id)                       AS pending_sites,
  COUNT(*)                                        AS pending_records,
  ROUND(AVG(days_pending)::numeric, 1)            AS avg_days_pending,
  MAX(days_pending)                               AS max_days_pending,
  COUNT(*) FILTER (WHERE days_pending > 30)       AS pending_gt_30d,
  COUNT(*) FILTER (WHERE days_pending > 60)       AS pending_gt_60d,
  COUNT(*) FILTER (WHERE days_pending > 90)       AS pending_gt_90d
FROM pending_sites
GROUP BY rgn_region
ORDER BY pending_projects DESC;
```

## Q3 — Market (4-month window)

```sql
-- Market-level Construction Complete to Integration Pending (NTM): 4-month window
WITH pending_sites AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    ms_1555_construction_complete_actual::date      AS construction_complete_date,
    CURRENT_DATE - ms_1555_construction_complete_actual::date AS days_pending
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name   = 'NTM'
    AND smp_status = 'Active'
    AND COALESCE(ntm_project_type, '') NOT IN
        ('E2E06 - NSD Cx Mgmt', 'E2E07 - OL/MOD Cx Mgmt')
    AND ms_1555_construction_complete_actual IS NOT NULL
    AND ms_1899_all_planned_technologies_integrated_actual IS NULL
    AND ms_1555_construction_complete_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m_market IS NOT NULL
    -- AND rgn_region = :region    -- when drilling from Region
    -- AND m_market   = :market    -- when market is the entry point
)
SELECT
  rgn_region                                      AS region,
  m_area                                          AS area,
  m_market                                        AS market,
  COUNT(DISTINCT pj_project_id)                   AS pending_projects,
  COUNT(DISTINCT s_site_id)                       AS pending_sites,
  COUNT(*)                                        AS pending_records,
  ROUND(AVG(days_pending)::numeric, 1)            AS avg_days_pending,
  MAX(days_pending)                               AS max_days_pending,
  COUNT(*) FILTER (WHERE days_pending > 30)       AS pending_gt_30d,
  COUNT(*) FILTER (WHERE days_pending > 60)       AS pending_gt_60d,
  COUNT(*) FILTER (WHERE days_pending > 90)       AS pending_gt_90d
FROM pending_sites
GROUP BY rgn_region, m_area, m_market
ORDER BY pending_projects DESC;
```

## Q4 — GC / Vendor (4-month window)

```sql
-- GC / Vendor-level Construction Complete to Integration Pending (NTM): 4-month window
WITH pending_sites AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    ms_1555_construction_complete_actual::date      AS construction_complete_date,
    CURRENT_DATE - ms_1555_construction_complete_actual::date AS days_pending
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name   = 'NTM'
    AND smp_status = 'Active'
    AND COALESCE(ntm_project_type, '') NOT IN
        ('E2E06 - NSD Cx Mgmt', 'E2E07 - OL/MOD Cx Mgmt')
    AND ms_1555_construction_complete_actual IS NOT NULL
    AND ms_1899_all_planned_technologies_integrated_actual IS NULL
    AND ms_1555_construction_complete_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND construction_gc IS NOT NULL
    AND m_market        IS NOT NULL
    -- AND rgn_region      = :region    -- when drilling from Region
    -- AND m_market        = :market    -- when drilling from Market
    -- AND construction_gc = :gc        -- when GC is the entry point
)
SELECT
  m_market                                        AS market,
  construction_gc                                 AS gc,
  COUNT(DISTINCT pj_project_id)                   AS pending_projects,
  COUNT(DISTINCT s_site_id)                       AS pending_sites,
  COUNT(*)                                        AS pending_records,
  ROUND(AVG(days_pending)::numeric, 1)            AS avg_days_pending,
  MAX(days_pending)                               AS max_days_pending,
  COUNT(*) FILTER (WHERE days_pending > 30)       AS pending_gt_30d,
  COUNT(*) FILTER (WHERE days_pending > 60)       AS pending_gt_60d,
  COUNT(*) FILTER (WHERE days_pending > 90)       AS pending_gt_90d
FROM pending_sites
GROUP BY m_market, construction_gc
ORDER BY pending_projects DESC;
```
'''