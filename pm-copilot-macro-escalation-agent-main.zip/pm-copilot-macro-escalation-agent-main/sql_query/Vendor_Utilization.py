Vendor_Utilization='''
-- National Vendor Utilization: 6-month window
WITH wip_sites AS (
  SELECT rgn_region, m_area, m_market, construction_gc, s_site_id
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE (
          (ms_1549_civil_construction_start_actual IS NOT NULL
            AND ms_1551_civil_construction_complete_actual_date IS NULL)
          OR
          (ms_1550_construction_start_actual IS NOT NULL
            AND ms_1555_construction_complete_actual IS NULL)
        )
    AND COALESCE(NULLIF(TRIM(pj_construction_start_delay_code), ''), NULL) IS NULL
    AND COALESCE(NULLIF(TRIM(pj_construction_complete_delay_code), ''), NULL) IS NULL
    AND GREATEST(
          ms_1549_civil_construction_start_actual::date,
          ms_1550_construction_start_actual::date
        ) >= CURRENT_DATE - INTERVAL '6 months'
    AND construction_gc IS NOT NULL
    AND m_market IS NOT NULL
),
gc_capacity AS (
  SELECT market, gc_company, SUM(day_wise_gc_capacity) AS capacity
  FROM gc_capacity_market_trial
  GROUP BY market, gc_company
)
SELECT
  COUNT(DISTINCT w.s_site_id)                                       AS wip_sites,
  COALESCE(SUM(DISTINCT c.capacity), 0)                             AS total_capacity,
  ROUND(
    100.0 * COUNT(DISTINCT w.s_site_id)
          / NULLIF(COALESCE(SUM(DISTINCT c.capacity), 0), 0),
    2
  )                                                                 AS vendor_utilization_pct
FROM wip_sites w
LEFT JOIN gc_capacity c
  ON w.m_market = c.market
 AND w.construction_gc = c.gc_company;


-- Region-level Vendor Utilization: 4-month window
WITH wip_sites AS (
  SELECT rgn_region, m_area, m_market, construction_gc, s_site_id
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE (
          (ms_1549_civil_construction_start_actual IS NOT NULL
            AND ms_1551_civil_construction_complete_actual_date IS NULL)
          OR
          (ms_1550_construction_start_actual IS NOT NULL
            AND ms_1555_construction_complete_actual IS NULL)
        )
    AND COALESCE(NULLIF(TRIM(pj_construction_start_delay_code), ''), NULL) IS NULL
    AND COALESCE(NULLIF(TRIM(pj_construction_complete_delay_code), ''), NULL) IS NULL
    AND GREATEST(
          ms_1549_civil_construction_start_actual::date,
          ms_1550_construction_start_actual::date
        ) >= CURRENT_DATE - INTERVAL '4 months'
    AND construction_gc IS NOT NULL
    AND m_market IS NOT NULL
    -- AND rgn_region = :region   -- uncomment when region is the entry point
),
gc_capacity AS (
  SELECT market, gc_company, SUM(day_wise_gc_capacity) AS capacity
  FROM gc_capacity_market_trial
  GROUP BY market, gc_company
),
region_wip AS (
  SELECT rgn_region, COUNT(DISTINCT s_site_id) AS wip_sites
  FROM wip_sites
  GROUP BY rgn_region
),
region_cap AS (
  SELECT w.rgn_region, SUM(DISTINCT c.capacity) AS capacity
  FROM wip_sites w
  JOIN gc_capacity c
    ON w.m_market = c.market AND w.construction_gc = c.gc_company
  GROUP BY w.rgn_region
)
SELECT
  rw.rgn_region                                    AS region,
  rw.wip_sites,
  COALESCE(rc.capacity, 0)                         AS capacity,
  ROUND(
    100.0 * rw.wip_sites / NULLIF(rc.capacity, 0),
    2
  )                                                AS vendor_utilization_pct
FROM region_wip rw
LEFT JOIN region_cap rc USING (rgn_region)
ORDER BY vendor_utilization_pct DESC NULLS LAST;


-- Market-level Vendor Utilization: 4-month window
WITH wip_sites AS (
  SELECT rgn_region, m_area, m_market, construction_gc, s_site_id
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE (
          (ms_1549_civil_construction_start_actual IS NOT NULL
            AND ms_1551_civil_construction_complete_actual_date IS NULL)
          OR
          (ms_1550_construction_start_actual IS NOT NULL
            AND ms_1555_construction_complete_actual IS NULL)
        )
    AND COALESCE(NULLIF(TRIM(pj_construction_start_delay_code), ''), NULL) IS NULL
    AND COALESCE(NULLIF(TRIM(pj_construction_complete_delay_code), ''), NULL) IS NULL
    AND GREATEST(
          ms_1549_civil_construction_start_actual::date,
          ms_1550_construction_start_actual::date
        ) >= CURRENT_DATE - INTERVAL '4 months'
    AND construction_gc IS NOT NULL
    AND m_market IS NOT NULL
    -- AND rgn_region = :region   -- when drilling from Region
    -- AND m_market   = :market   -- when market is the entry point
),
market_wip AS (
  SELECT rgn_region, m_area, m_market,
         COUNT(DISTINCT s_site_id) AS wip_sites
  FROM wip_sites
  GROUP BY rgn_region, m_area, m_market
),
market_cap AS (
  SELECT market,
         SUM(day_wise_gc_capacity) AS capacity
  FROM gc_capacity_market_trial
  GROUP BY market
)
SELECT
  mw.rgn_region                                    AS region,
  mw.m_area                                        AS area,
  mw.m_market                                      AS market,
  mw.wip_sites,
  COALESCE(mc.capacity, 0)                         AS capacity,
  ROUND(
    100.0 * mw.wip_sites / NULLIF(mc.capacity, 0),
    2
  )                                                AS vendor_utilization_pct
FROM market_wip mw
LEFT JOIN market_cap mc
  ON mw.m_market = mc.market
ORDER BY vendor_utilization_pct DESC NULLS LAST;



-- GC / Vendor-level Vendor Utilization: 4-month window
WITH wip_sites AS (
  SELECT rgn_region, m_area, m_market, construction_gc, s_site_id
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE (
          (ms_1549_civil_construction_start_actual IS NOT NULL
            AND ms_1551_civil_construction_complete_actual_date IS NULL)
          OR
          (ms_1550_construction_start_actual IS NOT NULL
            AND ms_1555_construction_complete_actual IS NULL)
        )
    AND COALESCE(NULLIF(TRIM(pj_construction_start_delay_code), ''), NULL) IS NULL
    AND COALESCE(NULLIF(TRIM(pj_construction_complete_delay_code), ''), NULL) IS NULL
    AND GREATEST(
          ms_1549_civil_construction_start_actual::date,
          ms_1550_construction_start_actual::date
        ) >= CURRENT_DATE - INTERVAL '4 months'
    AND construction_gc IS NOT NULL
    AND m_market IS NOT NULL
    -- AND rgn_region      = :region   -- when drilling from Region
    -- AND m_market        = :market   -- when drilling from Market
    -- AND construction_gc = :gc       -- when GC is the entry point
),
gc_wip AS (
  SELECT m_market, construction_gc,
         COUNT(DISTINCT s_site_id) AS wip_sites
  FROM wip_sites
  GROUP BY m_market, construction_gc
),
gc_cap AS (
  SELECT market, gc_company ,
         SUM(day_wise_gc_capacity) AS capacity
  FROM gc_capacity_market_trial
  GROUP BY market, gc_company
)
SELECT
  gw.m_market                                      AS market,
  gw.construction_gc                               AS gc,
  gw.wip_sites,
  COALESCE(gc.capacity, 0)                         AS capacity,
  ROUND(
    100.0 * gw.wip_sites / NULLIF(gc.capacity, 0),
    2
  )                                                AS vendor_utilization_pct
FROM gc_wip gw
LEFT JOIN gc_cap gc
  ON gw.m_market = gc.market
 AND gw.construction_gc = gc.gc_company
ORDER BY vendor_utilization_pct DESC NULLS LAST;
'''