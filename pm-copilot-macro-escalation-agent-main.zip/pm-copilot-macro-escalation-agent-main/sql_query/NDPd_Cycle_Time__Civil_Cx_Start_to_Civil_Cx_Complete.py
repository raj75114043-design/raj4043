NDPd_Cycle_Time__Civil_Cx_Start_to_Civil_Cx_Complete = '''
## Q1 — National (6-month)

```sql
-- National NDPd Cycle Time - Civil Cx Start → Civil Cx Complete: 6-month window
WITH civil_cycle AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id, smp_id,
    ms_1549_civil_construction_start::date              AS civil_start_date,
    ms_1551_civil_construction_complete_actual_date::date AS civil_complete_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE ms_1549_civil_construction_start              IS NOT NULL
    AND ms_1551_civil_construction_complete_actual_date IS NOT NULL
),
civil_windowed AS (
  SELECT *, (civil_complete_date - civil_start_date) AS cycle_days
  FROM civil_cycle
  WHERE civil_complete_date >= CURRENT_DATE - INTERVAL '6 months'
)
SELECT
  COUNT(*)                                                              AS sites_count,
  COUNT(*) FILTER (WHERE cycle_days < 0)                                AS data_quality_flag_negative,
  ROUND(AVG(cycle_days) FILTER (WHERE cycle_days >= 0)::numeric, 2)     AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days)
    FILTER (WHERE cycle_days >= 0)                                      AS median_cycle_days,
  MIN(cycle_days) FILTER (WHERE cycle_days >= 0)                        AS min_cycle_days,
  MAX(cycle_days) FILTER (WHERE cycle_days >= 0)                        AS max_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycle_days)
    FILTER (WHERE cycle_days >= 0)                                      AS p90_cycle_days
FROM civil_windowed;
```

## Q2 — Region (4-month)

```sql
WITH civil_cycle AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id, smp_id,
    ms_1549_civil_construction_start::date              AS civil_start_date,
    ms_1551_civil_construction_complete_actual_date::date AS civil_complete_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE ms_1549_civil_construction_start              IS NOT NULL
    AND ms_1551_civil_construction_complete_actual_date IS NOT NULL
    AND rgn_region IS NOT NULL
    -- AND rgn_region = :region
),
civil_windowed AS (
  SELECT *, (civil_complete_date - civil_start_date) AS cycle_days
  FROM civil_cycle
  WHERE civil_complete_date >= CURRENT_DATE - INTERVAL '4 months'
)
SELECT
  rgn_region AS region,
  COUNT(*) AS sites_count,
  COUNT(*) FILTER (WHERE cycle_days < 0) AS data_quality_flag_negative,
  ROUND(AVG(cycle_days) FILTER (WHERE cycle_days >= 0)::numeric, 2) AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days) FILTER (WHERE cycle_days >= 0) AS median_cycle_days,
  MIN(cycle_days) FILTER (WHERE cycle_days >= 0) AS min_cycle_days,
  MAX(cycle_days) FILTER (WHERE cycle_days >= 0) AS max_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycle_days) FILTER (WHERE cycle_days >= 0) AS p90_cycle_days
FROM civil_windowed
GROUP BY rgn_region
ORDER BY avg_cycle_days DESC NULLS LAST;
```

## Q3 — Market (4-month)

```sql
WITH civil_cycle AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id, smp_id,
    ms_1549_civil_construction_start::date              AS civil_start_date,
    ms_1551_civil_construction_complete_actual_date::date AS civil_complete_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE ms_1549_civil_construction_start              IS NOT NULL
    AND ms_1551_civil_construction_complete_actual_date IS NOT NULL
    AND m_market IS NOT NULL
    -- AND rgn_region = :region
    -- AND m_market   = :market
),
civil_windowed AS (
  SELECT *, (civil_complete_date - civil_start_date) AS cycle_days
  FROM civil_cycle
  WHERE civil_complete_date >= CURRENT_DATE - INTERVAL '4 months'
)
SELECT
  rgn_region AS region, m_area AS area, m_market AS market,
  COUNT(*) AS sites_count,
  COUNT(*) FILTER (WHERE cycle_days < 0) AS data_quality_flag_negative,
  ROUND(AVG(cycle_days) FILTER (WHERE cycle_days >= 0)::numeric, 2) AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days) FILTER (WHERE cycle_days >= 0) AS median_cycle_days,
  MIN(cycle_days) FILTER (WHERE cycle_days >= 0) AS min_cycle_days,
  MAX(cycle_days) FILTER (WHERE cycle_days >= 0) AS max_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycle_days) FILTER (WHERE cycle_days >= 0) AS p90_cycle_days
FROM civil_windowed
GROUP BY rgn_region, m_area, m_market
ORDER BY avg_cycle_days DESC NULLS LAST;
```

## Q4 — GC / Vendor (4-month)

```sql
WITH civil_cycle AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id, smp_id,
    ms_1549_civil_construction_start::date              AS civil_start_date,
    ms_1551_civil_construction_complete_actual_date::date AS civil_complete_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE ms_1549_civil_construction_start              IS NOT NULL
    AND ms_1551_civil_construction_complete_actual_date IS NOT NULL
    AND construction_gc IS NOT NULL
    AND m_market        IS NOT NULL
    -- AND rgn_region      = :region
    -- AND m_market        = :market
    -- AND construction_gc = :gc
),
civil_windowed AS (
  SELECT *, (civil_complete_date - civil_start_date) AS cycle_days
  FROM civil_cycle
  WHERE civil_complete_date >= CURRENT_DATE - INTERVAL '4 months'
)
SELECT
  m_market AS market, construction_gc AS gc,
  COUNT(*) AS sites_count,
  COUNT(*) FILTER (WHERE cycle_days < 0) AS data_quality_flag_negative,
  ROUND(AVG(cycle_days) FILTER (WHERE cycle_days >= 0)::numeric, 2) AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days) FILTER (WHERE cycle_days >= 0) AS median_cycle_days,
  MIN(cycle_days) FILTER (WHERE cycle_days >= 0) AS min_cycle_days,
  MAX(cycle_days) FILTER (WHERE cycle_days >= 0) AS max_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycle_days) FILTER (WHERE cycle_days >= 0) AS p90_cycle_days
FROM civil_windowed
GROUP BY m_market, construction_gc
ORDER BY avg_cycle_days DESC NULLS LAST;
```
'''