Average_NDPC_Rejected_GC_Crew_wise_Market_wise='''

## Q1 — National Avg NDPC Rejected % (6-month window)

```sql
-- National Avg NDPC Rejected %: 6-month window
WITH cohort AS (
  SELECT
    m.rgn_region, m.m_area, m.m_market, m.construction_gc,
    m.pj_project_id, m.s_site_id, m.smp_id, m.scop_title
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined m
  WHERE m.ms_1550_construction_start_actual IS NOT NULL
    AND m.ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl IS NULL
    AND m.ms_1550_construction_start_actual::date
        >= CURRENT_DATE - INTERVAL '6 months'
    AND m.scop_title IS NOT NULL
    -- AND m.smp_name = :smp_name
),
latest_session AS (
  SELECT sessiontitle, rejectedpercent, lastactivity
  FROM (
    SELECT
      s.sessiontitle,
      s.rejectedpercent,
      s.lastactivity,
      ROW_NUMBER() OVER (
        PARTITION BY s.sessiontitle
        ORDER BY s.lastactivity DESC NULLS LAST
      ) AS rn
    FROM pwc_macro_staging_schema.stg_services_ndpc_sessions_daily_from_sdb s
    WHERE s.sessiontitle IS NOT NULL
      AND s.rejectedpercent IS NOT NULL
  ) x
  WHERE rn = 1
),
joined AS (
  SELECT
    c.rgn_region, c.m_area, c.m_market, c.construction_gc,
    c.pj_project_id, c.s_site_id,
    ls.sessiontitle,
    NULLIF(REGEXP_REPLACE(ls.rejectedpercent::text, '[^0-9.\-]', '', 'g'), '')::numeric
      AS rejected_pct
  FROM cohort c
  JOIN latest_session ls ON ls.sessiontitle = c.scop_title
)
SELECT
  COUNT(DISTINCT sessiontitle)                           AS session_count,
  COUNT(DISTINCT s_site_id)                              AS site_count,
  ROUND(AVG(rejected_pct)::numeric, 2)                   AS avg_ndpc_rejected_pct
FROM joined;
```

## Q2 — Region Avg NDPC Rejected % (4-month window)

```sql
-- Region-level Avg NDPC Rejected %: 4-month window
WITH cohort AS (
  SELECT
    m.rgn_region, m.m_area, m.m_market, m.construction_gc,
    m.pj_project_id, m.s_site_id, m.smp_id, m.scop_title
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined m
  WHERE m.ms_1550_construction_start_actual IS NOT NULL
    AND m.ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl IS NULL
    AND m.ms_1550_construction_start_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m.scop_title  IS NOT NULL
    AND m.rgn_region  IS NOT NULL
    -- AND m.rgn_region = :region    -- uncomment when region is the entry point
    -- AND m.smp_name   = :smp_name
),
latest_session AS (
  SELECT sessiontitle, rejectedpercent, lastactivity
  FROM (
    SELECT s.sessiontitle, s.rejectedpercent, s.lastactivity,
           ROW_NUMBER() OVER (
             PARTITION BY s.sessiontitle
             ORDER BY s.lastactivity DESC NULLS LAST
           ) AS rn
    FROM pwc_macro_staging_schema.stg_services_ndpc_sessions_daily_from_sdb s
    WHERE s.sessiontitle IS NOT NULL
      AND s.rejectedpercent IS NOT NULL
  ) x
  WHERE rn = 1
),
joined AS (
  SELECT
    c.rgn_region, c.m_area, c.m_market, c.construction_gc,
    c.pj_project_id, c.s_site_id,
    ls.sessiontitle,
    NULLIF(REGEXP_REPLACE(ls.rejectedpercent::text, '[^0-9.\-]', '', 'g'), '')::numeric
      AS rejected_pct
  FROM cohort c
  JOIN latest_session ls ON ls.sessiontitle = c.scop_title
)
SELECT
  rgn_region                                              AS region,
  COUNT(DISTINCT sessiontitle)                            AS session_count,
  COUNT(DISTINCT s_site_id)                               AS site_count,
  ROUND(AVG(rejected_pct)::numeric, 2)                    AS avg_ndpc_rejected_pct
FROM joined
GROUP BY rgn_region
ORDER BY avg_ndpc_rejected_pct DESC NULLS LAST;
```

## Q3 — Market Avg NDPC Rejected % (4-month window)

```sql
-- Market-level Avg NDPC Rejected %: 4-month window
WITH cohort AS (
  SELECT
    m.rgn_region, m.m_area, m.m_market, m.construction_gc,
    m.pj_project_id, m.s_site_id, m.smp_id, m.scop_title
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined m
  WHERE m.ms_1550_construction_start_actual IS NOT NULL
    AND m.ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl IS NULL
    AND m.ms_1550_construction_start_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m.scop_title IS NOT NULL
    AND m.m_market   IS NOT NULL
    -- AND m.rgn_region = :region    -- when drilling from Region
    -- AND m.m_market   = :market    -- when market is the entry point
    -- AND m.smp_name   = :smp_name
),
latest_session AS (
  SELECT sessiontitle, rejectedpercent, lastactivity
  FROM (
    SELECT s.sessiontitle, s.rejectedpercent, s.lastactivity,
           ROW_NUMBER() OVER (
             PARTITION BY s.sessiontitle
             ORDER BY s.lastactivity DESC NULLS LAST
           ) AS rn
    FROM pwc_macro_staging_schema.stg_services_ndpc_sessions_daily_from_sdb s
    WHERE s.sessiontitle IS NOT NULL
      AND s.rejectedpercent IS NOT NULL
  ) x
  WHERE rn = 1
),
joined AS (
  SELECT
    c.rgn_region, c.m_area, c.m_market, c.construction_gc,
    c.pj_project_id, c.s_site_id,
    ls.sessiontitle,
    NULLIF(REGEXP_REPLACE(ls.rejectedpercent::text, '[^0-9.\-]', '', 'g'), '')::numeric
      AS rejected_pct
  FROM cohort c
  JOIN latest_session ls ON ls.sessiontitle = c.scop_title
)
SELECT
  rgn_region                                              AS region,
  m_area                                                  AS area,
  m_market                                                AS market,
  COUNT(DISTINCT sessiontitle)                            AS session_count,
  COUNT(DISTINCT s_site_id)                               AS site_count,
  ROUND(AVG(rejected_pct)::numeric, 2)                    AS avg_ndpc_rejected_pct
FROM joined
GROUP BY rgn_region, m_area, m_market
ORDER BY avg_ndpc_rejected_pct DESC NULLS LAST;
```

## Q4 — GC / Vendor Avg NDPC Rejected % (4-month window)

```sql
-- GC / Vendor-level Avg NDPC Rejected %: 4-month window
WITH cohort AS (
  SELECT
    m.rgn_region, m.m_area, m.m_market, m.construction_gc,
    m.pj_project_id, m.s_site_id, m.smp_id, m.scop_title
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined m
  WHERE m.ms_1550_construction_start_actual IS NOT NULL
    AND m.ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl IS NULL
    AND m.ms_1550_construction_start_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m.scop_title       IS NOT NULL
    AND m.construction_gc  IS NOT NULL
    AND m.m_market         IS NOT NULL
    -- AND m.rgn_region      = :region    -- when drilling from Region
    -- AND m.m_market        = :market    -- when drilling from Market
    -- AND m.construction_gc = :gc        -- when GC is the entry point
    -- AND m.smp_name        = :smp_name
),
latest_session AS (
  SELECT sessiontitle, rejectedpercent, lastactivity
  FROM (
    SELECT s.sessiontitle, s.rejectedpercent, s.lastactivity,
           ROW_NUMBER() OVER (
             PARTITION BY s.sessiontitle
             ORDER BY s.lastactivity DESC NULLS LAST
           ) AS rn
    FROM pwc_macro_staging_schema.stg_services_ndpc_sessions_daily_from_sdb s
    WHERE s.sessiontitle IS NOT NULL
      AND s.rejectedpercent IS NOT NULL
  ) x
  WHERE rn = 1
),
joined AS (
  SELECT
    c.rgn_region, c.m_area, c.m_market, c.construction_gc,
    c.pj_project_id, c.s_site_id,
    ls.sessiontitle,
    NULLIF(REGEXP_REPLACE(ls.rejectedpercent::text, '[^0-9.\-]', '', 'g'), '')::numeric
      AS rejected_pct
  FROM cohort c
  JOIN latest_session ls ON ls.sessiontitle = c.scop_title
)
SELECT
  m_market                                                AS market,
  construction_gc                                         AS gc,
  COUNT(DISTINCT sessiontitle)                            AS session_count,
  COUNT(DISTINCT s_site_id)                               AS site_count,
  ROUND(AVG(rejected_pct)::numeric, 2)                    AS avg_ndpc_rejected_pct
FROM joined
GROUP BY m_market, construction_gc
ORDER BY avg_ndpc_rejected_pct DESC NULLS LAST;
```
'''