Cx_Complete_to_COP_submission_Cycle_Time='''
## Q1 — National Cx→COP Cycle Time (6-month window)

```sql
-- National Cx Complete to COP Submission Cycle Time: 6-month window
WITH cycle_base AS (
  SELECT DISTINCT
    rgn_region,
    m_area,
    m_market,
    construction_gc,
    pj_project_id,
    s_site_id,
    ms_1555_construction_complete_actual::date                            AS cx_complete_date,
    ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl::date   AS cop_submit_date,
    (ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl::date
     - ms_1555_construction_complete_actual::date)                        AS cycletime_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name   = 'NTM'
    AND smp_status = 'Active'
    AND ntm_project_type NOT IN ('E2E06 - NSD Cx Mgmt', 'E2E07 - OL/MOD Cx Mgmt')
    AND ms_1555_construction_complete_actual IS NOT NULL
    AND ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl IS NOT NULL
    AND ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl::date
        >= CURRENT_DATE - INTERVAL '6 months'
),
cycle_clean AS (
  SELECT * FROM cycle_base WHERE cycletime_days >= 0
)
SELECT
  COUNT(DISTINCT pj_project_id)                                        AS projects_count,
  COUNT(*)                                                             AS records_count,
  ROUND(AVG(cycletime_days)::numeric, 2)                               AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycletime_days)          AS median_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycletime_days)          AS p90_cycle_days,
  MIN(cycletime_days)                                                  AS min_cycle_days,
  MAX(cycletime_days)                                                  AS max_cycle_days,
  (SELECT COUNT(*) FROM cycle_base WHERE cycletime_days < 0)           AS negative_cycle_excluded
FROM cycle_clean;
```

## Q2 — Region Cx→COP Cycle Time (4-month window)

```sql
-- Region-level Cx→COP Cycle Time: 4-month window
WITH cycle_base AS (
  SELECT DISTINCT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    ms_1555_construction_complete_actual::date                            AS cx_complete_date,
    ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl::date   AS cop_submit_date,
    (ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl::date
     - ms_1555_construction_complete_actual::date)                        AS cycletime_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name   = 'NTM'
    AND smp_status = 'Active'
    AND ntm_project_type NOT IN ('E2E06 - NSD Cx Mgmt', 'E2E07 - OL/MOD Cx Mgmt')
    AND ms_1555_construction_complete_actual IS NOT NULL
    AND ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl IS NOT NULL
    AND ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND rgn_region IS NOT NULL
    -- AND rgn_region = :region    -- uncomment when region is the entry point
),
cycle_clean AS (
  SELECT * FROM cycle_base WHERE cycletime_days >= 0
)
SELECT
  rgn_region                                                    AS region,
  COUNT(DISTINCT pj_project_id)                                 AS projects_count,
  COUNT(*)                                                      AS records_count,
  ROUND(AVG(cycletime_days)::numeric, 2)                        AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycletime_days)   AS median_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycletime_days)   AS p90_cycle_days,
  MIN(cycletime_days)                                           AS min_cycle_days,
  MAX(cycletime_days)                                           AS max_cycle_days
FROM cycle_clean
GROUP BY rgn_region
ORDER BY avg_cycle_days DESC NULLS LAST;
```

## Q3 — Market Cx→COP Cycle Time (4-month window)

```sql
-- Market-level Cx→COP Cycle Time: 4-month window
WITH cycle_base AS (
  SELECT DISTINCT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    ms_1555_construction_complete_actual::date                            AS cx_complete_date,
    ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl::date   AS cop_submit_date,
    (ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl::date
     - ms_1555_construction_complete_actual::date)                        AS cycletime_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name   = 'NTM'
    AND smp_status = 'Active'
    AND ntm_project_type NOT IN ('E2E06 - NSD Cx Mgmt', 'E2E07 - OL/MOD Cx Mgmt')
    AND ms_1555_construction_complete_actual IS NOT NULL
    AND ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl IS NOT NULL
    AND ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m_market IS NOT NULL
    -- AND rgn_region = :region    -- when drilling from Region
    -- AND m_market   = :market    -- when market is the entry point
),
cycle_clean AS (
  SELECT * FROM cycle_base WHERE cycletime_days >= 0
)
SELECT
  rgn_region                                                    AS region,
  m_area                                                        AS area,
  m_market                                                      AS market,
  COUNT(DISTINCT pj_project_id)                                 AS projects_count,
  COUNT(*)                                                      AS records_count,
  ROUND(AVG(cycletime_days)::numeric, 2)                        AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycletime_days)   AS median_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycletime_days)   AS p90_cycle_days,
  MIN(cycletime_days)                                           AS min_cycle_days,
  MAX(cycletime_days)                                           AS max_cycle_days
FROM cycle_clean
GROUP BY rgn_region, m_area, m_market
ORDER BY avg_cycle_days DESC NULLS LAST;
```

## Q4 — GC / Vendor Cx→COP Cycle Time (4-month window)

```sql
-- GC / Vendor-level Cx→COP Cycle Time: 4-month window
WITH cycle_base AS (
  SELECT DISTINCT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    ms_1555_construction_complete_actual::date                            AS cx_complete_date,
    ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl::date   AS cop_submit_date,
    (ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl::date
     - ms_1555_construction_complete_actual::date)                        AS cycletime_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name   = 'NTM'
    AND smp_status = 'Active'
    AND ntm_project_type NOT IN ('E2E06 - NSD Cx Mgmt', 'E2E07 - OL/MOD Cx Mgmt')
    AND ms_1555_construction_complete_actual IS NOT NULL
    AND ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl IS NOT NULL
    AND ms_1557_punch_checklist_reviewed_and_submitted_to_tmobile_atl::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND construction_gc IS NOT NULL
    AND m_market        IS NOT NULL
    -- AND rgn_region      = :region    -- when drilling from Region
    -- AND m_market        = :market    -- when drilling from Market
    -- AND construction_gc = :gc        -- when GC is the entry point
),
cycle_clean AS (
  SELECT * FROM cycle_base WHERE cycletime_days >= 0
)
SELECT
  m_market                                                      AS market,
  construction_gc                                               AS gc,
  COUNT(DISTINCT pj_project_id)                                 AS projects_count,
  COUNT(*)                                                      AS records_count,
  ROUND(AVG(cycletime_days)::numeric, 2)                        AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycletime_days)   AS median_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycletime_days)   AS p90_cycle_days,
  MIN(cycletime_days)                                           AS min_cycle_days,
  MAX(cycletime_days)                                           AS max_cycle_days
FROM cycle_clean
GROUP BY m_market, construction_gc
ORDER BY avg_cycle_days DESC NULLS LAST;
```
'''