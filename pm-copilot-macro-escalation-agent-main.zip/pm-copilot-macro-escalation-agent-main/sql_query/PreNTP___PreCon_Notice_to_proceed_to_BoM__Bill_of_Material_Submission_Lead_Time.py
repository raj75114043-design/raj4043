PreNTP___PreCon_Notice_to_proceed_to_BoM__Bill_of_Material_Submission_Lead_Time='''

## Q1 — National Pre-NTP to BoM Lead Time (6-month window)

```sql
-- National Pre-NTP to BoM Submission Lead Time: 6-month window
WITH cycle_times AS (
  SELECT
    rgn_region,
    m_area,
    m_market,
    construction_gc,
    smp_id,
    pj_project_id,
    s_site_id,
    pj_a_3800_pre_ntp_issued_finish::date           AS pre_ntp_date,
    pj_a_3850_bom_submitted_bom_in_bat_finish::date AS bom_submit_date,
    GREATEST(
      (pj_a_3850_bom_submitted_bom_in_bat_finish::date
       - pj_a_3800_pre_ntp_issued_finish::date),
      0
    ) AS lead_time_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE pj_a_3800_pre_ntp_issued_finish           IS NOT NULL
    AND pj_a_3850_bom_submitted_bom_in_bat_finish IS NOT NULL
    AND pj_a_3850_bom_submitted_bom_in_bat_finish::date
        >= CURRENT_DATE - INTERVAL '6 months'
)
SELECT
  COUNT(*)                                                         AS projects_count,
  ROUND(AVG(lead_time_days)::numeric, 2)                           AS avg_lead_time_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY lead_time_days)      AS median_lead_time_days,
  MIN(lead_time_days)                                              AS min_lead_time_days,
  MAX(lead_time_days)                                              AS max_lead_time_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY lead_time_days)      AS p90_lead_time_days
FROM cycle_times;
```

## Q2 — Region Pre-NTP to BoM Lead Time (4-month window)

```sql
-- Region-level Pre-NTP to BoM Submission Lead Time: 4-month window
WITH cycle_times AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc, smp_id, pj_project_id, s_site_id,
    GREATEST(
      (pj_a_3850_bom_submitted_bom_in_bat_finish::date
       - pj_a_3800_pre_ntp_issued_finish::date),
      0
    ) AS lead_time_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE pj_a_3800_pre_ntp_issued_finish           IS NOT NULL
    AND pj_a_3850_bom_submitted_bom_in_bat_finish IS NOT NULL
    AND pj_a_3850_bom_submitted_bom_in_bat_finish::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND rgn_region IS NOT NULL
    -- AND rgn_region = :region    -- uncomment when region is the entry point
)
SELECT
  rgn_region                                                       AS region,
  COUNT(*)                                                         AS projects_count,
  ROUND(AVG(lead_time_days)::numeric, 2)                           AS avg_lead_time_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY lead_time_days)      AS median_lead_time_days,
  MIN(lead_time_days)                                              AS min_lead_time_days,
  MAX(lead_time_days)                                              AS max_lead_time_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY lead_time_days)      AS p90_lead_time_days
FROM cycle_times
GROUP BY rgn_region
ORDER BY median_lead_time_days DESC NULLS LAST;
```

## Q3 — Market Pre-NTP to BoM Lead Time (4-month window)

```sql
-- Market-level Pre-NTP to BoM Submission Lead Time: 4-month window
WITH cycle_times AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc, smp_id, pj_project_id, s_site_id,
    GREATEST(
      (pj_a_3850_bom_submitted_bom_in_bat_finish::date
       - pj_a_3800_pre_ntp_issued_finish::date),
      0
    ) AS lead_time_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE pj_a_3800_pre_ntp_issued_finish           IS NOT NULL
    AND pj_a_3850_bom_submitted_bom_in_bat_finish IS NOT NULL
    AND pj_a_3850_bom_submitted_bom_in_bat_finish::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m_market IS NOT NULL
    -- AND rgn_region = :region    -- when drilling from Region
    -- AND m_market   = :market    -- when market is the entry point
)
SELECT
  rgn_region                                                       AS region,
  m_area                                                           AS area,
  m_market                                                         AS market,
  COUNT(*)                                                         AS projects_count,
  ROUND(AVG(lead_time_days)::numeric, 2)                           AS avg_lead_time_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY lead_time_days)      AS median_lead_time_days,
  MIN(lead_time_days)                                              AS min_lead_time_days,
  MAX(lead_time_days)                                              AS max_lead_time_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY lead_time_days)      AS p90_lead_time_days
FROM cycle_times
GROUP BY rgn_region, m_area, m_market
ORDER BY median_lead_time_days DESC NULLS LAST;
```

## Q4 — GC / Vendor Pre-NTP to BoM Lead Time (4-month window)

```sql
-- GC / Vendor-level Pre-NTP to BoM Submission Lead Time: 4-month window
WITH cycle_times AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc, smp_id, pj_project_id, s_site_id,
    GREATEST(
      (pj_a_3850_bom_submitted_bom_in_bat_finish::date
       - pj_a_3800_pre_ntp_issued_finish::date),
      0
    ) AS lead_time_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE pj_a_3800_pre_ntp_issued_finish           IS NOT NULL
    AND pj_a_3850_bom_submitted_bom_in_bat_finish IS NOT NULL
    AND pj_a_3850_bom_submitted_bom_in_bat_finish::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND construction_gc IS NOT NULL
    AND m_market        IS NOT NULL
    -- AND rgn_region      = :region    -- when drilling from Region
    -- AND m_market        = :market    -- when drilling from Market
    -- AND construction_gc = :gc        -- when GC is the entry point
)
SELECT
  m_market                                                         AS market,
  construction_gc                                                  AS gc,
  COUNT(*)                                                         AS projects_count,
  ROUND(AVG(lead_time_days)::numeric, 2)                           AS avg_lead_time_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY lead_time_days)      AS median_lead_time_days,
  MIN(lead_time_days)                                              AS min_lead_time_days,
  MAX(lead_time_days)                                              AS max_lead_time_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY lead_time_days)      AS p90_lead_time_days
FROM cycle_times
GROUP BY m_market, construction_gc
ORDER BY median_lead_time_days DESC NULLS LAST;
```

---

### Business-days variant (drop-in replacement for `lead_time_days`)

If your SME wants business days instead of calendar days (matching the NTP-to-swap reference SQL from JSON #3), replace the `GREATEST(...)` expression with a subquery. Cleanest form, applied to any of the four queries:

```sql
(
  SELECT COUNT(*)
  FROM generate_series(
         pj_a_3800_pre_ntp_issued_finish::date,
         pj_a_3850_bom_submitted_bom_in_bat_finish::date,
         INTERVAL '1 day'
       ) g
  WHERE EXTRACT(ISODOW FROM g) BETWEEN 1 AND 5
) AS lead_time_days
```
'''