Integration_Start_Delay_After_Construction='''
## Q1 — National Integration Start Delay (6-month window)

```sql
-- National Integration Start Delay After Construction: 6-month window
WITH pending_integration AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    pj_a_5175_construction_complete_finish::date AS construction_complete_date,
    CURRENT_DATE - pj_a_5175_construction_complete_finish::date AS days_pending
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE pj_a_5175_construction_complete_finish IS NOT NULL
    AND pj_a_5270_integration_start_finish   IS NULL
    AND pj_a_5175_construction_complete_finish::date
        >= CURRENT_DATE - INTERVAL '6 months'
)
SELECT
  COUNT(DISTINCT pj_project_id)               AS sites_pending_integration,
  ROUND(AVG(days_pending), 1)                 AS avg_days_pending,
  MAX(days_pending)                           AS max_days_pending,
  COUNT(*) FILTER (WHERE days_pending = 0)    AS same_day_pending,
  COUNT(*) FILTER (WHERE days_pending BETWEEN 1 AND 7)   AS within_1_week,
  COUNT(*) FILTER (WHERE days_pending BETWEEN 8 AND 30)  AS within_1_month,
  COUNT(*) FILTER (WHERE days_pending > 30)              AS over_1_month
FROM pending_integration;
```

## Q2 — Region Integration Start Delay (4-month window)

```sql
-- Region-level Integration Start Delay After Construction: 4-month window
WITH pending_integration AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    pj_a_5175_construction_complete_finish::date AS construction_complete_date,
    CURRENT_DATE - pj_a_5175_construction_complete_finish::date AS days_pending
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE pj_a_5175_construction_complete_finish IS NOT NULL
    AND pj_a_5270_integration_start_finish   IS NULL
    AND pj_a_5175_construction_complete_finish::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND rgn_region IS NOT NULL
    -- AND rgn_region = :region    -- uncomment when region is the entry point
)
SELECT
  rgn_region                                             AS region,
  COUNT(DISTINCT pj_project_id)                          AS sites_pending_integration,
  ROUND(AVG(days_pending), 1)                            AS avg_days_pending,
  MAX(days_pending)                                      AS max_days_pending,
  COUNT(*) FILTER (WHERE days_pending > 30)              AS over_1_month
FROM pending_integration
GROUP BY rgn_region
ORDER BY sites_pending_integration DESC NULLS LAST;
```

## Q3 — Market Integration Start Delay (4-month window)

```sql
-- Market-level Integration Start Delay After Construction: 4-month window
WITH pending_integration AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    pj_a_5175_construction_complete_finish::date AS construction_complete_date,
    CURRENT_DATE - pj_a_5175_construction_complete_finish::date AS days_pending
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE pj_a_5175_construction_complete_finish IS NOT NULL
    AND pj_a_5270_integration_start_finish   IS NULL
    AND pj_a_5175_construction_complete_finish::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m_market IS NOT NULL
    -- AND rgn_region = :region    -- when drilling from Region
    -- AND m_market   = :market    -- when market is the entry point
)
SELECT
  rgn_region                                             AS region,
  m_area                                                 AS area,
  m_market                                               AS market,
  COUNT(DISTINCT pj_project_id)                          AS sites_pending_integration,
  ROUND(AVG(days_pending), 1)                            AS avg_days_pending,
  MAX(days_pending)                                      AS max_days_pending,
  COUNT(*) FILTER (WHERE days_pending > 30)              AS over_1_month
FROM pending_integration
GROUP BY rgn_region, m_area, m_market
ORDER BY sites_pending_integration DESC NULLS LAST;
```

## Q4 — GC / Vendor Integration Start Delay (4-month window)

```sql
-- GC / Vendor-level Integration Start Delay After Construction: 4-month window
WITH pending_integration AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    pj_a_5175_construction_complete_finish::date AS construction_complete_date,
    CURRENT_DATE - pj_a_5175_construction_complete_finish::date AS days_pending
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE pj_a_5175_construction_complete_finish IS NOT NULL
    AND pj_a_5270_integration_start_finish   IS NULL
    AND pj_a_5175_construction_complete_finish::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND construction_gc IS NOT NULL
    AND m_market        IS NOT NULL
    -- AND rgn_region      = :region    -- when drilling from Region
    -- AND m_market        = :market    -- when drilling from Market
    -- AND construction_gc = :gc        -- when GC is the entry point
)
SELECT
  m_market                                               AS market,
  construction_gc                                        AS gc,
  COUNT(DISTINCT pj_project_id)                          AS sites_pending_integration,
  ROUND(AVG(days_pending), 1)                            AS avg_days_pending,
  MAX(days_pending)                                      AS max_days_pending,
  COUNT(*) FILTER (WHERE days_pending > 30)              AS over_1_month
FROM pending_integration
GROUP BY m_market, construction_gc
ORDER BY sites_pending_integration DESC NULLS LAST;
```
'''