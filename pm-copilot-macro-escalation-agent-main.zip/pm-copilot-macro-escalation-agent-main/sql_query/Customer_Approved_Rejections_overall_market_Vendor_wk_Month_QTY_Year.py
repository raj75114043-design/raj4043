Customer_Approved_Rejections_overall_market_Vendor_wk_Month_QTY_Year = '''
## Q1 — National Customer Approval/Rejection (6-month window)

```sql
-- National Customer Approval/Rejection: 6-month window
WITH decisions AS (
  SELECT
    macro.rgn_region, macro.m_area, macro.m_market, macro.construction_gc,
    ndpc.formanswerstatus,
    ndpc.formanswerdate::date AS answer_date
  FROM pwc_macro_staging_schema.stg_services_ndpc_answers_daily_from_sdb ndpc
  LEFT JOIN pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined macro
    ON macro.scop_title = ndpc.sessiontitle
  WHERE ndpc.formanswerstatus IN ('6', '7')
    AND ndpc.formanswerdate::date >= CURRENT_DATE - INTERVAL '6 months'
    AND COALESCE(LOWER(TRIM(ndpc.isdeleted::text)), '') <> 'true'
    -- AND macro.smp_name = :smp_name   -- e.g. 'NTM'
)
SELECT
  COUNT(*) FILTER (WHERE formanswerstatus = '6')                      AS accepted_count,
  COUNT(*) FILTER (WHERE formanswerstatus = '7')                      AS rejected_count,
  COUNT(*)                                                            AS total_decisions,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '6') / NULLIF(COUNT(*), 0), 2) AS approved_pct,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '7') / NULLIF(COUNT(*), 0), 2) AS rejected_pct
FROM decisions;
```

## Q2 — Region (4-month)

```sql
-- Region-level Customer Approval/Rejection: 4-month window
WITH decisions AS (
  SELECT
    macro.rgn_region, macro.m_area, macro.m_market, macro.construction_gc,
    ndpc.formanswerstatus,
    ndpc.formanswerdate::date AS answer_date
  FROM pwc_macro_staging_schema.stg_services_ndpc_answers_daily_from_sdb ndpc
  LEFT JOIN pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined macro
    ON macro.scop_title = ndpc.sessiontitle
  WHERE ndpc.formanswerstatus IN ('6', '7')
    AND ndpc.formanswerdate::date >= CURRENT_DATE - INTERVAL '4 months'
    AND COALESCE(LOWER(TRIM(ndpc.isdeleted::text)), '') <> 'true'
    AND macro.rgn_region IS NOT NULL
    -- AND macro.rgn_region = :region
    -- AND macro.smp_name   = :smp_name
)
SELECT
  rgn_region                                                          AS region,
  COUNT(*) FILTER (WHERE formanswerstatus = '6')                      AS accepted_count,
  COUNT(*) FILTER (WHERE formanswerstatus = '7')                      AS rejected_count,
  COUNT(*)                                                            AS total_decisions,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '6') / NULLIF(COUNT(*), 0), 2) AS approved_pct,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '7') / NULLIF(COUNT(*), 0), 2) AS rejected_pct
FROM decisions
GROUP BY rgn_region
ORDER BY rejected_pct DESC NULLS LAST;
```

## Q3 — Market (4-month)

```sql
-- Market-level Customer Approval/Rejection: 4-month window
WITH decisions AS (
  SELECT
    macro.rgn_region, macro.m_area, macro.m_market, macro.construction_gc,
    ndpc.formanswerstatus,
    ndpc.formanswerdate::date AS answer_date
  FROM pwc_macro_staging_schema.stg_services_ndpc_answers_daily_from_sdb ndpc
  LEFT JOIN pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined macro
    ON macro.scop_title = ndpc.sessiontitle
  WHERE ndpc.formanswerstatus IN ('6', '7')
    AND ndpc.formanswerdate::date >= CURRENT_DATE - INTERVAL '4 months'
    AND COALESCE(LOWER(TRIM(ndpc.isdeleted::text)), '') <> 'true'
    AND macro.m_market IS NOT NULL
    -- AND macro.rgn_region = :region
    -- AND macro.m_market   = :market
    -- AND macro.smp_name   = :smp_name
)
SELECT
  rgn_region                                                          AS region,
  m_area                                                              AS area,
  m_market                                                            AS market,
  COUNT(*) FILTER (WHERE formanswerstatus = '6')                      AS accepted_count,
  COUNT(*) FILTER (WHERE formanswerstatus = '7')                      AS rejected_count,
  COUNT(*)                                                            AS total_decisions,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '6') / NULLIF(COUNT(*), 0), 2) AS approved_pct,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '7') / NULLIF(COUNT(*), 0), 2) AS rejected_pct
FROM decisions
GROUP BY rgn_region, m_area, m_market
ORDER BY rejected_pct DESC NULLS LAST;
```

## Q4 — GC / Vendor (4-month)

```sql
-- GC / Vendor-level Customer Approval/Rejection: 4-month window
WITH decisions AS (
  SELECT
    macro.rgn_region, macro.m_area, macro.m_market, macro.construction_gc,
    ndpc.formanswerstatus,
    ndpc.formanswerdate::date AS answer_date
  FROM pwc_macro_staging_schema.stg_services_ndpc_answers_daily_from_sdb ndpc
  LEFT JOIN pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined macro
    ON macro.scop_title = ndpc.sessiontitle
  WHERE ndpc.formanswerstatus IN ('6', '7')
    AND ndpc.formanswerdate::date >= CURRENT_DATE - INTERVAL '4 months'
    AND COALESCE(LOWER(TRIM(ndpc.isdeleted::text)), '') <> 'true'
    AND macro.construction_gc IS NOT NULL
    AND macro.m_market        IS NOT NULL
    -- AND macro.rgn_region      = :region
    -- AND macro.m_market        = :market
    -- AND macro.construction_gc = :gc
    -- AND macro.smp_name        = :smp_name
)
SELECT
  m_market                                                            AS market,
  construction_gc                                                     AS gc,
  COUNT(*) FILTER (WHERE formanswerstatus = '6')                      AS accepted_count,
  COUNT(*) FILTER (WHERE formanswerstatus = '7')                      AS rejected_count,
  COUNT(*)                                                            AS total_decisions,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '6') / NULLIF(COUNT(*), 0), 2) AS approved_pct,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '7') / NULLIF(COUNT(*), 0), 2) AS rejected_pct
FROM decisions
GROUP BY m_market, construction_gc
ORDER BY rejected_pct DESC NULLS LAST;
```

---

### Q5 — Weekly

```sql
-- Weekly Customer Approval/Rejection: 12-month window
WITH decisions AS (
  SELECT
    DATE_TRUNC('week', ndpc.formanswerdate::date)::date AS week_start,
    ndpc.formanswerstatus
  FROM pwc_macro_staging_schema.stg_services_ndpc_answers_daily_from_sdb ndpc
  LEFT JOIN pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined macro
    ON macro.scop_title = ndpc.sessiontitle
  WHERE ndpc.formanswerstatus IN ('6', '7')
    AND ndpc.formanswerdate::date >= CURRENT_DATE - INTERVAL '12 months'
    AND COALESCE(LOWER(TRIM(ndpc.isdeleted::text)), '') <> 'true'
    -- AND macro.m_market        = :market
    -- AND macro.construction_gc = :gc
    -- AND macro.smp_name        = :smp_name
)
SELECT
  week_start,
  EXTRACT(ISOYEAR FROM week_start)::int AS iso_year,
  EXTRACT(WEEK    FROM week_start)::int AS iso_week,
  COUNT(*) FILTER (WHERE formanswerstatus = '6')                      AS accepted_count,
  COUNT(*) FILTER (WHERE formanswerstatus = '7')                      AS rejected_count,
  COUNT(*)                                                            AS total_decisions,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '6') / NULLIF(COUNT(*), 0), 2) AS approved_pct,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '7') / NULLIF(COUNT(*), 0), 2) AS rejected_pct
FROM decisions
GROUP BY week_start
ORDER BY week_start DESC;
```

### Q6 — Monthly

```sql
-- Monthly Customer Approval/Rejection: 12-month window
WITH decisions AS (
  SELECT
    DATE_TRUNC('month', ndpc.formanswerdate::date)::date AS month_start,
    ndpc.formanswerstatus
  FROM pwc_macro_staging_schema.stg_services_ndpc_answers_daily_from_sdb ndpc
  LEFT JOIN pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined macro
    ON macro.scop_title = ndpc.sessiontitle
  WHERE ndpc.formanswerstatus IN ('6', '7')
    AND ndpc.formanswerdate::date >= CURRENT_DATE - INTERVAL '12 months'
    AND COALESCE(LOWER(TRIM(ndpc.isdeleted::text)), '') <> 'true'
    -- AND macro.m_market        = :market
    -- AND macro.construction_gc = :gc
    -- AND macro.smp_name        = :smp_name
)
SELECT
  month_start,
  TO_CHAR(month_start, 'YYYY-MM')                                     AS year_month,
  COUNT(*) FILTER (WHERE formanswerstatus = '6')                      AS accepted_count,
  COUNT(*) FILTER (WHERE formanswerstatus = '7')                      AS rejected_count,
  COUNT(*)                                                            AS total_decisions,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '6') / NULLIF(COUNT(*), 0), 2) AS approved_pct,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '7') / NULLIF(COUNT(*), 0), 2) AS rejected_pct
FROM decisions
GROUP BY month_start
ORDER BY month_start DESC;
```

### Q7 — Quarterly


```sql
-- Quarterly Customer Approval/Rejection: 24-month window (8 quarters)
WITH decisions AS (
  SELECT
    DATE_TRUNC('quarter', ndpc.formanswerdate::date)::date AS quarter_start,
    ndpc.formanswerstatus
  FROM pwc_macro_staging_schema.stg_services_ndpc_answers_daily_from_sdb ndpc
  LEFT JOIN pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined macro
    ON macro.scop_title = ndpc.sessiontitle
  WHERE ndpc.formanswerstatus IN ('6', '7')
    AND ndpc.formanswerdate::date >= CURRENT_DATE - INTERVAL '24 months'
    AND COALESCE(LOWER(TRIM(ndpc.isdeleted::text)), '') <> 'true'
    -- AND macro.m_market        = :market
    -- AND macro.construction_gc = :gc
    -- AND macro.smp_name        = :smp_name
)
SELECT
  quarter_start,
  EXTRACT(YEAR    FROM quarter_start)::int                            AS year,
  'Q' || EXTRACT(QUARTER FROM quarter_start)::int                     AS quarter,
  COUNT(*) FILTER (WHERE formanswerstatus = '6')                      AS accepted_count,
  COUNT(*) FILTER (WHERE formanswerstatus = '7')                      AS rejected_count,
  COUNT(*)                                                            AS total_decisions,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '6') / NULLIF(COUNT(*), 0), 2) AS approved_pct,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '7') / NULLIF(COUNT(*), 0), 2) AS rejected_pct
FROM decisions
GROUP BY quarter_start
ORDER BY quarter_start DESC;
```

### Q8 — Yearly

```sql
-- Yearly Customer Approval/Rejection: no window cap
WITH decisions AS (
  SELECT
    DATE_TRUNC('year', ndpc.formanswerdate::date)::date AS year_start,
    ndpc.formanswerstatus
  FROM pwc_macro_staging_schema.stg_services_ndpc_answers_daily_from_sdb ndpc
  LEFT JOIN pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined macro
    ON macro.scop_title = ndpc.sessiontitle
  WHERE ndpc.formanswerstatus IN ('6', '7')
    AND ndpc.formanswerdate IS NOT NULL
    AND COALESCE(LOWER(TRIM(ndpc.isdeleted::text)), '') <> 'true'
    -- AND macro.m_market        = :market
    -- AND macro.construction_gc = :gc
    -- AND macro.smp_name        = :smp_name
)
SELECT
  EXTRACT(YEAR FROM year_start)::int                                  AS year,
  COUNT(*) FILTER (WHERE formanswerstatus = '6')                      AS accepted_count,
  COUNT(*) FILTER (WHERE formanswerstatus = '7')                      AS rejected_count,
  COUNT(*)                                                            AS total_decisions,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '6') / NULLIF(COUNT(*), 0), 2) AS approved_pct,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '7') / NULLIF(COUNT(*), 0), 2) AS rejected_pct
FROM decisions
GROUP BY year_start
ORDER BY year_start DESC;
```
'''