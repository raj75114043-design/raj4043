No_of_sites_Civil_work_WIP_MB__Only_Magenta_Tracker = '''

## Q1 — National Civil WIP Count (6-month window)

```sql
-- National: Sites with Civil work WIP (Magenta Tracker), 6-month window on civil start
SELECT
  COUNT(DISTINCT pj_project_id) AS wip_projects,
  COUNT(DISTINCT s_site_id)     AS wip_sites
FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
WHERE pj_a_4250_civil_construction_start_finish    IS NOT NULL
  AND pj_a_4750_civil_construction_complete_finish IS NULL
  AND pj_a_4250_civil_construction_start_finish::date
      >= CURRENT_DATE - INTERVAL '6 months';
```

## Q2 — Region Civil WIP Count (4-month window)

```sql
-- Region-level Civil WIP (Magenta Tracker): 4-month window
SELECT
  rgn_region                     AS region,
  COUNT(DISTINCT pj_project_id)  AS wip_projects,
  COUNT(DISTINCT s_site_id)      AS wip_sites
FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
WHERE pj_a_4250_civil_construction_start_finish    IS NOT NULL
  AND pj_a_4750_civil_construction_complete_finish IS NULL
  AND pj_a_4250_civil_construction_start_finish::date
      >= CURRENT_DATE - INTERVAL '4 months'
  AND rgn_region IS NOT NULL
  -- AND rgn_region = :region    -- uncomment when region is the entry point
GROUP BY rgn_region
ORDER BY wip_sites DESC NULLS LAST;
```

## Q3 — Market Civil WIP Count (4-month window)

```sql
-- Market-level Civil WIP (Magenta Tracker): 4-month window
SELECT
  rgn_region                     AS region,
  m_area                         AS area,
  m_market                       AS market,
  COUNT(DISTINCT pj_project_id)  AS wip_projects,
  COUNT(DISTINCT s_site_id)      AS wip_sites
FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
WHERE pj_a_4250_civil_construction_start_finish    IS NOT NULL
  AND pj_a_4750_civil_construction_complete_finish IS NULL
  AND pj_a_4250_civil_construction_start_finish::date
      >= CURRENT_DATE - INTERVAL '4 months'
  AND m_market IS NOT NULL
  -- AND rgn_region = :region    -- when drilling from Region
  -- AND m_market   = :market    -- when market is the entry point
GROUP BY rgn_region, m_area, m_market
ORDER BY wip_sites DESC NULLS LAST;
```

## Q4 — GC / Vendor Civil WIP Count (4-month window)

```sql
-- GC / Vendor-level Civil WIP (Magenta Tracker): 4-month window
SELECT
  m_market                       AS market,
  construction_gc                AS gc,
  COUNT(DISTINCT pj_project_id)  AS wip_projects,
  COUNT(DISTINCT s_site_id)      AS wip_sites
FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
WHERE pj_a_4250_civil_construction_start_finish    IS NOT NULL
  AND pj_a_4750_civil_construction_complete_finish IS NULL
  AND pj_a_4250_civil_construction_start_finish::date
      >= CURRENT_DATE - INTERVAL '4 months'
  AND construction_gc IS NOT NULL
  AND m_market        IS NOT NULL
  -- AND rgn_region      = :region   -- when drilling from Region
  -- AND m_market        = :market   -- when drilling from Market
  -- AND construction_gc = :gc       -- when GC is the entry point
GROUP BY m_market, construction_gc
ORDER BY wip_sites DESC NULLS LAST;
```


'''
