Civil_Cx_Start_to_Civil_Cx_Complete_Cycle_Time = '''

## Q1 — National Civil Cx Cycle Time (6-month window)

```sql
-- National Civil Cx Start → Complete Cycle Time for NTM: 6-month window
WITH cycle_base AS (
  SELECT
    rgn_region,
    m_area,
    m_market,
    construction_gc,
    pj_project_id,
    ms_1549_civil_construction_start_actual::date         AS civil_start_dt,
    ms_1551_civil_construction_complete_actual_date::date AS civil_complete_dt,
    (ms_1551_civil_construction_complete_actual_date::date
     - ms_1549_civil_construction_start_actual::date)     AS cycle_time_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name = 'NTM'
    AND smp_status = 'Active'
    AND ntm_project_type NOT IN (
          'E2E06 - NSD Cx Mgmt',
          'E2E07 - OL/MOD Cx Mgmt'
        )
    AND ms_1549_civil_construction_start_actual IS NOT NULL
    AND ms_1551_civil_construction_complete_actual_date IS NOT NULL
    AND ms_1551_civil_construction_complete_actual_date::date
        >= CURRENT_DATE - INTERVAL '6 months'
    AND ms_1551_civil_construction_complete_actual_date::date
        >= ms_1549_civil_construction_start_actual::date
)
SELECT
  COUNT(DISTINCT pj_project_id)                                        AS projects_count,
  COUNT(*)                                                             AS records_count,
  ROUND(AVG(cycle_time_days)::numeric, 2)                              AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_time_days)         AS median_cycle_days,
  MIN(cycle_time_days)                                                 AS min_cycle_days,
  MAX(cycle_time_days)                                                 AS max_cycle_days
FROM cycle_base;
```

## Q2 — Region Civil Cx Cycle Time (4-month window)

```sql
-- Region-level Civil Cx Cycle Time for NTM: 4-month window
WITH cycle_base AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc, pj_project_id,
    (ms_1551_civil_construction_complete_actual_date::date
     - ms_1549_civil_construction_start_actual::date) AS cycle_time_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name = 'NTM'
    AND smp_status = 'Active'
    AND ntm_project_type NOT IN (
          'E2E06 - NSD Cx Mgmt',
          'E2E07 - OL/MOD Cx Mgmt'
        )
    AND ms_1549_civil_construction_start_actual IS NOT NULL
    AND ms_1551_civil_construction_complete_actual_date IS NOT NULL
    AND ms_1551_civil_construction_complete_actual_date::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND ms_1551_civil_construction_complete_actual_date::date
        >= ms_1549_civil_construction_start_actual::date
    AND rgn_region IS NOT NULL
    -- AND rgn_region = :region    -- uncomment when region is the entry point
)
SELECT
  rgn_region                                                           AS region,
  COUNT(DISTINCT pj_project_id)                                        AS projects_count,
  COUNT(*)                                                             AS records_count,
  ROUND(AVG(cycle_time_days)::numeric, 2)                              AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_time_days)         AS median_cycle_days,
  MIN(cycle_time_days)                                                 AS min_cycle_days,
  MAX(cycle_time_days)                                                 AS max_cycle_days
FROM cycle_base
GROUP BY rgn_region
ORDER BY avg_cycle_days DESC NULLS LAST;
```

## Q3 — Market Civil Cx Cycle Time (4-month window)

```sql
-- Market-level Civil Cx Cycle Time for NTM: 4-month window
WITH cycle_base AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc, pj_project_id,
    (ms_1551_civil_construction_complete_actual_date::date
     - ms_1549_civil_construction_start_actual::date) AS cycle_time_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name = 'NTM'
    AND smp_status = 'Active'
    AND ntm_project_type NOT IN (
          'E2E06 - NSD Cx Mgmt',
          'E2E07 - OL/MOD Cx Mgmt'
        )
    AND ms_1549_civil_construction_start_actual IS NOT NULL
    AND ms_1551_civil_construction_complete_actual_date IS NOT NULL
    AND ms_1551_civil_construction_complete_actual_date::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND ms_1551_civil_construction_complete_actual_date::date
        >= ms_1549_civil_construction_start_actual::date
    AND m_market IS NOT NULL
    -- AND rgn_region = :region    -- when drilling from Region
    -- AND m_market   = :market    -- when market is the entry point
)
SELECT
  rgn_region                                                           AS region,
  m_area                                                               AS area,
  m_market                                                             AS market,
  COUNT(DISTINCT pj_project_id)                                        AS projects_count,
  COUNT(*)                                                             AS records_count,
  ROUND(AVG(cycle_time_days)::numeric, 2)                              AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_time_days)         AS median_cycle_days,
  MIN(cycle_time_days)                                                 AS min_cycle_days,
  MAX(cycle_time_days)                                                 AS max_cycle_days
FROM cycle_base
GROUP BY rgn_region, m_area, m_market
ORDER BY avg_cycle_days DESC NULLS LAST;
```

## Q4 — GC / Vendor Civil Cx Cycle Time (4-month window)

```sql
-- GC / Vendor-level Civil Cx Cycle Time for NTM: 4-month window
WITH cycle_base AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc, pj_project_id,
    (ms_1551_civil_construction_complete_actual_date::date
     - ms_1549_civil_construction_start_actual::date) AS cycle_time_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name = 'NTM'
    AND smp_status = 'Active'
    AND ntm_project_type NOT IN (
          'E2E06 - NSD Cx Mgmt',
          'E2E07 - OL/MOD Cx Mgmt'
        )
    AND ms_1549_civil_construction_start_actual IS NOT NULL
    AND ms_1551_civil_construction_complete_actual_date IS NOT NULL
    AND ms_1551_civil_construction_complete_actual_date::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND ms_1551_civil_construction_complete_actual_date::date
        >= ms_1549_civil_construction_start_actual::date
    AND construction_gc IS NOT NULL
    AND m_market        IS NOT NULL
    -- AND rgn_region      = :region    -- when drilling from Region
    -- AND m_market        = :market    -- when drilling from Market
    -- AND construction_gc = :gc        -- when GC is the entry point
)
SELECT
  m_market                                                             AS market,
  construction_gc                                                      AS gc,
  COUNT(DISTINCT pj_project_id)                                        AS projects_count,
  COUNT(*)                                                             AS records_count,
  ROUND(AVG(cycle_time_days)::numeric, 2)                              AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_time_days)         AS median_cycle_days,
  MIN(cycle_time_days)                                                 AS min_cycle_days,
  MAX(cycle_time_days)                                                 AS max_cycle_days
FROM cycle_base
GROUP BY m_market, construction_gc
ORDER BY avg_cycle_days DESC NULLS LAST;
```
'''