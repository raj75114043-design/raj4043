Building_Permit_Approval_Cycle_Time = '''

## Q1 — National Building Permit Cycle Time (6-month window)

```sql
-- National Building Permit Approval Cycle Time: 6-month window (anchored on approval date)
WITH permit_cycles AS (
  SELECT
    m.rgn_region,
    m.m_area,
    m.m_market,
    m.construction_gc,
    m.pj_project_id,
    m.s_site_id,
    m.pj_a_3650_ran_building_permit_applied_finish::date  AS applied_date,
    m.pj_a_3675_ran_building_permit_approved_finish::date AS approved_date,
    (m.pj_a_3675_ran_building_permit_approved_finish::date
     - m.pj_a_3650_ran_building_permit_applied_finish::date)         AS cycle_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined m
  -- INNER JOIN pwc_macro_staging_schema.pm_tracker p
  --   ON p.project_id = m.pj_project_id        -- enable if pm_tracker is a required filter
  WHERE m.pj_a_3650_ran_building_permit_applied_finish  IS NOT NULL
    AND m.pj_a_3675_ran_building_permit_approved_finish IS NOT NULL
    AND m.pj_a_3675_ran_building_permit_approved_finish::date
        >= CURRENT_DATE - INTERVAL '6 months'
    AND m.pj_a_3675_ran_building_permit_approved_finish::date
        >= m.pj_a_3650_ran_building_permit_applied_finish::date      -- sanity: approved after applied
)
SELECT
  COUNT(*)                                                            AS projects_measured,
  ROUND(AVG(cycle_days)::numeric, 2)                                  AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days)             AS median_cycle_days,
  MIN(cycle_days)                                                     AS min_cycle_days,
  MAX(cycle_days)                                                     AS max_cycle_days
FROM permit_cycles;
```

## Q2 — Region Building Permit Cycle Time (4-month window)

```sql
-- Region-level Building Permit Approval Cycle Time: 4-month window
WITH permit_cycles AS (
  SELECT
    m.rgn_region, m.m_area, m.m_market, m.construction_gc,
    m.pj_project_id, m.s_site_id,
    (m.pj_a_3675_ran_building_permit_approved_finish::date
     - m.pj_a_3650_ran_building_permit_applied_finish::date) AS cycle_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined m
  -- INNER JOIN pwc_macro_staging_schema.pm_tracker p ON p.project_id = m.pj_project_id
  WHERE m.pj_a_3650_ran_building_permit_applied_finish  IS NOT NULL
    AND m.pj_a_3675_ran_building_permit_approved_finish IS NOT NULL
    AND m.pj_a_3675_ran_building_permit_approved_finish::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m.pj_a_3675_ran_building_permit_approved_finish::date
        >= m.pj_a_3650_ran_building_permit_applied_finish::date
    AND m.rgn_region IS NOT NULL
    -- AND m.rgn_region = :region    -- uncomment when region is the entry point
)
SELECT
  rgn_region                                                          AS region,
  COUNT(*)                                                            AS projects_measured,
  ROUND(AVG(cycle_days)::numeric, 2)                                  AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days)             AS median_cycle_days,
  MIN(cycle_days)                                                     AS min_cycle_days,
  MAX(cycle_days)                                                     AS max_cycle_days
FROM permit_cycles
GROUP BY rgn_region
ORDER BY avg_cycle_days DESC NULLS LAST;
```

## Q3 — Market Building Permit Cycle Time (4-month window)

```sql
-- Market-level Building Permit Approval Cycle Time: 4-month window
WITH permit_cycles AS (
  SELECT
    m.rgn_region, m.m_area, m.m_market, m.construction_gc,
    m.pj_project_id, m.s_site_id,
    (m.pj_a_3675_ran_building_permit_approved_finish::date
     - m.pj_a_3650_ran_building_permit_applied_finish::date) AS cycle_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined m
  -- INNER JOIN pwc_macro_staging_schema.pm_tracker p ON p.project_id = m.pj_project_id
  WHERE m.pj_a_3650_ran_building_permit_applied_finish  IS NOT NULL
    AND m.pj_a_3675_ran_building_permit_approved_finish IS NOT NULL
    AND m.pj_a_3675_ran_building_permit_approved_finish::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m.pj_a_3675_ran_building_permit_approved_finish::date
        >= m.pj_a_3650_ran_building_permit_applied_finish::date
    AND m.m_market IS NOT NULL
    -- AND m.rgn_region = :region    -- when drilling from Region
    -- AND m.m_market   = :market    -- when market is the entry point
)
SELECT
  rgn_region                                                          AS region,
  m_area                                                              AS area,
  m_market                                                            AS market,
  COUNT(*)                                                            AS projects_measured,
  ROUND(AVG(cycle_days)::numeric, 2)                                  AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days)             AS median_cycle_days,
  MIN(cycle_days)                                                     AS min_cycle_days,
  MAX(cycle_days)                                                     AS max_cycle_days
FROM permit_cycles
GROUP BY rgn_region, m_area, m_market
ORDER BY avg_cycle_days DESC NULLS LAST;
```

## Q4 — GC / Vendor Building Permit Cycle Time (4-month window)

```sql
-- GC / Vendor-level Building Permit Approval Cycle Time: 4-month window
WITH permit_cycles AS (
  SELECT
    m.rgn_region, m.m_area, m.m_market, m.construction_gc,
    m.pj_project_id, m.s_site_id,
    (m.pj_a_3675_ran_building_permit_approved_finish::date
     - m.pj_a_3650_ran_building_permit_applied_finish::date) AS cycle_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined m
  -- INNER JOIN pwc_macro_staging_schema.pm_tracker p ON p.project_id = m.pj_project_id
  WHERE m.pj_a_3650_ran_building_permit_applied_finish  IS NOT NULL
    AND m.pj_a_3675_ran_building_permit_approved_finish IS NOT NULL
    AND m.pj_a_3675_ran_building_permit_approved_finish::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m.pj_a_3675_ran_building_permit_approved_finish::date
        >= m.pj_a_3650_ran_building_permit_applied_finish::date
    AND m.construction_gc IS NOT NULL
    AND m.m_market        IS NOT NULL
    -- AND m.rgn_region      = :region    -- when drilling from Region
    -- AND m.m_market        = :market    -- when drilling from Market
    -- AND m.construction_gc = :gc        -- when GC is the entry point
)
SELECT
  m_market                                                            AS market,
  construction_gc                                                     AS gc,
  COUNT(*)                                                            AS projects_measured,
  ROUND(AVG(cycle_days)::numeric, 2)                                  AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days)             AS median_cycle_days,
  MIN(cycle_days)                                                     AS min_cycle_days,
  MAX(cycle_days)                                                     AS max_cycle_days
FROM permit_cycles
GROUP BY m_market, construction_gc
ORDER BY avg_cycle_days DESC NULLS LAST;
```
'''