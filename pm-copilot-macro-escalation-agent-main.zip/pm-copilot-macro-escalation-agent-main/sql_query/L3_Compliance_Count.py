L3_Compliance_Count = '''
## Q1 — National L3 Compliance Count (6-month window)

```sql
-- National L3 Compliance Count: 6-month window
WITH l3_events AS (
  SELECT
    region, market, gc_name, smp_id,
    TRIM(UPPER(level_3_status)) AS l3_status
  FROM pwc_macro_staging_schema.stg_tmo_hse_daily_tracker_v0_1
  WHERE review_date IS NOT NULL
    AND review_date::date >= CURRENT_DATE - INTERVAL '6 months'
    AND level_3_status IS NOT NULL
    -- AND smp_name = :smp_name   -- e.g. 'AHLOB Modernization'
)
SELECT
  COUNT(*) FILTER (WHERE l3_status = 'RESOLVED')                        AS l3_resolved_count,
  COUNT(*) FILTER (WHERE l3_status = 'NOT RESOLVED')                    AS l3_not_resolved_count,
  COUNT(*) FILTER (WHERE l3_status IN ('RESOLVED', 'NOT RESOLVED'))     AS total_l3_decisions,
  ROUND(
    100.0 * COUNT(*) FILTER (WHERE l3_status = 'RESOLVED')
          / NULLIF(COUNT(*) FILTER (WHERE l3_status IN ('RESOLVED', 'NOT RESOLVED')), 0),
    2
  )                                                                     AS l3_compliance_pct
FROM l3_events;
```

## Q2 — Region L3 Compliance Count (4-month window)

```sql
-- Region-level L3 Compliance Count: 4-month window
WITH l3_events AS (
  SELECT
    region, market, gc_name, smp_id,
    TRIM(UPPER(level_3_status)) AS l3_status
  FROM pwc_macro_staging_schema.stg_tmo_hse_daily_tracker_v0_1
  WHERE review_date IS NOT NULL
    AND review_date::date >= CURRENT_DATE - INTERVAL '4 months'
    AND level_3_status IS NOT NULL
    AND region IS NOT NULL
    -- AND region   = :region    -- uncomment when region is the entry point
    -- AND smp_name = :smp_name
)
SELECT
  region,
  COUNT(*) FILTER (WHERE l3_status = 'RESOLVED')                        AS l3_resolved_count,
  COUNT(*) FILTER (WHERE l3_status = 'NOT RESOLVED')                    AS l3_not_resolved_count,
  COUNT(*) FILTER (WHERE l3_status IN ('RESOLVED', 'NOT RESOLVED'))     AS total_l3_decisions,
  ROUND(
    100.0 * COUNT(*) FILTER (WHERE l3_status = 'RESOLVED')
          / NULLIF(COUNT(*) FILTER (WHERE l3_status IN ('RESOLVED', 'NOT RESOLVED')), 0),
    2
  )                                                                     AS l3_compliance_pct
FROM l3_events
GROUP BY region
ORDER BY l3_resolved_count DESC NULLS LAST;
```

## Q3 — Market L3 Compliance Count (4-month window)

```sql
-- Market-level L3 Compliance Count: 4-month window
WITH l3_events AS (
  SELECT
    region, market, gc_name, smp_id,
    TRIM(UPPER(level_3_status)) AS l3_status
  FROM pwc_macro_staging_schema.stg_tmo_hse_daily_tracker_v0_1
  WHERE review_date IS NOT NULL
    AND review_date::date >= CURRENT_DATE - INTERVAL '4 months'
    AND level_3_status IS NOT NULL
    AND market IS NOT NULL
    -- AND region   = :region    -- when drilling from Region
    -- AND market   = :market    -- when market is the entry point
    -- AND smp_name = :smp_name
)
SELECT
  region,
  market,
  COUNT(*) FILTER (WHERE l3_status = 'RESOLVED')                        AS l3_resolved_count,
  COUNT(*) FILTER (WHERE l3_status = 'NOT RESOLVED')                    AS l3_not_resolved_count,
  COUNT(*) FILTER (WHERE l3_status IN ('RESOLVED', 'NOT RESOLVED'))     AS total_l3_decisions,
  ROUND(
    100.0 * COUNT(*) FILTER (WHERE l3_status = 'RESOLVED')
          / NULLIF(COUNT(*) FILTER (WHERE l3_status IN ('RESOLVED', 'NOT RESOLVED')), 0),
    2
  )                                                                     AS l3_compliance_pct
FROM l3_events
GROUP BY region, market
ORDER BY l3_resolved_count DESC NULLS LAST;
```

## Q4 — GC / Vendor L3 Compliance Count (4-month window)

```sql
-- GC / Vendor-level L3 Compliance Count: 4-month window
WITH l3_events AS (
  SELECT
    region, market, gc_name, smp_id,
    TRIM(UPPER(level_3_status)) AS l3_status
  FROM pwc_macro_staging_schema.stg_tmo_hse_daily_tracker_v0_1
  WHERE review_date IS NOT NULL
    AND review_date::date >= CURRENT_DATE - INTERVAL '4 months'
    AND level_3_status IS NOT NULL
    AND gc_name IS NOT NULL
    AND market  IS NOT NULL
    -- AND region   = :region    -- when drilling from Region
    -- AND market   = :market    -- when drilling from Market
    -- AND gc_name  = :gc        -- when GC is the entry point
    -- AND smp_name = :smp_name
)
SELECT
  market,
  gc_name                                                               AS gc,
  COUNT(*) FILTER (WHERE l3_status = 'RESOLVED')                        AS l3_resolved_count,
  COUNT(*) FILTER (WHERE l3_status = 'NOT RESOLVED')                    AS l3_not_resolved_count,
  COUNT(*) FILTER (WHERE l3_status IN ('RESOLVED', 'NOT RESOLVED'))     AS total_l3_decisions,
  ROUND(
    100.0 * COUNT(*) FILTER (WHERE l3_status = 'RESOLVED')
          / NULLIF(COUNT(*) FILTER (WHERE l3_status IN ('RESOLVED', 'NOT RESOLVED')), 0),
    2
  )                                                                     AS l3_compliance_pct
FROM l3_events
GROUP BY market, gc_name
ORDER BY l3_resolved_count DESC NULLS LAST;
```
'''