Swap_FTR = '''
## Q1 — National Swap FTR (6-month window)

```sql
-- National Swap FTR for AHLOB Modernization: 6-month window
WITH swap_complete_sites AS (
  SELECT DISTINCT
    m.rgn_region,
    m.m_area,
    m.m_market,
    m.construction_gc,
    m.smp_id,
    m.s_site_id,
    m.pj_project_id,
    m.pj_a_5175_construction_complete_finish::date AS swap_actual_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined m
  WHERE m.smp_name = 'AHLOB Modernization'
    AND m.pj_a_5175_construction_complete_finish IS NOT NULL
    AND m.pj_a_5175_construction_complete_finish::date
        >= CURRENT_DATE - INTERVAL '6 months'
    AND m.smp_id IS NOT NULL
),
hse_entry_counts AS (
  SELECT
    smp_id,
    COUNT(*) AS entry_count
  FROM pwc_macro_staging_schema.stg_ndpd_hse_site_checklist
  WHERE smp_id IS NOT NULL
  GROUP BY smp_id
),
ftr_eval AS (
  SELECT
    s.*,
    COALESCE(h.entry_count, 0) AS hse_entry_count,
    CASE WHEN COALESCE(h.entry_count, 0) = 1 THEN 1 ELSE 0 END AS is_ftr
  FROM swap_complete_sites s
  LEFT JOIN hse_entry_counts h ON s.smp_id = h.smp_id
)
SELECT
  COUNT(*)                                                            AS total_swaps,
  SUM(is_ftr)                                                         AS ftr_success,
  COUNT(*) - SUM(is_ftr)                                              AS ftr_fail,
  ROUND(100.0 * SUM(is_ftr) / NULLIF(COUNT(*), 0), 2)                 AS swap_ftr_pct
FROM ftr_eval;
```

## Q2 — Region Swap FTR (4-month window)

```sql
-- Region-level Swap FTR for AHLOB Modernization: 4-month window
WITH swap_complete_sites AS (
  SELECT DISTINCT
    m.rgn_region, m.m_area, m.m_market, m.construction_gc,
    m.smp_id, m.s_site_id, m.pj_project_id,
    m.pj_a_5175_construction_complete_finish::date AS swap_actual_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined m
  WHERE m.smp_name = 'AHLOB Modernization'
    AND m.pj_a_5175_construction_complete_finish IS NOT NULL
    AND m.pj_a_5175_construction_complete_finish::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m.smp_id IS NOT NULL
    AND m.rgn_region IS NOT NULL
    -- AND m.rgn_region = :region    -- uncomment when region is the entry point
),
hse_entry_counts AS (
  SELECT smp_id, COUNT(*) AS entry_count
  FROM pwc_macro_staging_schema.stg_ndpd_hse_site_checklist
  WHERE smp_id IS NOT NULL
  GROUP BY smp_id
),
ftr_eval AS (
  SELECT s.*,
         COALESCE(h.entry_count, 0) AS hse_entry_count,
         CASE WHEN COALESCE(h.entry_count, 0) = 1 THEN 1 ELSE 0 END AS is_ftr
  FROM swap_complete_sites s
  LEFT JOIN hse_entry_counts h ON s.smp_id = h.smp_id
)
SELECT
  rgn_region                                                          AS region,
  COUNT(*)                                                            AS total_swaps,
  SUM(is_ftr)                                                         AS ftr_success,
  COUNT(*) - SUM(is_ftr)                                              AS ftr_fail,
  ROUND(100.0 * SUM(is_ftr) / NULLIF(COUNT(*), 0), 2)                 AS swap_ftr_pct
FROM ftr_eval
GROUP BY rgn_region
ORDER BY swap_ftr_pct ASC NULLS LAST;
```

## Q3 — Market Swap FTR (4-month window)

```sql
-- Market-level Swap FTR for AHLOB Modernization: 4-month window
WITH swap_complete_sites AS (
  SELECT DISTINCT
    m.rgn_region, m.m_area, m.m_market, m.construction_gc,
    m.smp_id, m.s_site_id, m.pj_project_id,
    m.pj_a_5175_construction_complete_finish::date AS swap_actual_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined m
  WHERE m.smp_name = 'AHLOB Modernization'
    AND m.pj_a_5175_construction_complete_finish IS NOT NULL
    AND m.pj_a_5175_construction_complete_finish::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m.smp_id IS NOT NULL
    AND m.m_market IS NOT NULL
    -- AND m.rgn_region = :region    -- when drilling from Region
    -- AND m.m_market   = :market    -- when market is the entry point
),
hse_entry_counts AS (
  SELECT smp_id, COUNT(*) AS entry_count
  FROM pwc_macro_staging_schema.stg_ndpd_hse_site_checklist
  WHERE smp_id IS NOT NULL
  GROUP BY smp_id
),
ftr_eval AS (
  SELECT s.*,
         COALESCE(h.entry_count, 0) AS hse_entry_count,
         CASE WHEN COALESCE(h.entry_count, 0) = 1 THEN 1 ELSE 0 END AS is_ftr
  FROM swap_complete_sites s
  LEFT JOIN hse_entry_counts h ON s.smp_id = h.smp_id
)
SELECT
  rgn_region                                                          AS region,
  m_area                                                              AS area,
  m_market                                                            AS market,
  COUNT(*)                                                            AS total_swaps,
  SUM(is_ftr)                                                         AS ftr_success,
  COUNT(*) - SUM(is_ftr)                                              AS ftr_fail,
  ROUND(100.0 * SUM(is_ftr) / NULLIF(COUNT(*), 0), 2)                 AS swap_ftr_pct
FROM ftr_eval
GROUP BY rgn_region, m_area, m_market
ORDER BY swap_ftr_pct ASC NULLS LAST;
```

## Q4 — GC / Vendor Swap FTR (4-month window)

```sql
-- GC / Vendor-level Swap FTR for AHLOB Modernization: 4-month window
WITH swap_complete_sites AS (
  SELECT DISTINCT
    m.rgn_region, m.m_area, m.m_market, m.construction_gc,
    m.smp_id, m.s_site_id, m.pj_project_id,
    m.pj_a_5175_construction_complete_finish::date AS swap_actual_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined m
  WHERE m.smp_name = 'AHLOB Modernization'
    AND m.pj_a_5175_construction_complete_finish IS NOT NULL
    AND m.pj_a_5175_construction_complete_finish::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m.smp_id IS NOT NULL
    AND m.construction_gc IS NOT NULL
    AND m.m_market        IS NOT NULL
    -- AND m.rgn_region      = :region    -- when drilling from Region
    -- AND m.m_market        = :market    -- when drilling from Market
    -- AND m.construction_gc = :gc        -- when GC is the entry point
),
hse_entry_counts AS (
  SELECT smp_id, COUNT(*) AS entry_count
  FROM pwc_macro_staging_schema.stg_ndpd_hse_site_checklist
  WHERE smp_id IS NOT NULL
  GROUP BY smp_id
),
ftr_eval AS (
  SELECT s.*,
         COALESCE(h.entry_count, 0) AS hse_entry_count,
         CASE WHEN COALESCE(h.entry_count, 0) = 1 THEN 1 ELSE 0 END AS is_ftr
  FROM swap_complete_sites s
  LEFT JOIN hse_entry_counts h ON s.smp_id = h.smp_id
)
SELECT
  m_market                                                            AS market,
  construction_gc                                                     AS gc,
  COUNT(*)                                                            AS total_swaps,
  SUM(is_ftr)                                                         AS ftr_success,
  COUNT(*) - SUM(is_ftr)                                              AS ftr_fail,
  ROUND(100.0 * SUM(is_ftr) / NULLIF(COUNT(*), 0), 2)                 AS swap_ftr_pct
FROM ftr_eval
GROUP BY m_market, construction_gc
ORDER BY swap_ftr_pct ASC NULLS LAST;
```
'''