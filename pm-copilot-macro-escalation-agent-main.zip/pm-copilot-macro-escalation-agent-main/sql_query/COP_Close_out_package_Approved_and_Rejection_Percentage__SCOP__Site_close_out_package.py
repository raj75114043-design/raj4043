COP_Close_out_package_Approved_and_Rejection_Percentage__SCOP__Site_close_out_package='''
## Q1 — National (6-month)

```sql
WITH cop_answers AS (
  SELECT
    macro.rgn_region, macro.m_area, macro.m_market, macro.construction_gc,
    ndpc.formanswerstatus
  FROM pwc_macro_staging_schema.stg_services_ndpc_answers_daily_from_sdb ndpc
  LEFT JOIN pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined macro
    ON macro.scop_title = ndpc.sessiontitle
  WHERE ndpc.formanswerstatus IN ('6', '7')
    AND ndpc.formanswerdate::date >= CURRENT_DATE - INTERVAL '6 months'
    AND COALESCE(LOWER(TRIM(ndpc.isdeleted::text)), '') <> 'true'
)
SELECT
  COUNT(*) FILTER (WHERE formanswerstatus = '6') AS accepted_count,
  COUNT(*) FILTER (WHERE formanswerstatus = '7') AS rejected_count,
  COUNT(*)                                       AS total_decisions,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '6') / NULLIF(COUNT(*), 0), 2) AS approved_pct,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '7') / NULLIF(COUNT(*), 0), 2) AS rejected_pct
FROM cop_answers;
```

## Q2 — Region (4-month)

```sql
WITH cop_answers AS (
  SELECT
    macro.rgn_region, macro.m_area, macro.m_market, macro.construction_gc,
    ndpc.formanswerstatus
  FROM pwc_macro_staging_schema.stg_services_ndpc_answers_daily_from_sdb ndpc
  LEFT JOIN pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined macro
    ON macro.scop_title = ndpc.sessiontitle
  WHERE ndpc.formanswerstatus IN ('6', '7')
    AND ndpc.formanswerdate::date >= CURRENT_DATE - INTERVAL '4 months'
    AND COALESCE(LOWER(TRIM(ndpc.isdeleted::text)), '') <> 'true'
    AND macro.rgn_region IS NOT NULL
    -- AND macro.rgn_region = :region
)
SELECT
  rgn_region AS region,
  COUNT(*) FILTER (WHERE formanswerstatus = '6') AS accepted_count,
  COUNT(*) FILTER (WHERE formanswerstatus = '7') AS rejected_count,
  COUNT(*) AS total_decisions,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '6') / NULLIF(COUNT(*), 0), 2) AS approved_pct,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '7') / NULLIF(COUNT(*), 0), 2) AS rejected_pct
FROM cop_answers
GROUP BY rgn_region
ORDER BY rejected_pct DESC NULLS LAST;
```

## Q3 — Market (4-month)

```sql
WITH cop_answers AS (
  SELECT
    macro.rgn_region, macro.m_area, macro.m_market, macro.construction_gc,
    ndpc.formanswerstatus
  FROM pwc_macro_staging_schema.stg_services_ndpc_answers_daily_from_sdb ndpc
  LEFT JOIN pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined macro
    ON macro.scop_title = ndpc.sessiontitle
  WHERE ndpc.formanswerstatus IN ('6', '7')
    AND ndpc.formanswerdate::date >= CURRENT_DATE - INTERVAL '4 months'
    AND COALESCE(LOWER(TRIM(ndpc.isdeleted::text)), '') <> 'true'
    AND macro.m_market IS NOT NULL
    -- AND macro.rgn_region = :region
    -- AND macro.m_market   = :market
)
SELECT
  rgn_region AS region, m_area AS area, m_market AS market,
  COUNT(*) FILTER (WHERE formanswerstatus = '6') AS accepted_count,
  COUNT(*) FILTER (WHERE formanswerstatus = '7') AS rejected_count,
  COUNT(*) AS total_decisions,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '6') / NULLIF(COUNT(*), 0), 2) AS approved_pct,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '7') / NULLIF(COUNT(*), 0), 2) AS rejected_pct
FROM cop_answers
GROUP BY rgn_region, m_area, m_market
ORDER BY rejected_pct DESC NULLS LAST;
```

## Q4 — GC / Vendor (4-month)

```sql
WITH cop_answers AS (
  SELECT
    macro.rgn_region, macro.m_area, macro.m_market, macro.construction_gc,
    ndpc.formanswerstatus
  FROM pwc_macro_staging_schema.stg_services_ndpc_answers_daily_from_sdb ndpc
  LEFT JOIN pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined macro
    ON macro.scop_title = ndpc.sessiontitle
  WHERE ndpc.formanswerstatus IN ('6', '7')
    AND ndpc.formanswerdate::date >= CURRENT_DATE - INTERVAL '4 months'
    AND COALESCE(LOWER(TRIM(ndpc.isdeleted::text)), '') <> 'true'
    AND macro.construction_gc IS NOT NULL
    AND macro.m_market        IS NOT NULL
    -- AND macro.rgn_region      = :region
    -- AND macro.m_market        = :market
    -- AND macro.construction_gc = :gc
)
SELECT
  m_market AS market, construction_gc AS gc,
  COUNT(*) FILTER (WHERE formanswerstatus = '6') AS accepted_count,
  COUNT(*) FILTER (WHERE formanswerstatus = '7') AS rejected_count,
  COUNT(*) AS total_decisions,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '6') / NULLIF(COUNT(*), 0), 2) AS approved_pct,
  ROUND(100.0 * COUNT(*) FILTER (WHERE formanswerstatus = '7') / NULLIF(COUNT(*), 0), 2) AS rejected_pct
FROM cop_answers
GROUP BY m_market, construction_gc
ORDER BY rejected_pct DESC NULLS LAST;
```
'''