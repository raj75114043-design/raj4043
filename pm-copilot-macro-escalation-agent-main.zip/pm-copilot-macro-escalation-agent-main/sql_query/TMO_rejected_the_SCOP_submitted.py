TMO_rejected_the_SCOP_submitted = '''

## Q1 — National TMO SCOP Rejections (6-month window)

```sql
-- National count of TMO-rejected SCOPs: 6-month window
SELECT
  COUNT(DISTINCT pj_project_id)                                      AS rejected_projects,
  COUNT(*)                                                           AS rejection_count
FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
WHERE punchlist_received_from_t_mobile IS NOT NULL
  AND punchlist_received_from_t_mobile::date >= CURRENT_DATE - INTERVAL '6 months';
```

## Q2 — Region TMO SCOP Rejections (4-month window)

```sql
-- Region-level TMO-rejected SCOPs: 4-month window
SELECT
  rgn_region                                                         AS region,
  COUNT(DISTINCT pj_project_id)                                      AS rejected_projects,
  COUNT(*)                                                           AS rejection_count
FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
WHERE punchlist_received_from_t_mobile IS NOT NULL
  AND punchlist_received_from_t_mobile::date >= CURRENT_DATE - INTERVAL '4 months'
  AND rgn_region IS NOT NULL
  -- AND rgn_region = :region    -- uncomment when region is the entry point
GROUP BY rgn_region
ORDER BY rejection_count DESC NULLS LAST;
```

## Q3 — Market TMO SCOP Rejections (4-month window)

```sql
-- Market-level TMO-rejected SCOPs: 4-month window
SELECT
  rgn_region                                                         AS region,
  m_area                                                             AS area,
  m_market                                                           AS market,
  COUNT(DISTINCT pj_project_id)                                      AS rejected_projects,
  COUNT(*)                                                           AS rejection_count
FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
WHERE punchlist_received_from_t_mobile IS NOT NULL
  AND punchlist_received_from_t_mobile::date >= CURRENT_DATE - INTERVAL '4 months'
  AND m_market IS NOT NULL
  -- AND rgn_region = :region    -- when drilling from Region
  -- AND m_market   = :market    -- when market is the entry point
GROUP BY rgn_region, m_area, m_market
ORDER BY rejection_count DESC NULLS LAST;
```

## Q4 — GC / Vendor TMO SCOP Rejections (4-month window)

```sql
-- GC / Vendor-level TMO-rejected SCOPs: 4-month window
SELECT
  m_market                                                           AS market,
  construction_gc                                                    AS gc,
  COUNT(DISTINCT pj_project_id)                                      AS rejected_projects,
  COUNT(*)                                                           AS rejection_count
FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
WHERE punchlist_received_from_t_mobile IS NOT NULL
  AND punchlist_received_from_t_mobile::date >= CURRENT_DATE - INTERVAL '4 months'
  AND construction_gc IS NOT NULL
  AND m_market        IS NOT NULL
  -- AND rgn_region      = :region    -- when drilling from Region
  -- AND m_market        = :market    -- when drilling from Market
  -- AND construction_gc = :gc        -- when GC is the entry point
GROUP BY m_market, construction_gc
ORDER BY rejection_count DESC NULLS LAST;
```
'''