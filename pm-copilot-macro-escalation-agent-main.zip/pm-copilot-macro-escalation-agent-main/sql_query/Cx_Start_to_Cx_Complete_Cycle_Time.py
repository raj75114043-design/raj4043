Cx_Start_to_Cx_Complete_Cycle_Time = '''
## Q1 — National Cx Cycle Time (6-month window)

```sql
-- National NDPd Cx Start to Cx Complete Cycle Time (NTM): 6-month window
WITH cycle_base AS (
  SELECT
    rgn_region,
    m_area,
    m_market,
    construction_gc,
    pj_project_id,
    s_site_id,
    ms_1550_construction_start_actual::date    AS cx_start_date,
    ms_1555_construction_complete_actual::date AS cx_complete_date,
    (ms_1555_construction_complete_actual::date
      - ms_1550_construction_start_actual::date) AS cycle_time_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name    = 'NTM'
    AND smp_status  = 'Active'
    AND ntm_project_type NOT IN (
          'E2E06 - NSD Cx Mgmt',
          'E2E07 - OL/MOD Cx Mgmt'
        )
    AND ms_1550_construction_start_actual    IS NOT NULL
    AND ms_1555_construction_complete_actual IS NOT NULL
    AND ms_1555_construction_complete_actual::date
        >= CURRENT_DATE - INTERVAL '6 months'
)
SELECT
  COUNT(DISTINCT pj_project_id)                                         AS projects_count,
  COUNT(*)                                                              AS records_count,
  ROUND(AVG(cycle_time_days)::numeric, 2)                               AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_time_days)::numeric AS median_cycle_days,
  MIN(cycle_time_days)                                                  AS min_cycle_days,
  MAX(cycle_time_days)                                                  AS max_cycle_days
FROM cycle_base
WHERE cycle_time_days >= 0;   -- guard against bad/reversed timestamps
```

## Q2 — Region Cx Cycle Time (4-month window)

```sql
-- Region-level NDPd Cx Cycle Time (NTM): 4-month window
WITH cycle_base AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id,
    (ms_1555_construction_complete_actual::date
      - ms_1550_construction_start_actual::date) AS cycle_time_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name    = 'NTM'
    AND smp_status  = 'Active'
    AND ntm_project_type NOT IN (
          'E2E06 - NSD Cx Mgmt',
          'E2E07 - OL/MOD Cx Mgmt'
        )
    AND ms_1550_construction_start_actual    IS NOT NULL
    AND ms_1555_construction_complete_actual IS NOT NULL
    AND ms_1555_construction_complete_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND rgn_region IS NOT NULL
    -- AND rgn_region = :region    -- uncomment when region is the entry point
)
SELECT
  rgn_region                                                            AS region,
  COUNT(DISTINCT pj_project_id)                                         AS projects_count,
  COUNT(*)                                                              AS records_count,
  ROUND(AVG(cycle_time_days)::numeric, 2)                               AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_time_days)::numeric AS median_cycle_days,
  MIN(cycle_time_days)                                                  AS min_cycle_days,
  MAX(cycle_time_days)                                                  AS max_cycle_days
FROM cycle_base
WHERE cycle_time_days >= 0
GROUP BY rgn_region
ORDER BY avg_cycle_days DESC NULLS LAST;
```

## Q3 — Market Cx Cycle Time (4-month window)

```sql
-- Market-level NDPd Cx Cycle Time (NTM): 4-month window
WITH cycle_base AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id,
    (ms_1555_construction_complete_actual::date
      - ms_1550_construction_start_actual::date) AS cycle_time_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name    = 'NTM'
    AND smp_status  = 'Active'
    AND ntm_project_type NOT IN (
          'E2E06 - NSD Cx Mgmt',
          'E2E07 - OL/MOD Cx Mgmt'
        )
    AND ms_1550_construction_start_actual    IS NOT NULL
    AND ms_1555_construction_complete_actual IS NOT NULL
    AND ms_1555_construction_complete_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m_market IS NOT NULL
    -- AND rgn_region = :region    -- when drilling from Region
    -- AND m_market   = :market    -- when market is the entry point
)
SELECT
  rgn_region                                                            AS region,
  m_area                                                                AS area,
  m_market                                                              AS market,
  COUNT(DISTINCT pj_project_id)                                         AS projects_count,
  COUNT(*)                                                              AS records_count,
  ROUND(AVG(cycle_time_days)::numeric, 2)                               AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_time_days)::numeric AS median_cycle_days,
  MIN(cycle_time_days)                                                  AS min_cycle_days,
  MAX(cycle_time_days)                                                  AS max_cycle_days
FROM cycle_base
WHERE cycle_time_days >= 0
GROUP BY rgn_region, m_area, m_market
ORDER BY avg_cycle_days DESC NULLS LAST;
```

## Q4 — GC / Vendor Cx Cycle Time (4-month window)

```sql
-- GC / Vendor-level NDPd Cx Cycle Time (NTM): 4-month window
WITH cycle_base AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id,
    (ms_1555_construction_complete_actual::date
      - ms_1550_construction_start_actual::date) AS cycle_time_days
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name    = 'NTM'
    AND smp_status  = 'Active'
    AND ntm_project_type NOT IN (
          'E2E06 - NSD Cx Mgmt',
          'E2E07 - OL/MOD Cx Mgmt'
        )
    AND ms_1550_construction_start_actual    IS NOT NULL
    AND ms_1555_construction_complete_actual IS NOT NULL
    AND ms_1555_construction_complete_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND construction_gc IS NOT NULL
    AND m_market        IS NOT NULL
    -- AND rgn_region      = :region    -- when drilling from Region
    -- AND m_market        = :market    -- when drilling from Market
    -- AND construction_gc = :gc        -- when GC is the entry point
)
SELECT
  m_market                                                              AS market,
  construction_gc                                                       AS gc,
  COUNT(DISTINCT pj_project_id)                                         AS projects_count,
  COUNT(*)                                                              AS records_count,
  ROUND(AVG(cycle_time_days)::numeric, 2)                               AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_time_days)::numeric AS median_cycle_days,
  MIN(cycle_time_days)                                                  AS min_cycle_days,
  MAX(cycle_time_days)                                                  AS max_cycle_days
FROM cycle_base
WHERE cycle_time_days >= 0
GROUP BY m_market, construction_gc
ORDER BY avg_cycle_days DESC NULLS LAST;
```
'''