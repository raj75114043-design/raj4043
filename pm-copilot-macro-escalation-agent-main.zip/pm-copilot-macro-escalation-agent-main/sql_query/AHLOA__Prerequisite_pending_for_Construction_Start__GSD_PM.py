AHLOA__Prerequisite_pending_for_Construction_Start__GSD_PM = '''
### Q1 — National (6-month)

```sql
-- National: AHLOA Prerequisite Pending (GSD PM), 6-month activity window
WITH ahloa_sites AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id, smp_id,
    pj_a_3875_bom_received_bom_in_aims_finish         AS prereq_1_bom_received,
    pj_a_3710_ran_entitlement_complete_finish         AS prereq_2_ran_entitlement,
    pj_a_4075_construction_ntp_submitted_to_gc_finish AS prereq_3_ntp_submitted,
    s_24x7_site_access                                AS prereq_4_site_access,
    ms_1555_construction_complete_cpo_custom_field    AS prereq_5_cpo,
    ms1555_construction_complete_spo                  AS prereq_6_spo,
    write_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name = 'AHLOB Modernization'
    AND pj_a_5175_construction_complete_finish IS NULL   -- still in pipeline
    AND COALESCE(
          pj_a_4075_construction_ntp_submitted_to_gc_finish::date,
          pj_a_3710_ran_entitlement_complete_finish::date,
          pj_a_3875_bom_received_bom_in_aims_finish::date,
          write_date::date
        ) >= CURRENT_DATE - INTERVAL '6 months'
),
prereq_flag AS (
  SELECT *,
    CASE WHEN NULLIF(TRIM(prereq_1_bom_received::text), '') IS NULL
           OR NULLIF(TRIM(prereq_2_ran_entitlement::text), '') IS NULL
           OR NULLIF(TRIM(prereq_3_ntp_submitted::text), '')   IS NULL
           OR NULLIF(TRIM(prereq_4_site_access::text), '')     IS NULL
           OR NULLIF(TRIM(prereq_5_cpo::text), '')             IS NULL
           OR NULLIF(TRIM(prereq_6_spo::text), '')             IS NULL
         THEN 1 ELSE 0 END AS is_pending
  FROM ahloa_sites
)
SELECT
  COUNT(*)                                             AS total_sites,
  SUM(is_pending)                                      AS pending_sites,
  COUNT(*) - SUM(is_pending)                           AS ready_sites,
  ROUND(100.0 * SUM(is_pending) / NULLIF(COUNT(*), 0), 2) AS pending_pct
FROM prereq_flag;
```

### Q2 — Region (4-month)

```sql
-- Region-level: AHLOA Prerequisite Pending, 4-month window
WITH ahloa_sites AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id, smp_id,
    pj_a_3875_bom_received_bom_in_aims_finish         AS prereq_1,
    pj_a_3710_ran_entitlement_complete_finish         AS prereq_2,
    pj_a_4075_construction_ntp_submitted_to_gc_finish AS prereq_3,
    s_24x7_site_access                                AS prereq_4,
    ms_1555_construction_complete_cpo_custom_field    AS prereq_5,
    ms1555_construction_complete_spo                  AS prereq_6
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name = 'AHLOB Modernization'
    AND pj_a_5175_construction_complete_finish IS NULL
    AND COALESCE(
          pj_a_4075_construction_ntp_submitted_to_gc_finish::date,
          pj_a_3710_ran_entitlement_complete_finish::date,
          pj_a_3875_bom_received_bom_in_aims_finish::date,
          write_date::date
        ) >= CURRENT_DATE - INTERVAL '4 months'
    AND rgn_region IS NOT NULL
    -- AND rgn_region = :region
),
prereq_flag AS (
  SELECT rgn_region,
    CASE WHEN NULLIF(TRIM(prereq_1::text), '') IS NULL
           OR NULLIF(TRIM(prereq_2::text), '') IS NULL
           OR NULLIF(TRIM(prereq_3::text), '') IS NULL
           OR NULLIF(TRIM(prereq_4::text), '') IS NULL
           OR NULLIF(TRIM(prereq_5::text), '') IS NULL
           OR NULLIF(TRIM(prereq_6::text), '') IS NULL
         THEN 1 ELSE 0 END AS is_pending
  FROM ahloa_sites
)
SELECT
  rgn_region                                           AS region,
  COUNT(*)                                             AS total_sites,
  SUM(is_pending)                                      AS pending_sites,
  COUNT(*) - SUM(is_pending)                           AS ready_sites,
  ROUND(100.0 * SUM(is_pending) / NULLIF(COUNT(*), 0), 2) AS pending_pct
FROM prereq_flag
GROUP BY rgn_region
ORDER BY pending_pct DESC NULLS LAST;
```

### Q3 — Market (4-month)

```sql
-- Market-level: AHLOA Prerequisite Pending, 4-month window
WITH ahloa_sites AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc, s_site_id,
    pj_a_3875_bom_received_bom_in_aims_finish         AS prereq_1,
    pj_a_3710_ran_entitlement_complete_finish         AS prereq_2,
    pj_a_4075_construction_ntp_submitted_to_gc_finish AS prereq_3,
    s_24x7_site_access                                AS prereq_4,
    ms_1555_construction_complete_cpo_custom_field    AS prereq_5,
    ms1555_construction_complete_spo                  AS prereq_6
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name = 'AHLOB Modernization'
    AND pj_a_5175_construction_complete_finish IS NULL
    AND COALESCE(
          pj_a_4075_construction_ntp_submitted_to_gc_finish::date,
          pj_a_3710_ran_entitlement_complete_finish::date,
          pj_a_3875_bom_received_bom_in_aims_finish::date,
          write_date::date
        ) >= CURRENT_DATE - INTERVAL '4 months'
    AND m_market IS NOT NULL
    -- AND rgn_region = :region
    -- AND m_market   = :market
),
prereq_flag AS (
  SELECT rgn_region, m_area, m_market,
    CASE WHEN NULLIF(TRIM(prereq_1::text), '') IS NULL
           OR NULLIF(TRIM(prereq_2::text), '') IS NULL
           OR NULLIF(TRIM(prereq_3::text), '') IS NULL
           OR NULLIF(TRIM(prereq_4::text), '') IS NULL
           OR NULLIF(TRIM(prereq_5::text), '') IS NULL
           OR NULLIF(TRIM(prereq_6::text), '') IS NULL
         THEN 1 ELSE 0 END AS is_pending
  FROM ahloa_sites
)
SELECT
  rgn_region                                           AS region,
  m_area                                               AS area,
  m_market                                             AS market,
  COUNT(*)                                             AS total_sites,
  SUM(is_pending)                                      AS pending_sites,
  COUNT(*) - SUM(is_pending)                           AS ready_sites,
  ROUND(100.0 * SUM(is_pending) / NULLIF(COUNT(*), 0), 2) AS pending_pct
FROM prereq_flag
GROUP BY rgn_region, m_area, m_market
ORDER BY pending_pct DESC NULLS LAST;
```

### Q4 — GC / Vendor (4-month)

```sql
-- GC-level: AHLOA Prerequisite Pending, 4-month window
WITH ahloa_sites AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc, s_site_id,
    pj_a_3875_bom_received_bom_in_aims_finish         AS prereq_1,
    pj_a_3710_ran_entitlement_complete_finish         AS prereq_2,
    pj_a_4075_construction_ntp_submitted_to_gc_finish AS prereq_3,
    s_24x7_site_access                                AS prereq_4,
    ms_1555_construction_complete_cpo_custom_field    AS prereq_5,
    ms1555_construction_complete_spo                  AS prereq_6
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name = 'AHLOB Modernization'
    AND pj_a_5175_construction_complete_finish IS NULL
    AND COALESCE(
          pj_a_4075_construction_ntp_submitted_to_gc_finish::date,
          pj_a_3710_ran_entitlement_complete_finish::date,
          pj_a_3875_bom_received_bom_in_aims_finish::date,
          write_date::date
        ) >= CURRENT_DATE - INTERVAL '4 months'
    AND construction_gc IS NOT NULL
    AND m_market IS NOT NULL
    -- AND rgn_region      = :region
    -- AND m_market        = :market
    -- AND construction_gc = :gc
),
prereq_flag AS (
  SELECT m_market, construction_gc,
    CASE WHEN NULLIF(TRIM(prereq_1::text), '') IS NULL
           OR NULLIF(TRIM(prereq_2::text), '') IS NULL
           OR NULLIF(TRIM(prereq_3::text), '') IS NULL
           OR NULLIF(TRIM(prereq_4::text), '') IS NULL
           OR NULLIF(TRIM(prereq_5::text), '') IS NULL
           OR NULLIF(TRIM(prereq_6::text), '') IS NULL
         THEN 1 ELSE 0 END AS is_pending
  FROM ahloa_sites
)
SELECT
  m_market                                             AS market,
  construction_gc                                      AS gc,
  COUNT(*)                                             AS total_sites,
  SUM(is_pending)                                      AS pending_sites,
  COUNT(*) - SUM(is_pending)                           AS ready_sites,
  ROUND(100.0 * SUM(is_pending) / NULLIF(COUNT(*), 0), 2) AS pending_pct
FROM prereq_flag
GROUP BY m_market, construction_gc
ORDER BY pending_pct DESC NULLS LAST;
```

---

## Version B — Live pipeline (no time window)

Drop the date filter entirely. Semantically cleaner for "what's currently pending" — escalation agents usually want this. Example for the market cut:

```sql
-- Market-level: AHLOA Prerequisite Pending, live pipeline (no time filter)
WITH ahloa_sites AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc, s_site_id,
    pj_a_3875_bom_received_bom_in_aims_finish         AS prereq_1,
    pj_a_3710_ran_entitlement_complete_finish         AS prereq_2,
    pj_a_4075_construction_ntp_submitted_to_gc_finish AS prereq_3,
    s_24x7_site_access                                AS prereq_4,
    ms_1555_construction_complete_cpo_custom_field    AS prereq_5,
    ms1555_construction_complete_spo                  AS prereq_6
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE smp_name = 'AHLOB Modernization'
    AND pj_a_5175_construction_complete_finish IS NULL
    AND m_market IS NOT NULL
),
prereq_flag AS (
  SELECT rgn_region, m_area, m_market,
    CASE WHEN NULLIF(TRIM(prereq_1::text), '') IS NULL
           OR NULLIF(TRIM(prereq_2::text), '') IS NULL
           OR NULLIF(TRIM(prereq_3::text), '') IS NULL
           OR NULLIF(TRIM(prereq_4::text), '') IS NULL
           OR NULLIF(TRIM(prereq_5::text), '') IS NULL
           OR NULLIF(TRIM(prereq_6::text), '') IS NULL
         THEN 1 ELSE 0 END AS is_pending
  FROM ahloa_sites
)
SELECT
  rgn_region AS region, m_area AS area, m_market AS market,
  COUNT(*)                                             AS total_sites,
  SUM(is_pending)                                      AS pending_sites,
  ROUND(100.0 * SUM(is_pending) / NULLIF(COUNT(*), 0), 2) AS pending_pct
FROM prereq_flag
GROUP BY rgn_region, m_area, m_market
ORDER BY pending_sites DESC NULLS LAST;
```

Apply the same "drop the date filter, drop `write_date` fallback" edit to Q1/Q2/Q4 if you want all four as Version B.

---

## Bonus — Per-prerequisite breakdown

This is what the escalation agent actually wants to surface: *which* prerequisite is blocking, not just how many sites are blocked. Useful as a second-hop query after the cascade lands on a specific market/GC.

```sql
-- Which prerequisite is missing, across AHLOA pending sites
SELECT
  rgn_region AS region,
  m_market   AS market,
  construction_gc AS gc,
  SUM(CASE WHEN NULLIF(TRIM(pj_a_3875_bom_received_bom_in_aims_finish::text), '') IS NULL THEN 1 ELSE 0 END) AS missing_bom_received,
  SUM(CASE WHEN NULLIF(TRIM(pj_a_3710_ran_entitlement_complete_finish::text), '') IS NULL THEN 1 ELSE 0 END) AS missing_ran_entitlement,
  SUM(CASE WHEN NULLIF(TRIM(pj_a_4075_construction_ntp_submitted_to_gc_finish::text), '') IS NULL THEN 1 ELSE 0 END) AS missing_ntp_submitted,
  SUM(CASE WHEN NULLIF(TRIM(s_24x7_site_access::text), '') IS NULL THEN 1 ELSE 0 END) AS missing_site_access,
  SUM(CASE WHEN NULLIF(TRIM(ms_1555_construction_complete_cpo_custom_field::text), '') IS NULL THEN 1 ELSE 0 END) AS missing_cpo,
  SUM(CASE WHEN NULLIF(TRIM(ms1555_construction_complete_spo::text), '') IS NULL THEN 1 ELSE 0 END) AS missing_spo,
  COUNT(*) AS total_pending_in_scope
FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
WHERE smp_name = 'AHLOB Modernization'
  AND pj_a_5175_construction_complete_finish IS NULL
  -- AND rgn_region = :region / m_market = :market / construction_gc = :gc
GROUP BY rgn_region, m_market, construction_gc
ORDER BY total_pending_in_scope DESC;
```
'''