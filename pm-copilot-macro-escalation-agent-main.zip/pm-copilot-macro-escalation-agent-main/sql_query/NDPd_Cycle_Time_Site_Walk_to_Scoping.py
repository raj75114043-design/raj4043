NDPd_Cycle_Time_Site_Walk_to_Scoping='''
## Q1 — National NDPd Cycle Time: Site Walk → Scoping (6-month window)

```sql
-- National NDPd Cycle Time (Site Walk → Scoping): 6-month window
WITH cycle_base AS (
  SELECT
    rgn_region,
    m_area,
    m_market,
    construction_gc,
    pj_project_id,
    s_site_id,
    smp_name,
    GREATEST(
      ms_1316_pre_con_site_walk_completed_actual::date,
      ms_1321_talon_view_drone_svcs_actual::date
    )                                                     AS start_date,
    ms_1327_scoping_and_quoting_package_validated_actual::date AS end_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE ms_1327_scoping_and_quoting_package_validated_actual IS NOT NULL
    AND (
          ms_1316_pre_con_site_walk_completed_actual IS NOT NULL
       OR ms_1321_talon_view_drone_svcs_actual       IS NOT NULL
    )
    AND ms_1327_scoping_and_quoting_package_validated_actual::date
        >= CURRENT_DATE - INTERVAL '6 months'
),
cycle_eval AS (
  SELECT
    *,
    (end_date - start_date) AS cycle_days
  FROM cycle_base
  WHERE start_date IS NOT NULL
    AND (end_date - start_date) >= 0
)
SELECT
  COUNT(*)                                                     AS site_count,
  ROUND(AVG(cycle_days)::numeric, 2)                           AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days)      AS median_cycle_days,
  MIN(cycle_days)                                              AS min_cycle_days,
  MAX(cycle_days)                                              AS max_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycle_days)      AS p90_cycle_days
FROM cycle_eval;
```

## Q2 — Region NDPd Cycle Time (4-month window)

```sql
-- Region-level NDPd Cycle Time (Site Walk → Scoping): 4-month window
WITH cycle_base AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    GREATEST(
      ms_1316_pre_con_site_walk_completed_actual::date,
      ms_1321_talon_view_drone_svcs_actual::date
    )                                                     AS start_date,
    ms_1327_scoping_and_quoting_package_validated_actual::date AS end_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE ms_1327_scoping_and_quoting_package_validated_actual IS NOT NULL
    AND (
          ms_1316_pre_con_site_walk_completed_actual IS NOT NULL
       OR ms_1321_talon_view_drone_svcs_actual       IS NOT NULL
    )
    AND ms_1327_scoping_and_quoting_package_validated_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND rgn_region IS NOT NULL
    -- AND rgn_region = :region    -- uncomment when region is the entry point
),
cycle_eval AS (
  SELECT *, (end_date - start_date) AS cycle_days
  FROM cycle_base
  WHERE start_date IS NOT NULL AND (end_date - start_date) >= 0
)
SELECT
  rgn_region                                                   AS region,
  COUNT(*)                                                     AS site_count,
  ROUND(AVG(cycle_days)::numeric, 2)                           AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days)      AS median_cycle_days,
  MIN(cycle_days)                                              AS min_cycle_days,
  MAX(cycle_days)                                              AS max_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycle_days)      AS p90_cycle_days
FROM cycle_eval
GROUP BY rgn_region
ORDER BY avg_cycle_days DESC NULLS LAST;
```

## Q3 — Market NDPd Cycle Time (4-month window)

```sql
-- Market-level NDPd Cycle Time (Site Walk → Scoping): 4-month window
WITH cycle_base AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    GREATEST(
      ms_1316_pre_con_site_walk_completed_actual::date,
      ms_1321_talon_view_drone_svcs_actual::date
    )                                                     AS start_date,
    ms_1327_scoping_and_quoting_package_validated_actual::date AS end_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE ms_1327_scoping_and_quoting_package_validated_actual IS NOT NULL
    AND (
          ms_1316_pre_con_site_walk_completed_actual IS NOT NULL
       OR ms_1321_talon_view_drone_svcs_actual       IS NOT NULL
    )
    AND ms_1327_scoping_and_quoting_package_validated_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND m_market IS NOT NULL
    -- AND rgn_region = :region    -- when drilling from Region
    -- AND m_market   = :market    -- when market is the entry point
),
cycle_eval AS (
  SELECT *, (end_date - start_date) AS cycle_days
  FROM cycle_base
  WHERE start_date IS NOT NULL AND (end_date - start_date) >= 0
)
SELECT
  rgn_region                                                   AS region,
  m_area                                                       AS area,
  m_market                                                     AS market,
  COUNT(*)                                                     AS site_count,
  ROUND(AVG(cycle_days)::numeric, 2)                           AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days)      AS median_cycle_days,
  MIN(cycle_days)                                              AS min_cycle_days,
  MAX(cycle_days)                                              AS max_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycle_days)      AS p90_cycle_days
FROM cycle_eval
GROUP BY rgn_region, m_area, m_market
ORDER BY avg_cycle_days DESC NULLS LAST;
```

## Q4 — GC / Vendor NDPd Cycle Time (4-month window)

```sql
-- GC / Vendor-level NDPd Cycle Time (Site Walk → Scoping): 4-month window
WITH cycle_base AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id,
    GREATEST(
      ms_1316_pre_con_site_walk_completed_actual::date,
      ms_1321_talon_view_drone_svcs_actual::date
    )                                                     AS start_date,
    ms_1327_scoping_and_quoting_package_validated_actual::date AS end_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE ms_1327_scoping_and_quoting_package_validated_actual IS NOT NULL
    AND (
          ms_1316_pre_con_site_walk_completed_actual IS NOT NULL
       OR ms_1321_talon_view_drone_svcs_actual       IS NOT NULL
    )
    AND ms_1327_scoping_and_quoting_package_validated_actual::date
        >= CURRENT_DATE - INTERVAL '4 months'
    AND construction_gc IS NOT NULL
    AND m_market        IS NOT NULL
    -- AND rgn_region      = :region    -- when drilling from Region
    -- AND m_market        = :market    -- when drilling from Market
    -- AND construction_gc = :gc        -- when GC is the entry point
),
cycle_eval AS (
  SELECT *, (end_date - start_date) AS cycle_days
  FROM cycle_base
  WHERE start_date IS NOT NULL AND (end_date - start_date) >= 0
)
SELECT
  m_market                                                     AS market,
  construction_gc                                              AS gc,
  COUNT(*)                                                     AS site_count,
  ROUND(AVG(cycle_days)::numeric, 2)                           AS avg_cycle_days,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY cycle_days)      AS median_cycle_days,
  MIN(cycle_days)                                              AS min_cycle_days,
  MAX(cycle_days)                                              AS max_cycle_days,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY cycle_days)      AS p90_cycle_days
FROM cycle_eval
GROUP BY m_market, construction_gc
ORDER BY avg_cycle_days DESC NULLS LAST;
```
'''