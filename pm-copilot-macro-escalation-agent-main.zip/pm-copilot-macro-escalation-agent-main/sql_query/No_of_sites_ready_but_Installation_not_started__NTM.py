No_of_sites_ready_but_Installation_not_started__NTM = '''
## Q1 — National: Sites ready but installation not started (6-month window)

```sql
-- National: NTM sites ready >7 days but installation not started (6-month window)
WITH ready_sites AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id, smp_id, smp_name,
    pj_a_3875_bom_received_bom_in_aims_finish::date        AS bom_received_date,
    pj_a_3710_ran_entitlement_complete_finish::date        AS ran_entitlement_date,
    pj_a_4075_construction_ntp_submitted_to_gc_finish::date AS ntp_submitted_date,
    GREATEST(
      pj_a_3875_bom_received_bom_in_aims_finish::date,
      pj_a_3710_ran_entitlement_complete_finish::date,
      pj_a_4075_construction_ntp_submitted_to_gc_finish::date
    )                                                      AS prereq_ready_date,
    pj_a_4225_construction_start_finish
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE
    -- Date prerequisites: all three non-blank
        pj_a_3875_bom_received_bom_in_aims_finish        IS NOT NULL
    AND pj_a_3710_ran_entitlement_complete_finish        IS NOT NULL
    AND pj_a_4075_construction_ntp_submitted_to_gc_finish IS NOT NULL
    -- Flag/reference prerequisites: non-blank text
    AND COALESCE(NULLIF(TRIM(s_24x7_site_access), ''), NULL)               IS NOT NULL
    AND COALESCE(NULLIF(TRIM(ms1555_construction_complete_so_header), ''), NULL) IS NOT NULL
    AND COALESCE(NULLIF(TRIM(ms1555_construction_complete_spo), ''), NULL) IS NOT NULL
    -- NTM / MACRO project filter
    AND smp_name = 'NTM'
    -- KPI cutoff: prereqs cleared > 7 days ago
    AND GREATEST(
          pj_a_3875_bom_received_bom_in_aims_finish::date,
          pj_a_3710_ran_entitlement_complete_finish::date,
          pj_a_4075_construction_ntp_submitted_to_gc_finish::date
        ) < CURRENT_DATE - INTERVAL '7 days'
    -- Reporting window
    AND GREATEST(
          pj_a_3875_bom_received_bom_in_aims_finish::date,
          pj_a_3710_ran_entitlement_complete_finish::date,
          pj_a_4075_construction_ntp_submitted_to_gc_finish::date
        ) >= CURRENT_DATE - INTERVAL '6 months'
    -- Installation NOT started
    AND pj_a_4225_construction_start_finish IS NULL
)
SELECT
  COUNT(DISTINCT s_site_id)                                         AS sites_ready_not_started,
  COUNT(DISTINCT pj_project_id)                                     AS projects_ready_not_started,
  ROUND(AVG(CURRENT_DATE - prereq_ready_date)::numeric, 1)          AS avg_days_pending,
  MAX(CURRENT_DATE - prereq_ready_date)                             AS max_days_pending,
  PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY CURRENT_DATE - prereq_ready_date) AS median_days_pending
FROM ready_sites;
```

## Q2 — Region (4-month window)

```sql
-- Region: NTM sites ready >7 days but installation not started (4-month window)
WITH ready_sites AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id, smp_id, smp_name,
    GREATEST(
      pj_a_3875_bom_received_bom_in_aims_finish::date,
      pj_a_3710_ran_entitlement_complete_finish::date,
      pj_a_4075_construction_ntp_submitted_to_gc_finish::date
    ) AS prereq_ready_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE pj_a_3875_bom_received_bom_in_aims_finish        IS NOT NULL
    AND pj_a_3710_ran_entitlement_complete_finish        IS NOT NULL
    AND pj_a_4075_construction_ntp_submitted_to_gc_finish IS NOT NULL
    AND COALESCE(NULLIF(TRIM(s_24x7_site_access), ''), NULL)               IS NOT NULL
    AND COALESCE(NULLIF(TRIM(ms1555_construction_complete_so_header), ''), NULL) IS NOT NULL
    AND COALESCE(NULLIF(TRIM(ms1555_construction_complete_spo), ''), NULL) IS NOT NULL
    AND smp_name = 'NTM'
    AND GREATEST(
          pj_a_3875_bom_received_bom_in_aims_finish::date,
          pj_a_3710_ran_entitlement_complete_finish::date,
          pj_a_4075_construction_ntp_submitted_to_gc_finish::date
        ) < CURRENT_DATE - INTERVAL '7 days'
    AND GREATEST(
          pj_a_3875_bom_received_bom_in_aims_finish::date,
          pj_a_3710_ran_entitlement_complete_finish::date,
          pj_a_4075_construction_ntp_submitted_to_gc_finish::date
        ) >= CURRENT_DATE - INTERVAL '4 months'
    AND pj_a_4225_construction_start_finish IS NULL
    AND rgn_region IS NOT NULL
    -- AND rgn_region = :region
)
SELECT
  rgn_region                                                        AS region,
  COUNT(DISTINCT s_site_id)                                         AS sites_ready_not_started,
  COUNT(DISTINCT pj_project_id)                                     AS projects_ready_not_started,
  ROUND(AVG(CURRENT_DATE - prereq_ready_date)::numeric, 1)          AS avg_days_pending,
  MAX(CURRENT_DATE - prereq_ready_date)                             AS max_days_pending
FROM ready_sites
GROUP BY rgn_region
ORDER BY sites_ready_not_started DESC NULLS LAST;
```

## Q3 — Market (4-month window)

```sql
-- Market: NTM sites ready >7 days but installation not started (4-month window)
WITH ready_sites AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id, smp_id, smp_name,
    GREATEST(
      pj_a_3875_bom_received_bom_in_aims_finish::date,
      pj_a_3710_ran_entitlement_complete_finish::date,
      pj_a_4075_construction_ntp_submitted_to_gc_finish::date
    ) AS prereq_ready_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE pj_a_3875_bom_received_bom_in_aims_finish        IS NOT NULL
    AND pj_a_3710_ran_entitlement_complete_finish        IS NOT NULL
    AND pj_a_4075_construction_ntp_submitted_to_gc_finish IS NOT NULL
    AND COALESCE(NULLIF(TRIM(s_24x7_site_access), ''), NULL)               IS NOT NULL
    AND COALESCE(NULLIF(TRIM(ms1555_construction_complete_so_header), ''), NULL) IS NOT NULL
    AND COALESCE(NULLIF(TRIM(ms1555_construction_complete_spo), ''), NULL) IS NOT NULL
    AND smp_name = 'NTM'
    AND GREATEST(
          pj_a_3875_bom_received_bom_in_aims_finish::date,
          pj_a_3710_ran_entitlement_complete_finish::date,
          pj_a_4075_construction_ntp_submitted_to_gc_finish::date
        ) < CURRENT_DATE - INTERVAL '7 days'
    AND GREATEST(
          pj_a_3875_bom_received_bom_in_aims_finish::date,
          pj_a_3710_ran_entitlement_complete_finish::date,
          pj_a_4075_construction_ntp_submitted_to_gc_finish::date
        ) >= CURRENT_DATE - INTERVAL '4 months'
    AND pj_a_4225_construction_start_finish IS NULL
    AND m_market IS NOT NULL
    -- AND rgn_region = :region
    -- AND m_market   = :market
)
SELECT
  rgn_region                                                        AS region,
  m_area                                                            AS area,
  m_market                                                          AS market,
  COUNT(DISTINCT s_site_id)                                         AS sites_ready_not_started,
  COUNT(DISTINCT pj_project_id)                                     AS projects_ready_not_started,
  ROUND(AVG(CURRENT_DATE - prereq_ready_date)::numeric, 1)          AS avg_days_pending,
  MAX(CURRENT_DATE - prereq_ready_date)                             AS max_days_pending
FROM ready_sites
GROUP BY rgn_region, m_area, m_market
ORDER BY sites_ready_not_started DESC NULLS LAST;
```

## Q4 — GC / Vendor (4-month window)

```sql
-- GC / Vendor: NTM sites ready >7 days but installation not started (4-month window)
WITH ready_sites AS (
  SELECT
    rgn_region, m_area, m_market, construction_gc,
    pj_project_id, s_site_id, smp_id, smp_name,
    GREATEST(
      pj_a_3875_bom_received_bom_in_aims_finish::date,
      pj_a_3710_ran_entitlement_complete_finish::date,
      pj_a_4075_construction_ntp_submitted_to_gc_finish::date
    ) AS prereq_ready_date
  FROM pwc_macro_staging_schema.stg_ndpd_mbt_tmobile_macro_combined
  WHERE pj_a_3875_bom_received_bom_in_aims_finish        IS NOT NULL
    AND pj_a_3710_ran_entitlement_complete_finish        IS NOT NULL
    AND pj_a_4075_construction_ntp_submitted_to_gc_finish IS NOT NULL
    AND COALESCE(NULLIF(TRIM(s_24x7_site_access), ''), NULL)               IS NOT NULL
    AND COALESCE(NULLIF(TRIM(ms1555_construction_complete_so_header), ''), NULL) IS NOT NULL
    AND COALESCE(NULLIF(TRIM(ms1555_construction_complete_spo), ''), NULL) IS NOT NULL
    AND smp_name = 'NTM'
    AND GREATEST(
          pj_a_3875_bom_received_bom_in_aims_finish::date,
          pj_a_3710_ran_entitlement_complete_finish::date,
          pj_a_4075_construction_ntp_submitted_to_gc_finish::date
        ) < CURRENT_DATE - INTERVAL '7 days'
    AND GREATEST(
          pj_a_3875_bom_received_bom_in_aims_finish::date,
          pj_a_3710_ran_entitlement_complete_finish::date,
          pj_a_4075_construction_ntp_submitted_to_gc_finish::date
        ) >= CURRENT_DATE - INTERVAL '4 months'
    AND pj_a_4225_construction_start_finish IS NULL
    AND construction_gc IS NOT NULL
    AND m_market        IS NOT NULL
    -- AND rgn_region      = :region
    -- AND m_market        = :market
    -- AND construction_gc = :gc
)
SELECT
  m_market                                                          AS market,
  construction_gc                                                   AS gc,
  COUNT(DISTINCT s_site_id)                                         AS sites_ready_not_started,
  COUNT(DISTINCT pj_project_id)                                     AS projects_ready_not_started,
  ROUND(AVG(CURRENT_DATE - prereq_ready_date)::numeric, 1)          AS avg_days_pending,
  MAX(CURRENT_DATE - prereq_ready_date)                             AS max_days_pending
FROM ready_sites
GROUP BY m_market, construction_gc
ORDER BY sites_ready_not_started DESC NULLS LAST;
```
'''